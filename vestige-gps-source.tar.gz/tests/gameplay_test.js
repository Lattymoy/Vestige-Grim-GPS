// gameplay_test.js — Tests scene update loops and interactions
import puppeteer from 'puppeteer-core';
import { spawn } from 'child_process';

const PORT = 4175;
let server;

async function startServer() {
    return new Promise((resolve, reject) => {
        server = spawn('npx', ['vite', 'preview', '--port', String(PORT), '--host'], {
            cwd: process.cwd(), stdio: ['pipe', 'pipe', 'pipe']
        });
        let started = false;
        const timeout = setTimeout(() => { if (!started) reject(new Error('timeout')); }, 15000);
        const handler = (data) => {
            if (data.toString().includes('http') && !started) {
                started = true; clearTimeout(timeout);
                setTimeout(() => resolve(), 500);
            }
        };
        server.stdout.on('data', handler);
        server.stderr.on('data', handler);
    });
}

async function run() {
    console.log('Building...');
    const build = spawn('npx', ['vite', 'build'], { cwd: process.cwd(), stdio: 'pipe' });
    await new Promise((res, rej) => build.on('close', c => c === 0 ? res() : rej()));

    console.log('Starting server...');
    await startServer();

    const browser = await puppeteer.launch({
        executablePath: '/usr/bin/google-chrome-stable',
        headless: 'new',
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-web-security']
    });

    const page = await browser.newPage();
    const allErrors = [];

    page.on('console', (msg) => {
        if (msg.type() === 'error') {
            const text = msg.text();
            if (text.includes('navigator.vibrate') || text.includes('favicon') || text.includes('404')) return;
            if (text.includes('Blocked call to')) return;
            allErrors.push(text);
        }
    });
    page.on('pageerror', (err) => allErrors.push(`PAGE: ${err.message}`));

    await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'domcontentloaded', timeout: 10000 });
    await new Promise(r => setTimeout(r, 3000));

    const results = {};

    async function testSceneGameplay(name, duration, setupFn) {
        const before = allErrors.length;

        // Start scene with optional setup
        await page.evaluate((n, setup) => {
            const g = window.__vestige?.game;
            if (!g) return;
            // Stop everything
            g.scene.scenes.forEach(s => { if (s.sys?.isActive()) g.scene.stop(s.sys.settings.key); });
            
            // If scene needs data, set it up
            if (setup) {
                try { eval(setup); } catch(e) { console.error('SETUP: ' + e.message); }
            }
            
            try { g.scene.start(n); } catch(e) { console.error('START: ' + e.message); }
        }, name, setupFn || null);

        // Let it tick for the specified duration
        await new Promise(r => setTimeout(r, duration));

        // Check state
        const state = await page.evaluate((n) => {
            const g = window.__vestige?.game;
            const scene = g?.scene?.scenes?.find(s => s.sys?.settings?.key === n);
            if (!scene) return { active: false, hasUpdate: false };
            return {
                active: scene.sys?.isActive(),
                hasUpdate: typeof scene.update === 'function',
                childCount: scene.children?.list?.length || 0,
            };
        }, name);

        const newErrors = allErrors.slice(before);
        const unique = [...new Set(newErrors.map(e => e.substring(0, 80)))];
        results[name] = { 
            active: state.active, 
            children: state.childCount,
            errorCount: unique.length,
            errors: unique.slice(0, 5) 
        };

        const tag = unique.length === 0 ? '✓' : '✗';
        console.log(`  ${tag} ${name.padEnd(25)} children=${String(state.childCount).padEnd(4)} ${unique.length} unique errors (${newErrors.length} total)`);
        unique.slice(0, 3).forEach(e => console.log(`    ${e.substring(0, 140)}`));
    }

    console.log('\nTesting scene update loops (3s each)...\n');

    // Test scenes that should work without special data
    await testSceneGameplay('TitleScene', 3000);
    await testSceneGameplay('BiomeSelectScene', 3000);
    await testSceneGameplay('StoryScene', 3000);
    await testSceneGameplay('CubeSimScene', 3000);

    // Scenes that need game state
    const stateSetup = `
        const g = window.__vestige?.game;
        if (g) {
            g.registry.set('gameState', {
                health: 100, maxHealth: 100, scrap: 50, rep: 10,
                inventory: [], equipment: { weapon: null, melee: null, armor: null },
                foundry: 'terracorp', biome: 'wastes', currentNode: null,
                survivors: [], squad: [], difficulty: 1, reach: 1,
                route: { nodes: [], currentIndex: 0 },
                convoyHP: 100, maxConvoyHP: 100,
            });
        }
    `;

    await testSceneGameplay('SafehouseScene', 3000, stateSetup);
    await testSceneGameplay('MapScene', 3000, stateSetup);
    await testSceneGameplay('HavenScene', 3000, stateSetup);
    await testSceneGameplay('InteriorScene', 3000, stateSetup);
    await testSceneGameplay('TraversalScene', 3000, stateSetup);
    await testSceneGameplay('SurvivorSelectScene', 3000, stateSetup);

    // GameScene needs more specific data
    const gameSetup = `
        const g = window.__vestige?.game;
        if (g) {
            g.registry.set('gameState', {
                health: 100, maxHealth: 100, scrap: 50, rep: 10,
                inventory: [], equipment: { 
                    weapon: { name: 'Rusty Pistol', foundry: 'terracorp', stats: { damage: 8, fireRate: 40, accuracy: 60, crit: 10, mag: 12, reload: 50, pierce: 1, targetRange: 1 } },
                    melee: { name: 'Pipe Wrench', foundry: 'scrap', stats: { meleeDamage: 15, meleeRange: 30, meleeSpeed: 40 } },
                    armor: null
                },
                foundry: 'terracorp', biome: 'wastes', currentNode: { type: 'defense', biome: 'wastes' },
                survivors: [], squad: [], difficulty: 1, reach: 1,
                route: { nodes: [{ type: 'defense', biome: 'wastes' }], currentIndex: 0 },
                convoyHP: 100, maxConvoyHP: 100,
                mode: 'defense',
            });
        }
    `;
    await testSceneGameplay('GameScene', 3000, gameSetup);

    // Portal dungeon
    await testSceneGameplay('PortalDungeonScene', 3000, stateSetup);

    // Summary
    console.log('\n' + '='.repeat(60));
    let clean = 0;
    for (const [k, v] of Object.entries(results)) {
        if (v.errorCount === 0) clean++;
    }
    console.log(`  ${clean}/${Object.keys(results).length} scenes tick without errors`);

    if (clean < Object.keys(results).length) {
        console.log('\n  UNIQUE ERRORS:');
        const globalSeen = new Set();
        for (const [k, v] of Object.entries(results)) {
            for (const e of v.errors) {
                if (!globalSeen.has(e)) {
                    globalSeen.add(e);
                    console.log(`    [${k}] ${e}`);
                }
            }
        }
    }
    console.log('='.repeat(60));

    await browser.close();
    server.kill();
    process.exit(clean === Object.keys(results).length ? 0 : 1);
}

run().catch(e => { console.error('Crashed:', e); if (server) server.kill(); process.exit(1); });
