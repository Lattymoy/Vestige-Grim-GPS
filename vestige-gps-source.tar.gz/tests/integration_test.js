// integration_test.js — Deep scene transition test
import puppeteer from 'puppeteer-core';
import { spawn } from 'child_process';

const PORT = 4174;
let server;

async function startServer() {
    return new Promise((resolve, reject) => {
        server = spawn('npx', ['vite', 'preview', '--port', String(PORT), '--host'], {
            cwd: process.cwd(), stdio: ['pipe', 'pipe', 'pipe']
        });
        let started = false;
        const timeout = setTimeout(() => { if (!started) reject(new Error('timeout')); }, 15000);
        const handler = (data) => {
            if (data.toString().includes('http') && !started) {
                started = true; clearTimeout(timeout);
                setTimeout(() => resolve(), 500);
            }
        };
        server.stdout.on('data', handler);
        server.stderr.on('data', handler);
    });
}

async function run() {
    console.log('Building...');
    const build = spawn('npx', ['vite', 'build'], { cwd: process.cwd(), stdio: 'pipe' });
    await new Promise((res, rej) => build.on('close', c => c === 0 ? res() : rej()));

    console.log('Starting server...');
    await startServer();

    const browser = await puppeteer.launch({
        executablePath: '/usr/bin/google-chrome-stable',
        headless: 'new',
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-web-security']
    });

    const page = await browser.newPage();
    const allErrors = [];

    page.on('console', (msg) => {
        if (msg.type() === 'error') {
            const text = msg.text();
            if (text.includes('navigator.vibrate') || text.includes('favicon') || text.includes('404')) return;
            allErrors.push(text);
        }
    });
    page.on('pageerror', (err) => allErrors.push(`PAGE: ${err.message}`));

    await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'domcontentloaded', timeout: 10000 });
    await new Promise(r => setTimeout(r, 3000));

    const results = {};

    async function testScene(label) {
        const before = allErrors.length;
        await new Promise(r => setTimeout(r, 1500));
        const state = await page.evaluate(() => {
            const g = window.__vestige?.game;
            if (!g) return { active: 'NO_GAME' };
            const active = g.scene.scenes.filter(s => s.sys?.isActive()).map(s => s.sys?.settings?.key);
            return { active: active.join(', ') || 'NONE' };
        });
        const newErrors = allErrors.slice(before);
        results[label] = { active: state.active, errors: newErrors };
        const tag = newErrors.length === 0 ? '✓' : '✗';
        console.log(`  ${tag} ${label.padEnd(25)} [${state.active}] ${newErrors.length} errors`);
        newErrors.slice(0, 3).forEach(e => console.log(`    ${e.substring(0, 140)}`));
    }

    // 1: Boot → TitleScene (already happened)
    await testScene('Boot→Title');

    // 2: Try each scene
    const scenes = [
        'BiomeSelectScene', 'SurvivorSelectScene', 'SafehouseScene',
        'MapScene', 'GameScene', 'InteriorScene', 'HavenScene',
        'PortalDungeonScene', 'StoryScene', 'TraversalScene', 'CubeSimScene'
    ];

    for (const name of scenes) {
        await page.evaluate((n) => {
            const g = window.__vestige?.game;
            if (!g) return;
            g.scene.scenes.forEach(s => { if (s.sys?.isActive()) g.scene.stop(s.sys.settings.key); });
            try { g.scene.start(n); } catch(e) { console.error('LAUNCH: ' + e.message); }
        }, name);
        await testScene(name);
    }

    // Summary
    console.log('\n' + '='.repeat(60));
    let clean = 0, total = Object.keys(results).length;
    for (const [k, v] of Object.entries(results)) {
        if (v.errors.length === 0) clean++;
    }
    console.log(`  ${clean}/${total} scenes launched without errors`);

    if (clean < total) {
        console.log('\n  ERROR SUMMARY:');
        const seen = new Set();
        for (const [k, v] of Object.entries(results)) {
            for (const e of v.errors) {
                // Deduplicate by first 80 chars
                const key = e.substring(0, 80);
                if (!seen.has(key)) {
                    seen.add(key);
                    console.log(`    [${k}] ${e.substring(0, 140)}`);
                }
            }
        }
    }
    console.log('='.repeat(60));

    await browser.close();
    server.kill();
    process.exit(clean === total ? 0 : 1);
}

run().catch(e => { console.error('Crashed:', e); if (server) server.kill(); process.exit(1); });
