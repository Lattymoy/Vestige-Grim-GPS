// browser_test.js — Headless browser integration test
// Starts vite preview, loads page, captures console/errors for 5 seconds

import puppeteer from 'puppeteer-core';
import { spawn } from 'child_process';

const PORT = 4173;
let server;

async function startServer() {
    return new Promise((resolve, reject) => {
        server = spawn('npx', ['vite', 'preview', '--port', String(PORT), '--host'], {
            cwd: process.cwd(),
            stdio: ['pipe', 'pipe', 'pipe']
        });
        let started = false;
        const timeout = setTimeout(() => {
            if (!started) reject(new Error('Server start timeout'));
        }, 15000);

        server.stdout.on('data', (data) => {
            const str = data.toString();
            if (str.includes('http') && !started) {
                started = true;
                clearTimeout(timeout);
                // Give it a moment to fully bind
                setTimeout(() => resolve(), 500);
            }
        });
        server.stderr.on('data', (data) => {
            const str = data.toString();
            if (str.includes('http') && !started) {
                started = true;
                clearTimeout(timeout);
                setTimeout(() => resolve(), 500);
            }
        });
    });
}

async function runTest() {
    console.log('Building...');
    const build = spawn('npx', ['vite', 'build'], { cwd: process.cwd(), stdio: 'pipe' });
    await new Promise((res, rej) => {
        build.on('close', (code) => code === 0 ? res() : rej(new Error('Build failed')));
    });

    console.log('Starting preview server...');
    await startServer();
    console.log(`Server running on port ${PORT}`);

    const browser = await puppeteer.launch({
        executablePath: '/usr/bin/google-chrome-stable',
        headless: 'new',
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-gpu', '--disable-web-security']
    });

    const page = await browser.newPage();

    const logs = [];
    const errors = [];
    const warnings = [];

    page.on('console', (msg) => {
        const type = msg.type();
        const text = msg.text();
        if (type === 'error') {
            // Filter non-critical browser warnings
            if (text.includes('navigator.vibrate') || text.includes('favicon') || text.includes('404')) return;
            errors.push(text);
        }
        else if (type === 'warning') warnings.push(text);
        else logs.push(`[${type}] ${text}`);
    });

    page.on('pageerror', (err) => {
        errors.push(`PAGE ERROR: ${err.message}`);
    });

    page.on('requestfailed', (req) => {
        const url = req.url();
        // Ignore favicon
        if (url.includes('favicon')) return;
        errors.push(`FAILED REQUEST: ${url} — ${req.failure()?.errorText}`);
    });

    console.log(`Loading http://localhost:${PORT}/ ...`);
    try {
        await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'domcontentloaded', timeout: 10000 });
    } catch (e) {
        errors.push(`NAVIGATION ERROR: ${e.message}`);
    }

    // Wait for Phaser to boot and scenes to start
    console.log('Waiting 5 seconds for game init...');
    await new Promise(r => setTimeout(r, 5000));

    // Check for canvas
    const hasCanvas = await page.evaluate(() => {
        const canvas = document.querySelector('canvas');
        return canvas ? { width: canvas.width, height: canvas.height } : null;
    });

    // Check for game object
    const gameState = await page.evaluate(() => {
        const g = window.__vestige;
        if (!g) return { exists: false };
        const scenes = g.game?.scene?.scenes || [];
        const testScene = scenes.find(s => s.sys?.config === 'TestScene' || s.sys?.settings?.key === 'TestScene');
        let sceneData = null;
        if (testScene) {
            sceneData = {
                hasPlayer: !!testScene.player,
                playerActive: testScene.player?.active ?? false,
                playerPos: testScene.player ? { x: Math.round(testScene.player.x), y: Math.round(testScene.player.y) } : null,
                enemyCount: testScene.enemies?.getChildren()?.filter(e => e.active)?.length ?? 0,
                health: testScene.state?.health ?? -1,
                maxHealth: testScene.state?.maxHealth ?? -1,
                dead: testScene.state?.dead ?? null,
                hasBulletGroup: !!testScene.bullets,
            };
        }
        return {
            exists: true,
            gameRunning: g.game?.isRunning ?? false,
            sceneCount: scenes.length,
            activeScenes: scenes.filter(s => s.sys?.isActive()).map(s => s.sys?.settings?.key || s.sys?.config),
            testScene: sceneData
        };
    });

    // Report
    console.log('\n' + '='.repeat(60));
    console.log('  BROWSER TEST RESULTS');
    console.log('='.repeat(60));

    console.log(`\nCanvas: ${hasCanvas ? `${hasCanvas.width}x${hasCanvas.height}` : 'NOT FOUND'}`);
    console.log(`Game object: ${gameState.exists ? 'found' : 'NOT FOUND'}`);
    if (gameState.exists) {
        console.log(`  Running: ${gameState.gameRunning}`);
        console.log(`  Scenes registered: ${gameState.sceneCount}`);
        console.log(`  Active scenes: ${JSON.stringify(gameState.activeScenes)}`);
        if (gameState.testScene) {
            const ts = gameState.testScene;
            console.log(`  TestScene:`);
            console.log(`    Player: ${ts.hasPlayer ? 'exists' : 'MISSING'}, active: ${ts.playerActive}, pos: ${JSON.stringify(ts.playerPos)}`);
            console.log(`    HP: ${ts.health}/${ts.maxHealth}, dead: ${ts.dead}`);
            console.log(`    Enemies alive: ${ts.enemyCount}`);
            console.log(`    Bullet group: ${ts.hasBulletGroup ? 'exists' : 'MISSING'}`);
        }
    }

    if (errors.length) {
        console.log(`\nERRORS (${errors.length}):`);
        errors.forEach((e, i) => console.log(`  ${i + 1}. ${e}`));
    } else {
        console.log('\nERRORS: none');
    }

    if (warnings.length) {
        console.log(`\nWARNINGS (${warnings.length}):`);
        warnings.slice(0, 10).forEach((w, i) => console.log(`  ${i + 1}. ${w}`));
    }

    if (logs.length) {
        console.log(`\nLOGS (${logs.length}):`);
        logs.forEach((l, i) => console.log(`  ${l}`));
    }

    const ts = gameState.testScene;
    const titleActive = gameState.activeScenes?.includes('TitleScene');
    const testActive = ts?.hasPlayer && ts?.enemyCount > 0;
    const passed = hasCanvas && !errors.length && gameState.exists && (titleActive || testActive);
    console.log(`\n${'='.repeat(60)}`);
    console.log(`  RESULT: ${passed ? 'PASS' : 'FAIL'}`);
    console.log(`${'='.repeat(60)}`);

    await browser.close();
    server.kill();
    process.exit(passed ? 0 : 1);
}

runTest().catch(e => {
    console.error('Test crashed:', e);
    if (server) server.kill();
    process.exit(1);
});
