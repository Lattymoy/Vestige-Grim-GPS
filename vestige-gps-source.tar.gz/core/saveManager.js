// Vestige GPS — SaveManager
// Persistence layer — currently localStorage, will become server API client
// NOTE: Circular deps with ItemManager and StatTracker
// ES modules handle this fine at runtime (calls are lazy)

import { CONFIG } from '../data/config.js';
import { ItemManager } from './itemManager.js';
import { SurvivorGenerator } from './survivorGenerator.js';
import { StatTracker } from './statTracker.js';

export const SaveManager = {
    _cache: null,
    SAVE_KEY: 'vestige_safehouse',
    BACKUP_KEY: 'vestige_backup',
    CUSTOM_KEY: 'vestige_custom',
    SAVE_VERSION: 1,
    
    getDefaultSaveData() {
        return {
            level: 1,
            stash: {
                bits: 50,
                powerAmmo: 20,
                fuel: 100,
                materials: 0,
                health: 100,
                inventory: ItemManager.createInventory(CONFIG.inventory.safehouseStashSlots)
            },
            equipment: {
                weapon: null,
                melee: null,
                gear: null,
                consumable: null
            },
            upgrades: {
                workbench: 0,
                stash: 0,
                garage: 0,
                computer: 0,
                gym: 0,
                barracks: 1
            },
            barracksUpgrade: null, // { startedAt, finishesAt, toLevel }
            vehicle: {
                type: 'basic',
                health: 100,
                upgrades: [],
                mods: {
                    weapon: -1,
                    armor: -1,
                    fuel: -1,
                    utility: -1
                }
            },
            cosmetics: {
                unlockedOutfits: ['default'],
                currentOutfit: 'default'
            },
            gymBuff: null,  // { category, buffs:{stat:val,...}, expiresAt, startedAt, duration }
            gymSession: { lastFreeUse: 0, sessionCount: 0, lastSessionDay: 0 },
            survivors: [],
            furniture: [],
            firstVisit: true,
            
            // === TERMINAL DATA ===
            profile: {
                name: 'Survivor',
                title: '',
                aura: 'none',
                unlockedTitles: [],
                unlockedAuras: ['none']
            },
            stats: {
                runsCompleted: 0,
                runsFailed: 0,
                totalRunTime: 0,
                enemiesKilled: 0,
                bossesKilled: 0,
                damageDealt: 0,
                damageTaken: 0,
                itemsLooted: 0,
                cubesCollected: 0,
                bitsEarned: 0,
                bitsSpent: 0,
                distanceTraveled: 0,
                buildingsExplored: 0,
                containersOpened: 0,
                meleeKills: 0,
                rangedKills: 0,
                deathCount: 0,
                flairWeaponsFound: 0,
                baneWeaponsFound: 0,
                longestSurvival: 0,
                highestReach: 0,
                timePlayed: 0,
                sessionsPlayed: 0,
                createdAt: Date.now()
            },
            loreChips: [],
            foundNotes: [],
            lastSleepTime: 0,
            wellRested: null, // { active: true, runsRemaining: 3 } — 15% currency bonus
            quests: {
                active: [],
                completed: []
            },
            achievements: [],
            tutorials: { seen: [], disabled: false },
            biome: 'grassy',
            routeSeed: null,      // Locked on first terminal MAP access per run
            activeRoute: null,    // { seed, reach, biome, nodes, edges, totalFuel, currentStep, status }
            currentReach: 1,      // Which reach the player is planning/on
            factionRep: {},       // { terracorp: 0, ucr: 0, ... }
            _saveVersion: 6
        };
    },
    
    load() {
        try {
            const saved = localStorage.getItem(this.SAVE_KEY);
            if (saved) {
                const data = JSON.parse(saved);
                this.migrate(data);
                this._cache = data;
                return data;
            }
        } catch(e) {
            console.warn('SaveManager.load failed, trying backup:', e);
            // Primary corrupted — try backup
            try {
                const backup = localStorage.getItem(this.BACKUP_KEY);
                if (backup) {
                    const data = JSON.parse(backup);
                    this.migrate(data);
                    this._cache = data;
                    localStorage.setItem(this.SAVE_KEY, backup);
                    console.log('SaveManager: Restored from backup');
                    return data;
                }
            } catch(e2) { console.warn('SaveManager.backup also failed:', e2); }
        }
        
        const fresh = this.getDefaultSaveData();
        this.migrate(fresh);
        this._cache = fresh;
        this.save(fresh);
        return fresh;
    },
    
    save(data) {
        try {
            this._cache = data || this._cache;
            if (this._cache) {
                const json = JSON.stringify(this._cache);
                localStorage.setItem(this.SAVE_KEY, json);
                // Backup every save — last-known-good copy
                localStorage.setItem(this.BACKUP_KEY, json);
            }
        } catch(e) { console.warn('SaveManager.save failed:', e); }
    },
    
    migrate(data) {
        // Backward compatibility migrations
        if (!data.stash) data.stash = { bits: 50, powerAmmo: 20, fuel: 100, materials: 0, health: 100 };
        if (!data.stash.inventory) data.stash.inventory = ItemManager.createInventory(CONFIG.inventory.safehouseStashSlots);
        if (data.stash.scrap !== undefined && data.stash.bits === undefined) {
            data.stash.bits = data.stash.scrap; delete data.stash.scrap;
        }
        if (data.stash.gas !== undefined && data.stash.fuel === undefined) {
            data.stash.fuel = data.stash.gas; delete data.stash.gas;
        }
        if (data.stash.materials === undefined) data.stash.materials = 0;
        if (data.stash.bits === undefined) data.stash.bits = 0;
        if (!data.equipment) data.equipment = { weapon: null, melee: null, gear: null, consumable: null };
        if (!data.equipment.consumable) data.equipment.consumable = null;
        // Migrate relic slot → augment system: relic items move to stash, slot removed
        if (data.equipment.relic !== undefined) {
            if (data.equipment.relic && data.stash && data.stash.inventory) {
                // Convert old relic to augment category and put in stash
                const oldRelic = data.equipment.relic;
                oldRelic.category = 'augment';
                const emptyIdx = data.stash.inventory.indexOf(null);
                if (emptyIdx >= 0) data.stash.inventory[emptyIdx] = oldRelic;
            }
            delete data.equipment.relic;
        }
        if (!data.upgrades) data.upgrades = { workbench: 0, stash: 0, garage: 0, computer: 0, gym: 0, barracks: 1 };
        if (data.upgrades.barracks === undefined) data.upgrades.barracks = 1;
        if (data.barracksUpgrade === undefined) data.barracksUpgrade = null;
        if (!data.vehicle) data.vehicle = { type: 'basic', health: 100, upgrades: [] };
        if (!data.vehicle.mods) data.vehicle.mods = { weapon: -1, armor: -1, fuel: -1, utility: -1 };
        if (!data.cosmetics) data.cosmetics = { unlockedOutfits: ['default'], currentOutfit: 'default' };
        if (!data.gymBuff) data.gymBuff = null;
        if (!data.gymSession) data.gymSession = { lastFreeUse: 0, sessionCount: 0, lastSessionDay: 0 };
        delete data.attributes; // Remove old training system
        if (!data.survivors) data.survivors = [];
        if (!data.furniture) data.furniture = [];
        
        // Haven-specific data
        if (!data.haven) data.haven = {};
        if (!data.haven.faction) data.haven.faction = { pledged: null, reputation: {}, lastChange: 0 };
        if (!data.haven.challenges) data.haven.challenges = { daily: [], weekly: [], monthly: [], lastDailyReset: 0, lastWeeklyReset: 0, lastMonthlyReset: 0 };
        if (!data.haven.portal) data.haven.portal = { highestFloor: 0, leaderboard: [] };
        if (!data.haven.shopTimestamps) data.haven.shopTimestamps = { lastReveal: 0, lastRebuild: 0 };
        
        // Terminal data migrations
        if (!data.profile) data.profile = { name: 'Survivor', title: '', aura: 'none', unlockedTitles: [], unlockedAuras: ['none'] };
        if (!data.stats) data.stats = { runsCompleted: 0, runsFailed: 0, totalRunTime: 0, enemiesKilled: 0, bossesKilled: 0, damageDealt: 0, damageTaken: 0, itemsLooted: 0, cubesCollected: 0, bitsEarned: 0, bitsSpent: 0, distanceTraveled: 0, buildingsExplored: 0, containersOpened: 0, meleeKills: 0, rangedKills: 0, deathCount: 0, flairWeaponsFound: 0, baneWeaponsFound: 0, longestSurvival: 0, highestReach: 0, timePlayed: 0, sessionsPlayed: 0, createdAt: Date.now() };
        if (!data.loreChips) data.loreChips = [];
        if (!data.foundNotes) data.foundNotes = [];
        if (!data.quests) data.quests = { active: [], completed: [] };
        if (!data.achievements) data.achievements = [];
        if (!data.tutorials) data.tutorials = { seen: [], disabled: false };
        
        // Save version tracking
        if (!data._saveVersion) data._saveVersion = 1;
        
        // === v2 MIGRATION: Flat stat system (old → new stat keys) ===
        if (data._saveVersion < 2) {
            const migrateItemStats = (item) => {
                if (!item || !item.stats) return;
                const s = item.stats;
                const cat = item.category || '';
                // Weapon stat renames — old range was pixels (100-260), old fireRate was shots/sec (0.8-5)
                if (cat === 'weapon' || (s.magazineSize !== undefined || s.ammoPerShot !== undefined)) {
                    if (s.range !== undefined && s.accuracy === undefined) { s.accuracy = Math.round(Math.min(100, (s.range || 150) * 0.35)); delete s.range; }
                    if (s.magazineSize !== undefined && s.mag === undefined) { s.mag = Math.min(100, Math.round((s.magazineSize || 12) * 3)); delete s.magazineSize; }
                    if (s.reloadTime !== undefined && s.reload === undefined) { s.reload = Math.round(Math.max(10, 100 - (s.reloadTime || 2) * 25)); delete s.reloadTime; }
                    if (s.fireRate !== undefined && s.fireRate < 10) { s.fireRate = Math.round(Math.min(100, (s.fireRate || 2) * 15)); }
                    if (s.ammoPerShot !== undefined) delete s.ammoPerShot;
                    if (s.pierce === undefined) s.pierce = 1;
                    if (s.targetRange === undefined) s.targetRange = Math.round(Math.min(5, Math.max(1, (s.accuracy || 50) / 20)));
                    if (s.crit === undefined) s.crit = 15;
                }
                // Melee stat renames — old swingSpeed was swings/sec (0.8-3), old range was pixels (30-40)
                if (cat === 'melee' || s.swingSpeed !== undefined) {
                    if (s.swingSpeed !== undefined && s.attackSpeed === undefined) { s.attackSpeed = Math.round(Math.min(100, (s.swingSpeed || 2) * 22)); delete s.swingSpeed; }
                    if (s.range !== undefined && s.reach === undefined) { s.reach = Math.min(100, s.range || 30); delete s.range; }
                    if (s.shieldAttack === undefined) s.shieldAttack = 1;
                }
            };
            const migrateMods = (item) => {
                if (!item || !item.mods) return;
                const nameMap = {
                    reloadSpeed: { stat: 'reload', name: 'Reload', id: 'reload_spd' },
                    deathSaves: { stat: 'soulbound', name: 'Soulbound', id: 'soulbound' },
                    critChance: { stat: 'crit', name: 'Crit', id: 'crit' },
                    critDamage: { stat: 'crit', name: 'Crit', id: 'crit' },
                    magSize: { stat: 'mag', name: 'Mag', id: 'mag_size' },
                    range: { stat: 'accuracy', name: 'Accuracy', id: 'accuracy' }
                };
                item.mods.forEach(mod => {
                    if (!mod) return;
                    const fix = nameMap[mod.stat];
                    if (fix) { mod.stat = fix.stat; mod.name = fix.name; mod.id = fix.id; }
                    if (mod.unit === '%') mod.unit = '';
                });
            };
            // Migrate equipped items
            if (data.equipment) {
                ['weapon', 'melee', 'gear'].forEach(slot => {
                    if (data.equipment[slot]) { migrateItemStats(data.equipment[slot]); migrateMods(data.equipment[slot]); }
                });
            }
            // Migrate stash inventory
            if (data.stash && data.stash.inventory) {
                data.stash.inventory.forEach(item => { if (item) { migrateItemStats(item); migrateMods(item); } });
            }
            data._saveVersion = 2;
            console.log('[Vestige] Save migrated to v2 — flat stat system');
        }
        
        // === v3/v4 FIX: Repair broken v2 migration (accuracy overflow, old mod names, value clamps) ===
        if (data._saveVersion < 4) {
            const repairItem = (item) => {
                if (!item || !item.stats) return;
                const s = item.stats;
                // Fix accuracy overflow from bad v2 (range*10 instead of range*0.35)
                if (s.accuracy > 100) s.accuracy = Math.round(Math.min(100, s.accuracy * 0.007));
                // Fix fireRate that stayed decimal or got over-scaled
                if (s.fireRate !== undefined && s.fireRate > 100) s.fireRate = Math.min(100, Math.round(s.fireRate * 0.015));
                if (s.fireRate !== undefined && s.fireRate < 10) s.fireRate = Math.round(Math.min(100, (s.fireRate || 2) * 15));
                // Fix mag overflow
                if (s.mag !== undefined && s.mag > 100) s.mag = Math.min(100, Math.round(s.mag * 0.8));
                // Ensure new fields exist
                if (item.category === 'weapon') {
                    if (s.pierce === undefined) s.pierce = 1;
                    if (s.targetRange === undefined) s.targetRange = Math.round(Math.min(5, Math.max(1, (s.accuracy || 50) / 20)));
                    if (s.crit === undefined) s.crit = 15;
                }
                if (item.category === 'melee') {
                    if (s.shieldAttack === undefined) s.shieldAttack = 1;
                }
            };
            const repairMods = (item) => {
                if (!item || !item.mods) return;
                const nameMap = {
                    reloadSpeed: { stat: 'reload', name: 'Reload', id: 'reload_spd' },
                    deathSaves: { stat: 'soulbound', name: 'Soulbound', id: 'soulbound' },
                    critChance: { stat: 'crit', name: 'Crit', id: 'crit' },
                    critDamage: { stat: 'crit', name: 'Crit', id: 'crit' },
                    magSize: { stat: 'mag', name: 'Mag', id: 'mag_size' },
                    range: { stat: 'accuracy', name: 'Accuracy', id: 'accuracy' }
                };
                // Also fix mod names that v2 migration missed
                const idToName = {
                    reload_spd: 'Reload', fire_rate: 'Fire Rate', dmg_boost: 'Damage',
                    crit: 'Crit', crit_chance: 'Crit', mag_size: 'Mag', pierce: 'Pierce',
                    target_range: 'Target Range', accuracy: 'Accuracy',
                    atk_spd: 'Attack Speed', melee_dmg: 'Damage',
                    stagger: 'Stagger', lifesteal: 'Lifesteal', reach: 'Reach',
                    mass_atk: 'Mass Attack', shield_atk: 'Shield Attack', soulbound: 'Soulbound'
                };
                const modMaxValues = {
                    damage: 13, fireRate: 13, reload: 13, accuracy: 13, crit: 20,
                    mag: 13, pierce: 3, targetRange: 3, attackSpeed: 13, meleeDamage: 13,
                    stagger: 13, reach: 13, lifesteal: 5, massAttack: 3, shieldAttack: 3, soulbound: 3
                };
                item.mods.forEach(mod => {
                    if (!mod) return;
                    const fix = nameMap[mod.stat];
                    if (fix) { mod.stat = fix.stat; mod.name = fix.name; mod.id = fix.id; }
                    // Fix old id: crit_chance → crit
                    if (mod.id === 'crit_chance') { mod.id = 'crit'; mod.stat = 'crit'; mod.name = 'Crit'; }
                    // Fix display name from id
                    if (mod.id && idToName[mod.id] && mod.name !== idToName[mod.id]) {
                        mod.name = idToName[mod.id];
                    }
                    // Clamp mod values to sane maximums
                    if (mod.stat && modMaxValues[mod.stat] !== undefined) {
                        mod.value = Math.min(mod.value, modMaxValues[mod.stat]);
                    }
                    if (mod.unit === '%') mod.unit = '';
                });
            };
            if (data.equipment) {
                ['weapon', 'melee', 'gear'].forEach(slot => {
                    if (data.equipment[slot]) { repairItem(data.equipment[slot]); repairMods(data.equipment[slot]); }
                });
            }
            if (data.stash && data.stash.inventory) {
                data.stash.inventory.forEach(item => { if (item) { repairItem(item); repairMods(item); } });
            }
            data._saveVersion = 4;
            console.log('[Vestige] Save migrated to v4 — repaired stat overflow + mod names + value clamps');
        }
        
        // === v5: Restore correct mod units (%, displayDiv) stripped by v2 migration ===
        if (data._saveVersion < 5) {
            const modUnitMap = {
                crit: { unit: '%', displayDiv: 2 },
                stagger: { unit: '%' },
                lifesteal: { unit: '%' },
                damageResist: { unit: '%' },
                healBonus: { unit: '%' },
                burnResist: { unit: '%' },
                poisonResist: { unit: '%' },
                bleedResist: { unit: '%' },
                sightline: { unit: 's', displayDiv: 10 }
            };
            const fixModUnits = (item) => {
                if (!item || !item.mods) return;
                item.mods.forEach(mod => {
                    if (!mod) return;
                    const fix = modUnitMap[mod.stat];
                    if (fix) {
                        mod.unit = fix.unit;
                        if (fix.displayDiv) mod.displayDiv = fix.displayDiv;
                    }
                });
            };
            if (data.equipment) {
                ['weapon', 'melee', 'gear'].forEach(slot => {
                    if (data.equipment[slot]) fixModUnits(data.equipment[slot]);
                });
            }
            if (data.stash && data.stash.inventory) {
                data.stash.inventory.forEach(item => { if (item) fixModUnits(item); });
            }
            data._saveVersion = 5;
            console.log('[Vestige] Save migrated to v5 — restored mod display units');
        }
        
        // === v6: Convert old cube items to tiered cube system ===
        if (data._saveVersion < 6) {
            const convertCubes = (item) => {
                if (!item) return item;
                if (item.id === 'the_cube' || item.baseId === 'the_cube') {
                    return ItemManager.createItem('cube_rare');
                }
                if (item.id === 'cube_fragment' || item.baseId === 'cube_fragment') {
                    return ItemManager.createItem('cube_uncommon');
                }
                return item;
            };
            if (data.stash && data.stash.inventory) {
                data.stash.inventory = data.stash.inventory.map(convertCubes);
            }
            data._saveVersion = 6;
            console.log('[Vestige] Save migrated to v6 — converted cubes to tiered system');
        }
        
        // === v7: Survivor achievements + deprecate quips ===
        if (!data._saveVersion || data._saveVersion < 7) {
            (data.survivors || []).forEach(s => {
                if (!s.achievements) {
                    s.achievements = SurvivorGenerator.assignAchievements(s.seed || Date.now());
                }
                delete s.quips;
                // Backfill missing stat fields
                if (s.meleeKills === undefined) s.meleeKills = 0;
                if (s.bestRunKills === undefined) s.bestRunKills = 0;
                if (s.bitsEarned === undefined) s.bitsEarned = 0;
                if (s.materialsEarned === undefined) s.materialsEarned = 0;
                if (s.cubesFound === undefined) s.cubesFound = 0;
                if (s.rareFinds === undefined) s.rareFinds = 0;
                if (s.fullLoadouts === undefined) s.fullLoadouts = 0;
                if (s.timesHealed === undefined) s.timesHealed = 0;
                if (s.injuriesRecovered === undefined) s.injuriesRecovered = 0;
                if (s.zeroDamageRuns === undefined) s.zeroDamageRuns = 0;
                if (s.closeCallRuns === undefined) s.closeCallRuns = 0;
                if (s.consecutiveRuns === undefined) s.consecutiveRuns = 0;
                if (s.buildingsExplored === undefined) s.buildingsExplored = 0;
                if (s.gymSessions === undefined) s.gymSessions = 0;
                if (s.reforges === undefined) s.reforges = 0;
            });
            data._saveVersion = 7;
            console.log('[Vestige] Save migrated to v7 — survivor achievements');
        }
        
        // Ensure minimum resources
        if (data.stash.fuel < 50) data.stash.fuel = 50;
        if (data.stash.powerAmmo < 20) data.stash.powerAmmo = 20;
        
        // Starter equipment for new saves — T1 weapon + melee + gear
        if (data.firstVisit && !data.equipment.weapon && !data.equipment.melee) {
            const ts = Date.now();
            data.equipment.weapon = {
                id: `starter_mini_1_${ts}_0`,
                baseId: 'mini',
                category: 'weapon',
                name: 'Scrap Buzzer',
                icon: '\uD83D\uDD2B',
                description: '[Full-Auto] Erratic recoil',
                rarity: 'common',
                tier: 1,
                tierName: 'Standard',
                tierLabel: 'Common',
                tierColor: 0x888888,
                stats: { damage: 8, fireRate: 50, accuracy: 30, crit: 5, mag: 20, reload: 45, pierce: 1, targetRange: 1 },
                mods: [],
                procedural: true,
                frame: 'stock',
                frameName: 'Stock',
                partConfig: { barrel: 'pipe', stock: 'wood', magazine: 'taped', muzzle: 'raw' },
                fireMode: 'auto',
                recoilType: 'erratic',
                weaponSprite: 'mini'
            };
            data.equipment.melee = {
                id: `starter_blade_1_${ts}_1`,
                baseId: 'blade',
                category: 'melee',
                name: 'Scrap Blade',
                icon: '\uD83D\uDD2A',
                description: '',
                rarity: 'common',
                tier: 1,
                tierName: 'Standard',
                tierLabel: 'Common',
                tierColor: 0x888888,
                stats: { damage: 10, attackSpeed: 40, reach: 25, stagger: 10, shieldAttack: 1 },
                mods: [],
                procedural: true,
                frame: 'stock',
                frameName: 'Stock',
                partConfig: { handle: 'wood', head: 'rusty', guard: 'none' }
            };
            data.equipment.gear = {
                id: `starter_scrap_1_${ts}_3`,
                baseId: 'scrap_armor',
                category: 'gear',
                name: 'Scrap Armor',
                icon: '👕',
                description: 'Salvaged scraps stitched together.',
                rarity: 'common',
                tier: 1,
                tierName: 'Standard',
                tierLabel: 'Common',
                tierColor: 0x888888,
                stats: { health: 80, armor: 1, speed: 105, luck: 0, backpack: 6 },
                mods: [],
                procedural: true,
                gearClass: 'scrap',
                frameName: 'Scrap Armor',
                outfit: { shirt: { base: '#5a4a3a', light: '#6a5a4a', dark: '#4a3a2a' }, pants: { base: '#3a3a30', light: '#4a4a40' } }
            };
            // ── STARTER: One of each encrypted cube in stash ──
            const starterCubes = ['cube_uncommon', 'cube_rare', 'cube_master', 'cube_legendary'];
            starterCubes.forEach(cubeId => {
                const slot = data.stash.inventory.findIndex(s => s === null);
                if (slot !== -1) {
                    data.stash.inventory[slot] = ItemManager.createItem(cubeId);
                }
            });
        }
        
        // Migrate old weapons: backfill partConfig from foundry+frame
        const _migrateItem = (item) => {
            if (!item) return;
            // Strip flair name prefix from weapon names (legacy saves had "Arc-Touched Terracorp AR-7")
            if ((item.category === 'weapon' || item.category === 'melee') && item.flair && item.name) {
                const flairPrefix = item.flair.name + ' ';
                if (item.name.startsWith(flairPrefix)) {
                    item.name = item.name.slice(flairPrefix.length);
                }
            }
            // Add flavorText to legacy weapons/melee that don't have it
            if ((item.category === 'weapon' || item.category === 'melee') && !item.flavorText && CONFIG.weaponFlavor) {
                const _pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
                const fp = CONFIG.weaponFlavor;
                if (item.flair && fp.flair[item.flair.id]) {
                    item.flavorText = Math.random() < 0.55 ? _pick(fp.flair[item.flair.id]) : _pick(fp.generic);
                } else if (item.foundry && fp.foundry[item.foundry]) {
                    item.flavorText = Math.random() < 0.5 ? _pick(fp.foundry[item.foundry]) : _pick(fp.generic);
                } else if (item.category === 'melee') {
                    item.flavorText = Math.random() < 0.45 ? _pick(fp.melee) : _pick(fp.universal || fp.generic);
                } else {
                    item.flavorText = _pick(fp.generic);
                }
            }
            // Init kill counter on legacy items
            if ((item.category === 'weapon' || item.category === 'melee') && item.kills === undefined) {
                item.kills = 0;
            }
            if (item.partConfig) return;
            if (item.category === 'weapon') {
                // Map old generic weapon frames to closest foundry frame
                const oldToNew = { 'Stock':'stock', 'Stripped':'stripped', 'Sighted':'marksman', 'Braced':'reinforced', 'Cooked':'overclocked' };
                const foundryId = item.foundry || null;
                const framePool = foundryId && CONFIG.foundryFrames[foundryId]
                    ? CONFIG.foundryFrames[foundryId] : CONFIG.scrapFrames;
                let frameKey = oldToNew[item.frameName] || 'stock';
                if (!framePool[frameKey]) frameKey = 'stock';
                const frameDef = framePool[frameKey];
                item.frame = frameKey;
                item.frameName = frameDef.name;
                item.partConfig = { ...frameDef.parts };
            } else if (item.category === 'melee') {
                // Map old generic melee frames to closest foundry melee frame
                const oldToNew = { 'Stock':'stock', 'Honed':'duelist', 'Weighted':'sledge' };
                const foundryId = item.foundry || null;
                const framePool = foundryId && CONFIG.foundryMeleeFrames[foundryId]
                    ? CONFIG.foundryMeleeFrames[foundryId] : CONFIG.scrapMeleeFrames;
                let frameKey = oldToNew[item.frameName] || 'stock';
                if (!framePool[frameKey]) frameKey = 'stock';
                const frameDef = framePool[frameKey];
                item.frame = frameKey;
                item.frameName = frameDef.name;
                item.partConfig = { ...frameDef.parts };
            }
        };
        // Migrate equipped items
        if (data.equipment) {
            _migrateItem(data.equipment.weapon);
            _migrateItem(data.equipment.melee);
        }
        // Migrate stash inventory
        if (data.stash && data.stash.inventory && data.stash.inventory.items) {
            data.stash.inventory.items.forEach(it => _migrateItem(it));
        }
    },
    
    reset() {
        try { localStorage.removeItem(this.SAVE_KEY); } catch(e) {}
        this._cache = null;
    },
    
    depositLoot(lootData, backpack, equipment, vehicle) {
        const data = this._cache || this.load();
        if (lootData) {
            data.stash.bits += lootData.bits || 0;
            data.stash.powerAmmo += lootData.powerAmmo || 0;
            data.stash.fuel = Math.min(100, data.stash.fuel + (lootData.fuel || 0));
            data.stash.materials = (data.stash.materials || 0) + (lootData.materials || 0);
        }
        if (backpack) {
            for (const item of backpack) {
                if (item) ItemManager.addItem(data.stash.inventory, item);
            }
        }
        if (equipment) data.equipment = equipment;
        if (vehicle) data._runVehicle = vehicle;
        this.save(data);
        return data;
    },
    
    handleDeath(equipment, vehicle) {
        const data = this._cache || this.load();
        if (equipment) data.equipment = equipment;
        if (vehicle) data._runVehicle = vehicle;
        this.save(data);
        return data;
    },
    
    getCustomization() {
        try { return JSON.parse(localStorage.getItem(this.CUSTOM_KEY) || '{}'); } catch(e) { return {}; }
    },
    
    saveCustomization(custom) {
        try { localStorage.setItem(this.CUSTOM_KEY, JSON.stringify(custom)); } catch(e) {}
    }
};

// ============================================
// EVENT BUS — Decoupled pub/sub for cross-system communication
// ============================================
