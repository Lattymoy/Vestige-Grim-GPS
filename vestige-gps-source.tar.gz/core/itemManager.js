// Vestige GPS — ItemManager
// Procedural weapon/gear generation, inventory, loot, equipment stats
// 2,997 lines — the crown jewel of extractable logic
//
// drawItemPixelArt uses injectable _shapeRenderer (Phaser shapes via bridge)
// renderWeaponCanvas uses raw Canvas2D (works in any browser context)
// Audio events emitted via EventBus (client subscribes)

import { CONFIG } from '../data/config.js';
import { EventBus } from './eventBus.js';
import { Haptics } from './haptics.js';
import { PlayerProgression } from './playerProgression.js';
import { SaveManager } from './saveManager.js';
import { StatTracker } from './statTracker.js';
import { Blurbs } from './blurbs.js';

export const ItemManager = {
    _shapeRenderer: null,

    /**
     * Set shape renderer for drawItemPixelArt.
     * Renderer: { rect(scene, container, x, y, w, h, color, alpha, depth), circle(scene, container, x, y, r, color, alpha, depth) }
     */
    setShapeRenderer(renderer) { ItemManager._shapeRenderer = renderer; },
    // Get static item definition from CONFIG
    getItem(itemId) {
        return CONFIG.items[itemId] || null;
    },
    
    // Weighted random pick from an array of { ..., dropWeight } or { ..., weight }
    _weightedPick(entries, weightKey = 'dropWeight') {
        const total = entries.reduce((s, e) => s + (e[weightKey] || 0), 0);
        let roll = Math.random() * total;
        for (const entry of entries) {
            roll -= (entry[weightKey] || 0);
            if (roll <= 0) return entry;
        }
        return entries[entries.length - 1];
    },
    
    // Roll a tier (1-5) with weighted probability, scaled by reach
    rollTier(luckBonus = 0, reach = 1) {
        const reachBonus = CONFIG.reachTierBonus[Math.min(reach, 8)] || CONFIG.reachTierBonus[1];
        // Loot quality bonus from Ballast mark (stored on active run state)
        const _lqb = (CONFIG._activeLootQualityBonus || 0) + (CONFIG._activeBiomeLootQualityBonus || 0);
        // Elite loot perk: +5 weight to T3+, +3 to T4+, +2 to T5
        let eliteBonus = {};
        try { if (PlayerProgression.hasPerk(SaveManager.load(), 'elite_loot')) eliteBonus = { 3: 5, 4: 3, 5: 2 }; } catch(e) {}
        const tiers = Object.entries(CONFIG.tiers).map(([k, v]) => {
            const t = parseInt(k);
            if (t >= 6) return null;
            const rBonus = reachBonus[t] || 0;
            const lBonus = t > 1 ? luckBonus : 0;
            const eBonus = eliteBonus[t] || 0;
            // lootQualityBonus pushes weight toward T3+ (subtle)
            const qBonus = t >= 3 ? Math.round(_lqb * 10) : 0;
            return {
                tier: t, ...v, 
                dropWeight: Math.max(0.01, v.dropWeight + rBonus + lBonus + eBonus + qBonus)
            };
        }).filter(Boolean);
        return this._weightedPick(tiers).tier;
    },
    
    // Roll a mod tier (1-5)
    rollModTier(itemTier = 1) {
        // Higher item tier biases toward better mod tiers
        const bonus = (itemTier - 1) * 3;
        const tiers = Object.entries(CONFIG.modTiers).map(([k, v]) => ({
            tier: parseInt(k), ...v,
            dropWeight: v.dropWeight + (parseInt(k) > 1 ? bonus : 0)
        }));
        return this._weightedPick(tiers).tier;
    },
    
    // Generate a single mod for a given category
    generateMod(category, itemTier) {
        const pool = CONFIG.modPools[category];
        if (!pool || pool.length === 0) return null;
        
        // Pick random mod from pool (no soulbound bias)
        const regularMods = pool.filter(m => !m.special);
        const modDef = regularMods[Math.floor(Math.random() * regularMods.length)];
        
        // 8% chance for Soulbound on any mod slot
        const soulboundMod = pool.find(m => m.id === 'soulbound');
        const useSoulbound = soulboundMod && Math.random() < 0.08;
        const chosen = useSoulbound ? soulboundMod : modDef;
        
        const modTier = this.rollModTier(itemTier);
        const modTierDef = CONFIG.modTiers[modTier];
        const value = Math.round(chosen.base * modTierDef.valueMult);
        
        return {
            id: chosen.id,
            name: chosen.name,
            stat: chosen.stat,
            value: value,
            unit: chosen.unit,
            displayDiv: chosen.displayDiv || 0,
            tier: modTier,
            tierName: modTierDef.name,
            color: modTierDef.color,
            special: chosen.special || false
        };
    },
    
    // Generate a Blood Forged signature mod (T5 unique)
    generateSignatureMod(category) {
        const sigs = CONFIG.bloodForgedSignatures[category];
        if (!sigs || sigs.length === 0) return null;
        
        const sig = sigs[Math.floor(Math.random() * sigs.length)];
        return {
            id: sig.id,
            name: sig.name,
            desc: sig.desc,
            effect: sig.effect,
            value: sig.value,
            cooldown: sig.cooldown || 0,
            duration: sig.duration || 0,
            dot: sig.dot || null,
            dotDuration: sig.dotDuration || 0,
            modType: sig.type || 'passive', // 'passive' or 'active'
            tier: 5,
            tierName: 'Blood',
            color: 0xff2244,
            signature: true
        };
    },
    

    // Generate a Bane weapon from a specific boss kill
    generateBaneWeapon(bossType) {
        const def = CONFIG.baneWeapons[bossType];
        if (!def) return null;
        
        const tierDef = CONFIG.tiers[6];
        // Bane stats are FINAL in CONFIG — no tier scaling, no frame mults
        // What you see in baneWeapons config is what the player gets
        const stats = {};
        for (const [k, v] of Object.entries(def.stats)) {
            stats[k] = v;
        }
        
        // Bane foundry+frame — each boss maps to a thematic foundry and rarest frame
        const baneFoundryMap = {
            warden:     { foundry: 'deralict',  wFrame: 'boreOut',     mFrame: 'sledge' },
            swarmQueen: { foundry: 'sworn',     wFrame: 'juryRig',     mFrame: 'ripper' },
            phantom:    { foundry: 'blackreach', wFrame: 'overcharged', mFrame: 'focused' },
            ironclad:   { foundry: 'terracorp', wFrame: 'heavy',       mFrame: 'breacher' },
            cubeAnomaly:{ foundry: 'cephalon',  wFrame: 'unstable',    mFrame: 'void' }
        };
        const bfm = baneFoundryMap[bossType] || baneFoundryMap.cubeAnomaly;
        const foundryId = bfm.foundry;
        const isWeapon = def.category === 'weapon';
        const frameKey = isWeapon ? bfm.wFrame : bfm.mFrame;
        const framePool = isWeapon
            ? (CONFIG.foundryFrames[foundryId] || CONFIG.scrapFrames)
            : (CONFIG.foundryMeleeFrames[foundryId] || CONFIG.scrapMeleeFrames);
        const frameDef = framePool[frameKey] || framePool.stock;
        const partConfig = { ...frameDef.parts };
        
        // Frame stat mults SKIPPED for bane — stats are final in CONFIG
        // Frame data retained for visuals only (foundry palette, part config)
        
        // Generate 4 high-tier mods
        const mods = [];
        const usedModIds = new Set();
        for (let i = 0; i < tierDef.modSlots; i++) {
            let mod = this.generateMod(def.category, 6);
            let attempts = 0;
            while (mod && usedModIds.has(mod.id) && !mod.special && attempts < 10) {
                mod = this.generateMod(def.category, 6);
                attempts++;
            }
            if (mod) { usedModIds.add(mod.id); mods.push(mod); }
        }
        
        const signatureMod = {
            id: def.signature.id,
            name: def.signature.name,
            desc: def.signature.desc,
            effect: def.signature.effect,
            value: def.signature.value,
            cooldown: def.signature.cooldown || 0,
            duration: def.signature.duration || 0,
            dot: def.signature.dot || null,
            modType: 'passive',
            tier: 6,
            tierName: 'Bane',
            color: 0x8800ff,
            signature: true
        };
        
        let description = mods.map(m => { const dv = m.displayDiv ? (m.value / m.displayDiv).toFixed(1) : m.value; return `+${dv}${m.unit} ${m.name}`; }).join(', ');
        description += ' | ' + def.signature.desc;
        if (def.lore) description += ' | "' + def.lore + '"';
        
        // Bane weapons ALWAYS roll flair — boss-themed
        const baneFlairMap = {
            warden:     { id: 'void', name: 'Void-Scarred', color: 0x8844ff, desc: 'Dark energy bleeds from hairline fractures' },
            stalker:    { id: 'spectral', name: 'Spectral', color: 0x44ff88, desc: 'A faint afterimage trails behind it' },
            deadlock:      { id: 'ember', name: 'Ember-Kissed', color: 0xff6622, desc: 'Smoldering embers drift from the metal' },
            cubeAnomaly:{ id: 'electric', name: 'Arc-Touched', color: 0x44ccff, desc: 'Electric pulses arc across the surface' }
        };
        const allFlairs = [
            { id: 'electric', name: 'Arc-Touched', color: 0x44ccff, desc: 'Electric pulses arc across the surface' },
            { id: 'ember', name: 'Ember-Kissed', color: 0xff6622, desc: 'Smoldering embers drift from the metal' },
            { id: 'void', name: 'Void-Scarred', color: 0x8844ff, desc: 'Dark energy bleeds from hairline fractures' },
            { id: 'frost', name: 'Frost-Locked', color: 0x88ddff, desc: 'A thin rime of ice that never melts' },
            { id: 'gilded', name: 'Gilded', color: 0xffcc44, desc: 'Gold veins run through the metal like ore' },
            { id: 'spectral', name: 'Spectral', color: 0x44ff88, desc: 'A faint afterimage trails behind it' }
        ];
        const baneFlair = baneFlairMap[bossType] || allFlairs[Math.floor(Math.random() * allFlairs.length)];
        
        const foundryDef = CONFIG.foundries[foundryId];
        return {
            id: `bane_${bossType}_${Date.now()}`,
            baseId: def.baseId,
            category: def.category,
            name: `${baneFlair.name} ${def.name}`,
            icon: def.icon,
            description: description,
            rarity: 'bane',
            tier: 6,
            tierName: 'Bane',
            tierLabel: 'Bane',
            tierColor: 0x8800ff,
            stats: stats,
            mods: mods,
            signatureMod: signatureMod,
            procedural: true,
            isBane: true,
            bossOrigin: bossType,
            lore: def.lore,
            flair: baneFlair,
            // Foundry module data
            foundry: foundryId,
            foundryName: foundryDef ? foundryDef.name : foundryId,
            foundryTag: foundryDef ? foundryDef.tag : '',
            foundryPalette: foundryDef ? foundryDef.palette : null,
            frame: frameKey,
            frameName: frameDef.name,
            partConfig: partConfig
        };
    },

        // === MAIN GENERATOR: Create a procedural item ===
    generateItem(category, forceTier = null, luckBonus = 0, reach = 1) {
        // Pick base item — respect gear tier restrictions
        let baseKeys = Object.keys(CONFIG.baseItems).filter(k => CONFIG.baseItems[k].category === category);
        if (baseKeys.length === 0) return null;
        
        // Roll tier first (needed for gear filtering)
        let tier;
        if (category === 'augment') {
            tier = 5;
        } else if (typeof forceTier === 'number' && forceTier > 0) {
            tier = this.rollTier(luckBonus, reach);
            if (tier < forceTier) tier = forceTier;
            tier = Math.min(tier, 5);
        } else {
            tier = this.rollTier(luckBonus, reach);
        }
        
        // Gear frame filtering — scrap only at T1-T2, light/medium/heavy at all tiers
        if (category === 'gear') {
            if (tier >= 3) {
                baseKeys = baseKeys.filter(k => k !== 'scrap_armor');
            }
        }
        
        const baseKey = baseKeys[Math.floor(Math.random() * baseKeys.length)];
        const base = CONFIG.baseItems[baseKey];
        const tierDef = CONFIG.tiers[tier];
        
        // Scale base stats by tier — damage/crit scale aggressively, utility stats scale gently
        // This prevents accuracy/fireRate/mag/reload from overflowing caps at high tiers
        const _damageStats = { damage:1, crit:1, health:1, armor:1 };
        const _fixedStats = { moveSpeed:1, pierce:1, targetRange:1, shieldAttack:1, speed:1, luck:1, backpack:1, dodge:1 };
        const stats = {};
        for (const [k, v] of Object.entries(base.stats)) {
            if (typeof v !== 'number') { stats[k] = v; continue; }
            if (_fixedStats[k]) { stats[k] = v; continue; }
            const mult = _damageStats[k] ? tierDef.damageMult : tierDef.utilityMult;
            stats[k] = Math.round(v * mult);
        }
        
        // === ROLL FOUNDRY FIRST for T3+ weapons/melee/gear ===
        // Foundry determines the frame pool — must roll before frame
        let foundryId = null;
        if (tier >= 3 && (category === 'weapon' || category === 'melee' || category === 'gear')) {
            foundryId = this.rollFoundry();
            
            // Apply foundry trait bias — subtle stat adjustments (+/- 8%)
            const foundryDef = CONFIG.foundries[foundryId];
            if (foundryDef && foundryDef.traitBias) {
                const bias = foundryDef.traitBias;
                if (bias === 'accuracy' && stats.accuracy) stats.accuracy = Math.round(stats.accuracy * 1.08);
                else if (bias === 'damage' && stats.damage) stats.damage = Math.round(stats.damage * 1.08);
                else if (bias === 'speed' && stats.fireRate) stats.fireRate = Math.round(stats.fireRate * 1.08);
                else if (bias === 'crit') { /* applied through mod system */ }
                else if (bias === 'mod') { /* higher mod effectiveness elsewhere */ }
            }
        }
        
        // === ROLL FRAME from foundry-specific pool ===
        let frameId = null, frameName = null, partConfig = null;
        if (category === 'weapon') {
            // Pick frame pool: foundry-specific for T3+, scrap for T1-T2
            const frames = (foundryId && CONFIG.foundryFrames[foundryId])
                ? CONFIG.foundryFrames[foundryId]
                : CONFIG.scrapFrames;
            // T5 Blood Forged: always pick the rarest frame (lowest weight)
            if (tier >= 5 && foundryId) {
                let rarestId = null, rarestWeight = Infinity;
                for (const [id, def] of Object.entries(frames)) {
                    if (def.weight < rarestWeight) { rarestWeight = def.weight; rarestId = id; }
                }
                frameId = rarestId || 'stock';
            } else {
                const pool = [];
                for (const [id, def] of Object.entries(frames)) {
                    for (let w = 0; w < def.weight; w++) pool.push(id);
                }
                frameId = pool[Math.floor(Math.random() * pool.length)];
            }
            const frameDef = frames[frameId];
            frameName = frameDef.name;
            partConfig = { ...frameDef.parts }; // clone part config
            for (const [k, m] of Object.entries(frameDef.mult)) {
                if (stats[k] !== undefined && typeof stats[k] === 'number') {
                    stats[k] = Math.round(stats[k] * m * 100) / 100;
                    stats[k] = Math.round(stats[k]);
                }
            }
        } else if (category === 'melee') {
            // Pick melee frame pool: foundry-specific for T3+, scrap for T1-T2
            const frames = (foundryId && CONFIG.foundryMeleeFrames[foundryId])
                ? CONFIG.foundryMeleeFrames[foundryId]
                : CONFIG.scrapMeleeFrames;
            // T5 Blood Forged: always pick the rarest frame (lowest weight)
            if (tier >= 5 && foundryId) {
                let rarestId = null, rarestWeight = Infinity;
                for (const [id, def] of Object.entries(frames)) {
                    if (def.weight < rarestWeight) { rarestWeight = def.weight; rarestId = id; }
                }
                frameId = rarestId || 'stock';
            } else {
                const pool = [];
                for (const [id, def] of Object.entries(frames)) {
                    for (let w = 0; w < def.weight; w++) pool.push(id);
                }
                frameId = pool[Math.floor(Math.random() * pool.length)];
            }
            const frameDef = frames[frameId];
            frameName = frameDef.name;
            partConfig = { ...frameDef.parts }; // melee part config
            for (const [k, m] of Object.entries(frameDef.mult)) {
                if (stats[k] !== undefined && typeof stats[k] === 'number') {
                    stats[k] = Math.round(stats[k] * m * 100) / 100;
                    stats[k] = Math.round(stats[k]);
                }
            }
        }
        
        // === WEAPON: Roll fire mode + recoil ===
        let fireMode = null, recoilType = null, fireModeCfg = null, recoilCfg = null;
        if (category === 'weapon' && base.fireModes) {
            // Roll fire mode
            fireMode = base.fireModes[Math.floor(Math.random() * base.fireModes.length)];
            fireModeCfg = CONFIG.fireModeConfig[fireMode];
            if (fireModeCfg) {
                stats.damage = Math.round(stats.damage * fireModeCfg.damageMult);
                stats.fireRate = Math.round(stats.fireRate * fireModeCfg.fireRateMult);
            }
            // Roll recoil
            if (base.recoilTypes) {
                recoilType = base.recoilTypes[Math.floor(Math.random() * base.recoilTypes.length)];
                recoilCfg = CONFIG.recoilConfig[recoilType];
            }
        }
        
        // === CLAMP STATS to their defined ranges ===
        const STAT_CAPS = { damage: 100, fireRate: 100, accuracy: 100, reload: 100, crit: 200, mag: 100, pierce: 5, targetRange: 5,
            attackSpeed: 100, reach: 100, stagger: 100, shieldAttack: 5, lifesteal: 15, massAttack: 5, soulbound: 3 };
        for (const [k, cap] of Object.entries(STAT_CAPS)) {
            if (stats[k] !== undefined && typeof stats[k] === 'number') {
                stats[k] = Math.min(stats[k], cap);
                if (stats[k] < 1) stats[k] = 1;
            }
        }
        
        // Generate mods (weapons, melee, gear get mods; augments don't)
        const mods = [];
        const altMods = []; // Destiny-style: second perk option per slot
        // Gear has custom mod slot counts: T1=0, T2/T3=2, T4=3, T5=3 (sig path adds 4th or extra mod)
        const gearModSlots = { 1: 0, 2: 2, 3: 2, 4: 3, 5: 3, 6: 4 };
        const modSlotCount = (category === 'gear') ? (gearModSlots[tier] || 0) : tierDef.modSlots;
        if (category !== 'augment' && modSlotCount > 0) {
            const usedModIds = new Set();
            const hasAltPerk = PlayerProgression.hasPerk(SaveManager.load(), 'mod_slot_2');
            for (let i = 0; i < modSlotCount; i++) {
                let mod = this.generateMod(category, tier);
                let attempts = 0;
                while (mod && usedModIds.has(mod.id) && !mod.special && attempts < 10) {
                    mod = this.generateMod(category, tier);
                    attempts++;
                }
                if (mod) {
                    usedModIds.add(mod.id);
                    mods.push(mod);
                    
                    // Roll an alternate option for this slot
                    if (hasAltPerk) {
                        let alt = this.generateMod(category, tier);
                        let altAttempts = 0;
                        while (alt && (usedModIds.has(alt.id) || alt.id === mod.id) && !alt.special && altAttempts < 10) {
                            alt = this.generateMod(category, tier);
                            altAttempts++;
                        }
                        altMods.push(alt || null);
                    } else {
                        altMods.push(null);
                    }
                }
            }
        }
        
        // Blood Forged: chance at unique signature mod OR a 5th regular mod (not augments — they use relicAbility)
        let signatureMod = null;
        if (tier === 5 && category !== 'augment') {
            const sigChance = 0.30; // 30% chance at unique signature
            if (Math.random() < sigChance) {
                signatureMod = this.generateSignatureMod(category);
            } else {
                // 5th regular mod instead
                let extraMod = this.generateMod(category, tier);
                let extraAttempts = 0;
                while (extraMod && usedModIds.has(extraMod.id) && !extraMod.special && extraAttempts < 10) {
                    extraMod = this.generateMod(category, tier);
                    extraAttempts++;
                }
                if (extraMod) { usedModIds.add(extraMod.id); mods.push(extraMod); }
            }
        }
        
        // === BUILD NAME ===
        let name;
        if (tier === 5 && CONFIG.bloodForgedNames[baseKey]) {
            // Blood Forged — unique name, keep foundry for visuals
            name = CONFIG.bloodForgedNames[baseKey];
        } else if (category === 'weapon') {
            const result = this.generateWeaponName(baseKey, tier, fireMode, foundryId);
            if (typeof result === 'object') {
                name = result.name;
                foundryId = result.foundry;
            } else {
                name = result;
            }
        } else if (category === 'melee') {
            const result = this.generateMeleeName(baseKey, tier, foundryId);
            if (typeof result === 'object') {
                name = result.name;
                foundryId = result.foundry;
            } else {
                name = result;
            }
        } else if (category === 'gear') {
            const result = this.generateGearName(baseKey, tier, foundryId);
            if (typeof result === 'object') {
                name = result.name;
                foundryId = result.foundry;
            } else {
                name = result;
            }
        } else {
            name = (tier >= 3 && category !== 'augment') ? `${tierDef.name} ${base.name}` : base.name;
        }
        
        // Get foundry data for description flavor
        const foundry = foundryId ? CONFIG.foundries[foundryId] : null;
        
        // Map tier to rarity
        const rarityMap = { 1: 'common', 2: 'uncommon', 3: 'rare', 4: 'legendary', 5: 'unique', 6: 'bane' };
        
        // Build description
        let description = '';
        // Fire mode + recoil tag for weapons
        if (fireModeCfg) {
            description = `[${fireModeCfg.label}]`;
            if (recoilCfg) description += ` ${recoilCfg.label} recoil`;
        }
        if (mods.length > 0) {
            description += (description ? ' | ' : '') + mods.map(m => { const dv = m.displayDiv ? (m.value / m.displayDiv).toFixed(1) : m.value; return `+${dv}${m.unit} ${m.name}`; }).join(', ');
        }
        if (signatureMod) {
            description += (description ? ' | ' : '') + signatureMod.desc;
        }
        if (base.desc) {
            description = base.desc + (description ? ' | ' : '') + description;
        }
        
        // Add foundry flavor to description
        if (foundry && foundry.flavorPool) {
            const flavor = foundry.flavorPool[Math.floor(Math.random() * foundry.flavorPool.length)];
            description += (description ? ' | ' : '') + '"' + flavor + '"';
        }
        
        const item = {
            id: `${baseKey}_${tier}_${Date.now()}_${Math.floor(Math.random()*9999)}`,
            baseId: baseKey,
            category: category,
            name: name,
            icon: base.icon,
            description: description,
            rarity: rarityMap[tier],
            tier: tier,
            tierName: tierDef.name,
            tierLabel: tierDef.label,
            tierColor: tierDef.color,
            stats: stats,
            mods: mods,
            altMods: altMods.some(m => m) ? altMods : undefined,
            signatureMod: signatureMod,
            procedural: true
        };
        
        // Foundry data — visual identity + lore hook
        if (foundryId) {
            item.foundry = foundryId;
            item.foundryName = CONFIG.foundries[foundryId].name;
            item.foundryTag = CONFIG.foundries[foundryId].tag;
            item.foundryPalette = CONFIG.foundries[foundryId].palette;
        }
        
        // Frame archetype data + modular part config
        if (frameId) {
            item.frame = frameId;
            item.frameName = frameName;
        }
        if (partConfig) {
            item.partConfig = partConfig;
        }
        
        // Weapon-specific data
        if (category === 'weapon') {
            if (fireMode) item.fireMode = fireMode;
            if (recoilType) item.recoilType = recoilType;
            if (fireModeCfg && fireModeCfg.burstCount) {
                item.burstCount = fireModeCfg.burstCount;
                item.burstDelay = fireModeCfg.burstDelay;
            }
            if (base.sprite) item.weaponSprite = base.sprite;
        }
        
        // Gear outfit data — foundry outfit overrides base default for T3+
        if (category === 'gear') {
            if (foundryId && CONFIG.foundries[foundryId] && CONFIG.foundries[foundryId].gearOutfit) {
                item.outfit = CONFIG.foundries[foundryId].gearOutfit;
            } else if (base.outfit) {
                item.outfit = base.outfit;
            }
            if (base.gearClass) item.gearClass = base.gearClass;
            // Frame name for subtitle display (mirrors weapon/melee pattern)
            const gearFrameLabels = { scrap: 'Scrap Armor', light: 'Light Armor', medium: 'Medium Armor', heavy: 'Heavy Armor' };
            item.frameName = gearFrameLabels[item.gearClass] || base.name;
        }
        
        // Relic ability data
        if (category === 'augment' && base.relicType) {
            item.relicType = base.relicType;
            item.relicAbility = base.relicAbility;
            item.relicCooldown = base.relicCooldown || 0;
        }
        
        // === ANIMATED FLAIR — "Shiny" weapons ===
        // Rare chance for weapons/melee to roll an animated visual effect
        // Higher tiers have better odds. Purely cosmetic.
        if (category === 'weapon' || category === 'melee') {
            // Base chance: 5% at T3, 8% at T4, 12% at T5. T1-T2 can't roll flair.
            const flairChance = tier <= 2 ? 0 : tier === 3 ? 0.05 : tier === 4 ? 0.08 : 0.12;
            if (Math.random() < flairChance) {
                const flairTypes = [
                    { id: 'electric', name: 'Arc-Touched', color: 0x44ccff, desc: 'Electric pulses arc across the surface' },
                    { id: 'ember', name: 'Ember-Kissed', color: 0xff6622, desc: 'Smoldering embers drift from the metal' },
                    { id: 'void', name: 'Void-Scarred', color: 0x8844ff, desc: 'Dark energy bleeds from hairline fractures' },
                    { id: 'frost', name: 'Frost-Locked', color: 0x88ddff, desc: 'A thin rime of ice that never melts' },
                    { id: 'gilded', name: 'Gilded', color: 0xffcc44, desc: 'Gold veins run through the metal like ore' },
                    { id: 'spectral', name: 'Spectral', color: 0x44ff88, desc: 'A faint afterimage trails behind it' }
                ];
                // Cephalon weapons bias toward void flair
                let pool = flairTypes;
                if (foundryId === 'cephalon') {
                    pool = [...flairTypes, flairTypes[2], flairTypes[2]]; // extra void weight
                } else if (foundryId === 'deralict') {
                    pool = [...flairTypes, flairTypes[1], flairTypes[1]]; // extra ember weight
                } else if (foundryId === 'blackreach') {
                    pool = [...flairTypes, flairTypes[4], flairTypes[4]]; // extra gilded weight
                }
                item.flair = pool[Math.floor(Math.random() * pool.length)];
                // Flair shown in subtitle only — NOT prepended to name
            }
        }
        
        // === FLAVOR TEXT — Every weapon/melee gets one ===
        if (category === 'weapon' || category === 'melee') {
            const _pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
            const fp = CONFIG.weaponFlavor;
            let flavor;
            if (item.flair && fp.flair[item.flair.id]) {
                flavor = Math.random() < 0.55 ? _pick(fp.flair[item.flair.id]) : _pick(fp.generic);
            } else if (foundryId && fp.foundry[foundryId]) {
                flavor = Math.random() < 0.5 ? _pick(fp.foundry[foundryId]) : _pick(fp.generic);
            } else if (category === 'melee') {
                flavor = Math.random() < 0.45 ? _pick(fp.melee) : _pick(fp.universal || fp.generic);
            } else {
                flavor = _pick(fp.generic);
            }
            item.flavorText = flavor;
            item.kills = 0;
        }
        
        return item;
    },
    
    // Generate procedural weapon name
    // Roll a random foundry for T3+ items
    rollFoundry() {
        const foundryKeys = Object.keys(CONFIG.foundries);
        // Weighted: Cephalon and Blackreach are rarer
        const weights = {
            terracorp: 25, ucr: 25, deralict: 20, sworn: 20, blackreach: 6, cephalon: 4
        };
        const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0);
        let roll = Math.random() * totalWeight;
        for (const key of foundryKeys) {
            roll -= (weights[key] || 10);
            if (roll <= 0) return key;
        }
        return foundryKeys[0];
    },
    
    generateWeaponName(baseKey, tier, fireMode, foundryId = null) {
        if (tier <= 2) {
            // Scrap — no foundry
            const pool = CONFIG.weaponNames.scrap;
            const prefix = pool.prefix[Math.floor(Math.random() * pool.prefix.length)];
            const suffixes = pool[baseKey] || ['Mk' + tier];
            const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
            return `${prefix} ${suffix}`;
        } else {
            // Foundry weapon: "Terracorp AR-7" or "Sworn Defiant"
            const fid = foundryId || this.rollFoundry();
            const foundry = CONFIG.foundries[fid];
            const fNames = CONFIG.weaponNames.foundry[fid];
            const suffixes = (fNames && fNames[baseKey]) || ['Mk'];
            const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
            // Short code names get a number (AR-7, MG-12), full names stand alone (Defiant, Avalanche)
            const nameStr = suffix.length <= 3
                ? `${suffix}-${Math.floor(Math.random() * 20) + 1}`
                : suffix;
            return { name: nameStr, foundry: fid };
        }
    },
    
    // Generate procedural melee name
    generateMeleeName(baseKey, tier, foundryId = null) {
        if (tier <= 2) {
            const pool = CONFIG.meleeNames.scrap;
            const names = pool[baseKey] || ['Weapon'];
            const name = names[Math.floor(Math.random() * names.length)];
            const prefixes = ['Rusty', 'Bent', 'Cracked', 'Taped', 'Worn', 'Dull', 'Chipped'];
            const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
            return `${prefix} ${name}`;
        } else {
            const fid = foundryId || this.rollFoundry();
            const foundry = CONFIG.foundries[fid];
            const fNames = CONFIG.meleeNames.foundry[fid];
            const names = (fNames && fNames[baseKey]) || ['Weapon'];
            const name = names[Math.floor(Math.random() * names.length)];
            return { name: name, foundry: fid };
        }
    },
    
    // Generate procedural gear name
    generateGearName(baseKey, tier, foundryId = null) {
        if (tier <= 2) {
            const pool = CONFIG.gearNames.scrap;
            const names = pool[baseKey] || ['Armor'];
            const name = names[Math.floor(Math.random() * names.length)];
            const prefixes = ['Scrap', 'Torn', 'Stitched', 'Salvaged', 'Patched', 'Worn', 'Frayed'];
            const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
            return `${prefix} ${name}`;
        } else {
            const fid = foundryId || this.rollFoundry();
            const fNames = CONFIG.gearNames.foundry[fid];
            const names = (fNames && fNames[baseKey]) || ['Armor'];
            const name = names[Math.floor(Math.random() * names.length)];
            return { name: name, foundry: fid };
        }
    },
    
    // Create a static item instance (consumables, scrap, keys, cubes)
    createItem(itemId) {
        // Check if it's a static item
        const def = this.getItem(itemId);
        if (def) {
            const item = {
                id: def.id,
                category: def.category,
                name: def.name,
                icon: def.icon,
                description: def.description,
                rarity: def.rarity,
                tier: def.tier || 1,
                healAmount: def.healAmount || 0,
                healPercent: def.healPercent || 0,
                procedural: false
            };
            // Carry consumable effect data
            if (def.effect) item.effect = def.effect;
            if (def.effectDuration) item.effectDuration = def.effectDuration;
            if (def.effectValue) item.effectValue = def.effectValue;
            if (def.effectRadius) item.effectRadius = def.effectRadius;
            // Carry subtype for consumable grouping
            if (def.subtype) item.subtype = def.subtype;
            // Carry scrap value
            if (def.scrapValue) item.scrapValue = def.scrapValue;
            // Carry grenade/pylon fields
            if (def.fuseTime !== undefined) item.fuseTime = def.fuseTime;
            if (def.callout) item.callout = def.callout;
            if (def.pylonType) item.pylonType = def.pylonType;
            if (def.pylonValue) item.pylonValue = def.pylonValue;
            if (def.pylonRadius) item.pylonRadius = def.pylonRadius;
            if (def.zoneDuration) item.zoneDuration = def.zoneDuration;
            if (def.tickInterval) item.tickInterval = def.tickInterval;
            // Carry key_item action fields
            if (def.useAction) item.useAction = def.useAction;
            if (def.grantMin) item.grantMin = def.grantMin;
            if (def.grantMax) item.grantMax = def.grantMax;
            if (def.grantBits !== undefined) item.grantBits = def.grantBits;
            if (def.grantMats !== undefined) item.grantMats = def.grantMats;
            return item;
        }
        return null;
    },
    
    // Get the correct loot table name for a context, factoring in reach
    getEnemyTable(reach) {
        if (reach >= 5) return 'enemy_late';
        if (reach >= 3) return 'enemy_mid';
        return 'enemy_early';
    },
    

    
    // Roll from a weighted loot table (returns item object or null)
    rollLootTable(tableName, luckBonus = 0, reach = 1, equipment = null, locationMods = null) {
        const table = CONFIG.lootTables[tableName];
        if (!table || table.length === 0) return null;
        
        // Apply location modifiers to weights
        let modTable = table;
        if (locationMods) {
            modTable = table.map(entry => {
                let w = entry.weight;
                // Match location modifier categories to entry properties
                if (entry.id) {
                    if (locationMods.medical && (entry.id.includes('bandage') || entry.id.includes('medkit') || entry.id.includes('pylon_heal'))) w *= locationMods.medical;
                    if (locationMods.consumable && (entry.id.includes('bandage') || entry.id.includes('medkit') || entry.id.includes('grenade') || entry.id.includes('pylon'))) w *= locationMods.consumable;
                    if (locationMods.ammo && entry.id.includes('ammo')) w *= locationMods.ammo;
                    if (locationMods.fuel && entry.id.includes('fuel')) w *= locationMods.fuel;
                    if (locationMods.crafting && (entry.id.includes('scrap') || entry.id.includes('lockpick'))) w *= locationMods.crafting;
                }
                if (entry.type === 'procedural') {
                    if (locationMods.weapon && entry.category === 'weapon') w *= locationMods.weapon;
                    if (locationMods.weapon_mod && entry.category === 'weapon') w *= locationMods.weapon_mod;
                    if (locationMods.augment && entry.category === 'augment') w *= locationMods.augment;
                }
                if (locationMods.general) w *= locationMods.general;
                return { ...entry, weight: w };
            });
        }
        
        const totalWeight = modTable.reduce((sum, e) => sum + e.weight, 0);
        let roll = Math.random() * totalWeight;
        
        let result = null;
        for (const entry of modTable) {
            roll -= entry.weight;
            if (roll <= 0) {
                if (entry.type === 'procedural') {
                    const minTier = entry.minTier || null;
                    result = this.generateItem(entry.category, minTier, luckBonus, reach);
                } else {
                    result = entry.id;
                }
                break;
            }
        }
        
        if (!result) {
            const last = modTable[modTable.length - 1];
            result = last.type === 'procedural' ? this.generateItem(last.category, null, luckBonus, reach) : last.id;
        }
        
        // Field Medic: 40% chance to upgrade bandage drops one tier (check augments on weapon/melee)
        const _hasAugAbility = (eq, ability) => {
            return (eq?.weapon?.augment?.relicAbility === ability) || (eq?.melee?.augment?.relicAbility === ability);
        };
        if (equipment && _hasAugAbility(equipment, 'fieldMedic') && typeof result === 'string') {
            const upgradeMap = { 'bandage': 'bandage_military', 'bandage_military': 'medkit', 'medkit': 'medkit_advanced' };
            if (upgradeMap[result] && Math.random() < 0.40) {
                result = upgradeMap[result];
            }
        }
        
        return result;
    },
    
    // Get tier color for an item (works for both static and procedural)
    getItemColor(item) {
        if (item.tierColor) return item.tierColor;
        const rarityDef = CONFIG.itemRarity[item.rarity];
        return rarityDef ? rarityDef.color : 0x888888;
    },
    
    // Get glow color for an item
    getItemGlow(item) {
        if (item.tier) {
            const tierDef = CONFIG.tiers[item.tier];
            return tierDef ? tierDef.glow : 0xaaaaaa;
        }
        const rarityDef = CONFIG.itemRarity[item.rarity];
        return rarityDef ? rarityDef.glow : 0xaaaaaa;
    },
    
    // Check if inventory has empty space
    hasSpace(inventory) {
        if (!inventory || !Array.isArray(inventory)) return false;
        return inventory.some(slot => slot === null);
    },
    
    findEmptySlot(inventory) {
        if (!inventory || !Array.isArray(inventory)) return -1;
        return inventory.findIndex(slot => slot === null);
    },
    
    getFilledCount(inventory) {
        if (!inventory || !Array.isArray(inventory)) return 0;
        return inventory.filter(slot => slot !== null).length;
    },
    
    // Stacking helpers — scrap and consumable items stack by matching ID
    isStackable(item) {
        if (!item) return false;
        return item.category === 'scrap' || item.category === 'consumable';
    },
    
    getStackLimit(item) {
        if (!item) return 1;
        if (item.category === 'scrap') return 10;
        if (item.category === 'consumable') return 5;
        return 1;
    },
    
    // Find existing stack of same item ID in inventory (returns slot index or -1)
    findExistingStack(inventory, item) {
        if (!inventory || !item || !this.isStackable(item)) return -1;
        const limit = this.getStackLimit(item);
        for (let i = 0; i < inventory.length; i++) {
            const slot = inventory[i];
            if (slot && slot.id === item.id && (slot.stackCount || 1) < limit) return i;
        }
        return -1;
    },
    
    // Get total count of an item across all stacks in inventory
    getTotalCount(inventory, itemId) {
        if (!inventory) return 0;
        let total = 0;
        for (let i = 0; i < inventory.length; i++) {
            if (inventory[i] && inventory[i].id === itemId) total += (inventory[i].stackCount || 1);
        }
        return total;
    },
    
    // Remove one from a stack (or the whole item if stackCount <= 1). Returns the item removed (single copy).
    removeOneFromStack(inventory, slotIndex) {
        if (!inventory || slotIndex < 0 || slotIndex >= inventory.length) return null;
        const item = inventory[slotIndex];
        if (!item) return null;
        const count = item.stackCount || 1;
        if (count <= 1) {
            inventory[slotIndex] = null;
            return item;
        }
        // Decrement stack, return a copy of the single item
        item.stackCount = count - 1;
        const copy = Object.assign({}, item);
        copy.stackCount = 1;
        return copy;
    },
    
    // Add item to inventory — accepts item object or static item ID string
    // Stackable items (scrap, consumable) will merge into existing stacks before using new slots
    addItem(inventory, itemOrId) {
        let item;
        if (typeof itemOrId === 'string') {
            item = this.createItem(itemOrId);
            if (!item) return false;
        } else if (typeof itemOrId === 'object' && itemOrId !== null) {
            item = itemOrId;
        } else {
            return false;
        }
        
        // Try to stack into existing slot first
        if (this.isStackable(item)) {
            const existingIdx = this.findExistingStack(inventory, item);
            if (existingIdx !== -1) {
                const existing = inventory[existingIdx];
                const addCount = item.stackCount || 1;
                existing.stackCount = (existing.stackCount || 1) + addCount;
                return true;
            }
        }
        
        // No existing stack (or not stackable) — find empty slot
        const slotIndex = this.findEmptySlot(inventory);
        if (slotIndex === -1) return false;
        
        // Ensure stackable items have stackCount initialized
        if (this.isStackable(item) && !item.stackCount) {
            item.stackCount = 1;
        }
        inventory[slotIndex] = item;
        return true;
    },
    
    removeItem(inventory, slotIndex) {
        if (!inventory || slotIndex < 0 || slotIndex >= inventory.length) return null;
        const item = inventory[slotIndex];
        inventory[slotIndex] = null;
        return item;
    },
    
    transferItem(fromInventory, fromSlot, toInventory, toSlot = null) {
        const item = this.removeItem(fromInventory, fromSlot);
        if (!item) return false;
        
        if (toSlot !== null && toSlot >= 0 && toSlot < toInventory.length) {
            if (toInventory[toSlot] !== null) {
                fromInventory[fromSlot] = toInventory[toSlot];
            }
            toInventory[toSlot] = item;
            return true;
        } else {
            // Use addItem for stack-aware placement
            if (this.addItem(toInventory, item)) {
                return true;
            }
            // No space — put it back
            fromInventory[fromSlot] = item;
            return false;
        }
    },
    
    clearInventory(inventory) {
        if (!inventory || !Array.isArray(inventory)) return;
        for (let i = 0; i < inventory.length; i++) {
            inventory[i] = null;
        }
    },
    
    createInventory(size) {
        return new Array(size).fill(null);
    },
    
    // Equip an item from backpack to equipment slot, return unequipped item (or null)
    equipItem(equipment, backpack, slotIndex) {
        const item = backpack[slotIndex];
        if (!item) return null;
        
        const slot = item.category; // 'weapon', 'melee', 'gear', 'augment'
        if (!CONFIG.equipmentSlots[slot]) return null;
        
        const prev = equipment[slot];
        equipment[slot] = item;
        backpack[slotIndex] = prev; // swap — old equipped goes to backpack slot
        EventBus.emit('audio:equip');
        Haptics.light();
        EventBus.emit('equip', { slot, item });
        return item;
    },
    
    // Unequip item from equipment slot back to backpack
    unequipItem(equipment, backpack, slot) {
        const item = equipment[slot];
        if (!item) return false;
        if (!this.hasSpace(backpack)) return false;
        equipment[slot] = null;
        this.addItem(backpack, item);
        return true;
    },
    

    
    // Find first consumable in backpack (for quick-use button)
    findFirstConsumable(backpack) {
        if (!backpack) return -1;
        for (let i = 0; i < backpack.length; i++) {
            if (backpack[i] && backpack[i].category === 'consumable') return i;
        }
        return -1;
    },
    
    /**
     * Use a key_item — grants currency, adds lore, etc.
     * Returns true if consumed, false if failed.
     */
    useKeyItem(scene, state, item, player) {
        if (!item || item.category !== 'key_item' || !item.useAction) return false;
        
        const action = item.useAction;
        const min = item.grantMin || 0;
        const max = item.grantMax || 0;
        const amount = min === max ? min : Math.floor(Math.random() * (max - min + 1)) + min;
        
        if (action === 'grant_bits') {
            if (state) state.bits = (state.bits || 0) + amount;
            if (scene && player && typeof Blurbs !== 'undefined') {
                Blurbs.show(scene, player, `+${amount} Bits`, { color: '#ffcc44', fontSize: 12 });
            }
            EventBus.emit('audio:heal');
            if (typeof Haptics !== 'undefined') Haptics.light();
            // Update HUD
            if (scene.bitsText) scene.bitsText.setText(`${state.bits || 0}`);
            return true;
            
        } else if (action === 'grant_fuel') {
            if (state) state.fuel = (state.fuel || 0) + amount;
            if (scene && player && typeof Blurbs !== 'undefined') {
                Blurbs.show(scene, player, `+${amount} Fuel`, { color: '#66aa66', fontSize: 12 });
            }
            EventBus.emit('audio:heal');
            if (typeof Haptics !== 'undefined') Haptics.light();
            if (scene.fuelText) scene.fuelText.setText(`${state.fuel || 0}`);
            return true;
            
        } else if (action === 'grant_materials') {
            // Materials add to current state — deposited to stash on run return
            const _matBonus = (state && state.survivorMods?.materialsBonus) || 0;
            const matAmount = Math.round(amount * (1 + _matBonus));
            if (state) state.materials = (state.materials || 0) + matAmount;
            if (scene && scene._runStats) scene._runStats.materialsEarned += matAmount;
            // Resonant mark: chance for bonus material on any pickup
            const _bonusMatChance = state?.survivorMods?.conditionals?.bonusMaterialChance || 0;
            if (_bonusMatChance > 0 && Math.random() < _bonusMatChance) {
                const bonusAmt = Math.max(1, Math.round(amount * 0.5));
                if (state) state.materials = (state.materials || 0) + bonusAmt;
                if (scene && player && typeof Blurbs !== 'undefined') {
                    Blurbs.show(scene, player, `+${bonusAmt} RESONANT`, { color: '#aa88ff', fontSize: 10, duration: 500 });
                }
            }
            if (scene && player && typeof Blurbs !== 'undefined') {
                Blurbs.show(scene, player, `+${matAmount} Materials`, { color: '#887766', fontSize: 12 });
            }
            EventBus.emit('audio:heal');
            if (typeof Haptics !== 'undefined') Haptics.light();
            return true;
            
        } else if (action === 'grant_powerAmmo') {
            if (state) state.powerAmmo = (state.powerAmmo || 0) + amount;
            if (scene && player && typeof Blurbs !== 'undefined') {
                Blurbs.show(scene, player, `+${amount} Power Ammo`, { color: '#aa8844', fontSize: 12 });
            }
            EventBus.emit('audio:heal');
            if (typeof Haptics !== 'undefined') Haptics.light();
            return true;
            
        } else if (action === 'lore') {
            // Lore chip — pick a random undiscovered chip and add to collection
            const chipId = (typeof SaveManager !== 'undefined' && StatTracker.getRandomUndiscoveredChip) 
                ? StatTracker.getRandomUndiscoveredChip() : null;
            if (chipId) {
                StatTracker.addLoreChip(chipId);
                const chip = CONFIG.loreChips[chipId];
                const chipTitle = chip ? chip.title : 'Unknown Entry';
                if (scene && player && typeof Blurbs !== 'undefined') {
                    Blurbs.show(scene, player, `Lore: ${chipTitle}`, { color: '#44ddcc', fontSize: 12 });
                }
            } else {
                // All lore already found
                if (scene && player && typeof Blurbs !== 'undefined') {
                    Blurbs.show(scene, player, 'All lore discovered', { color: '#888888', fontSize: 12 });
                }
                return false; // Don't consume if nothing to unlock
            }
            EventBus.emit('audio:heal');
            if (typeof Haptics !== 'undefined') Haptics.light();
            return true;
        }
        
        return false;
    },
    
    /**
     * Check if player has a toolkit in backpack or vehicle.
     * Returns the item and inventory index if found, or null.
     */
    findToolkit(backpack) {
        if (!backpack) return null;
        for (let i = 0; i < backpack.length; i++) {
            if (backpack[i] && backpack[i].id === 'toolkit') return { item: backpack[i], index: i };
        }
        return null;
    },
    
    // Get effective player stats from equipment
    getEquipmentStats(equipment) {
        const stats = {
            // Gun stats (all 1-100 flat, pierce/targetRange 1-5)
            damage: 0, fireRate: 0, accuracy: 0, crit: 0,
            mag: 10, reload: 50, pierce: 1, targetRange: 1,
            // Melee stats (all 1-100 flat, massAttack/shieldAttack 1-5)
            meleeDamage: 0, meleeSpeed: 0, meleeRange: 0, meleeStagger: 0,
            lifesteal: 0, massAttack: 1, shieldAttack: 1,
            // Gear stats
            armor: 0, moveSpeed: 100, lootLuck: 0, dodgeChance: 0,
            maxHealth: 0, damageResist: 0, healBonus: 0, carryCapacity: 0,
            backpackSlots: 0, sightline: 0,
            burnResist: 0, poisonResist: 0, bleedResist: 0,
            // Soulbound
            soulbound: 0,
            // Collected signature effects
            signatures: []
        };
        if (!equipment) return stats;
        
        // Helper: apply mods from an item — ALL flat adds, no percentages
        const applyMods = (item, statMap) => {
            if (!item || !item.mods) return;
            item.mods.forEach(mod => {
                if (!mod || mod.special) return;
                const mapping = statMap[mod.stat] || mod.stat;
                if (typeof mapping === 'string' && stats[mapping] !== undefined) {
                    stats[mapping] += mod.value;
                }
            });
            // Soulbound is special but still additive
            if (item.mods) item.mods.forEach(mod => {
                if (mod && mod.stat === 'soulbound') stats.soulbound += mod.value;
            });
            if (item.signatureMod) {
                stats.signatures.push(item.signatureMod);
            }
        };
        
        // Weapon — base stats + flat mods
        if (equipment.weapon && equipment.weapon.stats) {
            const ws = equipment.weapon.stats;
            stats.damage = ws.damage || 0;
            stats.fireRate = ws.fireRate || 0;
            stats.accuracy = ws.accuracy || 0;
            stats.crit = ws.crit || 0;
            stats.mag = ws.mag || 10;
            stats.reload = ws.reload || 50;
            stats.pierce = ws.pierce || 1;
            stats.targetRange = ws.targetRange || 1;
            applyMods(equipment.weapon, {
                damage: 'damage',
                fireRate: 'fireRate',
                reload: 'reload',
                accuracy: 'accuracy',
                crit: 'crit',
                mag: 'mag',
                pierce: 'pierce',
                targetRange: 'targetRange'
            });
        }
        // Melee — base stats + flat mods
        if (equipment.melee && equipment.melee.stats) {
            const ms = equipment.melee.stats;
            stats.meleeDamage = ms.damage || 0;
            stats.meleeSpeed = ms.attackSpeed || 0;
            stats.meleeRange = ms.reach || 0;
            stats.meleeStagger = ms.stagger || 0;
            stats.shieldAttack = ms.shieldAttack || 1;
            applyMods(equipment.melee, {
                meleeDamage: 'meleeDamage',
                attackSpeed: 'meleeSpeed',
                stagger: 'meleeStagger',
                lifesteal: 'lifesteal',
                reach: 'meleeRange',
                massAttack: 'massAttack',
                shieldAttack: 'shieldAttack'
            });
        }
        // Gear — base frame stats (health/armor scaled by tier, speed/luck/backpack fixed)
        if (equipment.gear && equipment.gear.stats) {
            const gs = equipment.gear.stats;
            stats.maxHealth += gs.health || 0;
            stats.armor += gs.armor || 0;
            stats.moveSpeed = gs.speed || 100;
            stats.lootLuck += gs.luck || 0;
            stats.backpackSlots = gs.backpack || 0;
            stats.dodgeChance = gs.dodge || 0;
            // Gear mods
            applyMods(equipment.gear, {
                carryCapacity: 'carryCapacity',
                maxHealth: 'maxHealth',
                damageResist: 'damageResist',
                sightline: 'sightline',
                healBonus: 'healBonus',
                lootLuck: 'lootLuck',
                burnResist: 'burnResist',
                poisonResist: 'poisonResist',
                bleedResist: 'bleedResist'
            });
        }
        // Augments — check augment chips slotted into weapon and melee
        [equipment.weapon, equipment.melee].forEach(item => {
            if (item && item.augment && item.augment.stats) {
                const rs = item.augment.stats;
                for (const [k, v] of Object.entries(rs)) {
                    if (k === 'damage') {
                        stats.damage += v;
                        stats.meleeDamage += v;
                    } else if (stats[k] !== undefined) {
                        stats[k] += v;
                    } else {
                        stats[k] = v;
                    }
                }
            }
        });
        // Apply augment chip passive bonuses
        const _hasAugAbility2 = (eq, ability) => {
            return (eq?.weapon?.augment?.relicAbility === ability) || (eq?.melee?.augment?.relicAbility === ability);
        };
        if (_hasAugAbility2(equipment, 'luckyDucky')) {
            stats.lootLuck += 5; // +5% loot chance
        }
        
        // Apply active gym buff from save data
        try {
            const saveData = SaveManager.load();
            if (saveData && saveData.gymBuff && saveData.gymBuff.remainingMs > 0) {
                const gb = saveData.gymBuff.buffs;
                if (gb.maxHealth)    stats.maxHealth += gb.maxHealth;
                if (gb.damageResist) stats.damageResist = (stats.damageResist || 0) + gb.damageResist;
                if (gb.elemResist)   { stats.burnResist = (stats.burnResist || 0) + gb.elemResist; stats.poisonResist = (stats.poisonResist || 0) + gb.elemResist; }
                if (gb.accuracy)     stats.accuracy = (stats.accuracy || 0) + gb.accuracy;
                if (gb.damage)       stats.gymDamageBonus = gb.damage;  // % bonus, applied in shoot/melee
                if (gb.crit)         stats.crit = (stats.crit || 0) + gb.crit;
                if (gb.dodge)        stats.dodgeChance = (stats.dodgeChance || 0) + gb.dodge;
                if (gb.speed)        stats.moveSpeed += gb.speed;  // additive, not multiplicative
                if (gb.lootLuck)     stats.lootLuck = (stats.lootLuck || 0) + gb.lootLuck;
            }
        } catch(e) { /* silently fail if save not available */ }
        
        return stats;
    },
    
    // Convenience — get equipment stats from player state
    getEquippedStats(state) {
        return this.getEquipmentStats(state && state.equipment ? state.equipment : {});
    },
    // scale: 1.0 = rack size, 1.5 = inventory slot, 2.0 = detail card
    drawItemPixelArt(scene, container, x, y, item, scale, depth) {
        if (!item) return;
        const base = CONFIG.baseItems[item.baseId] || {};
        const cat = item.category || base.category || '';
        const sprite = base.sprite || item.baseId || '';
        const d = depth || 50;
        const s = scale || 1.0;
        const color = ItemManager.getItemColor(item);
        const metal = 0x8a8a8a;
        const darkM = 0x5a5a5a;
        const wood = 0x6a4a2a;
        
        // Per-instance seed — deterministic micro-offsets from item ID
        // Gives visual variety: two same-frame weapons look subtly different
        let _seedVal = 0;
        const _id = item.id || '';
        for (let i = 0; i < _id.length; i++) _seedVal = ((_seedVal * 31 + _id.charCodeAt(i)) ^ (_seedVal >>> 3)) | 0;
        // Scramble bits to decorrelate adjacent indices
        const _sOff = (idx) => {
            let h = (_seedVal ^ (idx * 2654435761)) | 0; // Knuth multiplicative hash
            h = ((h >>> 16) ^ h) | 0;
            return ((h & 0x1F) - 15.5) / 15.5; // 32 levels, range -1.0 to +1.0
        };
        
        const _sr = ItemManager._shapeRenderer;
        if (!_sr) return; // No renderer — skip visual drawing
        const r = (rx, ry, rw, rh, col, alpha) => {
            _sr.rect(scene, container, x + rx * s, y + ry * s, rw * s, rh * s, col, alpha !== undefined ? alpha : 1, d);
        };
        const c = (cx, cy, cr, col, alpha) => {
            _sr.circle(scene, container, x + cx * s, y + cy * s, cr * s, col, alpha !== undefined ? alpha : 1, d);
        };
        
        if (cat === 'weapon') {
            // === FOUNDRY PALETTE ===
            const foundry = item.foundry ? CONFIG.foundries[item.foundry] : null;
            const p = foundry ? foundry.palette : null;
            const isScrap = !foundry;
            const bCol  = p ? parseInt(p.body.replace('#',''),16)      : 0x4a4038;
            const bColL = p ? parseInt(p.bodyLight.replace('#',''),16) : 0x5a5248;
            const bColD = p ? parseInt(p.bodyDark.replace('#',''),16)  : 0x3a3430;
            const aCol  = p ? parseInt(p.accent.replace('#',''),16)    : 0x8a8a6a;
            const mCol  = p ? parseInt(p.metal.replace('#',''),16)     : 0x5a5248;
            const mColL = p ? parseInt(p.metalLight.replace('#',''),16): 0x5a5248;
            const dCol  = p ? parseInt(p.detail.replace('#',''),16)    : 0x3a3430;
            const wCol  = isScrap ? 0x5a4228 : (p ? Math.min(0xFFFFFF, parseInt(p.body.replace('#',''),16) + 0x101008) : 0x6a4a2a);
            const scTape = 0x8a8a6a;
            const scRust = 0x6a3a1a;
            
            // Part configuration from generation (or fallback)
            const pc = item.partConfig || { barrel: 'standard', stock: 'polymer', magazine: 'box', muzzle: 'birdcage' };
            const isEnergy = (foundry && (item.foundry === 'blackreach' || item.foundry === 'cephalon'));
            
            // ══════════════════════════════════════════════════════════
            // PARAMETERIZED PART DEFINITIONS
            // ══════════════════════════════════════════════════════════
            // Barrel: [lengthMul, widthMul, flags]
            const BD = {
                standard: [1.0, 1.0], precision: [1.1, 0.85], match: [1.3, 0.85, 'fluted'],
                heavy: [1.0, 1.3], short: [0.7, 1.0], fluted: [1.0, 0.85, 'fluted'],
                railed: [1.1, 1.0, 'rail'], bore: [0.85, 1.4], heavy_bore: [1.0, 1.5],
                wide_bore: [0.85, 1.7, 'flared'], salvaged: [0.9, 1.0, 'tape'], cut_down: [0.65, 1.0],
                mixed: [1.0, 1.0, 'mixed'], pipe: [0.85, 1.1, 'rust'],
                emitter: [1.0, 1.0, 'glow'], long_emitter: [1.3, 0.9, 'glow'],
                charged_emitter: [1.1, 1.1, 'glow_pulse'], slim_emitter: [1.0, 0.7, 'glow'],
                conduit: [1.0, 1.0, 'seam'], long_conduit: [1.3, 0.9, 'seam'],
                warped: [0.9, 1.0, 'seam_warp'], tuned_conduit: [1.15, 1.0, 'seam_rings']
            };
            // Stock: [widthMul, heightMul, style]
            const SD = {
                polymer: [1.0, 1.0, 'solid'], adjustable: [1.1, 0.8, 'tube'], fixed: [1.0, 1.2, 'solid'],
                folding: [0.8, 0.5, 'wire'], ergonomic: [1.0, 1.0, 'contour'], precision: [1.1, 1.0, 'contour'],
                skeleton: [1.0, 0.8, 'skel'], thumbhole: [1.2, 1.0, 'contour'],
                pipe: [0.6, 0.6, 'pipe'], braced: [1.2, 1.2, 'brace'], none: [0, 0, 'none'],
                wrapped: [0.9, 0.9, 'wrap'], chopped: [0.6, 0.8, 'solid'], carved: [1.0, 1.0, 'carved'],
                scrap: [0.8, 0.8, 'scrap'], integrated: [1.0, 0.8, 'seamless'], skeletal: [0.8, 0.7, 'skel'],
                floating: [0.7, 0.7, 'float'], organic: [0.9, 0.9, 'organic'],
                wood: [0.9, 0.9, 'solid'], plank: [0.8, 1.0, 'plank']
            };
            // Magazine: [widthMul, heightMul, style]
            const MD = {
                box: [1.0, 1.0, 'box'], extended: [1.0, 1.4, 'box'], flush: [0.8, 0.6, 'flush'],
                canister: [1.2, 1.0, 'round'], drum: [1.8, 1.5, 'round'], hopper: [1.5, 1.2, 'top'],
                taped: [1.0, 1.0, 'tape'], taped_double: [1.6, 1.0, 'tape'], franken: [1.3, 1.3, 'scrap'],
                cell: [0.9, 0.8, 'crystal'], dual_cell: [1.4, 0.8, 'crystal'], core: [1.0, 1.0, 'sphere'],
                phase: [0.9, 0.9, 'phase'], recursive: [1.0, 1.2, 'phase'], exposed: [1.0, 1.0, 'exposed']
            };
            // Muzzle: [sizeMul, style]
            const ZD = {
                birdcage: [1.0, 'cage'], compensator: [1.0, 'vent'], brake: [1.3, 'vent'],
                suppressor: [2.5, 'can'], flash_hider: [0.8, 'cage'], tuned: [0.6, 'crown'],
                coils: [1.2, 'coil'], ported: [0.8, 'port'], nozzle: [1.0, 'nozzle'],
                open: [0.5, 'open'], cage: [1.2, 'cage'], flared: [1.4, 'flare'],
                hacksawed: [0.5, 'raw'], welded: [0.9, 'weld'], raw: [0.3, 'raw'],
                improvised: [0.8, 'scrap'], filed: [0.5, 'crown'], lens: [1.0, 'lens'],
                aperture: [1.2, 'iris'], diffuser: [1.3, 'multi'], prism: [1.2, 'prism'],
                slit: [0.7, 'slit'], ring: [1.0, 'ring'], void_ring: [1.3, 'ring'],
                fracture: [1.0, 'fracture'], harmonic: [1.2, 'harmonic']
            };
            
            const _bd = BD[pc.barrel] || BD.standard;
            const _sd = SD[pc.stock] || SD.polymer;
            const _md = MD[pc.magazine] || MD.box;
            const zd = ZD[pc.muzzle] || ZD.birdcage;
            
            // Per-instance micro-variation: ±8% on key dimensions via seed
            const bd = [_bd[0] * (1 + _sOff(0) * 0.08), _bd[1] * (1 + _sOff(1) * 0.06), _bd[2]];
            const sd = [_sd[0] * (1 + _sOff(2) * 0.06), _sd[1] * (1 + _sOff(3) * 0.06), _sd[2]];
            const md = [_md[0] * (1 + _sOff(4) * 0.05), _md[1] * (1 + _sOff(5) * 0.07), _md[2]];
            
            // ══════════════════════════════════════════════════════════
            // PER-TYPE WEAPON ASSEMBLY
            // Each type defines base dimensions per slot, then draws
            // parts using parameterized configs
            // ══════════════════════════════════════════════════════════
            
            if (sprite === 'rifle') {
                // Receiver — always drawn
                r(-1, 0, 8, 3, bCol);
                r(0, -2, 6, 1, bColD);                // top rail
                r(1, 1.5, 1.5, 1.5, mCol, 0.7);      // trigger guard
                
                // Barrel — base 6 long, 2 wide, starts x+3
                const bL = 6 * bd[0], bW = 2 * bd[1];
                r(3 + bL/2, 0, bL, bW, mCol);
                r(3 + bL, 0, 1, bW * 0.75, mColL);   // tip
                if (bd[2] === 'fluted') { for (let f=0;f<3;f++) r(3+bL*0.3+f*bL*0.2, 0, 0.5, bW*0.7, bColD, 0.2); }
                if (bd[2] === 'rail') r(3+bL*0.2, -bW/2-0.5, bL*0.6, 0.5, mColL, 0.5);
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(3+bL*0.2, 0, bL*0.6, 0.5, aCol, 0.35);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(3+bL*0.1, 0, bL*0.8, 0.5, aCol, 0.3);
                if (bd[2] === 'seam_rings') { r(3+bL*0.3, 0, 0.5, bW+1, aCol, 0.2); r(3+bL*0.6, 0, 0.5, bW+1, aCol, 0.2); }
                if (bd[2] === 'tape' || bd[2] === 'mixed') r(3+bL*0.3, 0, 1, bW, scTape, 0.4);
                if (bd[2] === 'rust') r(3+bL*0.5, 0, 1, bW*0.6, scRust, 0.3);
                
                // Stock — base 4w × 2.5h, at x-6
                if (sd[2] !== 'none') {
                    const sW = 4 * sd[0], sH = 2.5 * sd[1];
                    const sCol = (sd[2]==='wrap'||sd[2]==='carved'||sd[2]==='solid'||sd[2]==='plank') ? wCol : mCol;
                    r(-4 - sW/2, 0.5, sW, sH, sCol);
                    r(-4 - sW, 0.5, 1.5, sH + 0.5, bColD); // buttpad
                    if (sd[2] === 'wire' || sd[2] === 'skel') { r(-4-sW/2, 0.5, sW, 0.5, mCol); r(-4-sW, 0.5, 0.5, sH, mCol); }
                    if (sd[2] === 'wrap') r(-4-sW*0.4, 0.5, sW*0.4, sH*0.8, scTape, 0.3);
                    if (sd[2] === 'float') { r(-5.5, 0.5, sW*0.7, sH*0.7, mCol); } // gap between receiver and stock
                    if (sd[2] === 'seamless') r(-4-sW/2, 0.5, sW, sH, bCol); // same color as receiver
                    if (sd[2] === 'contour') r(-4-sW*0.3, 0, 1, sH+1, bColD, 0.2); // grip cutout hint
                    if (sd[2] === 'carved') r(-4-sW*0.5, 0.5, 0.5, sH*0.5, aCol, 0.25); // notch marks
                    if (sd[2] === 'scrap') r(-4-sW*0.3, 0.5, sW*0.5, sH, bColD, 0.3);
                    if (sd[2] === 'organic') { c(-4-sW/2, 0.5, sH*0.6, mCol, 0.5); }
                }
                
                // Magazine — base 2w × 3.5h, at x-1, below receiver
                const mgW = 2 * md[0], mgH = 3.5 * md[1];
                if (md[2] === 'top') { r(-1, -3, mgW, mgH*0.6, mCol); } // hopper: above receiver
                else {
                    r(-1, 2.5, mgW, mgH, mCol);
                    r(-1, 2.5, mgW*0.75, mgH*0.8, bColD, 0.3); // shadow
                }
                if (md[2] === 'round') c(-1, 2.5 + mgH/2, mgW*0.4, mColL, 0.3);
                if (md[2] === 'tape') r(-1, 2.5 + mgH*0.3, mgW, 1, scTape, 0.4);
                if (md[2] === 'crystal') { r(-1, 2.5, mgW, mgH, bColD); r(-1, 2.5+mgH*0.3, mgW*0.6, mgH*0.4, aCol, 0.25); }
                if (md[2] === 'phase') { r(-1, 2.5, mgW, mgH, bColD); r(-1, 2.5, mgW*0.5, mgH*0.6, aCol, 0.15); }
                if (md[2] === 'sphere') c(-1, 3.5, mgW*0.5, aCol, 0.3);
                if (md[2] === 'exposed') { r(-1, 2.5, mgW, mgH, aCol, 0.15); r(-1, 3, 0.5, mgH*0.5, aCol, 0.4); }
                if (md[2] === 'scrap') r(-1, 2.5+mgH*0.2, 1, mgH*0.5, scTape, 0.35);
                
                // Muzzle device — at barrel tip
                const mzX = 3 + bL + 0.5;
                const mzS = 2 * zd[0];
                if (zd[1] === 'can') r(mzX + mzS/2, 0, mzS, bW + 0.5, mColL, 0.9); // suppressor
                else if (zd[1] === 'vent') { r(mzX, 0, mzS*0.6, bW+0.5, mCol); r(mzX, -bW*0.6, mzS*0.4, 0.5, mColL, 0.5); }
                else if (zd[1] === 'cage') r(mzX, 0, mzS*0.5, bW+0.5, mColL, 0.6);
                else if (zd[1] === 'coil') { r(mzX, 0, mzS*0.6, bW+1, aCol, 0.3); r(mzX-0.5, 0, 0.5, bW+1.5, aCol, 0.2); r(mzX+0.5, 0, 0.5, bW+1.5, aCol, 0.2); }
                else if (zd[1] === 'nozzle') r(mzX, 0, mzS*0.6, bW+1, mCol);
                else if (zd[1] === 'flare') r(mzX, 0, mzS*0.4, bW+1.5, mCol);
                else if (zd[1] === 'weld') r(mzX, 0, mzS*0.5, bW+0.5, mCol, 0.7);
                else if (zd[1] === 'scrap') r(mzX, 0, mzS*0.4, bW+0.5, scTape, 0.5);
                else if (zd[1] === 'lens') { c(mzX, 0, mzS*0.4, aCol, 0.4); c(mzX, 0, mzS*0.2, mColL, 0.3); }
                else if (zd[1] === 'iris') { c(mzX, 0, mzS*0.5, mCol); c(mzX, 0, mzS*0.25, aCol, 0.5); }
                else if (zd[1] === 'multi') { r(mzX-0.5, -1, 0.5, 0.5, aCol, 0.4); r(mzX+0.5, -1, 0.5, 0.5, aCol, 0.4); r(mzX, 1, 0.5, 0.5, aCol, 0.4); }
                else if (zd[1] === 'prism') r(mzX, 0, mzS*0.4, mzS*0.5, aCol, 0.35);
                else if (zd[1] === 'ring') { c(mzX+0.5, 0, mzS*0.5, aCol, 0.2); c(mzX+0.5, 0, mzS*0.3, bColD, 0.8); }
                else if (zd[1] === 'fracture') { r(mzX, -0.5, mzS*0.3, bW+1, aCol, 0.3); r(mzX+0.5, 0.5, mzS*0.2, bW*0.5, aCol, 0.4); }
                else if (zd[1] === 'harmonic') { c(mzX, 0, mzS*0.4, aCol, 0.15); c(mzX+1, 0, mzS*0.35, aCol, 0.12); }
                // raw/open/crown/port — just the barrel end, minimal
                
                // Foundry accent marks
                if (!isScrap && !isEnergy) {
                    r(-1, -1.5, 1, 0.5, aCol, 0.5);
                    r(2, 1, 0.5, 1, dCol, 0.4);
                }
                if (isEnergy) {
                    r(0, -0.5, 0.5, 2, aCol, 0.15); // receiver seam glow
                }
                
            } else if (sprite === 'mini') {
                // Receiver
                r(0, 0, 7, 2.5, bCol);
                r(1, -1.5, 4, 1, bColD);              // top rail
                
                // Barrel — base 3 long, 1.5 wide
                const bL = 3 * bd[0], bW = 1.5 * bd[1];
                r(4 + bL/2, 0, bL, bW, mCol);
                r(4 + bL, 0, 0.5, bW*0.75, mColL);
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(4+bL*0.2, 0, bL*0.6, 0.5, aCol, 0.3);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(4+bL*0.1, 0, bL*0.8, 0.5, aCol, 0.25);
                if (bd[2] === 'tape') r(4+bL*0.3, 0, 0.5, bW, scTape, 0.4);
                if (bd[2] === 'bore') r(4+bL/2, 0, bL, bW*1.2, mCol);
                
                // Grip — always present on SMG
                r(-1, 2.5, 2.5, 4, wCol);
                r(-1, 2, 2, 1, bColD);
                
                // Stock — base 2w wire, at x-4
                if (sd[2] !== 'none') {
                    const sW = 2 * sd[0];
                    if (sd[2] === 'wire' || sd[2] === 'skel') { r(-4, 0, sW, 0.5, mCol); r(-4-sW*0.3, -0.5, 0.5, 2, mCol); }
                    else if (sd[2] === 'float') { r(-5, 0, sW*0.7, 1.5, mCol); }
                    else { r(-4, 0, sW, 2, sd[2]==='wrap'||sd[2]==='carved' ? wCol : mCol); }
                    if (sd[2] === 'wrap') r(-4, 0, sW*0.5, 1.5, scTape, 0.3);
                }
                
                // Magazine — base 1.5w × 3h, below grip
                const mgW = 1.5 * md[0], mgH = 3 * md[1];
                r(-1, 4, mgW, mgH, mCol);
                r(-1, 4+mgH*0.3, mgW*0.7, mgH*0.5, bColD, 0.3);
                if (md[2] === 'round') c(-1, 4+mgH/2, mgW*0.4, mColL, 0.3);
                if (md[2] === 'tape') r(-1, 4+mgH*0.4, mgW+0.5, 0.5, scTape, 0.4);
                if (md[2] === 'crystal') r(-1, 4+mgH*0.3, mgW*0.5, mgH*0.3, aCol, 0.25);
                if (md[2] === 'phase') r(-1, 4, mgW*0.4, mgH*0.5, aCol, 0.15);
                
                // Muzzle — at barrel tip
                const mzX = 4 + bL + 0.5;
                const mzS = 1.5 * zd[0];
                if (zd[1] === 'can') r(mzX + mzS/2, 0, mzS, bW + 0.5, mColL, 0.9);
                else if (zd[1] === 'coil') { r(mzX, 0, mzS*0.5, bW+1, aCol, 0.25); }
                else if (zd[1] === 'lens' || zd[1] === 'iris') c(mzX, 0, mzS*0.35, aCol, 0.35);
                else if (zd[1] === 'ring') c(mzX+0.3, 0, mzS*0.4, aCol, 0.2);
                else if (zd[1] !== 'raw' && zd[1] !== 'open') r(mzX, 0, mzS*0.5, bW+0.3, mColL, 0.6);
                
                if (!isScrap && !isEnergy) r(0, -1, 0.5, 0.5, aCol, 0.5);
                if (isEnergy) r(0, -0.5, 0.5, 1.5, aCol, 0.12);
                
            } else if (sprite === 'heavy_rifle') {
                // Thick receiver
                r(-1, 0, 9, 3.5, bCol);
                r(-1, 0, 8, 3, bColL);
                r(1, -2.5, 5, 1.5, bColD);            // carry handle
                r(0, -2.5, 1, 2, mCol);               // handle post
                
                // Barrel — base 5 long, 2.5 wide
                const bL = 5 * bd[0], bW = 2.5 * bd[1];
                r(5 + bL/2, 0, bL, bW, mCol);
                r(5 + bL, 0, 1.5, bW*0.8, mColL);
                r(5 + bL, -0.5, 0.5, 1, 0xffffff, 0.15); // heat
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(5+bL*0.2, 0, bL*0.6, 0.5, aCol, 0.3);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(5+bL*0.1, 0, bL*0.8, 0.5, aCol, 0.25);
                if (bd[2] === 'tape') r(5+bL*0.3, 0, 1, bW, scTape, 0.35);
                
                // Bipod (always on heavy)
                r(5, 2, 0.5, 2.5, mCol, 0.6);
                r(3.5, 2, 0.5, 2, mCol, 0.6);
                
                // Stock — base 4w × 3.5h
                if (sd[2] !== 'none') {
                    const sW = 4 * sd[0], sH = 3.5 * sd[1];
                    const sCol = (sd[2]==='wrap'||sd[2]==='carved'||sd[2]==='solid'||sd[2]==='plank') ? wCol : mCol;
                    r(-6, 0, sW, sH, sCol);
                    r(-7.5, 0, 1.5, sH + 0.5, bColD);
                    if (sd[2] === 'wire' || sd[2] === 'skel') { r(-6, 0, sW, 0.5, mCol); r(-7.5, 0, 0.5, sH, mCol); }
                    if (sd[2] === 'wrap') r(-6-sW*0.3, 0, sW*0.4, sH*0.7, scTape, 0.3);
                    if (sd[2] === 'seamless') r(-6, 0, sW, sH, bCol);
                    if (sd[2] === 'float') r(-7, 0, sW*0.6, sH*0.6, mCol);
                }
                
                // Magazine — base 4w × 3h, BOX style (LMG)
                const mgW = 4 * md[0], mgH = 3 * md[1];
                if (md[2] === 'top') { r(-1, -4, mgW, mgH*0.7, mCol); }
                else {
                    r(-1, 3, mgW, mgH, bColD);
                    r(-1, 3.5, mgW*0.9, mgH*0.8, mCol);
                }
                if (md[2] === 'round') c(-1, 3+mgH/2, mgW*0.35, mColL, 0.3);
                if (md[2] === 'tape') r(-1, 3+mgH*0.4, mgW, 0.5, scTape, 0.4);
                if (md[2] === 'crystal') { r(-1, 3, mgW, mgH, bColD); r(-1, 3+mgH*0.25, mgW*0.5, mgH*0.5, aCol, 0.2); }
                if (md[2] === 'phase') r(-1, 3, mgW*0.4, mgH*0.5, aCol, 0.12);
                
                // Muzzle
                const mzX = 5 + bL + 0.5;
                const mzS = 2 * zd[0];
                if (zd[1] === 'can') r(mzX + mzS/2, 0, mzS, bW+0.5, mColL, 0.9);
                else if (zd[1] === 'vent') { r(mzX, 0, mzS*0.5, bW+1, mCol); r(mzX, -bW*0.5, mzS*0.3, 0.5, mColL, 0.4); }
                else if (zd[1] === 'cage') r(mzX, 0, mzS*0.5, bW+1, mColL, 0.5);
                else if (zd[1] === 'coil') { r(mzX, 0, mzS*0.5, bW+1.5, aCol, 0.25); }
                else if (zd[1] === 'nozzle' || zd[1] === 'flare') r(mzX, 0, mzS*0.5, bW+1.5, mCol);
                else if (zd[1] === 'lens' || zd[1] === 'iris') c(mzX, 0, mzS*0.4, aCol, 0.35);
                else if (zd[1] === 'ring') c(mzX+0.3, 0, mzS*0.45, aCol, 0.2);
                else if (zd[1] !== 'raw' && zd[1] !== 'open') r(mzX, 0, mzS*0.4, bW+0.5, mColL, 0.5);
                
                if (!isScrap && !isEnergy) { r(-1, -2, 2, 0.5, aCol, 0.4); r(-3, 1, 0.5, 1, aCol, 0.3); }
                if (isEnergy) r(0, -0.5, 0.5, 2.5, aCol, 0.12);
                
            } else if (sprite === 'handcannon') {
                // Frame body
                r(0, 0, 7, 3, bCol);
                r(1, -1.5, 5, 1.5, bColD);            // top strap
                r(2, -2, 2, 0.5, mColL, 0.4);         // rear sight
                // Cylinder
                r(1, 0, 2.5, 3.5, mCol);
                c(1.5, 0, 1.5, mColL, 0.5);
                c(1.5, 0, 0.5, bColD, 0.4);
                // Hammer
                r(-0.5, -2.5, 1, 1.5, mCol);
                r(-0.5, -3, 1.5, 0.5, mColL);
                // Trigger guard
                r(0, 2, 1.5, 1.5, mCol, 0.5);
                
                // Barrel — base 3 long, 2 wide
                const bL = 3 * bd[0], bW = 2 * bd[1];
                r(3.5 + bL/2, -0.5, bL, bW, mCol);
                r(3.5 + bL, -0.5, 1, bW*0.75, mColL);
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(3.5+bL*0.2, -0.5, bL*0.6, 0.5, aCol, 0.3);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(3.5+bL*0.1, -0.5, bL*0.8, 0.5, aCol, 0.25);
                if (bd[2] === 'tape') r(3.5+bL*0.4, -0.5, 0.5, bW, scTape, 0.4);
                
                // Grip — always present, angled
                r(-2, 2, 2.5, 4, wCol);
                r(-2, 1.5, 2, 1, bCol);
                r(-2, 5.5, 2.5, 1, mCol);
                if (sd[2] === 'wrap') r(-2, 3, 2, 2, scTape, 0.3);
                if (sd[2] === 'carved') r(-2, 3.5, 0.5, 1.5, aCol, 0.2);
                if (sd[2] === 'seamless') r(-2, 2, 2.5, 4, bCol);
                if (sd[2] === 'organic') r(-2, 2, 2.5, 4, mCol, 0.8);
                
                // No separate stock on handcannons — grip IS the stock
                
                // Magazine (cylinder is already drawn — this is for energy/anomalous variants)
                if (md[2] === 'crystal') { r(-1, 3, 1.5, 1, bColD); r(-1, 3, 1, 0.5, aCol, 0.3); }
                if (md[2] === 'phase') r(1.5, 0, 2.5, 3.5, aCol, 0.08); // overlay on cylinder
                if (md[2] === 'exposed') { c(1.5, 0, 1.8, aCol, 0.15); }
                
                // Muzzle
                const mzX = 3.5 + bL + 0.5;
                const mzS = 1.5 * zd[0];
                if (zd[1] === 'can') r(mzX + mzS/2, -0.5, mzS, bW+0.5, mColL, 0.9);
                else if (zd[1] === 'vent') r(mzX, -0.5, mzS*0.5, bW+0.5, mCol);
                else if (zd[1] === 'lens' || zd[1] === 'iris') c(mzX, -0.5, mzS*0.35, aCol, 0.4);
                else if (zd[1] === 'ring') c(mzX+0.3, -0.5, mzS*0.4, aCol, 0.2);
                else if (zd[1] === 'fracture') { r(mzX, -1, mzS*0.3, bW+1, aCol, 0.3); }
                else if (zd[1] !== 'raw' && zd[1] !== 'open' && zd[1] !== 'crown') r(mzX, -0.5, mzS*0.4, bW+0.3, mColL, 0.5);
                
                if (!isScrap && !isEnergy) { r(-2, 3, 0.5, 2, aCol, 0.35); }
                if (isEnergy) r(0, -0.5, 0.5, 2, aCol, 0.12);
                
            } else if (sprite === 'sniper') {
                // Receiver
                r(-1, 0, 7, 2.5, bCol);
                // Bolt handle
                r(1, 1.5, 1, 2, mCol);
                r(1.5, 2, 1.5, 0.5, mColL);
                // Trigger guard
                r(-1, 1.5, 1.5, 1, mCol, 0.6);
                
                // Scope (defining feature)
                r(2, -3, 5, 2, bColD);
                r(2, -3, 4.5, 1.5, mColL);
                r(-0.5, -3, 1, 1.5, mCol, 0.6);      // ring
                r(5, -3, 1, 1.5, mCol, 0.6);          // ring
                r(4, -3, 1, 1, aCol, 0.5);            // lens
                
                // Barrel — base 7 long, 1.5 wide, starts x+3
                const bL = 7 * bd[0], bW = 1.5 * bd[1];
                r(3 + bL*0.4, 0, bL, bW, mCol);       // main barrel
                r(3 + bL*0.7, 0, bL*0.4, bW*0.7, mColL); // thin section
                if (bd[2] === 'fluted') { for (let f=0;f<4;f++) r(3+bL*0.2+f*bL*0.18, 0, 0.5, bW*0.6, bColD, 0.2); }
                if (bd[2] === 'rail') r(3+bL*0.15, -bW/2-0.5, bL*0.5, 0.5, mColL, 0.4);
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(3+bL*0.1, 0, bL*0.8, 0.5, aCol, 0.3);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(3+bL*0.1, 0, bL*0.8, 0.5, aCol, 0.25);
                if (bd[2] === 'seam_rings') { r(3+bL*0.3, 0, 0.5, bW+1, aCol, 0.15); r(3+bL*0.6, 0, 0.5, bW+1, aCol, 0.15); }
                if (bd[2] === 'tape') r(3+bL*0.3, 0, 1, bW, scTape, 0.35);
                if (bd[2] === 'rust') r(3+bL*0.5, 0, 1, bW*0.5, scRust, 0.25);
                
                // Stock — base 3w × 2h
                if (sd[2] !== 'none') {
                    const sW = 3 * sd[0], sH = 2 * sd[1];
                    const sCol = (sd[2]==='wrap'||sd[2]==='carved'||sd[2]==='solid'||sd[2]==='plank') ? wCol : mCol;
                    r(-5, 0.5, sW, sH, sCol);
                    r(-7, 0.5, 2, sH + 0.5, bColD);   // buttstock
                    r(-6, 2, 1.5, 1, mCol);            // cheek rest
                    if (sd[2] === 'wire' || sd[2] === 'skel') { r(-5, 0.5, sW, 0.5, mCol); r(-7, 0.5, 0.5, sH, mCol); }
                    if (sd[2] === 'wrap') r(-5-sW*0.3, 0.5, sW*0.4, sH*0.7, scTape, 0.3);
                    if (sd[2] === 'seamless') r(-5, 0.5, sW, sH, bCol);
                    if (sd[2] === 'float') r(-6, 0.5, sW*0.6, sH*0.6, mCol);
                    if (sd[2] === 'carved') r(-5-sW*0.4, 0.5, 0.5, sH*0.5, aCol, 0.2);
                }
                
                // Magazine — base 2w × 2h, flush
                const mgW = 2 * md[0], mgH = 2 * md[1];
                r(0, 2.5, mgW, mgH, bColD);
                if (md[2] === 'round') c(0, 2.5+mgH/2, mgW*0.35, mColL, 0.3);
                if (md[2] === 'tape') r(0, 2.5+mgH*0.4, mgW, 0.5, scTape, 0.4);
                if (md[2] === 'crystal') r(0, 2.5+mgH*0.25, mgW*0.5, mgH*0.4, aCol, 0.25);
                if (md[2] === 'phase') r(0, 2.5, mgW*0.4, mgH*0.5, aCol, 0.12);
                
                // Muzzle — at barrel tip
                const mzX = 3 + bL + 0.5;
                const mzS = 2 * zd[0];
                if (zd[1] === 'can') r(mzX + mzS/2, 0, mzS, bW+1, mColL, 0.9);
                else if (zd[1] === 'vent') { r(mzX, 0, mzS*0.5, bW+1, mCol); }
                else if (zd[1] === 'coil') { r(mzX, 0, mzS*0.5, bW+1.5, aCol, 0.2); r(mzX-0.3, 0, 0.5, bW+2, aCol, 0.15); }
                else if (zd[1] === 'lens' || zd[1] === 'iris') c(mzX, 0, mzS*0.4, aCol, 0.35);
                else if (zd[1] === 'ring') c(mzX+0.3, 0, mzS*0.45, aCol, 0.2);
                else if (zd[1] === 'fracture') { r(mzX, -0.5, mzS*0.3, bW+1.5, aCol, 0.25); }
                else if (zd[1] === 'harmonic') { c(mzX, 0, mzS*0.4, aCol, 0.12); c(mzX+1, 0, mzS*0.35, aCol, 0.1); }
                else if (zd[1] !== 'raw' && zd[1] !== 'open' && zd[1] !== 'crown') r(mzX, 0, mzS*0.4, bW+0.5, mColL, 0.5);
                
                if (!isScrap && !isEnergy) { r(2, -1, 0.5, 0.5, aCol, 0.4); r(-5, 1, 1.5, 0.5, aCol, 0.3); }
                if (isEnergy) r(0, -0.5, 0.5, 2, aCol, 0.1);
            }
        } else if (cat === 'melee') {
            // === MELEE FOUNDRY PALETTE ===
            const foundry = item.foundry ? CONFIG.foundries[item.foundry] : null;
            const p = foundry ? foundry.palette : null;
            const isScrap = !foundry;
            const isEnergy = foundry && (item.foundry === 'blackreach' || item.foundry === 'cephalon');
            const mBCol  = p ? parseInt(p.body.replace('#',''),16)      : 0x5a5248;
            const mACol  = p ? parseInt(p.accent.replace('#',''),16)    : 0x888888;
            const mMCol  = p ? parseInt(p.metal.replace('#',''),16)     : 0x6a6a6a;
            const mMColL = p ? parseInt(p.metalLight.replace('#',''),16): 0x8a8a8a;
            const mDCol  = p ? parseInt(p.detail.replace('#',''),16)    : 0x4a4a4a;
            const mWood  = isScrap ? 0x5a4228 : (isEnergy ? mBCol : 0x6a4a2a);
            
            const mpc = item.partConfig || { handle: 'wood', head: 'rusty', guard: 'none' };
            
            // Melee seed variation — ±8% per-instance micro-offsets (matches weapon system)
            const _mhV = 1 + _sOff(10) * 0.08; // handle length
            const _mhwV = 1 + _sOff(11) * 0.06; // handle width  
            const _mhdV = 1 + _sOff(12) * 0.07; // head size (width & height)
            const _mgV = 1 + _sOff(13) * 0.05;  // guard width
            
            // Handle style flags
            const hIsWrap = ['wrapped','cord','tape'].includes(mpc.handle);
            const hIsOrganic = ['bone','tendril','organic'].includes(mpc.handle);
            const hIsCrystal = ['crystal','slim_crystal'].includes(mpc.handle);
            const hIsMetal = ['pipe','rebar','machined','contoured','engraved','polymer','rubber'].includes(mpc.handle);
            const hIsCarved = mpc.handle === 'carved'; // Sworn — carved wood with notch marks
            const hCol = hIsOrganic ? 0x8a7a6a : hIsCrystal ? mACol : hIsMetal ? mMCol : mWood;
            
            // Head style flags
            const headGlow = ['energy_edge','focused_edge','harmonic','overcharged','phase_edge','fold','void_edge','leech'].includes(mpc.head);
            const headPrecision = ['alloy','steel','tempered','hardened','filed'].includes(mpc.head);
            const headHCol = headGlow ? mACol : headPrecision ? mMColL : mMColL;
            
            if (sprite === 'blade') {
                // === BLADE — vertical orientation ===
                // Blade body — precision heads get polished metal color
                const bLen = (headGlow ? 9 : 8) * _mhdV;
                const bladeCol = headGlow ? mACol : headPrecision ? mMColL : 0xbbbbbb;
                r(0, -3, 2 * _mhwV, bLen, bladeCol);
                // Tip
                if (headGlow) {
                    r(0, -3 - bLen/2 + 1, 1.5, 2, mACol, 0.7); // energy tip glow
                    r(0, -3 - bLen/2, 1, 1.5, 0xffffff, 0.3);
                } else if (['serrated','saw_disc'].includes(mpc.head)) {
                    for (let t = 0; t < 4; t++) r(1.5, -6 + t * 1.5, 0.5, 0.5, mMColL, 0.7); // teeth
                    r(0, -6.5, 1.5, 2, 0xdddddd);
                } else if (mpc.head === 'sharpened') {
                    r(0, -7, 1, 2.5, 0xdddddd);
                } else if (mpc.head === 'filed') {
                    r(0, -6.5, 1.5, 2, 0xdddddd);
                    for (let f = 0; f < 3; f++) r(0.8, -5 + f * 2, 0.5, 0.8, mMCol, 0.3); // file marks
                } else if (mpc.head === 'tempered' || mpc.head === 'hardened') {
                    r(0, -6.5, 1.5, 2, 0xeeeeff); // blue-white tempered tip
                    r(0.5, -4, 0.5, bLen * 0.4, mACol, 0.12); // heat-treat gradient
                } else {
                    r(0, -6.5, 1.5, 2, 0xdddddd); // standard tip
                }
                // Edge highlight
                if (!headGlow) r(0.8, -3, 0.5, bLen * 0.7, 0xdddddd, 0.4);
                if (headPrecision && !['filed'].includes(mpc.head)) r(-0.8, -3, 0.3, bLen * 0.5, 0xffffff, 0.15); // double-edge polish
                
                // Guard
                if (mpc.guard === 'crossbar' || mpc.guard === 'full') {
                    r(0, 1, 4 * _mgV, 1.5, mMCol);
                    if (mpc.guard === 'full') r(0, 1.5, 3 * _mgV, 1, mMColL, 0.3);
                } else if (mpc.guard === 'swept' || mpc.guard === 'rapier' || mpc.guard === 'ornate') {
                    r(0, 1, 3.5 * _mgV, 1, mMCol); r(1.5, 1, 0.5, 2, mMCol, 0.6);
                    if (mpc.guard === 'ornate') r(0, 0.5, 1, 0.5, mACol, 0.4);
                } else if (mpc.guard === 'knuckle') {
                    r(0, 1, 4 * _mgV, 1.5, mMCol); r(0, 2, 3.5 * _mgV, 1, mMCol, 0.5);
                } else if (mpc.guard === 'plate') {
                    r(0, 1, 3 * _mgV, 2, mMCol);
                } else if (mpc.guard === 'cage') {
                    r(0, 1, 3.5 * _mgV, 1, mMCol); r(1.5, 2, 0.5, 2, mMCol, 0.5); r(-1.5, 2, 0.5, 2, mMCol, 0.5);
                } else if (mpc.guard === 'flange') {
                    r(0, 1, 4.5 * _mgV, 1, mMCol); r(0, 1.5, 3 * _mgV, 0.5, mDCol, 0.4);
                } else if (mpc.guard === 'scrap') {
                    r(0, 1, 3.5 * _mgV, 1.5, mMCol); r(1, 0.5, 0.5, 1, 0x8a8a6a, 0.4);
                } else if (mpc.guard === 'emitter' || mpc.guard === 'prism' || mpc.guard === 'arc') {
                    r(0, 1, 3 * _mgV, 1, mBCol); r(0, 1, 2 * _mgV, 0.5, mACol, 0.3);
                } else if (mpc.guard === 'ring' || mpc.guard === 'orbit') {
                    c(0, 1, 2 * _mgV, mACol, 0.2); r(0, 1, 2.5 * _mgV, 0.5, mBCol);
                } else if (mpc.guard === 'bolted') {
                    r(0, 1, 3.5 * _mgV, 1, mMCol); r(1.2, 1, 0.5, 0.5, 0xaaaaaa, 0.5);
                } else if (mpc.guard === 'tape') {
                    r(0, 1, 3 * _mgV, 1, 0x8a8a6a, 0.5);
                } else if (mpc.guard === 'spine') {
                    r(0, 1, 3 * _mgV, 1, mBCol); r(1, 0.5, 0.5, 1, mACol, 0.4); r(-1, 0.5, 0.5, 1, mACol, 0.4);
                } else if (mpc.guard !== 'none') {
                    r(0, 1, 3 * _mgV, 1.5, darkM);
                }
                
                // Handle
                r(0, 3.5, 2.5 * _mhwV, 4 * _mhV, hCol);
                if (hIsWrap) r(0, 3.5, 2 * _mhwV, 3 * _mhV, 0x8a8a6a, 0.4);
                if (hIsCrystal) r(0, 3.5, 1.5 * _mhwV, 3 * _mhV, mACol, 0.15);
                if (hIsOrganic) { r(0.5, 3, 0.5, 3.5 * _mhV, mACol, 0.15); r(-0.5, 4, 0.5, 2 * _mhV, mACol, 0.1); }
                if (hIsCarved) { r(0.5, 2.5, 0.5, 1, mDCol, 0.3); r(-0.5, 4.5, 0.5, 1, mDCol, 0.3); } // carved notches
                if (mpc.handle === 'engraved') r(0, 3.5, 0.5, 3 * _mhV, mACol, 0.2);
                // Pommel
                r(0, 6, 3 * _mhwV, 1.5, hIsCrystal ? mACol : mMCol);
                if (isEnergy) r(0, 6, 2 * _mhwV, 1, mACol, 0.2);
                
            } else if (sprite === 'blunt') {
                // === BLUNT — club/mace ===
                // Handle
                r(0, 0, 2.5 * _mhwV, 12 * _mhV, hCol);
                if (hIsWrap) r(0, 2, 2 * _mhwV, 5 * _mhV, 0x8a8a6a, 0.4);
                if (hIsCrystal) r(0, 0, 1.5 * _mhwV, 10 * _mhV, mACol, 0.12);
                if (hIsOrganic) r(0.3, -1, 0.5, 8 * _mhV, mACol, 0.12);
                if (hIsCarved) { r(0.5, 1, 0.5, 1, mDCol, 0.3); r(-0.5, 3, 0.5, 1, mDCol, 0.3); }
                if (mpc.handle === 'rebar') { r(0.8, 0, 0.5, 10 * _mhV, mMCol, 0.3); }
                
                // Head
                if (['piston','counterweight'].includes(mpc.head)) {
                    r(0, -5, 5 * _mhdV, 4.5 * _mhdV, mMCol);
                    r(0, -6, 4 * _mhdV, 1.5, mMColL);
                    if (mpc.head === 'piston') r(0, -4.5, 1.5, 3 * _mhdV, mDCol, 0.4);
                } else if (mpc.head === 'saw_disc') {
                    c(0, -5, 2.5, mMCol); c(0, -5, 1.5, mMColL, 0.6);
                    for (let t = 0; t < 6; t++) { const a = t * Math.PI/3; r(Math.cos(a)*2, -5+Math.sin(a)*2, 0.5, 0.5, mMColL, 0.6); }
                } else if (headGlow) {
                    r(0, -5, 4 * _mhdV, 4 * _mhdV, mBCol);
                    r(0, -5, 3 * _mhdV, 3 * _mhdV, mACol, 0.25);      // energy core
                    r(0, -6, 2.5 * _mhdV, 1, mACol, 0.4);     // glow top
                } else if (headPrecision) {
                    r(0, -5, 4 * _mhdV, 4 * _mhdV, mMCol);             // precision forged head
                    r(0, -6, 3 * _mhdV, 1.5, mMColL);          // polished cap
                    if (mpc.head === 'tempered' || mpc.head === 'hardened') r(0, -5, 3 * _mhdV, 3 * _mhdV, mACol, 0.08);
                    if (mpc.head === 'filed') { r(1.5, -5, 0.5, 1, mDCol, 0.25); r(-1.5, -5, 0.5, 1, mDCol, 0.25); }
                } else {
                    r(0, -5, 4 * _mhdV, 4 * _mhdV, darkM);
                    r(0, -6, 3 * _mhdV, 1.5, headHCol);       // top cap
                }
                if (mpc.head === 'bolted') r(1.5, -5, 0.5, 0.5, 0xaaaaaa, 0.5);
                
            } else {
                // === HEAVY — axe/hammer ===
                // Handle
                r(0, 1, 2.5 * _mhwV, 10 * _mhV, hCol);
                if (hIsWrap) r(0, 3, 2 * _mhwV, 4 * _mhV, 0x8a8a6a, 0.4);
                if (hIsCrystal) r(0, 1, 1.5 * _mhwV, 8 * _mhV, mACol, 0.12);
                if (hIsOrganic) r(0.3, 0, 0.5, 8 * _mhV, mACol, 0.1);
                if (hIsCarved) { r(0.5, 0, 0.5, 1, mDCol, 0.3); r(-0.5, 3, 0.5, 1, mDCol, 0.3); }
                if (mpc.handle === 'rebar') r(0.8, 1, 0.5, 8 * _mhV, mMCol, 0.3);
                
                // Head
                if (['counterweight','cast_iron','tungsten'].includes(mpc.head)) {
                    r(0, -4, 7 * _mhdV, 4.5 * _mhdV, mMCol);
                    r(3.5 * _mhdV, -4, 2 * _mhdV, 3.5 * _mhdV, mDCol);
                    r(-1, -5.5, 3 * _mhdV, 1.5, mMColL);
                } else if (mpc.head === 'saw_disc') {
                    c(0, -4, 3 * _mhdV, mMCol); c(0, -4, 2 * _mhdV, mMColL, 0.5);
                    for (let t = 0; t < 8; t++) { const a = t * Math.PI/4; r(Math.cos(a)*2.5*_mhdV, -4+Math.sin(a)*2.5*_mhdV, 0.5, 0.5, mMColL, 0.5); }
                } else if (['chopper','scavenged','sharpened'].includes(mpc.head)) {
                    r(0, -4, 6 * _mhdV, 4 * _mhdV, mMCol);
                    r(3 * _mhdV, -4, 2 * _mhdV, 3 * _mhdV, mDCol);
                    r(-1, -5, 2 * _mhdV, 1.5, mMColL);
                } else if (headGlow) {
                    r(0, -4, 6 * _mhdV, 4 * _mhdV, mBCol);
                    r(3 * _mhdV, -4, 2 * _mhdV, 3.5 * _mhdV, mACol, 0.3);
                    r(-1, -5, 2 * _mhdV, 1.5, mACol, 0.2);
                    r(0, -4, 5 * _mhdV, 3 * _mhdV, mACol, 0.08);
                } else if (headPrecision) {
                    r(0, -4, 6 * _mhdV, 4 * _mhdV, mMCol);
                    r(3 * _mhdV, -4, 2 * _mhdV, 3 * _mhdV, mMColL);
                    r(-1, -5, 2 * _mhdV, 1.5, mMColL);
                    if (mpc.head === 'tempered' || mpc.head === 'hardened') r(2, -4, 3 * _mhdV, 2.5 * _mhdV, mACol, 0.08);
                    if (mpc.head === 'filed') { r(3, -3, 0.5, 1, mDCol, 0.25); r(3, -5, 0.5, 1, mDCol, 0.25); }
                } else {
                    r(0, -4, 6 * _mhdV, 4 * _mhdV, mMCol);
                    r(3 * _mhdV, -4, 2 * _mhdV, 3 * _mhdV, darkM);
                    r(-1, -5, 2 * _mhdV, 1.5, 0xaaaaaa);
                }
            }
            
            // Foundry accent (non-scrap)
            if (!isScrap && !isEnergy) {
                if (sprite === 'blade') r(0, 0.5, 0.5, 1, mACol, 0.35);
                else r(0, -4, 0.5, 1, mACol, 0.3);
            }
        } else if (cat === 'gear') {
            const outfit = item.outfit || (base.outfit || null);
            const shirtHex = outfit ? (typeof outfit.shirt === 'string' ? outfit.shirt : (outfit.shirt && outfit.shirt.base) || '#5a5a5a') : '#5a5a5a';
            const gC = parseInt(shirtHex.replace('#', ''), 16) || 0x5a6a5a;
            const gCL = gC + 0x111111; // lighter shade
            const gCD = Math.max(0, gC - 0x111111); // darker shade
            const gc = item.gearClass || 'scrap';
            const gP = item.foundryPalette || (item.foundry && CONFIG.foundries[item.foundry] ? CONFIG.foundries[item.foundry].palette : null);
            const aCol = gP ? parseInt(gP.accent.replace('#',''), 16) : 0;
            
            if (gc === 'heavy') {
                // Heavy plate — thick torso, shoulder pads, belt, straps
                r(0, 0, 10, 12, gCD);                     // back plate shadow
                r(0, -0.5, 9, 11, gC);                    // front plate body
                r(0, -1, 7, 8, gCL);                      // center plate highlight
                r(0, -5, 6, 2.5, gCD);                    // collar ridge
                r(0, -5.5, 4, 1.5, gC);                   // collar inner
                // Shoulder pads
                r(-5.5, -3, 3, 4, gC);                    // left pad
                r(-5.5, -3.5, 2.5, 3, gCL);               // left pad highlight
                r(5.5, -3, 3, 4, gC);                     // right pad
                r(5.5, -3.5, 2.5, 3, gCL);                // right pad highlight
                // Straps
                r(-3, -1, 1, 7, gCD);                     // left strap
                r(3, -1, 1, 7, gCD);                      // right strap
                // Belt
                r(0, 4.5, 9, 2, gCD);                     // belt
                r(0, 4.5, 1.5, 1.5, metal);               // buckle
                // Pouches
                r(-3.5, 3, 2, 2.5, darkM);                // left pouch
                r(3.5, 3, 2, 2.5, darkM);                 // right pouch
                // Plate rivets
                c(-2, -3, 0.5, metal, 0.5); c(2, -3, 0.5, metal, 0.5);
                c(-2, 1, 0.5, metal, 0.5); c(2, 1, 0.5, metal, 0.5);
                // Foundry accent stripe
                if (aCol) r(0, -1, 0.5, 8, aCol, 0.35);
            } else if (gc === 'medium') {
                // Medium coat — trench coat style, collar, flap, pockets
                r(0, 0, 9, 12, gC);                       // coat body
                r(0, -0.5, 8, 10, gCL);                   // front panel
                // Collar — popped
                r(-2.5, -5.5, 2, 3, gC);                  // left collar fold
                r(2.5, -5.5, 2, 3, gC);                   // right collar fold
                r(-2.5, -6, 1.5, 2, gCL);                 // left collar highlight
                r(2.5, -6, 1.5, 2, gCL);                  // right collar highlight
                // Center seam
                r(0, -1, 0.5, 9, gCD);                    // center line
                // Shoulder seams
                r(-4, -3.5, 1, 5, gCD);                   // left shoulder line
                r(4, -3.5, 1, 5, gCD);                    // right shoulder line
                // Pockets
                r(-2.5, 1, 3, 2.5, gCD);                  // left pocket
                r(-2.5, 1.5, 2.5, 0.5, gC);               // left pocket flap
                r(2.5, 1, 3, 2.5, gCD);                   // right pocket
                r(2.5, 1.5, 2.5, 0.5, gC);                // right pocket flap
                // Belt
                r(0, 4.5, 8, 1.5, gCD);                   // belt
                r(0, 4.5, 1, 1, metal);                    // buckle
                // Coat tail / bottom edge
                r(-2, 5.5, 3.5, 1.5, gC);                 // left tail
                r(2, 5.5, 3.5, 1.5, gC);                  // right tail
                r(0, 5.5, 1, 1.5, gCD);                   // tail split
                // Foundry accent
                if (aCol) { r(-2.5, 1, 0.5, 2.5, aCol, 0.3); r(2.5, 1, 0.5, 2.5, aCol, 0.3); }
            } else if (gc === 'light') {
                // Light vest — slim, minimal, tactical
                r(0, 0, 8, 10, gC);                       // vest body
                r(0, -0.5, 7, 8, gCL);                    // front
                // V-neck opening
                r(0, -4, 3, 3, darkM);                     // neck opening
                r(-1.5, -3.5, 1, 2, gCL);                 // left lapel
                r(1.5, -3.5, 1, 2, gCL);                  // right lapel
                // Arm holes
                r(-4.5, -2, 1.5, 5, gCD);                 // left arm seam
                r(4.5, -2, 1.5, 5, gCD);                  // right arm seam
                // Zipper
                r(0, 0, 0.5, 7, metal, 0.5);              // center zip
                c(0, 3, 0.5, metal, 0.7);                  // zip pull
                // Small pockets
                r(-2, 2, 2, 1.5, gCD);                    // left pocket
                r(2, 2, 2, 1.5, gCD);                     // right pocket
                // Bottom hem
                r(0, 4.5, 7, 1, gCD);                     // hem
                // Foundry accent
                if (aCol) r(0, -4, 0.5, 1.5, aCol, 0.4);
            } else {
                // Scrap — torn rags, visible stitching, patches
                r(0, 0, 7, 10, gC);                       // base fabric
                r(0, -0.5, 6, 8, gCL);                    // front
                // Ragged collar
                r(-1, -4.5, 1.5, 2, gCD);                 // left collar scrap
                r(1, -4.5, 2, 1.5, gC);                   // right collar scrap
                // Patches — mismatched colors
                r(-2, 0, 2.5, 3, gC + 0x0a0505);          // patch 1 (slightly red)
                r(2, -1, 2, 2.5, gC - 0x050505);          // patch 2 (darker)
                r(-1, 3, 3, 2, gCD + 0x050a05);           // patch 3 (slightly green)
                // Stitching lines
                r(-0.5, -2, 0.3, 5, 0x7a6a5a, 0.6);      // center stitch
                r(-3, 0, 0.3, 3, 0x7a6a5a, 0.5);         // left stitch
                r(3, -1, 0.3, 2.5, 0x7a6a5a, 0.5);       // right stitch
                // Torn edges
                r(-3.5, 3, 1, 2, gCD, 0.5);               // left tear
                r(3, 4, 1.5, 1, gCD, 0.5);                // right tear
                // Bindings / wraps
                r(0, 2, 6, 0.8, 0x6a5a48);                // wrap band
                r(0, -1.5, 6, 0.8, 0x6a5a48);             // wrap band 2
            }
        } else if (cat === 'augment') {
            // Augment chip — detailed circuit board chip
            r(0, 0, 10, 7, darkM);              // chip body (dark substrate)
            r(0, 0, 9, 6, metal);               // chip face (lighter)
            r(0, -0.5, 4, 3, color, 0.8);       // glowing core
            c(0, -0.5, 1, 0xffffff, 0.5);       // core highlight
            // Pin legs (left/right sides)
            r(-5, -2, 1.5, 1, metal);
            r(-5, 0, 1.5, 1, metal);
            r(-5, 2, 1.5, 1, metal);
            r(5, -2, 1.5, 1, metal);
            r(5, 0, 1.5, 1, metal);
            r(5, 2, 1.5, 1, metal);
            // Circuit traces
            r(-2, 0, 0.5, 4, color, 0.3);
            r(2, 0, 0.5, 4, color, 0.3);
            r(0, -2, 6, 0.5, color, 0.2);
            r(0, 2, 6, 0.5, color, 0.2);
        } else if (cat === 'consumable' || cat === 'key_item' || cat === 'scrap' || cat === 'cube' || cat === 'key') {
            // ═══ CONSUMABLE / KEY_ITEM / SCRAP PIXEL ART — ¾ perspective ═══
            const sub = item.subtype || item.id || '';
            
            if (sub === 'bandage') {
                // ── BANDAGE ROLL — cylindrical wrap seen from ¾ ──
                // Tier differentiates color: T1=white, T2=olive
                const isMil = item.id === 'bandage_military';
                const fabric = isMil ? 0x6a7a5a : 0xe8e0d8;
                const fabDark = isMil ? 0x546648 : 0xc8c0b8;
                const fabLight = isMil ? 0x8a9a7a : 0xf8f4f0;
                const cross = isMil ? 0xcc4444 : 0xcc3333;
                
                // Roll body — front face (dominant, ¾ view)
                r(0, 1, 10, 8, fabric);               // main wrap body
                r(0, 1, 9, 7, fabLight);               // lighter inner
                // Foreshortened top ellipse
                r(0, -3, 10, 2.5, fabDark);            // top surface
                r(0, -3, 8, 1.5, fabric);              // top highlight
                // Wrap ridges (horizontal lines showing coiled layers)
                r(0, -0.5, 8, 0.5, fabDark, 0.4);
                r(0, 1.5, 8, 0.5, fabDark, 0.3);
                r(0, 3.5, 8, 0.5, fabDark, 0.35);
                // Red cross on front face
                r(0, 1, 1.5, 5, cross);               // vertical bar
                r(0, 1, 5, 1.5, cross);               // horizontal bar
                // Loose tail hanging from bottom-right
                r(3, 5.5, 4, 1.5, fabric, 0.7);
                r(4, 6.5, 2, 1, fabDark, 0.5);
                // Shadow underneath
                r(0, 5.5, 8, 1, 0x000000, 0.1);
                // Military: add strap buckle
                if (isMil) {
                    r(0, -1, 10, 1, 0x4a3a2a, 0.6);  // strap across
                    r(-3, -1, 1.5, 1.5, 0x8a7a5a);    // buckle
                }
                
            } else if (sub === 'medkit') {
                // ── MEDICAL KIT — rigid box with latch, ¾ view ──
                const isAdv = item.id === 'medkit_advanced';
                const boxCol = isAdv ? 0xd8d0c8 : 0xe0ddd8;
                const boxDark = isAdv ? 0xa89888 : 0xb0aaa0;
                const boxLight = isAdv ? 0xf0e8e0 : 0xf0ece8;
                const accent = isAdv ? 0xccaa44 : 0xcc3333;
                const accentDark = isAdv ? 0x997722 : 0x992222;
                
                // Box body — front face dominant
                r(0, 1, 12, 9, boxDark);               // shadow / back
                r(0, 0.5, 11, 8, boxCol);              // front face
                r(0, 0.5, 10, 7, boxLight);            // front highlight
                // ¾ top surface (foreshortened)
                r(0, -4, 12, 2.5, boxDark);            // top surface
                r(0, -4, 10, 1.5, boxCol);             // top lighter
                // Lid seam
                r(0, -2.5, 11, 0.5, boxDark, 0.5);
                // Cross on front
                r(0, 0.5, 1.5, 5, accent);
                r(0, 0.5, 5, 1.5, accent);
                // Latch
                r(0, 4, 3, 1.5, 0x8a8a8a);            // latch plate
                r(0, 4, 2, 1, 0xaaaaaa);               // latch highlight
                // Rounded corners hint
                c(-5.5, -4, 0.5, boxDark);
                c(5.5, -4, 0.5, boxDark);
                // Handle on top
                r(0, -5, 4, 1, 0x6a6a6a);             // handle bar
                r(-2, -4.5, 1, 1, 0x8a8a8a);          // handle post L
                r(2, -4.5, 1, 1, 0x8a8a8a);           // handle post R
                // Advanced: gold trim
                if (isAdv) {
                    r(0, -2.5, 12, 0.5, 0xccaa44, 0.6); // gold seam
                    r(-5.5, 0.5, 0.5, 8, 0xccaa44, 0.3); // left edge gold
                    r(5.5, 0.5, 0.5, 8, 0xccaa44, 0.3);  // right edge gold
                    c(0, -5, 1, 0xffdd66, 0.4);           // handle glow
                }
                // Shadow
                r(0, 5.5, 10, 1, 0x000000, 0.1);
                
            } else if (sub === 'grenade') {
                // ── GRENADES — spherical body + spoon + pin, ¾ view ──
                const gType = item.grenadeType || 'frag';
                let gBody, gDark, gLight, gMark;
                if (gType === 'frag') {
                    gBody = 0x5a6a4a; gDark = 0x3a4a2a; gLight = 0x7a8a6a; gMark = 0xddcc44;
                } else if (gType === 'poison') {
                    gBody = 0x3a6a3a; gDark = 0x2a4a2a; gLight = 0x5a8a5a; gMark = 0xaaff66;
                } else {
                    gBody = 0x8a4a2a; gDark = 0x6a3a1a; gLight = 0xaa6a4a; gMark = 0xff8833;
                }
                
                // Main body — slightly squashed sphere from ¾
                c(0, 1, 6, gBody);                      // main sphere
                c(0, 1, 5.5, gLight, 0.5);              // front highlight
                c(-2, -0.5, 2, 0xffffff, 0.08);         // specular
                // Segmented lines (frag pineapple pattern)
                if (gType === 'frag') {
                    r(-2, 1, 0.3, 8, gDark, 0.4);
                    r(2, 1, 0.3, 8, gDark, 0.4);
                    r(0, -1, 8, 0.3, gDark, 0.4);
                    r(0, 3, 8, 0.3, gDark, 0.4);
                }
                // Hazard marking on front face
                if (gType === 'poison') {
                    // Skull: simple crossbones
                    c(0, 0.5, 2, gMark, 0.6);           // skull circle
                    r(0, 0, 1, 0.5, gDark, 0.8);        // eye sockets hint
                    r(-1.5, 2.5, 4, 0.5, gMark, 0.5);   // crossbone
                } else if (gType === 'inferno') {
                    // Flame icon
                    c(0, 0, 1.5, gMark, 0.7);            // flame center
                    r(0, -1.5, 1, 2, gMark, 0.5);        // flame tip
                    c(0, 1, 1, 0xffcc22, 0.4);           // inner flame
                }
                // Top cap / fuse well
                r(0, -5, 4, 2, gDark);                  // neck
                r(0, -5, 3, 1.5, gBody);                 // neck highlight
                // Spoon (lever) — angled along right side
                r(2.5, -4, 1, 5, 0x8a8a8a);             // spoon shaft
                r(2.5, -7, 1.5, 1, 0xaaaaaa);           // spoon top
                // Pin ring — sticking out left
                c(-3, -5.5, 1.5, 0x000000, 0);
                c(-3, -5.5, 1.5, 0xcccccc, 0.0);        // ring outline (use stroke)
                r(-3, -5.5, 2, 2, 0x000000, 0);
                // Draw ring as thin circle parts
                r(-4, -5.5, 1.5, 0.5, 0xaaaaaa);       // pin ring left
                r(-3, -6.5, 0.5, 1.5, 0xaaaaaa);       // pin ring top
                r(-2, -5.5, 0.5, 0.5, 0xaaaaaa);       // pin ring right bit
                r(-3, -4.5, 0.5, 1, 0xaaaaaa);          // pin ring bottom
                // Shadow
                r(0, 7, 8, 1.5, 0x000000, 0.1);
                
            } else if (sub === 'pylon') {
                // ── PYLONS — vertical crystal on base platform, ¾ view ──
                const isHeal = item.pylonType === 'heal';
                const pCol = isHeal ? 0x44ddaa : 0xff4466;
                const pDark = isHeal ? 0x228866 : 0xaa2244;
                const pLight = isHeal ? 0x66ffcc : 0xff6688;
                const pGlow = isHeal ? 0x88ffdd : 0xff88aa;
                
                // Base platform — hexagonal seen from ¾ (simplified as trapezoid)
                r(0, 6, 12, 3, 0x3a3a44);              // base plate
                r(0, 5.5, 11, 2, 0x4a4a55);            // base top surface
                r(0, 6, 10, 0.5, 0x5a5a66);            // base edge highlight
                // Base accent ring
                r(0, 5, 8, 0.5, pCol, 0.4);
                
                // Crystal body — pointed top, wider bottom
                // Main facet (front face, dominant)
                r(0, 0, 6, 10, pDark);                  // crystal body dark
                r(-0.5, -0.5, 5, 9, pCol);              // front facet
                r(-1, -1, 3, 7, pLight, 0.5);           // highlight facet
                // Point at top
                r(0, -6, 4, 2, pCol);
                r(0, -7, 2, 1.5, pLight);
                r(0, -7.5, 1, 0.5, 0xffffff, 0.6);     // tip sparkle
                // Side facets (depth lines)
                r(-3, 0, 0.5, 8, pDark, 0.6);          // left edge
                r(3, 0, 0.5, 8, pDark, 0.6);           // right edge
                // Inner glow core
                c(0, 0, 1.5, pGlow, 0.5);              // glowing center
                c(0, -1, 0.8, 0xffffff, 0.3);           // white hot center
                // Energy lines running up crystal
                r(0, -3, 0.3, 5, pGlow, 0.3);
                r(1.5, -2, 0.3, 4, pGlow, 0.2);
                r(-1.5, -2, 0.3, 4, pGlow, 0.2);
                // Shadow from crystal on base
                r(0, 6, 4, 1, 0x000000, 0.15);
                
            } else if (sub === 'energy_drink') {
                // ── ENERGY DRINK — tall slim can, ¾ view ──
                const canBody = 0x2255aa;
                const canDark = 0x1a3a7a;
                const canLight = 0x3366cc;
                const accent = 0x44ffaa;
                // Front face — tall slim can body
                r(0, 0, 8, 14, canDark);                 // can shadow
                r(0, -0.5, 7, 13, canBody);              // can front
                r(-1, -1, 4, 10, canLight, 0.25);        // specular highlight
                // ¾ foreshortened top
                r(0, -7, 8, 2, canDark);                 // top surface
                r(0, -7, 6, 1.2, canBody);               // top lighter
                // Pull tab on top
                r(1, -7.5, 2, 1.5, 0x888888);            // tab
                r(1, -7.5, 1.5, 1, 0xaaaaaa);            // tab highlight
                // Lightning bolt design on front face
                r(0, -3, 1.5, 3, accent, 0.7);           // bolt top
                r(-1, -1, 1.5, 2, accent, 0.7);          // bolt mid
                r(0, 1, 1.5, 3, accent, 0.7);            // bolt bottom
                // Label stripe
                r(0, -2, 7, 0.5, accent, 0.3);
                r(0, 3, 7, 0.5, accent, 0.3);
                // Bottom edge / rim
                r(0, 6.5, 8, 1, canDark, 0.6);
                // Condensation droplets
                c(2.5, 0, 0.5, 0xffffff, 0.15);
                c(2, 2.5, 0.4, 0xffffff, 0.12);
                // Shadow
                r(0, 7.5, 6, 1, 0x000000, 0.1);
                
            } else if (sub === 'lockpick') {
                // ── LOCKPICK — pick + tension wrench, ¾ view ──
                // Handle — front face dominant with ¾ top
                r(0, -7, 4, 4, 0x4a3a2a);               // handle shadow
                r(0, -7.5, 3.5, 3.5, 0x5a4a3a);         // handle body
                r(0, -7.5, 3, 3, 0x6a5a4a);              // handle lighter
                r(0, -9, 4, 1, 0x4a3a2a);                // handle ¾ top
                r(0, -9, 3, 0.6, 0x5a4a3a);              // top lighter
                // Grip texture ridges
                r(-0.5, -8, 0.5, 2, 0x7a6a5a, 0.5);
                r(0.5, -8, 0.5, 2, 0x7a6a5a, 0.5);
                r(0, -7, 0.5, 2, 0x7a6a5a, 0.4);
                // Main shaft — round metal rod
                r(0, 0, 1.5, 12, metal);                 // shaft body
                r(-0.3, 0, 0.8, 11, 0xbbbbbb, 0.4);     // shaft highlight (left edge)
                r(0.5, 0, 0.3, 11, darkM, 0.3);         // shaft shadow (right edge)
                // Hook end (bottom) — bent tip
                r(1.5, 5, 3, 1.5, metal);               // hook horizontal
                r(3, 4, 1.5, 2.5, metal);               // hook tip up
                r(3, 3.5, 1, 1, 0xcccccc);              // hook tip highlight
                r(2, 5, 2, 0.5, darkM, 0.3);            // hook shadow
                // Tension wrench (second tool, slightly behind)
                r(-2.5, 1, 1, 8, 0x7a7a7a);             // wrench shaft
                r(-2.5, 1, 0.6, 7, 0x8a8a8a, 0.4);      // wrench highlight
                r(-2.5, -3.5, 2.5, 1.5, 0x888888);       // wrench bend
                r(-2.5, -3.5, 2, 1, 0x999999);            // bend highlight
                
            } else if (sub === 'lore_chip') {
                // ── LORE CHIP — data disc, ¾ view (front edge dominant) ──
                const discBody = 0x3a3a4a;
                const discFace = 0x4a4a5a;
                const discLight = 0x5a5a6a;
                const discDark = 0x2a2a3a;
                const glow = 0x44ffcc;
                // Front face — wide oval edge visible (disc seen at angle)
                r(0, 1, 12, 7, discDark);                // shadow
                r(0, 0.5, 11, 6, discBody);              // disc front edge
                r(0, 0.5, 10, 5, discFace);              // lighter face
                r(-1, -0.5, 6, 3, discLight, 0.3);       // specular highlight
                // ¾ foreshortened top surface (thin strip)
                r(0, -3, 12, 2, discDark);               // top surface
                r(0, -3, 10, 1.2, discBody);             // top lighter
                // Center spindle hole (on front face)
                r(0, 0.5, 2.5, 2.5, discDark);           // hole outer
                r(0, 0.5, 1.5, 1.5, 0x222233);           // hole inner
                // Data track grooves (horizontal lines across front face)
                r(0, -1, 9, 0.3, glow, 0.25);
                r(0, 0.5, 10, 0.3, glow, 0.2);
                r(0, 2, 9, 0.3, glow, 0.25);
                // Data label etched on surface
                r(3, -0.5, 3, 0.5, glow, 0.4);
                r(3, 0.8, 2, 0.5, glow, 0.3);
                // Inner glow from data
                r(0, 0.5, 6, 3, glow, 0.08);
                // Thin depth edge on bottom
                r(0, 3.5, 11, 0.8, discDark, 0.6);
                // Shadow
                r(0, 5, 9, 1, 0x000000, 0.1);
                
            } else if (sub === 'toolkit') {
                // ── TOOLKIT — small toolbox, ¾ view ──
                const tBox = 0x884422;
                const tBoxL = 0xaa6633;
                const tBoxD = 0x663311;
                // Box body — front face dominant
                r(0, 1, 12, 8, tBoxD);                  // shadow
                r(0, 0.5, 11, 7, tBox);                 // front face
                r(0, 0.5, 10, 6, tBoxL);                // highlight
                // ¾ top surface
                r(0, -3.5, 12, 2.5, tBoxD);             // top
                r(0, -3.5, 10, 1.5, tBox);              // top lighter
                // Handle
                r(0, -5, 4, 1, 0x666666);               // handle bar
                r(-2, -4.5, 1, 1.5, 0x888888);          // post L
                r(2, -4.5, 1, 1.5, 0x888888);           // post R
                // Latch
                r(0, 3.5, 3, 1.5, 0x999999);
                r(0, 3.5, 2, 1, 0xbbbbbb);
                // Tool silhouettes on front face
                r(-3, 0, 1, 4, 0x555555, 0.3);          // wrench
                r(-1, -0.5, 1, 3, 0x555555, 0.3);       // screwdriver
                r(1, 0.5, 2, 2, 0x555555, 0.3);         // pliers
                // Shadow
                r(0, 5.5, 10, 1, 0x000000, 0.1);
                
            } else if (sub === 'fuel_canister') {
                // ── FUEL CANISTER — jerry can, ¾ view ──
                const fCan = 0x447744;
                const fCanD = 0x335533;
                const fCanL = 0x66aa66;
                // Body — front face dominant
                r(0, 1, 10, 10, fCanD);                 // shadow
                r(0, 0.5, 9, 9, fCan);                  // front
                r(0, 0.5, 8, 8, fCanL, 0.4);            // highlight
                // ¾ top
                r(0, -4.5, 10, 2, fCanD);
                r(0, -4.5, 8, 1.5, fCan);
                // Spout (top right)
                r(3, -6, 2, 2.5, 0x666666);             // spout neck
                r(3, -7, 2.5, 1, 0x888888);             // spout cap
                // Handle (top)
                r(-1, -6, 4, 1, 0x555555);              // handle
                r(-3, -5.5, 1, 1.5, 0x666666);          // handle post
                // Embossed cross on front (fuel marking)
                r(0, 1, 1, 5, fCanD, 0.5);
                r(0, 1, 5, 1, fCanD, 0.5);
                // Liquid level hint
                r(0, 3, 7, 2, fCanD, 0.3);
                // Shadow
                r(0, 6, 8, 1, 0x000000, 0.1);
                
            } else if (sub === 'currency_grant') {
                // ── PURSE / WALLET / SCRAP BOX / AMMO BOX ──
                const action = item.useAction || '';
                
                if (item.id === 'purse') {
                    // ── PURSE — small drawstring pouch, ¾ view ──
                    const pBody = 0x8a5a6a;
                    const pLight = 0xa06a7a;
                    const pDark = 0x6a4a5a;
                    // Front face — rounded pouch body (wide, dominant)
                    r(0, 1, 10, 8, pDark);               // shadow
                    r(0, 0.5, 9, 7, pBody);              // front face
                    r(0, 0.5, 8, 6, pLight, 0.4);        // highlight
                    r(-1.5, -1, 4, 3, 0xffffff, 0.06);   // specular
                    // ¾ foreshortened top
                    r(0, -3.5, 10, 2, pDark);            // top surface
                    r(0, -3.5, 8, 1.2, pBody);           // top lighter
                    // Drawstring gathered at top
                    r(-2, -4.5, 1, 2, pDark);            // string L
                    r(2, -4.5, 1, 2, pDark);             // string R
                    r(0, -5, 4, 1, pDark);               // string cross
                    // Clasp / knot
                    r(0, -5, 2, 1.5, 0xccaa44);          // gold clasp
                    r(0, -5, 1.5, 1, 0xddbb55);          // clasp highlight
                    // Bits coin peeking from opening
                    r(0, -4, 2, 1, 0xffdd44, 0.5);
                    // Stitch lines on front face
                    r(0, 1, 0.3, 5, pDark, 0.3);         // center seam
                    // Slight bulge detail
                    r(-3, 1, 0.5, 4, pDark, 0.2);
                    r(3, 1, 0.5, 4, pDark, 0.2);
                    // Shadow
                    r(0, 5.5, 8, 1, 0x000000, 0.1);
                    
                } else if (item.id === 'wallet') {
                    // Bi-fold wallet, slightly open
                    r(0, 0, 10, 7, 0x4a3a2a);            // back panel
                    r(0, 0.5, 9, 6, 0x5a4a3a);           // front panel
                    r(0, 0.5, 8, 5, 0x6a5a4a);           // front highlight
                    // Fold line
                    r(0, -2.5, 10, 0.5, 0x3a2a1a);
                    // ¾ top — wallet slightly open showing interior
                    r(0, -3, 10, 1.5, 0x3a2a1a);
                    r(0, -3, 8, 0.8, 0x7a6a5a);          // interior
                    // Card slot lines
                    r(0, -0.5, 6, 0.4, 0x3a2a1a, 0.4);
                    r(0, 1, 6, 0.4, 0x3a2a1a, 0.4);
                    // Bits poking out top
                    r(1, -3.5, 3, 1, 0xccaa44, 0.7);
                    r(2, -4, 2, 0.8, 0xffdd66, 0.5);
                    // Stitch line
                    r(-5, 0, 0.3, 5, 0x3a2a1a, 0.3);
                    // Shadow
                    r(0, 4.5, 8, 1, 0x000000, 0.1);
                    
                } else if (item.id === 'scrap_box') {
                    // ── SCRAP BOX — cardboard box with lid ajar, ¾ view ──
                    const boxBody = 0x8a7a5a;
                    const boxDark = 0x6a5a3a;
                    const boxLight = 0x9a8a6a;
                    // Box body — front face dominant
                    r(0, 1, 11, 8, boxDark);              // shadow/back
                    r(0, 0.5, 10, 7, boxBody);            // front face
                    r(0, 0.5, 9, 6, boxLight, 0.4);       // highlight
                    // Cardboard corrugation lines on front
                    r(0, -1, 8, 0.3, boxDark, 0.25);
                    r(0, 1, 8, 0.3, boxDark, 0.2);
                    r(0, 3, 8, 0.3, boxDark, 0.2);
                    // ¾ top — lid partly open
                    r(0, -3.5, 11, 2, boxDark);           // top surface
                    r(1, -4.5, 8, 1.5, 0x7a6a4a);         // lid flap angled up
                    r(1, -5, 7, 0.5, boxLight, 0.3);      // lid edge highlight
                    // Materials icon on front (gear/cog symbol)
                    r(0, 0.5, 4, 4, 0x887766, 0.35);      // gear body
                    r(0, 0.5, 2, 2, 0x887766, 0.5);       // gear center
                    r(0, -1.5, 1, 1, 0x887766, 0.4);      // gear tooth top
                    r(0, 2.5, 1, 1, 0x887766, 0.4);       // gear tooth bottom
                    r(-2, 0.5, 1, 1, 0x887766, 0.4);      // gear tooth left
                    r(2, 0.5, 1, 1, 0x887766, 0.4);       // gear tooth right
                    // Packing tape across center
                    r(0, -1.5, 3, 8, 0xccaa66, 0.15);
                    // Shipping label (white rectangle)
                    r(-3, -1, 3, 2, 0xddddcc, 0.4);
                    r(-3, -0.5, 2, 0.3, boxDark, 0.3);    // label text line
                    r(-3, 0.5, 2.5, 0.3, boxDark, 0.2);   // label text line
                    // Reinforced corner
                    r(-5, -3.5, 1.5, 2, boxDark, 0.4);
                    r(5, -3.5, 1.5, 2, boxDark, 0.4);
                    // Shadow
                    r(0, 5.5, 10, 1, 0x000000, 0.1);
                    
                } else if (item.id === 'ammo_box') {
                    // Military ammo crate
                    r(0, 1, 12, 8, 0x3a4a3a);            // body dark
                    r(0, 0.5, 11, 7, 0x4a5a4a);          // front face
                    r(0, 0.5, 10, 6, 0x5a6a5a, 0.4);     // highlight
                    // ¾ top
                    r(0, -3.5, 12, 2, 0x3a4a3a);
                    r(0, -3.5, 10, 1.5, 0x4a5a4a);
                    // Latch
                    r(0, 3.5, 3, 1.5, 0x888888);
                    r(0, 3.5, 2, 1, 0xaaaaaa);
                    // Stencil text hint (ammo marking)
                    r(-3, 0, 6, 0.8, 0xcccc88, 0.3);
                    r(-3, 1.5, 4, 0.8, 0xcccc88, 0.25);
                    // Bullet icons on front
                    r(3, -0.5, 1, 3, 0xaa8844, 0.5);
                    r(3, -2, 1.5, 1, 0x999999, 0.5);
                    // Handle
                    r(0, -5, 4, 1, 0x666666);
                    r(-2, -4.5, 1, 1, 0x777777);
                    r(2, -4.5, 1, 1, 0x777777);
                    // Shadow
                    r(0, 5.5, 10, 1, 0x000000, 0.1);
                    
                } else if (item.id === 'husk_faded_id') {
                    // ── FADED ID — small rectangular card, bleached ──
                    r(0, 0, 10, 7, 0x8a8a7a);              // card body
                    r(0, 0, 9, 6, 0x9a9a8a);               // lighter face
                    r(-2.5, -1.5, 3, 3, 0x6a6a5a, 0.4);    // photo area (faded)
                    r(1.5, -1, 5, 0.5, 0x6a6a5a, 0.3);     // text line
                    r(1.5, 0.5, 4, 0.5, 0x6a6a5a, 0.3);    // text line
                    r(1.5, 2, 3, 0.5, 0x6a6a5a, 0.3);      // text line
                } else if (item.id === 'husk_corroded_trinket') {
                    // ── CORRODED TRINKET — tarnished ring/pendant ──
                    c(0, 0, 4, 0x6a5a4a, 0.8);             // ring outer
                    c(0, 0, 2.5, 0x3a3a3a, 0.6);           // ring hole
                    c(0, 0, 3, 0x7a6a5a, 0.3);             // tarnish
                    r(-1, -5, 0.5, 3, 0x5a5a4a, 0.4);      // chain bit
                    r(1, -5, 0.5, 3, 0x5a5a4a, 0.4);       // chain bit
                } else if (item.id === 'husk_cracked_visor') {
                    // ── CRACKED VISOR — eye protection, cracked lens ──
                    r(0, 0, 12, 5, 0x3a4a5a);              // frame
                    r(0, 0, 10, 4, 0x4a6a8a, 0.6);         // lens
                    r(-1, -0.5, 5, 2, 0x6a8aaa, 0.3);      // reflection
                    r(2, -1, 0.5, 5, 0x2a2a2a, 0.7);       // crack
                    r(3, 0, 0.5, 3, 0x2a2a2a, 0.5);        // crack branch
                } else if (item.id === 'flicker_cube_node') {
                    // ── CUBE NODE — dense crystal knot, pulsing ──
                    c(0, 0, 5, 0x3a2a5a, 0.6);             // outer shell
                    c(0, 0, 3.5, 0x5a3a8a, 0.7);           // mid layer
                    c(0, 0, 2, 0x8844cc, 0.8);             // bright core
                    r(-2, -2, 1, 1, 0xaa55ee, 0.5);         // facet
                    r(2, -1, 1, 1, 0xaa55ee, 0.4);          // facet
                    r(-1, 2, 1, 1, 0xaa55ee, 0.35);         // facet
                    r(0, 0, 1, 1, 0xcc77ff, 0.6);           // center pulse
                } else {
                    // Generic grant item fallback
                    r(0, 0, 8, 6, darkM);
                    r(0, -1, 6, 4, metal);
                    c(0, -1, 2, color, 0.5);
                }
                
            } else if (item.id === 'scrap_wood') {
                // ── SCRAP WOOD — rough plank piece ──
                r(0, 0, 4, 12, 0x8a7a5a);               // plank body
                r(-0.5, 0, 3, 11, 0x9a8a6a);            // lighter face
                r(-1, -3, 1, 3, 0x7a6a4a, 0.5);         // knot
                r(0, 5, 4, 0.5, 0x6a5a3a);              // crack line
                r(0, -5.5, 4, 1, 0x7a6a4a);             // rough top edge
                r(2.5, -3, 0.5, 2, 0x9a8a6a, 0.6);      // splinter
                r(-2, 4, 0.5, 1.5, 0x7a6a4a, 0.5);      // splinter

            } else if (item.id === 'scrap_wire') {
                // ── WIRE BUNDLE — coiled wires ──
                c(0, 0, 5, 0x6a6a7a);                   // coil outer
                c(0, 0, 4, 0x7a7a8a);                   // coil mid
                c(0, 0, 2.5, 0x5a5a6a);                 // center void
                r(3, -2, 3, 0.5, 0xcc4444, 0.6);        // red wire end
                r(-2, 3, 2, 0.5, 0x4466cc, 0.6);        // blue wire end
                r(1, -4, 0.5, 2, 0x44aa44, 0.5);        // green wire end
                r(2, 0, 0.5, 3, 0xcc8844, 0.4);         // copper glint
                r(-1, -1, 3, 0.5, 0xcc8844, 0.3);

            } else if (item.id === 'scrap_metal') {
                // ── METAL SCRAP — bent plate with bolt ──
                r(0, 0, 10, 7, 0x5a5a5a);               // plate body
                r(0, -0.5, 9, 6, 0x6a6a6a);             // lighter face
                r(-2, 0, 5, 3, 0x7a7a7a, 0.4);          // highlight
                r(4, -3, 2, 2, 0x4a4a4a);               // fold shadow
                r(4, -3.5, 2, 1.5, 0x5a5a5a);           // fold
                c(-3, 1, 1.5, 0x888888);                 // bolt
                c(-3, 1, 0.8, 0xaaaaaa);                 // bolt highlight
                r(1, -1, 4, 0.3, 0x8a8a8a, 0.4);        // scratch

            } else if (item.id === 'scrap_cloth') {
                // ── CLOTH STRIP — torn fabric ──
                r(0, 0, 6, 10, 0x8a7a6a);               // cloth body
                r(-0.5, 0, 5, 9, 0x9a8a7a);             // lighter
                r(-3, -4, 1, 2, 0x7a6a5a, 0.5);         // frayed edge
                r(3, 3, 1, 2.5, 0x7a6a5a, 0.5);         // frayed edge
                r(0, -1, 5, 0.5, 0x6a5a4a, 0.4);        // fold crease
                r(0, 2, 4, 0.5, 0x6a5a4a, 0.3);         // fold crease
                r(-1, -2, 0.3, 6, 0x7a6a5a, 0.2);       // weave hint
                r(1, -1, 0.3, 5, 0x7a6a5a, 0.2);

            } else if (item.id === 'scrap_tech') {
                // ── TECH COMPONENT — circuit board fragment ──
                r(0, 0, 10, 8, 0x2a5a2a);               // PCB green
                r(0, 0, 9, 7, 0x3a6a3a);                // lighter
                r(-2, -2, 0.5, 5, 0xccaa44, 0.5);       // trace
                r(1, -1, 4, 0.5, 0xccaa44, 0.5);        // trace
                r(3, 0, 0.5, 3, 0xccaa44, 0.4);         // trace
                c(-2, 2, 0.8, 0xcccccc, 0.6);           // solder pad
                c(1, -1, 0.8, 0xcccccc, 0.6);           // solder pad
                r(-1, 1, 3, 2, 0x222222);               // IC chip
                r(-1, 1, 2.5, 1.5, 0x333333);           // chip lighter
                r(5, -1, 0.5, 4, 0x1a4a1a, 0.6);        // broken edge

            } else if (item.id === 'husk_tattered_cloth') {
                // ── TATTERED GARMENT — torn fabric scrap ──
                r(0, 0, 9, 11, 0x5a4a3a);               // fabric body
                r(0, 0, 8, 10, 0x6a5a4a, 0.7);          // lighter weave
                r(-3, -3, 2, 0.5, 0x4a3a2a, 0.5);       // tear line
                r(2, 1, 0.5, 4, 0x4a3a2a, 0.5);         // rip
                r(-1, 4, 3, 0.5, 0x551010, 0.3);         // blood stain
                r(4, -2, 1, 3, 0x5a4a3a, 0.4);           // frayed edge
                r(-4, 2, 1, 2, 0x5a4a3a, 0.4);           // frayed edge
            } else if (item.id === 'husk_cube_residue') {
                // ── CUBE RESIDUE — crystalline organic cluster ──
                r(0, 0, 6, 8, 0x4a2a5a);                // tissue base
                r(0, 0, 5, 7, 0x5a3a6a, 0.7);           // lighter
                r(-1, -2, 3, 4, 0x7a44aa, 0.5);         // crystal growth
                r(1, 1, 2, 3, 0x7a44aa, 0.4);           // crystal growth
                c(-1, -2, 1.5, 0xaa66dd, 0.3);          // glow
                c(1, 1, 1, 0xaa66dd, 0.25);             // glow
                r(0, -4, 1, 2, 0x6a3a8a, 0.6);          // shard point

            } else if (item.id === 'flicker_blade_shard') {
                // ── BLADE SHARD — crystallized bone-metal fragment ──
                r(0, 0, 3, 12, 0x4a4a5a);               // blade body
                r(0, 0, 2, 11, 0x5a5a6a, 0.7);          // lighter face
                r(-1, 0, 1, 12, 0x6a6a7a, 0.4);         // edge highlight
                r(0, -5, 2, 2, 0x3a3a4a);                // broken top
                r(0, 5, 1, 2, 0x3a3a4a);                 // sharp tip
                r(1, -2, 1, 4, 0x8844cc, 0.3);           // cube vein
            } else if (item.id === 'flicker_tendril_strand') {
                // ── TENDRIL STRAND — severed, still twitching ──
                r(0, -4, 2, 3, 0x4a2a6a);               // thick end
                r(0, -2, 1.5, 4, 0x3a2a5a);             // mid section
                r(1, 1, 1, 4, 0x3a2a5a);                // curving
                r(2, 4, 1, 3, 0x4a2a6a);                 // tip section
                c(2, 6, 1, 0xaa55ee, 0.4);               // glowing tip
                r(-1, -3, 1, 2, 0x551030, 0.4);          // severed end (blood)
            } else if (item.id === 'flicker_phase_residue') {
                // ── PHASE RESIDUE — iridescent dust cluster ──
                c(0, 0, 5, 0x4a2a6a, 0.3);              // dust cloud
                c(-1, -1, 3, 0x6a3a8a, 0.25);           // inner shimmer
                c(1, 1, 2, 0x8844cc, 0.35);             // bright core
                r(-2, -2, 1, 1, 0xaa55ee, 0.5);         // sparkle
                r(2, 0, 1, 1, 0xaa55ee, 0.4);           // sparkle
                r(0, 2, 1, 1, 0xcc77ff, 0.35);          // sparkle
                r(-1, 1, 1, 1, 0xaa55ee, 0.3);          // sparkle

            } else if (item.id === 'cube_uncommon' || item.id === 'cube_rare' || item.id === 'cube_master' || item.id === 'cube_legendary') {
                // ── ENCRYPTED CUBES — ¾ iso cube with rarity-colored energy ──
                const cubeColors = {
                    cube_uncommon: { body: 0x2a3a2a, face: 0x3a4a3a, top: 0x4a5a4a, glow: 0x44aa44, line: 0x66cc66, core: 0x88ee88 },
                    cube_rare:      { body: 0x2a2a3a, face: 0x3a3a5a, top: 0x4a4a6a, glow: 0x4488ff, line: 0x66aaff, core: 0x88ccff },
                    cube_master:    { body: 0x3a2a1a, face: 0x5a3a2a, top: 0x6a4a3a, glow: 0xffaa22, line: 0xffcc44, core: 0xffee66 },
                    cube_legendary: { body: 0x3a1a1a, face: 0x5a2a2a, top: 0x6a3a3a, glow: 0xff2244, line: 0xff4466, core: 0xff8888 }
                };
                const cc = cubeColors[item.id] || cubeColors.cube_rare;
                // Main body — front face (wide, dominant)
                r(0, 1, 10, 10, cc.body);
                r(0, 0.5, 9, 9, cc.face);
                // Top face — foreshortened strip
                r(0, -5, 10, 2.5, cc.body);
                r(0, -5, 8, 1.5, cc.top);
                // Right side edge
                r(5.5, 0, 1.5, 10, cc.body, 0.6);
                // Energy circuit lines on front face
                r(-2, -1, 0.5, 5, cc.line, 0.5);
                r(2, 0, 0.5, 4, cc.line, 0.4);
                r(0, -2, 5, 0.5, cc.line, 0.4);
                r(0, 2, 3, 0.5, cc.line, 0.3);
                // Corner nodes
                r(-3, -3, 1, 1, cc.glow, 0.6);
                r(3, -3, 1, 1, cc.glow, 0.5);
                r(-3, 3, 1, 1, cc.glow, 0.4);
                r(3, 3, 1, 1, cc.glow, 0.5);
                // Core glow
                c(0, 0, 2, cc.glow, 0.4);
                c(0, 0, 1, cc.core, 0.25);
                // Top face energy pip
                r(0, -5, 2, 1, cc.glow, 0.5);
                // Edge rivets
                r(-4, -4, 0.5, 0.5, cc.line, 0.3);
                r(4, -4, 0.5, 0.5, cc.line, 0.3);
                r(-4, 4, 0.5, 0.5, cc.line, 0.2);
                r(4, 4, 0.5, 0.5, cc.line, 0.2);

            } else if (item.id === 'keycard_red') {
                // ── KEYCARD — plastic card, ¾ view ──
                r(0, 0, 10, 7, 0x992222);
                r(0, -0.5, 9, 6, 0xbb3333);
                r(-2, -0.5, 4, 3, 0xdd4444, 0.4);
                r(0, -3.5, 10, 1, 0x882222);            // top edge
                r(0, 2, 9, 1.5, 0x222222);              // mag stripe
                r(-3, -1, 2.5, 2, 0xccaa44);            // chip
                r(-3, -1, 2, 1.5, 0xddbb55);
                r(2, -1, 3, 0.5, 0xffffff, 0.25);       // text line

            } else {
                // Unknown item fallback
                r(0, 0, 6, 6, darkM);
                r(0, -1, 4, 4, metal);
                c(0, -1, 1.5, color, 0.6);
            }
        }

    },
    
    // ════════════════════════════════════════════════════════
    // RENDER WEAPON TO CANVAS — Canvas2D mirror of drawItemPixelArt
    // Returns { canvas, gripX, gripY } for armed sprite compositing
    // Weapon drawn pointing RIGHT; melee drawn pointing UP
    // ════════════════════════════════════════════════════════
    renderWeaponCanvas(item) {
        if (!item) return null;
        const base = CONFIG.baseItems[item.baseId] || {};
        const cat = item.category || base.category || '';
        const sprite = base.sprite || item.baseId || '';
        const isWeapon = (cat === 'weapon');
        const isMelee = (cat === 'melee');
        if (!isWeapon && !isMelee) return null;
        
        // Canvas size — generous to capture all weapon details
        const cW = isWeapon ? 52 : 32;
        const cH = isWeapon ? 28 : 44;
        const canvas = document.createElement('canvas');
        canvas.width = cW; canvas.height = cH;
        const ctx = canvas.getContext('2d');
        
        // Center point — weapons draw relative to this
        const cx = isWeapon ? 20 : cW / 2;
        const cy = cH / 2;
        const s = 1.0; // full scale, we'll downscale during composite
        
        // Per-instance seed (same algorithm as drawItemPixelArt)
        let _seedVal = 0;
        const _id = item.id || '';
        for (let i = 0; i < _id.length; i++) _seedVal = ((_seedVal * 31 + _id.charCodeAt(i)) ^ (_seedVal >>> 3)) | 0;
        const _sOff = (idx) => {
            let h = (_seedVal ^ (idx * 2654435761)) | 0;
            h = ((h >>> 16) ^ h) | 0;
            return ((h & 0x1F) - 15.5) / 15.5;
        };
        
        // Canvas draw helpers — mirror Phaser's centered rectangles
        const _hex = (col) => '#' + (col >>> 0).toString(16).padStart(6, '0');
        const r = (rx, ry, rw, rh, col, alpha) => {
            ctx.globalAlpha = alpha !== undefined ? alpha : 1;
            ctx.fillStyle = _hex(col);
            ctx.fillRect(cx + rx * s - rw * s / 2, cy + ry * s - rh * s / 2, rw * s, rh * s);
        };
        const c = (cx2, cy2, cr, col, alpha) => {
            ctx.globalAlpha = alpha !== undefined ? alpha : 1;
            ctx.fillStyle = _hex(col);
            ctx.beginPath();
            ctx.arc(cx + cx2 * s, cy + cy2 * s, cr * s, 0, Math.PI * 2);
            ctx.fill();
        };
        
        let gripX = cx, gripY = cy; // grip point in canvas coords
        
        if (isWeapon) {
            // === WEAPON PALETTE ===
            const foundry = item.foundry ? CONFIG.foundries[item.foundry] : null;
            const p = foundry ? foundry.palette : null;
            const isScrap = !foundry;
            const bCol  = p ? parseInt(p.body.replace('#',''),16)      : 0x4a4038;
            const bColL = p ? parseInt(p.bodyLight.replace('#',''),16) : 0x5a5248;
            const bColD = p ? parseInt(p.bodyDark.replace('#',''),16)  : 0x3a3430;
            const aCol  = p ? parseInt(p.accent.replace('#',''),16)    : 0x8a8a6a;
            const mCol  = p ? parseInt(p.metal.replace('#',''),16)     : 0x5a5248;
            const mColL = p ? parseInt(p.metalLight.replace('#',''),16): 0x5a5248;
            const dCol  = p ? parseInt(p.detail.replace('#',''),16)    : 0x3a3430;
            const wCol  = isScrap ? 0x5a4228 : (p ? Math.min(0xFFFFFF, parseInt(p.body.replace('#',''),16) + 0x101008) : 0x6a4a2a);
            const scTape = 0x8a8a6a;
            const scRust = 0x6a3a1a;
            const isEnergy = (foundry && (item.foundry === 'blackreach' || item.foundry === 'cephalon'));
            
            const pc = item.partConfig || { barrel: 'standard', stock: 'polymer', magazine: 'box', muzzle: 'birdcage' };
            
            // Part definitions (copied from drawItemPixelArt)
            const BD = {
                standard: [1.0, 1.0], precision: [1.1, 0.85], match: [1.3, 0.85, 'fluted'],
                heavy: [1.0, 1.3], short: [0.7, 1.0], fluted: [1.0, 0.85, 'fluted'],
                railed: [1.1, 1.0, 'rail'], bore: [0.85, 1.4], heavy_bore: [1.0, 1.5],
                wide_bore: [0.85, 1.7, 'flared'], salvaged: [0.9, 1.0, 'tape'], cut_down: [0.65, 1.0],
                mixed: [1.0, 1.0, 'mixed'], pipe: [0.85, 1.1, 'rust'],
                emitter: [1.0, 1.0, 'glow'], long_emitter: [1.3, 0.9, 'glow'],
                charged_emitter: [1.1, 1.1, 'glow_pulse'], slim_emitter: [1.0, 0.7, 'glow'],
                conduit: [1.0, 1.0, 'seam'], long_conduit: [1.3, 0.9, 'seam'],
                warped: [0.9, 1.0, 'seam_warp'], tuned_conduit: [1.15, 1.0, 'seam_rings']
            };
            const SD = {
                polymer: [1.0, 1.0, 'solid'], adjustable: [1.1, 0.8, 'tube'], fixed: [1.0, 1.2, 'solid'],
                folding: [0.8, 0.5, 'wire'], ergonomic: [1.0, 1.0, 'contour'], precision: [1.1, 1.0, 'contour'],
                skeleton: [1.0, 0.8, 'skel'], thumbhole: [1.2, 1.0, 'contour'],
                pipe: [0.6, 0.6, 'pipe'], braced: [1.2, 1.2, 'brace'], none: [0, 0, 'none'],
                wrapped: [0.9, 0.9, 'wrap'], chopped: [0.6, 0.8, 'solid'], carved: [1.0, 1.0, 'carved'],
                scrap: [0.8, 0.8, 'scrap'], integrated: [1.0, 0.8, 'seamless'], skeletal: [0.8, 0.7, 'skel'],
                floating: [0.7, 0.7, 'float'], organic: [0.9, 0.9, 'organic'],
                wood: [0.9, 0.9, 'solid'], plank: [0.8, 1.0, 'plank']
            };
            const MD = {
                box: [1.0, 1.0, 'box'], extended: [1.0, 1.4, 'box'], flush: [0.8, 0.6, 'flush'],
                canister: [1.2, 1.0, 'round'], drum: [1.8, 1.5, 'round'], hopper: [1.5, 1.2, 'top'],
                taped: [1.0, 1.0, 'tape'], taped_double: [1.6, 1.0, 'tape'], franken: [1.3, 1.3, 'scrap'],
                cell: [0.9, 0.8, 'crystal'], dual_cell: [1.4, 0.8, 'crystal'], core: [1.0, 1.0, 'sphere'],
                phase: [0.9, 0.9, 'phase'], recursive: [1.0, 1.2, 'phase'], exposed: [1.0, 1.0, 'exposed']
            };
            const ZD = {
                birdcage: [1.0, 'cage'], compensator: [1.0, 'vent'], brake: [1.3, 'vent'],
                suppressor: [2.5, 'can'], flash_hider: [0.8, 'cage'], tuned: [0.6, 'crown'],
                coils: [1.2, 'coil'], ported: [0.8, 'port'], nozzle: [1.0, 'nozzle'],
                open: [0.5, 'open'], cage: [1.2, 'cage'], flared: [1.4, 'flare'],
                hacksawed: [0.5, 'raw'], welded: [0.9, 'weld'], raw: [0.3, 'raw'],
                improvised: [0.8, 'scrap'], filed: [0.5, 'crown'], lens: [1.0, 'lens'],
                aperture: [1.2, 'iris'], diffuser: [1.3, 'multi'], prism: [1.2, 'prism'],
                slit: [0.7, 'slit'], ring: [1.0, 'ring'], void_ring: [1.3, 'ring'],
                fracture: [1.0, 'fracture'], harmonic: [1.2, 'harmonic']
            };
            
            const _bd = BD[pc.barrel] || BD.standard;
            const _sd = SD[pc.stock] || SD.polymer;
            const _md = MD[pc.magazine] || MD.box;
            const zd = ZD[pc.muzzle] || ZD.birdcage;
            const bd = [_bd[0] * (1 + _sOff(0) * 0.08), _bd[1] * (1 + _sOff(1) * 0.06), _bd[2]];
            const sd = [_sd[0] * (1 + _sOff(2) * 0.06), _sd[1] * (1 + _sOff(3) * 0.06), _sd[2]];
            const md = [_md[0] * (1 + _sOff(4) * 0.05), _md[1] * (1 + _sOff(5) * 0.07), _md[2]];
            
            // Muzzle helper
            const drawMuzzle = (mzX, mzS, bW) => {
                if (zd[1] === 'can') r(mzX + mzS/2, 0, mzS, bW + 0.5, mColL, 0.9);
                else if (zd[1] === 'vent') { r(mzX, 0, mzS*0.6, bW+0.5, mCol); r(mzX, -bW*0.6, mzS*0.4, 0.5, mColL, 0.5); }
                else if (zd[1] === 'cage') r(mzX, 0, mzS*0.5, bW+0.5, mColL, 0.6);
                else if (zd[1] === 'coil') { r(mzX, 0, mzS*0.6, bW+1, aCol, 0.3); r(mzX-0.5, 0, 0.5, bW+1.5, aCol, 0.2); r(mzX+0.5, 0, 0.5, bW+1.5, aCol, 0.2); }
                else if (zd[1] === 'nozzle' || zd[1] === 'flare') r(mzX, 0, mzS*0.5, bW+1.5, mCol);
                else if (zd[1] === 'weld') r(mzX, 0, mzS*0.5, bW+0.5, mCol, 0.7);
                else if (zd[1] === 'scrap') r(mzX, 0, mzS*0.4, bW+0.5, scTape, 0.5);
                else if (zd[1] === 'lens') { c(mzX, 0, mzS*0.4, aCol, 0.4); c(mzX, 0, mzS*0.2, mColL, 0.3); }
                else if (zd[1] === 'iris') { c(mzX, 0, mzS*0.5, mCol); c(mzX, 0, mzS*0.25, aCol, 0.5); }
                else if (zd[1] === 'multi') { r(mzX-0.5, -1, 0.5, 0.5, aCol, 0.4); r(mzX+0.5, -1, 0.5, 0.5, aCol, 0.4); r(mzX, 1, 0.5, 0.5, aCol, 0.4); }
                else if (zd[1] === 'prism') r(mzX, 0, mzS*0.4, mzS*0.5, aCol, 0.35);
                else if (zd[1] === 'ring') { c(mzX+0.5, 0, mzS*0.5, aCol, 0.2); c(mzX+0.5, 0, mzS*0.3, bColD, 0.8); }
                else if (zd[1] === 'fracture') { r(mzX, -0.5, mzS*0.3, bW+1, aCol, 0.3); r(mzX+0.5, 0.5, mzS*0.2, bW*0.5, aCol, 0.4); }
                else if (zd[1] === 'harmonic') { c(mzX, 0, mzS*0.4, aCol, 0.15); c(mzX+1, 0, mzS*0.35, aCol, 0.12); }
            };
            
            // Barrel detail helper
            const drawBarrelDetail = (bx, bL, bW) => {
                if (bd[2] === 'fluted') { for (let f=0;f<3;f++) r(bx+bL*0.3+f*bL*0.2, 0, 0.5, bW*0.7, bColD, 0.2); }
                if (bd[2] === 'rail') r(bx+bL*0.2, -bW/2-0.5, bL*0.6, 0.5, mColL, 0.5);
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(bx+bL*0.2, 0, bL*0.6, 0.5, aCol, 0.35);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(bx+bL*0.1, 0, bL*0.8, 0.5, aCol, 0.3);
                if (bd[2] === 'seam_rings') { r(bx+bL*0.3, 0, 0.5, bW+1, aCol, 0.2); r(bx+bL*0.6, 0, 0.5, bW+1, aCol, 0.2); }
                if (bd[2] === 'tape' || bd[2] === 'mixed') r(bx+bL*0.3, 0, 1, bW, scTape, 0.4);
                if (bd[2] === 'rust') r(bx+bL*0.5, 0, 1, bW*0.6, scRust, 0.3);
            };
            
            if (sprite === 'rifle') {
                r(-1, 0, 8, 3, bCol); r(0, -2, 6, 1, bColD); r(1, 1.5, 1.5, 1.5, mCol, 0.7);
                const bL = 6 * bd[0], bW = 2 * bd[1];
                r(3 + bL/2, 0, bL, bW, mCol); r(3 + bL, 0, 1, bW * 0.75, mColL);
                drawBarrelDetail(3, bL, bW);
                if (sd[2] !== 'none') {
                    const sW = 4 * sd[0], sH = 2.5 * sd[1];
                    const sCol = (sd[2]==='wrap'||sd[2]==='carved'||sd[2]==='solid'||sd[2]==='plank') ? wCol : mCol;
                    r(-4 - sW/2, 0.5, sW, sH, sCol); r(-4 - sW, 0.5, 1.5, sH + 0.5, bColD);
                    if (sd[2] === 'wire' || sd[2] === 'skel') { r(-4-sW/2, 0.5, sW, 0.5, mCol); r(-4-sW, 0.5, 0.5, sH, mCol); }
                    if (sd[2] === 'wrap') r(-4-sW*0.4, 0.5, sW*0.4, sH*0.8, scTape, 0.3);
                    if (sd[2] === 'seamless') r(-4-sW/2, 0.5, sW, sH, bCol);
                    if (sd[2] === 'contour') r(-4-sW*0.3, 0, 1, sH+1, bColD, 0.2);
                    if (sd[2] === 'carved') r(-4-sW*0.5, 0.5, 0.5, sH*0.5, aCol, 0.25);
                }
                const mgW = 2 * md[0], mgH = 3.5 * md[1];
                if (md[2] === 'top') { r(-1, -3, mgW, mgH*0.6, mCol); }
                else { r(-1, 2.5, mgW, mgH, mCol); r(-1, 2.5, mgW*0.75, mgH*0.8, bColD, 0.3); }
                if (md[2] === 'round') c(-1, 2.5 + mgH/2, mgW*0.4, mColL, 0.3);
                if (md[2] === 'tape') r(-1, 2.5 + mgH*0.3, mgW, 1, scTape, 0.4);
                if (md[2] === 'crystal') { r(-1, 2.5, mgW, mgH, bColD); r(-1, 2.5+mgH*0.3, mgW*0.6, mgH*0.4, aCol, 0.25); }
                if (md[2] === 'phase') { r(-1, 2.5, mgW, mgH, bColD); r(-1, 2.5, mgW*0.5, mgH*0.6, aCol, 0.15); }
                if (md[2] === 'sphere') c(-1, 3.5, mgW*0.5, aCol, 0.3);
                if (md[2] === 'exposed') { r(-1, 2.5, mgW, mgH, aCol, 0.15); r(-1, 3, 0.5, mgH*0.5, aCol, 0.4); }
                const mzX = 3 + bL + 0.5, mzS = 2 * zd[0]; drawMuzzle(mzX, mzS, bW);
                if (!isScrap && !isEnergy) { r(-1, -1.5, 1, 0.5, aCol, 0.5); r(2, 1, 0.5, 1, dCol, 0.4); }
                if (isEnergy) r(0, -0.5, 0.5, 2, aCol, 0.15);
                gripX = cx + 0; gripY = cy + 0; // grip at receiver

            } else if (sprite === 'mini') {
                r(0, 0, 7, 2.5, bCol); r(1, -1.5, 4, 1, bColD);
                const bL = 3 * bd[0], bW = 1.5 * bd[1];
                r(4 + bL/2, 0, bL, bW, mCol); r(4 + bL, 0, 0.5, bW*0.75, mColL);
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(4+bL*0.2, 0, bL*0.6, 0.5, aCol, 0.3);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(4+bL*0.1, 0, bL*0.8, 0.5, aCol, 0.25);
                if (bd[2] === 'tape') r(4+bL*0.3, 0, 0.5, bW, scTape, 0.4);
                r(-1, 2.5, 2.5, 4, wCol); r(-1, 2, 2, 1, bColD);
                if (sd[2] !== 'none') {
                    const sW = 2 * sd[0];
                    if (sd[2] === 'wire' || sd[2] === 'skel') { r(-4, 0, sW, 0.5, mCol); r(-4-sW*0.3, -0.5, 0.5, 2, mCol); }
                    else if (sd[2] === 'float') { r(-5, 0, sW*0.7, 1.5, mCol); }
                    else { r(-4, 0, sW, 2, sd[2]==='wrap'||sd[2]==='carved' ? wCol : mCol); }
                }
                const mgW = 1.5 * md[0], mgH = 3 * md[1];
                r(-1, 4, mgW, mgH, mCol); r(-1, 4+mgH*0.3, mgW*0.7, mgH*0.5, bColD, 0.3);
                if (md[2] === 'round') c(-1, 4+mgH/2, mgW*0.4, mColL, 0.3);
                if (md[2] === 'tape') r(-1, 4+mgH*0.4, mgW+0.5, 0.5, scTape, 0.4);
                if (md[2] === 'crystal') r(-1, 4+mgH*0.3, mgW*0.5, mgH*0.3, aCol, 0.25);
                const mzX = 4 + bL + 0.5, mzS = 1.5 * zd[0]; drawMuzzle(mzX, mzS, bW);
                if (!isScrap && !isEnergy) r(0, -1, 0.5, 0.5, aCol, 0.5);
                gripX = cx + 0; gripY = cy + 0;

            } else if (sprite === 'heavy_rifle') {
                r(-1, 0, 9, 3.5, bCol); r(-1, 0, 8, 3, bColL); r(1, -2.5, 5, 1.5, bColD); r(0, -2.5, 1, 2, mCol);
                const bL = 5 * bd[0], bW = 2.5 * bd[1];
                r(5 + bL/2, 0, bL, bW, mCol); r(5 + bL, 0, 1.5, bW*0.8, mColL);
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(5+bL*0.2, 0, bL*0.6, 0.5, aCol, 0.3);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(5+bL*0.1, 0, bL*0.8, 0.5, aCol, 0.25);
                if (bd[2] === 'tape') r(5+bL*0.3, 0, 1, bW, scTape, 0.35);
                r(5, 2, 0.5, 2.5, mCol, 0.6); r(3.5, 2, 0.5, 2, mCol, 0.6);
                if (sd[2] !== 'none') {
                    const sW = 4 * sd[0], sH = 3.5 * sd[1];
                    const sCol = (sd[2]==='wrap'||sd[2]==='carved'||sd[2]==='solid'||sd[2]==='plank') ? wCol : mCol;
                    r(-6, 0, sW, sH, sCol); r(-7.5, 0, 1.5, sH + 0.5, bColD);
                    if (sd[2] === 'wire' || sd[2] === 'skel') { r(-6, 0, sW, 0.5, mCol); r(-7.5, 0, 0.5, sH, mCol); }
                    if (sd[2] === 'wrap') r(-6-sW*0.3, 0, sW*0.4, sH*0.7, scTape, 0.3);
                    if (sd[2] === 'seamless') r(-6, 0, sW, sH, bCol);
                }
                const mgW = 4 * md[0], mgH = 3 * md[1];
                if (md[2] === 'top') { r(-1, -4, mgW, mgH*0.7, mCol); }
                else { r(-1, 3, mgW, mgH, bColD); r(-1, 3.5, mgW*0.9, mgH*0.8, mCol); }
                if (md[2] === 'round') c(-1, 3+mgH/2, mgW*0.35, mColL, 0.3);
                if (md[2] === 'crystal') { r(-1, 3, mgW, mgH, bColD); r(-1, 3+mgH*0.25, mgW*0.5, mgH*0.5, aCol, 0.2); }
                const mzX = 5 + bL + 0.5, mzS = 2 * zd[0]; drawMuzzle(mzX, mzS, bW);
                if (!isScrap && !isEnergy) { r(-1, -2, 2, 0.5, aCol, 0.4); r(-3, 1, 0.5, 1, aCol, 0.3); }
                if (isEnergy) r(0, -0.5, 0.5, 2.5, aCol, 0.12);
                gripX = cx + 0; gripY = cy + 0;

            } else if (sprite === 'handcannon') {
                r(0, 0, 7, 3, bCol); r(1, -1.5, 5, 1.5, bColD); r(2, -2, 2, 0.5, mColL, 0.4);
                r(1, 0, 2.5, 3.5, mCol); c(1.5, 0, 1.5, mColL, 0.5); c(1.5, 0, 0.5, bColD, 0.4);
                r(-0.5, -2.5, 1, 1.5, mCol); r(-0.5, -3, 1.5, 0.5, mColL); r(0, 2, 1.5, 1.5, mCol, 0.5);
                const bL = 3 * bd[0], bW = 2 * bd[1];
                r(3.5 + bL/2, -0.5, bL, bW, mCol); r(3.5 + bL, -0.5, 1, bW*0.75, mColL);
                if (bd[2] === 'glow' || bd[2] === 'glow_pulse') r(3.5+bL*0.2, -0.5, bL*0.6, 0.5, aCol, 0.3);
                if (bd[2] === 'seam' || bd[2] === 'seam_warp' || bd[2] === 'seam_rings') r(3.5+bL*0.1, -0.5, bL*0.8, 0.5, aCol, 0.25);
                r(-2, 2, 2.5, 4, wCol); r(-2, 1.5, 2, 1, bCol); r(-2, 5.5, 2.5, 1, mCol);
                if (sd[2] === 'wrap') r(-2, 3, 2, 2, scTape, 0.3);
                if (sd[2] === 'carved') r(-2, 3.5, 0.5, 1.5, aCol, 0.2);
                if (md[2] === 'crystal') { r(-1, 3, 1.5, 1, bColD); r(-1, 3, 1, 0.5, aCol, 0.3); }
                if (md[2] === 'phase') r(1.5, 0, 2.5, 3.5, aCol, 0.08);
                const mzX = 3.5 + bL + 0.5, mzS = 1.5 * zd[0]; drawMuzzle(mzX, mzS, bW);
                if (!isScrap && !isEnergy) r(-2, 3, 0.5, 2, aCol, 0.35);
                if (isEnergy) r(0, -0.5, 0.5, 2, aCol, 0.12);
                gripX = cx - 1; gripY = cy + 1;

            } else if (sprite === 'sniper') {
                r(-1, 0, 7, 2.5, bCol); r(1, 1.5, 1, 2, mCol); r(1.5, 2, 1.5, 0.5, mColL); r(-1, 1.5, 1.5, 1, mCol, 0.6);
                r(2, -3, 5, 2, bColD); r(2, -3, 4.5, 1.5, mColL);
                r(-0.5, -3, 1, 1.5, mCol, 0.6); r(5, -3, 1, 1.5, mCol, 0.6); r(4, -3, 1, 1, aCol, 0.5);
                const bL = 7 * bd[0], bW = 1.5 * bd[1];
                r(3 + bL*0.4, 0, bL, bW, mCol); r(3 + bL*0.7, 0, bL*0.4, bW*0.7, mColL);
                drawBarrelDetail(3, bL, bW);
                if (sd[2] !== 'none') {
                    const sW = 3 * sd[0], sH = 2 * sd[1];
                    const sCol = (sd[2]==='wrap'||sd[2]==='carved'||sd[2]==='solid'||sd[2]==='plank') ? wCol : mCol;
                    r(-5, 0.5, sW, sH, sCol); r(-7, 0.5, 2, sH + 0.5, bColD); r(-6, 2, 1.5, 1, mCol);
                    if (sd[2] === 'wire' || sd[2] === 'skel') { r(-5, 0.5, sW, 0.5, mCol); r(-7, 0.5, 0.5, sH, mCol); }
                    if (sd[2] === 'wrap') r(-5-sW*0.3, 0.5, sW*0.4, sH*0.7, scTape, 0.3);
                    if (sd[2] === 'seamless') r(-5, 0.5, sW, sH, bCol);
                }
                const mgW = 2 * md[0], mgH = 2 * md[1];
                r(0, 2.5, mgW, mgH, bColD);
                if (md[2] === 'round') c(0, 2.5+mgH/2, mgW*0.35, mColL, 0.3);
                if (md[2] === 'crystal') r(0, 2.5+mgH*0.25, mgW*0.5, mgH*0.4, aCol, 0.25);
                const mzX = 3 + bL + 0.5, mzS = 2 * zd[0]; drawMuzzle(mzX, mzS, bW);
                if (!isScrap && !isEnergy) { r(2, -1, 0.5, 0.5, aCol, 0.4); r(-5, 1, 1.5, 0.5, aCol, 0.3); }
                if (isEnergy) r(0, -0.5, 0.5, 2, aCol, 0.1);
                gripX = cx + 0; gripY = cy + 0;
            }
            // Fallback pistol — simple shape
            if (!['rifle','mini','heavy_rifle','handcannon','sniper'].includes(sprite)) {
                r(0, 0, 5, 2.5, bCol); r(2, 0, 3, 2, mCol); r(3.5, 0, 1, 1.5, mColL);
                r(-1, 2, 2, 3, wCol); r(-1, 1.5, 1.5, 1, bColD);
                gripX = cx + 0; gripY = cy + 0;
            }
            
        } else if (isMelee) {
            // === MELEE PALETTE ===
            const foundry = item.foundry ? CONFIG.foundries[item.foundry] : null;
            const p = foundry ? foundry.palette : null;
            const isScrap = !foundry;
            const isEnergy = foundry && (item.foundry === 'blackreach' || item.foundry === 'cephalon');
            const mBCol  = p ? parseInt(p.body.replace('#',''),16)      : 0x5a5248;
            const mACol  = p ? parseInt(p.accent.replace('#',''),16)    : 0x888888;
            const mMCol  = p ? parseInt(p.metal.replace('#',''),16)     : 0x6a6a6a;
            const mMColL = p ? parseInt(p.metalLight.replace('#',''),16): 0x8a8a8a;
            const mDCol  = p ? parseInt(p.detail.replace('#',''),16)    : 0x4a4a4a;
            const mWood  = isScrap ? 0x5a4228 : (isEnergy ? mBCol : 0x6a4a2a);
            const mpc = item.partConfig || { handle: 'wood', head: 'rusty', guard: 'none' };
            const _mhV = 1 + _sOff(10) * 0.08, _mhwV = 1 + _sOff(11) * 0.06;
            const _mhdV = 1 + _sOff(12) * 0.07, _mgV = 1 + _sOff(13) * 0.05;
            const hIsWrap = ['wrapped','cord','tape'].includes(mpc.handle);
            const hIsOrganic = ['bone','tendril','organic'].includes(mpc.handle);
            const hIsCrystal = ['crystal','slim_crystal'].includes(mpc.handle);
            const hIsMetal = ['pipe','rebar','machined','contoured','engraved','polymer','rubber'].includes(mpc.handle);
            const hIsCarved = mpc.handle === 'carved';
            const hCol = hIsOrganic ? 0x8a7a6a : hIsCrystal ? mACol : hIsMetal ? mMCol : mWood;
            const headGlow = ['energy_edge','focused_edge','harmonic','overcharged','phase_edge','fold','void_edge','leech'].includes(mpc.head);
            const headPrecision = ['alloy','steel','tempered','hardened','filed'].includes(mpc.head);
            const darkM = 0x5a5a5a;
            
            if (sprite === 'blade') {
                const bLen = (headGlow ? 9 : 8) * _mhdV;
                const bladeCol = headGlow ? mACol : headPrecision ? mMColL : 0xbbbbbb;
                r(0, -3, 2 * _mhwV, bLen, bladeCol);
                if (headGlow) { r(0, -3 - bLen/2 + 1, 1.5, 2, mACol, 0.7); r(0, -3 - bLen/2, 1, 1.5, 0xffffff, 0.3); }
                else r(0, -6.5, 1.5, 2, 0xdddddd);
                if (!headGlow) r(0.8, -3, 0.5, bLen * 0.7, 0xdddddd, 0.4);
                if (mpc.guard !== 'none') r(0, 1, 4 * _mgV, 1.5, mMCol);
                r(0, 3.5, 2.5 * _mhwV, 4 * _mhV, hCol);
                if (hIsWrap) r(0, 3.5, 2 * _mhwV, 3 * _mhV, 0x8a8a6a, 0.4);
                r(0, 6, 3 * _mhwV, 1.5, hIsCrystal ? mACol : mMCol);
                gripX = cx; gripY = cy + 5; // grip at handle bottom
                
            } else if (sprite === 'blunt') {
                r(0, 0, 2.5 * _mhwV, 12 * _mhV, hCol);
                if (hIsWrap) r(0, 2, 2 * _mhwV, 5 * _mhV, 0x8a8a6a, 0.4);
                if (headGlow) { r(0, -5, 4 * _mhdV, 4 * _mhdV, mBCol); r(0, -5, 3 * _mhdV, 3 * _mhdV, mACol, 0.25); }
                else if (headPrecision) { r(0, -5, 4 * _mhdV, 4 * _mhdV, mMCol); r(0, -6, 3 * _mhdV, 1.5, mMColL); }
                else { r(0, -5, 4 * _mhdV, 4 * _mhdV, darkM); r(0, -6, 3 * _mhdV, 1.5, mMColL); }
                gripX = cx; gripY = cy + 5;
                
            } else {
                // heavy — axe/hammer
                r(0, 1, 2.5 * _mhwV, 10 * _mhV, hCol);
                if (hIsWrap) r(0, 3, 2 * _mhwV, 4 * _mhV, 0x8a8a6a, 0.4);
                if (headGlow) { r(0, -4, 6 * _mhdV, 4 * _mhdV, mBCol); r(3 * _mhdV, -4, 2 * _mhdV, 3.5 * _mhdV, mACol, 0.3); }
                else if (headPrecision) { r(0, -4, 6 * _mhdV, 4 * _mhdV, mMCol); r(3 * _mhdV, -4, 2 * _mhdV, 3 * _mhdV, mMColL); }
                else { r(0, -4, 6 * _mhdV, 4 * _mhdV, mMCol); r(3 * _mhdV, -4, 2 * _mhdV, 3 * _mhdV, darkM); r(-1, -5, 2 * _mhdV, 1.5, 0xaaaaaa); }
                gripX = cx; gripY = cy + 5;
            }
            if (!isScrap && !isEnergy) {
                if (sprite === 'blade') r(0, 0.5, 0.5, 1, mACol, 0.35);
                else r(0, -4, 0.5, 1, mACol, 0.3);
            }
        }
        
        ctx.globalAlpha = 1;
        return { canvas, gripX, gripY, isWeapon, isMelee };
    },
    
    // Process equipment on death: strip non-soulbound items, consume soulbound charges
    // Returns { lost: [{name, category}], saved: [{name, category, remaining}] }
    processDeathEquipment(equipment) {
        if (!equipment) return { lost: [], saved: [] };
        const lost = [], saved = [];
        
        // === SOUL SURVIVOR CHECK ===
        // If any gear piece has Soul Survivor signature, protect ALL equipment this death
        let soulSurvivorItem = null;
        let soulSurvivorSig = null;
        ['weapon', 'melee', 'gear'].forEach(slot => {
            const item = equipment[slot];
            if (!item || soulSurvivorItem) return;
            if (item.signatureMod && item.signatureMod.effect === 'soulSurvivor') {
                soulSurvivorItem = item;
                soulSurvivorSig = item.signatureMod;
            }
        });
        
        if (soulSurvivorItem) {
            // Soul Survivor activates — protect everything, consume the signature
            soulSurvivorItem.signatureMod = null;
            ['weapon', 'melee', 'gear'].forEach(slot => {
                const item = equipment[slot];
                if (!item) return;
                saved.push({ name: item.name || slot, category: slot, remaining: -1, soulSurvivor: true });
            });
            return { lost, saved, soulSurvivorTriggered: true };
        }
        
        // Normal soulbound check per item
        ['weapon', 'melee', 'gear'].forEach(slot => {
            const item = equipment[slot];
            if (!item) return;
            const sbMod = item.mods ? item.mods.find(m => m.stat === 'soulbound' || m.id === 'soulbound') : null;
            if (sbMod && sbMod.value > 0) {
                // Soulbound protects the item — consume one charge
                sbMod.value--;
                if (sbMod.value <= 0) {
                    // Remove exhausted soulbound mod
                    item.mods = item.mods.filter(m => m !== sbMod);
                }
                saved.push({ name: item.name || slot, category: slot, remaining: sbMod.value });
            } else {
                // No soulbound — item is lost
                lost.push({ name: item.name || slot, category: slot });
                equipment[slot] = null;
            }
        });
        // Consumable always lost (unless Soul Survivor was active — handled above)
        if (equipment.consumable) {
            lost.push({ name: equipment.consumable.name || 'Consumable', category: 'consumable' });
            equipment.consumable = null;
        }
        return { lost, saved };
    }
};

