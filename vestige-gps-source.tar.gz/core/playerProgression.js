// Vestige GPS — PlayerProgression
// XP, leveling, perk system
// AudioManager is optional (rendering layer)

import { CONFIG } from "../data/config.js";
import { EventBus } from './eventBus.js';
import { Haptics } from "./haptics.js";
import { AudioManager } from '../client/audioManager.js';

export const PlayerProgression = {
    // Get current level from total XP
    getLevel(totalXP) {
        let level = 1;
        let xpNeeded = 0;
        while (level < CONFIG.leveling.maxLevel) {
            xpNeeded += CONFIG.leveling.xpForLevel(level);
            if (totalXP < xpNeeded) break;
            level++;
        }
        return Math.min(level, CONFIG.leveling.maxLevel);
    },
    

    
    // Award XP and check for level ups — returns { newXP, leveledUp, newLevel, rewards }
    awardXP(saveData, amount, source) {
        if (!saveData.player) saveData.player = {};
        const prevXP = saveData.player.totalXP || 0;
        const prevLevel = this.getLevel(prevXP);
        
        saveData.player.totalXP = prevXP + amount;
        const newLevel = this.getLevel(saveData.player.totalXP);
        saveData.player.level = newLevel;
        
        const result = { xpGained: amount, source, newXP: saveData.player.totalXP, leveledUp: false, newLevel, rewards: [] };
        
        if (newLevel > prevLevel) {
            result.leveledUp = true;
            EventBus.emit('player:levelUp', { level: state.level });
            Haptics.success();
            EventBus.emit('levelUp', { newLevel, prevLevel });
            // Collect milestone rewards for all levels gained
            for (let l = prevLevel + 1; l <= newLevel; l++) {
                const perLevel = CONFIG.leveling.levelRewards.perLevel;
                result.rewards.push({ type: 'stat', hp: perLevel.hp, slots: perLevel.inventorySlots, level: l });
                
                const milestone = CONFIG.leveling.levelRewards.milestones[l];
                if (milestone) {
                    result.rewards.push({ type: 'milestone', ...milestone, level: l });
                    if (!saveData.player.perks) saveData.player.perks = [];
                    if (!saveData.player.perks.includes(milestone.perk)) {
                        saveData.player.perks.push(milestone.perk);
                    }
                }
            }
        }
        
        return result;
    },
    
    // Check if player has a perk
    hasPerk(saveData, perkId) {
        return saveData.player && saveData.player.perks && saveData.player.perks.includes(perkId);
    }
};

// ============================================
// Consistent lighting: top/front lighter, sides darker.
// ============================================
