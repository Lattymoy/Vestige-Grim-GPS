// Vestige GPS — DOTManager
// DOT application to enemies
// Rendering (tint flashes, floating numbers, icons) delegated to renderer

import { CONFIG } from '../data/config.js';
import { ItemManager } from './itemManager.js';
import { CombatSystem } from './combatSystem.js';

export const DOTManager = {
    // Active DOTs: Map of target → [{ type, dmg, remaining, tickTimer, sourceId, icon }]
    _dots: new Map(),
    _renderer: null,

    /**
     * Initialize with a renderer implementation.
     * Renderer should implement:
     *   flashTint(scene, target, color, durationMs)
     *   floatingDamage(scene, target, dmg, color)
     *   renderDebuffIcons(scene, target, dots)
     *   clearIcons(target)
     */
    init(renderer) {
        DOTManager._renderer = renderer;
    },
    
    // Apply a DOT to a target (enemy or player object)
    apply(scene, target, type, totalDmg, durationMs, sourceId) {
        if (!target || !target.active) return;
        const cfg = CONFIG.dotTypes[type];
        if (!cfg) return;
        
        // One DOT of each type per source per target
        let dots = this._dots.get(target);
        if (!dots) { dots = []; this._dots.set(target, dots); }
        const existing = dots.find(d => d.type === type && d.sourceId === sourceId);
        if (existing) return; // Already applied from this source
        
        const ticks = Math.ceil(durationMs / cfg.tickInterval);
        const dmgPerTick = Math.round(totalDmg / ticks);
        
        dots.push({
            type, dmg: dmgPerTick, remaining: ticks, tickTimer: 0,
            tickInterval: cfg.tickInterval, sourceId: sourceId || 'unknown',
            color: cfg.color, name: cfg.name, durationMs
        });
        
        // Flash tint on application
        if (DOTManager._renderer) {
            DOTManager._renderer.flashTint(scene, target, cfg.color, 120);
        }
    },
    
    // Call every frame from scene update — processes all active DOTs
    update(scene, delta, killFn) {
        this._dots.forEach((dots, target) => {
            if (!target.active) { this._dots.delete(target); this._rendererClear(target); return; }
            
            let i = dots.length;
            while (i--) {
                const d = dots[i];
                d.tickTimer += delta;
                if (d.tickTimer >= d.tickInterval) {
                    d.tickTimer -= d.tickInterval;
                    d.remaining--;
                    
                    // Apply tick damage
                    if (target.hp !== undefined) {
                        // Enemy target
                        target.hp -= d.dmg;
                        // Visual feedback
                        if (DOTManager._renderer) {
                            DOTManager._renderer.flashTint(scene, target, d.color, 60);
                            DOTManager._renderer.floatingDamage(scene, target, d.dmg, d.color);
                        }
                        
                        if (target.hp <= 0 && killFn) killFn(target);
                    } else if (target === scene.player || target._isPlayer) {
                        // Player DOT — apply resist from gear + survivor marks
                        let dotDmg = d.dmg;
                        if (scene.state && scene.state.equipment) {
                            const eqs = scene._eqStats || ItemManager.getEquipmentStats(scene.state.equipment);
                            const resistMap = { burn: eqs.burnResist || 0, poison: eqs.poisonResist || 0, bleed: eqs.bleedResist || 0 };
                            const resist = resistMap[d.type] || 0;
                            if (resist > 0) dotDmg = Math.max(1, Math.round(dotDmg * (1 - resist / 100)));
                            // Survivor mark elemental resistance (flat additive, e.g. -0.10 = 10% less elemental resist)
                            const _elemResist = scene.state.survivorMods?.elementalResist || 0;
                            if (_elemResist !== 0) dotDmg = Math.max(1, Math.round(dotDmg * (1 - _elemResist)));
                        }
                        scene.state.health -= dotDmg;
                        if (scene.state.health <= 0) scene.state.health = 0;
                    }
                    
                    if (d.remaining <= 0) dots.splice(i, 1);
                }
            }
            if (dots.length === 0) { this._dots.delete(target); this._rendererClear(target); }
        });
    },
    
    // Render DOT icons above enemies — delegates to renderer
    renderEnemyDebuffs(scene) {
        if (!DOTManager._renderer) return;
        this._dots.forEach((dots, target) => {
            if (!target.active || target._isPlayer) return;
            DOTManager._renderer.clearIcons(target);
            if (dots.length === 0) return;
            DOTManager._renderer.renderDebuffIcons(scene, target, dots);
        });
    },

    _rendererClear(target) {
        if (DOTManager._renderer) DOTManager._renderer.clearIcons(target);
    },
    
    // Check if target has a specific DOT type
    has(target, type) {
        const dots = this._dots.get(target);
        return dots ? dots.some(d => d.type === type) : false;
    },
    
    // Clear all DOTs (scene cleanup)
    reset() {
        if (DOTManager._renderer) {
            this._dots.forEach((dots, target) => DOTManager._renderer.clearIcons(target));
        }
        this._dots.clear();
    },
    

};

// ============================================
// SIGNATURE EFFECTS — Processes T5/T6 unique mod effects
// Separated from CombatSystem for cleanliness
// ============================================
