// Vestige GPS — RouteGenerator
// Node graph generation with biome/difficulty/boss assignment
// NOTE: In GPS version, this becomes the GPS-to-node mapper.
// The reach/branch/boss-gate structure still applies.

import { CONFIG } from '../data/config.js';
import { Utils } from './utils.js';

// Stub: CRTTypewriter ref removed (UI-layer only)
const CRTTypewriter = { stopAll() {} };

export const RouteGenerator = {
    // Node type definitions (visual + gameplay)
    NODE_TYPES: {
        safehouse:   { name: 'Safehouse',   color: 0x44aa44 },
        exploration: { name: 'Exploration', color: 0xaa8844 },
        boss:        { name: 'Boss Gate',   color: 0xcc2244 },
        haven:       { name: 'Safe Haven',  color: 0x4488cc }
    },

    // Encounter types that can occur on edges
    ENCOUNTER_TYPES: {
        scavenge:  { name: 'Scavenge',         color: 0xaa44aa, weight: 40 },
        defense:   { name: 'Defense Stand',    color: 0xcc8844, weight: 20 },
        rescue:    { name: 'Survivor Rescue',  color: 0x44cc66, weight: 15 },
        anomaly:   { name: 'Anomaly',          color: 0x44aaaa, weight: 5 }
    },

    // Generate a complete reach
    // Returns { nodes:{}, edges:[], meta:{} }
    generateReach(seed, reachNum, biome) {
        const rng = Utils.createRNG(seed + reachNum * 7919);
        const random = () => rng();
        const randomInt = (min, max) => Math.floor(random() * (max - min + 1)) + min;
        const randomFromArray = (arr) => arr[Math.floor(random() * arr.length)];

        const nodes = {};
        const edges = [];

        // Time of day cycles through columns
        const timesOfDay = ['dawn', 'midday', 'dusk', 'night'];
        const startTimeIdx = randomInt(0, 3);

        // Columns in this reach — always 6 exploration stops + boss
        const colCount = 6;

        // Vertical layout
        const roadY = 200;        // center Y in CRT coordinate space
        const laneSpread = 140;    // vertical spread for node lanes

        // ── Safehouse / Haven anchor (column 0) ──
        const anchorType = reachNum === 1 ? 'safehouse' : 'haven';
        const anchorId = reachNum === 1 ? 'safehouse' : `haven_reach${reachNum}`;
        nodes[anchorId] = {
            id: anchorId,
            type: anchorType,
            name: anchorType === 'safehouse' ? 'Safehouse' : 'Safe Haven',
            col: 0,
            y: roadY,
            reach: reachNum,
            biome: biome,
            timeOfDay: timesOfDay[startTimeIdx],
            discovered: true,
            completed: true
        };

        let nodeCounter = (reachNum - 1) * 100 + 1;

        // ── Exploration columns ──
        for (let c = 0; c < colCount; c++) {
            const col = c + 1;
            const nodesInCol = randomInt(2, 3);
            const colNodes = [];
            const posInReach = c / colCount;

            for (let i = 0; i < nodesInCol; i++) {
                const laneOffset = (i - (nodesInCol - 1) / 2) * (laneSpread / Math.max(1, nodesInCol - 1));
                const y = roadY + laneOffset + randomInt(-15, 15);

                // Pick location type weighted by biome
                const locationType = this._pickLocationType(biome, random);
                const locationName = this._generateLocationName(locationType, randomFromArray);

                // Story chance from location config
                const locDef = CONFIG.locations[locationType];
                const hasStoryEvent = locDef && random() < (locDef.storyChance || 0);

                // Difficulty scales with reach and position
                const difficulty = this._getDifficulty(reachNum, posInReach, random);

                const id = `r${reachNum}_n${nodeCounter++}`;
                nodes[id] = {
                    id: id,
                    type: 'defense',
                    name: locationName,
                    locationType: locationType,
                    hasStoryEvent: hasStoryEvent,
                    col: col,
                    y: y,
                    reach: reachNum,
                    biome: random() < 0.15 ? randomFromArray(['grassy', 'barren', 'apocalyptic']) : biome,
                    difficulty: difficulty,
                    timeOfDay: timesOfDay[(startTimeIdx + col) % 4],
                    discovered: false,
                    completed: false
                };
                colNodes.push(id);
            }

            // ── Edges: connect every prev node to every node in this column ──
            // With 2-3 nodes per column, full connectivity gives the player all choices
            const prevCol = col - 1;
            const prevNodes = Object.values(nodes).filter(n => n.col === prevCol);

            prevNodes.forEach(fromNode => {
                colNodes.forEach(toId => {
                    edges.push(this._generateEdge(fromNode.id, toId, reachNum, col, colCount, random, randomInt));
                });
            });
        }

        // ── Boss gate (final column) ──
        const bossCol = colCount + 1;
        const bossId = `boss_reach${reachNum}`;
        const bossNames = ['The Hollow', 'The Swarm Mother', 'Cube Phantom', 'Iron Revenant', 'Void Tesseract'];
        const bossEntityTypes = ['warden', 'swarmQueen', 'phantom', 'ironclad', 'cubeAnomaly'];

        nodes[bossId] = {
            id: bossId,
            type: 'boss',
            name: bossNames[(reachNum - 1) % 5] || 'Boss Gate',
            bossEntityType: bossEntityTypes[(reachNum - 1) % 5],
            col: bossCol,
            y: roadY,
            reach: reachNum,
            biome: biome,
            difficulty: this._getDifficulty(reachNum, 1.0, random),
            timeOfDay: timesOfDay[(startTimeIdx + bossCol) % 4],
            discovered: false,
            completed: false
        };

        // Edges from last exploration column to boss
        const lastColNodes = Object.values(nodes).filter(n => n.col === bossCol - 1).map(n => n.id);
        lastColNodes.forEach(fromId => {
            const edge = this._generateEdge(fromId, bossId, reachNum, bossCol, colCount, random, randomInt);
            edge.fuel = Math.max(edge.fuel, 5);  // boss approach always costs fuel
            edges.push(edge);
        });

        // ── Assign X positions (spacing by fuel cost) ──
        const nodeSpacing = 100;  // base spacing in CRT map units
        const nodesByCol = {};
        Object.values(nodes).forEach(n => {
            if (!nodesByCol[n.col]) nodesByCol[n.col] = [];
            nodesByCol[n.col].push(n);
        });

        let cumX = 40;  // starting X
        const maxCol = Math.max(...Object.keys(nodesByCol).map(Number));
        for (let col = 0; col <= maxCol; col++) {
            const nodesInCol = nodesByCol[col];
            if (!nodesInCol) continue;

            if (col > 0) {
                // Space based on average fuel — fuel DOMINATES distance
                const incomingEdges = edges.filter(e => nodes[e.to] && nodes[e.to].col === col);
                const avgFuel = incomingEdges.length > 0
                    ? incomingEdges.reduce((s, e) => s + e.fuel, 0) / incomingEdges.length
                    : 8;
                const fuelDist = 20 + avgFuel * 8;
                // Minimum gap from safehouse (col 0→1) is larger
                const minGap = col === 1 ? 120 : 60;
                cumX += Math.max(minGap, fuelDist);
            }

            nodesInCol.forEach(n => {
                n.x = cumX + randomInt(-12, 12);
            });
        }

        const totalWidth = cumX + nodeSpacing;

        return {
            nodes: nodes,
            edges: edges,
            meta: {
                seed: seed,
                reach: reachNum,
                biome: biome,
                colCount: colCount,
                totalWidth: totalWidth,
                bossId: bossId,
                anchorId: anchorId
            }
        };
    },

    // Generate edge data between two nodes
    _generateEdge(fromId, toId, reach, col, totalCols, random, randomInt) {
        // Fuel cost: base 5-12, scales with reach
        const baseFuel = randomInt(3, 16);
        const reachBonus = Math.floor((reach - 1) * 2.5);
        const fuel = baseFuel + reachBonus;

        // Encounters disabled — edge system preserved for future traversal events
        const encounters = [];
        const encounterChance = 0;

        // Danger rating: kept for visual variety on edges
        const posRatio = col / (totalCols + 1);
        const dangerRoll = 0.15 + posRatio * 0.25 + (reach - 1) * 0.08;
        const danger = dangerRoll < 0.20 ? 0
                     : dangerRoll < 0.35 ? 1
                     : dangerRoll < 0.50 ? 2 : 3;

        return {
            from: fromId,
            to: toId,
            fuel: fuel,
            encounters: encounters,
            encounterChance: parseFloat(encounterChance.toFixed(2)),
            danger: danger
        };
    },

    // Pick encounter type weighted by reach
    _pickEncounterType(reach, random) {
        const types = this.ENCOUNTER_TYPES;
        const weights = {};
        Object.entries(types).forEach(([id, def]) => {
            weights[id] = def.weight;
        });
        // Scale anomaly up with reach
        weights.anomaly = types.anomaly.weight + (reach - 1) * 5;
        // Rescue chance increases slightly with reach
        weights.rescue = types.rescue.weight + (reach - 1) * 2;

        const total = Object.values(weights).reduce((s, w) => s + w, 0);
        let roll = random() * total;
        for (const [id, w] of Object.entries(weights)) {
            roll -= w;
            if (roll <= 0) return id;
        }
        return 'scavenge';
    },

    // Pick location type weighted by biome
    _pickLocationType(biome, random) {
        const locs = CONFIG.locations;
        const entries = Object.entries(locs).filter(([k, v]) => v.category === 'scavenge' && v.biomeWeight && v.biomeWeight[biome] > 0);
        const total = entries.reduce((s, [k, v]) => s + (v.biomeWeight[biome] || 0), 0);
        let roll = random() * total;
        for (const [key, loc] of entries) {
            roll -= (loc.biomeWeight[biome] || 0);
            if (roll <= 0) return key;
        }
        return 'house';
    },

    // Generate a location name from the location config
    _generateLocationName(locationType, randomFromArray) {
        const loc = CONFIG.locations[locationType];
        if (!loc || !loc.names) return locationType;
        const prefix = randomFromArray(loc.names.prefixes);
        const suffix = randomFromArray(loc.names.suffixes);
        return `${prefix} ${suffix}`;
    },

    // Difficulty based on reach + position
    _getDifficulty(reach, posInReach, random) {
        const base = reach - 1;
        const diffs = ['Normal', 'Hard', 'Extreme', 'Deadly'];
        let idx = Math.min(3, base + (posInReach > 0.7 ? 1 : 0));
        if (random() < 0.3 && idx > 0) idx--;
        if (random() < 0.15 && idx < 3) idx++;
        return diffs[idx];
    },

    // Calculate total fuel for a planned route (array of node IDs)
    calculateRouteFuel(route, edges) {
        let total = 0;
        for (let i = 0; i < route.length - 1; i++) {
            const edge = edges.find(e => e.from === route[i] && e.to === route[i + 1]);
            if (edge) total += edge.fuel;
        }
        return total;
    },

    // Get all valid next nodes from a given node
    getNextNodes(nodeId, edges) {
        return edges.filter(e => e.from === nodeId).map(e => e.to);
    },

    // Create a locked route data structure for saveData
    createActiveRoute(seed, reachNum, biome, selectedNodeIds, reachData) {
        const routeEdges = [];
        for (let i = 0; i < selectedNodeIds.length - 1; i++) {
            const edge = reachData.edges.find(e => e.from === selectedNodeIds[i] && e.to === selectedNodeIds[i + 1]);
            if (edge) routeEdges.push(edge);
        }

        return {
            seed: seed,
            reach: reachNum,
            biome: biome,
            nodes: selectedNodeIds,
            edges: routeEdges,
            totalFuel: this.calculateRouteFuel(selectedNodeIds, reachData.edges),
            currentStep: 0,
            status: 'locked'  // locked → active → complete
        };
    }
};

// ============================================
// INTERACT HIGHLIGHT — Simple pulsing dot on nearby interactables
// ============================================
// ============================================
// CRT TYPEWRITER — Character-by-character text reveal with cursor
// Usage: CRTTypewriter.type(scene, textObj, { speed, onComplete, sound })
// ============================================
