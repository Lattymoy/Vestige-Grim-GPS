// Vestige GPS — SignatureEffects
// Foundry weapon signature abilities
// Pure logic + renderer bridge for visual feedback
// Rendering: call SignatureEffects.init(renderer) with visual implementation

import { CONFIG } from '../data/config.js';
import { CombatSystem } from './combatSystem.js';
import { DOTManager } from './dotManager.js';
import { ItemManager } from './itemManager.js';
import { EnemyManager } from './enemyManager.js';

// Helpers — inline Phaser.Math replacements
const _dist = (x1, y1, x2, y2) => { const dx = x2 - x1, dy = y2 - y1; return Math.sqrt(dx * dx + dy * dy); };
const _angle = (x1, y1, x2, y2) => Math.atan2(y2 - y1, x2 - x1);
const _now = (scene) => (scene.time ? scene.time.now : Date.now());

export const SignatureEffects = {
    _cooldowns: {},
    _renderer: null,

    /**
     * Set renderer for signature visual feedback.
     * Renderer should implement:
     *   floatingText(scene, x, y, text, opts) — { color, fontSize, bold }
     *   shackleVFX(scene, originX, originY, radius, enemies, duration)
     *   ricochetTracer(scene, x1, y1, x2, y2)
     *   phaseShiftVisual(scene, duration)
     *   hardenedVisual(scene)
     *   healingCubeSpawn(scene, x, y, opts) — complex entity, returns cleanup fn
     *   delayedCall(scene, ms, callback)
     */
    init(renderer) {
        SignatureEffects._renderer = renderer;
    },

    isReady(scene, effectId, cooldownMs) {
        const key = (scene.scene ? scene.scene.key : 'unknown') + '_' + effectId;
        const last = this._cooldowns[key] || 0;
        return (_now(scene) - last) >= cooldownMs;
    },
    
    trigger(scene, effectId, cooldownMs) {
        const key = (scene.scene ? scene.scene.key : 'unknown') + '_' + effectId;
        this._cooldowns[key] = _now(scene);
    },
    

    
    // Blood Pact: build stack on any damage taken (called from all damage paths)
    buildBloodPactStack(scene) {
        const eq = scene.state?.equipment;
        const wAug = eq?.weapon?.augment;
        const mAug = eq?.melee?.augment;
        const bp = (wAug?.relicAbility === 'bloodPact' ? wAug : null) || (mAug?.relicAbility === 'bloodPact' ? mAug : null);
        if (!bp) return;
        scene._bloodPactStacks = Math.min(5, (scene._bloodPactStacks || 0) + 1);
        scene._bloodPactDmgBonus = scene._bloodPactStacks * 4;
        scene._bloodPactResist = scene._bloodPactStacks * 3;
        scene._bloodPactLastHit = _now(scene);
        if (scene._bloodPactStacks >= 2 && SignatureEffects._renderer) {
            SignatureEffects._renderer.floatingText(scene, scene.player.x, scene.player.y - 25,
                `PACT x${scene._bloodPactStacks}`, { color: '#ff4466', fontSize: 9, bold: true });
        }
    },
    
    // === GUN SIGNATURE HOOKS (called from CombatSystem.shoot) ===
    
    // Nomad: distance-based damage bonus (returns multiplier)
    calcNomadBonus(sig, playerX, playerY, targetX, targetY) {
        const dist = _dist(playerX, playerY, targetX, targetY);
        const maxDist = 200; // Full bonus at 200+ px
        const pct = Math.min(1, dist / maxDist) * (sig.value / 100);
        return 1 + pct;
    },
    
    // Berserker: low-HP damage bonus (returns multiplier)
    calcBerserkerBonus(sig, health, maxHealth) {
        if (health >= maxHealth * 0.5) return 1;
        const hpPct = health / maxHealth;
        const bonus = (sig.value / 100) * (1 - hpPct * 2); // Max at 0 HP
        return 1 + bonus;
    },
    
    // Ricochet: bounce bullet to nearest enemy
    doRicochet(scene, bullet, hitEnemy, dmg, sig) {
        if (!scene.enemies) return;
        let nearest = null, nd = 200;
        scene.enemies.getChildren().forEach(e => {
            if (!e.active || e === hitEnemy) return;
            const d = _dist(hitEnemy.x, hitEnemy.y, e.x, e.y);
            if (d < nd) { nd = d; nearest = e; }
        });
        if (nearest) {
            const bounceDmg = Math.round(dmg * sig.value / 100);
            // Visual: tracer line
            if (SignatureEffects._renderer) {
                SignatureEffects._renderer.ricochetTracer(scene, hitEnemy.x, hitEnemy.y, nearest.x, nearest.y);
            }
            // Apply damage
            CombatSystem.damageEnemy(scene, nearest, bounceDmg, 'ricochet', scene.player, scene.state, scene.state.equipment);
        }
    },
    
    // === MELEE SIGNATURE HOOKS (called from CombatSystem.melee) ===
    
    // Finisher: instant kill below threshold
    checkFinisher(sig, enemy) {
        if (!enemy.maxHp) return false;
        return enemy.hp > 0 && enemy.hp <= enemy.maxHp * (sig.value / 100);
    },
    
    // Vampiric: heal on kill + chance on hit
    doVampiricHit(scene, state, equipment) {
        // 15% chance to heal 1HP on hit
        if (Math.random() < 0.15) {
            const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(equipment).maxHealth || 0);
            state.health = Math.min(maxHp, state.health + 1);
        }
    },
    
    doVampiricKill(scene, state, equipment, sig) {
        const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(equipment).maxHealth || 0);
        const heal = sig.value || 10;
        state.health = Math.min(maxHp, state.health + heal);
        if (SignatureEffects._renderer) {
            SignatureEffects._renderer.floatingText(scene, scene.player.x, scene.player.y - 20,
                `+${heal}`, { color: '#44ff44', fontSize: 11 });
        }
    },
    
    // Reaper: chance to apply Bleed
    tryReaper(scene, enemy, sig) {
        if (Math.random() < 0.25) { // 25% chance
            DOTManager.apply(scene, enemy, 'bleed', sig.value || 15, sig.dotDuration || 5000, 'reaper');
        }
    },
    
    // === BANE HOOKS ===
    
    // Shackled: power charge melee (Warden)
    doShackled(scene, enemy, sig) {
        if (!this.isReady(scene, 'shackled', sig.cooldown || 15000)) return false;
        this.trigger(scene, 'shackled', sig.cooldown || 15000);
        
        const shackleDur = (sig.value || 5) * 1000;
        const shackleRadius = 80;
        
        // Find enemies in range
        const affected = [];
        if (scene.enemies) {
            scene.enemies.getChildren().forEach(e => {
                if (!e.active || e === enemy) return;
                const d = _dist(enemy.x, enemy.y, e.x, e.y);
                if (d < shackleRadius) {
                    e._staggered = true;
                    if (e.body) e.body.setVelocity(0, 0);
                    affected.push(e);
                }
            });
        }
        
        // Visual + timed unshackle via renderer
        if (SignatureEffects._renderer) {
            SignatureEffects._renderer.shackleVFX(scene, enemy.x, enemy.y, shackleRadius, affected, shackleDur);
        } else {
            // Headless fallback: just clear stagger after duration
            setTimeout(() => { affected.forEach(e => { if (e.active) e._staggered = false; }); }, shackleDur);
        }
        return true;
    },
    
    // Parasitic Rounds: auto-load poison bullets (Swarm Queen)
    updateParasiticRounds(scene, state, sig) {
        if (!this.isReady(scene, 'parasitic', sig.cooldown || 10000)) return;
        this.trigger(scene, 'parasitic', sig.cooldown || 10000);
        
        state._parasiticRounds = (state._parasiticRounds || 0) + (sig.value || 10);
        if (SignatureEffects._renderer) {
            SignatureEffects._renderer.floatingText(scene, scene.player.x, scene.player.y - 25,
                `+${sig.value} PARASITIC`, { color: '#44cc44', fontSize: 9, bold: true });
        }
    },
    
    // Consume a parasitic round on bullet hit — returns true if consumed
    consumeParasiticRound(scene, state, enemy) {
        if (!state._parasiticRounds || state._parasiticRounds <= 0) return false;
        state._parasiticRounds--;
        // Heal 2HP
        const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(state.equipment).maxHealth || 0);
        state.health = Math.min(maxHp, state.health + 2);
        // Apply poison DOT
        DOTManager.apply(scene, enemy, 'poison', 10, 5000, 'parasitic');
        return true;
    },
    
    // Phase Shift: invisibility on dodge (Phantom)
    doPhaseShift(scene, sig) {
        if (!this.isReady(scene, 'phaseShift', sig.cooldown || 10000)) return;
        this.trigger(scene, 'phaseShift', sig.cooldown || 10000);
        
        const dur = (sig.value || 5) * 1000;
        scene._phantomInvis = true;
        
        if (SignatureEffects._renderer) {
            SignatureEffects._renderer.phaseShiftVisual(scene, dur);
        } else {
            setTimeout(() => { scene._phantomInvis = false; }, dur);
        }
    },
    
    // Hardened: damage reduction on dodge (Ironclad)
    doHardened(scene, sig) {
        if (!this.isReady(scene, 'hardened', sig.cooldown || 25000)) return;
        this.trigger(scene, 'hardened', sig.cooldown || 25000);
        
        const dur = sig.duration || 5000;
        scene._hardenedActive = true;
        scene._hardenedReduction = (sig.value || 50) / 100;
        
        if (SignatureEffects._renderer) {
            SignatureEffects._renderer.floatingText(scene, scene.player.x, scene.player.y - 25,
                'HARDENED', { color: '#ccaa44', fontSize: 9, bold: true });
            SignatureEffects._renderer.delayedCall(scene, dur, () => {
                scene._hardenedActive = false;
                scene._hardenedReduction = 0;
            });
        } else {
            setTimeout(() => { scene._hardenedActive = false; scene._hardenedReduction = 0; }, dur);
        }
    },
    
    // Another World: healing cube on kill (Cube Anomaly)
    spawnHealingCube(scene, enemy, sig) {
        if (!this.isReady(scene, 'anotherWorld', sig.cooldown || 30000)) return;
        this.trigger(scene, 'anotherWorld', sig.cooldown || 30000);
        
        const maxHeal = sig.value || 100;
        const cx = enemy.x, cy = enemy.y;
        
        if (SignatureEffects._renderer) {
            // Delegate entire visual entity to renderer with logic callbacks
            SignatureEffects._renderer.healingCubeSpawn(scene, cx, cy, {
                maxHeal,
                getPlayerPos: () => ({ x: scene.player.x, y: scene.player.y }),
                heal: (amount) => {
                    const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(scene.state.equipment).maxHealth || 0);
                    const tick = Math.min(amount, maxHp - scene.state.health);
                    scene.state.health += tick;
                    return tick;
                },
                findNearestEnemy: (fromX, fromY, range) => {
                    if (!scene.enemies) return null;
                    let nearest = null, nd = range;
                    scene.enemies.getChildren().forEach(e => {
                        if (!e.active) return;
                        const dd = _dist(fromX, fromY, e.x, e.y);
                        if (dd < nd) { nd = dd; nearest = e; }
                    });
                    return nearest;
                },
                damageEnemy: (target, dmg) => {
                    CombatSystem.damageEnemy(scene, target, dmg, 'cubeExplosion', scene.player, scene.state, scene.state.equipment);
                }
            });
        }
        // If no renderer, healing cube just doesn't spawn (visual-only entity)
    },
    
    // === ACTIVE AUGMENT SYSTEM ===
    
    // Firepower: fire slug ammunition
    activateFirepower(scene, sig) {
        if (!this.isReady(scene, 'firepower', sig.cooldown || 15000)) return false;
        this.trigger(scene, 'firepower', sig.cooldown || 15000);
        
        const dur = sig.duration || 10000;
        scene.state._firepowerActive = true;
        if (SignatureEffects._renderer) {
            SignatureEffects._renderer.floatingText(scene, scene.player.x, scene.player.y - 25,
                'FIREPOWER', { color: '#ff6622', fontSize: 10, bold: true });
            SignatureEffects._renderer.delayedCall(scene, dur, () => { scene.state._firepowerActive = false; });
        } else {
            setTimeout(() => { scene.state._firepowerActive = false; }, dur);
        }
        return true;
    },
    
    // Sharpshooter: perfect accuracy + damage
    activateSharpshooter(scene, sig) {
        if (!this.isReady(scene, 'sharpshooter', sig.cooldown || 20000)) return false;
        this.trigger(scene, 'sharpshooter', sig.cooldown || 20000);
        
        const dur = sig.duration || 8000;
        scene.state._sharpshooterActive = true;
        scene.state._sharpshooterDmgBonus = (sig.value || 25) / 100;
        if (SignatureEffects._renderer) {
            SignatureEffects._renderer.floatingText(scene, scene.player.x, scene.player.y - 25,
                'SHARPSHOOTER', { color: '#44ccff', fontSize: 10, bold: true });
            SignatureEffects._renderer.delayedCall(scene, dur, () => {
                scene.state._sharpshooterActive = false;
                scene.state._sharpshooterDmgBonus = 0;
            });
        } else {
            setTimeout(() => { scene.state._sharpshooterActive = false; scene.state._sharpshooterDmgBonus = 0; }, dur);
        }
        return true;
    },
    
    // Kill tracking hook (called from EnemyManager.killEnemy)
    onKill(scene, enemy) {
        // Extend here for kill-triggered signature effects
    },
    
    // Reset all cooldowns (scene transition)
    reset() {
        this._cooldowns = {};
    }
};

// ============================================
// PLAYER STATUS ICONS — Active buff/debuff indicators below player sprite
// Small colored rectangles showing active effects
// ============================================
