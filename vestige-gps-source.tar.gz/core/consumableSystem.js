// Vestige GPS — ConsumableSystem
// Bandages, medkits, grenades, pylons, drinks
// Rendering decoupled via _renderer bridge
// Audio events emitted via EventBus

import { Blurbs } from './blurbs.js';
import { CONFIG } from '../data/config.js';
import { CombatSystem } from './combatSystem.js';
import { EventBus } from './eventBus.js';
import { Haptics } from './haptics.js';
import { ItemManager } from './itemManager.js';
import { GameScene } from '../client/scenes/GameScene.js';
import { InteriorScene } from '../client/scenes/InteriorScene.js';

// Inline math helpers
const _dist = (x1, y1, x2, y2) => { const dx = x2-x1, dy = y2-y1; return Math.sqrt(dx*dx + dy*dy); };
const _between = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

export const ConsumableSystem = {
    _zones: [],
    _channeling: null,
    _renderer: null,

    /**
     * Set renderer for consumable VFX.
     * Renderer should implement:
     *   instantHealVFX(scene, player, heal)
     *   createChannelBar(scene, player, color) -> { update(x, y, pct), destroy() }
     *   channelParticle(scene, x, y, color)
     *   channelComplete(scene, x, y, color)
     *   channelInterrupt(scene, x, y)
     *   regenVFX(scene, player, duration) -> { tickPulse(x, y), destroy() }
     *   regenSparkle(scene, x, y)
     *   grenadeVFX(scene, player, target, item, onLand, onDetonate)
     *   detonateVFX(scene, x, y, type, radius)
     *   createZoneVisuals(scene, x, y, radius, type, duration) -> { fade(pct), destroy() }
     *   pylonBurst(scene, x, y, color, radius)
     *   delayedCall(scene, ms, fn)
     *   timedEvent(scene, delay, repeat, fn) -> { remove() }
     *   audioHeal()
     */
    init(renderer) {
        ConsumableSystem._renderer = renderer;
    },

    use(scene, state, item, player) {
        if (!item || !item.effect) return false;
        if (item.effect === 'channelHeal' || item.effect === 'instantHeal') {
            if (scene._runStats) scene._runStats.timesHealed++;
        }
        switch (item.effect) {
            case 'channelHeal':
                return this.startChannel(scene, state, item, player);
            case 'instantHeal':
                return this.instantHeal(scene, state, item, player);
            case 'grenade':
                return this.throwGrenade(scene, state, item, player);
            case 'pylon':
                return this.startChannel(scene, state, item, player);
            default:
                return false;
        }
    },
    
    // === INSTANT HEAL ===
    instantHeal(scene, state, item, player) {
        const bonus = ItemManager.getEquipmentStats(state.equipment).healBonus || 0;
        const maxHpBonus = ItemManager.getEquipmentStats(state.equipment).maxHealth || 0;
        const maxHp = CONFIG.player.health + maxHpBonus;
        const baseHeal = item.healPercent ? Math.round(maxHp * item.healPercent / 100) : (item.healAmount || 0);
        const _healEff = state.survivorMods?.healingEffectiveness || 0;
        const _consEff = state.survivorMods?.consumableEffectiveness || 0;
        const heal = Math.round(baseHeal * (1 + bonus / 100) * (1 + _healEff) * (1 + _consEff));
        state.health = Math.min(maxHp, state.health + heal);
        
        if (ConsumableSystem._renderer) ConsumableSystem._renderer.audioHeal();
        Haptics.light();
        Blurbs.show(scene, player, `+${heal} HP`, { color: '#44dd44', fontSize: 13 });
        
        if (ConsumableSystem._renderer) {
            ConsumableSystem._renderer.instantHealVFX(scene, player, heal);
        }
        
        return true;
    },
    
    // === CHANNELED ACTIONS (Bandage, Pylons) ===
    startChannel(scene, state, item, player) {
        if (this._channeling) return false;
        
        const duration = item.channelTime || 3000;
        const isPylon = item.subtype === 'pylon';
        const isHealPylon = isPylon && item.pylonType === 'heal';
        const label = isPylon ? 'Placing...' : 'Bandaging...';
        const barColor = isPylon ? (isHealPylon ? 0x44ddaa : 0xff4466) : 0x44dd44;
        const barHex = isPylon ? (isHealPylon ? '#44ddaa' : '#ff4466') : '#44dd44';
        
        let barHandle = null;
        if (ConsumableSystem._renderer) {
            barHandle = ConsumableSystem._renderer.createChannelBar(scene, player, barColor);
        }
        
        const blurb = Blurbs.showPersistent(scene, player, label, { color: barHex, fontSize: 9 });
        
        if (ConsumableSystem._renderer) ConsumableSystem._renderer.audioHeal();
        Haptics.light();
        
        this._channeling = {
            scene, entity: player, item, state,
            elapsed: 0, duration,
            blurb, barHandle,
            particleColor: barColor, particleTimer: 0,
            onComplete: () => {
                if (item.effect === 'channelHeal') {
                    this._startRegen(scene, state, item, player);
                } else if (item.effect === 'pylon') {
                    this._placePylon(scene, state, item, player);
                }
            }
        };
        
        scene._channelSpeedMult = 0.15;
        return true;
    },
    
    update(scene, delta, player) {
        // === CHANNEL UPDATE ===
        if (this._channeling && this._channeling.scene === scene) {
            const ch = this._channeling;
            ch.elapsed += delta;
            
            const pct = Math.min(1, ch.elapsed / ch.duration);
            if (ch.barHandle) {
                ch.barHandle.update(player.x, player.y, pct);
            }
            if (ch.blurb && ch.blurb.update) ch.blurb.update();
            
            // Orbiting channel particles
            ch.particleTimer += delta;
            if (ch.particleTimer > 180 && ConsumableSystem._renderer) {
                ch.particleTimer -= 180;
                const angle = (ch.elapsed / 300) + Math.random() * 0.5;
                const dist = 12 + Math.random() * 4;
                const px = player.x + Math.cos(angle) * dist;
                const py = player.y + Math.sin(angle) * dist;
                ConsumableSystem._renderer.channelParticle(scene, px, py, ch.particleColor);
            }
            
            if (ch.elapsed >= ch.duration) {
                if (ConsumableSystem._renderer) {
                    ConsumableSystem._renderer.channelComplete(scene, player.x, player.y, ch.particleColor);
                }
                ch.onComplete();
                this._cleanupChannel();
            }
        }
        
        // === ZONE UPDATE ===
        for (let i = this._zones.length - 1; i >= 0; i--) {
            const z = this._zones[i];
            if (z.scene !== scene) continue;
            z.elapsed += delta;
            
            if (z.elapsed >= z.duration) {
                this._destroyZone(z);
                this._zones.splice(i, 1);
                continue;
            }
            
            if (z.tickInterval) {
                z.tickTimer += delta;
                if (z.tickTimer >= z.tickInterval) {
                    z.tickTimer -= z.tickInterval;
                    this._tickZone(scene, z, player);
                }
            }
            
            // Fade out in last 2s
            const remaining = z.duration - z.elapsed;
            if (remaining < 2000 && z.vfxHandle && z.vfxHandle.fade) {
                z.vfxHandle.fade(remaining / 2000);
            }
        }
    },
    
    interruptChannel() {
        if (!this._channeling) return;
        const ch = this._channeling;
        // Partial heal if bandage was partially done
        if (ch.item.effect === 'channelHeal' && ch.elapsed > 0) {
            const pct = ch.elapsed / ch.duration;
            const bonus = ItemManager.getEquipmentStats(ch.state.equipment).healBonus || 0;
            const maxHpBonus = ItemManager.getEquipmentStats(ch.state.equipment).maxHealth || 0;
            const maxHp = CONFIG.player.health + maxHpBonus;
            const baseHeal = ch.item.healPercent ? Math.round(maxHp * ch.item.healPercent / 100) : (ch.item.healAmount || 0);
            const _healEffI = ch.state.survivorMods?.healingEffectiveness || 0;
            const _consEffI = ch.state.survivorMods?.consumableEffectiveness || 0;
            const partialHeal = Math.round(baseHeal * pct * (1 + bonus / 100) * (1 + _healEffI) * (1 + _consEffI));
            if (partialHeal > 0) {
                ch.state.health = Math.min(maxHp, ch.state.health + partialHeal);
                Blurbs.show(ch.scene, ch.entity, `+${partialHeal} HP (partial)`, { color: '#88aa44', fontSize: 10 });
            }
        }
        Blurbs.show(ch.scene, ch.entity, 'INTERRUPTED', { color: '#ff4444', fontSize: 11 });
        if (ConsumableSystem._renderer) {
            ConsumableSystem._renderer.channelInterrupt(ch.scene, ch.entity.x, ch.entity.y);
        }
        this._cleanupChannel();
    },
    
    isChanneling() { return !!this._channeling; },
    
    _cleanupChannel() {
        if (!this._channeling) return;
        const ch = this._channeling;
        if (ch.blurb && ch.blurb.destroy) ch.blurb.destroy();
        if (ch.barHandle && ch.barHandle.destroy) ch.barHandle.destroy();
        ch.scene._channelSpeedMult = 1;
        this._channeling = null;
    },
    
    // === REGEN (post-channel bandage) ===
    _startRegen(scene, state, item, player) {
        const bonus = ItemManager.getEquipmentStats(state.equipment).healBonus || 0;
        const maxHpBonus = ItemManager.getEquipmentStats(state.equipment).maxHealth || 0;
        const maxHp = CONFIG.player.health + maxHpBonus;
        const baseHeal = item.healPercent ? Math.round(maxHp * item.healPercent / 100) : (item.healAmount || 0);
        const _healEffR = state.survivorMods?.healingEffectiveness || 0;
        const _consEffR = state.survivorMods?.consumableEffectiveness || 0;
        const totalHeal = Math.round(baseHeal * (1 + bonus / 100) * (1 + _healEffR) * (1 + _consEffR));
        const regenDur = item.regenDuration || 4000;
        const ticks = 8;
        const healPerTick = Math.ceil(totalHeal / ticks);
        let ticksDone = 0;
        
        if (ConsumableSystem._renderer) ConsumableSystem._renderer.audioHeal();
        Blurbs.show(scene, player, 'Healing...', { color: '#44dd44', fontSize: 10, duration: 1200 });
        
        let regenVFX = null;
        if (ConsumableSystem._renderer) {
            regenVFX = ConsumableSystem._renderer.regenVFX(scene, player, regenDur);
        }
        
        const _doTick = () => {
            ticksDone++;
            const heal = Math.min(healPerTick, maxHp - state.health);
            if (heal > 0) {
                state.health += heal;
                Blurbs.show(scene, player, `+${heal}`, { color: '#44dd44', fontSize: 9, duration: 500, rise: 15, offsetY: -20 - ticksDone * 3 });
                if (ConsumableSystem._renderer) {
                    ConsumableSystem._renderer.regenSparkle(scene, player.x + _between(-6, 6), player.y + _between(-8, 2));
                }
            }
            if (regenVFX && regenVFX.tickPulse) regenVFX.tickPulse(player.x, player.y);
        };
        
        if (ConsumableSystem._renderer) {
            ConsumableSystem._renderer.timedEvent(scene, regenDur / ticks, ticks - 1, _doTick);
        }
    },
    
    // === GRENADES ===
    throwGrenade(scene, state, item, player) {
        if (!scene.lockedTarget || !scene.lockedTarget.active) {
            Blurbs.show(scene, player, 'No target locked!', { color: '#ff4444' });
            return false;
        }
        
        const target = scene.lockedTarget;
        const targetX = target.x, targetY = target.y;
        const callout = item.callout || 'Frag out!';
        
        if (ConsumableSystem._renderer) ConsumableSystem._renderer.audioHeal();
        Haptics.light();
        Blurbs.show(scene, player, callout, { color: '#ff8844', fontSize: 13 });
        
        if (ConsumableSystem._renderer) {
            ConsumableSystem._renderer.grenadeVFX(scene, player, { x: targetX, y: targetY }, item,
                (landX, landY) => {},
                (detX, detY) => {
                    this._detonateGrenade(scene, state, item, detX, detY);
                }
            );
        } else {
            this._detonateGrenade(scene, state, item, targetX, targetY);
        }
        
        return true;
    },
    
    _detonateGrenade(scene, state, item, x, y) {
        const dmg = item.effectValue || 40;
        const radius = item.effectRadius || 80;
        const type = item.grenadeType || 'frag';
        
        Haptics.medium();
        
        if (ConsumableSystem._renderer) {
            ConsumableSystem._renderer.detonateVFX(scene, x, y, type, radius);
        }
        
        if (type === 'frag') {
            this._damageEnemiesInRadius(scene, state, x, y, radius, dmg);
        } else if (type === 'poison') {
            const initialDmg = Math.round(dmg * 0.4);
            this._damageEnemiesInRadius(scene, state, x, y, radius, initialDmg);
            this._createZone(scene, state, 'poison', x, y, radius * 0.8, Math.round(dmg * 0.15), item.zoneDuration || 5000, 500);
        } else if (type === 'inferno') {
            this._damageEnemiesInRadius(scene, state, x, y, radius, dmg);
            this._createZone(scene, state, 'fire', x, y, radius * 0.7, Math.round(dmg * 0.2), item.zoneDuration || 4000, 400);
        }
    },
    
    _damageEnemiesInRadius(scene, state, x, y, radius, dmg) {
        if (!scene.enemies) return;
        scene.enemies.getChildren().forEach(e => {
            if (!e.active || e.hp <= 0) return;
            const d = _dist(x, y, e.x, e.y);
            if (d < radius) {
                const falloff = 1 - (d / radius) * 0.5;
                const finalDmg = Math.round(dmg * falloff);
                CombatSystem.damageEnemy(scene, e, finalDmg, 'grenade', scene.player, scene.state, scene.state.equipment);
            }
        });
    },
    
    _createZone(scene, state, type, x, y, radius, value, duration, tickInterval) {
        let vfxHandle = null;
        if (ConsumableSystem._renderer) {
            vfxHandle = ConsumableSystem._renderer.createZoneVisuals(scene, x, y, radius, type, duration);
        }
        
        this._zones.push({
            type, x, y, radius, value, duration, elapsed: 0,
            tickTimer: 0, tickInterval: tickInterval || 0,
            vfxHandle, scene, state
        });
    },
    
    _tickZone(scene, zone, player) {
        if (zone.type === 'poison' || zone.type === 'fire') {
            if (scene.enemies) {
                scene.enemies.getChildren().forEach(e => {
                    if (!e.active || e.hp <= 0) return;
                    const d = _dist(zone.x, zone.y, e.x, e.y);
                    if (d < zone.radius) {
                        CombatSystem.damageEnemy(scene, e, zone.value, zone.type, scene.player, scene.state, scene.state.equipment);
                    }
                });
            }
        } else if (zone.type === 'heal') {
            if (player) {
                const d = _dist(zone.x, zone.y, player.x, player.y);
                if (d < zone.radius) {
                    const eqStats = ItemManager.getEquipmentStats(zone.state.equipment);
                    const maxHp = CONFIG.player.health + (eqStats.maxHealth || 0);
                    const bonus = eqStats.healBonus || 0;
                    const baseHeal = zone.value;
                    const healVal = Math.round(baseHeal * (1 + bonus / 100));
                    if (zone.state.health < maxHp) {
                        const heal = Math.min(healVal, maxHp - zone.state.health);
                        zone.state.health += heal;
                        Blurbs.show(scene, player, `+${heal}`, { color: '#44ddaa', fontSize: 9, duration: 400, rise: 12, offsetY: -20 });
                    }
                }
            }
        }
    },
    
    getDamageZoneBonus(scene, player) {
        let bonus = 0;
        for (const z of this._zones) {
            if (z.scene !== scene || z.type !== 'damage') continue;
            const d = _dist(z.x, z.y, player.x, player.y);
            if (d < z.radius) bonus += z.value;
        }
        return bonus;
    },
    
    // === PYLONS ===
    _placePylon(scene, state, item, player) {
        if (ConsumableSystem._renderer) ConsumableSystem._renderer.audioHeal();
        Haptics.medium();
        
        const type = item.pylonType;
        const x = player.x, y = player.y;
        const radius = item.pylonRadius || 50;
        const value = item.pylonValue || 8;
        const duration = item.zoneDuration || 10000;
        const tickInterval = item.tickInterval || 500;
        const col = type === 'heal' ? 0x44ddaa : 0xff4466;
        
        Blurbs.show(scene, player, type === 'heal' ? 'Healing Rift!' : 'Damage Rift!',
            { color: type === 'heal' ? '#44ddaa' : '#ff4466', fontSize: 12 });
        
        if (ConsumableSystem._renderer) {
            ConsumableSystem._renderer.pylonBurst(scene, x, y, col, radius);
        }
        
        this._createZone(scene, state, type, x, y, radius, value, duration, tickInterval);
    },
    
    _destroyZone(zone) {
        if (zone.vfxHandle && zone.vfxHandle.destroy) zone.vfxHandle.destroy();
    },
    
    cleanupScene(scene) {
        for (let i = this._zones.length - 1; i >= 0; i--) {
            if (this._zones[i].scene === scene) {
                this._destroyZone(this._zones[i]);
                this._zones.splice(i, 1);
            }
        }
        if (this._channeling && this._channeling.scene === scene) {
            this._cleanupChannel();
        }
    },
    
    cleanupAll() {
        for (const z of this._zones) {
            this._destroyZone(z);
        }
        this._zones.length = 0;
        if (this._channeling) {
            this._channeling = null;
        }
    }
};

// ============================================
// Both GameScene and InteriorScene call these functions
// to ensure identical behavior (damage, VFX, signatures)
// ============================================
