// Vestige GPS — NPCManager
// NPC lifecycle, 7 behavior profiles
// Rendering decoupled: call NPCManager.init(renderer) with sprite implementation
// Without init(), spawns create data-only handles (headless/server-safe)
import { SpriteManager } from '../client/spriteManager.js';

export const NPCManager = {
    _registry: new Map(), // sceneKey → [npcHandle, ...]
    _renderer: null,

    /**
     * Initialize with a renderer implementation.
     * Renderer should implement:
     *   createNPCSprite(scene, x, y, preset) → sprite
     *   playNPCWalk(sprite, dir)
     *   stopNPC(sprite)
     *   addShadow(scene, sprite, opts)
     */
    init(renderer) {
        NPCManager._renderer = renderer;
    },
    
    // ── BEHAVIOR PROFILES ──
    // Each profile defines how an NPC acts during idle state.
    // Combat AI is handled separately by scene-specific code.
    behaviors: {
        idle_pace: {
            // Pace ±rangeX from home. Face player when close.
            rangeX: 20,
            paceInterval: 3000,
            facePlayerDist: 60,
            interactDist: 45
        },
        waypoint_patrol: {
            // Walk a route of waypoints, pause at each.
            speed: 22,
            pauseMin: 1000,
            pauseMax: 2000,
            pauseChance: 1.0 // pause at every waypoint
        },
        work_cycle: {
            // Crouch→stand→walk to tool→walk back→crouch
            workDurMin: 7000,
            workDurMax: 9000,
            standDur: 800,
            walkSpeed: 20,
            toolOffsetX: 15,
            crouchScale: 0.9
        },
        stationary: {
            // Stand in place, optional fixed direction
        },
        face_player: {
            // Stand still, rotate to face player when close
            faceDist: 50
        },
        conversation: {
            // Face a partner NPC. Occasional idle sway.
            swayInterval: 4000,
            swayAmount: 1
        },
        sentry: {
            // Stand guard, scan left/right periodically
            scanInterval: 3000,
            scanDirs: ['left', 'right']
        }
    },
    
    // ── FOUNDRY OUTFIT TABLE ──
    // Maps foundryId + role → preset ID for SpriteManager
    // Future foundries: just add a row here + preset entries in SpriteManager.npcPresets
    foundryOutfits: {
        terracorp:  { guard: 'tc_guard',  patrol: 'tc_patrol',  mechanic: 'tc_mechanic' },
        ucr:        { guard: 'ucr_guard', patrol: 'ucr_patrol', mechanic: 'ucr_mechanic' },
        deralict:   { guard: 'drl_guard', patrol: 'drl_patrol', mechanic: 'drl_mechanic' },
        sworn:      { guard: 'swn_guard', patrol: 'swn_patrol', mechanic: 'swn_mechanic' },
        blackreach: { guard: 'blk_guard', patrol: 'blk_patrol', mechanic: 'blk_mechanic' },
        cephalon:   { guard: 'cph_guard', patrol: 'cph_patrol', mechanic: 'cph_mechanic' }
    },
    
    // Get preset ID from foundry + role
    getFoundryPreset(foundryId, role) {
        const entry = this.foundryOutfits[foundryId];
        if (entry && entry[role]) return entry[role];
        // Fallback to terracorp
        const fb = this.foundryOutfits.terracorp;
        return fb[role] || fb.guard;
    },
    
    // ── SPAWN ──
    // Creates an NPC sprite with auto-applied tint, shadow, depth, and registers it
    // config: { x, y, preset, role, behavior, behaviorOpts, scene-specific data... }
    spawn(scene, config) {
        const { x, y, preset, role, behavior, behaviorOpts } = config;
        const sprite = NPCManager._renderer ? NPCManager._renderer.createNPCSprite(scene, x, y, preset) : null;
        const depth = config.depth || (10 + y * 0.01);
        if (sprite) sprite.setDepth(depth);
        
        // Auto-apply ambient tint
        if (sprite && scene._ambientTint && scene._ambientTint !== 0xffffff) {
            sprite.setTint(scene._ambientTint);
        }
        
        // Auto-apply shadow
        const shadowOpts = config.shadowOpts || { offsetY: 8, scale: 0.5, alpha: 0.12 };
        if (config.interior) shadowOpts.interior = true;
        if (NPCManager._renderer) NPCManager._renderer.addShadow(scene, sprite, shadowOpts);
        
        // Build handle
        const handle = {
            sprite,
            x, y,
            role: role || 'generic',
            preset,
            behavior: behavior || 'stationary',
            behaviorOpts: behaviorOpts || {},
            _homeX: x,
            _homeY: y,
            _timer: 0,
            _state: 'idle', // idle, paused, walking, working, standing, walking_away, walking_back
            _dir: 1,
            _waypointIdx: 0,
            _waypointPause: 0,
            _workDur: 0,
            // Scene-specific data passthrough
            ...config.extra
        };
        
        // Register
        const key = scene.scene.key;
        if (!this._registry.has(key)) this._registry.set(key, []);
        this._registry.get(key).push(handle);
        
        return handle;
    },
    
    // ── GET registered NPCs ──
    getAll(scene) {
        return this._registry.get(scene.scene.key) || [];
    },
    
    getByRole(scene, role) {
        return this.getAll(scene).filter(n => n.role === role);
    },
    
    // ── UPDATE ALL ── 
    // Runs behavior AI for all registered idle NPCs in this scene.
    // Pass playerRef for face-player behaviors. freezeAll = true during dialogue.
    updateAll(scene, dt, opts = {}) {
        const npcs = this.getAll(scene);
        if (npcs.length === 0) return;
        
        const player = opts.player || scene.player;
        const freezeAll = opts.freeze || false;
        
        for (const npc of npcs) {
            if (!npc.sprite || !npc.sprite.active) continue;
            if (npc._skipBehavior) continue; // scene-specific code managing this NPC
            
            if (freezeAll) {
                NPCManager._npcStop(npc.sprite);
                continue;
            }
            
            const bName = npc.behavior;
            const bCfg = this.behaviors[bName];
            if (!bCfg) { NPCManager._npcStop(npc.sprite); continue; }
            
            this._runBehavior(scene, npc, bName, bCfg, dt, player);
        }
    },
    
    _runBehavior(scene, npc, bName, bCfg, dt, player) {
        const dtMs = dt * 1000;
        
        if (bName === 'idle_pace') {
            const range = npc.behaviorOpts.rangeX || bCfg.rangeX;
            const interval = npc.behaviorOpts.paceInterval || bCfg.paceInterval;
            const faceDist = npc.behaviorOpts.facePlayerDist || bCfg.facePlayerDist;
            const interactDist = npc.behaviorOpts.interactDist || bCfg.interactDist;
            
            const _dx = player ? player.x - npc.x : 0;
            const _dy = player ? player.y - npc.y : 0;
            const playerDist = player
                ? Math.sqrt(_dx * _dx + _dy * _dy)
                : 999;
            
            if (playerDist < interactDist) {
                // Within interact range — stop and face player
                NPCManager._npcStop(npc.sprite);
                this._faceTarget(npc, player);
            } else if (playerDist < faceDist) {
                NPCManager._npcStop(npc.sprite);
                const dx = player.x - npc.x;
                npc.sprite._npcDir = dx > 0 ? 'right' : 'left';
                this._setFrame(npc);
            } else {
                // Pace
                npc._timer += dtMs;
                if (npc._timer > interval) {
                    npc._timer = 0;
                    npc._dir *= -1;
                }
                const targetX = npc._homeX + npc._dir * range;
                const dx = targetX - npc.x;
                if (Math.abs(dx) > 1) {
                    npc.x += Math.sign(dx) * 18 * dt;
                    npc.sprite.setPosition(npc.x, npc.y);
                    NPCManager._npcWalk(npc.sprite, dx > 0 ? 'right' : 'left');
                } else {
                    NPCManager._npcStop(npc.sprite);
                }
            }
            
        } else if (bName === 'waypoint_patrol') {
            const wps = npc.behaviorOpts.waypoints;
            if (!wps || wps.length === 0) return;
            
            const speed = npc.behaviorOpts.speed || bCfg.speed;
            
            // Pause at waypoint
            if (npc._waypointPause > 0) {
                npc._waypointPause -= dtMs;
                NPCManager._npcStop(npc.sprite);
                return;
            }
            
            const wp = wps[npc._waypointIdx];
            const dx = wp.x - npc.x;
            const dy = wp.y - npc.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            
            if (dist < 3) {
                // Arrived — pause and advance
                const pauseChance = npc.behaviorOpts.pauseChance !== undefined ? npc.behaviorOpts.pauseChance : (bCfg.pauseChance || 1.0);
                if (Math.random() < pauseChance) {
                    const pMin = npc.behaviorOpts.pauseMin || bCfg.pauseMin || 1000;
                    const pMax = npc.behaviorOpts.pauseMax || bCfg.pauseMax || 2000;
                    npc._waypointPause = pMin + Math.random() * (pMax - pMin);
                }
                npc._waypointIdx = (npc._waypointIdx + 1) % wps.length;
                NPCManager._npcStop(npc.sprite);
            } else {
                npc.x += (dx / dist) * speed * dt;
                npc.y += (dy / dist) * speed * dt;
                npc.sprite.setPosition(npc.x, npc.y);
                if (npc.sprite.setDepth) npc.sprite.setDepth(10 + npc.y * 0.01);
                NPCManager._npcWalk(npc.sprite, this._dirFromDelta(dx, dy));
            }
            
        } else if (bName === 'work_cycle') {
            npc._timer += dtMs;
            const state = npc._state || 'working';
            const walkSpeed = npc.behaviorOpts.walkSpeed || bCfg.walkSpeed;
            const toolX = npc.behaviorOpts.toolOffsetX
                ? npc._homeX + npc.behaviorOpts.toolOffsetX
                : npc._homeX + bCfg.toolOffsetX;
            
            if (state === 'working') {
                npc.sprite.setScale(bCfg.crouchScale || 0.9);
                NPCManager._npcStop(npc.sprite);
                if (!npc._workDur) npc._workDur = bCfg.workDurMin + Math.random() * (bCfg.workDurMax - bCfg.workDurMin);
                if (npc._timer > npc._workDur) {
                    npc._state = 'standing';
                    npc._timer = 0;
                    npc._workDur = 0;
                    npc.sprite.setScale(1.0);
                }
            } else if (state === 'standing') {
                NPCManager._npcStop(npc.sprite);
                if (npc._timer > (bCfg.standDur || 800)) {
                    npc._state = 'walking_away';
                    npc._timer = 0;
                }
            } else if (state === 'walking_away') {
                const dx = toolX - npc.x;
                if (Math.abs(dx) > 1) {
                    npc.x += Math.sign(dx) * walkSpeed * dt;
                    npc.sprite.setPosition(npc.x, npc.y);
                    NPCManager._npcWalk(npc.sprite, dx > 0 ? 'right' : 'left');
                } else {
                    NPCManager._npcStop(npc.sprite);
                    if (npc._timer > 1200) {
                        npc._state = 'walking_back';
                        npc._timer = 0;
                    }
                }
            } else if (state === 'walking_back') {
                const dx = npc._homeX - npc.x;
                if (Math.abs(dx) > 1) {
                    npc.x += Math.sign(dx) * walkSpeed * dt;
                    npc.sprite.setPosition(npc.x, npc.y);
                    NPCManager._npcWalk(npc.sprite, dx > 0 ? 'right' : 'left');
                } else {
                    npc.x = npc._homeX;
                    npc.sprite.setPosition(npc.x, npc.y);
                    npc._state = 'working';
                    npc._timer = 0;
                }
            }
            
        } else if (bName === 'face_player') {
            if (player) {
                const _fpDx = player.x - npc.x, _fpDy = player.y - npc.y;
                const dist = Math.sqrt(_fpDx * _fpDx + _fpDy * _fpDy);
                if (dist < (bCfg.faceDist || 50)) {
                    this._faceTarget(npc, player);
                }
            }
            NPCManager._npcStop(npc.sprite);
            
        } else if (bName === 'conversation') {
            // Face conversation partner
            const partner = npc.behaviorOpts.partner;
            if (partner) {
                const dx = partner.x - npc.x;
                npc.sprite._npcDir = dx > 0 ? 'right' : 'left';
                this._setFrame(npc);
            }
            
        } else if (bName === 'sentry') {
            npc._timer += dtMs;
            if (npc._timer > (bCfg.scanInterval || 3000)) {
                npc._timer = 0;
                const dirs = bCfg.scanDirs || ['left', 'right'];
                const idx = Math.floor(Math.random() * dirs.length);
                npc.sprite._npcDir = dirs[idx];
                this._setFrame(npc);
            }
            
        } else {
            // stationary — do nothing
            NPCManager._npcStop(npc.sprite);
        }
    },
    
    // ── Rendering helpers (delegate to injected renderer) ──
    _npcWalk(sprite, dir) {
        if (NPCManager._renderer) NPCManager._renderer.playNPCWalk(sprite, dir);
    },
    _npcStop(sprite) {
        if (NPCManager._renderer) NPCManager._renderer.stopNPC(sprite);
    },

    // ── Helpers ──
    _faceTarget(npc, target) {
        const dx = target.x - npc.x;
        const dy = target.y - npc.y;
        const absDx = Math.abs(dx), absDy = Math.abs(dy);
        let dir;
        if (absDy > absDx * 1.5) dir = dy > 0 ? 'down' : 'up';
        else if (absDx > absDy * 1.5) dir = dx > 0 ? 'right' : 'left';
        else if (dx > 0) dir = dy > 0 ? 'down_right' : 'up_right';
        else dir = dy > 0 ? 'down_left' : 'up_left';
        npc.sprite._npcDir = dir;
        this._setFrame(npc);
    },
    
    _setFrame(npc) {
        const dirMap = { down:0, down_right:1, right:2, up_right:3, up:4, up_left:5, left:6, down_left:7 };
        npc.sprite.setFrame((dirMap[npc.sprite._npcDir] || 0) * 3);
    },
    
    _dirFromDelta(dx, dy) {
        const absDx = Math.abs(dx), absDy = Math.abs(dy);
        if (absDy > absDx * 1.5) return dy > 0 ? 'down' : 'up';
        if (absDx > absDy * 1.5) return dx > 0 ? 'right' : 'left';
        if (dx > 0) return dy > 0 ? 'down_right' : 'up_right';
        return dy > 0 ? 'down_left' : 'up_left';
    },
    
    // ── CLEANUP ──
    destroyAll(scene) {
        const key = scene.scene.key;
        const npcs = this._registry.get(key);
        if (npcs) {
            npcs.forEach(n => {
                if (n.sprite && n.sprite.active) n.sprite.destroy();
            });
            this._registry.delete(key);
        }
    },
    
    // Remove a specific NPC handle
    remove(scene, handle) {
        const key = scene.scene.key;
        const list = this._registry.get(key);
        if (list) {
            const idx = list.indexOf(handle);
            if (idx >= 0) list.splice(idx, 1);
        }
    }
};

// ============================================
// DYNAMIC SHADOWS — Auto-generated floor shadows driven by time of day
// ============================================
