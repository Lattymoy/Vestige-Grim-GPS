// Vestige GPS — Biome Classifier
// Maps real-world GPS coordinates to Raum biomes
//
// Pipeline:
//   GPS coords → Reverse geocode → Land-use classification → Biome assignment
//
// Uses OpenStreetMap Overpass API (free, no key needed) for land-use data.
// Elevation from Open-Elevation API (free).
// Falls back to a default biome if APIs are unreachable.

const BIOME_MAP = {
    // OpenStreetMap landuse tags → Raum biomes
    // Higher confidence = more specific match
    landuse: {
        'residential':  { biome: 'ironfield',   confidence: 0.7 },
        'commercial':   { biome: 'ironfield',   confidence: 0.8 },
        'industrial':   { biome: 'ironfield',   confidence: 0.9 },
        'retail':       { biome: 'ironfield',   confidence: 0.7 },
        'construction': { biome: 'ironfield',   confidence: 0.6 },
        'railway':      { biome: 'ironfield',   confidence: 0.8 },

        'forest':       { biome: 'mirelands',   confidence: 0.9 },
        'meadow':       { biome: 'mirelands',   confidence: 0.7 },
        'grass':        { biome: 'mirelands',   confidence: 0.6 },
        'orchard':      { biome: 'mirelands',   confidence: 0.5 },
        'vineyard':     { biome: 'mirelands',   confidence: 0.5 },
        'recreation_ground': { biome: 'mirelands', confidence: 0.4 },

        'farmland':     { biome: 'scorchflats', confidence: 0.6 },
        'quarry':       { biome: 'hollows',     confidence: 0.9 },
        'landfill':     { biome: 'ashveil',     confidence: 0.7 },
        'cemetery':     { biome: 'hollows',     confidence: 0.5 },
        'military':     { biome: 'ashveil',     confidence: 0.6 },
    },
    natural: {
        'water':        { biome: 'tidemarsh',   confidence: 0.9 },
        'wetland':      { biome: 'tidemarsh',   confidence: 0.9 },
        'coastline':    { biome: 'tidemarsh',   confidence: 0.95 },
        'beach':        { biome: 'tidemarsh',   confidence: 0.9 },
        'bay':          { biome: 'tidemarsh',   confidence: 0.8 },

        'wood':         { biome: 'mirelands',   confidence: 0.9 },
        'tree_row':     { biome: 'mirelands',   confidence: 0.5 },
        'scrub':        { biome: 'scorchflats', confidence: 0.7 },
        'heath':        { biome: 'scorchflats', confidence: 0.7 },
        'grassland':    { biome: 'scorchflats', confidence: 0.6 },
        'sand':         { biome: 'scorchflats', confidence: 0.8 },
        'bare_rock':    { biome: 'hollows',     confidence: 0.8 },
        'scree':        { biome: 'hollows',     confidence: 0.8 },
        'cliff':        { biome: 'hollows',     confidence: 0.9 },
        'cave_entrance': { biome: 'hollows',    confidence: 0.95 },
        'volcano':      { biome: 'ashveil',     confidence: 0.95 },
        'glacier':      { biome: 'ashveil',     confidence: 0.7 },
    },
    leisure: {
        'park':         { biome: 'mirelands',   confidence: 0.5 },
        'garden':       { biome: 'mirelands',   confidence: 0.4 },
        'nature_reserve': { biome: 'mirelands', confidence: 0.8 },
        'swimming_pool': { biome: 'tidemarsh',  confidence: 0.3 },
    },
    // Elevation modifiers — applied on top of land-use classification
    // If elevation is high enough, it can override to hollows
    elevationOverrides: {
        above1500: 'hollows',   // mountains
        above2500: 'ashveil',   // extreme altitude
    }
};

// Fallback when no land-use data available
const DEFAULT_BIOME = 'scorchflats';

// Difficulty scaling based on distance from player's safehouse
const DIFFICULTY_BRACKETS = [
    { maxKm: 0.5,  difficulty: 1 },
    { maxKm: 1.0,  difficulty: 2 },
    { maxKm: 2.0,  difficulty: 3 },
    { maxKm: 5.0,  difficulty: 5 },
    { maxKm: 10.0, difficulty: 7 },
    { maxKm: 25.0, difficulty: 8 },
    { maxKm: 50.0, difficulty: 9 },
    { maxKm: Infinity, difficulty: 10 },
];

export const BiomeClassifier = {

    // Main entry point: classify a GPS coordinate into a Raum biome
    async classify(lat, lng) {
        const results = [];

        // Query OSM Overpass for land-use data around this point
        try {
            const osmData = await this._queryOverpass(lat, lng);
            results.push(...this._classifyOSM(osmData));
        } catch (e) {
            console.warn('BiomeClassifier: Overpass query failed, using fallback', e.message);
        }

        // Query elevation
        try {
            const elevation = await this._queryElevation(lat, lng);
            if (elevation > 2500) {
                results.push({ biome: 'ashveil', confidence: 0.8, source: 'elevation' });
            } else if (elevation > 1500) {
                results.push({ biome: 'hollows', confidence: 0.6, source: 'elevation' });
            }
        } catch (e) {
            // Elevation is optional enrichment
        }

        // Pick highest confidence result
        if (results.length === 0) {
            return { biome: DEFAULT_BIOME, confidence: 0.1, source: 'fallback' };
        }

        results.sort((a, b) => b.confidence - a.confidence);
        return results[0];
    },

    // Calculate difficulty based on distance from safehouse
    getDifficulty(distanceKm) {
        for (const bracket of DIFFICULTY_BRACKETS) {
            if (distanceKm <= bracket.maxKm) return bracket.difficulty;
        }
        return 10;
    },

    // Determine node type from OSM features
    getNodeType(osmData) {
        // Larger/prominent features become boss gates
        // Religious/historic buildings become havens
        // Everything else is a standard defense node
        if (!osmData || !osmData.elements) return 'defense';

        for (const el of osmData.elements) {
            const tags = el.tags || {};
            if (tags.historic || tags.monument || tags.memorial) return 'boss';
            if (tags.amenity === 'place_of_worship') return 'haven';
            if (tags.tourism === 'museum' || tags.tourism === 'attraction') return 'boss';
            if (tags.building === 'cathedral' || tags.building === 'castle') return 'boss';
        }

        return 'defense';
    },

    // Query OpenStreetMap Overpass API
    async _queryOverpass(lat, lng) {
        const radius = 100; // meters
        const query = `
            [out:json][timeout:5];
            (
                way(around:${radius},${lat},${lng})["landuse"];
                way(around:${radius},${lat},${lng})["natural"];
                way(around:${radius},${lat},${lng})["leisure"];
                node(around:${radius},${lat},${lng})["natural"];
                way(around:${radius},${lat},${lng})["amenity"];
                way(around:${radius},${lat},${lng})["historic"];
                way(around:${radius},${lat},${lng})["tourism"];
            );
            out tags;
        `;

        const resp = await fetch('https://overpass-api.de/api/interpreter', {
            method: 'POST',
            body: `data=${encodeURIComponent(query)}`,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            signal: AbortSignal.timeout(8000),
        });

        if (!resp.ok) throw new Error(`Overpass ${resp.status}`);
        return resp.json();
    },

    // Query elevation (Open-Elevation API)
    async _queryElevation(lat, lng) {
        const resp = await fetch(
            `https://api.open-elevation.com/api/v1/lookup?locations=${lat},${lng}`,
            { signal: AbortSignal.timeout(5000) }
        );
        if (!resp.ok) throw new Error(`Elevation ${resp.status}`);
        const data = await resp.json();
        return data.results?.[0]?.elevation ?? 0;
    },

    // Classify OSM data into biome candidates
    _classifyOSM(osmData) {
        const results = [];
        if (!osmData?.elements) return results;

        for (const el of osmData.elements) {
            const tags = el.tags || {};

            // Check each tag category
            for (const category of ['landuse', 'natural', 'leisure']) {
                const value = tags[category];
                if (value && BIOME_MAP[category]?.[value]) {
                    const match = BIOME_MAP[category][value];
                    results.push({
                        biome: match.biome,
                        confidence: match.confidence,
                        source: `osm:${category}=${value}`,
                    });
                }
            }
        }

        return results;
    },

    // Batch classify multiple coordinates (for scanning an area)
    async classifyArea(lat, lng, radiusKm, gridSize = 5) {
        const points = [];
        const step = (radiusKm * 2) / gridSize;

        for (let i = 0; i < gridSize; i++) {
            for (let j = 0; j < gridSize; j++) {
                const pLat = (lat - radiusKm / 111) + (i * step / 111);
                const pLng = (lng - radiusKm / (111 * Math.cos(lat * Math.PI / 180)))
                    + (j * step / (111 * Math.cos(lat * Math.PI / 180)));
                points.push({ lat: pLat, lng: pLng });
            }
        }

        // Classify in parallel with rate limiting
        const results = [];
        for (const pt of points) {
            try {
                const result = await this.classify(pt.lat, pt.lng);
                results.push({ ...pt, ...result });
            } catch (e) {
                results.push({ ...pt, biome: DEFAULT_BIOME, confidence: 0.1, source: 'error' });
            }
            // Rate limit: Overpass API is shared, be nice
            await new Promise(r => setTimeout(r, 200));
        }

        return results;
    }
};
