// Vestige GPS — CombatSystem
// Core combat: shooting, melee, damage, kills
// Rendering delegated via _renderer bridge
// 100% rendering methods moved to client/rendering/combatRenderer.js:
//   createTracer, spark, updateFlairEffects, muzzle flash, damage numbers, etc.

import { CONFIG } from '../data/config.js';
import { ConsumableSystem } from './consumableSystem.js';
import { EventBus } from './eventBus.js';
import { Haptics } from './haptics.js';
import { ItemManager } from './itemManager.js';
import { SignatureEffects } from './signatureEffects.js';

// Inline Phaser.Math replacements
const _dist = (x1, y1, x2, y2) => { const dx = x2-x1, dy = y2-y1; return Math.sqrt(dx*dx+dy*dy); };
const _angle = (x1, y1, x2, y2) => Math.atan2(y2 - y1, x2 - x1);
const _between = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

export const CombatSystem = {
    _renderer: null,

    /**
     * Set renderer for combat VFX.
     * Renderer should implement:
     *   audioShoot(), audioMelee(), audioUiClick()
     *   createBullet(scene, group, x, y, fxId, fx, angle, speed, opts) → sprite
     *   muzzleFlash(scene, x, y, angle, fx, isCrit)
     *   playerRecoil(scene, player, angle, isCrit)
     *   cameraShake(scene, duration, intensity)
     *   createTracer(scene, x, y, angle, fx)
     *   spark(scene, x, y, fromAngle, fx)
     *   perfectDodgeFlash(scene, x, y)
     *   burstMuzzleFlash(scene, x, y, fx)
     *   damageNumber(scene, x, y, text, opts) — { color, fontSize, duration }
     *   hitFlash(scene, target, color, durationMs)
     *   impactRing(scene, x, y, source)
     *   hitStop(scene, enemy, durationMs)
     *   shieldBlockVFX(scene, enemy)
     *   shieldBreakVFX(scene, enemy)
     *   meleeSwingVFX(scene, player, angle, mfx, meleeType, mRange)
     *   meleeImpactSparks(scene, player, angle, mfx)
     *   finisherText(scene, x, y)
     *   staggerVFX(scene, enemy, durationMs)
     *   whirlwindVFX(scene, player, range)
     *   cubeShatterVFX(scene, x, y, cfg)
     *   bloodSquaresVFX(scene, x, y)
     *   bloodStainVFX(scene, x, y)
     *   floatingText(scene, x, y, text, opts)
     *   updateFlairEffects(scene) — entire flair particle system
     *   delayedCall(scene, ms, callback)
     *   lungeTween(scene, player, angle, dist)
     */
    init(renderer) {
        CombatSystem._renderer = renderer;
    },

    // === SHOOTING ===
    shoot(scene, opts) {
        if (!opts.target || !opts.target.active) return false;
        const R = CombatSystem._renderer;

        const eqStats = ItemManager.getEquipmentStats(opts.equipment);

        // Power ammo check
        if (opts.state._powerAmmoActive) {
            if ((opts.state.powerAmmo || 0) < 1) {
                opts.state._powerAmmoActive = false;
                if (scene._ammoHud) scene._ammoHud.update(scene._magazine, false, 0);
                return false;
            }
            opts.state.powerAmmo -= 1;
        }

        // Range check
        const range = 130 + (eqStats.targetRange || 1) * 30;
        const dist = _dist(opts.player.x, opts.player.y, opts.target.x, opts.target.y);
        if (dist > range || dist < CONFIG.player.autoMeleeRange) return false;

        if (R) R.audioShoot();
        Haptics.medium();
        EventBus.emit('shoot', { scene });

        const sx = opts.player.x + Math.cos(opts.aimAngle) * 14;
        const sy = opts.player.y + Math.sin(opts.aimAngle) * 14;

        // Foundry FX profile
        const weapon = opts.equipment?.weapon;
        const fxId = weapon?.foundry || 'scrap';
        const fx = CONFIG.foundryFX[fxId] || CONFIG.foundryFX.scrap;

        // === DAMAGE COMPUTATION (pure logic) ===
        let bulletDmg = eqStats.damage || CONFIG.player.gunDamage;

        // Survivor mark/rank multiplier
        const _sMods = opts.state.survivorMods;
        if (_sMods && _sMods.statMultiplier !== 1) bulletDmg = Math.round(bulletDmg * _sMods.statMultiplier);

        // Spite mark
        const _sConds = _sMods?.conditionals;
        if (_sConds && _sConds.spiteBonus) {
            const _sMaxHP = CONFIG.player.health + (eqStats.maxHealth || 0);
            if (opts.state.health / _sMaxHP < _sConds.spiteThreshold) bulletDmg = Math.round(bulletDmg * (1 + _sConds.spiteBonus));
        }

        if (opts.state._powerAmmoActive) bulletDmg = Math.round(bulletDmg * 1.3);
        if (eqStats.gymDamageBonus) bulletDmg = Math.round(bulletDmg * (1 + eqStats.gymDamageBonus / 100));

        // Signature damage mods
        const sigs = eqStats.signatures || [];
        const sharpshooterActive = opts.state._sharpshooterActive;
        if (sharpshooterActive) bulletDmg = Math.round(bulletDmg * (1 + (opts.state._sharpshooterDmgBonus || 0.25)));

        const berserker = sigs.find(s => s.effect === 'berserker');
        if (berserker) bulletDmg = Math.round(bulletDmg * SignatureEffects.calcBerserkerBonus(berserker, opts.state.health, CONFIG.player.health + (eqStats.maxHealth || 0)));

        const nomad = sigs.find(s => s.effect === 'nomad');
        if (nomad) bulletDmg = Math.round(bulletDmg * SignatureEffects.calcNomadBonus(nomad, opts.player.x, opts.player.y, opts.target.x, opts.target.y));

        const diablo = sigs.find(s => s.effect === 'diablo');
        if (diablo && opts.target.isBoss) bulletDmg = Math.round(bulletDmg * (1 + diablo.value / 100));

        const dabloon = sigs.find(s => s.effect === 'dabloon');
        if (dabloon) bulletDmg = Math.round(bulletDmg * (1 - dabloon.value / 100));

        // Accuracy + crit
        const hitChance = sharpshooterActive ? 100 : 50 + (eqStats.accuracy || 0) / 2;
        const didMiss = Math.random() * 100 > hitChance;
        const critStat = eqStats.crit || 0;
        const critRoll = Math.random() * 200;
        const isCrit = critStat > 0 && critRoll < critStat;
        const isRedCrit = isCrit && critStat > 100 && critRoll < (critStat - 100);
        if (isCrit) bulletDmg = Math.round(bulletDmg * (isRedCrit ? 2.5 : 1.5));

        // Visual spread
        const baseSpread = 0.08;
        const survSpreadMod = (opts.state.survivorMods && opts.state.survivorMods.weaponSpread) || 0;
        const spread = baseSpread * (1 - Math.min(1, (eqStats.accuracy || 0) / 100)) * Math.max(0.1, 1 + survSpreadMod);
        const finalAngle = opts.aimAngle + (Math.random() - 0.5) * spread;

        // === BULLET CREATION (via renderer) ===
        let bullet = null;
        if (R) {
            bullet = R.createBullet(scene, opts.bullets, sx, sy, fxId, fx, finalAngle, CONFIG.player.bulletSpeed, {
                damage: didMiss ? 0 : bulletDmg,
                isCrit, isRedCrit, didMiss, fx, sigs,
                isFirepower: !!opts.state._firepowerActive,
                isParasitic: (opts.state._parasiticRounds || 0) > 0,
                pierceChance: Math.min(1, (eqStats.pierce || 1) * 0.2)
            });
        }
        if (!bullet) return false;
        if (bullet._isParasitic) opts.state._parasiticRounds--;

        // Perfect dodge boost
        if (scene._nextShotBoosted) {
            bullet.damage = Math.round(bullet.damage * 2);
            bullet.isCrit = true;
            scene._nextShotBoosted = false;
            if (R) R.perfectDodgeFlash(scene, sx, sy);
        }

        // === MUZZLE FLASH + RECOIL + TRACER (via renderer) ===
        if (R) {
            R.muzzleFlash(scene, sx, sy, opts.aimAngle, fx, isCrit);
            R.playerRecoil(scene, opts.player, opts.aimAngle, isCrit);
            if (isCrit) R.cameraShake(scene, 50, 0.004);
            R.createTracer(scene, sx, sy, opts.aimAngle, fx);
        }

        // Dabloon: second bullet
        if (dabloon && !bullet._isDabloonClone && R) {
            const d2Angle = opts.aimAngle + (Math.random() - 0.5) * 0.12;
            const d2 = R.createBullet(scene, opts.bullets, sx, sy, fxId, fx, d2Angle, CONFIG.player.bulletSpeed, {
                damage: bullet.damage, isCrit: bullet.isCrit, isRedCrit: bullet.isRedCrit,
                didMiss: bullet.didMiss, fx, sigs, isFirepower: bullet._isFirepower,
                isParasitic: false, pierceChance: bullet.pierceChance, isDabloonClone: true
            });
            if (d2) bullet._dabloonExtraAmmo = true;
        }

        // Burst fire
        if (weapon && weapon.burstCount && weapon.burstCount > 1 && R) {
            const extraShots = weapon.burstCount - 1;
            const burstDelay = weapon.burstDelay || 60;
            for (let i = 1; i <= extraShots; i++) {
                R.delayedCall(scene, burstDelay * i, () => {
                    if (opts.state.dead) return;
                    if (opts.state._powerAmmoActive) {
                        if ((opts.state.powerAmmo || 0) < 1) return;
                        opts.state.powerAmmo -= 1;
                    }
                    const bsx = opts.player.x + Math.cos(opts.aimAngle) * 14;
                    const bsy = opts.player.y + Math.sin(opts.aimAngle) * 14;
                    const bSpread = (Math.random() - 0.5) * 0.08;
                    const bb = R.createBullet(scene, opts.bullets, bsx, bsy, fxId, fx,
                        opts.aimAngle + bSpread, CONFIG.player.bulletSpeed, {
                        damage: bulletDmg, isCrit: false, isRedCrit: false, didMiss: false,
                        fx, sigs: [], isFirepower: false, isParasitic: false,
                        pierceChance: bullet.pierceChance
                    });
                    if (bb) R.burstMuzzleFlash(scene, bsx, bsy, fx);
                });
            }
        }

        // Alert enemies
        if (opts.alertEnemies && scene.enemies) {
            scene.enemies.getChildren().forEach(e => { if (e.active) { e.aiState = 'chase'; e.alertTimer = 5; } });
        }
        if (opts.dormantEnemies) {
            opts.dormantEnemies.forEach(de => {
                if (!de.isAwake) {
                    const dd = _dist(opts.player.x, opts.player.y, de.x, de.y);
                    if (dd < 150) de.aggroRange = 999;
                }
            });
        }

        const fireRate = Math.max(80, 1200 - (eqStats.fireRate || 1) * 11);
        return { fireRate };
    },

    // === DAMAGE ENEMY ===
    damageEnemy(scene, enemy, dmg, source, player, state, equipment) {
        if (!enemy || !enemy.active || enemy._dying) return 0;
        const R = CombatSystem._renderer;

        // Miss
        if (source === 'miss') {
            if (R) R.damageNumber(scene, enemy.x + (Math.random()-0.5)*12, enemy.y - 15, 'MISSED', { color: '#888888', fontSize: 11, duration: 600 });
            return 0;
        }

        // Shield check
        if (enemy.hasShield && enemy.shieldHP > 0) {
            const sc = CONFIG.shieldConfig;
            let shieldDmg = 0;
            if (source === 'melee' || source === 'shockwave') {
                const eqS = equipment ? ItemManager.getEquipmentStats(equipment) : {};
                shieldDmg = Math.round(dmg * sc.meleeMultiplier * Math.max(1, (eqS.shieldAttack || 1) * 0.5));
            } else if (state && state._powerAmmoActive) {
                shieldDmg = Math.round(dmg * sc.powerAmmoMultiplier);
            }
            if (shieldDmg <= 0) {
                if (R) R.shieldBlockVFX(scene, enemy);
                return 0;
            }
            enemy.shieldHP -= shieldDmg;
            if (R) R.damageNumber(scene, enemy.x + 10, enemy.y - 18, `-${shieldDmg}`, { color: '#44aaff', fontSize: 10, duration: 350 });
            if (enemy.shieldHP <= 0) {
                enemy.shieldHP = 0;
                enemy.hasShield = false;
                if (R) { R.shieldBreakVFX(scene, enemy); R.audioUiClick(); }
            } else {
                if (R) R.hitFlash(scene, enemy, 0x4488ff, 80);
            }
            return 0;
        }

        let finalDmg = dmg;

        // Damage bonuses (logic)
        if (scene._bloodPactDmgBonus && scene._bloodPactDmgBonus > 0) finalDmg = Math.round(finalDmg * (1 + scene._bloodPactDmgBonus / 100));
        if (scene._warTotemActive && scene._warTotemDmgBonus > 0) {
            const wDist = _dist(player.x, player.y, scene._warTotemX || 0, scene._warTotemY || 0);
            if (wDist < 65) finalDmg = Math.round(finalDmg * (1 + scene._warTotemDmgBonus));
        }
        const zoneBonus = ConsumableSystem.getDamageZoneBonus(scene, player);
        if (zoneBonus > 0) finalDmg = Math.round(finalDmg * (1 + zoneBonus / 100));

        enemy.hp -= finalDmg;

        if (scene._runStats) { scene._runStats.damageDealt += finalDmg; enemy._lastDamageSource = source; }

        // Hit feedback (rendering)
        if (R) {
            const flashColor = source === 'melee' ? 0xffaa44 : source === 'dodge' ? 0xccddee : 0xffffff;
            R.hitFlash(scene, enemy, flashColor, 80);
            if (source === 'bullet' || source === 'crit' || source === 'redcrit') R.impactRing(scene, enemy.x, enemy.y, source);
            if (source === 'melee' || source === 'dodge' || source === 'crit' || source === 'redcrit') R.hitStop(scene, enemy, 40);
        }

        // Damage number
        let color, fs;
        if (source === 'redcrit') { color = '#ff2222'; fs = 16; }
        else if (source === 'crit') { color = '#ffcc00'; fs = 14; }
        else if (source === 'melee') { color = '#ffcc44'; fs = 12; }
        else if (source === 'shockwave') { color = '#ff4466'; fs = 12; }
        else if (source === 'dodge') { color = '#ccddee'; fs = 14; }
        else { color = '#ff4444'; fs = 12; }
        if (R) R.damageNumber(scene, enemy.x, enemy.y - 15, `-${finalDmg}`, { color, fontSize: fs, duration: 400 });

        // Knockback
        if (!enemy._staggered) {
            const ang = _angle(player.x, player.y, enemy.x, enemy.y);
            const kbForce = source === 'melee' ? 200 : source === 'dodge' ? 180 : source === 'redcrit' ? 160 : 120;
            if (enemy.setVelocity) enemy.setVelocity(Math.cos(ang) * kbForce, Math.sin(ang) * kbForce);
        }

        // Alert
        enemy.awareness = 100;
        enemy.aiState = 'chase';
        enemy.lastKnownPos = { x: player.x, y: player.y };

        return finalDmg;
    },

    // === MELEE ===
    melee(scene, opts) {
        const R = CombatSystem._renderer;
        const eqStats = ItemManager.getEquipmentStats(opts.equipment);
        const mRange = Math.max(eqStats.meleeRange || 0, CONFIG.player.meleeRange);
        let mDmg = eqStats.meleeDamage || CONFIG.player.meleeDamage;

        // Survivor mark/rank multiplier
        const _msMods = opts.state.survivorMods;
        if (_msMods && _msMods.statMultiplier !== 1) mDmg = Math.round(mDmg * _msMods.statMultiplier);
        const _msConds = _msMods?.conditionals;
        if (_msConds && _msConds.spiteBonus) {
            const _msMaxHP = CONFIG.player.health + (eqStats.maxHealth || 0);
            if (opts.state.health / _msMaxHP < _msConds.spiteThreshold) mDmg = Math.round(mDmg * (1 + _msConds.spiteBonus));
        }
        if (eqStats.gymDamageBonus) mDmg = Math.round(mDmg * (1 + eqStats.gymDamageBonus / 100));

        const mSigs = eqStats.signatures || [];
        const mBerserker = mSigs.find(s => s.effect === 'berserker');
        if (mBerserker) mDmg = Math.round(mDmg * SignatureEffects.calcBerserkerBonus(mBerserker, opts.state.health, CONFIG.player.health + (eqStats.maxHealth || 0)));

        // Find closest target
        let meleeTarget = null;
        let closestDist = mRange;
        opts.enemies.getChildren().forEach(e => {
            if (!e.active) return;
            const d = _dist(opts.player.x, opts.player.y, e.x, e.y);
            if (d < closestDist) { closestDist = d; meleeTarget = e; }
        });
        if (!meleeTarget) return false;

        if (R) R.audioMelee();
        Haptics.medium();
        EventBus.emit('melee', { scene });

        const swingAngle = _angle(opts.player.x, opts.player.y, meleeTarget.x, meleeTarget.y);

        // Foundry melee FX
        const meleeItem = opts.equipment && opts.equipment.melee;
        const mfxId = meleeItem && meleeItem.foundry ? meleeItem.foundry : 'scrap';
        const mfx = CONFIG.foundryMeleeFX[mfxId] || CONFIG.foundryMeleeFX.scrap;
        const meleeType = meleeItem ? ((CONFIG.baseItems[meleeItem.baseId] || {}).sprite || 'blade') : 'blade';

        // Swing visual + VFX via renderer
        if (R) {
            if (typeof scene.meleeSwing === 'function') scene.meleeSwing(swingAngle);
            R.meleeSwingVFX(scene, opts.player, swingAngle, mfx, meleeType, mRange);
            R.meleeImpactSparks(scene, opts.player, swingAngle, mfx);
        }

        // Lunge
        const lungeDist = Math.min(12, closestDist * 0.4);
        if (R) R.lungeTween(scene, opts.player, swingAngle, lungeDist);

        // Brief melee i-frames
        scene.isInvincible = true;
        if (R) R.delayedCall(scene, 100, () => { if (!scene.isDodging) scene.isInvincible = false; });
        else setTimeout(() => { if (!scene.isDodging) scene.isInvincible = false; }, 100);

        // Signature checks
        const massAtkStat = eqStats.massAttack || 1;
        const massAtkChance = Math.min(1, massAtkStat * 0.2);
        const whirlwind = mSigs.find(s => s.effect === 'whirlwind');
        const whirlwindActive = whirlwind && SignatureEffects.isReady(scene, 'whirlwind', whirlwind.cooldown || 5000);
        if (whirlwindActive) SignatureEffects.trigger(scene, 'whirlwind', whirlwind.cooldown || 5000);
        const shackled = mSigs.find(s => s.effect === 'shackled');
        const shackledReady = shackled && SignatureEffects.isReady(scene, 'shackled', shackled.cooldown || 15000);

        // === HIT ENEMIES ===
        let hitCount = 0, totalDmgDealt = 0, killCount = 0;
        opts.enemies.getChildren().forEach(e => {
            if (!e.active) return;
            const d = _dist(opts.player.x, opts.player.y, e.x, e.y);
            if (d < mRange) {
                if (whirlwindActive || hitCount === 0 || Math.random() < massAtkChance) {
                    let finalDmg = mDmg;

                    const finisher = mSigs.find(s => s.effect === 'finisher');
                    if (finisher && SignatureEffects.checkFinisher(finisher, e)) {
                        finalDmg = e.hp;
                        if (R) R.finisherText(scene, e.x, e.y);
                    }

                    const wasAlive = e.hp > 0;
                    const dealt = opts.onDamage(e, finalDmg, 'melee');
                    totalDmgDealt += (dealt || finalDmg);
                    hitCount++;

                    const vampiric = mSigs.find(s => s.effect === 'vampiric');
                    if (vampiric) SignatureEffects.doVampiricHit(scene, opts.state, opts.equipment);
                    const reaper = mSigs.find(s => s.effect === 'reaper');
                    if (reaper && e.active) SignatureEffects.tryReaper(scene, e, reaper);

                    // Stagger
                    if (e.active && !e.isBoss) {
                        const staggerChance = Math.min(0.95, (eqStats.meleeStagger || 0) / 100);
                        if (Math.random() < staggerChance) {
                            const ka = Math.atan2(e.y - opts.player.y, e.x - opts.player.x);
                            if (e.setVelocity) e.setVelocity(Math.cos(ka) * 250, Math.sin(ka) * 250);
                            e._staggered = true;
                            if (R) R.staggerVFX(scene, e, 300);
                            else setTimeout(() => { if (e.active) e._staggered = false; }, 300);
                        }
                    }

                    if (wasAlive && (!e.active || e.hp <= 0)) killCount++;
                }
            }
        });

        // Shackled bane
        if (shackledReady && hitCount > 0 && meleeTarget) {
            SignatureEffects.doShackled(scene, meleeTarget, shackled);
            if (R) R.floatingText(scene, opts.player.x, opts.player.y - 30, 'SHACKLED', { color: '#ffaa22', fontSize: 10, bold: true });
        }

        // Whirlwind VFX
        if (whirlwindActive && hitCount > 0 && R) {
            R.whirlwindVFX(scene, opts.player, mRange);
        }

        // Melee kill sustain
        if (killCount > 0) {
            const baseHeal = 2 + killCount;
            const maxHp = CONFIG.player.health + (eqStats.maxHealth || 0);
            const heal = Math.min(baseHeal, maxHp - opts.state.health);
            if (heal > 0) {
                opts.state.health += heal;
                if (R) R.floatingText(scene, opts.player.x, opts.player.y - 20, `+${heal}`, { color: '#44ff88', fontSize: 10 });
            }
        }

        if (hitCount > 0 && R) R.cameraShake(scene, 60, 0.008 + hitCount * 0.003);

        // Lifesteal
        if (eqStats.lifesteal > 0 && totalDmgDealt > 0) {
            const heal = Math.round(totalDmgDealt * eqStats.lifesteal / 100);
            if (heal > 0) {
                opts.state.health = Math.min(CONFIG.player.health + (eqStats.maxHealth || 0), opts.state.health + heal);
                if (R) R.floatingText(scene, opts.player.x, opts.player.y - 30, `+${heal}`, { color: '#44ff44', fontSize: 10 });
            }
        }

        // Alert nearby
        opts.enemies.getChildren().forEach(e => { if (e.active) { e.aiState = 'chase'; e.alertTimer = 4; } });

        const cooldown = Math.max(150, 1200 - (eqStats.meleeSpeed || 1) * 10);
        return { cooldown, hitCount, killCount };
    },

    // === KILL EFFECTS ===
    applyKillEffects(scene, enemy, player, state, equipment) {
        const R = CombatSystem._renderer;
        const eqStats = ItemManager.getEquipmentStats(equipment);
        const cfg = CONFIG.enemyTypes[enemy.enemyType] || CONFIG.enemyTypes.husk;

        // Signature kill effects
        if (eqStats.signatures) {
            const vampiric = eqStats.signatures.find(s => s.effect === 'vampiric');
            if (vampiric) SignatureEffects.doVampiricKill(scene, state, equipment, vampiric);
            const anotherWorld = eqStats.signatures.find(s => s.effect === 'anotherWorld');
            if (anotherWorld) SignatureEffects.spawnHealingCube(scene, enemy, anotherWorld);
        }

        // Death VFX via renderer
        if (R) {
            R.cubeShatterVFX(scene, enemy.x, enemy.y, cfg);
            R.bloodSquaresVFX(scene, enemy.x, enemy.y);
            R.bloodStainVFX(scene, enemy.x, enemy.y);
        }
    },

    // === FLAIR EFFECTS (delegated entirely to renderer) ===
    updateFlairEffects(scene) {
        if (CombatSystem._renderer) CombatSystem._renderer.updateFlairEffects(scene);
    }
};
