// Vestige GPS — RealtimeTOD
// Time-of-day from system clock. No dependencies.

export const RealtimeTOD = {
    // Returns tod string based on local hour
    getFromClock() {
        const h = new Date().getHours();
        if (h >= 5 && h < 9) return 'dawn';
        if (h >= 9 && h < 17) return 'midday';
        if (h >= 17 && h < 20) return 'dusk';
        return 'night'; // 20:00–04:59
    },

    // Returns sun/moon icon data for CRT display
    getCelestialIcon() {
        const tod = this.getFromClock();
        const h = new Date().getHours();
        if (tod === 'night') return { type: 'moon', phase: this.getMoonPhase(), hour: h };
        if (tod === 'dawn') return { type: 'sun', elevation: 'low', hour: h };
        if (tod === 'dusk') return { type: 'sun', elevation: 'low', hour: h };
        return { type: 'sun', elevation: 'high', hour: h };
    },

    // Simple moon phase (8 phases over 29.5 day cycle)
    getMoonPhase() {
        const known = new Date(2000, 0, 6).getTime(); // known new moon
        const diff = Date.now() - known;
        const days = diff / (1000 * 60 * 60 * 24);
        const phase = ((days % 29.53) / 29.53) * 8;
        return Math.floor(phase); // 0=new, 2=first quarter, 4=full, 6=last quarter
    },

    // Draw sun/moon icon on CRT screen at given position
    drawCelestialIcon(graphics, x, y, crtPalette) {
        const info = this.getCelestialIcon();
        const glow = crtPalette.glow || 0x22aa22;
        const bright = crtPalette.glowBright || 0x44cc44;

        if (info.type === 'sun') {
            // Sun circle
            graphics.fillStyle(bright, 0.9);
            graphics.fillCircle(x, y, 5);
            // Rays
            graphics.lineStyle(1, glow, 0.6);
            for (let a = 0; a < Math.PI * 2; a += Math.PI / 4) {
                const r1 = 7, r2 = 10;
                graphics.beginPath();
                graphics.moveTo(x + Math.cos(a) * r1, y + Math.sin(a) * r1);
                graphics.lineTo(x + Math.cos(a) * r2, y + Math.sin(a) * r2);
                graphics.stroke();
            }
            // Low elevation = half below horizon line
            if (info.elevation === 'low') {
                graphics.fillStyle(0x000000, 0.8);
                graphics.fillRect(x - 12, y + 2, 24, 12);
                graphics.lineStyle(1, glow, 0.4);
                graphics.beginPath(); graphics.moveTo(x - 11, y + 2); graphics.lineTo(x + 11, y + 2); graphics.stroke();
            }
        } else {
            // Moon — crescent style
            graphics.fillStyle(bright, 0.8);
            graphics.fillCircle(x, y, 5);
            // Shadow bite for crescent (skip if full moon phase 4)
            const phase = info.phase;
            if (phase !== 4) {
                const shadowX = phase < 4 ? x + 3 : x - 3;
                const shadowAlpha = phase === 0 ? 0.95 : (Math.abs(phase - 4) / 4) * 0.7;
                graphics.fillStyle(0x000000, shadowAlpha);
                graphics.fillCircle(shadowX, y, 4.5);
            }
            // Stars around moon
            graphics.fillStyle(glow, 0.4);
            graphics.fillCircle(x - 9, y - 4, 0.8);
            graphics.fillCircle(x + 7, y + 5, 0.6);
            graphics.fillCircle(x + 10, y - 2, 0.7);
        }
    }
};

// ============================================
// WEATHER SYSTEM — Real weather mapped to biome-appropriate effects
// Uses wttr.in for simple weather codes, cached for 30 min
// ============================================
