// Vestige GPS — EnemyManager
// Enemy spawning, pooling, death, loot
// Rendering decoupled: call EnemyManager.init(renderer) with visual implementation

import { Blurbs } from './blurbs.js';
import { CONFIG } from '../data/config.js';
import { CombatSystem } from './combatSystem.js';
import { ConsumableSystem } from './consumableSystem.js';
import { DOTSystem } from './dotSystem.js';
import { EventBus } from './eventBus.js';
import { Haptics } from './haptics.js';
import { ItemManager } from './itemManager.js';
import { SignatureEffects } from './signatureEffects.js';

export const EnemyManager = {
    _renderer: null,

    /**
     * Set renderer for enemy visuals.
     * Renderer should implement:
     *   createSprite(scene, x, y, type, cfg) → sprite (physics-enabled)
     *   spawnAnimation(scene, sprite)
     *   addShadow(scene, sprite)
     *   deathAnimation(scene, enemy, callback)
     *   bloodPool(scene, x, y, cfg, wasCrit)
     *   bloodSplatter(scene, x, y, cfg)
     *   acidFadeout(scene, gfx)
     *   hitFeedback(scene, enemy) — tint flash, camera shake, VFX
     *   dodgeFeedback(scene, durationMs) — alpha flicker on dodge
     *   iFrames(scene, durationMs)
     *   audioEnemyDeath()
     *   audioPlayerHit()
     *   applyAmbientTint(sprite, tint)
     */
    init(renderer) {
        EnemyManager._renderer = renderer;
    },

    // -------------------------------------------------------
    // SPAWN — Creates and configures an enemy
    // opts: { hpMult, speedMult, forceShield, aiState, patrolPoint, caravanTarget }
    // -------------------------------------------------------
    createEnemy(scene, x, y, type = 'husk', opts = {}) {
        const cfg = CONFIG.enemyTypes[type];
        if (!cfg) return null;
        
        // Create sprite via renderer
        let e;
        if (EnemyManager._renderer) {
            e = EnemyManager._renderer.createSprite(scene, x, y, type, cfg);
        }
        if (!e) return null;
        
        e.enemyType = type;
        
        // HP with optional multipliers
        const hpMult = opts.hpMult || 1;
        e.hp = Math.round(cfg.health * hpMult);
        e.maxHp = e.hp;
        e._speedMult = opts.speedMult || 1;
        e.canAttack = true;
        
        // AI State
        e.aiState = opts.aiState || 'chase';
        e.stuckTimer = 0;
        e.lastPos = { x, y };
        if (opts.patrolPoint) {
            e.patrolTarget = opts.patrolPoint;
            e.patrolPauseTimer = 0;
        }
        if (type === 'husk_crawl' || type === 'crawler') e._isCrawler = true;
        
        // Husk personality — pack/stray/lurcher
        if (type === 'husk') {
            const roll = Math.random();
            if (roll < 0.60) {
                e._huskPersonality = 'pack';
            } else if (roll < 0.85) {
                e._huskPersonality = 'stray';
                e._strayAngleOffset = (Math.random() > 0.5 ? 1 : -1) * (0.4 + Math.random() * 0.5);
                e._speedMult = (e._speedMult || 1) * (1.05 + Math.random() * 0.1);
            } else {
                e._huskPersonality = 'lurcher';
                e._lurchTimer = 0;
                e._lurchPaused = false;
                e._lurchPauseDur = 800 + Math.random() * 1200;
                e._lurchMoveDur = 600 + Math.random() * 800;
            }
        }
        
        // Spawn animation + shadow via renderer
        if (EnemyManager._renderer) {
            EnemyManager._renderer.spawnAnimation(scene, e);
            EnemyManager._renderer.addShadow(scene, e);
        }
        if (scene.enemies) scene.enemies.add(e);
        
        // Shield roll
        const shieldChance = (CONFIG.shieldConfig.spawnChance[type] || 0) * (opts.shieldMult || 1);
        const forceShield = opts.forceShield || false;
        if (forceShield || (shieldChance > 0 && Math.random() < shieldChance)) {
            const sc = CONFIG.shieldConfig;
            e.shieldHP = sc.baseHP + (scene.state?.reach || 1) * sc.reachScale;
            e.shieldMaxHP = e.shieldHP;
            e.hasShield = true;
        }
        
        // Optional: defense mode caravan targeting
        if (opts.caravanTarget) e._targetingCaravan = true;
        
        // Apply time-of-day ambient tint
        if (EnemyManager._renderer && scene._ambientTint && scene._ambientTint !== 0xffffff) {
            EnemyManager._renderer.applyAmbientTint(e, scene._ambientTint);
        }
        
        return e;
    },

    // -------------------------------------------------------
    // KILL — Common cleanup, gore, and husk reactions
    // opts: { skipLoot, skipRunStats, deathTween, onPreGore, onPostKill }
    // Returns: { ex, ey } — death position for scene-specific logic
    // -------------------------------------------------------
    killEnemy(scene, enemy, opts = {}) {
        if (enemy._dying) return null;
        enemy._dying = true;
        
        // === SYSTEM CLEANUP ===
        DOTSystem.cleanupEnemyBar(enemy);
        if (enemy._activeTelegraph) { enemy._activeTelegraph.cancel(); enemy._activeTelegraph = null; }
        if (enemy._telegraphGfx) { enemy._telegraphGfx.destroy(); enemy._telegraphGfx = null; }
        enemy._attackActive = false;
        
        // Latched skitterling cleanup
        if (enemy._latched && scene._latchedSkitterlings) {
            enemy._latched = false;
            scene._latchedSkitterlings = scene._latchedSkitterlings.filter(s => s !== enemy);
        }
        // Spawn aura cleanup
        if (enemy._auraGfx) { enemy._auraGfx.destroy(); enemy._auraGfx = null; }
        if (enemy.enemyType === 'spawn') {
            if (scene.enemies) scene.enemies.getChildren().forEach(other => {
                if (other._spawnBuffed) { other._spawnBuffed = false; other._speedMult = 1; other._dmgMult = 1; }
            });
        }
        if (enemy._acidGfx) {
            const gfx = enemy._acidGfx;
            enemy._acidGfx = null;
            if (EnemyManager._renderer) {
                EnemyManager._renderer.acidFadeout(scene, gfx);
            } else {
                gfx.destroy();
            }
        }
        
        if (EnemyManager._renderer) EnemyManager._renderer.removeShadow(scene, enemy);
        scene.state.kills++;
        
        // Track kills on weapon/melee
        const eq = scene.state.equipment;
        if (enemy._lastDamageSource === 'melee') {
            if (eq?.melee) eq.melee.kills = (eq.melee.kills || 0) + 1;
        } else {
            if (eq?.weapon) eq.weapon.kills = (eq.weapon.kills || 0) + 1;
        }
        
        if (EnemyManager._renderer) EnemyManager._renderer.audioEnemyDeath();
        EventBus.emit('enemyKill', { scene, enemy, kills: scene.state.kills });
        
        // Clear lock if this was the locked target
        if (scene.lockedTarget === enemy) {
            scene.lockedTarget = null;
            if (scene.target !== undefined) scene.target = null;
        }
        
        // Blood Forged kill effects
        CombatSystem.applyKillEffects(scene, enemy, scene.player, scene.state, scene.state.equipment);
        
        // Run stats (GS only — CS has no _runStats)
        if (scene._runStats) {
            scene._runStats.kills++;
            if (enemy.enemyType === 'boss') scene._runStats.bossesKilled++;
            if (enemy._lastDamageSource === 'melee') scene._runStats.meleeKills++;
            scene._runStats.damageDealt += (enemy.maxHp || 0);
        }
        
        // Signature kill tracking
        SignatureEffects.onKill(scene, enemy);
        
        const ex = enemy.x, ey = enemy.y;
        const cfg = CONFIG.enemyTypes[enemy.enemyType];
        const wasCrit = enemy._lastHitCrit;
        
        // Pre-gore hook (scene-specific — e.g. loot drop markers)
        if (opts.onPreGore) opts.onPreGore(ex, ey, cfg);
        
        // Blood pool + splatter via renderer
        if (EnemyManager._renderer) {
            EnemyManager._renderer.bloodPool(scene, ex, ey, cfg, wasCrit);
            EnemyManager._renderer.bloodSplatter(scene, ex, ey, cfg);
        }
        
        // Nearby husk reactions: stumble or frenzy
        if (scene.enemies) {
            const nearby = scene.enemies.getChildren().filter(
                other => other !== enemy && other.active && !other._dying
            );
            nearby.forEach(other => {
                const dx = other.x - ex, dy = other.y - ey;
                const d = Math.sqrt(dx * dx + dy * dy);
                if (d < 70 && other.enemyType === 'husk') {
                    const roll = Math.random();
                    if (roll < 0.4) {
                        if (!other._stumbling) {
                            const recoilAngle = Math.atan2(other.y - ey, other.x - ex);
                            if (other.setVelocity) other.setVelocity(Math.cos(recoilAngle) * 30, Math.sin(recoilAngle) * 30);
                            other.canAttack = false;
                            if (EnemyManager._renderer) {
                                EnemyManager._renderer.delayedCall(scene, 250, () => { if (other.active) other.canAttack = true; });
                            }
                        }
                    } else {
                        other._frenzyUntil = (scene.time ? scene.time.now : Date.now()) + 2000;
                    }
                }
            });
        }
        
        // Post-kill hook (loot drops, etc.)
        if (opts.onPostKill) opts.onPostKill(ex, ey, cfg);
        
        // Death animation
        if (opts.deathTween) {
            opts.deathTween(scene, enemy);
        } else if (EnemyManager._renderer) {
            EnemyManager._renderer.deathAnimation(scene, enemy);
        } else {
            if (enemy.active) enemy.destroy();
        }
        
        return { ex, ey };
    },

    // -------------------------------------------------------
    // CONTACT DAMAGE — Shared enemy-touches-player pipeline
    // opts: { todDamage, defDodge, runStats, onDeath }
    // -------------------------------------------------------
    enemyHitPlayer(scene, enemy, opts = {}) {
        if (scene.isInvincible || scene.state.dead || !enemy.canAttack) return;
        
        // Contact exclusions
        const _ncCfg = CONFIG.enemyTypes[enemy.enemyType];
        if (_ncCfg && _ncCfg.noContactDamage) return;
        if (_ncCfg && _ncCfg.attackCommit && !enemy._attackActive) return;
        
        if (scene._godMode) { scene.state.health = 999; return; }
        
        // Equipment dodge chance
        const _eqStats = scene._eqStats || ItemManager.getEquipmentStats(scene.state.equipment);
        const _defDodge = opts.defDodge || 0;
        const _totalDodge = _defDodge + (_eqStats.dodgeChance || 0);
        if (_totalDodge > 0 && Math.random() * 100 < _totalDodge) {
            enemy.canAttack = false;
            const cfg = CONFIG.enemyTypes[enemy.enemyType];
            if (EnemyManager._renderer) {
                EnemyManager._renderer.delayedCall(scene, cfg ? cfg.attackCooldown : 1000, () => { if (enemy.active) enemy.canAttack = true; });
                EnemyManager._renderer.dodgeFeedback(scene, 200);
            }
            Blurbs.show(scene, scene.player, 'DODGE', { color: '#66ccff', fontSize: 11, duration: 400 });
            return;
        }
        
        // Phantom Step: mark-based dodge chance
        const _phDodge = scene.state.survivorMods?.conditionals?.phantomDodgeChance || 0;
        const _phMov = scene.state.survivorMods?.conditionals?.phasedDodgeChance || 0;
        const _phTotal = _phDodge + (scene.player && scene.player.body && scene.player.body.velocity.length() > 10 ? _phMov : 0);
        if (_phTotal > 0 && Math.random() < _phTotal) {
            enemy.canAttack = false;
            const cfgPh = CONFIG.enemyTypes[enemy.enemyType];
            if (EnemyManager._renderer) {
                EnemyManager._renderer.delayedCall(scene, cfgPh ? cfgPh.attackCooldown : 1000, () => { if (enemy.active) enemy.canAttack = true; });
                EnemyManager._renderer.dodgeFeedback(scene, 200);
            }
            Blurbs.show(scene, scene.player, 'PHANTOM', { color: '#aa88ff', fontSize: 11, duration: 400 });
            return;
        }
        
        const cfg = CONFIG.enemyTypes[enemy.enemyType];
        if (!cfg) return;
        const todMult = opts.todDamage || 1.0;
        let dmg = Math.round(cfg.damage * todMult * (enemy._dmgMult || 1));
        
        // Temp armor absorption
        if (scene._tempArmor && scene._tempArmor > 0) {
            const absorbed = Math.min(scene._tempArmor, dmg);
            scene._tempArmor -= absorbed;
            dmg -= absorbed;
        }
        
        // Equipment armor + damage resist
        if (_eqStats.armor > 0) dmg = Math.max(1, Math.round(dmg * (1 - _eqStats.armor / 100)));
        if (_eqStats.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - _eqStats.damageResist / 100)));
        
        // Survivor mark damage resistance
        const _emMods = scene.state.survivorMods;
        if (_emMods && _emMods.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - _emMods.damageResist)));
        
        // Threshold mark: dynamic resist based on HP ratio
        const _emConds = _emMods?.conditionals;
        if (_emConds && _emConds.thresholdHigh) {
            const _emMaxHP = scene.state.maxHealth || (CONFIG.player.health + (_eqStats.maxHealth || 0));
            const _emRatio = scene.state.health / _emMaxHP;
            const _emThreshR = _emRatio < _emConds.thresholdHigh ? _emConds.thresholdResistBelow : _emConds.thresholdResistAbove;
            if (_emThreshR) dmg = Math.max(1, Math.round(dmg * (1 - _emThreshR)));
        }
        
        // Fracture Point: first hit multiplier
        if (_emConds && _emConds.firstHitMultiplier && !scene._firstHitTaken) {
            scene._firstHitTaken = true;
            dmg = Math.max(1, Math.round(dmg * _emConds.firstHitMultiplier));
            Blurbs.show(scene, scene.player, 'FRACTURE', { color: '#ff6644', fontSize: 10, duration: 500 });
        }
        
        // Blood Pact + Hardened + Sheltered
        if (scene._bloodPactResist && scene._bloodPactResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - scene._bloodPactResist / 100)));
        if (scene._hardenedActive && scene._hardenedReduction) dmg = Math.max(1, Math.round(dmg * (1 - scene._hardenedReduction)));
        if (scene._shelteredActive) dmg = Math.max(1, Math.round(dmg * 0.8));
        
        enemy.canAttack = false;
        scene.state.health -= dmg;
        if (scene._lastCombatTime !== undefined && scene.time) scene._lastCombatTime = scene.time.now;
        if (EnemyManager._renderer) EnemyManager._renderer.audioPlayerHit();
        Haptics.heavy();
        ConsumableSystem.interruptChannel();
        EventBus.emit('playerHit', { scene, dmg, health: scene.state.health });
        if (scene._runStats) scene._runStats.damageTaken += dmg;
        
        // Melee Reflect
        const _reflectPct = scene.state.survivorMods?.conditionals?.meleeReflect || 0;
        if (_reflectPct > 0 && enemy.active) {
            const reflDmg = Math.max(1, Math.round(dmg * _reflectPct));
            enemy.hp -= reflDmg;
            Blurbs.show(scene, enemy, `-${reflDmg}`, { color: '#aa44cc', fontSize: 9, duration: 400 });
            if (enemy.hp <= 0 && enemy.active) { enemy.hp = 0; EnemyManager.killEnemy(scene, enemy); }
        }
        
        SignatureEffects.buildBloodPactStack(scene);
        if (scene.hud && scene.hud.updateHP) scene.hud.updateHP(scene.state.health, scene.state.maxHealth);
        
        // Visual feedback via renderer
        if (EnemyManager._renderer) {
            EnemyManager._renderer.hitFeedback(scene, enemy);
        }
        Blurbs.show(scene, scene.player, `-${dmg}`, { color: '#ff4444', fontSize: 10, duration: 500 });
        
        // Flicker blades: 30% bleed on contact
        if (enemy.enemyType === 'flicker' && Math.random() < 0.3) {
            DOTSystem.applyToPlayer(scene, 'bleed');
        }
        
        // Attack cooldown + invincibility frames
        if (EnemyManager._renderer) {
            EnemyManager._renderer.delayedCall(scene, cfg.attackCooldown || 1000, () => { if (enemy.active) enemy.canAttack = true; });
            EnemyManager._renderer.iFrames(scene, 500);
        }
        
        // Death handling
        if (scene.state.health <= 0) {
            if (opts.onDeath) {
                opts.onDeath(dmg, _eqStats);
            } else {
                scene.state.health = 0;
            }
        }
    },
};
