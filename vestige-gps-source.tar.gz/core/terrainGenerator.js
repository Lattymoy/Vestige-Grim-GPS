// Vestige GPS — TerrainGenerator
// Procedural combat map terrain from biome type

import { CONFIG } from '../data/config.js';
import { Utils } from './utils.js';

export class TerrainGenerator {
    constructor(scene, biomeType, seed = null, locationType = null) {
        this.scene = scene;
        this.biome = CONFIG.biomes[biomeType] || CONFIG.biomes.grassy;
        this.biomeType = biomeType;
        this.locationType = locationType;
        this.seed = seed || Date.now();
        
        // Attach RNG utilities
        Utils.attachRNG(this, this.seed);
        
        this.w = CONFIG.world.width;
        this.h = CONFIG.world.height;
        
        // Map size scaling factors
        const ms = CONFIG.activeMapSize || CONFIG.mapSizes.medium;
        this.scale = {
            building: ms.buildingScale || 1,
            prop: ms.propScale || 1,
            tree: ms.treeScale || 1,
            spawn: ms.spawnScale || 1,
            loot: ms.lootScale || 1,
            groundDetail: ms.groundDetailScale || 1
        };
        
        // Placement tracking
        this.placedObjects = [];
        this.buildingDoors = [];
        this.spawnPoints = [];
    }
    
    // Main generation function
    generate() {
        const result = {
            groundColor: this.biome.groundColor,
            biomeType: this.biomeType,
            buildings: [],
            props: [],
            trees: [],
            spawnPoints: [],
            buildingDoors: [],
            vehicles: []
        };
        
        // Generate road (always horizontal)
        this.road = this.generateRoad();
        result.road = this.road;
        
        // Generate buildings from biome pool
        this.buildings = this.generateBuildings();
        result.buildings = this.buildings;
        result.buildingDoors = this.buildingDoors;
        
        // Generate shell buildings (open ruins — walk-through, no interior scene)
        result.shellBuildings = this.generateShellBuildings();
        
        // Generate environmental storytelling scenes
        result.storyScenes = this.generateStoryScenes();
        
        // Generate props from biome weighted pool
        result.props = this.generateProps();
        
        // Generate roadside vehicle wrecks
        result.vehicles = this.generateRoadsideVehicles();
        
        // Generate trees (biome-aware)
        result.trees = this.generateTrees();
        
        // Generate spawn points
        result.spawnPoints = this.generateSpawnPoints();
        
        return result;
    }
    
    generateRoad() {
        const road = { type: 'horizontal', segments: [] };
        road.segments.push({
            x: this.w / 2,
            y: this.h / 2,
            width: this.w,
            height: 70
        });
        this.placedObjects.push({
            x: 0, y: this.h / 2 - 65,
            width: this.w, height: 130,
            isRoad: true
        });
        return road;
    }
    
    // Pick a random item from a weighted pool: [{ type, weight }, ...]
    weightedPick(pool) {
        const totalWeight = pool.reduce((sum, entry) => sum + entry.weight, 0);
        let roll = this.random() * totalWeight;
        for (const entry of pool) {
            roll -= entry.weight;
            if (roll <= 0) return entry.type;
        }
        return pool[pool.length - 1].type;
    }
    
    generateBuildings() {
        const buildings = [];
        const [minB, maxB] = this.biome.buildingCount;
        const count = Math.round(this.randomInt(minB, maxB) * this.scale.building);
        const damageChance = CONFIG.biomeDamageChance[this.biomeType] || 0.15;
        
        // Building zones: above and below the road
        const zones = [
            { x: 50, y: 50, width: this.w - 100, height: this.h / 2 - 130 },
            { x: 50, y: this.h / 2 + 80, width: this.w - 100, height: this.h / 2 - 130 }
        ];
        
        for (let i = 0; i < count; i++) {
            // First building uses location type's template if available
            let buildingType;
            if (i === 0 && this.locationType) {
                const locConfig = CONFIG.locations[this.locationType];
                buildingType = locConfig?.buildingTemplate || this.weightedPick(this.biome.buildings);
            } else {
                buildingType = this.weightedPick(this.biome.buildings);
            }
            const template = CONFIG.buildingTemplates[buildingType];
            if (!template) continue;
            
            const width = Array.isArray(template.width) 
                ? this.randomInt(template.width[0], template.width[1])
                : template.width;
            const height = Array.isArray(template.height)
                ? this.randomInt(template.height[0], template.height[1])
                : template.height;
            
            // Pick shape from template options
            const shapes = template.shapes || ['rect'];
            const shape = this.randomFromArray(shapes);
            
            // For L-shapes, calculate wing dimensions
            let wing = null;
            let totalBoundsW = width;
            let totalBoundsH = height;
            
            if (shape === 'L_right' || shape === 'L_left') {
                const wingW = this.randomInt(Math.floor(width * 0.35), Math.floor(width * 0.55));
                const wingH = this.randomInt(Math.floor(height * 0.35), Math.floor(height * 0.5));
                const side = shape === 'L_right' ? 1 : -1; // 1 = right, -1 = left
                wing = {
                    // Wing offset from main body center
                    dx: side * (width / 2 + wingW / 2 - 4), // overlap 4px for seamless join
                    dy: -(height / 2 - wingH / 2), // align top edges
                    w: wingW,
                    h: wingH,
                    side: side
                };
                totalBoundsW = width + wingW - 4;
                totalBoundsH = Math.max(height, wingH);
            }
            
            const pos = this.findBuildingPosition(totalBoundsW, totalBoundsH, zones);
            if (pos) {
                // Adjust center for L-shapes so bounding box stays in valid zone
                const cx = shape === 'L_right' ? pos.x - (wing ? wing.w / 2 - 2 : 0) :
                           shape === 'L_left' ? pos.x + (wing ? wing.w / 2 - 2 : 0) : pos.x;
                
                const damaged = template.alwaysDamaged || (this.random() < damageChance);
                
                // Resolve interior scale from template range
                const iScaleRange = template.interiorScale || [2.0, 2.5];
                const interiorScale = iScaleRange[0] + this.random() * (iScaleRange[1] - iScaleRange[0]);
                
                const building = {
                    x: cx,
                    y: pos.y,
                    width: width,
                    height: height,
                    color: template.color,
                    archetype: template.archetype,
                    subtype: template.subtype || null,
                    name: this.randomFromArray(template.names),
                    type: buildingType,
                    shape: shape,
                    wing: wing,
                    damaged: damaged,
                    interiorScale: interiorScale,
                    buildingId: `${Math.round(cx)}_${Math.round(pos.y)}_${buildingType}`
                };
                buildings.push(building);
                
                // Placement bounds — use total footprint + isometric overhang
                const isoOverhang = Math.min(height * 0.35, 30) + 20; // front face + door + steps
                this.placedObjects.push({
                    x: pos.x - totalBoundsW / 2 - 20,
                    y: pos.y - totalBoundsH / 2 - 15,
                    width: totalBoundsW + 40,
                    height: totalBoundsH + isoOverhang + 15,
                    isBuilding: true
                });
                
                // Register parking lot exclusion zone (lots go to right of building, or left if overflow)
                if (template.subtype !== 'house' && template.subtype !== 'church') {
                    const lotW = Math.min(width * 1.2, 160);
                    const lotH = 80;
                    const worldEdge = this.w - 10;
                    let lotX = cx + width / 2 + lotW / 2 + 15;
                    if (lotX + lotW / 2 > worldEdge) lotX = cx - width / 2 - lotW / 2 - 15;
                    lotX = Math.max(lotW / 2 + 5, Math.min(lotX, worldEdge - lotW / 2));
                    this.placedObjects.push({
                        x: lotX - lotW / 2 - 5,
                        y: pos.y - lotH / 2 - 5,
                        width: lotW + 10,
                        height: lotH + 10
                    });
                }
                
                // Register canopy exclusion for gas stations (canopy rendered at runtime)
                if (template.subtype === 'gas_station') {
                    const roadCenter = this.h / 2;
                    const canopySide = (pos.y < roadCenter) ? 1 : -1;
                    const canopyW = Math.min(width * 0.9, 80);
                    const canopyH = 40;
                    const canopyY = pos.y + canopySide * (height / 2 + 40);
                    this.placedObjects.push({
                        x: cx - canopyW / 2 - 10,
                        y: canopyY - canopyH / 2 - 10,
                        width: canopyW + 20,
                        height: canopyH + 20,
                        isCanopy: true
                    });
                }
                
                const roadCenter = this.h / 2;
                const isBelowRoad = pos.y > roadCenter;
                const doorY = isBelowRoad 
                    ? pos.y - height / 2 - 8  // North side — outside building, facing road
                    : pos.y + height / 2 - 22; // South side — on front face
                
                this.buildingDoors.push({
                    x: cx,
                    y: doorY,
                    buildingName: building.name,
                    archetype: building.archetype,
                    subtype: building.subtype,
                    buildingWidth: width,
                    buildingHeight: height,
                    interiorScale: interiorScale,
                    buildingId: `${Math.round(cx)}_${Math.round(pos.y)}_${buildingType}`
                });
            }
        }
        
        return buildings;
    }
    
    findBuildingPosition(width, height, zones) {
        for (let attempt = 0; attempt < 50; attempt++) {
            const zone = this.randomFromArray(zones);
            const x = zone.x + width / 2 + this.random() * (zone.width - width);
            const y = zone.y + height / 2 + this.random() * (zone.height - height);
            if (this.isPositionValid(x, y, width, height)) {
                return { x, y };
            }
        }
        return null;
    }
    
    isPositionValid(x, y, width, height, padding = 25) {
        const rect = {
            left: x - width / 2 - padding,
            right: x + width / 2 + padding,
            top: y - height / 2 - padding,
            bottom: y + height / 2 + padding
        };
        if (rect.left < 20 || rect.right > this.w - 20 ||
            rect.top < 20 || rect.bottom > this.h - 20) {
            return false;
        }
        for (const obj of this.placedObjects) {
            if (this.rectsOverlap(rect, {
                left: obj.x, right: obj.x + obj.width,
                top: obj.y, bottom: obj.y + obj.height
            })) {
                return false;
            }
        }
        return true;
    }
    
    rectsOverlap(a, b) {
        return !(a.right < b.left || a.left > b.right ||
                 a.bottom < b.top || a.top > b.bottom);
    }
    
    generateShellBuildings() {
        const shells = [];
        const shellRange = this.biome.shellCount || [0, 0];
        const count = Math.round(this.randomInt(shellRange[0], shellRange[1]) * (this.scale.building || 1));
        if (count === 0) return shells;
        
        // Shell building archetypes per biome
        const shellTypes = {
            grassy: [
                { name: 'Collapsed Garage', w: [50, 70], h: [40, 55], wallColor: 0x5a5a52, floorColor: 0x3a3a35, style: 'suburban' },
                { name: 'Ruined Shed', w: [35, 50], h: [30, 40], wallColor: 0x4a4a3a, floorColor: 0x3a3530, style: 'wood' },
            ],
            barren: [
                { name: 'Gutted Rest Stop', w: [55, 80], h: [40, 60], wallColor: 0x4a4540, floorColor: 0x353025, style: 'concrete' },
                { name: 'Stripped Station', w: [50, 70], h: [40, 55], wallColor: 0x3a3530, floorColor: 0x2a2520, style: 'concrete' },
                { name: 'Roofless Bunker', w: [40, 55], h: [35, 45], wallColor: 0x3a3a3a, floorColor: 0x2a2a28, style: 'military' },
            ],
            apocalyptic: [
                { name: 'Breached Lab', w: [50, 70], h: [40, 55], wallColor: 0x3a3540, floorColor: 0x252028, style: 'cube' },
                { name: 'Shattered Office', w: [55, 75], h: [40, 60], wallColor: 0x3a3a40, floorColor: 0x1a1a20, style: 'cube' },
            ]
        };
        
        const pool = shellTypes[this.biomeType] || shellTypes.barren;
        const zones = [
            { x: 50, y: 50, width: this.w - 100, height: this.h / 2 - 130 },
            { x: 50, y: this.h / 2 + 80, width: this.w - 100, height: this.h / 2 - 130 }
        ];
        
        for (let i = 0; i < count; i++) {
            const template = pool[Math.floor(this.random() * pool.length)];
            const sw = this.randomInt(template.w[0], template.w[1]);
            const sh = this.randomInt(template.h[0], template.h[1]);
            
            const pos = this.findBuildingPosition(sw + 20, sh + 20, zones);
            if (!pos) continue;
            
            // Pick which walls are missing (1-2 walls removed)
            const missingWalls = [];
            // South always has an opening
            missingWalls.push('south');
            // Maybe remove another wall
            if (this.random() < 0.4) {
                missingWalls.push(this.random() < 0.5 ? 'east' : 'west');
            }
            
            // Interior searchable props (1-3)
            const interiorProps = [];
            const lootTypes = ['Scrap', 'Parts', 'Wire', 'Cloth', 'Meds'];
            const propCount = 1 + Math.floor(this.random() * 3);
            for (let p = 0; p < propCount; p++) {
                interiorProps.push({
                    x: pos.x + this.randomInt(-sw/3, sw/3),
                    y: pos.y + this.randomInt(-sh/4, sh/4),
                    loot: [lootTypes[Math.floor(this.random() * lootTypes.length)]]
                });
            }
            
            shells.push({
                x: pos.x, y: pos.y, w: sw, h: sh,
                name: template.name,
                wallColor: template.wallColor,
                floorColor: template.floorColor,
                style: template.style,
                missingWalls: missingWalls,
                interiorProps: interiorProps
            });
            
            this.placedObjects.push({
                x: pos.x - sw/2 - 10, y: pos.y - sh/2 - 10,
                width: sw + 20, height: sh + 30,
                isBuilding: true
            });
        }
        return shells;
    }
    
    generateStoryScenes() {
        const scenes = [];
        const sceneRange = this.biome.sceneCount || [0, 0];
        const count = this.randomInt(sceneRange[0], sceneRange[1]);
        if (count === 0) return scenes;
        
        const pool = CONFIG.storyScenes[this.biomeType];
        if (!pool || pool.length === 0) return scenes;
        
        // Shuffle pool and pick up to count
        const shuffled = [...pool].sort(() => this.random() - 0.5);
        const zones = [
            { x: 50, y: 50, width: this.w - 100, height: this.h / 2 - 130 },
            { x: 50, y: this.h / 2 + 80, width: this.w - 100, height: this.h / 2 - 130 }
        ];
        
        for (let i = 0; i < Math.min(count, shuffled.length); i++) {
            const scene = shuffled[i];
            const fw = scene.footprint.w;
            const fh = scene.footprint.h;
            
            const pos = this.findBuildingPosition(fw + 20, fh + 20, zones);
            if (!pos) continue;
            
            scenes.push({
                id: scene.id,
                name: scene.name,
                x: pos.x,
                y: pos.y,
                w: fw,
                h: fh
            });
            
            // Reserve the space
            this.placedObjects.push({
                x: pos.x - fw / 2 - 10, y: pos.y - fh / 2 - 10,
                width: fw + 20, height: fh + 20
            });
        }
        return scenes;
    }
    
    generateProps() {
        const props = [];
        const [minP, maxP] = this.biome.propCount;
        const totalBudget = Math.round(this.randomInt(minP, maxP) * this.scale.prop);
        
        // Classify prop placement zones
        const roadY = this.road.segments[0]?.y || this.h / 2;
        const roadH = this.road.segments[0]?.height || 60;
        const sidewalkTop = roadY - roadH / 2 - 26;
        const sidewalkBot = roadY + roadH / 2 + 26;
        
        // === CLUSTER DEFINITIONS ===
        // Each cluster: { zone, props: [{type, dx, dy}], footprint: {w, h}, biomes: [...] }
        const clusters = {
            // --- SIDEWALK clusters ---
            bus_stop: {
                zone: 'sidewalk', footprint: { w: 50, h: 20 },
                biomes: ['grassy', 'apocalyptic'],
                props: [
                    { type: 'bench', dx: 0, dy: 0 },
                    { type: 'lamp_post', dx: -20, dy: -2 },
                    { type: 'trash_can', dx: 18, dy: 2 }
                ]
            },
            storefront: {
                zone: 'sidewalk', footprint: { w: 40, h: 18 },
                biomes: ['grassy', 'apocalyptic'],
                props: [
                    { type: 'mailbox', dx: 0, dy: 0 },
                    { type: 'newspaper_box', dx: 14, dy: 1 },
                    { type: 'sign_post', dx: -12, dy: -2 }
                ]
            },
            street_corner: {
                zone: 'sidewalk', footprint: { w: 40, h: 20 },
                biomes: ['grassy', 'apocalyptic'],
                props: [
                    { type: 'lamp_post', dx: 0, dy: 0 },
                    { type: 'fire_hydrant', dx: 16, dy: 4 }
                ]
            },
            litter_pile: {
                zone: 'sidewalk', footprint: { w: 30, h: 16 },
                biomes: ['apocalyptic'],
                props: [
                    { type: 'trash_can', dx: 0, dy: 0 },
                    { type: 'shopping_cart', dx: 14, dy: 3 }
                ]
            },
            // --- BUILDING EDGE clusters ---
            loading_dock: {
                zone: 'building_edge', footprint: { w: 60, h: 40 },
                biomes: ['barren', 'apocalyptic'],
                props: [
                    { type: 'crate_stack', dx: 0, dy: 0 },
                    { type: 'dumpster', dx: 30, dy: 5 },
                    { type: 'oil_barrel', dx: -18, dy: 8 }
                ]
            },
            fenced_storage: {
                zone: 'building_edge', footprint: { w: 70, h: 30 },
                biomes: ['grassy', 'barren'],
                props: [
                    { type: 'fence_h', dx: 0, dy: -10 },
                    { type: 'crate_stack', dx: -10, dy: 8 },
                    { type: 'oil_barrel', dx: 15, dy: 6 }
                ]
            },
            dumpster_alley: {
                zone: 'building_rear', footprint: { w: 50, h: 30 },
                biomes: ['apocalyptic'],
                props: [
                    { type: 'dumpster', dx: 0, dy: 0 },
                    { type: 'trash_can', dx: 22, dy: 4 },
                    { type: 'oil_barrel', dx: -20, dy: 6 }
                ]
            },
            // --- FIELD clusters ---
            crash_site: {
                zone: 'road_or_field', footprint: { w: 80, h: 50 },
                biomes: ['barren', 'apocalyptic'],
                props: [
                    { type: 'car_wreck', dx: 0, dy: 0 },
                    { type: 'oil_barrel', dx: 35, dy: 12 },
                    { type: 'dead_tree', dx: -40, dy: -8 }
                ]
            },
            pileup: {
                zone: 'road_or_field', footprint: { w: 100, h: 50 },
                biomes: ['apocalyptic'],
                props: [
                    { type: 'car_wreck', dx: -20, dy: 0 },
                    { type: 'truck_wreck', dx: 35, dy: 5 },
                    { type: 'barrier', dx: -55, dy: -3 }
                ]
            },
            tree_grove: {
                zone: 'field', footprint: { w: 50, h: 50 },
                biomes: ['grassy'],
                props: [
                    { type: 'tree', dx: 0, dy: 0 },
                    { type: 'tree', dx: 20, dy: -15 },
                    { type: 'tree_pine', dx: -15, dy: 12 }
                ]
            },
            dead_grove: {
                zone: 'field', footprint: { w: 50, h: 50 },
                biomes: ['barren', 'apocalyptic'],
                props: [
                    { type: 'dead_tree', dx: 0, dy: 0 },
                    { type: 'dead_tree', dx: 22, dy: -12 }
                ]
            },
            supply_dump: {
                zone: 'field', footprint: { w: 60, h: 40 },
                biomes: ['barren'],
                props: [
                    { type: 'oil_barrel', dx: 0, dy: 0 },
                    { type: 'oil_barrel', dx: 12, dy: 4 },
                    { type: 'crate_stack', dx: -15, dy: 6 }
                ]
            },
            abandoned_camp: {
                zone: 'field', footprint: { w: 50, h: 35 },
                biomes: ['barren', 'grassy'],
                props: [
                    { type: 'bench', dx: 0, dy: 0 },
                    { type: 'oil_barrel', dx: 18, dy: -5 },
                    { type: 'fence_h', dx: -5, dy: 15 }
                ]
            },
            container_yard: {
                zone: 'field', footprint: { w: 100, h: 50 },
                biomes: ['apocalyptic'],
                props: [
                    { type: 'shipping_container', dx: 0, dy: 0 },
                    { type: 'crate_stack', dx: -45, dy: 10 },
                    { type: 'oil_barrel', dx: 48, dy: 8 }
                ]
            },
            // --- ROAD EDGE clusters ---
            checkpoint: {
                zone: 'road_edge', footprint: { w: 60, h: 25 },
                biomes: ['barren', 'apocalyptic'],
                props: [
                    { type: 'barrier', dx: 0, dy: 0 },
                    { type: 'sign_post', dx: -30, dy: -4 },
                    { type: 'oil_barrel', dx: 28, dy: 3 }
                ]
            },
            road_accident: {
                zone: 'road_edge', footprint: { w: 80, h: 30 },
                biomes: ['barren', 'apocalyptic'],
                props: [
                    { type: 'car_wreck', dx: 0, dy: 0 },
                    { type: 'barrier', dx: -40, dy: -4 }
                ]
            },
            // --- ANOMALOUS CLUSTERS ---
            cube_emergence: {
                zone: 'field', footprint: { w: 40, h: 40 },
                biomes: ['apocalyptic'],
                props: [
                    { type: 'crystal_spire', dx: 0, dy: 0 },
                    { type: 'fungal_cluster', dx: 16, dy: 8 },
                    { type: 'cube_node', dx: -12, dy: 10 }
                ]
            },
            corrupted_street: {
                zone: 'sidewalk', footprint: { w: 40, h: 20 },
                biomes: ['apocalyptic'],
                props: [
                    { type: 'corrupted_lamp', dx: 0, dy: 0 },
                    { type: 'fungal_cluster', dx: 16, dy: 4 }
                ]
            },
            organ_grove: {
                zone: 'field', footprint: { w: 50, h: 40 },
                biomes: ['apocalyptic'],
                props: [
                    { type: 'organ_pillar', dx: 0, dy: 0 },
                    { type: 'organ_pillar', dx: 18, dy: -8 },
                    { type: 'fungal_cluster', dx: -10, dy: 12 }
                ]
            },
            worship_site: {
                zone: 'building_edge', footprint: { w: 40, h: 30 },
                biomes: ['apocalyptic'],
                props: [
                    { type: 'cephalon_shrine', dx: 0, dy: 0 },
                    { type: 'crystal_spire', dx: -18, dy: -6 }
                ]
            },
            // --- WASTELAND CLUSTERS ---
            bone_field: {
                zone: 'field', footprint: { w: 40, h: 25 },
                biomes: ['barren'],
                props: [
                    { type: 'bleached_skeleton', dx: 0, dy: 0 },
                    { type: 'bleached_skeleton', dx: 18, dy: 6 }
                ]
            },
            trailmarker: {
                zone: 'road_edge', footprint: { w: 30, h: 20 },
                biomes: ['barren'],
                props: [
                    { type: 'rock_cairn', dx: 0, dy: 0 },
                    { type: 'sign_post', dx: 12, dy: -3 }
                ]
            },
            survivor_camp: {
                zone: 'field', footprint: { w: 50, h: 35 },
                biomes: ['barren'],
                props: [
                    { type: 'abandoned_tent', dx: 0, dy: 0 },
                    { type: 'oil_barrel', dx: 20, dy: -4 },
                    { type: 'barbed_wire', dx: -16, dy: 10 }
                ]
            },
            dried_outpost: {
                zone: 'building_edge', footprint: { w: 40, h: 30 },
                biomes: ['barren'],
                props: [
                    { type: 'dried_wellhead', dx: 0, dy: 0 },
                    { type: 'oil_barrel', dx: 16, dy: 6 }
                ]
            },
            // --- OVERGROWN clusters ---
            backyard_scene: {
                zone: 'field', footprint: { w: 50, h: 35 },
                biomes: ['grassy'],
                props: [
                    { type: 'clothesline_post', dx: 0, dy: 0 },
                    { type: 'bird_bath', dx: 18, dy: 8 },
                    { type: 'child_bicycle', dx: -14, dy: 12 }
                ]
            },
            playground_ruin: {
                zone: 'field', footprint: { w: 45, h: 30 },
                biomes: ['grassy'],
                props: [
                    { type: 'rusted_swing_set', dx: 0, dy: 0 },
                    { type: 'bench', dx: 20, dy: 10 }
                ]
            },
            overgrown_lot: {
                zone: 'building_edge', footprint: { w: 50, h: 25 },
                biomes: ['grassy'],
                props: [
                    { type: 'ivy_wall', dx: 0, dy: 0 },
                    { type: 'collapsed_fence', dx: 22, dy: 4 }
                ]
            },
            suburban_decay: {
                zone: 'sidewalk', footprint: { w: 40, h: 20 },
                biomes: ['grassy'],
                props: [
                    { type: 'mailbox', dx: 0, dy: 0 },
                    { type: 'collapsed_fence', dx: 16, dy: 3 }
                ]
            }
        };
        
        // Build weighted cluster pool for this biome
        const biomeType = this.biomeType || 'grassy';
        const validClusters = Object.entries(clusters)
            .filter(([_, c]) => c.biomes.includes(biomeType))
            .map(([name, c]) => ({ name, ...c }));
        
        // === PLACE CLUSTERS FIRST (60% of budget) ===
        const clusterBudget = Math.ceil(totalBudget * 0.6);
        let propsPlaced = 0;
        let clusterAttempts = 0;
        const maxClusterAttempts = 30;
        
        while (propsPlaced < clusterBudget && clusterAttempts < maxClusterAttempts && validClusters.length > 0) {
            clusterAttempts++;
            const cluster = validClusters[Math.floor(this.random() * validClusters.length)];
            
            // Find position for the cluster's anchor
            const pos = this.findContextualPosition(
                cluster.footprint.w, cluster.footprint.h,
                cluster.zone, roadY, roadH, sidewalkTop, sidewalkBot
            );
            if (!pos) continue;
            
            // Check that all member positions are valid (not overlapping placed objects)
            let allFit = true;
            for (const member of cluster.props) {
                const mx = pos.x + member.dx;
                const my = pos.y + member.dy;
                if (mx < 25 || mx > this.w - 25 || my < 25 || my > this.h - 25) {
                    allFit = false;
                    break;
                }
            }
            if (!allFit) continue;
            
            // Place all cluster members
            for (const member of cluster.props) {
                const mx = pos.x + member.dx;
                const my = pos.y + member.dy;
                const template = CONFIG.propTemplates[member.type];
                if (!template) continue;
                
                props.push({ type: member.type, x: mx, y: my, ...template });
            }
            
            // Register the cluster footprint as placed
            this.placedObjects.push({
                x: pos.x - cluster.footprint.w / 2 - 5,
                y: pos.y - cluster.footprint.h / 2 - 5,
                width: cluster.footprint.w + 10,
                height: cluster.footprint.h + 10
            });
            
            propsPlaced += cluster.props.length;
        }
        
        // === FILL REMAINING BUDGET WITH SOLO PROPS (40%) ===
        const soloBudget = totalBudget - propsPlaced;
        
        // Prop context rules — where each type makes sense
        const propZones = {
            mailbox: 'sidewalk', lamp_post: 'sidewalk', fire_hydrant: 'sidewalk',
            bench: 'sidewalk', trash_can: 'sidewalk', newspaper_box: 'sidewalk',
            sign_post: 'sidewalk', shopping_cart: 'sidewalk',
            fence_h: 'building_edge', dumpster: 'building_rear',
            tree: 'field', tree_pine: 'field', dead_tree: 'field', converted_tree: 'field',
            car_wreck: 'road_or_field', truck_wreck: 'road_or_field',
            oil_barrel: 'field', crate_stack: 'building_edge',
            barrier: 'road_edge', shipping_container: 'field'
        };
        
        for (let i = 0; i < soloBudget; i++) {
            const propType = this.weightedPick(this.biome.props);
            const template = CONFIG.propTemplates[propType];
            if (!template) continue;
            
            const zone = propZones[propType] || 'field';
            const pos = this.findContextualPosition(template.width, template.height, zone, roadY, roadH, sidewalkTop, sidewalkBot);
            if (pos) {
                const sameType = props.filter(p => p.type === propType);
                const minSpacing = propType === 'mailbox' ? 80 : propType === 'lamp_post' ? 60 : propType === 'fire_hydrant' ? 70 : 40;
                const tooClose = sameType.some(p => Math.abs(p.x - pos.x) + Math.abs(p.y - pos.y) < minSpacing);
                if (tooClose) continue;
                
                props.push({ type: propType, x: pos.x, y: pos.y, ...template });
                this.placedObjects.push({
                    x: pos.x - template.width / 2 - 5,
                    y: pos.y - template.height / 2 - 5,
                    width: template.width + 10,
                    height: template.height + 10
                });
            }
        }
        
        return props;
    }
    
    findContextualPosition(width, height, zone, roadY, roadH, swTop, swBot) {
        for (let attempt = 0; attempt < 40; attempt++) {
            let x, y;
            
            switch (zone) {
                case 'sidewalk': {
                    // Along the sidewalk strips (within ~30px of road edge)
                    x = 50 + this.random() * (this.w - 100);
                    const topOrBot = this.random() < 0.5;
                    y = topOrBot ? swTop + this.random() * 16 - 8 : swBot + this.random() * 16 - 8;
                    break;
                }
                case 'building_edge': {
                    // Near a building perimeter
                    if (this.buildings.length > 0) {
                        const b = this.buildings[Math.floor(this.random() * this.buildings.length)];
                        const side = Math.floor(this.random() * 4);
                        const margin = 15;
                        if (side === 0) { x = b.x + this.random() * b.width; y = b.y - margin; }
                        else if (side === 1) { x = b.x + this.random() * b.width; y = b.y + b.height + margin; }
                        else if (side === 2) { x = b.x - margin; y = b.y + this.random() * b.height; }
                        else { x = b.x + b.width + margin; y = b.y + this.random() * b.height; }
                    } else {
                        x = 50 + this.random() * (this.w - 100);
                        y = 50 + this.random() * (this.h - 100);
                    }
                    break;
                }
                case 'building_rear': {
                    // Behind buildings (away from road)
                    if (this.buildings.length > 0) {
                        const b = this.buildings[Math.floor(this.random() * this.buildings.length)];
                        x = b.x + this.random() * b.width;
                        const bCenterY = b.y + b.height / 2;
                        y = bCenterY < roadY ? b.y - 15 - this.random() * 20 : b.y + b.height + 15 + this.random() * 20;
                    } else {
                        x = 50 + this.random() * (this.w - 100);
                        y = 50 + this.random() * (this.h - 100);
                    }
                    break;
                }
                case 'road_or_field': {
                    // Wrecked vehicles can be on/near road or in fields
                    if (this.random() < 0.4) {
                        // On/near road
                        x = 50 + this.random() * (this.w - 100);
                        y = roadY + (this.random() - 0.5) * (roadH + 30);
                    } else {
                        x = 50 + this.random() * (this.w - 100);
                        y = 50 + this.random() * (this.h - 100);
                    }
                    break;
                }
                case 'road_edge': {
                    // Barriers along road edges
                    x = 50 + this.random() * (this.w - 100);
                    const edge = this.random() < 0.5;
                    y = edge ? roadY - roadH / 2 - 8 : roadY + roadH / 2 + 8;
                    break;
                }
                default: // 'field' — anywhere off the road
                    x = 50 + this.random() * (this.w - 100);
                    y = 50 + this.random() * (this.h - 100);
                    // Avoid placing directly on road
                    if (Math.abs(y - roadY) < roadH / 2 + 10) {
                        y = roadY + (y < roadY ? -1 : 1) * (roadH / 2 + 20 + this.random() * 40);
                    }
                    break;
            }
            
            if (this.isPositionValid(x, y, width, height, 5)) {
                return { x, y };
            }
        }
        return null;
    }
    
    findPropPosition(width, height) {
        const roadY = this.road?.segments?.[0]?.y || this.h / 2;
        const roadH = this.road?.segments?.[0]?.height || 60;
        const sidewalkBuffer = 40; // road edge + sidewalk width + margin
        for (let attempt = 0; attempt < 30; attempt++) {
            const x = 50 + this.random() * (this.w - 100);
            let y = 50 + this.random() * (this.h - 100);
            // Avoid placing on road OR sidewalks
            if (Math.abs(y - roadY) < roadH / 2 + sidewalkBuffer) {
                y = roadY + (y < roadY ? -1 : 1) * (roadH / 2 + sidewalkBuffer + 5 + this.random() * 30);
            }
            if (this.isPositionValid(x, y, width, height, 5)) {
                return { x, y };
            }
        }
        return null;
    }
    
    generateRoadsideVehicles() {
        const vehicles = [];
        const roadY = this.h / 2;
        const types = ['sedan', 'compact', 'suv', 'truck'];
        
        // Vehicle count by biome
        let count;
        switch(this.biomeType) {
            case 'grassy': count = this.randomInt(1, 3); break;
            case 'barren': count = this.randomInt(2, 4); break;
            case 'apocalyptic': count = this.randomInt(3, 6); break;
            default: count = 2;
        }
        count = Math.round(count * (this.scale.prop || 1));
        
        for (let i = 0; i < count; i++) {
            const vType = this.randomFromArray(types);
            const vw = vType === 'truck' ? 62 : vType === 'suv' ? 52 : vType === 'sedan' ? 48 : 40;
            const vh = 28;
            
            // Place along road shoulders or pulled off to side
            const aboveOrBelow = this.random() < 0.5 ? -1 : 1;
            const vx = 60 + this.random() * (this.w - 120);
            const vy = roadY + aboveOrBelow * (45 + this.random() * 30); // on shoulders
            
            if (this.isPositionValid(vx, vy, vw, vh, 8)) {
                vehicles.push({ type: vType, x: vx, y: vy });
                this.placedObjects.push({
                    x: vx - vw/2 - 5,
                    y: vy - vh/2 - 5,
                    width: vw + 10,
                    height: vh + 10
                });
            }
        }
        return vehicles;
    }
    
    generateTrees() {
        const trees = [];
        
        // Tree count and type based on biome
        let treeCount, deadChance;
        switch (this.biomeType) {
            case 'grassy':
                treeCount = Math.round(this.randomInt(10, 16) * this.scale.tree);
                deadChance = 0.05;
                break;
            case 'barren':
                treeCount = Math.round(this.randomInt(3, 6) * this.scale.tree);
                deadChance = 0.7;
                break;
            case 'apocalyptic':
                treeCount = Math.round(this.randomInt(4, 8) * this.scale.tree);
                deadChance = 0.5;
                break;
            default:
                treeCount = Math.round(8 * this.scale.tree);
                deadChance = 0.1;
        }
        
        for (let i = 0; i < treeCount; i++) {
            const pos = this.findPropPosition(30, 40);
            if (pos) {
                let treeType;
                const roll = this.random();
                if (this.biomeType === 'apocalyptic') {
                    // Anomalous biome — Cube-converted trees dominate
                    if (roll < 0.15) treeType = 'dead';
                    else if (roll < 0.30) treeType = 'pine';
                    else treeType = 'converted';
                } else {
                    if (roll < deadChance) treeType = 'dead';
                    else if (roll < deadChance + 0.35) treeType = 'pine';
                    else treeType = 'leafy';
                }
                
                trees.push({ x: pos.x, y: pos.y, type: treeType });
                this.placedObjects.push({
                    x: pos.x - 15, y: pos.y - 10,
                    width: 30, height: 40,
                    isTree: true
                });
            }
        }
        
        return trees;
    }
    
    generateSpawnPoints() {
        const points = [];
        const [minE, maxE] = this.biome.enemyCount;
        // Reach-based scaling: base count grows with reach (reach 1 = 1.0x, reach 6 = ~1.8x)
        const reach = (this.scene && this.scene.destinationNode && this.scene.destinationNode.reach) || 1;
        const reachMult = 1 + (reach - 1) * 0.15;
        const count = Math.round(Math.max(minE, Math.floor(maxE * 1.5)) * this.scale.spawn * reachMult);
        
        for (let i = 0; i < count; i++) {
            const pos = this.findPropPosition(30, 30);
            if (pos) {
                points.push({
                    x: pos.x,
                    y: pos.y,
                    enemyType: this.randomFromArray(this.biome.enemyTypes)
                });
            }
        }
        
        return points;
    }
}

