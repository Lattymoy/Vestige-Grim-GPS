// Vestige GPS — BossAI
// 5 boss types with phase-based behavior, telegraphs, attack patterns
// Rendering delegated via _renderer bridge
// Attack methods provide damage callbacks to renderer for projectile/proximity logic
// createBossTexture, all VFX, projectile visuals → client/rendering/bossRenderer.js

import { CONFIG } from '../data/config.js';
import { CombatHelper } from './combatHelper.js';
import { DOTSystem } from './dotSystem.js';
import { EnemyManager } from './enemyManager.js';
import { Blurbs } from './blurbs.js';
import { ConsumableSystem } from './consumableSystem.js';
import { EventBus } from './eventBus.js';
import { Haptics } from './haptics.js';
import { ItemManager } from './itemManager.js';
import { SignatureEffects } from './signatureEffects.js';

const _dist = (x1, y1, x2, y2) => { const dx = x2-x1, dy = y2-y1; return Math.sqrt(dx*dx+dy*dy); };
const _clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const _between = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const _radToDeg = (r) => r * 180 / Math.PI;

export const BossAI = {
    _renderer: null,

    /**
     * Renderer interface for boss VFX. See client/rendering/bossRenderer.js
     */
    init(renderer) { BossAI._renderer = renderer; },

    // Boss stat definitions (pure data)
    _bossStats: {
        warden:      { hp: 300, hpScale: 50, speed: 35, size: 52, color: 0x884422, damage: 20 },
        swarmQueen:  { hp: 250, hpScale: 40, speed: 20, size: 48, color: 0x448844, damage: 12 },
        phantom:     { hp: 200, hpScale: 45, speed: 60, size: 40, color: 0x664488, damage: 18 },
        ironclad:    { hp: 400, hpScale: 60, speed: 30, size: 56, color: 0x666677, damage: 25 },
        cubeAnomaly: { hp: 500, hpScale: 70, speed: 40, size: 50, color: 0x8844aa, damage: 30 }
    },

    _bossDisplayNames: {
        warden: 'THE WARDEN', swarmQueen: 'THE SWARM QUEEN',
        phantom: 'THE PHANTOM', ironclad: 'THE IRONCLAD', cubeAnomaly: 'CUBE ANOMALY'
    },

    spawnBossEntity(scene) {
        if (!scene.modeState || scene.modeState.bossEntity) return;
        const R = BossAI._renderer;

        const reach = scene.modeState.reach || 1;
        const bossType = scene.modeState.bossType || 'warden';
        const base = BossAI._bossStats[bossType] || BossAI._bossStats.warden;
        const stats = { ...base, hp: base.hp + reach * base.hpScale };
        const cx = CONFIG.world.width / 2;
        const cy = CONFIG.world.height / 2 - 60;

        // Create boss sprite via renderer
        let boss;
        if (R) {
            boss = R.createBossSprite(scene, cx, cy, bossType, stats);
        }
        if (!boss) return;

        // Logic state
        boss.enemyType = 'boss';
        boss.bossType = bossType;
        boss.hp = stats.hp;
        boss.maxHp = stats.hp;
        boss.canAttack = true;
        boss.speed = stats.speed;
        boss.damage = stats.damage;
        boss.aiState = 'boss';
        boss.bossPhase = 1;
        boss.attackCooldown = 0;
        boss.specialCooldown = 0;
        boss.moveTarget = { x: cx, y: cy };
        boss.phaseChanged = false;
        boss.isBoss = true;

        // Boss shields
        const sc = CONFIG.shieldConfig;
        boss.shieldHP = (sc.bossShieldHP[1] || 80) + reach * sc.bossShieldReachScale;
        boss.shieldMaxHP = boss.shieldHP;
        boss.hasShield = true;

        // Entrance VFX + idle animation via renderer
        if (R) {
            R.bossEntranceVFX(scene, boss, bossType, cx, cy);
            R.bossIdleAnimation(scene, boss, bossType);
        }

        scene.enemies.add(boss);
        scene.modeState.bossEntity = boss;
        scene.modeState.bossHp = stats.hp;
        scene.modeState.bossMaxHp = stats.hp;
        scene.modeState.phase = 'active';

        // Boss HP bar
        const displayName = BossAI._bossDisplayNames[bossType] || 'BOSS';
        if (scene.bossHP) scene.bossHP.setName(displayName);
        if (R) R.bossNameDisplay(scene, displayName);
        if (R) R.showBossHPBar(scene);

        if (R) R.audioBossSpawn();
        Haptics.heavy();
        EventBus.emit('bossSpawn', { scene, bossType });

        // Overlap for contact damage
        if (R) R.setupBossOverlap(scene, boss, () => {
            if (boss && boss.active) BossAI.bossTouchDamage(scene, boss);
        });
    },

    updateBossEncounter(scene, dt) {
        if (!scene.modeState || !scene.modeState.bossEntity || !scene.modeState.bossEntity.active) return;
        if (scene.modeState.phase !== 'active') return;
        const R = BossAI._renderer;

        const boss = scene.modeState.bossEntity;
        const bossType = boss.bossType;
        const hpRatio = boss.hp / boss.maxHp;

        // Phase transitions
        if (hpRatio <= 0.6 && boss.bossPhase === 1) {
            boss.bossPhase = 2;
            const sc2 = CONFIG.shieldConfig;
            boss.shieldHP = (sc2.bossShieldHP[2] || 120) + (scene.state?.reach || 1) * sc2.bossShieldReachScale;
            boss.shieldMaxHP = boss.shieldHP;
            boss.hasShield = true;
            const p2Text = { warden: 'Chains break loose.', swarmQueen: 'The hive awakens.', phantom: 'It splits apart.', ironclad: 'Overdrive engaged.', cubeAnomaly: 'Dimensions fold.' };
            scene.showModeAnnouncement('PHASE 2', p2Text[bossType] || 'It\'s getting angry...', true);
            boss.speed *= 1.3;
            if (R) R.phaseTransitionVFX(scene, boss, 2, bossType);
        }
        if (hpRatio <= 0.25 && boss.bossPhase === 2) {
            boss.bossPhase = 3;
            const sc3 = CONFIG.shieldConfig;
            boss.shieldHP = (sc3.bossShieldHP[3] || 160) + (scene.state?.reach || 1) * sc3.bossShieldReachScale;
            boss.shieldMaxHP = boss.shieldHP;
            boss.hasShield = true;
            const p3Text = { warden: 'No more restraint.', swarmQueen: 'She screams.', phantom: 'The veil tears.', ironclad: 'Core meltdown.', cubeAnomaly: 'THE ANOMALY UNFOLDS.' };
            scene.showModeAnnouncement('FINAL PHASE', p3Text[bossType] || 'Now or never!', true);
            boss.speed *= 1.3;
            boss.damage = Math.floor(boss.damage * 1.5);
            if (R) R.enrageAura(scene, boss, bossType);
        }
        if (R && boss._enrageAura) R.trackEnrageAura(boss);

        // Cooldowns
        boss.attackCooldown = Math.max(0, boss.attackCooldown - dt);
        boss.specialCooldown = Math.max(0, boss.specialCooldown - dt);
        scene.modeState.addsTimer += dt;

        // Spawn adds
        const addsInterval = boss.bossPhase === 3 ? 6 : boss.bossPhase === 2 ? 10 : 15;
        if (scene.modeState.addsTimer > addsInterval) {
            scene.modeState.addsTimer = 0;
            scene.spawnWave(boss.bossPhase === 3 ? 3 : boss.bossPhase === 2 ? 2 : 1);
        }

        // Boss-specific AI
        switch (bossType) {
            case 'warden': BossAI.updateWardenBoss(scene, boss, dt); break;
            case 'swarmQueen': BossAI.updateSwarmQueenBoss(scene, boss, dt); break;
            case 'phantom': BossAI.updatePhantomBoss(scene, boss, dt); break;
            case 'ironclad': BossAI.updateIroncladBoss(scene, boss, dt); break;
            case 'cubeAnomaly': BossAI.updateCubeAnomalyBoss(scene, boss, dt); break;
            default: BossAI.updateWardenBoss(scene, boss, dt); break;
        }

        scene.modeState.bossHp = boss.hp;
    },

    // === WARDEN — charge attack boss ===
    updateWardenBoss(scene, boss, dt) {
        const R = BossAI._renderer;
        if (!boss.wardenState) boss.wardenState = 'stalk';
        const px = scene.player.x, py = scene.player.y;
        const dist = _dist(boss.x, boss.y, px, py);

        if (boss.wardenState === 'stalk') {
            const angle = Math.atan2(py - boss.y, px - boss.x);
            if (boss.setVelocity) boss.setVelocity(Math.cos(angle) * boss.speed, Math.sin(angle) * boss.speed);
            if (dist < 200 && boss.attackCooldown <= 0) {
                boss.wardenState = 'windup';
                if (boss.setVelocity) boss.setVelocity(0, 0);
                boss.chargeAngle = Math.atan2(py - boss.y, px - boss.x);
                boss.windupTimer = 0.8;
                if (R) R.wardenWindup(scene, boss);
            }
        } else if (boss.wardenState === 'windup') {
            boss.windupTimer -= dt;
            if (boss.windupTimer <= 0) {
                boss.wardenState = 'charging';
                if (R) R.wardenChargeStart(scene, boss);
                const chargeSpeed = 350 + (boss.bossPhase - 1) * 100;
                if (boss.setVelocity) boss.setVelocity(Math.cos(boss.chargeAngle) * chargeSpeed, Math.sin(boss.chargeAngle) * chargeSpeed);
                boss.chargeTimer = 0.6;
            }
        } else if (boss.wardenState === 'charging') {
            boss.chargeTimer -= dt;
            if (boss.chargeTimer <= 0) {
                boss.wardenState = 'stunned';
                if (boss.setVelocity) boss.setVelocity(0, 0);
                boss.stunnedTimer = boss.bossPhase === 3 ? 0.8 : 1.5;
                if (R) R.wardenStunned(scene, boss);
            }
        } else if (boss.wardenState === 'stunned') {
            boss.stunnedTimer -= dt;
            if (boss.stunnedTimer <= 0) {
                if (R) R.wardenRecover(scene, boss);
                boss.wardenState = 'stalk';
                boss.attackCooldown = boss.bossPhase === 3 ? 1.5 : boss.bossPhase === 2 ? 2.5 : 3.5;
            }
        }

        if (boss.bossPhase >= 2 && boss.wardenState === 'stalk' && boss.specialCooldown <= 0) {
            BossAI.bossThrowDebris(scene, boss);
            boss.specialCooldown = boss.bossPhase === 3 ? 2 : 4;
        }
    },

    // === SWARM QUEEN — spawner boss ===
    updateSwarmQueenBoss(scene, boss, dt) {
        const cx = CONFIG.world.width / 2, cy = CONFIG.world.height / 2;
        const drift = { x: cx + Math.sin(Date.now() * 0.001) * 80, y: cy + Math.cos(Date.now() * 0.0008) * 60 };
        const angle = Math.atan2(drift.y - boss.y, drift.x - boss.x);
        if (boss.setVelocity) boss.setVelocity(Math.cos(angle) * 15, Math.sin(angle) * 15);

        if (boss.attackCooldown <= 0) {
            const count = boss.bossPhase === 3 ? 4 : boss.bossPhase === 2 ? 3 : 2;
            for (let i = 0; i < count; i++) {
                const spawnAngle = (Math.PI * 2 / count) * i;
                scene.spawnEnemy(boss.x + Math.cos(spawnAngle) * 40, boss.y + Math.sin(spawnAngle) * 40, 'flicker');
            }
            boss.attackCooldown = boss.bossPhase === 3 ? 3 : boss.bossPhase === 2 ? 5 : 7;
        }

        if (boss.bossPhase >= 2 && boss.specialCooldown <= 0) {
            BossAI.bossProjectileVolley(scene, boss);
            boss.specialCooldown = boss.bossPhase === 3 ? 2.5 : 4;
        }

        if (boss.bossPhase === 3) {
            const pa = Math.atan2(scene.player.y - boss.y, scene.player.x - boss.x);
            if (boss.setVelocity) boss.setVelocity(Math.cos(pa) * 40, Math.sin(pa) * 40);
        }
    },

    // === PHANTOM — teleport boss ===
    updatePhantomBoss(scene, boss, dt) {
        const R = BossAI._renderer;
        if (!boss.phantomState) boss.phantomState = 'visible';

        if (boss.phantomState === 'visible') {
            const angle = Math.atan2(scene.player.y - boss.y, scene.player.x - boss.x);
            if (boss.setVelocity) boss.setVelocity(Math.cos(angle) * boss.speed, Math.sin(angle) * boss.speed);
            if (boss.attackCooldown <= 0) {
                boss.phantomState = 'vanishing';
                if (boss.setVelocity) boss.setVelocity(0, 0);
                if (R) {
                    R.phantomVanish(scene, boss, () => {
                        // Logic callback after vanish completes
                        if (boss.bossPhase >= 2) BossAI.bossHazardZone(scene, boss.x, boss.y, 40, 3);
                        const tAngle = Math.random() * Math.PI * 2;
                        const tDist = 80 + Math.random() * 60;
                        boss.x = _clamp(scene.player.x + Math.cos(tAngle) * tDist, 50, CONFIG.world.width - 50);
                        boss.y = _clamp(scene.player.y + Math.sin(tAngle) * tDist, 50, CONFIG.world.height - 50);
                        boss.phantomState = 'appearing';
                        R.phantomAppear(scene, boss, () => {
                            boss.phantomState = 'visible';
                            boss.attackCooldown = boss.bossPhase === 3 ? 1.5 : boss.bossPhase === 2 ? 2.5 : 3.5;
                        });
                    });
                }
            }
        }

        if (boss.bossPhase >= 3 && boss.specialCooldown <= 0) {
            BossAI.bossSpawnDecoy(scene, boss);
            boss.specialCooldown = 5;
        }
    },

    // === IRONCLAD — armored tank ===
    updateIroncladBoss(scene, boss, dt) {
        const R = BossAI._renderer;
        if (!boss.ironcladState) boss.ironcladState = 'patrol';

        if (boss.ironcladState === 'patrol') {
            if (!boss.patrolAngle) boss.patrolAngle = 0;
            boss.patrolAngle += dt * 0.8;
            const cx = CONFIG.world.width / 2, cy = CONFIG.world.height / 2;
            const tx = cx + Math.cos(boss.patrolAngle) * 150;
            const ty = cy + Math.sin(boss.patrolAngle) * 150;
            const angle = Math.atan2(ty - boss.y, tx - boss.x);
            if (boss.setVelocity) boss.setVelocity(Math.cos(angle) * boss.speed * 1.5, Math.sin(angle) * boss.speed * 1.5);

            if (boss.attackCooldown <= 0) {
                BossAI.bossTurretShot(scene, boss);
                boss.attackCooldown = boss.bossPhase === 3 ? 0.8 : boss.bossPhase === 2 ? 1.5 : 2.5;
            }

            if (boss.bossPhase >= 2 && boss.specialCooldown <= 0) {
                BossAI.bossDropMine(scene, boss);
                boss.specialCooldown = boss.bossPhase === 3 ? 2 : 3.5;
            }

            if (boss.bossPhase >= 3 && Math.random() < 0.005) {
                boss.ironcladState = 'ram';
                const pa = Math.atan2(scene.player.y - boss.y, scene.player.x - boss.x);
                if (boss.setVelocity) boss.setVelocity(Math.cos(pa) * 300, Math.sin(pa) * 300);
                if (R) R.ironcladRamStart(scene, boss);
                boss.ramTimer = 0.8;
            }
        } else if (boss.ironcladState === 'ram') {
            boss.ramTimer -= dt;
            if (boss.ramTimer <= 0) {
                boss.ironcladState = 'patrol';
                if (R) R.ironcladRamEnd(scene, boss);
            }
        }
    },

    // === CUBE ANOMALY — reality-warping final boss ===
    updateCubeAnomalyBoss(scene, boss, dt) {
        const R = BossAI._renderer;
        if (!boss.cubeRotation) boss.cubeRotation = 0;
        boss.cubeRotation += dt;

        if (!boss._corruptionLevel) boss._corruptionLevel = 0;
        if (!boss._corruptionWalls) boss._corruptionWalls = [];
        if (!boss._gravityWells) boss._gravityWells = [];

        const w = CONFIG.world.width, h = CONFIG.world.height;
        const cx = w / 2, cy = h / 2;

        const patterns = boss.bossPhase === 3 ? ['corrupt', 'gravity', 'tear', 'invert', 'volley'] :
                        boss.bossPhase === 2 ? ['corrupt', 'gravity', 'tear', 'volley'] :
                        ['corrupt', 'gravity', 'volley'];

        if (!boss.currentPattern) boss.currentPattern = patterns[0];
        if (!boss.patternTimer) boss.patternTimer = 0;
        boss.patternTimer += dt;
        if (boss.patternTimer > 4.5) {
            boss.patternTimer = 0;
            boss.currentPattern = patterns[(patterns.indexOf(boss.currentPattern) + 1) % patterns.length];
        }

        // Movement — orbits center
        const orbitSpeed = 0.5 + boss._corruptionLevel * 0.1;
        const orbitRadius = 100 - boss._corruptionLevel * 8;
        const orbX = cx + Math.cos(boss.cubeRotation * orbitSpeed) * Math.max(40, orbitRadius);
        const orbY = cy - 60 + Math.sin(boss.cubeRotation * orbitSpeed * 0.7) * Math.max(30, orbitRadius * 0.6);
        const moveAngle = Math.atan2(orbY - boss.y, orbX - boss.x);
        if (boss.setVelocity) boss.setVelocity(Math.cos(moveAngle) * boss.speed * 1.2, Math.sin(moveAngle) * boss.speed * 1.2);

        if (boss.bossPhase >= 3 && Math.sin(boss.cubeRotation * 2) > 0.8) {
            const pa = Math.atan2(scene.player.y - boss.y, scene.player.x - boss.x);
            if (boss.setVelocity) boss.setVelocity(Math.cos(pa) * boss.speed * 2, Math.sin(pa) * boss.speed * 2);
        }

        // Gravity well pull (logic — runs regardless of renderer)
        for (const gw of boss._gravityWells) {
            if (!gw.active) continue;
            const dist = _dist(gw.x, gw.y, scene.player.x, scene.player.y);
            if (dist < gw.radius && dist > 10) {
                const pullStr = (1 - dist / gw.radius) * 60 * dt;
                const ga = Math.atan2(gw.y - scene.player.y, gw.x - scene.player.x);
                scene.player.x += Math.cos(ga) * pullStr;
                scene.player.y += Math.sin(ga) * pullStr;
                if (dist < 20 && !gw._dmgCooldown) {
                    gw._dmgCooldown = true;
                    BossAI.bossHitPlayer(scene, 8, 0.004);
                    if (R) R.delayedCall(scene, 800, () => { if (gw) gw._dmgCooldown = false; });
                    else setTimeout(() => { if (gw) gw._dmgCooldown = false; }, 800);
                }
            }
        }

        if (boss.attackCooldown <= 0) {
            switch (boss.currentPattern) {
                case 'corrupt': {
                    boss._corruptionLevel = Math.min(boss.bossPhase === 3 ? 8 : boss.bossPhase === 2 ? 6 : 4, boss._corruptionLevel + 1);
                    const margin = boss._corruptionLevel * 18;
                    if (R) R.corruptionWalls(scene, boss, w, h, margin);
                    // Damage player in corruption zone
                    if (scene.player.x < margin + 10 || scene.player.x > w - margin - 10 ||
                        scene.player.y < margin + 10 || scene.player.y > h - margin - 10) {
                        BossAI.bossHitPlayer(scene, 12, 0.006);
                    }
                    boss.attackCooldown = 5;
                    break;
                }
                case 'gravity': {
                    // Cleanup old wells
                    for (const gw of boss._gravityWells) { if (gw && gw.destroy) gw.destroy(); }
                    boss._gravityWells = [];
                    const wellCount = boss.bossPhase >= 3 ? 3 : boss.bossPhase >= 2 ? 2 : 1;
                    for (let i = 0; i < wellCount; i++) {
                        const wx = _between(80, w - 80), wy = _between(80, h - 80);
                        const radius = 70 + boss.bossPhase * 10;
                        let well;
                        if (R) {
                            well = R.createGravityWell(scene, wx, wy, radius, 6000, (w2) => {
                                const idx = boss._gravityWells.indexOf(w2);
                                if (idx >= 0) boss._gravityWells.splice(idx, 1);
                            });
                        } else {
                            well = { x: wx, y: wy, radius, active: true, destroy() { this.active = false; } };
                            setTimeout(() => { const idx = boss._gravityWells.indexOf(well); if (idx >= 0) boss._gravityWells.splice(idx, 1); well.active = false; }, 6000);
                        }
                        if (well) boss._gravityWells.push(well);
                    }
                    boss.attackCooldown = 4;
                    break;
                }
                case 'tear': {
                    if (R) R.dimensionTear(scene, boss, (dmg, shake) => BossAI.bossHitPlayer(scene, dmg, shake));
                    boss.attackCooldown = 3.5;
                    break;
                }
                case 'invert': {
                    if (R) R.invertEffect(scene);
                    boss.attackCooldown = 6;
                    break;
                }
                case 'volley': {
                    BossAI.bossProjectileVolley(scene, boss);
                    boss.attackCooldown = boss.bossPhase === 3 ? 1.5 : 3;
                    break;
                }
            }
        }
    },

    // === ATTACK METHODS — logic + renderer callbacks ===

    bossThrowDebris(scene, boss) {
        const R = BossAI._renderer;
        if (R) {
            R.throwDebris(scene, boss, {
                hitPlayer: (dmg, shake) => BossAI.bossHitPlayer(scene, dmg, shake),
                getPlayerPos: () => ({ x: scene.player.x, y: scene.player.y })
            });
        }
    },

    bossProjectileVolley(scene, boss) {
        const R = BossAI._renderer;
        if (R) {
            R.projectileVolley(scene, boss, {
                hitPlayer: (dmg, shake) => BossAI.bossHitPlayer(scene, dmg, shake),
                getPlayerPos: () => ({ x: scene.player.x, y: scene.player.y })
            });
        }
    },

    bossHazardZone(scene, x, y, radius, duration) {
        const R = BossAI._renderer;
        if (R) {
            R.hazardZone(scene, x, y, radius, duration, {
                checkDamage: () => {
                    const d = _dist(x, y, scene.player.x, scene.player.y);
                    if (d < radius && !scene.isInvincible && !scene.state.dead) BossAI.bossHitPlayer(scene, 8, 0.003);
                }
            });
        }
    },

    bossDropMine(scene, boss) {
        const R = BossAI._renderer;
        if (R) {
            R.dropMine(scene, boss, {
                checkProximity: (mineX, mineY) => {
                    const d = _dist(mineX, mineY, scene.player.x, scene.player.y);
                    if (d < 25) { BossAI.bossHitPlayer(scene, 15, 0.01); return true; }
                    return false;
                }
            });
        }
    },

    bossTurretShot(scene, boss) {
        const R = BossAI._renderer;
        if (R) {
            R.turretShot(scene, boss, {
                hitPlayer: (dmg, shake) => BossAI.bossHitPlayer(scene, dmg, shake),
                getPlayerPos: () => ({ x: scene.player.x, y: scene.player.y })
            });
        }
    },

    bossSpawnDecoy(scene, boss) {
        const R = BossAI._renderer;
        if (R) {
            const decoy = R.createDecoy(scene, boss);
            if (decoy) {
                decoy.enemyType = boss.bossType + '_decoy';
                decoy.hp = 30;
                decoy.maxHp = 30;
                decoy.canAttack = true;
                decoy.aiState = 'chase';
                decoy.speed = boss.speed * 0.8;
                scene.enemies.add(decoy);
            }
        }
    },

    bossTouchDamage(scene, boss) {
        if (!boss || !boss.active || !boss.damage) return;
        if (scene.isInvincible || scene.state.dead) return;
        if (boss.touchCooldown) return;
        boss.touchCooldown = true;
        const R = BossAI._renderer;
        if (R) R.delayedCall(scene, 1000, () => { if (boss && boss.active) boss.touchCooldown = false; });
        else setTimeout(() => { if (boss && boss.active) boss.touchCooldown = false; }, 1000);
        BossAI.bossHitPlayer(scene, boss.damage);
    },

    // === BOSS DAMAGE TO PLAYER — defensive pipeline (mirrors CombatHelper) ===
    bossHitPlayer(scene, rawDmg, shake = 0.01) {
        if (scene.isInvincible || scene.state.dead) return;
        const R = BossAI._renderer;

        // Dodge check
        const equipStats = ItemManager.getEquipmentStats(scene.state.equipment);
        const bossDodge = (scene._defDodge || 0) + (equipStats.dodgeChance || 0);
        if (bossDodge > 0 && Math.random() * 100 < bossDodge) {
            if (R) R.dodgeVFX(scene, scene.player, 200);
            Blurbs.show(scene, scene.player, 'DODGE', { color: '#66ccff', fontSize: 11, duration: 400 });
            return;
        }
        // Phantom/Phased dodge
        const _bpConds = scene.state.survivorMods?.conditionals;
        const _bpDodge = (_bpConds?.phantomDodgeChance || 0) + (scene.player.body && scene.player.body.velocity.length() > 10 ? (_bpConds?.phasedDodgeChance || 0) : 0);
        if (_bpDodge > 0 && Math.random() < _bpDodge) {
            if (R) R.dodgeVFX(scene, scene.player, 200);
            Blurbs.show(scene, scene.player, 'PHANTOM', { color: '#aa88ff', fontSize: 11, duration: 400 });
            return;
        }

        // Damage reduction pipeline (pure logic)
        let dmg = rawDmg;
        if (equipStats.armor > 0) dmg = Math.max(1, Math.round(dmg * (1 - equipStats.armor / 100)));
        if (equipStats.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - equipStats.damageResist / 100)));
        const _dsMods = scene.state.survivorMods;
        if (_dsMods && _dsMods.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - _dsMods.damageResist)));
        const _dsConds = _dsMods?.conditionals;
        if (_dsConds && _dsConds.thresholdHigh) {
            const _dsMaxHP = CONFIG.player.health + (equipStats.maxHealth || 0);
            const _dsRatio = scene.state.health / _dsMaxHP;
            const _dsThreshR = _dsRatio < _dsConds.thresholdHigh ? _dsConds.thresholdResistBelow : _dsConds.thresholdResistAbove;
            if (_dsThreshR) dmg = Math.max(1, Math.round(dmg * (1 - _dsThreshR)));
        }
        if (_dsConds && _dsConds.firstHitMultiplier && !scene._firstHitTaken) {
            scene._firstHitTaken = true;
            dmg = Math.max(1, Math.round(dmg * _dsConds.firstHitMultiplier));
            Blurbs.show(scene, scene.player, 'FRACTURE', { color: '#ff6644', fontSize: 10, duration: 500 });
        }
        if (scene._tempArmor && scene._tempArmor > 0) {
            const absorbed = Math.min(dmg, scene._tempArmor);
            scene._tempArmor -= absorbed;
            dmg -= absorbed;
        }
        if (scene._bloodPactResist && scene._bloodPactResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - scene._bloodPactResist / 100)));
        if (scene._hardenedActive && scene._hardenedReduction) dmg = Math.max(1, Math.round(dmg * (1 - scene._hardenedReduction)));
        if (scene._shelteredActive) dmg = Math.max(1, Math.round(dmg * 0.8));

        scene.state.health -= dmg;
        SignatureEffects.buildBloodPactStack(scene);
        ConsumableSystem.interruptChannel();

        // Hit feedback via renderer
        if (R) R.bossHitPlayerVFX(scene, shake);

        if (scene.state.health <= 0) scene.die();
    },
};
