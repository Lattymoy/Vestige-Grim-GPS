// Vestige GPS — Haptics
// Extracted from game_2_.html lines 27956-27979

export const Haptics = {
    _enabled: true,
    _supported: typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function',
    
    enable(val) { this._enabled = val !== undefined ? val : true; },
    
    // Core vibrate (ms or pattern array)
    _vib(ms) {
        if (!this._enabled || !this._supported) return;
        try { navigator.vibrate(ms); } catch(e) {}
    },
    
    // Named patterns
    light()       { this._vib(8); },       // UI tap, pickup
    medium()      { this._vib(20); },      // Melee hit, shoot
    heavy()       { this._vib(50); },      // Player hit, explosion
    death()       { this._vib([40, 30, 60, 30, 100]); },  // Player death
    success()     { this._vib([15, 40, 15]); },            // Level up, boss kill
    error()       { this._vib([30, 20, 30]); },            // Empty clip, failed action
};

// ============================================
// TUTORIAL MANAGER — Guided tooltip system with highlight mask
// ============================================
