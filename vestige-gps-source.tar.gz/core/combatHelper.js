// Vestige GPS — CombatHelper
// Damage formulas, armor calc, defensive pipeline
// Rendering (tint flash, camera shake, VFX, iFrame alpha) delegated via _renderer

import { Blurbs } from './blurbs.js';
import { CONFIG } from '../data/config.js';
import { ConsumableSystem } from './consumableSystem.js';
import { DOTSystem } from './dotSystem.js';
import { EventBus } from './eventBus.js';
import { Haptics } from './haptics.js';
import { ItemManager } from './itemManager.js';
import { SignatureEffects } from './signatureEffects.js';
import { AttackVFX } from '../client/rendering/attackVFX.js';

export const CombatHelper = {
    _renderer: null,

    /**
     * Set renderer for hit feedback visuals.
     * Renderer should implement:
     *   playerHitFeedback(scene, opts) — tint flash, camera shake, VFX, knockback
     *   playerIFrames(scene, durationMs, visible) — alpha flicker + invincibility timer
     *   lastStandEffect(scene) — camera flash + floating text
     *   simResetEffect(scene) — alpha flash
     *   audioPlayerHit() — hit sound
     */
    init(renderer) {
        CombatHelper._renderer = renderer;
    },

    /**
     * Apply damage to the player with full defensive pipeline.
     * Call AFTER confirming the hit lands (range/angle check + isInvincible/dead check
     * are the caller's responsibility for direct attacks, or handled by enemyHitPlayer for contact).
     *
     * @param {object} scene
     * @param {number} rawDmg — pre-mitigation damage
     * @param {object} opts
     *   source:    enemy sprite — enables melee reflect (optional)
     *   color:     blurb color (default '#ff4444')
     *   fontSize:  blurb size (default 10)
     *   label:     suffix like ' BLAST' or ' INFERNO' (default '')
     *   knockback: { angle, force } — push player (optional)
     *   vfx:       'hitFlash' → enemyHitFlash using source
     *              { weight, angle } → AttackVFX.play at player pos
     *              null → no VFX (default)
     *   shake:     { duration, intensity } (default { duration: 100, intensity: 0.015 })
     *   dot:       'burn' | 'bleed' | 'toxic' — apply DOT (optional)
     *   iFrames:   invincibility ms (default 500)
     * @returns {{ dealt: number, blocked: boolean }}
     */
    damagePlayer(scene, rawDmg, opts = {}) {
        // Guard — caller should check these for direct attacks, but double-safe
        if (scene.isInvincible || scene.state.dead) return { dealt: 0, blocked: true };
        if (scene._godMode) { scene.state.health = 999; return { dealt: 0, blocked: true }; }
        
        let dmg = rawDmg;
        const eqs = ItemManager.getEquipmentStats(scene.state.equipment);
        
        // ── DEFENSIVE PIPELINE ──
        
        // 1. Temp armor (e.g. Pylon shield)
        if (scene._tempArmor && scene._tempArmor > 0) {
            const absorbed = Math.min(scene._tempArmor, dmg);
            scene._tempArmor -= absorbed;
            dmg -= absorbed;
        }
        
        // 2. Equipment armor + damage resist
        if (eqs.armor > 0) dmg = Math.max(1, Math.round(dmg * (1 - eqs.armor / 100)));
        if (eqs.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - eqs.damageResist / 100)));
        
        // 3. Survivor mark damage resistance
        const mods = scene.state.survivorMods;
        if (mods && mods.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - mods.damageResist)));
        
        // 4. Threshold mark: dynamic resist based on HP ratio
        const conds = mods?.conditionals;
        if (conds && conds.thresholdHigh) {
            const maxHP = CONFIG.player.health + (eqs.maxHealth || 0);
            const ratio = scene.state.health / (scene.state.maxHealth || maxHP);
            const threshR = ratio < conds.thresholdHigh ? conds.thresholdResistBelow : conds.thresholdResistAbove;
            if (threshR) dmg = Math.max(1, Math.round(dmg * (1 - threshR)));
        }
        
        // 5. Fracture Point / Resonant Break: first hit each building deals extra dmg
        if (conds && conds.firstHitMultiplier && !scene._firstHitTaken) {
            scene._firstHitTaken = true;
            dmg = Math.max(1, Math.round(dmg * conds.firstHitMultiplier));
            Blurbs.show(scene, scene.player, 'FRACTURE', { color: '#ff6644', fontSize: 10, duration: 500 });
        }
        
        // 6. Blood Pact: reduce incoming damage by 3% per stack
        if (scene._bloodPactResist && scene._bloodPactResist > 0) {
            dmg = Math.max(1, Math.round(dmg * (1 - scene._bloodPactResist / 100)));
        }
        
        // 7. Hardened (Bane): -50% damage after dodge
        if (scene._hardenedActive && scene._hardenedReduction) {
            dmg = Math.max(1, Math.round(dmg * (1 - scene._hardenedReduction)));
        }
        
        // 8. Sheltered: -20% damage after exiting interior
        if (scene._shelteredActive) {
            dmg = Math.max(1, Math.round(dmg * 0.8));
        }
        
        // ── APPLY DAMAGE ──
        scene.state.health -= dmg;
        if (scene._lastCombatTime !== undefined && scene.time) scene._lastCombatTime = scene.time.now;
        if (scene.hud && scene.hud.updateHP) scene.hud.updateHP(scene.state.health, scene.state.maxHealth);
        
        // Blurb (already decoupled via Blurbs dispatcher)
        const color = opts.color || '#ff4444';
        const fontSize = opts.fontSize || 10;
        const label = opts.label || '';
        Blurbs.show(scene, scene.player, `-${dmg}${label}`, { color, fontSize, duration: 500 });
        
        // Audio + Haptics
        if (CombatHelper._renderer) CombatHelper._renderer.audioPlayerHit();
        Haptics.heavy();
        
        // Interrupt channeling (bandaging, pylon placement)
        ConsumableSystem.interruptChannel();
        
        // Event + stats
        EventBus.emit('playerHit', { scene, dmg, health: scene.state.health });
        if (scene._runStats) scene._runStats.damageTaken += dmg;
        
        // Melee Reflect: return portion of damage to attacker
        if (opts.source && opts.source.active) {
            const reflectPct = scene.state.survivorMods?.conditionals?.meleeReflect || 0;
            if (reflectPct > 0) {
                const reflDmg = Math.max(1, Math.round(dmg * reflectPct));
                opts.source.hp -= reflDmg;
                Blurbs.show(scene, opts.source, `-${reflDmg}`, { color: '#aa44cc', fontSize: 9, duration: 400 });
                if (opts.source.hp <= 0 && opts.source.active) {
                    if (typeof scene.killEnemy === 'function') {
                        scene.killEnemy(opts.source);
                    } else {
                        opts.source.hp = 0; opts.source.destroy();
                    }
                }
            }
        }
        
        // Blood Pact: getting hit builds stacks
        SignatureEffects.buildBloodPactStack(scene);
        
        // ── HIT FEEDBACK (rendering) ──
        if (CombatHelper._renderer) {
            CombatHelper._renderer.playerHitFeedback(scene, {
                shake: opts.shake || { duration: 100, intensity: 0.015 },
                vfx: opts.vfx,
                source: opts.source,
                knockback: opts.knockback
            });
        }
        
        // DOT
        if (opts.dot) {
            const dotType = typeof opts.dot === 'string' ? opts.dot : opts.dot.type;
            if (dotType) DOTSystem.applyToPlayer(scene, dotType, typeof opts.dot === 'object' ? opts.dot : {});
        }
        
        // ── INVINCIBILITY ──
        const iFrames = opts.iFrames !== undefined ? opts.iFrames : 500;
        scene.isInvincible = true;
        if (CombatHelper._renderer) {
            CombatHelper._renderer.playerIFrames(scene, iFrames, iFrames > 300);
        } else {
            // Headless fallback — just set timer
            setTimeout(() => { scene.isInvincible = false; }, iFrames);
        }
        
        // ── DEATH CHECK ──
        if (scene.state.health <= 0) {
            if (typeof scene.die === 'function') {
                const lastStand = eqs.signatures ? eqs.signatures.find(s => s.effect === 'lastStand') : null;
                if (lastStand && !scene._lastStandUsed) {
                    scene._lastStandUsed = true;
                    scene.state.health = 1;
                    scene.isInvincible = true;
                    if (CombatHelper._renderer) CombatHelper._renderer.lastStandEffect(scene);
                } else {
                    scene.die();
                }
            } else {
                // CS: sim reset
                scene.state.health = scene.state.maxHealth;
                if (scene.hud && scene.hud.updateHP) scene.hud.updateHP(scene.state.health, scene.state.maxHealth);
                Blurbs.show(scene, scene.player, 'SIM RESET', { color: '#22ffcc', fontSize: 12, duration: 800 });
                if (CombatHelper._renderer) CombatHelper._renderer.simResetEffect(scene);
            }
        }
        
        return { dealt: dmg, blocked: false };
    }
};

// ============================================
// CONSUMABLE SYSTEM — Handles all consumable effects
// Channeling, grenades, AOE zones, pylons
// ============================================
