// Vestige GPS — StatTracker
// Kill counts, damage, missions, milestones
// NOTE: Circular dep with SaveManager (StatTracker.save → SaveManager.save)

import { CONFIG } from '../data/config.js';
import { PlayerProgression } from './playerProgression.js';
import { SaveManager } from './saveManager.js';

export const StatTracker = {
    // Increment a numeric stat
    inc(statKey, amount = 1) {
        const data = SaveManager.load();
        if (!data.stats) data.stats = {};
        data.stats[statKey] = (data.stats[statKey] || 0) + amount;
        SaveManager.save(data);
        // Check quests and achievements
        this.checkQuests(data);
        this.checkAchievements(data);
    },
    
    // Add a lore chip (returns true if new)
    addLoreChip(chipId) {
        const data = SaveManager.load();
        if (!data.loreChips) data.loreChips = [];
        if (data.loreChips.includes(chipId)) return false;
        data.loreChips.push(chipId);
        SaveManager.save(data);
        this.checkAchievements(data);
        return true;
    },
    
    addFoundNote(noteId) {
        const data = SaveManager.load();
        if (!data.foundNotes) data.foundNotes = [];
        if (data.foundNotes.includes(noteId)) return false;
        data.foundNotes.push(noteId);
        SaveManager.save(data);
        return true;
    },
    
    getFoundNotes() {
        const data = SaveManager.load();
        return data.foundNotes || [];
    },
    
    // Get a random undiscovered lore chip (for drops)
    getRandomUndiscoveredChip() {
        const data = SaveManager.load();
        const found = data.loreChips || [];
        const all = Object.keys(CONFIG.loreChips);
        const undiscovered = all.filter(id => !found.includes(id));
        if (undiscovered.length === 0) return null;
        
        // Weight by rarity: common 50%, uncommon 30%, rare 15%, legendary 5%
        const weighted = [];
        undiscovered.forEach(id => {
            const chip = CONFIG.loreChips[id];
            const w = chip.rarity === 'common' ? 10 : chip.rarity === 'uncommon' ? 6 : chip.rarity === 'rare' ? 3 : 1;
            for (let i = 0; i < w; i++) weighted.push(id);
        });
        return weighted[Math.floor(Math.random() * weighted.length)];
    },
    
    // Check quest completion
    checkQuests(data) {
        if (!data.quests) data.quests = { active: [], completed: [] };
        const stats = data.stats || {};
        let changed = false;
        
        Object.values(CONFIG.quests).forEach(q => {
            if (data.quests.completed.includes(q.id)) return;
            if (q.stat === 'custom') return; // Custom checks handled elsewhere
            
            const progress = stats[q.stat] || 0;
            if (progress >= q.target) {
                data.quests.completed.push(q.id);
                changed = true;
                
                // Grant rewards
                if (q.reward) {
                    if (q.reward.bits) data.stash.bits = (data.stash.bits || 0) + q.reward.bits;
                    if (q.reward.title && data.profile) {
                        if (!data.profile.unlockedTitles.includes(q.reward.title)) {
                            data.profile.unlockedTitles.push(q.reward.title);
                        }
                    }
                }
            }
        });
        
        if (changed) SaveManager.save(data);
    },
    
    // Check achievement completion
    checkAchievements(data) {
        if (!data.achievements) data.achievements = [];
        const stats = data.stats || {};
        let changed = false;
        
        Object.values(CONFIG.achievements).forEach(ach => {
            if (data.achievements.includes(ach.id)) return;
            
            let earned = false;
            if (ach.stat === 'custom') {
                // Custom checks
                if (ach.check === 'loreCount') {
                    earned = (data.loreChips || []).length >= ach.target;
                }
                // Other custom checks added here
            } else {
                earned = (stats[ach.stat] || 0) >= ach.target;
            }
            
            if (earned) {
                data.achievements.push(ach.id);
                changed = true;
                
                // Grant rewards
                if (ach.reward) {
                    if (ach.reward.title && data.profile) {
                        if (!data.profile.unlockedTitles.includes(ach.reward.title)) {
                            data.profile.unlockedTitles.push(ach.reward.title);
                        }
                    }
                    if (ach.reward.aura && data.profile) {
                        if (!data.profile.unlockedAuras.includes(ach.reward.aura)) {
                            data.profile.unlockedAuras.push(ach.reward.aura);
                        }
                    }
                }
            }
        });
        
        if (changed) SaveManager.save(data);
    },
    
    // Batch update at end of run (avoids excessive saves during gameplay)
    endOfRun(runStats) {
        const data = SaveManager.load();
        if (!data.stats) data.stats = {};
        const s = data.stats;
        
        // Merge run stats
        s.enemiesKilled = (s.enemiesKilled || 0) + (runStats.kills || 0);
        s.meleeKills = (s.meleeKills || 0) + (runStats.meleeKills || 0);
        s.rangedKills = (s.rangedKills || 0) + (runStats.rangedKills || 0);
        s.bossesKilled = (s.bossesKilled || 0) + (runStats.bossesKilled || 0);
        s.damageDealt = (s.damageDealt || 0) + (runStats.damageDealt || 0);
        s.damageTaken = (s.damageTaken || 0) + (runStats.damageTaken || 0);
        s.itemsLooted = (s.itemsLooted || 0) + (runStats.itemsLooted || 0);
        s.containersOpened = (s.containersOpened || 0) + (runStats.containersOpened || 0);
        s.buildingsExplored = (s.buildingsExplored || 0) + (runStats.buildingsExplored || 0);
        s.distanceTraveled = (s.distanceTraveled || 0) + (runStats.distanceTraveled || 0);
        s.flairWeaponsFound = (s.flairWeaponsFound || 0) + (runStats.flairWeaponsFound || 0);
        s.baneWeaponsFound = (s.baneWeaponsFound || 0) + (runStats.baneWeaponsFound || 0);
        s.cubesCollected = (s.cubesCollected || 0) + (runStats.cubesCollected || 0);
        s.timePlayed = (s.timePlayed || 0) + (runStats.runTime || 0);
        
        if (runStats.survived) {
            s.runsCompleted = (s.runsCompleted || 0) + 1;
            s.bitsEarned = (s.bitsEarned || 0) + (runStats.bitsEarned || 0);
        } else {
            s.runsFailed = (s.runsFailed || 0) + 1;
            s.deathCount = (s.deathCount || 0) + 1;
        }
        
        if ((runStats.runTime || 0) > (s.longestSurvival || 0)) s.longestSurvival = runStats.runTime;
        if ((runStats.reach || 0) > (s.highestReach || 0)) s.highestReach = runStats.reach;
        
        s.sessionsPlayed = (s.sessionsPlayed || 0) + 1;
        
        // === XP CALCULATION ===
        const xpR = CONFIG.leveling.xpRewards;
        let xpEarned = 0;
        xpEarned += (runStats.kills || 0) * xpR.enemyKill;
        xpEarned += (runStats.bossesKilled || 0) * xpR.bossKill;
        xpEarned += (runStats.buildingsExplored || 0) * xpR.buildingExplored;
        xpEarned += (runStats.itemsLooted || 0) * xpR.itemExtracted;
        xpEarned += (runStats.cubesCollected || 0) * xpR.cubFragmentFound;
        xpEarned += (runStats.nodesCleared || 0) * xpR.nodeCleared;
        if (runStats.survived) {
            xpEarned += xpR.runCompleted;
            if ((runStats.damageTaken || 0) === 0) xpEarned += xpR.runCompletedFlawless;
        }
        
        const xpResult = PlayerProgression.awardXP(data, xpEarned, 'run_complete');
        // Store in runStats so the results screen can show it
        runStats.xpEarned = xpEarned;
        runStats.leveledUp = xpResult.leveledUp;
        runStats.newLevel = xpResult.newLevel;
        runStats.levelRewards = xpResult.rewards;
        
        SaveManager.save(data);
        this.checkQuests(data);
        this.checkAchievements(data);
        
        return data;
    }
};

