// Vestige GPS — SurvivorGenerator
// Procedural NPC/squad member generation

import { CONFIG } from '../data/config.js';

export const SurvivorGenerator = {
    _textureRegistrar: null,

    /**
     * Set a texture registrar for Phaser texture caching.
     * registrar: { exists(scene, key), register(scene, key, canvas) }
     * Without this, icon methods return { key, canvas } instead of registering.
     */
    setTextureRegistrar(registrar) {
        SurvivorGenerator._textureRegistrar = registrar;
    },

    _registerTex(scene, key, canvas) {
        const reg = SurvivorGenerator._textureRegistrar;
        if (reg) {
            reg.register(scene, key, canvas);
        }
        return key;
    },

    _texExists(scene, key) {
        const reg = SurvivorGenerator._textureRegistrar;
        return reg ? reg.exists(scene, key) : false;
    },

    // ── RARITY TIERS ──
    RARITIES: {
        common:    { label: 'Common',    color: 0x888888, textColor: '#888888', marks: 0, weight: 50 },
        uncommon:  { label: 'Uncommon',  color: 0x44aa44, textColor: '#44aa44', marks: 1, weight: 28 },
        rare:      { label: 'Rare',      color: 0x4488cc, textColor: '#4488cc', marks: 2, weight: 14 },
        master:    { label: 'Master',    color: 0xaa44cc, textColor: '#aa44cc', marks: 3, weight: 6 },
        legendary: { label: 'Legendary', color: 0xcc8822, textColor: '#cc8822', marks: 4, weight: 2 }
    },

    // ── NAME POOLS (tiered by rarity — rarer = more unique) ──
    NAMES_COMMON: [
        'Ash','Bolt','Cade','Dex','Grit','Knox','Pike','Reed','Ward','Nash',
        'Jet','Arc','Dune','Fray','Moss','Rust','Slate','Tusk','York','Zinc',
        'Cole','Hank','Dale','Jeb','Mack','Dunn','Clay','Burt','Glen','Ray'
    ],
    NAMES_UNCOMMON: [
        'Ember','Flint','Haze','Jinx','Mace','Scar','Thorn','Vale','Wren',
        'Blaze','Crow','Edge','Forge','Hawk','Ivy','Lynx','Mira','Sage','Talon',
        'Crag','Bane','Pyre','Opal','Kova','Iron','Ghost'
    ],
    NAMES_RARE: [
        'Drift','Gale','Hex','Jade','Kael','Lark','Nyx','Onyx','Pulse',
        'Ursa','Vex','Wisp','Xero','Yara','Quill','Vigil','Zara','Uma'
    ],
    NAMES_MASTER: [
        'Lux','Nox','Raze','Xan','Zeke','Aether','Sable','Mordecai',
        'Solace','Requiem','Veris','Tenebra','Eidolon','Cadence','Nihil'
    ],
    NAMES_LEGENDARY: [
        'Remnant','Hollow','Ashborn','Duskwalker','Gravebound','Forsaken',
        'Stormcalled','Threadbare','Voidtouched','Branded','Faceless',
        'Undying','Witness','Severance','Omen','Wraith','Revenant',
        'Haunt','Vestige','Ruin'
    ],

    // ── GENDER ──
    GENDERS: [
        { id: 'male', label: 'Male', weight: 40 },
        { id: 'female', label: 'Female', weight: 40 },
        { id: 'unknown', label: 'Unknown', weight: 20 }
    ],

    // ── APPEARANCE DATA ──
    SKIN_TONES: [
        { id: 'pale', color: 0xffe0c0 },
        { id: 'light', color: 0xf0c8a0 },
        { id: 'medium', color: 0xc8a070 },
        { id: 'tan', color: 0xa87840 },
        { id: 'brown', color: 0x805030 },
        { id: 'dark', color: 0x503020 }
    ],
    HAIR_STYLES: ['shaved','short','messy','mohawk','long','ponytail','braids','bald','hood','bandana'],
    HAIR_COLORS: [
        { id: 'black', color: 0x1a1a1a },
        { id: 'brown', color: 0x4a3020 },
        { id: 'auburn', color: 0x6a3020 },
        { id: 'blonde', color: 0xc0a060 },
        { id: 'grey', color: 0x808080 },
        { id: 'white', color: 0xcccccc },
        { id: 'red', color: 0x883322 }
    ],
    EYE_COLORS: [
        { id: 'brown', color: 0x553311 },
        { id: 'green', color: 0x338833 },
        { id: 'blue', color: 0x335588 },
        { id: 'grey', color: 0x667788 },
        { id: 'amber', color: 0x886622 },
        { id: 'hazel', color: 0x667733 }
    ],
    CLOTHES_COLORS: [
        0x3a3a3a, 0x4a4a3a, 0x2a3a2a, 0x3a2a2a, 0x2a2a3a,
        0x5a4a3a, 0x3a4a4a, 0x4a3a4a, 0x555544, 0x443344
    ],
    LEGENDARY_OUTFIT_COLORS: [
        { primary: 0x882222, accent: 0xcc8822 },
        { primary: 0x224488, accent: 0x88ccff },
        { primary: 0x222222, accent: 0xcc4444 },
        { primary: 0x443388, accent: 0xaa66ff },
        { primary: 0x2a4a2a, accent: 0x88ff44 },
        { primary: 0x884400, accent: 0xffcc00 }
    ],

    // ── PERSONALITY TEMPLATES ──
    PERSONALITIES: [
        { id: 'stoic', label: 'Stoic', quips: [
            'Silence is armor.', 'I\'ve seen worse.', 'Keep moving.', 'No complaints.'
        ]},
        { id: 'nervous', label: 'Nervous', quips: [
            'D-did you hear that?', 'Maybe we should go back...', 'I have a bad feeling.', 'Is that blood?'
        ]},
        { id: 'aggressive', label: 'Aggressive', quips: [
            'Let me at them.', 'Finally, a fight.', 'Point me at trouble.', 'They bleed just fine.'
        ]},
        { id: 'optimistic', label: 'Optimistic', quips: [
            'We\'ve got this!', 'Every day above ground.', 'Could be worse!', 'The sun\'s still up.'
        ]},
        { id: 'cynical', label: 'Cynical', quips: [
            'This won\'t end well.', 'Hope is expensive.', 'Trust gets you killed.', 'Another day in paradise.'
        ]},
        { id: 'curious', label: 'Curious', quips: [
            'What\'s that over there?', 'I want to look closer.', 'How does this work?', 'Interesting...'
        ]},
        { id: 'loyal', label: 'Loyal', quips: [
            'I\'ve got your back.', 'Where you go, I go.', 'Leave no one behind.', 'Say the word.'
        ]},
        { id: 'haunted', label: 'Haunted', quips: [
            'They\'re still out there.', 'I can\'t forget.', 'The walls remember.', '...sorry. Bad dream.'
        ]},
        { id: 'mechanical', label: 'Mechanical', quips: [
            'Operational.', 'Directive received.', 'Efficiency nominal.', 'Awaiting input.'
        ]},
        { id: 'infected', label: 'Benign Host', quips: [
            'It whispers sometimes.', 'I can feel them.', 'My blood runs cold.', 'Don\'t worry. It\'s dormant.'
        ]}
    ],

    // ── PERK DEFINITIONS ──
    // ── MARK POOLS ──
    // Born Marks — rolled at survivor generation based on rarity
    MARKS_BORN: {
        // Mundane tier — each mark ≈ 1/3 of a gear mod slot in value
        thick_skinned:  { name: 'Thick Skinned',  tier: 'mundane',   type: 'positive', desc: '+4% damage resistance',                      trigger: null, cubeVariantOf: null, effects: { damageResist: 0.04 } },
        light_sleeper:  { name: 'Light Sleeper',   tier: 'mundane',   type: 'mixed',    desc: '+3% speed, -2% max HP',                      trigger: null, cubeVariantOf: null, effects: { speedMultiplier: 1.03, hpMultiplier: 0.98 } },
        steady_hands:   { name: 'Steady Hands',    tier: 'mundane',   type: 'positive', desc: '-5% weapon spread',                          trigger: null, cubeVariantOf: null, effects: { weaponSpread: -0.05 } },
        hollow_stomach: { name: 'Hollow Stomach',  tier: 'mundane',   type: 'negative', desc: 'Consumables 12% less effective',               trigger: null, cubeVariantOf: null, effects: { consumableEffectiveness: -0.12 } },
        pack_rat:       { name: 'Pack Rat',         tier: 'mundane',   type: 'positive', desc: '+1 backpack slot when deployed',               trigger: null, cubeVariantOf: null, effects: { backpackBonus: 1 } },
        paranoid:       { name: 'Paranoid',         tier: 'mundane',   type: 'mixed',    desc: '+5% detection range, -3% speed',               trigger: null, cubeVariantOf: null, effects: { detectionRange: 0.05, speedMultiplier: 0.97 } },
        scar_tissue:    { name: 'Scar Tissue',      tier: 'mundane',   type: 'mixed',    desc: '+5% physical resist, -3% elemental resist',    trigger: null, cubeVariantOf: null, effects: { damageResist: 0.05, elementalResist: -0.03 } },
        iron_gut:       { name: 'Iron Gut',         tier: 'mundane',   type: 'positive', desc: 'Immune to poison status',                     trigger: null, cubeVariantOf: null, effects: { immunities: ['poison'] } },
        // Strange tier — notable effects with meaningful tradeoffs
        cube_adjacent:  { name: 'Cube Adjacent',   tier: 'strange',   type: 'mixed',    desc: '+8% dmg vs anomaly, -5% vs human',             trigger: null, cubeVariantOf: null, effects: { conditionals: { damageVsAnomaly: 0.08, damageVsHuman: -0.05 } } },
        bloodless:      { name: 'Bloodless',        tier: 'strange',   type: 'mixed',    desc: '-10% aggro range, healing 15% less effective',  trigger: null, cubeVariantOf: null, effects: { aggroRange: -0.10, healingEffectiveness: -0.15 } },
        fracture_point: { name: 'Fracture Point',  tier: 'strange',   type: 'negative', desc: 'First hit each encounter deals 1.4x dmg to you', trigger: null, cubeVariantOf: null, effects: { conditionals: { firstHitMultiplier: 1.4 } } },
        resonant:       { name: 'Resonant',         tier: 'strange',   type: 'positive', desc: '5% chance bonus material from loot',            trigger: null, cubeVariantOf: null, effects: { conditionals: { bonusMaterialChance: 0.05 } } },
        twice_born:     { name: 'Twice Born',       tier: 'strange',   type: 'positive', desc: 'Once per run survive a killing blow at 1HP',   trigger: null, cubeVariantOf: null, effects: { conditionals: { twiceBorn: true } } },
        void_touched:   { name: 'Void Touched',    tier: 'strange',   type: 'negative', desc: 'Cube Anomaly enemies prioritize you',          trigger: null, cubeVariantOf: null, effects: { conditionals: { cubeAggroTarget: true } } },
        // Legendary tier — powerful unique effects
        raums_favorite: { name: "Raum's Favorite", tier: 'legendary', type: 'mixed',    desc: '+6% all stats, negative Marks accumulate 2x',   trigger: null, cubeVariantOf: null, effects: { statMultiplier: 1.06, conditionals: { doubleNegativeMarkRate: true } } },
        the_weight:     { name: 'The Weight',       tier: 'legendary', type: 'negative', desc: '+3% fuel cost on all routes when deployed',    trigger: null, cubeVariantOf: null, effects: { fuelCostMultiplier: 1.03 } },
        unmarked:       { name: 'Unmarked',         tier: 'legendary', type: 'positive', desc: 'Immune to earning negative injury Marks',      trigger: null, cubeVariantOf: null, effects: { conditionals: { immuneToInjuryMarks: true } } }
    },

    // Earned Marks — acquired through gameplay events
    MARKS_EARNED: {
        // trigger: 'permanent_injury'
        shattered_knee: { name: 'Shattered Knee',  tier: 'earned', type: 'negative', desc: '-5% speed permanent',                          trigger: 'permanent_injury', cubeVariantOf: null, effects: { speedMultiplier: 0.95 } },
        nerve_damage:   { name: 'Nerve Damage',    tier: 'earned', type: 'negative', desc: '+4% weapon spread permanent',                  trigger: 'permanent_injury', cubeVariantOf: null, effects: { weaponSpread: 0.04 } },
        hollow_eye:     { name: 'Hollow Eye',      tier: 'earned', type: 'negative', desc: '-4% detection range permanent',                trigger: 'permanent_injury', cubeVariantOf: null, effects: { detectionRange: -0.04 } },
        scar_map:       { name: 'Scar Map',        tier: 'earned', type: 'mixed',    desc: '-3% max HP, +3% damage resistance',            trigger: 'permanent_injury', cubeVariantOf: null, effects: { hpMultiplier: 0.97, damageResist: 0.03 } },
        ghost_limb:     { name: 'Ghost Limb',      tier: 'earned', type: 'mixed',    desc: '-3% all stats, immune to maimed injury',       trigger: 'permanent_injury', cubeVariantOf: null, effects: { statMultiplier: 0.97, immunities: ['maimed'] } },
        // trigger: 'near_death_survived'
        spite:          { name: 'Spite',            tier: 'earned', type: 'positive', desc: '+8% all stats when below 25% HP',             trigger: 'near_death_survived', cubeVariantOf: null, effects: { conditionals: { spiteThreshold: 0.25, spiteBonus: 0.08 } } },
        threshold:      { name: 'Threshold',       tier: 'earned', type: 'mixed',    desc: '+8% resist below 50% HP, -3% above',          trigger: 'near_death_survived', cubeVariantOf: null, effects: { conditionals: { thresholdHigh: 0.50, thresholdResistBelow: 0.08, thresholdResistAbove: -0.03 } } },
        haunted_pace:   { name: 'Haunted Pace',    tier: 'earned', type: 'negative', desc: '-3% speed permanent',                          trigger: 'near_death_survived', cubeVariantOf: null, effects: { speedMultiplier: 0.97 } },
        // trigger: 'boss_killed'
        wardens_brand:  { name: "Warden's Brand",  tier: 'earned', type: 'mixed',    desc: '+8% dmg vs armored, prioritized by armored',   trigger: 'boss_killed', cubeVariantOf: null, effects: { conditionals: { damageVsArmored: 0.08, armoredAggroTarget: true } } },
        swarm_memory:   { name: 'Swarm Memory',    tier: 'earned', type: 'mixed',    desc: 'Immune to swarm, 3% extra enemy wave',         trigger: 'boss_killed', cubeVariantOf: null, effects: { immunities: ['swarm'], conditionals: { extraWaveChance: 0.03 } } },
        phantom_step:   { name: 'Phantom Step',    tier: 'earned', type: 'positive', desc: '6% chance to dodge any hit',                   trigger: 'boss_killed', cubeVariantOf: null, effects: { conditionals: { phantomDodgeChance: 0.06 } } },
        ironclad_grudge:{ name: 'Ironclad Grudge', tier: 'earned', type: 'positive', desc: '+8% damage to mechanical enemies',             trigger: 'boss_killed', cubeVariantOf: null, effects: { conditionals: { damageVsMechanical: 0.08 } } },
        cube_witness:   { name: 'Cube Witness',    tier: 'earned', type: 'mixed',    desc: '+10% vs anomaly, 12% Cube variant chance',     trigger: 'boss_killed', cubeVariantOf: null, effects: { conditionals: { damageVsAnomaly: 0.10, cubeVariantChance: 0.12 } } },
        // trigger: 'foundry_completed'
        foundry_lungs:  { name: 'Foundry Lungs',   tier: 'earned', type: 'negative', desc: '-5% max HP permanent',                         trigger: 'foundry_completed', cubeVariantOf: null, effects: { hpMultiplier: 0.95 } },
        smelters_instinct: { name: "Smelter's Instinct", tier: 'earned', type: 'positive', desc: '+5% materials found',                    trigger: 'foundry_completed', cubeVariantOf: null, effects: { materialsBonus: 0.05 } },
        // trigger: 'cube_anomaly_survived'
        static_mind:    { name: 'Static Mind',     tier: 'earned', type: 'mixed',    desc: 'Immune to confusion/disorientation, quips off',  trigger: 'cube_anomaly_survived', cubeVariantOf: null, effects: { immunities: ['confusion', 'disorientation'], conditionals: { quipsSuppressed: true } } },
        // trigger: 'runs_milestone'
        raum_veteran:   { name: 'Raum Veteran',    tier: 'earned', type: 'positive', desc: '+3% all stat multipliers',                     trigger: 'runs_milestone', cubeVariantOf: null, effects: { statMultiplier: 1.03 } },
        road_ghost:     { name: 'Road Ghost',      tier: 'earned', type: 'positive', desc: '-3% fuel cost when deployed',                  trigger: 'runs_milestone', cubeVariantOf: null, effects: { fuelCostMultiplier: 0.97 } },
        irreplaceable:  { name: 'Irreplaceable',   tier: 'earned', type: 'mixed',    desc: '+5% all stats, -3% convoy loot on death',      trigger: 'runs_milestone', cubeVariantOf: null, effects: { statMultiplier: 1.05, conditionals: { irreplaceablePenalty: true } } }
    },

    // Cube Variant Marks — twisted upgrades of negative/mixed Marks via Cube influence
    MARKS_CUBE: {
        phased_stride:   { name: 'Phased Stride',   tier: 'cube', type: 'mixed', desc: '-5% speed, 4% dodge while moving',             cubeVariantOf: 'shattered_knee',  effects: { speedMultiplier: 0.95, conditionals: { phasedDodgeChance: 0.04 } } },
        signal_hands:    { name: 'Signal Hands',    tier: 'cube', type: 'mixed', desc: '+4% spread, +8% reload, crit disorient',       cubeVariantOf: 'nerve_damage',    effects: { weaponSpread: 0.04, reloadSpeed: 0.08, conditionals: { critDisorientChance: 0.08 } } },
        the_other_sight: { name: 'The Other Sight', tier: 'cube', type: 'mixed', desc: '-4% detection, see anomaly through walls',      cubeVariantOf: 'hollow_eye',      effects: { detectionRange: -0.04, conditionals: { anomalyWallDetect: 50 } } },
        the_following:   { name: 'The Following',   tier: 'cube', type: 'mixed', desc: '-3% speed, auto-dodge killing blow once/run',    cubeVariantOf: 'haunted_pace',    effects: { speedMultiplier: 0.97, conditionals: { theFollowingActive: true } } },
        cube_metabolized:{ name: 'Cube Metabolized', tier: 'cube', type: 'mixed', desc: 'Consumables -12%, +1HP regen every 12s',        cubeVariantOf: 'hollow_stomach',  effects: { consumableEffectiveness: -0.12, conditionals: { cubeRegenRate: 12000, cubeRegenAmount: 1 } } },
        resonant_break:  { name: 'Resonant Break',  tier: 'cube', type: 'mixed', desc: 'First hit 1.4x dmg, stagger pulse to enemies',  cubeVariantOf: 'fracture_point',  effects: { conditionals: { firstHitMultiplier: 1.4, firstHitStaggerPulse: true } } },
        ballast:         { name: 'Ballast',          tier: 'cube', type: 'mixed', desc: '+3% fuel, +4% loot quality when deployed',      cubeVariantOf: 'the_weight',      effects: { fuelCostMultiplier: 1.03, conditionals: { lootQualityBonus: 0.04 } } },
        claimed:         { name: 'Claimed',          tier: 'cube', type: 'mixed', desc: 'Cube aggro, 10% melee damage reflected',        cubeVariantOf: 'void_touched',    effects: { conditionals: { cubeAggroTarget: true, meleeReflect: 0.10 } } }
    },

    // Boss type → earned mark mapping
    _BOSS_MARK_MAP: {
        warden: 'wardens_brand', swarmQueen: 'swarm_memory', phantom: 'phantom_step',
        ironclad: 'ironclad_grudge', cubeAnomaly: 'cube_witness'
    },

    // Runs milestone → earned mark mapping
    _RUNS_MARK_MAP: { 10: 'raum_veteran', 25: 'road_ghost', 50: 'irreplaceable' },

    // ── RANK ICON RENDERER ──
    // Generates 16×16 pixel-art rank insignia textures, cached per rank level
    // All ranks share the same arm-patch shape. Higher levels add chevrons, then stars.
    getRankIconKey(level) { return `rank_icon_${level}`; },
    generateRankIcon(scene, level) {
        const key = this.getRankIconKey(level);
        if (SurvivorGenerator._texExists(scene, key)) return key;
        const s = 16;
        const c = document.createElement('canvas'); c.width = s; c.height = s;
        const x = c.getContext('2d');
        const px = (ax, ay, col) => { x.fillStyle = col; x.fillRect(ax, ay, 1, 1); };
        const rect = (ax, ay, w, h, col) => { x.fillStyle = col; x.fillRect(ax, ay, w, h); };

        // ── Base patch shape (same for all ranks) ──
        // Fabric background color gets richer with rank
        const fabrics = ['#3a3a44','#3a3322','#3a2222','#2a3344','#3a2a1a','#2a2a18','#221122'];
        const borders = ['#555566','#665533','#774433','#556688','#886633','#887744','#553366'];
        const fab = fabrics[level-1], bord = borders[level-1];
        
        // Patch body — rounded rectangle
        rect(3,2,10,12,fab);
        rect(2,3,1,10,fab); rect(13,3,1,10,fab);
        // Border stitching
        rect(3,1,10,1,bord); rect(3,14,10,1,bord);
        rect(1,3,1,10,bord); rect(14,3,1,10,bord);
        px(2,2,bord); px(13,2,bord); px(2,13,bord); px(13,13,bord);
        // Corner stitch dots
        px(3,2,'#666666'); px(12,2,'#666666'); px(3,13,'#666666'); px(12,13,'#666666');

        // ── Chevrons (levels 2+) — drawn from bottom up ──
        const chevCol = level >= 5 ? '#ccaa44' : level >= 4 ? '#8899aa' : '#aa8855';
        const chevHi  = level >= 5 ? '#eedd66' : level >= 4 ? '#aabbcc' : '#ccaa66';
        const numChev = level <= 1 ? 0 : level <= 2 ? 1 : level <= 3 ? 2 : 3;
        
        for (let ci = 0; ci < numChev; ci++) {
            const cy = 11 - ci * 3; // bottom chevron at y=11, stacking up
            // V-shape chevron, 2px thick
            for (let i = 0; i < 3; i++) {
                px(5+i, cy-i, chevCol); px(10-i, cy-i, chevCol);
                px(5+i, cy-i-1, chevHi); px(10-i, cy-i-1, chevHi);
            }
            // Chevron peak
            px(7, cy-2, chevHi); px(8, cy-2, chevHi);
        }

        // ── Stars (levels 5+) — drawn above chevrons ──
        const numStars = level <= 4 ? 0 : level === 5 ? 1 : level === 6 ? 2 : 3;
        const starCol = level >= 7 ? '#cc88ff' : '#eedd66';
        const starGlow = level >= 7 ? '#aa66ee' : '#ccaa44';
        
        if (numStars === 1) {
            // Single centered star
            px(7,3,starCol); px(8,3,starCol); px(6,4,starGlow); px(9,4,starGlow);
            px(7,4,starCol); px(8,4,starCol); px(7,5,starGlow); px(8,5,starGlow);
        } else if (numStars === 2) {
            // Two stars side by side
            px(5,3,starCol); px(5,4,starGlow); px(6,3,starGlow);
            px(10,3,starCol); px(10,4,starGlow); px(9,3,starGlow);
        } else if (numStars === 3) {
            // Three stars — one top center, two flanking below
            px(7,2,starCol); px(8,2,starCol); px(7,3,starGlow); px(8,3,starGlow);
            px(4,4,starCol); px(5,4,starGlow); px(4,5,starGlow);
            px(10,4,starCol); px(11,4,starGlow); px(10,5,starGlow);
        }

        // Level 1 special: frayed/blank patch, no insignia — just stitch marks
        if (level === 1) {
            // Diagonal stitch lines across empty fabric
            for(let i=0;i<4;i++) { px(5+i*2, 5+i, '#4a4a55'); px(6+i*2, 8+i, '#4a4a55'); }
            // Frayed bottom edge
            px(4,13,'#2a2a33'); px(7,14,'#2a2a33'); px(10,13,'#2a2a33');
        }
        
        // Level 7 special: cosmic glow border
        if (level === 7) {
            px(2,1,'#6633aa'); px(13,1,'#6633aa'); px(2,14,'#6633aa'); px(13,14,'#6633aa');
            px(0,5,'#442266'); px(0,9,'#442266'); px(15,5,'#442266'); px(15,9,'#442266');
            px(1,2,'#553377'); px(14,2,'#553377'); px(1,12,'#553377'); px(14,12,'#553377');
        }

        SurvivorGenerator._registerTex(scene, key, c);
        return key;
    },

    // ── MARK ICON RENDERER ──
    // Generates 14×14 pixel-art mark icons, cached by mark ID
    getMarkIconKey(id) { return `mark_icon_${id}`; },
    generateMarkIcon(scene, id) {
        const key = this.getMarkIconKey(id);
        if (SurvivorGenerator._texExists(scene, key)) return key;
        const s = 14;
        const c = document.createElement('canvas'); c.width = s; c.height = s;
        const x = c.getContext('2d');
        const px = (ax,ay,col) => { x.fillStyle=col; x.fillRect(ax,ay,1,1); };
        const rect = (ax,ay,w,h,col) => { x.fillStyle=col; x.fillRect(ax,ay,w,h); };
        const vLine = (ax,ay,len,col) => rect(ax,ay,1,len,col);

        // ═══ BORN MARKS ═══
        if (id === 'thick_skinned') {
            const plate='#668866',hi='#88aa88',dark='#445544',edge='#334433';
            rect(3,2,8,10,plate);rect(2,3,1,8,dark);rect(11,3,1,8,dark);
            rect(3,2,8,1,hi);rect(3,12,8,1,edge);
            for(let r=0;r<3;r++) for(let cc=0;cc<3;cc++){px(4+cc*3,4+r*3,hi);px(5+cc*3,5+r*3,dark);}
            px(4,3,'#99bb99');px(10,3,'#99bb99');px(4,11,'#99bb99');px(10,11,'#99bb99');
        } else if (id === 'light_sleeper') {
            const lid='#88aa66',iris='#aabb44',pupil='#334422',spark='#eeff88';
            rect(3,5,8,4,lid);rect(4,4,6,1,lid);rect(4,9,6,1,lid);
            px(2,6,'#556644');px(11,6,'#556644');
            rect(6,5,2,3,'#667733');px(7,6,iris);px(6,6,pupil);
            px(7,2,spark);px(6,1,spark);px(8,1,spark);px(7,3,'#aacc55');
        } else if (id === 'steady_hands') {
            const ring='#66aa66',cross='#88cc88',dot='#aaffaa';
            rect(5,2,4,1,ring);rect(5,11,4,1,ring);rect(2,5,1,4,ring);rect(11,5,1,4,ring);
            px(3,3,ring);px(10,3,ring);px(3,10,ring);px(10,10,ring);
            rect(6,0,2,3,cross);rect(6,11,2,3,cross);rect(0,6,3,2,cross);rect(11,6,3,2,cross);
            px(6,6,dot);px(7,6,dot);px(6,7,dot);px(7,7,dot);
        } else if (id === 'hollow_stomach') {
            const bowl='#aa6644',rim='#cc8855',empty='#3a2211',crack='#884422';
            rect(4,4,6,2,rim);rect(3,6,8,4,bowl);rect(4,10,6,1,bowl);rect(5,11,4,1,crack);
            rect(5,5,4,4,empty);
            px(5,7,crack);px(6,8,crack);px(8,6,crack);
            px(2,5,'#663322');px(11,5,'#663322');px(7,12,'#663322');
        } else if (id === 'pack_rat') {
            const bag='#668844',strap='#557733',buckle='#aaaa44',dark='#334422';
            rect(4,3,6,8,bag);rect(3,4,1,6,dark);rect(10,4,1,6,dark);
            rect(4,3,6,1,'#779955');rect(4,11,6,1,dark);
            vLine(5,1,3,strap);vLine(8,1,3,strap);
            px(5,3,buckle);px(8,3,buckle);
            rect(5,7,4,3,'#557733');rect(5,7,4,1,'#779955');px(7,8,buckle);
        } else if (id === 'paranoid') {
            const eye='#88aa44',scan='#aacc66',pupil='#223311',alert='#ccee88';
            rect(3,5,8,4,'#667733');rect(4,4,6,1,'#667733');rect(4,9,6,1,'#667733');
            px(6,6,pupil);px(7,6,pupil);px(6,7,scan);px(7,7,scan);
            px(1,4,scan);px(2,3,scan);px(3,2,alert);
            px(12,4,scan);px(11,3,scan);px(10,2,alert);
        } else if (id === 'scar_tissue') {
            const skin='#998877',scar='#aa6666',deep='#884444',tough='#88aa88';
            rect(3,2,8,10,skin);
            for(let i=0;i<7;i++){px(3+i,3+i,scar);px(4+i,3+i,deep);}
            px(4,6,tough);px(5,4,tough);px(9,8,tough);px(8,10,tough);
            px(5,4,'#666655');px(7,6,'#666655');px(9,8,'#666655');
        } else if (id === 'iron_gut') {
            const iron='#778888',hi='#99bbbb',dark='#445555',cap='#aaaa66';
            rect(5,3,4,9,iron);rect(4,4,6,7,iron);
            rect(5,3,4,1,hi);rect(4,11,6,1,dark);
            rect(6,1,2,2,cap);px(6,2,hi);vLine(5,4,6,hi);
            px(6,6,dark);px(8,6,dark);px(7,7,'#66aa66');px(6,8,dark);px(8,8,dark);
        } else if (id === 'cube_adjacent') {
            const cube='#556666',glow='#aa88cc',dark='#334444',bright='#cc99ee';
            rect(3,3,8,8,cube);rect(3,3,4,8,glow);
            rect(3,3,8,1,bright);rect(3,11,8,1,dark);rect(2,4,1,6,dark);rect(11,4,1,6,dark);
            vLine(7,3,8,'#44555555');
            px(1,5,bright);px(0,7,glow);px(1,9,bright);
        } else if (id === 'bloodless') {
            const blood='#aa5555',dark='#662233',x_col='#cc8844';
            px(6,2,blood);px(7,2,blood);rect(5,3,4,2,blood);
            rect(4,5,6,4,blood);rect(5,9,4,2,blood);px(6,11,dark);
            px(5,4,'#cc7777');
            for(let i=0;i<6;i++){px(4+i,4+i,x_col);px(9-i,4+i,x_col);}
        } else if (id === 'fracture_point') {
            const crack='#aa4444',deep='#882222',flash='#ff6644',bg='#331111';
            rect(3,3,8,8,bg);
            px(6,6,flash);px(7,6,flash);px(6,7,flash);px(7,7,flash);
            px(5,5,crack);px(4,4,deep);px(3,3,crack);
            px(8,5,crack);px(9,4,deep);px(10,3,crack);
            px(5,8,crack);px(4,9,deep);px(3,10,crack);
            px(8,8,crack);px(9,9,deep);px(10,10,crack);
            px(6,4,crack);px(7,9,crack);px(4,7,crack);px(9,6,crack);
        } else if (id === 'resonant') {
            const fork='#66aa66',vib='#88cc88',glow='#aaffaa';
            vLine(5,2,6,fork);vLine(8,2,6,fork);
            rect(6,8,2,4,fork);px(6,12,'#448844');
            px(5,2,glow);px(8,2,glow);
            px(3,4,vib);px(4,3,vib);px(10,4,vib);px(9,3,vib);
            px(3,6,vib);px(10,6,vib);px(2,5,glow);px(11,5,glow);
        } else if (id === 'twice_born') {
            const flame='#44cc66',bright='#88ffaa',core='#ffffff',dark='#227744';
            rect(5,4,4,6,flame);rect(6,3,2,1,flame);
            px(6,2,bright);px(7,2,bright);px(7,1,core);
            px(4,5,flame);px(3,4,bright);px(2,3,dark);
            px(9,5,flame);px(10,4,bright);px(11,3,dark);
            px(6,6,core);px(7,6,core);px(6,7,bright);px(7,7,bright);
            px(5,10,'#336644');px(8,10,'#336644');px(6,11,dark);px(7,11,dark);
        } else if (id === 'void_touched') {
            const void_c='#221133',iris='#8844aa',pupil='#000000',rim='#553366';
            rect(2,4,10,6,void_c);rect(3,3,8,1,rim);rect(3,10,8,1,rim);
            px(1,6,rim);px(12,6,rim);
            rect(5,5,4,4,iris);rect(6,4,2,1,'#6633aa');
            vLine(6,5,4,pupil);vLine(7,5,4,pupil);
            px(2,3,'#553366');px(11,3,'#553366');
        } else if (id === 'raums_favorite') {
            const star='#cc8822',glow='#ffaa33',halo='#eedd66',dark='#884411';
            px(6,3,halo);px(7,3,halo);rect(5,4,4,1,glow);rect(3,5,8,2,star);
            rect(5,7,4,1,glow);px(6,8,star);px(7,8,star);
            px(6,2,glow);px(7,2,glow);px(2,5,glow);px(11,5,glow);px(6,9,dark);px(7,9,dark);
            rect(4,1,6,1,dark);rect(4,10,6,1,dark);
            px(2,3,dark);px(11,3,dark);px(2,8,dark);px(11,8,dark);
            px(1,5,dark);px(1,6,dark);px(12,5,dark);px(12,6,dark);
        } else if (id === 'the_weight') {
            const chain='#aa5544',link='#884433',dark='#552222',heavy='#cc6655';
            rect(4,1,6,3,chain);rect(3,2,1,1,link);rect(10,2,1,1,link);
            rect(5,4,4,2,dark);
            rect(4,6,6,3,chain);rect(3,7,1,1,link);rect(10,7,1,1,link);
            rect(5,9,4,2,dark);
            rect(4,11,6,2,chain);rect(3,12,1,1,link);
            px(5,2,heavy);px(8,2,heavy);px(5,7,heavy);px(8,7,heavy);
            rect(5,13,4,1,'#331111');
        } else if (id === 'unmarked') {
            const shield='#66aa66',rim='#448844',hi='#88cc88';
            rect(4,2,6,1,hi);rect(3,3,8,7,shield);rect(4,10,6,1,shield);
            rect(5,11,4,1,rim);px(6,12,rim);px(7,12,rim);
            rect(4,3,2,3,hi);px(4,2,hi);rect(6,5,2,3,'#77bb77');
        }
        // ═══ EARNED MARKS ═══
        else if (id === 'shattered_knee') {
            const bone='#aa8877',crack='#cc4444',dark='#664433',snap='#ff5544';
            vLine(6,1,5,bone);vLine(7,1,5,bone);vLine(6,8,5,bone);vLine(7,8,5,bone);
            rect(4,5,6,3,dark);px(5,6,snap);px(6,6,crack);px(7,6,crack);px(8,6,snap);
            rect(5,1,4,1,'#bbaa99');rect(5,12,4,1,'#bbaa99');px(5,4,crack);px(8,7,crack);
        } else if (id === 'nerve_damage') {
            const nerve='#aa5544',spark='#ffaa44',dark='#662222',wire='#cc6655';
            vLine(7,1,4,wire);vLine(6,2,3,wire);rect(5,5,4,2,spark);
            px(4,7,nerve);px(3,8,dark);px(2,9,nerve);
            px(6,7,nerve);px(6,8,nerve);px(5,9,dark);
            px(8,7,nerve);px(9,8,nerve);px(10,9,dark);
            px(10,7,nerve);px(11,8,dark);
            px(4,5,spark);px(9,5,spark);px(3,7,'#ffcc44');
        } else if (id === 'hollow_eye') {
            const rim='#886655',socket='#221111',dark='#554433',skin='#997766';
            rect(3,4,8,6,skin);rect(4,3,6,1,rim);rect(4,10,6,1,rim);
            rect(5,5,4,4,socket);rect(4,6,6,2,socket);
            px(3,5,dark);px(10,5,dark);px(3,8,dark);px(10,8,dark);
            px(6,4,'#331111');px(7,4,'#331111');
        } else if (id === 'scar_map') {
            const skin='#aa9988',scar='#cc6644',face='#998877',dark='#776655';
            rect(4,2,6,10,face);rect(3,4,1,6,dark);rect(10,4,1,6,dark);
            rect(5,1,4,1,skin);rect(5,12,4,1,dark);
            px(5,3,scar);px(6,4,scar);px(7,5,scar);px(8,4,scar);px(9,5,scar);
            px(4,7,scar);px(5,8,scar);px(6,9,scar);px(8,8,scar);px(9,7,scar);
            px(5,5,'#445544');px(8,5,'#445544');
        } else if (id === 'ghost_limb') {
            const ghost='#88aacc',outline='#445566';
            rect(5,2,4,3,outline);rect(4,5,2,4,ghost);rect(8,5,2,4,ghost);
            rect(5,9,4,2,outline);rect(4,11,2,1,ghost);rect(8,11,2,1,ghost);
            px(3,4,'#334455');px(10,4,'#334455');px(6,1,ghost);px(7,1,ghost);
        } else if (id === 'spite') {
            const flame='#cc4422',core='#ff6644',bright='#ffaa44',dark='#881111';
            rect(5,5,4,5,flame);rect(6,4,2,1,flame);
            px(6,3,core);px(7,3,core);px(7,2,bright);px(6,1,bright);
            px(4,6,core);px(3,5,flame);px(9,6,core);px(10,5,flame);
            px(6,7,bright);px(7,7,bright);px(6,8,'#ffcc44');px(7,8,'#ffcc44');
            px(5,10,dark);px(8,10,dark);px(6,11,dark);px(7,11,dark);
        } else if (id === 'threshold') {
            const above='#aa4444',below='#44aa66',line='#aaaa44',bg='#222222';
            rect(2,2,10,10,bg);
            rect(4,2,6,4,above);rect(3,3,8,3,above);px(3,4,above);
            rect(4,8,6,4,below);rect(3,8,8,3,below);
            rect(2,6,10,2,line);
            px(5,7,'#cccc66');px(6,7,'#cccc66');px(7,7,'#cccc66');px(8,7,'#cccc66');
        } else if (id === 'haunted_pace') {
            const print='#aa5544',fade='#664433',ghost='#553322';
            rect(7,8,3,2,print);rect(8,7,2,1,print);px(7,10,fade);
            rect(4,4,3,2,fade);rect(5,3,2,1,fade);px(4,6,ghost);
            rect(8,1,2,1,ghost);px(9,0,ghost);
            px(6,7,ghost);px(3,3,ghost);px(10,5,'#332211');
        } else if (id === 'wardens_brand') {
            const shield='#887744',brand='#cc8844',dark='#554422',hi='#aaaa66';
            rect(4,2,6,1,hi);rect(3,3,8,7,shield);rect(4,10,6,1,shield);
            rect(5,11,4,1,dark);px(6,12,dark);
            vLine(7,3,8,'#ffaa44');vLine(6,4,6,brand);px(4,3,hi);px(5,2,hi);
        } else if (id === 'swarm_memory') {
            const bug='#88aa44',wing='#aacc66';
            px(3,3,bug);px(4,3,wing);px(2,4,wing);
            px(7,2,bug);px(8,2,wing);px(6,3,wing);
            px(10,4,bug);px(11,4,wing);px(9,5,wing);
            px(5,6,bug);px(6,6,wing);px(4,7,wing);
            px(9,7,bug);px(10,7,wing);px(8,8,wing);
            px(3,9,bug);px(4,9,wing);
            px(7,10,bug);px(8,10,wing);px(6,11,wing);
            px(11,9,bug);px(10,10,wing);
        } else if (id === 'phantom_step') {
            const ghost='#8888cc',glow='#aaaaee',fade='#555577';
            rect(4,4,6,3,ghost);rect(3,7,8,3,ghost);rect(4,10,6,2,fade);
            rect(5,5,4,2,glow);px(5,4,glow);
            px(2,6,fade);px(11,6,fade);px(2,9,fade);px(11,9,fade);
            px(6,2,glow);px(7,2,glow);px(6,12,fade);px(7,12,fade);
        } else if (id === 'ironclad_grudge') {
            const gear='#778888',rim='#99aaaa',crack='#cc6644',dark='#445555';
            rect(4,4,6,6,gear);
            rect(6,2,2,2,rim);rect(6,10,2,2,rim);rect(2,6,2,2,rim);rect(10,6,2,2,rim);
            rect(6,6,2,2,dark);px(6,6,rim);px(7,7,rim);
            px(5,4,crack);px(6,5,crack);px(7,7,crack);px(8,8,crack);px(9,9,crack);
        } else if (id === 'cube_witness') {
            const cube='#557788',eye='#aacc44',pupil='#223311',glow='#88aa33';
            rect(3,3,8,8,cube);rect(4,2,6,1,'#668899');rect(3,11,8,1,'#445566');
            rect(4,5,6,3,eye);rect(5,4,4,1,glow);rect(5,8,4,1,glow);
            px(6,6,pupil);px(7,6,pupil);px(6,7,'#113300');
        } else if (id === 'foundry_lungs') {
            const lung='#aa5555',dark='#662233',smoke='#887766';
            rect(2,4,4,6,lung);rect(3,3,3,1,lung);px(4,2,dark);
            rect(8,4,4,6,lung);rect(8,3,3,1,lung);px(9,2,dark);
            vLine(6,1,3,dark);vLine(7,1,3,dark);
            px(3,6,dark);px(4,8,dark);px(9,5,dark);px(10,7,dark);
            px(5,0,smoke);px(7,0,smoke);px(8,1,smoke);
        } else if (id === 'smelters_instinct') {
            const handle='#886644',head='#66aa66',edge='#88cc88',dark='#446633';
            for(let i=0;i<7;i++) px(3+i,3+i,handle);
            for(let i=0;i<6;i++) px(4+i,3+i,'#775533');
            rect(2,2,4,2,head);px(1,2,edge);px(6,2,dark);rect(2,1,3,1,edge);px(1,1,'#aaffaa');
        } else if (id === 'static_mind') {
            const on='#88aaaa',off='#334444',line='#aacccc';
            rect(2,2,10,10,'#223333');
            const noise=[[0,1,0,1,1,0,1,0,1,0],[1,0,1,0,0,1,0,1,0,1],[0,1,1,0,1,1,0,0,1,0],[1,0,0,1,0,0,1,1,0,1],[0,1,0,1,1,0,1,0,1,0],[1,1,0,0,1,1,0,1,0,0],[0,0,1,1,0,0,1,0,1,1],[1,0,1,0,1,0,0,1,0,1]];
            for(let r=0;r<8;r++) for(let cc=0;cc<10;cc++){if(noise[r][cc]) px(2+cc,3+r,on); else px(2+cc,3+r,off);}
            rect(2,6,10,1,line);
        } else if (id === 'raum_veteran') {
            const ribbon='#44aa44',medal='#ccaa44',ring='#aa8833',pin='#eedd66';
            rect(4,2,6,3,ribbon);rect(5,1,4,1,'#55bb55');px(7,1,pin);
            rect(5,6,4,4,medal);rect(4,7,6,2,medal);
            px(5,5,ring);px(8,5,ring);px(5,10,ring);px(8,10,ring);
            px(6,7,pin);px(7,7,pin);px(6,8,pin);px(7,8,pin);px(7,5,ring);
        } else if (id === 'road_ghost') {
            const road='#555555',line='#aaaa44',ghost='#667788',fade='#334444';
            rect(1,10,12,3,road);rect(2,8,10,2,road);rect(3,6,8,2,road);
            rect(4,4,6,2,'#444444');rect(5,2,4,2,fade);
            vLine(7,2,11,line);vLine(6,4,9,line);
            px(7,1,ghost);px(6,2,ghost);px(8,2,ghost);px(7,3,ghost);
        } else if (id === 'irreplaceable') {
            const crown='#ccaa44',gem='#cc4444',gold='#eedd66',dark='#886622';
            rect(3,7,8,3,crown);rect(2,10,10,1,dark);
            px(3,5,crown);px(4,4,gold);px(5,6,crown);
            px(7,3,gold);px(8,4,gold);px(10,5,crown);px(9,6,crown);
            px(6,7,gem);px(7,7,gem);px(6,8,'#ff5555');px(7,8,'#ff5555');px(4,7,gold);
        }
        // ═══ CUBE VARIANT MARKS ═══
        else if (id === 'phased_stride') {
            const phase='#8855aa',glow='#aa77cc',ghost='#6633aa',bright='#cc99ee';
            rect(4,3,3,8,phase);rect(7,3,3,8,ghost);
            rect(2,4,2,1,glow);rect(10,5,2,1,glow);rect(1,7,3,1,bright);rect(10,8,3,1,bright);
            rect(3,11,4,1,phase);rect(7,11,4,1,ghost);
            px(1,3,ghost);px(12,4,ghost);px(2,10,glow);px(11,10,glow);
        } else if (id === 'signal_hands') {
            const hand='#8855aa',spark='#cc99ee',bolt='#ffbbff',dark='#553377';
            rect(2,5,4,5,hand);rect(8,5,4,5,hand);
            px(2,4,hand);px(4,4,hand);px(8,4,hand);px(10,4,hand);
            px(6,5,bolt);px(7,6,spark);px(6,7,bolt);px(7,8,spark);
            px(5,3,spark);px(9,3,spark);px(1,4,spark);px(12,4,spark);px(6,9,bolt);px(7,4,bolt);
        } else if (id === 'the_other_sight') {
            const skin='#887766',eye='#aa66cc',pupil='#220033',glow='#cc88ee';
            rect(3,6,8,6,skin);rect(4,5,6,1,skin);
            rect(4,2,6,3,eye);rect(5,1,4,1,glow);rect(5,5,4,1,eye);
            vLine(6,2,3,pupil);vLine(7,2,3,pupil);
            px(3,3,glow);px(10,3,glow);px(7,0,glow);
        } else if (id === 'the_following') {
            const shadow='#442255',glow='#6633aa',bright='#8855cc',body='#553366';
            rect(5,2,4,3,shadow);rect(4,5,6,5,body);rect(5,10,4,2,shadow);
            rect(6,1,2,2,glow);px(6,3,bright);px(7,3,bright);
            px(3,6,shadow);px(2,7,glow);px(10,6,shadow);px(11,7,glow);
            px(5,12,'#221133');px(8,12,'#221133');
        } else if (id === 'cube_metabolized') {
            const cube='#7744aa',pulse='#44cc66',glow='#aa77dd',dark='#442266';
            rect(4,3,4,4,cube);rect(5,2,2,1,glow);rect(3,4,1,2,dark);
            px(1,7,pulse);px(2,7,pulse);px(3,6,pulse);px(4,5,pulse);
            px(5,7,pulse);px(6,6,pulse);px(7,4,pulse);px(8,6,pulse);
            px(9,7,pulse);px(10,7,pulse);px(11,7,pulse);px(12,8,pulse);
            px(5,5,glow);px(6,5,glow);
        } else if (id === 'resonant_break') {
            const fork='#8855aa',shard='#aa77cc',burst='#cc99ee',dark='#553377';
            vLine(4,2,4,fork);px(3,6,fork);px(2,7,shard);
            vLine(9,2,4,fork);px(10,6,fork);px(11,7,shard);
            rect(5,5,4,3,burst);px(6,4,burst);px(7,4,burst);
            rect(6,8,2,4,fork);px(3,3,shard);px(10,3,shard);px(1,5,dark);px(12,5,dark);
        } else if (id === 'ballast') {
            const anchor='#7744aa',chain='#553377',glow='#aa88dd',bright='#cc99ee';
            rect(5,1,4,2,anchor);px(5,2,chain);px(8,2,chain);rect(6,0,2,1,glow);
            vLine(6,3,7,anchor);vLine(7,3,7,anchor);
            px(4,9,anchor);px(3,10,glow);px(9,9,anchor);px(10,10,glow);
            px(4,10,anchor);px(9,10,anchor);rect(4,6,6,1,anchor);
            px(2,8,bright);px(11,8,bright);px(5,11,chain);px(8,11,chain);
        } else if (id === 'claimed') {
            const cube='#6633aa',chain='#aa88dd',link='#8855bb',dark='#331166';
            rect(4,4,6,6,cube);rect(5,3,4,1,'#7744bb');
            rect(3,5,1,4,dark);rect(10,5,1,4,dark);
            px(3,4,chain);px(4,3,chain);px(10,4,chain);px(9,3,chain);
            px(3,9,chain);px(4,10,chain);px(10,9,chain);px(9,10,chain);
            px(2,5,link);px(11,5,link);px(2,8,link);px(11,8,link);
            px(6,6,'#aa88ee');px(7,6,'#aa88ee');px(6,7,'#9977dd');px(7,7,'#9977dd');
        }

        SurvivorGenerator._registerTex(scene, key, c);
        return key;
    },

    // ══════════════════════════════════════
    // SURVIVOR ACHIEVEMENTS (per-survivor, 9 assigned on creation)
    // ══════════════════════════════════════
    SURVIVOR_ACHIEVEMENTS: [
        // ── COMBAT (skull/sword icons) ──
        { id: 'sa_first_blood',    name: 'First Blood',      desc: 'Kill your first enemy',             stat: 'kills',           target: 1,    icon: 'skull',   color: '#cc4444', reward: { xp: 15 } },
        { id: 'sa_slayer_10',      name: 'Blooded',           desc: 'Kill 10 enemies',                   stat: 'kills',           target: 10,   icon: 'skull',   color: '#dd5555', reward: { xp: 30, bits: 50 } },
        { id: 'sa_slayer_50',      name: 'Carnage',           desc: 'Kill 50 enemies',                   stat: 'kills',           target: 50,   icon: 'skull',   color: '#ee3333', reward: { xp: 60, bits: 150 } },
        { id: 'sa_slayer_100',     name: 'Century',           desc: 'Kill 100 enemies',                  stat: 'kills',           target: 100,  icon: 'skull',   color: '#ff2222', reward: { xp: 120, bits: 300, materials: 100 } },
        { id: 'sa_boss_slayer',    name: 'Giant Slayer',      desc: 'Kill your first boss',              stat: 'bossesKilled',    target: 1,    icon: 'crown',   color: '#cc8822', reward: { xp: 50, bits: 200 } },
        { id: 'sa_boss_master',    name: 'Boss Hunter',       desc: 'Kill 5 bosses',                     stat: 'bossesKilled',    target: 5,    icon: 'crown',   color: '#ddaa33', reward: { xp: 100, bits: 500, materials: 200 } },
        { id: 'sa_damage_1k',      name: 'Heavy Hitter',      desc: 'Deal 1000 total damage',            stat: 'damageDealt',     target: 1000, icon: 'sword',   color: '#aa6644', reward: { xp: 40 } },
        { id: 'sa_damage_5k',      name: 'Wrecking Ball',     desc: 'Deal 5000 total damage',            stat: 'damageDealt',     target: 5000, icon: 'sword',   color: '#cc7733', reward: { xp: 80, bits: 200 } },
        { id: 'sa_melee_25',       name: 'Blade Dancer',      desc: 'Kill 25 enemies in melee',          stat: 'meleeKills',      target: 25,   icon: 'sword',   color: '#bb5555', reward: { xp: 50 } },
        { id: 'sa_overkill',       name: 'Overkill',          desc: 'Kill 15 enemies in a single run',   stat: 'bestRunKills',    target: 15,   icon: 'skull',   color: '#ff4444', reward: { xp: 60, bits: 100 } },
        // ── EXPLORATION (boot/compass icons) ──
        { id: 'sa_first_run',      name: 'Pathfinder',        desc: 'Complete your first run',           stat: 'runsCompleted',   target: 1,    icon: 'boot',    color: '#44aa88', reward: { xp: 10 } },
        { id: 'sa_runs_10',        name: 'Road Worn',         desc: 'Complete 10 runs',                  stat: 'runsCompleted',   target: 10,   icon: 'boot',    color: '#55bb77', reward: { xp: 40, bits: 100 } },
        { id: 'sa_runs_25',        name: 'Nomad',             desc: 'Complete 25 runs',                  stat: 'runsCompleted',   target: 25,   icon: 'boot',    color: '#66cc66', reward: { xp: 80, materials: 100 } },
        { id: 'sa_runs_50',        name: 'Road Legend',        desc: 'Complete 50 runs',                  stat: 'runsCompleted',   target: 50,   icon: 'boot',    color: '#77dd55', reward: { xp: 150, bits: 500, materials: 200 } },
        { id: 'sa_explore_10',     name: 'Scavenger',         desc: 'Explore 10 buildings',              stat: 'buildingsExplored', target: 10, icon: 'compass', color: '#4488aa', reward: { xp: 25 } },
        { id: 'sa_explore_30',     name: 'Cartographer',      desc: 'Explore 30 buildings',              stat: 'buildingsExplored', target: 30, icon: 'compass', color: '#55aacc', reward: { xp: 60, bits: 150 } },
        { id: 'sa_depth_3',        name: 'Deep Diver',        desc: 'Reach map depth 3',                 stat: 'highestReach',    target: 3,    icon: 'compass', color: '#3388bb', reward: { xp: 40 } },
        { id: 'sa_depth_5',        name: 'Abyss Walker',      desc: 'Reach map depth 5',                 stat: 'highestReach',    target: 5,    icon: 'compass', color: '#2277cc', reward: { xp: 80, bits: 300 } },
        { id: 'sa_distance_5k',    name: 'Wanderer',          desc: 'Travel 5000 distance',              stat: 'distanceTraveled',target: 5000, icon: 'boot',    color: '#88aa55', reward: { xp: 30 } },
        { id: 'sa_distance_15k',   name: 'Drifter',           desc: 'Travel 15000 distance',             stat: 'distanceTraveled',target: 15000,icon: 'boot',    color: '#aacc44', reward: { xp: 70, materials: 80 } },
        // ── SURVIVAL (shield/heart icons) ──
        { id: 'sa_survive_first',  name: 'Still Standing',    desc: 'Survive your first run',            stat: 'runsCompleted',   target: 1,    icon: 'shield',  color: '#4488cc', reward: { xp: 10 } },
        { id: 'sa_tank_1k',        name: 'Thick Skin',        desc: 'Take 1000 total damage',            stat: 'damageTaken',     target: 1000, icon: 'shield',  color: '#5599bb', reward: { xp: 40 } },
        { id: 'sa_tank_5k',        name: 'Bulletproof',       desc: 'Take 5000 total damage',            stat: 'damageTaken',     target: 5000, icon: 'shield',  color: '#6688aa', reward: { xp: 80, bits: 200 } },
        { id: 'sa_no_damage',      name: 'Untouchable',       desc: 'Complete a run taking 0 damage',    stat: 'zeroDamageRuns',  target: 1,    icon: 'shield',  color: '#ffffff', reward: { xp: 100, bits: 300 } },
        { id: 'sa_close_call',     name: 'By a Thread',       desc: 'Finish a run with under 10% HP',   stat: 'closeCallRuns',   target: 1,    icon: 'heart',   color: '#ee4455', reward: { xp: 40 } },
        { id: 'sa_heal_10',        name: 'Field Medic',       desc: 'Heal 10 times',                     stat: 'timesHealed',     target: 10,   icon: 'heart',   color: '#44cc77', reward: { xp: 25 } },
        { id: 'sa_heal_50',        name: 'Mender',            desc: 'Heal 50 times',                     stat: 'timesHealed',     target: 50,   icon: 'heart',   color: '#55dd66', reward: { xp: 60, materials: 50 } },
        { id: 'sa_recover_injury', name: 'Resilient',         desc: 'Recover from an injury',            stat: 'injuriesRecovered', target: 1,  icon: 'heart',   color: '#ddaa44', reward: { xp: 30 } },
        { id: 'sa_deathless_5',    name: 'Deathless',         desc: 'Complete 5 runs without dying',     stat: 'consecutiveRuns', target: 5,    icon: 'shield',  color: '#aaddff', reward: { xp: 80, bits: 300 } },
        { id: 'sa_endure_time',    name: 'Endurance',         desc: 'Survive for 30 minutes total',      stat: 'timeSurvived',    target: 1800000, icon: 'shield', color: '#99bbdd', reward: { xp: 50 } },
        // ── COLLECTION (gem/chest icons) ──
        { id: 'sa_loot_20',        name: 'Scrap Picker',      desc: 'Loot 20 items',                     stat: 'itemsLooted',     target: 20,   icon: 'gem',     color: '#44ccaa', reward: { xp: 20 } },
        { id: 'sa_loot_100',       name: 'Hoarder',           desc: 'Loot 100 items',                    stat: 'itemsLooted',     target: 100,  icon: 'gem',     color: '#55ddbb', reward: { xp: 60, bits: 200 } },
        { id: 'sa_bits_500',       name: 'Penny Pincher',     desc: 'Accumulate 500 bits',               stat: 'bitsEarned',      target: 500,  icon: 'chest',   color: '#ccaa33', reward: { xp: 30 } },
        { id: 'sa_bits_2k',        name: 'Fortune',           desc: 'Accumulate 2000 bits',              stat: 'bitsEarned',      target: 2000, icon: 'chest',   color: '#ddbb22', reward: { xp: 70, bits: 500 } },
        { id: 'sa_mats_200',       name: 'Stockpiler',        desc: 'Gather 200 materials',              stat: 'materialsEarned', target: 200,  icon: 'chest',   color: '#88aacc', reward: { xp: 30, materials: 50 } },
        { id: 'sa_mats_1k',        name: 'Supply Line',       desc: 'Gather 1000 materials',             stat: 'materialsEarned', target: 1000, icon: 'chest',   color: '#99bbdd', reward: { xp: 80, materials: 150 } },
        { id: 'sa_cube_find',      name: 'Cube Seeker',       desc: 'Find an Encrypted Cube',            stat: 'cubesFound',      target: 1,    icon: 'gem',     color: '#aa66ff', reward: { xp: 50 } },
        { id: 'sa_cube_5',         name: 'Cube Adept',        desc: 'Find 5 Encrypted Cubes',            stat: 'cubesFound',      target: 5,    icon: 'gem',     color: '#bb77ff', reward: { xp: 100, bits: 300 } },
        { id: 'sa_rare_find',      name: 'Treasure Hunter',   desc: 'Find a Rare-tier item or better',   stat: 'rareFinds',       target: 1,    icon: 'gem',     color: '#4488cc', reward: { xp: 30 } },
        { id: 'sa_equip_full',     name: 'Fully Loaded',      desc: 'Fill all equipment slots',           stat: 'fullLoadouts',    target: 1,    icon: 'chest',   color: '#aabb66', reward: { xp: 40, bits: 100 } },
        // ── PROGRESSION (star/arrow icons) ──
        { id: 'sa_rank_2',         name: 'Promoted',          desc: 'Reach rank 2',                      stat: 'rankReached',     target: 2,    icon: 'star',    color: '#bbaa55', reward: { xp: 20 } },
        { id: 'sa_rank_4',         name: 'Officer',           desc: 'Reach rank 4',                      stat: 'rankReached',     target: 4,    icon: 'star',    color: '#ccbb44', reward: { xp: 60, bits: 200 } },
        { id: 'sa_rank_6',         name: 'Elite',             desc: 'Reach rank 6',                      stat: 'rankReached',     target: 6,    icon: 'star',    color: '#ddcc33', reward: { xp: 120, bits: 500, materials: 200 } },
        { id: 'sa_xp_200',         name: 'Quick Study',       desc: 'Earn 200 XP',                       stat: 'xp',             target: 200,  icon: 'arrow',   color: '#88cc44', reward: { bits: 50 } },
        { id: 'sa_xp_1k',          name: 'Veteran',           desc: 'Earn 1000 XP',                      stat: 'xp',             target: 1000, icon: 'arrow',   color: '#99dd33', reward: { bits: 200, materials: 100 } },
        { id: 'sa_xp_3k',          name: 'Ascendant',         desc: 'Earn 3000 XP',                      stat: 'xp',             target: 3000, icon: 'arrow',   color: '#aaee22', reward: { bits: 500, materials: 300 } },
        { id: 'sa_mark_first',     name: 'Marked',            desc: 'Earn your first mark',              stat: 'marksEarned',     target: 1,    icon: 'star',    color: '#aa88cc', reward: { xp: 20 } },
        { id: 'sa_mark_4',         name: 'Branded',           desc: 'Have 4 or more marks',              stat: 'marksEarned',     target: 4,    icon: 'star',    color: '#bb99dd', reward: { xp: 50, bits: 150 } },
        { id: 'sa_gym_use',        name: 'Gym Rat',           desc: 'Complete a gym training',           stat: 'gymSessions',     target: 1,    icon: 'arrow',   color: '#cc5555', reward: { xp: 15 } },
        { id: 'sa_reforge',        name: 'Forge Master',      desc: 'Reforge a weapon',                  stat: 'reforges',        target: 1,    icon: 'star',    color: '#cc8844', reward: { xp: 25, bits: 50 } },
    ],

    // Get achievement def by id
    getAchievementDef(id) {
        return this.SURVIVOR_ACHIEVEMENTS.find(a => a.id === id) || null;
    },

    // Assign 9 random achievements to a survivor
    assignAchievements(seed) {
        const pool = [...this.SURVIVOR_ACHIEVEMENTS];
        const assigned = [];
        let s = seed || Date.now();
        const rng = () => { s = (s * 16807 + 11) % 2147483647; return (s & 0x7fffffff) / 0x7fffffff; };
        while (assigned.length < 9 && pool.length > 0) {
            const idx = Math.floor(rng() * pool.length);
            const ach = pool.splice(idx, 1)[0];
            assigned.push({ id: ach.id, complete: false, progress: 0 });
        }
        return assigned;
    },

    // Check all achievements for a survivor, complete any that are done
    checkSurvivorAchievements(surv, saveData) {
        if (!surv.achievements) return [];
        const completed = [];
        surv.achievements.forEach(ach => {
            if (ach.complete) return;
            const def = this.getAchievementDef(ach.id);
            if (!def) return;
            // Resolve stat value
            let val = 0;
            if (def.stat === 'xp') val = surv.xp || 0;
            else if (def.stat === 'rankReached') val = this.getRank(surv).level;
            else if (def.stat === 'marksEarned') val = (surv.marks || []).length;
            else val = surv[def.stat] || 0;
            ach.progress = Math.min(val, def.target);
            if (val >= def.target) {
                ach.complete = true;
                ach.completedAt = Date.now();
                completed.push(def);
                // Apply rewards
                if (def.reward) {
                    if (def.reward.xp) this.addXP(surv, def.reward.xp);
                    if (saveData && saveData.stash) {
                        if (def.reward.bits) saveData.stash.bits = (saveData.stash.bits || 0) + def.reward.bits;
                        if (def.reward.materials) saveData.stash.materials = (saveData.stash.materials || 0) + def.reward.materials;
                    }
                }
            }
        });
        // Check mastery unlock whenever achievements complete
        if (completed.length > 0) {
            this.checkMasteryUnlock(surv);
        }
        return completed;
    },

    // Generate 16×16 achievement icon sprite
    generateAchievementIcon(scene, achId) {
        const key = `ach_icon_${achId}`;
        if (SurvivorGenerator._texExists(scene, key)) return key;
        const def = this.getAchievementDef(achId);
        if (!def) return key;
        const s = 16;
        const c = document.createElement('canvas'); c.width = s; c.height = s;
        const x = c.getContext('2d');
        const px = (ax,ay,col) => { x.fillStyle = col; x.fillRect(ax,ay,1,1); };
        const rect = (ax,ay,w,h,col) => { x.fillStyle = col; x.fillRect(ax,ay,w,h); };
        // Parse color for variations
        const col = def.color;
        const _hex = col.replace('#','');
        const r = parseInt(_hex.substring(0,2),16), g = parseInt(_hex.substring(2,4),16), b = parseInt(_hex.substring(4,6),16);
        const hi = `rgb(${Math.min(255,r+60)},${Math.min(255,g+60)},${Math.min(255,b+60)})`;
        const lo = `rgb(${Math.max(0,r-60)},${Math.max(0,g-60)},${Math.max(0,b-60)})`;
        const mid = col;

        if (def.icon === 'skull') {
            rect(5,2,6,1,mid); rect(4,3,8,5,mid); rect(5,8,6,2,mid); rect(6,10,4,2,mid);
            rect(5,3,2,2,lo); rect(9,3,2,2,lo); // eyes
            px(6,4,hi); px(10,4,hi); // eye glint
            rect(6,7,1,1,lo); rect(7,7,2,1,lo); rect(9,7,1,1,lo); // nose+teeth
            px(5,2,hi); px(6,2,hi); rect(4,4,1,2,lo); rect(11,4,1,2,lo);
        } else if (def.icon === 'crown') {
            rect(3,8,10,3,mid); rect(3,11,10,2,lo);
            px(3,5,mid); px(5,3,mid); px(8,2,hi); px(10,3,mid); px(12,5,mid);
            rect(3,6,1,2,mid); rect(5,4,1,4,mid); rect(8,3,1,5,mid); rect(10,4,1,4,mid); rect(12,6,1,2,mid);
            rect(4,7,8,1,mid);
            px(8,3,hi); px(5,4,hi); px(3,6,hi); px(10,4,hi); px(12,6,hi);
            rect(4,9,8,1,hi);
        } else if (def.icon === 'sword') {
            rect(7,1,2,8,mid); rect(6,2,1,6,lo); rect(9,2,1,6,lo);
            px(7,1,hi); px(8,1,hi);
            rect(4,9,8,1,lo); rect(5,10,6,1,mid); // crossguard
            rect(7,11,2,3,lo); px(7,14,mid); px(8,14,mid); // grip
            px(6,9,hi); rect(7,3,1,3,hi);
        } else if (def.icon === 'boot') {
            rect(5,2,4,8,mid); rect(4,3,1,6,lo); rect(9,3,1,7,mid);
            rect(5,10,6,2,mid); rect(4,12,8,2,lo);
            rect(10,8,2,4,mid); rect(11,10,1,2,lo);
            px(5,2,hi); px(6,2,hi); rect(5,4,2,2,hi);
            rect(4,13,8,1,lo);
        } else if (def.icon === 'compass') {
            rect(4,2,8,1,lo); rect(3,3,10,10,mid); rect(4,13,8,1,lo);
            rect(3,3,1,10,lo); rect(12,3,1,10,lo);
            // face
            rect(5,4,6,8,lo);
            px(8,5,hi); rect(7,6,2,2,mid); // N needle
            px(7,10,mid); rect(7,8,2,2,lo); // S needle
            px(5,8,mid); px(10,8,mid); // E/W
            px(8,5,'#ff4444'); px(7,6,'#dd3333'); // red north
        } else if (def.icon === 'shield') {
            rect(4,2,8,1,mid); rect(3,3,10,6,mid); rect(4,9,8,2,mid);
            rect(5,11,6,1,mid); rect(6,12,4,1,lo); px(7,13,lo);
            rect(3,3,1,6,lo); rect(12,3,1,6,lo);
            rect(5,4,6,4,lo); // inner field
            rect(6,5,4,2,hi); // emblem
            px(4,2,hi); px(11,2,hi);
        } else if (def.icon === 'heart') {
            px(4,3,mid); px(5,2,mid); px(6,2,mid); px(7,3,lo);
            px(8,3,lo); px(9,2,mid); px(10,2,mid); px(11,3,mid);
            rect(3,4,5,3,mid); rect(8,4,5,3,mid);
            rect(4,7,8,2,mid); rect(5,9,6,1,mid); rect(6,10,4,1,lo);
            px(7,11,lo); px(8,11,lo);
            px(4,4,hi); px(5,3,hi); px(5,4,hi);
        } else if (def.icon === 'gem') {
            rect(5,2,6,1,hi); rect(4,3,8,2,mid); rect(3,5,10,3,mid);
            rect(4,8,8,2,mid); rect(5,10,6,2,lo); rect(6,12,4,1,lo);
            px(7,13,lo);
            px(5,3,hi); px(6,3,hi); rect(4,5,2,2,hi);
            rect(9,5,2,2,lo); px(8,8,lo);
        } else if (def.icon === 'chest') {
            rect(3,5,10,7,mid); rect(3,4,10,1,hi);
            rect(3,5,1,7,lo); rect(12,5,1,7,lo); rect(3,11,10,1,lo);
            rect(3,7,10,1,lo); // lid line
            rect(7,6,2,3,hi); px(7,8,lo); px(8,8,lo); // latch
            rect(4,9,8,1,lo); // shadow
            px(4,5,hi); px(5,5,hi);
        } else if (def.icon === 'star') {
            px(7,1,hi); px(8,1,hi);
            rect(7,2,2,2,mid); rect(6,4,4,1,mid);
            rect(3,5,10,2,mid); rect(4,7,8,1,mid);
            rect(5,8,2,2,lo); rect(9,8,2,2,lo);
            px(5,10,lo); px(10,10,lo);
            px(7,1,hi); px(4,5,hi); px(11,5,hi);
            rect(7,4,2,1,hi);
        } else if (def.icon === 'arrow') {
            rect(7,2,2,10,mid); rect(6,3,1,8,lo); rect(9,3,1,8,lo);
            rect(5,3,1,2,mid); rect(10,3,1,2,mid);
            rect(4,4,1,1,mid); rect(11,4,1,1,mid);
            px(3,5,lo); px(12,5,lo);
            px(7,2,hi); px(8,2,hi); px(7,3,hi);
            rect(7,12,2,2,lo);
        }

        SurvivorGenerator._registerTex(scene, key, c);
        return key;
    },
    RANKS: [
        { level: 1, label: 'Stray',     xpNeeded: 0,    bonus: null, shedAllowed: false, shedType: null },
        { level: 2, label: 'Drifter',   xpNeeded: 100,  bonus: { statMultiplier: 1.03 }, shedAllowed: false, shedType: null },
        { level: 3, label: 'Scarred',   xpNeeded: 300,  bonus: { statMultiplier: 1.05 }, shedAllowed: true, shedType: 'born_negative' },
        { level: 4, label: 'Hardened',  xpNeeded: 700,  bonus: { statMultiplier: 1.08, damageResist: 0.03 }, shedAllowed: true, shedType: 'earned_negative' },
        { level: 5, label: 'Branded',   xpNeeded: 1500, bonus: { statMultiplier: 1.10, damageResist: 0.05 }, shedAllowed: true, shedType: 'any_non_cube' },
        { level: 6, label: 'Warden',    xpNeeded: 3000, bonus: { statMultiplier: 1.12, damageResist: 0.06, convoyPassive: true }, shedAllowed: false, shedType: null },
        { level: 7, label: 'Vestige',   xpNeeded: 6000, bonus: { statMultiplier: 1.15, damageResist: 0.08, convoyPassive: true, auraUnlocked: true }, shedAllowed: false, shedType: null }
    ],

    // ── GENERATION ──

    generate(seed, rarity = null) {
        const rng = this._seededRNG(seed);
        const r = () => rng();
        const pick = (arr) => arr[Math.floor(r() * arr.length)];
        const ri = (a, b) => Math.floor(r() * (b - a + 1)) + a;

        // Rarity
        if (!rarity) {
            const roll = r() * 100;
            let cum = 0;
            for (const [key, val] of Object.entries(this.RARITIES)) {
                cum += val.weight;
                if (roll < cum) { rarity = key; break; }
            }
        }
        const rarityDef = this.RARITIES[rarity];
        const isLegendary = rarity === 'legendary';

        // Name — rarer survivors get more unique names, legendary = mononym
        const namePool = rarity === 'legendary' ? this.NAMES_LEGENDARY
            : rarity === 'master' ? this.NAMES_MASTER
            : rarity === 'rare' ? this.NAMES_RARE
            : rarity === 'uncommon' ? this.NAMES_UNCOMMON
            : this.NAMES_COMMON;
        const name = pick(namePool);

        // Gender
        const gRoll = r() * 100;
        let gCum = 0, gender = 'male';
        for (const g of this.GENDERS) {
            gCum += g.weight;
            if (gRoll < gCum) { gender = g.id; break; }
        }
        // Unknown gender types
        const unknownType = gender === 'unknown' ? pick(['robotic','infected','masked','augmented']) : null;

        // Appearance
        const skin = pick(this.SKIN_TONES);
        const hairStyle = pick(this.HAIR_STYLES);
        const hairColor = pick(this.HAIR_COLORS);
        const eyeColor = pick(this.EYE_COLORS);
        const clothesColor = isLegendary ? pick(this.LEGENDARY_OUTFIT_COLORS) : { primary: pick(this.CLOTHES_COLORS), accent: pick(this.CLOTHES_COLORS) };

        // Personality
        let personality;
        if (unknownType === 'robotic') {
            personality = this.PERSONALITIES.find(p => p.id === 'mechanical');
        } else if (unknownType === 'infected') {
            personality = this.PERSONALITIES.find(p => p.id === 'infected');
        } else {
            personality = pick(this.PERSONALITIES.filter(p => p.id !== 'mechanical' && p.id !== 'infected'));
        }

        // ── Born Marks ──
        // Rarity rules: common=0, uncommon=1 mundane, rare=2 (mundane+mundane/strange),
        // master=3 (strange primary, mundane allowed), legendary=4 (all tiers incl legendary)
        const marks = [];
        const usedMarkIds = new Set();
        const markCount = rarityDef.marks;
        
        const mundanePool = Object.entries(this.MARKS_BORN).filter(([,v]) => v.tier === 'mundane');
        const strangePool = Object.entries(this.MARKS_BORN).filter(([,v]) => v.tier === 'strange');
        const legendaryPool = Object.entries(this.MARKS_BORN).filter(([,v]) => v.tier === 'legendary');
        
        const pickUnique = (pool) => {
            const available = pool.filter(([id]) => !usedMarkIds.has(id));
            if (available.length === 0) return null;
            const entry = available[Math.floor(r() * available.length)];
            usedMarkIds.add(entry[0]);
            return { id: entry[0], ...entry[1], origin: 'born' };
        };
        
        for (let i = 0; i < markCount; i++) {
            let mark = null;
            if (rarity === 'common') break; // 0 marks
            if (rarity === 'uncommon') {
                mark = pickUnique(mundanePool);
            } else if (rarity === 'rare') {
                if (i === 0) mark = pickUnique(mundanePool);
                else mark = pickUnique(r() < 0.5 ? mundanePool : strangePool) || pickUnique(mundanePool);
            } else if (rarity === 'master') {
                if (i < 2) mark = pickUnique(strangePool) || pickUnique(mundanePool);
                else mark = pickUnique(mundanePool) || pickUnique(strangePool);
            } else if (isLegendary) {
                if (i === 0) mark = pickUnique(legendaryPool) || pickUnique(strangePool);
                else if (i === 1) mark = pickUnique(strangePool) || pickUnique(mundanePool);
                else mark = pickUnique(mundanePool) || pickUnique(strangePool) || pickUnique(legendaryPool);
            }
            if (mark) marks.push(mark);
        }

        // Starting rank by rarity (level number)
        const startRank = rarity === 'legendary' ? 3 : rarity === 'master' ? 2 : 1;

        return {
            id: `surv_${seed}`,
            seed,
            name,
            rarity,
            gender,
            unknownType,
            rank: startRank,
            xp: 0,
            alive: true,
            deployed: false,
            appearance: {
                skin: skin.id,
                skinColor: skin.color,
                hairStyle,
                hairColor: hairColor.id,
                hairColorHex: hairColor.color,
                eyeColor: eyeColor.id,
                eyeColorHex: eyeColor.color,
                clothesPrimary: clothesColor.primary,
                clothesAccent: clothesColor.accent,
                isLegendaryOutfit: isLegendary
            },
            personality: { id: personality.id, label: personality.label },
            achievements: this.assignAchievements(seed),
            marks,
            injury: null,
            anomalyEncounters: 0,
            markFlags: {},
            shedCharges: 0,
            auraUnlocked: false,
            equippedTitle: null,
            equippedAura: 'none',
            unlockedTitles: [],
            unlockedAuras: ['none'],
            runsCompleted: 0,
            runsFailed: 0,
            kills: 0,
            meleeKills: 0,
            bestRunKills: 0,
            bossesKilled: 0,
            damageDealt: 0,
            damageTaken: 0,
            itemsLooted: 0,
            distanceTraveled: 0,
            highestReach: 0,
            timeSurvived: 0,
            bitsEarned: 0,
            materialsEarned: 0,
            cubesFound: 0,
            rareFinds: 0,
            fullLoadouts: 0,
            timesHealed: 0,
            injuriesRecovered: 0,
            zeroDamageRuns: 0,
            closeCallRuns: 0,
            consecutiveRuns: 0,
            buildingsExplored: 0,
            gymSessions: 0,
            reforges: 0,
            recruitedAt: Date.now()
        };
    },

    // Get rank info for a survivor
    getRank(survivor) {
        let rank = this.RANKS[0];
        for (const r of this.RANKS) {
            if (survivor.xp >= r.xpNeeded) rank = r;
        }
        return rank;
    },

    // Get the bonus object for survivor's current rank
    getRankBonus(survivor) {
        const rank = this.getRank(survivor);
        return rank.bonus ? { ...rank.bonus } : {};
    },

    // Get XP needed to reach next rank, or null if at max
    getXPForNextRank(survivor) {
        const current = this.getRank(survivor);
        const next = this.RANKS.find(r => r.level === current.level + 1);
        if (!next) return null;
        return next.xpNeeded - survivor.xp;
    },

    // Add XP to a survivor — returns rank up data or null
    addXP(survivor, amount) {
        if (!survivor.alive) return null;
        const oldRank = this.getRank(survivor);
        survivor.xp += amount;
        const newRank = this.getRank(survivor);
        if (newRank.level > oldRank.level) {
            const result = { ranked: true, oldRank, newRank, shedAwarded: false };
            // Check all crossed rank thresholds for shed charges
            for (let lvl = oldRank.level + 1; lvl <= newRank.level; lvl++) {
                const crossedRank = this.RANKS.find(r => r.level === lvl);
                if (crossedRank && crossedRank.shedAllowed && (survivor.shedCharges || 0) < 3) {
                    survivor.shedCharges = (survivor.shedCharges || 0) + 1;
                    result.shedAwarded = true;
                }
            }
            // Rank 7 aura unlock
            if (newRank.level >= 7 && !survivor.auraUnlocked) {
                this.unlockAura(survivor);
            }
            return result;
        }
        return null;
    },

    // ── SHED SYSTEM ──
    // Shed a mark from a survivor using a shed charge

    // ── CONVOY PASSIVES ──
    // Iterates all alive survivors and merges passive bonuses from rank 6+ survivors
    getConvoyPassives(saveData) {
        const result = { lootBonus: 0, fuelDiscount: 0, recruitQuality: 0 };
        if (!saveData || !saveData.survivors) return result;
        
        for (const s of saveData.survivors) {
            if (!s.alive) continue;
            const rank = this.getRank(s);
            if (rank.level === 6) {
                result.lootBonus += 0.03;
                result.fuelDiscount += 0.02;
                result.recruitQuality += 0.03;
            } else if (rank.level >= 7) {
                result.lootBonus += 0.05;
                result.fuelDiscount += 0.03;
                result.recruitQuality += 0.05;
            }
        }
        return result;
    },

    // ── RANK 7 AURA UNLOCK ──
    // AURA SYSTEM HOOK — assign rank 7 aura here when aura system is implemented
    unlockAura(survivor) {
        if (!survivor) return survivor;
        survivor.auraUnlocked = true;
        // Check if mastery conditions are also met
        this.checkMasteryUnlock(survivor);
        return survivor;
    },

    // ── MASTERY UNLOCK — all 9 achievements complete + rank 7 ──
    // Awards "Lord of Raum" title and "Sovereign Flame" aura
    checkMasteryUnlock(survivor) {
        if (!survivor) return false;
        const rank = this.getRank(survivor);
        if (!rank || rank.level < 7) return false;
        
        const achs = survivor.achievements || [];
        const allComplete = achs.length === 9 && achs.every(a => a.complete);
        if (!allComplete) return false;
        
        // Already unlocked?
        if (!survivor.unlockedTitles) survivor.unlockedTitles = [];
        if (!survivor.unlockedAuras) survivor.unlockedAuras = ['none'];
        
        let newUnlock = false;
        if (!survivor.unlockedTitles.includes('Lord of Raum')) {
            survivor.unlockedTitles.push('Lord of Raum');
            if (!survivor.equippedTitle) survivor.equippedTitle = 'Lord of Raum';
            newUnlock = true;
        }
        if (!survivor.unlockedAuras.includes('lordOfRaum')) {
            survivor.unlockedAuras.push('lordOfRaum');
            if (survivor.equippedAura === 'none') survivor.equippedAura = 'lordOfRaum';
            newUnlock = true;
        }
        return newUnlock;
    },

    // Kill a survivor (permadeath)
    kill(survivor, deathContext) {
        survivor.alive = false;
        survivor.deployed = false;
        survivor.diedAt = Date.now();
        // Death context: what killed them, where, how far they got
        if (deathContext) {
            survivor.deathCause = deathContext.cause || 'unknown';
            survivor.deathBiome = deathContext.biome || null;
            survivor.deathReach = deathContext.reach || 0;
        }
    },

    // ── INJURY SYSTEM ──
    // States: Healthy → Injured → Critical → Dead
    // Recovery: whichever comes first — remaining runs OR elapsed time
    
    INJURY_TYPES: {
        wounded:       { label: 'Wounded',       deployable: true,  treatment: 'medkit',     recoveryRuns: 2, recoveryMs: 20 * 60 * 1000,  effect: 'marks_halved' },
        exhausted:     { label: 'Exhausted',     deployable: true,  treatment: 'ration_pack', recoveryRuns: 1, recoveryMs: 15 * 60 * 1000,  effect: 'hp_75pct' },
        shell_shocked: { label: 'Shell Shocked', deployable: true,  treatment: 'rest',       recoveryRuns: 3, recoveryMs: 30 * 60 * 1000,  effect: 'stat_penalty_5pct' },
        maimed:        { label: 'Maimed',        deployable: false, treatment: 'trauma_kit', recoveryRuns: 4, recoveryMs: 45 * 60 * 1000,  effect: 'undeployable' }
    },
    
    // Apply an injury to a survivor
    applyInjury(survivor, type) {
        if (!survivor || !survivor.alive) return;
        const def = this.INJURY_TYPES[type];
        if (!def) return;
        survivor.injury = {
            type: type,
            since: Date.now(),
            treatedAt: null,
            recoveryRuns: def.recoveryRuns,
            recoveryMs: def.recoveryMs
        };
    },
    
    // Treat an injury with the matching item type

    
    // Check if recovery conditions are met and clear injury
    // Uses global run completion count — any squad member's runs count toward recovery
    checkRecovery(survivor, globalRunsCompleted) {
        if (!survivor || !survivor.injury) return false;
        const inj = survivor.injury;
        if (!inj.treatedAt) {
            // Untreated — check if time alone clears it (shell_shocked: treatment is rest/time)
            // Only rest-type injuries auto-start recovery clock from injury time
            const def = this.INJURY_TYPES[inj.type];
            if (def && def.treatment === 'rest') {
                const timePassed = Date.now() - inj.since;
                if (timePassed >= inj.recoveryMs) {
                    survivor.injuriesRecovered = (survivor.injuriesRecovered || 0) + 1;
                    survivor.injury = null;
                    return true;
                }
            }
            return false;
        }
        
        const timePassed = Date.now() - inj.treatedAt;
        const runsSinceTreatment = (globalRunsCompleted || 0) - (inj.runsAtTreatment || 0);
        const runsCleared = runsSinceTreatment >= inj.recoveryRuns;
        const timeCleared = timePassed >= inj.recoveryMs;
        
        if (runsCleared || timeCleared) {
            // Maimed recovery awards an earned mark before clearing
            if (inj.type === 'maimed') {
                this.awardEarnedMark(survivor, 'permanent_injury', { injuryType: inj.type });
            }
            survivor.injuriesRecovered = (survivor.injuriesRecovered || 0) + 1;
            survivor.injury = null;
            return true;
        }
        return false;
    },
    
    // Check if a survivor can be deployed
    isDeployable(survivor) {
        if (!survivor || !survivor.alive) return false;
        if (survivor.injury) {
            const def = this.INJURY_TYPES[survivor.injury.type];
            if (def && !def.deployable) return false;
        }
        return true;
    },
    
    // Get penalties object for run initialization
    // Returns { statMultiplier, hpMultiplier, marksActive } 
    getInjuryPenalties(survivor) {
        const penalties = { statMultiplier: 1.0, hpMultiplier: 1.0, marksActive: true };
        if (!survivor || !survivor.injury) return penalties;
        const type = survivor.injury.type;
        if (type === 'wounded') {
            penalties.marksActive = false; // marks effectiveness halved (consumer decides half vs off)
        } else if (type === 'exhausted') {
            penalties.hpMultiplier = 0.75;
        } else if (type === 'shell_shocked') {
            penalties.statMultiplier = 0.95; // 5% penalty across the board
        }
        // maimed survivors can't deploy — isDeployable() catches this upstream
        return penalties;
    },
    
    // ── MARK CAP SYSTEM ──
    // Maximum 8 total per survivor. Maximum 4 Born. Maximum 4 Earned. Cube variants count toward Earned.
    isAtCap(survivor) {
        return (survivor.marks || []).length >= 8;
    },
    isEarnedAtCap(survivor) {
        return (survivor.marks || []).filter(m => m.origin === 'earned').length >= 4;
    },
    _hasMark(survivor, markId) {
        return (survivor.marks || []).some(m => m.id === markId);
    },
    _addMark(survivor, mark) {
        if (!survivor.marks) survivor.marks = [];
        if (this.isAtCap(survivor)) return false;
        if (mark.origin === 'earned' && this.isEarnedAtCap(survivor)) return false;
        if (this._hasMark(survivor, mark.id)) return false;
        survivor.marks.push(mark);
        return true;
    },

    // ── EARNED MARK AWARD LOGIC ──
    awardEarnedMark(survivor, trigger, context = {}) {
        if (!survivor || !survivor.alive) return null;
        if (this.isEarnedAtCap(survivor)) return null;
        
        const pool = this.MARKS_EARNED;
        const cubePool = this.MARKS_CUBE;
        const owned = new Set((survivor.marks || []).map(m => m.id));
        
        // Check for special marks on this survivor
        const hasCubeWitness = owned.has('cube_witness');
        const hasUnmarked = owned.has('unmarked');
        const hasRaumsFavorite = owned.has('raums_favorite');
        
        // Cube variant substitution check
        const _tryCubeVariant = (mark) => {
            if (!hasCubeWitness) return mark;
            if (mark.type !== 'negative' && mark.type !== 'mixed') return mark;
            const cubeChance = 0.20;
            if (Math.random() >= cubeChance) return mark;
            // Find cube variant of this mark
            const variant = Object.entries(cubePool).find(([, v]) => v.cubeVariantOf === mark.id);
            if (!variant || owned.has(variant[0])) return mark;
            return { id: variant[0], ...variant[1], origin: 'earned' };
        };
        
        // Raum's favorite: for negative marks, roll twice take worse
        const _raumCheck = (candidates) => {
            if (!hasRaumsFavorite || candidates.length < 2) return candidates[Math.floor(Math.random() * candidates.length)];
            const a = candidates[Math.floor(Math.random() * candidates.length)];
            const b = candidates[Math.floor(Math.random() * candidates.length)];
            // "Worse" = lower sum of positive effects minus negative effects
            const score = (m) => {
                let s = 0;
                const e = pool[m]?.effects || {};
                for (const [k, v] of Object.entries(e)) {
                    if (k === 'immunities' || k === 'conditionals') continue;
                    s += (typeof v === 'number') ? v : 0;
                }
                return s;
            };
            return score(a) <= score(b) ? a : b;
        };
        
        let markToAward = null;
        
        if (trigger === 'permanent_injury') {
            // Skip if unmarked
            const injuryMarks = Object.keys(pool).filter(k => pool[k].trigger === 'permanent_injury' && !owned.has(k));
            if (hasUnmarked) {
                // Filter out negative-only marks
                const filtered = injuryMarks.filter(k => pool[k].type !== 'negative');
                if (filtered.length === 0) return null;
                const picked = hasRaumsFavorite ? _raumCheck(filtered) : filtered[Math.floor(Math.random() * filtered.length)];
                markToAward = { id: picked, ...pool[picked], origin: 'earned' };
            } else if (injuryMarks.length > 0) {
                const picked = hasRaumsFavorite ? _raumCheck(injuryMarks) : injuryMarks[Math.floor(Math.random() * injuryMarks.length)];
                markToAward = { id: picked, ...pool[picked], origin: 'earned' };
            }
        } else if (trigger === 'near_death_survived') {
            const ndMarks = ['spite', 'threshold', 'haunted_pace'].filter(k => !owned.has(k));
            if (ndMarks.length > 0) {
                const picked = ndMarks[Math.floor(Math.random() * ndMarks.length)];
                markToAward = { id: picked, ...pool[picked], origin: 'earned' };
            }
        } else if (trigger === 'boss_killed') {
            const bossMarkId = this._BOSS_MARK_MAP[context.bossType];
            if (bossMarkId && !owned.has(bossMarkId) && pool[bossMarkId]) {
                markToAward = { id: bossMarkId, ...pool[bossMarkId], origin: 'earned' };
            }
        } else if (trigger === 'foundry_completed') {
            if (owned.has('foundry_lungs') || owned.has('smelters_instinct')) return null;
            if (this.isEarnedAtCap(survivor)) return null;
            // Award both as a pair — check cap allows 2
            const earnedCount = (survivor.marks || []).filter(m => m.origin === 'earned').length;
            if (earnedCount + 2 > 4) return null;
            const m1 = { id: 'foundry_lungs', ...pool.foundry_lungs, origin: 'earned' };
            const m2 = { id: 'smelters_instinct', ...pool.smelters_instinct, origin: 'earned' };
            this._addMark(survivor, _tryCubeVariant(m1));
            this._addMark(survivor, _tryCubeVariant(m2));
            return m1; // Return first as confirmation
        } else if (trigger === 'cube_anomaly_survived') {
            survivor.anomalyEncounters = (survivor.anomalyEncounters || 0) + 1;
            if (survivor.anomalyEncounters >= 3 && !owned.has('static_mind')) {
                markToAward = { id: 'static_mind', ...pool.static_mind, origin: 'earned' };
            }
        } else if (trigger === 'runs_milestone') {
            const milestoneMarkId = this._RUNS_MARK_MAP[context.runs];
            if (milestoneMarkId && !owned.has(milestoneMarkId) && pool[milestoneMarkId]) {
                markToAward = { id: milestoneMarkId, ...pool[milestoneMarkId], origin: 'earned' };
            }
        }
        
        if (!markToAward) return null;
        
        // Apply cube variant substitution
        markToAward = _tryCubeVariant(markToAward);
        
        // Add to survivor
        if (this._addMark(survivor, markToAward)) return markToAward;
        return null;
    },
    
    // ── MARK EFFECTS RESOLVER ──
    // Iterates all marks and returns merged flat effects object
    getMarkEffects(survivor) {
        const result = {
            statMultiplier: 1.0, speedMultiplier: 1.0, hpMultiplier: 1.0,
            damageResist: 0, elementalResist: 0, weaponSpread: 0,
            backpackBonus: 0, fuelCostMultiplier: 1.0, materialsBonus: 0,
            detectionRange: 0, healingEffectiveness: 0, consumableEffectiveness: 0,
            reloadSpeed: 0, aggroRange: 0,
            immunities: [], conditionals: {}
        };
        if (!survivor || !survivor.marks) return result;
        
        const MULTIPLICATIVE = new Set(['statMultiplier', 'speedMultiplier', 'hpMultiplier', 'fuelCostMultiplier']);
        
        for (const mark of survivor.marks) {
            if (!mark.effects) continue;
            for (const [key, val] of Object.entries(mark.effects)) {
                if (key === 'immunities') {
                    // Merge deduplicated
                    if (Array.isArray(val)) {
                        for (const imm of val) {
                            if (!result.immunities.includes(imm)) result.immunities.push(imm);
                        }
                    }
                } else if (key === 'conditionals') {
                    // Merge by key — higher positive, lower negative
                    if (val && typeof val === 'object') {
                        for (const [ck, cv] of Object.entries(val)) {
                            if (typeof cv === 'boolean') {
                                result.conditionals[ck] = cv; // boolean just overwrites
                            } else if (typeof cv === 'number') {
                                if (result.conditionals[ck] === undefined) {
                                    result.conditionals[ck] = cv;
                                } else {
                                    // Higher for positive, lower for negative
                                    result.conditionals[ck] = cv >= 0
                                        ? Math.max(result.conditionals[ck], cv)
                                        : Math.min(result.conditionals[ck], cv);
                                }
                            } else {
                                result.conditionals[ck] = cv;
                            }
                        }
                    }
                } else if (MULTIPLICATIVE.has(key)) {
                    result[key] *= val;
                } else if (typeof val === 'number' && result[key] !== undefined) {
                    result[key] += val;
                }
            }
        }
        return result;
    },
    
    // ── MARK FLAGS RESET ──
    // Call at run deployment to reset per-run mark state
    resetMarkFlags(survivor) {
        if (!survivor) return;
        survivor.markFlags = {
            twiceBornUsed: false,
            theFollowingUsed: false
        };
    },
    
    // ── SAVE MIGRATION ──
    migrateSurvivorData(survivor) {
        if (!survivor) return;
        // Rename perks → vestiges → marks (handles both old formats)
        if (survivor.perks && !survivor.vestiges && !survivor.marks) {
            survivor.marks = survivor.perks.map(p => ({ ...p, origin: p.origin || 'born', tier: p.tier || 'mundane', cubeVariantOf: p.cubeVariantOf || null }));
            delete survivor.perks;
        }
        if (survivor.vestiges && !survivor.marks) {
            survivor.marks = survivor.vestiges.map(v => ({ ...v, origin: v.origin || 'born', tier: v.tier || (v.origin === 'earned' ? 'earned' : 'mundane'), cubeVariantOf: v.cubeVariantOf || null }));
            delete survivor.vestiges;
        }
        // Ensure all marks have required fields
        if (survivor.marks) {
            survivor.marks.forEach(m => {
                if (!m.origin) m.origin = 'born';
                if (!m.tier) m.tier = m.origin === 'earned' ? 'earned' : 'mundane';
                if (m.cubeVariantOf === undefined) m.cubeVariantOf = null;
                if (!m.trigger) m.trigger = null;
                if (!m.effects) m.effects = {};
            });
        } else {
            survivor.marks = [];
        }
        // Ensure injury field exists
        if (survivor.injury === undefined) survivor.injury = null;
        // Ensure anomalyEncounters
        if (survivor.anomalyEncounters === undefined) survivor.anomalyEncounters = 0;
        // Ensure markFlags
        if (!survivor.markFlags) survivor.markFlags = {};
        // Ensure shedCharges
        if (survivor.shedCharges === undefined) survivor.shedCharges = 0;
        // Ensure auraUnlocked
        if (survivor.auraUnlocked === undefined) survivor.auraUnlocked = false;
        // Ensure survivor title/aura fields
        if (survivor.equippedTitle === undefined) survivor.equippedTitle = null;
        if (survivor.equippedAura === undefined) survivor.equippedAura = 'none';
        if (!survivor.unlockedTitles) survivor.unlockedTitles = [];
        if (!survivor.unlockedAuras) survivor.unlockedAuras = ['none'];
    },
    toCustomization(survivor) {
        const app = survivor.appearance;
        const ut = survivor.unknownType;
        const skinMap = { pale: 'light', light: 'light', medium: 'medium', tan: 'tan', brown: 'brown', dark: 'dark' };
        const hairMap = { black: 'black', brown: 'brown', auburn: 'auburn', blonde: 'blond', grey: 'grey', white: 'white', red: 'red' };
        const shirtNearest = (hex) => {
            const shirts = CONFIG.customization.shirtColors;
            let best = shirts[0].id, bestD = Infinity;
            const r1 = (hex >> 16) & 0xff, g1 = (hex >> 8) & 0xff, b1 = hex & 0xff;
            shirts.forEach(s => {
                const c = parseInt(s.base.slice(1), 16);
                const d = Math.abs(r1 - ((c >> 16) & 0xff)) + Math.abs(g1 - ((c >> 8) & 0xff)) + Math.abs(b1 - (c & 0xff));
                if (d < bestD) { bestD = d; best = s.id; }
            });
            return best;
        };
        const pantsNearest = (hex) => {
            const pants = CONFIG.customization.pantsColors;
            let best = pants[0].id, bestD = Infinity;
            const r1 = (hex >> 16) & 0xff, g1 = (hex >> 8) & 0xff, b1 = hex & 0xff;
            pants.forEach(p => {
                const c = parseInt(p.base.slice(1), 16);
                const d = Math.abs(r1 - ((c >> 16) & 0xff)) + Math.abs(g1 - ((c >> 8) & 0xff)) + Math.abs(b1 - (c & 0xff));
                if (d < bestD) { bestD = d; best = p.id; }
            });
            return best;
        };
        const styleMap = {
            shaved: 'buzzed', short: 'short', messy: 'short', mohawk: 'mohawk',
            long: 'long', ponytail: 'long', braids: 'long', bald: 'bald',
            hood: 'short', bandana: 'buzzed'
        };
        
        // Override skin for special types
        let skinId = skinMap[app.skin] || 'light';
        let hairStyleId = styleMap[app.hairStyle] || 'short';
        if (ut === 'robotic') {
            skinId = ['chrome','carbon','rust'][survivor.seed % 3];
            hairStyleId = 'bald'; // robots have no hair
        } else if (ut === 'infected') {
            skinId = 'infected';
        } else if (ut === 'augmented') {
            skinId = 'chrome'; // cybernetic plating
        }
        
        // Gear type overlay for special survivor types
        let gearType = null;
        if (ut === 'robotic') gearType = 'robotic';
        else if (ut === 'infected') gearType = 'infected';
        else if (ut === 'augmented') gearType = 'robotic'; // augmented uses robotic overlay
        
        return {
            skin: skinId,
            hair: hairMap[app.hairColor] || 'brown',
            hairStyle: hairStyleId,
            shirt: ut === 'robotic' ? 'black' : shirtNearest(app.clothesPrimary),
            pants: ut === 'robotic' ? 'black' : pantsNearest(app.clothesAccent),
            gearType: gearType
        };
    },

    // Seeded RNG
    _seededRNG(seed) {
        let s = seed;
        return () => {
            s = (s * 16807 + 0) % 2147483647;
            return (s - 1) / 2147483646;
        };
    }
};

