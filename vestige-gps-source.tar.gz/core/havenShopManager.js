// Vestige GPS — HavenShopManager
// Shop inventory, buy/sell logic

import { CONFIG } from '../data/config.js';
import { ItemManager } from './itemManager.js';

export const HavenShopManager = {
    getRotationId() { return Math.floor(Date.now() / (12 * 60 * 60 * 1000)); },
    getDailyId() { return Math.floor(Date.now() / (24 * 60 * 60 * 1000)); },
    getWeeklyId() { return Math.floor(Date.now() / (7 * 24 * 60 * 60 * 1000)); },
    getMonthlyId() { return Math.floor(Date.now() / (30 * 24 * 60 * 60 * 1000)); },
    timeUntilRotation() { return (12*3600000) - (Date.now() % (12*3600000)); },
    formatTime(ms) {
        const h = Math.floor(ms/3600000), m = Math.floor((ms%3600000)/60000);
        return `${h}h ${m}m`;
    },
    _rng(seed) {
        let s = seed;
        return () => { s = (s * 16807 + 12345) % 2147483647; return (s & 0x7fffffff) / 0x7fffffff; };
    },
    getMedicalShop(reach) {
        const rng = this._rng(this.getRotationId() * 7919 + 101);
        const pool = [
            { id: 'bandage', cost: 15, tier: 1 }, { id: 'bandage_military', cost: 35, tier: 2 },
            { id: 'medkit', cost: 75, tier: 3 }, { id: 'medkit_advanced', cost: 150, tier: 4 },
            { id: 'grenade_frag', cost: 120, tier: 4 },
        ];
        const shuffled = [...pool].sort(() => rng() - 0.5);
        return shuffled.slice(0, 4 + Math.floor(rng() * 3)).map(it => ({
            ...it, revealed: rng() > 0.4, stock: 1 + Math.floor(rng() * 3)
        }));
    },
    getBarterShop(reach) {
        const rng = this._rng(this.getRotationId() * 6271 + 202);
        const items = [];
        const cats = ['weapon', 'melee', 'gear'];
        for (let i = 0; i < 5 + Math.floor(rng() * 3); i++) {
            const cat = cats[Math.floor(rng() * cats.length)];
            let tier = 1 + Math.floor(rng() * 4);
            if (rng() < 0.08) tier = 5;
            const item = ItemManager.generateItem(cat, tier, 0, reach || 1);
            if (item) {
                item._shopCost = Math.round([0,30,80,180,400,800][Math.min(tier,5)] * (0.8 + rng() * 0.4));
                items.push(item);
            }
        }
        return items;
    },
    getFactionShop(factionId, reach) {
        const rng = this._rng(this.getRotationId() * 4733 + ((factionId||'').charCodeAt(0)||0) * 100);
        const items = [];
        for (let i = 0; i < 4; i++) {
            const cat = rng() > 0.5 ? 'weapon' : (rng() > 0.5 ? 'melee' : 'gear');
            const tier = 2 + Math.floor(rng() * 3);
            const item = ItemManager.generateItem(cat, tier, 0, reach || 1);
            if (item && factionId && CONFIG.foundries[factionId]) {
                item.foundry = factionId; item.foundryName = CONFIG.foundries[factionId].name;
            }
            if (item) {
                item._shopCost = Math.round([0,30,80,180,400,800][Math.min(tier,5)] * (0.85 + rng() * 0.3));
                item._repRequired = [0,0,50,150,300][Math.min(tier-1,4)] || 0;
                items.push(item);
            }
        }
        return items;
    },
    getSellPrice(item) {
        if (!item || item.tier === 6) return 0;
        return Math.max(1, Math.round([0,5,15,40,100,200,0][Math.min(item.tier||1,6)] * (0.7 + Math.random() * 0.3)));
    },
    getChallenges(type) {
        const pools = {
            daily: [
                { id:'d_kill10', desc:'Kill 10 enemies in Portal', target:10, stat:'portalKills', reward:50, icon:'⚔' },
                { id:'d_floor5', desc:'Reach Portal Floor 5', target:5, stat:'portalFloor', reward:80, icon:'⛰' },
                { id:'d_loot5', desc:'Loot 5 items in Portal', target:5, stat:'portalLoot', reward:40, icon:'📦' },
                { id:'d_buy1', desc:'Purchase from a shop', target:1, stat:'shopBuy', reward:25, icon:'🛒' },
                { id:'d_sell3', desc:'Sell 3 items at Barter', target:3, stat:'shopSell', reward:35, icon:'💰' },
            ],
            weekly: [
                { id:'w_kill100', desc:'Kill 100 Portal enemies', target:100, stat:'portalKills', reward:300, icon:'💀' },
                { id:'w_floor25', desc:'Reach Portal Floor 25', target:25, stat:'portalFloor', reward:500, icon:'🗼' },
                { id:'w_boss5', desc:'Defeat 5 Portal bosses', target:5, stat:'portalBosses', reward:400, icon:'👑' },
            ],
            monthly: [
                { id:'m_floor50', desc:'Reach Portal Floor 50', target:50, stat:'portalFloor', reward:2000, icon:'⭐' },
                { id:'m_kill500', desc:'Kill 500 Portal enemies', target:500, stat:'portalKills', reward:1500, icon:'🔥' },
            ]
        };
        const id = type==='daily' ? this.getDailyId() : type==='weekly' ? this.getWeeklyId() : this.getMonthlyId();
        const rng = this._rng(id * 3571 + (type==='daily'?1:type==='weekly'?2:3));
        const p = pools[type] || pools.daily;
        const shuffled = [...p].sort(() => rng() - 0.5);
        return shuffled.slice(0, type==='daily'?3:type==='weekly'?2:1).map(c => ({ ...c, progress:0, claimed:false }));
    },
    factions: {
        sworn:     { name:'The Sworn',   icon:'[S]', color:'#4a6a3a', motto:'What was taken will be reclaimed.' },
        terracorp: { name:'Terracorp',    icon:'[T]', color:'#8a2a2a', motto:'Through structure, survival.' },
        deralict:  { name:'Deralict',     icon:'[D]', color:'#cc6622', motto:'Dig deeper.' },
        cephalon:  { name:'Cephalon',     icon:'[C]', color:'#33aaaa', motto:'The signal is the way.' },
        blackreach:{ name:'Blackreach',   icon:'[B]', color:'#aa8833', motto:'Beyond the veil, we endure.' },
    },
    ranks: [ {name:'Outsider',rep:0}, {name:'Known',rep:50}, {name:'Trusted',rep:150}, {name:'Honored',rep:350}, {name:'Champion',rep:600} ],
    getRank(rep) { let r = this.ranks[0]; for (const rk of this.ranks) { if (rep >= rk.rep) r = rk; } return r; }
};

// ==================== HAVEN SCENE ====================
// Safe Haven — rest stop between acts with vendors and services

// ==================== HAVEN SCENE v2 ====================
// Rebuilt: single bottom gate, horizontal road + T-intersection,
// square roundabout w/ 8 parking spots, interior wall + archway

