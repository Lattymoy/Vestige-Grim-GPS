// Vestige GPS — WeatherSystem
// Real weather API → biome effects mapping
// Pure logic: fetch, parse, map conditions to effect configs
// Rendering moved to client/rendering/weatherRenderer.js

import { CONFIG } from '../data/config.js';

export const WeatherSystem = {
    _cache: null,
    _cacheTime: 0,
    _renderer: null,
    CACHE_DURATION: 30 * 60 * 1000, // 30 minutes
    
    init(renderer) {
        this._renderer = renderer;
    },
    
    // Bridge to renderer
    render(scene, effectConfig, biomeId) {
        if (this._renderer) return this._renderer.render(scene, effectConfig, biomeId);
        return () => {}; // noop cleanup
    },

    // Weather condition mapping: real → biome effect
    // wttr.in codes: https://github.com/chubin/wttr.in/blob/master/lib/constants.py
    _biomeMap: {
        grassy: {
            clear: 'clear', sunny: 'clear', partly_cloudy: 'haze',
            cloudy: 'overcast', fog: 'fog', mist: 'fog',
            rain: 'rain', drizzle: 'rain_light', heavy_rain: 'rain_heavy',
            thunderstorm: 'storm', snow: 'frost', sleet: 'frost',
            wind: 'wind', dust: 'haze'
        },
        barren: {
            clear: 'clear', sunny: 'heat_shimmer', partly_cloudy: 'haze',
            cloudy: 'dust_haze', fog: 'sandstorm_light', mist: 'dust_haze',
            rain: 'dust_rain', drizzle: 'dust_mist', heavy_rain: 'mudstorm',
            thunderstorm: 'dust_storm', snow: 'salt_wind', sleet: 'salt_wind',
            wind: 'sandstorm', dust: 'sandstorm'
        },
        apocalyptic: {
            clear: 'clear', sunny: 'pale_glow', partly_cloudy: 'spore_drift',
            cloudy: 'ashfall_light', fog: 'miasma', mist: 'spore_drift',
            rain: 'ashfall', drizzle: 'ashfall_light', heavy_rain: 'ashfall_heavy',
            thunderstorm: 'anomaly_storm', snow: 'crystalline_fall', sleet: 'crystalline_fall',
            wind: 'void_wind', dust: 'spore_drift'
        }
    },

    // Particle configs per weather effect — data only, no rendering
    _effects: {
        clear:           { particles: null, overlay: null, sound: null },
        haze:            { particles: null, overlay: { color: 0xccccaa, alpha: 0.06 }, sound: null },
        overcast:        { particles: null, overlay: { color: 0x888899, alpha: 0.1 }, sound: null },
        fog:             { particles: null, overlay: { color: 0xaaaaaa, alpha: 0.18 }, sound: null },
        rain_light:      { particles: { type: 'rain', count: 15, speed: 3, color: 0x6688aa }, overlay: { color: 0x556677, alpha: 0.08 }, sound: 'rain' },
        rain:            { particles: { type: 'rain', count: 30, speed: 5, color: 0x5577aa }, overlay: { color: 0x445566, alpha: 0.12 }, sound: 'rain' },
        rain_heavy:      { particles: { type: 'rain', count: 50, speed: 7, color: 0x4466aa }, overlay: { color: 0x334455, alpha: 0.18 }, sound: 'rain_heavy' },
        storm:           { particles: { type: 'rain', count: 50, speed: 8, color: 0x4455aa }, overlay: { color: 0x2a2a3a, alpha: 0.22 }, sound: 'storm', flash: true },
        frost:           { particles: { type: 'snow', count: 20, speed: 1.5, color: 0xccddee }, overlay: { color: 0xaabbcc, alpha: 0.08 }, sound: null },
        wind:            { particles: { type: 'drift', count: 8, speed: 4, color: 0x998877 }, overlay: null, sound: 'wind' },
        // Barren biome
        heat_shimmer:    { particles: null, overlay: { color: 0xddaa66, alpha: 0.05 }, sound: null, shimmer: true },
        dust_haze:       { particles: { type: 'drift', count: 10, speed: 2, color: 0x998866 }, overlay: { color: 0xaa8855, alpha: 0.1 }, sound: null },
        dust_rain:       { particles: { type: 'rain', count: 20, speed: 4, color: 0x887755 }, overlay: { color: 0x776644, alpha: 0.1 }, sound: 'rain' },
        dust_mist:       { particles: { type: 'drift', count: 12, speed: 1.5, color: 0xaa9977 }, overlay: { color: 0x998866, alpha: 0.08 }, sound: null },
        mudstorm:        { particles: { type: 'rain', count: 40, speed: 6, color: 0x665533 }, overlay: { color: 0x554422, alpha: 0.18 }, sound: 'rain_heavy' },
        dust_storm:      { particles: { type: 'drift', count: 35, speed: 6, color: 0xaa8844 }, overlay: { color: 0x886633, alpha: 0.25 }, sound: 'storm', flash: true },
        sandstorm:       { particles: { type: 'drift', count: 25, speed: 5, color: 0xbb9955 }, overlay: { color: 0x997744, alpha: 0.2 }, sound: 'wind' },
        sandstorm_light: { particles: { type: 'drift', count: 12, speed: 3, color: 0xaa8855 }, overlay: { color: 0x998866, alpha: 0.12 }, sound: null },
        salt_wind:       { particles: { type: 'snow', count: 12, speed: 2, color: 0xccbbaa }, overlay: { color: 0xbbaa88, alpha: 0.06 }, sound: 'wind' },
        // Apocalyptic biome
        pale_glow:       { particles: null, overlay: { color: 0xaa88cc, alpha: 0.04 }, sound: null },
        spore_drift:     { particles: { type: 'drift', count: 10, speed: 1, color: 0x8855aa }, overlay: { color: 0x6633aa, alpha: 0.06 }, sound: null },
        ashfall_light:   { particles: { type: 'snow', count: 12, speed: 1, color: 0x777788 }, overlay: { color: 0x555566, alpha: 0.08 }, sound: null },
        ashfall:         { particles: { type: 'snow', count: 25, speed: 1.5, color: 0x666677 }, overlay: { color: 0x444455, alpha: 0.12 }, sound: null },
        ashfall_heavy:   { particles: { type: 'snow', count: 40, speed: 2, color: 0x555566 }, overlay: { color: 0x333344, alpha: 0.2 }, sound: null },
        miasma:          { particles: { type: 'drift', count: 15, speed: 0.8, color: 0x553388 }, overlay: { color: 0x442266, alpha: 0.18 }, sound: null },
        anomaly_storm:   { particles: { type: 'snow', count: 35, speed: 3, color: 0x7744bb }, overlay: { color: 0x331155, alpha: 0.25 }, sound: 'storm', flash: true, flashColor: 0x8844cc },
        crystalline_fall:{ particles: { type: 'snow', count: 18, speed: 1, color: 0xaa88dd }, overlay: { color: 0x775599, alpha: 0.08 }, sound: null },
        void_wind:       { particles: { type: 'drift', count: 18, speed: 4, color: 0x553388 }, overlay: { color: 0x442266, alpha: 0.15 }, sound: 'wind' }
    },

    // Fetch weather (uses wttr.in — free, no API key, returns simple codes)
    async fetchWeather() {
        const now = Date.now();
        if (this._cache && now - this._cacheTime < this.CACHE_DURATION) return this._cache;
        try {
            const resp = await fetch('https://wttr.in/?format=%C', { signal: AbortSignal.timeout(5000) });
            if (!resp.ok) throw new Error('Weather fetch failed');
            const text = (await resp.text()).trim().toLowerCase();
            const condition = this._parseCondition(text);
            this._cache = condition;
            this._cacheTime = now;
            return condition;
        } catch (e) {
            console.warn('Weather fetch failed, using clear:', e.message);
            return this._cache || 'clear';
        }
    },

    // Parse wttr.in text description to a condition key
    _parseCondition(text) {
        if (text.includes('thunder')) return 'thunderstorm';
        if (text.includes('heavy rain') || text.includes('torrential')) return 'heavy_rain';
        if (text.includes('drizzle') || text.includes('light rain')) return 'drizzle';
        if (text.includes('rain') || text.includes('shower')) return 'rain';
        if (text.includes('heavy snow') || text.includes('blizzard')) return 'snow';
        if (text.includes('snow') || text.includes('sleet') || text.includes('ice')) return 'snow';
        if (text.includes('fog') || text.includes('freezing fog')) return 'fog';
        if (text.includes('mist') || text.includes('haze')) return 'mist';
        if (text.includes('dust') || text.includes('sand')) return 'dust';
        if (text.includes('wind') || text.includes('gale')) return 'wind';
        if (text.includes('overcast')) return 'cloudy';
        if (text.includes('cloudy') || text.includes('partly')) return 'partly_cloudy';
        if (text.includes('sunny') || text.includes('clear')) return 'sunny';
        return 'clear';
    },

    // Get biome-mapped effect for a condition
    getEffect(condition, biomeId) {
        const map = this._biomeMap[biomeId] || this._biomeMap.grassy;
        const effectName = map[condition] || 'clear';
        return { name: effectName, config: this._effects[effectName] || this._effects.clear };
    },

    // Get CRT-friendly weather label for terminal display
    getLabel(effectName) {
        const labels = {
            clear: 'CLEAR', haze: 'HAZE', overcast: 'OVERCAST', fog: 'FOG',
            rain_light: 'LIGHT RAIN', rain: 'RAIN', rain_heavy: 'HEAVY RAIN',
            storm: 'STORM', frost: 'FROST', wind: 'HIGH WIND',
            heat_shimmer: 'HEAT SHIMMER', dust_haze: 'DUST HAZE',
            dust_rain: 'DUST RAIN', dust_mist: 'DUST MIST', mudstorm: 'MUDSTORM',
            dust_storm: 'DUST STORM', sandstorm: 'SANDSTORM', sandstorm_light: 'LIGHT SANDSTORM',
            salt_wind: 'SALT WIND', pale_glow: 'PALE GLOW', spore_drift: 'SPORE DRIFT',
            ashfall_light: 'LIGHT ASHFALL', ashfall: 'ASHFALL', ashfall_heavy: 'HEAVY ASHFALL',
            miasma: 'MIASMA', anomaly_storm: 'ANOMALY STORM',
            crystalline_fall: 'CRYSTAL FALL', void_wind: 'VOID WIND'
        };
        return labels[effectName] || 'UNKNOWN';
    }
};

// ============================================
// PARALLAX LANDSCAPE BACKGROUND — Multi-layer biome vistas
// Used by SafehouseScene (camera scroll parallax) and BiomeSelectScene (auto-drift)
// ============================================
