// Vestige GPS — Biome Grid
// Maps real-world GPS coordinates to Biome Reaches using Perlin noise
//
// The world is divided into a global grid. Each cell is a "Biome Reach" assigned
// one of 6 biomes via Perlin noise with a global seed. All players see the same grid.
//
// Grid cell size: ~500m per side (adjustable via CELL_SIZE_METERS)
// Biome assignment: Perlin noise sampled at cell center, quantized to 6 biomes
//
// Usage:
//   BiomeGrid.init(seed)           — set global seed (same for all players)
//   BiomeGrid.getBiome(lat, lng)   — returns { biome, cellX, cellY, reachId }
//   BiomeGrid.getReachInfo(lat, lng) — full reach data with weather/foundry
//   BiomeGrid.getNearbyCells(lat, lng, radius) — all cells within radius

// ============================================
// PERLIN NOISE (2D, deterministic from seed)
// Classic implementation — Ken Perlin's improved noise
// ============================================

const _p = new Uint8Array(512);
const _grad = [
    [1,1],[-1,1],[1,-1],[-1,-1],
    [1,0],[-1,0],[0,1],[0,-1]
];

function _seedPermutation(seed) {
    // Fisher-Yates shuffle seeded by simple LCG
    const perm = new Uint8Array(256);
    for (let i = 0; i < 256; i++) perm[i] = i;

    let s = seed >>> 0;
    for (let i = 255; i > 0; i--) {
        s = (s * 1664525 + 1013904223) >>> 0;
        const j = s % (i + 1);
        [perm[i], perm[j]] = [perm[j], perm[i]];
    }
    for (let i = 0; i < 256; i++) {
        _p[i] = perm[i];
        _p[i + 256] = perm[i];
    }
}

function _fade(t) { return t * t * t * (t * (t * 6 - 15) + 10); }
function _lerp(a, b, t) { return a + t * (b - a); }

function _dot(gi, x, y) {
    const g = _grad[gi % 8];
    return g[0] * x + g[1] * y;
}

function perlin2D(x, y) {
    const xi = Math.floor(x) & 255;
    const yi = Math.floor(y) & 255;
    const xf = x - Math.floor(x);
    const yf = y - Math.floor(y);

    const u = _fade(xf);
    const v = _fade(yf);

    const aa = _p[_p[xi] + yi];
    const ab = _p[_p[xi] + yi + 1];
    const ba = _p[_p[xi + 1] + yi];
    const bb = _p[_p[xi + 1] + yi + 1];

    return _lerp(
        _lerp(_dot(aa, xf, yf), _dot(ba, xf - 1, yf), u),
        _lerp(_dot(ab, xf, yf - 1), _dot(bb, xf - 1, yf - 1), u),
        v
    );
}

// ============================================
// BIOME DEFINITIONS
// ============================================

const BIOMES = [
    {
        id: 'ironfield',
        name: 'Ironfield',
        desc: 'Rusted infrastructure, collapsed cities',
        color: 0x8a7a6a,
        weather: { clear: 'smog', rain: 'acid_rain', fog: 'haze', storm: 'acid_storm' },
        renderBase: 'barren',
    },
    {
        id: 'mirelands',
        name: 'Mirelands',
        desc: 'Overgrown ruins, fungal growth, swamps',
        color: 0x4a6a4a,
        weather: { clear: 'humidity', rain: 'drizzle', fog: 'thick_fog', storm: 'spore_burst' },
        renderBase: 'grassy',
    },
    {
        id: 'scorchflats',
        name: 'Scorchflats',
        desc: 'Flat wasteland, dust, dried earth',
        color: 0x9a8a5a,
        weather: { clear: 'heat_haze', rain: 'dust_rain', fog: 'dust_storm', storm: 'sandstorm' },
        renderBase: 'barren',
    },
    {
        id: 'hollows',
        name: 'Hollows',
        desc: 'Deep chasms, collapsed mines, caverns',
        color: 0x5a5a7a,
        weather: { clear: 'still', rain: 'drip', fog: 'echo_mist', storm: 'cave_in' },
        renderBase: 'apocalyptic',
    },
    {
        id: 'tidemarsh',
        name: 'Tidemarsh',
        desc: 'Flooded ruins, tidal pools, coastline',
        color: 0x4a7a8a,
        weather: { clear: 'mist', rain: 'downpour', fog: 'sea_fog', storm: 'tidal_surge' },
        renderBase: 'grassy',
    },
    {
        id: 'ashveil',
        name: 'Ashveil',
        desc: 'Toxic fog, Cube corruption, dead zones',
        color: 0x6a5a6a,
        weather: { clear: 'ash_fall', rain: 'black_rain', fog: 'void_static', storm: 'cube_storm' },
        renderBase: 'apocalyptic',
    },
];

// ============================================
// GPS → GRID COORDINATE CONVERSION
// ============================================

// Earth constants
const METERS_PER_DEG_LAT = 111320; // ~111.32 km per degree latitude

// Cell size in meters — determines how big each biome reach is
const CELL_SIZE_METERS = 750; // ~750m per cell side (slightly larger than Orna)

function _metersPerDegLng(lat) {
    return METERS_PER_DEG_LAT * Math.cos(lat * Math.PI / 180);
}

function _gpsToCell(lat, lng) {
    // Convert GPS to a global grid coordinate
    // cellX = longitude direction, cellY = latitude direction
    const cellY = Math.floor((lat * METERS_PER_DEG_LAT) / CELL_SIZE_METERS);
    const cellX = Math.floor((lng * _metersPerDegLng(lat)) / CELL_SIZE_METERS);
    return { cellX, cellY };
}

function _cellToGPSCenter(cellX, cellY, refLat) {
    // Approximate center of a cell back to GPS coordinates
    const lat = (cellY * CELL_SIZE_METERS + CELL_SIZE_METERS / 2) / METERS_PER_DEG_LAT;
    const lng = (cellX * CELL_SIZE_METERS + CELL_SIZE_METERS / 2) / _metersPerDegLng(refLat || lat);
    return { lat, lng };
}

// ============================================
// BIOME ASSIGNMENT
// ============================================

// Perlin noise scale — controls how "blobby" the biome regions are
// Larger value = bigger biome clusters
const NOISE_SCALE = 0.07;

// Biome lookup grid — two noise axes select a biome
// Axis 1 ("temperature"): cold → hot
// Axis 2 ("moisture"): dry → wet
// No single biome dominates the center — center cell gets Ashveil (rare/interesting)
const BIOME_GRID = [
    // dry          mid          wet        ← moisture axis
    ['hollows',    'ironfield', 'tidemarsh'],  // cold
    ['scorchflats','ashveil',   'mirelands'],  // temperate
    ['scorchflats','ironfield', 'tidemarsh'],  // hot
];

function _assignBiome(cellX, cellY) {
    // Two independent noise samples at offset positions
    const temp = perlin2D(cellX * NOISE_SCALE, cellY * NOISE_SCALE);
    const moist = perlin2D(cellX * NOISE_SCALE + 500, cellY * NOISE_SCALE + 500);

    // Map from Perlin range to 0-2 index
    // Narrow center band (-0.12 to 0.12) so center biome doesn't dominate
    const ti = temp < -0.12 ? 0 : temp > 0.12 ? 2 : 1;
    const mi = moist < -0.12 ? 0 : moist > 0.12 ? 2 : 1;

    const biomeId = BIOME_GRID[ti][mi];
    return BIOMES.find(b => b.id === biomeId);
}

// ============================================
// REACH ID — unique identifier for a grid cell
// ============================================

function _reachId(cellX, cellY) {
    // Deterministic string ID for any grid cell
    return `${cellX}:${cellY}`;
}

// ============================================
// PUBLIC API
// ============================================

let _seed = 42;
let _initialized = false;

export const BiomeGrid = {

    // Set the global seed. Must be the same for all players.
    init(seed = 42) {
        _seed = seed;
        _seedPermutation(seed);
        _initialized = true;
    },

    // Get biome for a GPS coordinate
    getBiome(lat, lng) {
        if (!_initialized) this.init(_seed);

        const { cellX, cellY } = _gpsToCell(lat, lng);
        const biome = _assignBiome(cellX, cellY);
        const center = _cellToGPSCenter(cellX, cellY, lat);

        return {
            biome: biome.id,
            biomeName: biome.name,
            biomeData: biome,
            cellX,
            cellY,
            reachId: _reachId(cellX, cellY),
            center,
        };
    },

    // Get full reach info including weather mapping
    getReachInfo(lat, lng) {
        const base = this.getBiome(lat, lng);

        return {
            ...base,
            weather: base.biomeData.weather,
            renderBase: base.biomeData.renderBase,
            foundry: null, // Will be assigned by foundry territory system later
        };
    },

    // Get all biome cells within a radius (in meters) of a GPS point
    getNearbyCells(lat, lng, radiusMeters = 2000) {
        if (!_initialized) this.init(_seed);

        const cells = [];
        const cellRadius = Math.ceil(radiusMeters / CELL_SIZE_METERS);
        const { cellX: cx, cellY: cy } = _gpsToCell(lat, lng);

        for (let dy = -cellRadius; dy <= cellRadius; dy++) {
            for (let dx = -cellRadius; dx <= cellRadius; dx++) {
                const x = cx + dx;
                const y = cy + dy;
                const biome = _assignBiome(x, y);
                const center = _cellToGPSCenter(x, y, lat);

                // Check actual distance
                const dLat = (center.lat - lat) * METERS_PER_DEG_LAT;
                const dLng = (center.lng - lng) * _metersPerDegLng(lat);
                const dist = Math.sqrt(dLat * dLat + dLng * dLng);

                if (dist <= radiusMeters) {
                    cells.push({
                        biome: biome.id,
                        biomeName: biome.name,
                        biomeData: biome,
                        cellX: x,
                        cellY: y,
                        reachId: _reachId(x, y),
                        center,
                        distance: Math.round(dist),
                    });
                }
            }
        }

        cells.sort((a, b) => a.distance - b.distance);
        return cells;
    },

    // Get the biome at a specific grid cell (no GPS conversion)
    getBiomeAtCell(cellX, cellY) {
        if (!_initialized) this.init(_seed);
        const biome = _assignBiome(cellX, cellY);
        return {
            biome: biome.id,
            biomeName: biome.name,
            biomeData: biome,
            cellX,
            cellY,
            reachId: _reachId(cellX, cellY),
        };
    },

    // Check if two GPS coordinates are in the same biome reach
    sameReach(lat1, lng1, lat2, lng2) {
        const a = _gpsToCell(lat1, lng1);
        const b = _gpsToCell(lat2, lng2);
        return a.cellX === b.cellX && a.cellY === b.cellY;
    },

    // Get cell size in meters
    getCellSize() {
        return CELL_SIZE_METERS;
    },

    // Get all 6 biome definitions
    getAllBiomes() {
        return [...BIOMES];
    },

    // Raw Perlin access for other systems
    perlin(x, y) {
        if (!_initialized) this.init(_seed);
        return perlin2D(x, y);
    },
};
