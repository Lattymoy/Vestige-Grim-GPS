// Vestige GPS — DOTSystem
// Damage-over-time system (bleed, burn, poison, toxic)
// Pure logic: apply DOTs, tick damage, track state
// Rendering (icons, bars, tint flashes) delegated via _renderer

import { Blurbs } from './blurbs.js';
import { CONFIG } from '../data/config.js';

export const DOTSystem = {
    _playerDOTs: [],   // Active DOTs on player: { type, damage, tickRate, duration, elapsed, tickElapsed, id }
    _nextId: 1,
    _renderer: null,

    /**
     * Set renderer for visual feedback.
     * Renderer should implement:
     *   buildIcons(scene)
     *   renderDebuffHUD(scene, playerDOTs)
     *   ensureEnemyBar(scene, enemy, dots)
     *   cleanupEnemyBar(enemy)
     *   flashTint(scene, target, color, durationMs)
     *   clearHudIcons()
     */
    init(renderer) {
        DOTSystem._renderer = renderer;
    },

    // Apply a DOT to the player
    applyToPlayer(scene, type, opts = {}) {
        const def = CONFIG.dotEffects[type];
        if (!def) return;
        
        const existing = this._playerDOTs.find(d => d.type === type);
        if (existing) {
            existing.duration = opts.duration || def.duration;
            existing.elapsed = 0;
            existing.damage = opts.damage || def.damage;
            return;
        }
        
        this._playerDOTs.push({
            type, id: this._nextId++,
            damage: opts.damage || def.damage,
            tickRate: opts.tickRate || def.tickRate,
            duration: opts.duration || def.duration,
            elapsed: 0, tickElapsed: 0
        });
        
        // Flash blurb on application
        if (scene.player) {
            Blurbs.show(scene, scene.player, def.blurbText, {
                color: def.blurbColor, fontSize: 8, duration: 600
            });
        }
    },
    

    
    // Tick all player DOTs — call in scene update
    updatePlayer(scene, delta) {
        if (!scene.state || scene.state.dead) return;
        const dt = delta || 16;
        let tookDmg = false;
        
        for (let i = this._playerDOTs.length - 1; i >= 0; i--) {
            const dot = this._playerDOTs[i];
            dot.elapsed += dt;
            dot.tickElapsed += dt;
            
            // Expired
            if (dot.elapsed >= dot.duration) {
                this._playerDOTs.splice(i, 1);
                continue;
            }
            
            // Tick damage
            if (dot.tickElapsed >= dot.tickRate) {
                dot.tickElapsed -= dot.tickRate;
                const def = CONFIG.dotEffects[dot.type];
                scene.state.health -= dot.damage;
                // Update combat timestamp (renderer may need scene.time.now — pass via callback)
                if (scene._lastCombatTime !== undefined && scene.time) scene._lastCombatTime = scene.time.now;
                tookDmg = true;
                
                // Damage number via Blurbs (already decoupled)
                if (scene.player) {
                    Blurbs.show(scene, scene.player, `-${dot.damage}`, {
                        color: def ? def.blurbColor : '#ff4444', fontSize: 7, duration: 400
                    });
                    // Tint flash via renderer
                    if (DOTSystem._renderer) {
                        const tintColor = dot.type === 'toxic' ? 0x44cc44 : dot.type === 'bleed' ? 0xcc3333 : 0xff4444;
                        DOTSystem._renderer.flashTint(scene, scene.player, tintColor, 80);
                    }
                }
            }
        }
        
        if (tookDmg && scene.hud && scene.hud.updateHP) {
            const maxHp = scene.state.maxHealth || (CONFIG.player.health + ((scene._eqStats && scene._eqStats.maxHealth) || 0));
            scene.hud.updateHP(scene.state.health, maxHp);
        }
    },
    
    // Tick DOTs on a specific enemy — call in updateEnemies per enemy
    updateEnemy(scene, enemy, delta) {
        if (!enemy._dots || enemy._dots.length === 0) return;
        const dt = delta || 16;
        
        for (let i = enemy._dots.length - 1; i >= 0; i--) {
            const dot = enemy._dots[i];
            dot.elapsed += dt;
            dot.tickElapsed += dt;
            
            if (dot.elapsed >= dot.duration) {
                enemy._dots.splice(i, 1);
                continue;
            }
            
            if (dot.tickElapsed >= dot.tickRate) {
                dot.tickElapsed -= dot.tickRate;
                enemy.hp -= dot.damage;
                // Blurb for enemy damage
                const def = CONFIG.dotEffects[dot.type];
                Blurbs.show(scene, enemy, `-${dot.damage}`, {
                    color: def ? def.blurbColor : '#ff4444', fontSize: 7, duration: 400
                });
            }
        }
    },

    // Render player debuff icons — delegates to renderer
    renderDebuffHUD(scene) {
        if (DOTSystem._renderer) {
            DOTSystem._renderer.renderDebuffHUD(scene, this._playerDOTs);
        }
    },
    
    // Create/update floating HP bar on an enemy — delegates to renderer
    ensureEnemyBar(scene, enemy) {
        if (DOTSystem._renderer) {
            DOTSystem._renderer.ensureEnemyBar(scene, enemy);
        }
    },
    
    // Clean up enemy bar when enemy dies
    cleanupEnemyBar(enemy) {
        if (DOTSystem._renderer) {
            DOTSystem._renderer.cleanupEnemyBar(enemy);
        } else if (enemy._hpBarGfx) {
            enemy._hpBarGfx.destroy();
            enemy._hpBarGfx = null;
        }
    },
    
    // Get active player DOTs (for external queries)
    getPlayerDOTs() {
        return this._playerDOTs;
    },

    // Check if player has a DOT type
    playerHas(type) {
        return this._playerDOTs.some(d => d.type === type);
    },
    
    // Clear all player DOTs (scene transition)
    clearPlayer() {
        this._playerDOTs = [];
        if (DOTSystem._renderer) DOTSystem._renderer.clearHudIcons();
    }
};

// ============================================
// TELEGRAPH SYSTEM — Standardized danger indicators
// All enemy attacks call this instead of hand-rolling graphics.
// Three tiers with FIXED durations. Enemies do not pass custom durations.
// ============================================
