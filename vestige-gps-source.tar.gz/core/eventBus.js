// Vestige GPS — EventBus
// Extracted from game_2_.html lines 27264-27295

export const EventBus = {
    _listeners: {},
    
    on(event, fn, context) {
        if (!this._listeners[event]) this._listeners[event] = [];
        this._listeners[event].push({ fn, context: context || null });
        return this;
    },
    
    off(event, fn) {
        const list = this._listeners[event];
        if (!list) return;
        this._listeners[event] = list.filter(l => l.fn !== fn);
    },
    
    emit(event, data) {
        const list = this._listeners[event];
        if (!list) return;
        for (let i = 0; i < list.length; i++) {
            list[i].fn.call(list[i].context, data);
        }
    },
    
    clear(event) {
        if (event) delete this._listeners[event];
        else this._listeners = {};
    }
};

// ============================================
// OBJECT POOL — Recycle Phaser game objects to reduce GC pressure
// ============================================
