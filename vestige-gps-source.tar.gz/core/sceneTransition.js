// Vestige GPS — SceneTransition (Core)
// State packaging and run finalization logic
// Rendering (fadeTo, fadeIn) moved to client/rendering/sceneTransition.js

import { ItemManager } from './itemManager.js';
import { CONFIG } from '../data/config.js';
import { SaveManager } from './saveManager.js';
import { StatTracker } from './statTracker.js';
import { SurvivorGenerator } from './survivorGenerator.js';

export const SceneTransition = {
    _renderer: null,
    
    init(renderer) {
        this._renderer = renderer;
    },
    
    // === Rendering bridge ===
    fadeIn(scene, duration) {
        if (this._renderer) this._renderer.fadeIn(scene, duration);
        else scene.cameras.main.fadeIn(duration || 400);
    },
    
    fadeTo(scene, targetScene, data, opts) {
        if (this._renderer) this._renderer.fadeTo(scene, targetScene, data, opts);
        else scene.scene.start(targetScene, data);
    },

    // Build standard map-return data payload
    mapReturnData(scene) {
        return {
            playerState: scene.state,
            mapSeed: scene.mapSeed,
            currentNodeId: scene.currentNodeId,
            previousNodeId: scene.previousNodeId,
            completedNodes: scene.completedNodes || [],
            traveledRoutes: scene.traveledRoutes || [],
            activeRoute: scene.activeRoute || null,
            deployedSurvivor: scene.deployedSurvivor || null
        };
    },
    
    // Build standard safehouse-return data payload
    safehouseReturnData(scene, opts = {}) {
        const data = {};
        
        // Flush run stats to SaveManager (global stats)
        if (scene._runStats) {
            scene._runStats.runTime = Date.now() - (scene._runStartTime || Date.now());
            scene._runStats.survived = !opts.died;
            scene._runStats.bitsEarned = scene.state.bits || 0;
            scene._runStats.reach = scene.destinationNode?.reach || scene._runStats.reach || 0;
            StatTracker.endOfRun(scene._runStats);
            data.runXP = scene._runStats.xpEarned || 0;
            data.leveledUp = scene._runStats.leveledUp || false;
            data.newLevel = scene._runStats.newLevel || 1;
            data.bossTypesKilled = scene._runStats.bossTypesKilled || [];
            data.cubesCollected = scene._runStats.cubesCollected || 0;
            
            // ── Per-survivor stat accumulation ──
            // Write this run's stats to the deployed survivor object in save data
            const saveData = SaveManager.load();
            const survId = scene.deployedSurvivor ? scene.deployedSurvivor.id : null;
            if (survId && saveData.survivors) {
                const surv = saveData.survivors.find(s => s.id === survId);
                if (surv) {
                    const rs = scene._runStats;
                    surv.kills = (surv.kills || 0) + (rs.kills || 0);
                    surv.meleeKills = (surv.meleeKills || 0) + (rs.meleeKills || 0);
                    surv.timeSurvived = (surv.timeSurvived || 0) + (rs.runTime || 0);
                    surv.damageDealt = (surv.damageDealt || 0) + (rs.damageDealt || 0);
                    surv.damageTaken = (surv.damageTaken || 0) + (rs.damageTaken || 0);
                    surv.bossesKilled = (surv.bossesKilled || 0) + (rs.bossesKilled || 0);
                    surv.itemsLooted = (surv.itemsLooted || 0) + (rs.itemsLooted || 0);
                    surv.distanceTraveled = (surv.distanceTraveled || 0) + (rs.distanceTraveled || 0);
                    surv.highestReach = Math.max(surv.highestReach || 0, rs.reach || 0);
                    surv.buildingsExplored = (surv.buildingsExplored || 0) + (rs.buildingsExplored || 0);
                    surv.timesHealed = (surv.timesHealed || 0) + (rs.timesHealed || 0);
                    surv.bitsEarned = (surv.bitsEarned || 0) + (rs.bitsEarned || 0);
                    surv.materialsEarned = (surv.materialsEarned || 0) + (rs.materialsEarned || 0);
                    surv.cubesFound = (surv.cubesFound || 0) + (rs.cubesCollected || 0);
                    surv.rareFinds = (surv.rareFinds || 0) + (rs.rareFinds || 0);
                    if (rs.survived) {
                        surv.runsCompleted = (surv.runsCompleted || 0) + 1;
                        surv.consecutiveRuns = (surv.consecutiveRuns || 0) + 1;
                        // Zero damage run
                        if ((rs.damageTaken || 0) === 0) {
                            surv.zeroDamageRuns = (surv.zeroDamageRuns || 0) + 1;
                        }
                        // Fully loaded — all 4 equipment slots filled
                        const eq = scene.state.equipment;
                        if (eq && eq.weapon && eq.melee && eq.gear && eq.consumable) {
                            surv.fullLoadouts = (surv.fullLoadouts || 0) + 1;
                        }
                    } else {
                        surv.runsFailed = (surv.runsFailed || 0) + 1;
                        surv.consecutiveRuns = 0; // reset streak on death
                    }
                    // XP award
                    SurvivorGenerator.addXP(surv, data.runXP || 0);
                    
                    // ── MARK AWARD TRIGGERS ──
                    const _markNotes = [];
                    
                    // Boss killed — award mark for each boss type defeated this run
                    if (data.bossTypesKilled && data.bossTypesKilled.length > 0) {
                        data.bossTypesKilled.forEach(bt => {
                            const m = SurvivorGenerator.awardEarnedMark(surv, 'boss_killed', { bossType: bt });
                            if (m) _markNotes.push({ mark: m, trigger: 'boss_killed' });
                        });
                    }
                    
                    // Near death survived — returned alive below 10% HP
                    if (rs.survived) {
                        const _eqHP = ItemManager.getEquipmentStats(scene.state.equipment).maxHealth || 0;
                        const _maxHP = CONFIG.player.health + _eqHP;
                        const _curHP = scene.state.health || 0;
                        const hpRatio = _curHP / _maxHP;
                        if (hpRatio > 0 && hpRatio < 0.10) {
                            surv.closeCallRuns = (surv.closeCallRuns || 0) + 1;
                            const m = SurvivorGenerator.awardEarnedMark(surv, 'near_death_survived');
                            if (m) _markNotes.push({ mark: m, trigger: 'near_death' });
                        }
                    }
                    
                    // Runs milestone — check 10, 25, 50
                    const rc = surv.runsCompleted || 0;
                    [10, 25, 50].forEach(milestone => {
                        if (rc >= milestone) {
                            const m = SurvivorGenerator.awardEarnedMark(surv, 'runs_milestone', { runs: milestone });
                            if (m) _markNotes.push({ mark: m, trigger: 'milestone' });
                        }
                    });
                    
                    // Cube anomaly survived — increment + check at 3
                    if (data.cubesCollected && data.cubesCollected > 0) {
                        const m = SurvivorGenerator.awardEarnedMark(surv, 'cube_anomaly_survived');
                        if (m) _markNotes.push({ mark: m, trigger: 'anomaly' });
                    }
                    
                    // Store mark notifications for safehouse display
                    data._markNotifications = _markNotes;
                    
                    // ── SURVIVOR ACHIEVEMENT CHECK ──
                    // Update bestRunKills
                    surv.bestRunKills = Math.max(surv.bestRunKills || 0, rs.kills || 0);
                    const achCompleted = SurvivorGenerator.checkSurvivorAchievements(surv, saveData);
                    if (achCompleted.length > 0) {
                        data._achNotifications = achCompleted;
                    }
                    
                    SaveManager.save(saveData);
                }
            }
        }
        
        if (opts.died) {
            data.died = true;
            data.returnedEquipment = scene.state.equipment;
            data.returnedVehicle = scene.state.vehicle;
            data.deployedSurvivor = scene.deployedSurvivor || null;
            data.deathContext = scene._deathContext || { cause: 'unknown' };
        } else {
            data.returnedLoot = {
                bits: scene.state.bits || 0,
                powerAmmo: scene.state.powerAmmo || 0,
                fuel: scene.state.fuel || 0,
                cubeBonus: 0
            };
            data.returnedBackpack = scene.state.backpack;
            data.returnedEquipment = scene.state.equipment;
            data.returnedVehicle = scene.state.vehicle;
            data.deployedSurvivor = scene.deployedSurvivor || null;
            // Pass health state for injury evaluation
            const eqStats = ItemManager.getEquipmentStats(scene.state.equipment);
            data.returnedHealth = scene.state.health || 0;
            data.maxHealth = CONFIG.player.health + (eqStats.maxHealth || 0);
        }
        return data;
    }
};
