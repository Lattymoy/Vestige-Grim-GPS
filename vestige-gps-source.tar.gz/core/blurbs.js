// Vestige GPS — Blurbs
// Combat flavor text dispatcher
// Core provides the interface; client provides the Phaser implementation via init()
// Without init(), all calls are silent no-ops (server-safe)
import { PhaserBlurbs } from '../client/rendering/blurbs.js';

export const Blurbs = {
    _impl: null,

    /**
     * Initialize with a renderer implementation.
     * Call once at client startup:
     *   Blurbs.init(PhaserBlurbs);
     */
    init(impl) {
        Blurbs._impl = impl;
    },

    /**
     * Show a floating text blurb above an entity.
     * @param {object} scene - Active scene
     * @param {object} entity - Must have .x, .y properties
     * @param {string} text - Text to display
     * @param {object} opts - { color, fontSize, duration, rise, depth, bold, offsetY }
     */
    show(scene, entity, text, opts = {}) {
        if (Blurbs._impl) return Blurbs._impl.show(scene, entity, text, opts);
        return null;
    },

    /**
     * Show a persistent blurb that follows an entity.
     * Returns a handle with .update() and .destroy()
     */
    showPersistent(scene, entity, text, opts = {}) {
        if (Blurbs._impl) return Blurbs._impl.showPersistent(scene, entity, text, opts);
        return { text: null, update() {}, destroy() {} };
    }
};
