// Vestige GPS — EnemyAI
// All enemy behavior trees and attack patterns
// Rendering fully decoupled via _renderer bridge + proxy helpers:
//   - All scene.add/tweens/cameras → proxy helpers (_circle, _rect, _gfx, _tween, _camMain)
//   - All SpriteManager/DynamicShadows/TelegraphSystem/AttackVFX → renderer delegates
//   - All sprite state (setTexture/setFrame/anims) → _setTex/_setFrame/_playAnim proxies
//   - Phaser.Math → inline helpers (_dist, _angle, _between, _clamp)
//   - _noop Proxy handles all chained calls in headless mode
//   - Remaining grep hits are sprite property setters on proxy objects (safe via _noop)

import { Blurbs } from './blurbs.js';
import { CONFIG } from '../data/config.js';
import { CombatHelper } from './combatHelper.js';
import { DOTSystem } from './dotSystem.js';
import { ItemManager } from './itemManager.js';
import { EventBus } from './eventBus.js';
import { DynamicShadows } from '../client/dynamicShadows.js';
import { AttackVFX } from '../client/rendering/attackVFX.js';
import { TelegraphSystem } from '../client/rendering/telegraphSystem.js';
import { SpriteManager } from '../client/spriteManager.js';

// Inline Phaser.Math replacements
const _dist = (x1, y1, x2, y2) => { const dx = x2-x1, dy = y2-y1; return Math.sqrt(dx*dx+dy*dy); };
const _angle = (x1, y1, x2, y2) => Math.atan2(y2 - y1, x2 - x1);
const _between = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const _clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const _radToDeg = (r) => r * 180 / Math.PI;
const _now = (scene) => (scene.time ? scene.time.now : Date.now());
const _delay = (scene, ms, fn) => { if (scene.time) scene.time.delayedCall(ms, fn); else setTimeout(fn, ms); };

// Rendering proxies — no-op when headless (no renderer)
const _R = () => EnemyAI._renderer;
// Noop chainable+callable object for headless mode
// Supports: _noop.anything → _noop, _noop() → _noop, _noop.x.y.z() → _noop
const _noop = new Proxy(function(){}, { get: () => _noop, apply: () => _noop });
// Shape creation: returns game object or chainable noop
const _circle = (sc, x, y, r, col, a, d) => _R() ? _R().addCircle(sc, x, y, r, col, a, d) : _noop;
const _rect = (sc, x, y, w, h, col, a, d) => _R() ? _R().addRect(sc, x, y, w, h, col, a, d) : _noop;
const _gfx = (sc, d) => _R() ? _R().addGraphics(sc, d) : _noop;
const _line = (sc, x1, y1, x2, y2, col, a, d) => _R() ? _R().addLine(sc, x1, y1, x2, y2, col, a, d) : _noop;
const _ellipse = (sc, x, y, w, h, col, a, d) => _R() ? _R().addEllipse(sc, x, y, w, h, col, a, d) : _noop;
// Tweens + camera
const _tween = (sc, cfg) => { if (_R()) _R().tween(sc, cfg); };
const _shake = (sc, dur, intensity) => { if (_R()) _R().cameraShake(sc, dur, intensity); };
const _camMain = (sc) => _R() ? _R().cameraMain(sc) : { scrollX: 0, scrollY: 0, width: 800, height: 600 };
// Telegraph + sprite systems
const _telegraph = (sc, cfg) => _R() ? _R().telegraph(sc, cfg) : null;
const _buildSheet = (sc, key) => { if (_R()) _R().buildEnemySheet(sc, key); };
const _texExists = (sc, key) => _R() ? _R().textureExists(sc, key) : false;
const _telDur = (tier) => _R() ? _R().telegraphDuration(tier) : ({ fast: 300, standard: 500, heavy: 800 }[tier] || 500);
const _hitFlash = (sc, e, target) => { if (_R()) _R().enemyHitFlash(sc, e, target); };
// Sprite state — safe for headless (guards sprite existence)
const _setTex = (e, key, frame) => { if (e && e.setTexture) _setTex(e, key, frame); };
const _setFrame = (e, frame) => { if (e && e.setFrame) _setFrame(e, frame); };
const _stopAnim = (e) => { try { if (e && e.anims) _stopAnim(e); } catch(x) {} };
const _playAnim = (e, key, ignoreIfPlaying) => { try { if (e && e.anims) e.anims.play(key, ignoreIfPlaying); } catch(x) {} };
const _setTint = (e, col) => { if (e && e.setTint) _setTint(e, col); };
const _restoreTint = (e) => { if (_R()) _R().restoreTint(e); else if (e && e.clearTint) e.clearTint(); };
const _setAlpha = (e, a) => { if (e && e.setAlpha) _setAlpha(e, a); };
const _setDepth = (obj, d) => { if (obj && obj.setDepth) obj.setDepth(d); };
const _setScale = (obj, s) => { if (obj && obj.setScale) obj.setScale(s); };
const _setScale2 = (obj, sx, sy) => { if (obj && obj.setScale) obj.setScale(sx, sy); };
// Timer event proxy — wraps scene.time.addEvent with headless fallback
const _addEvent = (scene, cfg) => {
    if (scene.time && scene.time.addEvent) return scene.time.addEvent(cfg);
    // Headless fallback: setInterval-based
    const handle = { _destroyed: false, destroy() { this._destroyed = true; if (this._id) clearInterval(this._id); } };
    if (cfg.loop) {
        handle._id = setInterval(() => { if (!handle._destroyed) cfg.callback(); }, cfg.delay || 16);
    } else {
        handle._id = setTimeout(() => { if (!handle._destroyed) cfg.callback(); }, cfg.delay || 0);
    }
    return handle;
};
// Physics proxy — projectile/overlap creation routes through renderer
const _physSprite = (sc, x, y, key) => _R() ? _R().physicsSprite(sc, x, y, key) : null;
const _physOverlap = (sc, a, b, fn) => { if (_R()) _R().physicsOverlap(sc, a, b, fn); };
const _physExisting = (sc, obj) => { if (_R()) _R().physicsExisting(sc, obj); };

export const EnemyAI = {
    _renderer: null,

    /**
     * Set renderer for enemy AI visual effects.
     * See client/rendering/enemyAIRenderer.js for full interface.
     */
    init(renderer) { EnemyAI._renderer = renderer; },
    aiMelee(scene, e, cfg, dist, angle) {
        if (e._staggered) return;
        e.aiState = 'chase';
        const spdM = e._speedMult || 1;
        
        // === HUSK PERSONALITY AI — contact damage fodder ===
        const isHusk = e.enemyType === 'husk' || e.enemyType === 'husk_stumble';
        if (isHusk) {
            const personality = e._huskPersonality || 'pack';
            let goalX = Math.cos(angle);
            let goalY = Math.sin(angle);
            let spdFactor = 1;
            
            if (personality === 'pack') {
                // Cohesion: drift toward nearby husks while chasing
                let cohX = 0, cohY = 0, count = 0;
                scene.enemies.getChildren().forEach(other => {
                    if (other === e || !other.active || other._dying || other._stumbling) return;
                    if (other.enemyType !== 'husk' && other.enemyType !== 'husk_stumble') return;
                    const d = _dist(e.x, e.y, other.x, other.y);
                    if (d < 60 && d > 8) {
                        cohX += other.x; cohY += other.y; count++;
                    }
                });
                if (count > 0) {
                    cohX /= count; cohY /= count;
                    const cohAngle = Math.atan2(cohY - e.y, cohX - e.x);
                    goalX = goalX * 0.7 + Math.cos(cohAngle) * 0.3;
                    goalY = goalY * 0.7 + Math.sin(cohAngle) * 0.3;
                }
            } else if (personality === 'stray') {
                const strayAngle = angle + (e._strayAngleOffset || 0.5);
                const arcBlend = Math.min(dist / 150, 1);
                goalX = Math.cos(angle) * (1 - arcBlend * 0.6) + Math.cos(strayAngle) * arcBlend * 0.6;
                goalY = Math.sin(angle) * (1 - arcBlend * 0.6) + Math.sin(strayAngle) * arcBlend * 0.6;
            } else if (personality === 'lurcher') {
                const dt = scene.game.loop.delta || 16;
                e._lurchTimer = (e._lurchTimer || 0) + dt;
                if (e._lurchPaused) {
                    spdFactor = 0.05;
                    if (e._lurchTimer > (e._lurchPauseDur || 1000)) {
                        e._lurchPaused = false;
                        e._lurchTimer = 0;
                        e._lurchMoveDur = 500 + Math.random() * 600;
                    }
                } else {
                    spdFactor = 1.4;
                    if (e._lurchTimer > (e._lurchMoveDur || 700)) {
                        e._lurchPaused = true;
                        e._lurchTimer = 0;
                        e._lurchPauseDur = 600 + Math.random() * 1200;
                    }
                }
            }
            
            // Frenzy speed boost from nearby death
            if (e._frenzyUntil && _now(scene) < e._frenzyUntil) {
                spdFactor *= 1.5;
                _setTint(e, 0xcc6644);
            } else if (e._frenzyUntil) {
                e._frenzyUntil = 0;
                _restoreTint(e);
            }
            
            const spd = dist < 120 ? cfg.chaseSpeed : cfg.speed;
            // Stop piling on the player — slow/orbit when very close
            if (dist < 16) {
                // At contact range: orbit slowly instead of pushing through
                const orbAngle = angle + Math.PI / 2 * ((e.x + e.y) % 2 === 0 ? 1 : -1);
                e.setVelocity(Math.cos(orbAngle) * spd * 0.25 * spdM, Math.sin(orbAngle) * spd * 0.25 * spdM);
            } else if (dist < 28) {
                // Near attack range: slow approach
                e.setVelocity(goalX * spd * spdM * spdFactor * 0.3, goalY * spd * spdM * spdFactor * 0.3);
            } else {
                e.setVelocity(goalX * spd * spdM * spdFactor, goalY * spd * spdM * spdFactor);
            }
            return;
        }
        
        // === NON-HUSK MELEE: lunge telegraph ===
        if (dist < 35 && !e._lungeWindup && !e._lungeCooldown) {
            e._lungeWindup = true;
            e.setVelocity(0, 0);
            _setTint(e, 0xff6644);
            _delay(scene, 350, () => {
                if (!e.active || e._staggered) { e._lungeWindup = false; return; }
                _restoreTint(e);
                e._lungeWindup = false;
                const la = _angle(e.x, e.y, scene.player.x, scene.player.y);
                e.setVelocity(Math.cos(la) * cfg.chaseSpeed * 2.5, Math.sin(la) * cfg.chaseSpeed * 2.5);
                e._lungeCooldown = true;
                _delay(scene, 200, () => {
                    if (e.active) e.setVelocity(e.body.velocity.x * 0.3, e.body.velocity.y * 0.3);
                });
                _delay(scene, 1200, () => { if (e.active) e._lungeCooldown = false; });
            });
        } else if (!e._lungeWindup) {
            if (dist > 25) {
                e.setVelocity(Math.cos(angle) * cfg.chaseSpeed * spdM, Math.sin(angle) * cfg.chaseSpeed * spdM);
            } else {
                e.setVelocity(e.body.velocity.x * 0.8, e.body.velocity.y * 0.8);
            }
        }
    },
    
    // === FLICKER ERRATIC AI — jagged lateral dashes, phase shift, blade attack ===
    aiErratic(scene, e, cfg, dist, angle, delta) {
        if (e._staggered || e._flickerAttacking) return;
        e.aiState = 'chase';
        const spdM = e._speedMult || 1;
        const dt = delta || 16;
        
        // --- Stutter: micro-pauses every 150-250ms creating visible jitter ---
        e._stutterTimer = (e._stutterTimer || 0) + dt;
        if (e._stutterTimer > (e._stutterDur || 200)) {
            e._stutterTimer = 0;
            e._stutterDur = 150 + Math.random() * 100;
            if (Math.random() < 0.3 && !e._phaseShifting) {
                e._stutterPause = true;
                _delay(scene, 50, () => { if (e.active) e._stutterPause = false; });
            }
        }
        if (e._stutterPause) {
            e.setVelocity(e.body.velocity.x * 0.1, e.body.velocity.y * 0.1);
            return;
        }
        
        // --- Phase shift dash: every 3-5s, rapid translucent dash ---
        e._phaseTimer = (e._phaseTimer || 0) + dt;
        if (!e._phaseShifting && e._phaseTimer > (e._phaseInterval || 4000) && dist < 200) {
            e._phaseShifting = true;
            e._phaseTimer = 0;
            e._phaseInterval = 3000 + Math.random() * 2000;
            const dashAngle = angle + (Math.random() - 0.5) * 0.4;
            const dashSpd = cfg.chaseSpeed * 3;
            e.setVelocity(Math.cos(dashAngle) * dashSpd, Math.sin(dashAngle) * dashSpd);
            _setAlpha(e, 0.3);
            for (let i = 0; i < 3; i++) {
                _delay(scene, i * 70, () => {
                    if (!e.active) return;
                    const ghost = _circle(scene, e.x, e.y, 6, 0x8844cc, 0.25).setDepth(1);
                    _tween(scene, { targets: ghost, alpha: 0, scaleX: 0.3, scaleY: 0.3, duration: 300, onComplete: () => ghost.destroy() });
                });
            }
            _delay(scene, 250, () => {
                if (!e.active) return;
                e._phaseShifting = false;
                _setAlpha(e, 1);
                e.setVelocity(0, 0);
            });
            return;
        }
        if (e._phaseShifting) return;
        
        // Flicker is contact-damage only — no discrete attack, blade damage via enemyHitPlayer overlap
        
        // --- Erratic approach: change vector every 400-800ms ---
        e._erraticTimer = (e._erraticTimer || 0) + dt;
        if (e._erraticTimer > (e._erraticDur || 500)) {
            e._erraticTimer = 0;
            e._erraticDur = 400 + Math.random() * 400;
            const offsetSign = Math.random() > 0.5 ? 1 : -1;
            const offsetMag = (30 + Math.random() * 30) * Math.PI / 180;
            e._erraticAngle = angle + offsetSign * offsetMag;
        }
        const moveAngle = e._erraticAngle || angle;
        const blend = Math.min(dist / 100, 1);
        const finalX = Math.cos(angle) * (1 - blend * 0.5) + Math.cos(moveAngle) * blend * 0.5;
        const finalY = Math.sin(angle) * (1 - blend * 0.5) + Math.sin(moveAngle) * blend * 0.5;
        const spd = dist < 100 ? cfg.chaseSpeed : cfg.speed;
        // Stop piling on the player — orbit when very close
        if (dist < 18) {
            const orbDir = ((e.x * 7 + e.y * 3) % 2 === 0) ? 1 : -1;
            const orbAngle = angle + Math.PI / 2 * orbDir;
            e.setVelocity(Math.cos(orbAngle) * spd * 0.3 * spdM, Math.sin(orbAngle) * spd * 0.3 * spdM);
        } else {
            e.setVelocity(finalX * spd * spdM, finalY * spd * spdM);
        }
    },
    
    // NOTE: _flickerAttack is no longer called — flicker is contact-damage only via enemyHitPlayer.
    // Method preserved per codebase policy (do not remove).
    // Flicker blade attack — wind up, triple slash, follow-through
    _flickerAttack(scene, e, cfg, angle) {
        if (!e.active || e._dying) return;
        e._flickerAttacking = true;
        e._flickerAtkCooldown = true;
        e.setVelocity(0, 0);
        
        const buildTime = _telDur('fast');
        const slashRange = 35;
        const slashArc = Math.PI / 2; // 90° cone
        
        _buildSheet(scene, 'flicker_attack');
        const atkKey = 'enemy_flicker_attack_sheet';
        const walkKey = 'enemy_flicker_sheet';
        const dir = e._lastDir || 0;
        const baseFrame = dir * 3;
        
        if (_texExists(scene, atkKey)) {
            _stopAnim(e); _setTex(e, atkKey, 0);
            
            // Frame 0: WINDUP — plays during telegraph
            _setFrame(e, baseFrame + 0);
            
            // Telegraph: cone in attack direction
            const tel = _telegraph(scene, {
                shape: 'cone', tier: 'fast', color: 'arcane',
                source: e, radius: slashRange, angle: angle, arc: slashArc
            });
            e._activeTelegraph = tel;
            
            // At buildTime: SLASH — damage here
            _delay(scene, buildTime, () => {
                if (!e.active || e._dying) { e._flickerAttacking = false; return; }
                _setFrame(e, baseFrame + 1);
                const d = _dist(e.x, e.y, scene.player.x, scene.player.y);
                const aToP = Math.atan2(scene.player.y - e.y, scene.player.x - e.x);
                let aDiff = Math.abs(aToP - angle);
                if (aDiff > Math.PI) aDiff = Math.PI * 2 - aDiff;
                if (d < slashRange && aDiff < slashArc / 2 && !scene.isInvincible && !scene.state.dead) {
                    const fDmg = Math.round(cfg.damage * (e._dmgMult || 1));
                    scene.state.health -= fDmg;
                    scene._lastCombatTime = _now(scene);
                    scene.hud.updateHP(scene.state.health, scene.state.maxHealth);
                    Blurbs.show(scene, scene.player, `-${fDmg}`, { color: '#aa44ff', fontSize: 9 });
                    _hitFlash(scene, e, scene.player);
                    // 30% chance to apply bleed DOT
                    if (Math.random() < 0.3) {
                        DOTSystem.applyToPlayer(scene, 'bleed');
                    }
                }
            });
            
            // Frame 2: FOLLOW-THROUGH (150ms after slash)
            _delay(scene, buildTime + 150, () => {
                if (!e.active) return;
                _setFrame(e, baseFrame + 2);
            });
            
            // Restore walk sheet (300ms after slash)
            _delay(scene, buildTime + 300, () => {
                if (!e.active) return;
                if (_texExists(scene, walkKey)) { _stopAnim(e); _setTex(e, walkKey, 0); }
                e._flickerAttacking = false;
            });
        } else {
            e._flickerAttacking = false;
        }
        
        _delay(scene, cfg.attackCooldown || 800, () => {
            if (e.active) e._flickerAtkCooldown = false;
        });
    },
    
    // Maimed flicker AI — erratic movement, no phase shift, no blade attack, contact damage + acid trail
    aiErraticMaimed(scene, e, cfg, dist, angle, delta) {
        if (e._staggered) return;
        e.aiState = 'chase';
        const spdM = e._speedMult || 1;
        const dt = delta || 16;
        
        // Stutter — more frequent when maimed, panicked
        e._stutterTimer = (e._stutterTimer || 0) + dt;
        if (e._stutterTimer > (e._stutterDur || 150)) {
            e._stutterTimer = 0;
            e._stutterDur = 100 + Math.random() * 100;
            if (Math.random() < 0.35) {
                e._stutterPause = true;
                _delay(scene, 40, () => { if (e.active) e._stutterPause = false; });
            }
        }
        if (e._stutterPause) {
            e.setVelocity(e.body.velocity.x * 0.1, e.body.velocity.y * 0.1);
            return;
        }
        
        // Erratic approach — tighter angle changes, more desperate
        e._erraticTimer = (e._erraticTimer || 0) + dt;
        if (e._erraticTimer > (e._erraticDur || 400)) {
            e._erraticTimer = 0;
            e._erraticDur = 300 + Math.random() * 300;
            const offsetSign = Math.random() > 0.5 ? 1 : -1;
            const offsetMag = (20 + Math.random() * 40) * Math.PI / 180;
            e._erraticAngle = angle + offsetSign * offsetMag;
        }
        const moveAngle = e._erraticAngle || angle;
        const blend = Math.min(dist / 80, 1);
        const finalX = Math.cos(angle) * (1 - blend * 0.4) + Math.cos(moveAngle) * blend * 0.4;
        const finalY = Math.sin(angle) * (1 - blend * 0.4) + Math.sin(moveAngle) * blend * 0.4;
        const spd = dist < 80 ? cfg.chaseSpeed : cfg.speed;
        // Stop piling on the player — orbit when very close
        if (dist < 18) {
            const orbDir = ((e.x * 7 + e.y * 3) % 2 === 0) ? 1 : -1;
            const orbAngle = angle + Math.PI / 2 * orbDir;
            e.setVelocity(Math.cos(orbAngle) * spd * 0.3 * spdM, Math.sin(orbAngle) * spd * 0.3 * spdM);
        } else {
            e.setVelocity(finalX * spd * spdM, finalY * spd * spdM);
        }
    },
    
    // Flicker blade severance — shot arms off, becomes acid-trailing maimed variant
    _flickerMaimCheck(scene, enemy) {
        if (!enemy.active || enemy._dying) return;
        if (enemy.enemyType !== 'flicker') return;
        if (enemy._isMaimed) return;
        
        // Roll chance — higher when low HP
        const hpRatio = enemy.hp / enemy.maxHp;
        let chance = 0.06;
        if (hpRatio < 0.5) chance = 0.18;
        if (hpRatio < 0.25) chance = 0.35;
        if (Math.random() > chance) return;
        
        enemy._isMaimed = true;
        enemy.enemyType = 'flicker_maimed';
        
        // Build maimed sheet
        _buildSheet(scene, 'flicker_maimed');
        const maimedKey = 'enemy_flicker_maimed_sheet';
        if (_texExists(scene, maimedKey)) {
            _stopAnim(enemy); _setTex(enemy, maimedKey, 0);
            enemy.hasAnimSheet = true;
        }
        
        // Apply maimed cfg stats
        const mCfg = CONFIG.enemyTypes.flicker_maimed;
        enemy.maxHp = mCfg.health;
        enemy.hp = Math.min(enemy.hp, mCfg.health);
        
        // Clear phase shift — no more dashing
        enemy._phaseShifting = false;
        enemy._phaseTimer = 0;
        enemy._phaseInterval = Infinity;
        enemy._flickerAttacking = false;
        enemy._flickerAtkCooldown = false;
        // Enable contact damage
        enemy.canAttack = true;
        
        // Init acid trail
        enemy._acidTrail = [];
        enemy._acidTimer = 0;
        
        // Visual feedback — sever flash + blade fragments
        _setTint(enemy, 0x44cc44);
        _delay(scene, 150, () => { if (enemy.active) _restoreTint(enemy); });
        Blurbs.show(scene, enemy, 'BLADES SEVERED', { color: '#55dd55', fontSize: 8, duration: 800 });
        
        // Spawn blade fragments as debris
        for (let i = 0; i < 2; i++) {
            const frag = _rect(scene, 
                enemy.x + (Math.random() - 0.5) * 20,
                enemy.y + (Math.random() - 0.5) * 10,
                4, 8, 0x4a4a5a, 0.7
            ).setDepth(1);
            _tween(scene, {
                targets: frag, alpha: 0, y: frag.y + 10, rotation: Math.random() * 2,
                duration: 1500, onComplete: () => frag.destroy()
            });
        }
    },
    
    _stumbleEnemy(scene, e) {
        if (!e.active || e._dying || e._stumbling || e._stumbleImmune) return;
        if (e.enemyType !== 'husk') return;
        e._stumbling = true;
        e.canAttack = false;
        
        const vx = e.body.velocity.x, vy = e.body.velocity.y;
        e.setVelocity(vx * -0.3, vy * -0.3);
        
        _buildSheet(scene, 'husk_stumble');
        const stumbleKey = 'enemy_husk_stumble_sheet';
        if (!_texExists(scene, stumbleKey)) { e._stumbling = false; e.canAttack = true; return; }
        
        e.enemyType = 'husk_stumble';
        _stopAnim(e); _setTex(e, stumbleKey, 0);
        e.hasAnimSheet = true;
        
        
        // Determine direction for frame offset: 0=down, 1=right, 2=up, 3=left
        const dir = e._lastDir || 0;
        const baseFrame = dir * 3;
        
        // Frame 0: FALLING (0-300ms)
        _setFrame(e, baseFrame + 0);
        
        // Frame 1: PRONE (300-2200ms) — long downtime, out of the fight
        _delay(scene, 300, () => {
            if (!e.active) return;
            _setFrame(e, baseFrame + 1);
            e.setVelocity(0, 0); // fully stopped on ground
        });
        
        // Frame 2: GETTING UP (2200-2600ms)
        _delay(scene, 2200, () => {
            if (!e.active) return;
            _setFrame(e, baseFrame + 2);
        });
        
        // Restore (2600ms)
        _delay(scene, 2600, () => {
            if (!e.active) return;
            e.enemyType = 'husk';
            const origKey = 'enemy_husk_sheet';
            if (_texExists(scene, origKey)) {
                _stopAnim(e); _setTex(e, origKey, 0);
            }
            e._stumbling = false;
            e.canAttack = true;
            // 2s immunity before can stumble again
            e._stumbleImmune = true;
            _delay(scene, 2000, () => { if (e.active) e._stumbleImmune = false; });
        });
    },
    
    _limbLossToCrawler(scene, enemy, bulletX, bulletY) {
        if (!enemy.active || enemy._dying) return;
        if (enemy.enemyType !== 'husk') return;
        if (enemy._isCrawler) return;
        
        const hpRatio = enemy.hp / enemy.maxHp;
        let chance = 0.08;
        if (hpRatio < 0.5) chance = 0.20;
        if (hpRatio < 0.25) chance = 0.40;
        if (Math.random() > chance) return;
        
        const cx = enemy.x, cy = enemy.y;
        const remainingHp = enemy.hp;
        
        if (enemy._telegraphGfx) { enemy._telegraphGfx.destroy(); }
        if (_R()) _R().shadowRemove(scene, enemy);
        if (scene.lockedTarget === enemy) { scene.lockedTarget = null; scene.target = null; }
        enemy._dying = true;
        enemy.destroy();
        
        const crawlType = 'husk_crawl';
        _buildSheet(scene, crawlType);
        const crawlCfg = CONFIG.enemyTypes[crawlType];
        const sheetKey = 'enemy_' + crawlType + '_sheet';
        const hasSheet = _texExists(scene, sheetKey);
        
        const c = _physSprite(scene, cx, cy, hasSheet ? sheetKey : ('enemy_' + crawlType));
        if (!c) return; // headless — no physics sprite available
        if (c.setDisplaySize) { c.setDisplaySize(crawlCfg.size, crawlCfg.size); _setDepth(c, 20); }
        c.enemyType = crawlType;
        c.hasAnimSheet = hasSheet;
        c.hp = Math.min(remainingHp, Math.floor(crawlCfg.health * 0.8));
        c.maxHp = c.hp;
        c._speedMult = (enemy._speedMult || 1);
        c._isCrawler = true;
        c.canAttack = true;
        if (c.setCollideWorldBounds) c.setCollideWorldBounds(true);
        if (c.body) { c.body.setSize(crawlCfg.size * 0.8, crawlCfg.size * 0.5); c.body.setOffset(crawlCfg.size * 0.1, crawlCfg.size * 0.25); }
        if (hasSheet) {
            const idleKey = 'enemy_' + crawlType + '_idle';
            if (_R() && _R().animExists(scene, idleKey)) _playAnim(c, idleKey, true);
        }
        c.aiState = 'chase';
        c.stuckTimer = 0;
        c.lastPos = { x: cx, y: cy };
        
        scene.enemies.add(c);
        if (_R()) _R().shadowAdd(scene, c, { offsetY: 3, scale: 0.35, alpha: 0.1 });
        
        // Gore — persistent limbs + blood
        const impactAngle = Math.atan2(cy - bulletY, cx - bulletX);
        for (let i = 0; i < 2; i++) {
            const la = impactAngle + (i === 0 ? -0.4 : 0.5) + (Math.random() - 0.5) * 0.6;
            const ld = 12 + Math.random() * 18;
            const lx = cx + Math.cos(la) * ld;
            const ly = cy + Math.sin(la) * ld;
            const leg = _gfx(scene).setDepth(2);
            const legLen = 6 + Math.random() * 4;
            const legW = 2 + Math.random();
            leg.fillStyle(0x6a5a4e, 0.7);
            leg.fillRect(-legW/2, -legLen/2, legW, legLen);
            leg.fillStyle(0x8a8070, 0.5);
            leg.fillCircle(0, -legLen/2, 1.5);
            leg.fillStyle(0x5a2a1a, 0.6);
            leg.fillRect(-legW/2 - 0.5, legLen/2 - 2, legW + 1, 2);
            leg.setPosition(lx, ly);
            if (leg && leg.setAngle) leg.setAngle(Math.random() * 360);
            _tween(scene, { targets: leg, alpha: 0.1, duration: 15000, onComplete: () => leg.destroy() });
        }
        for (let i = 0; i < 3; i++) {
            const fa = impactAngle + (Math.random() - 0.5) * 1.8;
            const fd = 5 + Math.random() * 18;
            const frag = _rect(scene, 
                cx + Math.cos(fa) * fd, cy + Math.sin(fa) * fd,
                1 + Math.random() * 2, 1 + Math.random() * 2,
                Math.random() > 0.5 ? 0x5a2a1a : 0x4a3a32, 0.5
            ).setDepth(2).setAngle(Math.random() * 360);
            _tween(scene, { targets: frag, alpha: 0.05, duration: 12000, onComplete: () => frag.destroy() });
        }
        const pool = _circle(scene, cx, cy, 8, 0x551010, 0.3).setDepth(1);
        _tween(scene, { targets: pool, alpha: 0.05, scaleX: 1.2, scaleY: 1.1, duration: 15000, onComplete: () => pool.destroy() });
        
        Blurbs.show(scene, c, 'DISMEMBERED', { color: '#cc6644', fontSize: 8, duration: 500 });
    },
    
    // Host — ranged 4-armed flesh-thrower: keeps distance, quick attack (2 toxic projectiles), power attack (4 lobbed AoE)
    aiHost(scene, e, cfg, dist, angle, delta) {
        if (e._staggered) return;
        const spdM = e._speedMult || 1;
        const dt = delta || 16;
        const fleeRange = cfg.fleeRange || 70;
        const keepDist = cfg.keepDist || 120;
        const atkRange = cfg.attackRange || 160;
        
        // --- MOVEMENT: keep distance like overseer ---
        if (dist < fleeRange) {
            const fleeAngle = angle + Math.PI;
            e.setVelocity(Math.cos(fleeAngle) * cfg.chaseSpeed * 1.2 * spdM, Math.sin(fleeAngle) * cfg.chaseSpeed * 1.2 * spdM);
        } else if (dist < keepDist - 15) {
            const drift = angle + Math.PI + (Math.random() - 0.5) * 0.5;
            e.setVelocity(Math.cos(drift) * cfg.speed * 0.5 * spdM, Math.sin(drift) * cfg.speed * 0.5 * spdM);
        } else if (dist > atkRange + 30) {
            e.setVelocity(Math.cos(angle) * cfg.chaseSpeed * spdM, Math.sin(angle) * cfg.chaseSpeed * spdM);
        } else {
            // In range — slow drift, face player
            if (!e._hostDrift || Math.random() < 0.008) e._hostDrift = angle + (Math.random() > 0.5 ? 1 : -1) * Math.PI / 3;
            e.setVelocity(Math.cos(e._hostDrift) * cfg.speed * 0.25 * spdM, Math.sin(e._hostDrift) * cfg.speed * 0.25 * spdM);
        }
        
        // Stop moving during attack buildup
        if (e._hostBuilding) {
            e.setVelocity(e.body.velocity.x * 0.1, e.body.velocity.y * 0.1);
        }
        
        // --- ATTACK COOLDOWNS ---
        if (!e._quickTimer) e._quickTimer = 2000;
        if (!e._powerTimer) e._powerTimer = 6000;
        if (!e._detachTimer) e._detachTimer = 3000; // start near-ready
        e._quickTimer += dt;
        e._powerTimer += dt;
        e._detachTimer += dt;
        
        if (e._hostBuilding) return;
        
        // --- SKITTERLING DETACH: when player rushes in, shed parasites as defense ---
        const detachRange = cfg.detachRange || 80;
        const detachCD = cfg.detachCooldown || 5000;
        if (dist < detachRange && e._detachTimer >= detachCD && scene.enemies.getChildren().length < 30) {
            e._detachTimer = 0;
            const count = cfg.detachCount || 2;
            Blurbs.show(scene, e, 'SHED', { color: '#77aa55', fontSize: 9, duration: 500 });
            _setTint(e, 0x77aa55);
            _delay(scene, 120, () => { if (e.active) _restoreTint(e); });
            for (let sk = 0; sk < count; sk++) {
                _delay(scene, sk * 150, () => {
                    if (!e.active || e._dying) return;
                    const skAngle = Math.atan2(scene.player.y - e.y, scene.player.x - e.x) + (Math.random() - 0.5) * 1.2;
                    const skX = e.x + Math.cos(skAngle) * 12;
                    const skY = e.y + Math.sin(skAngle) * 12;
                    const skit = scene.spawnEnemy(skX, skY, 'skitterling');
                    if (skit) {
                        if (_R()) _R().killTweensOf(scene, skit);
                        _setScale(skit, 0.2); _setTint(skit, 0x77aa55);
                        _tween(scene, { targets: skit, scaleX: 1, scaleY: 1, duration: 250, ease: 'Back.easeOut',
                            onComplete: () => { if (skit.active) _restoreTint(skit); }
                        });
                        // Burst particles from host body
                        for (let p = 0; p < 3; p++) {
                            const pa = skAngle + (Math.random() - 0.5) * 1.5;
                            const dot = _circle(scene, e.x, e.y, 2, 0x668844, 0.5).setDepth(25);
                            _tween(scene, { targets: dot, x: skX + Math.cos(pa) * 12, y: skY + Math.sin(pa) * 8, alpha: 0, duration: 250, onComplete: () => dot.destroy() });
                        }
                    }
                });
            }
        }
        
        if (dist > atkRange) return;
        
        // --- POWER ATTACK: lobbed AoE (higher priority, longer cooldown) ---
        const powerCD = cfg.powerCooldown || 12000;
        if (!e._hostBuilding && e._powerTimer >= powerCD && dist < atkRange) {
            e._hostBuilding = true;
            e._hostBuildType = 'power';
            e._buildupTimer = 0;
            e._spawnBuildup = 0;
            const buildTime = _telDur('heavy');
            
            // Standardized ground telegraph — circle around host
            const tel = _telegraph(scene, {
                shape: 'circle', tier: 'heavy', color: 'toxic',
                source: e, radius: 30
            });
            e._activeTelegraph = tel;
            
            // Buildup bar progress (overhead bar still driven by _spawnBuildup)
            const barEvt = _addEvent(scene, { delay: 33, loop: true, callback: () => {
                if (!e.active || e._dying) { barEvt.destroy(); return; }
                e._buildupTimer += 33;
                e._spawnBuildup = Math.min(1, e._buildupTimer / buildTime);
            }});
            
            _delay(scene, buildTime, () => {
                barEvt.destroy();
                if (!e.active || e._dying) { e._hostBuilding = false; if (tel) tel.cancel(); return; }
                e._hostBuilding = false;
                e._spawnBuildup = 0;
                e._powerTimer = 0;
                e._activeTelegraph = null;
                EnemyAI._hostPowerAttack(scene, e, cfg);
            });
            return;
        }
        
        // --- QUICK ATTACK: direct toxic projectiles ---
        const quickCD = cfg.attackCooldown || 4000;
        if (!e._hostBuilding && e._quickTimer >= quickCD && dist < atkRange) {
            e._hostBuilding = true;
            e._hostBuildType = 'quick';
            e._buildupTimer = 0;
            e._spawnBuildup = 0;
            const buildTime = _telDur('standard');
            
            // Standardized ground telegraph — cone toward player, follows host
            const freshA = _angle(e.x, e.y, scene.player.x, scene.player.y);
            const tel = _telegraph(scene, {
                shape: 'cone', tier: 'standard', color: 'toxic',
                source: e, radius: 50, angle: freshA, arc: 0.8
            });
            e._activeTelegraph = tel;
            
            // Buildup bar progress
            const barEvt = _addEvent(scene, { delay: 33, loop: true, callback: () => {
                if (!e.active || e._dying) { barEvt.destroy(); return; }
                e._buildupTimer += 33;
                e._spawnBuildup = Math.min(1, e._buildupTimer / buildTime);
            }});
            
            _delay(scene, buildTime, () => {
                barEvt.destroy();
                if (!e.active || e._dying) { e._hostBuilding = false; if (tel) tel.cancel(); return; }
                e._hostBuilding = false;
                e._spawnBuildup = 0;
                e._quickTimer = 0;
                e._activeTelegraph = null;
                const fireAngle = _angle(e.x, e.y, scene.player.x, scene.player.y);
                EnemyAI._hostQuickAttack(scene, e, cfg, fireAngle);
            });
        }
    },
    
    // Quick attack: 4 flesh chunks (one per arm), alternating left-right, staggered
    _hostQuickAttack(scene, e, cfg, angle) {
        if (!e.active || e._dying) return;
        const count = cfg.quickCount || 4;
        const speed = cfg.projectileSpeed || 140;
        const dmg = Math.round((cfg.damage || 10) * (e._dmgMult || 1));
        
        // Arm positions: upper-left, upper-right, lower-left, lower-right
        const armOffsets = [
            { side: -1, dist: 16, spread: -0.18 },  // upper left — widest
            { side:  1, dist: 16, spread:  0.18 },  // upper right — widest
            { side: -1, dist: 10, spread: -0.08 },  // lower left — tighter
            { side:  1, dist: 10, spread:  0.08 },  // lower right — tighter
        ];
        
        for (let i = 0; i < count; i++) {
            const arm = armOffsets[i % armOffsets.length];
            const a = angle + arm.spread;
            const perp = angle + Math.PI / 2;
            const ox = Math.cos(a) * arm.dist + Math.cos(perp) * arm.side * 8;
            const oy = Math.sin(a) * arm.dist + Math.sin(perp) * arm.side * 8;
            
            _delay(scene, i * 180, () => {
                if (!e.active) return;
                
                // Arm wind flash on the throwing side
                const flashSide = arm.side;
                _setTint(e, i % 2 === 0 ? 0xbb7744 : 0xaa6633);
                _delay(scene, 100, () => { if (e.active) _restoreTint(e); });
                
                // Flesh chunk
                const projGfx = _gfx(scene).setDepth(25);
                projGfx.setPosition(e.x + ox, e.y + oy);
                // Draw chunky flesh blob
                projGfx.fillStyle(0x7a4422, 0.9);
                projGfx.fillRect(-4, -3, 8, 6);
                projGfx.fillStyle(0x6a3318, 0.8);
                projGfx.fillRect(-3, -4, 6, 2); // top ridge
                projGfx.fillRect(-3, 3, 5, 2);  // bottom ridge
                projGfx.fillStyle(0x994433, 0.6);
                projGfx.fillRect(-2, -1, 4, 2);  // wet sheen
                // Dripping bits
                projGfx.fillStyle(0x44aa33, 0.5);
                projGfx.fillRect(-1, 3, 2, 2);   // toxic drip
                
                _physExisting(scene, projGfx);
                projGfx.body.setVelocity(Math.cos(a) * speed, Math.sin(a) * speed);
                projGfx.body.setAllowGravity(false);
                projGfx.body.setSize(10, 8);
                projGfx._damage = dmg;
                projGfx._isEnemyProjectile = true;
                
                // === ACID DRIP TRAIL — simple drops, no polyline (4 projectiles = must be cheap) ===
                const trailDur = cfg.toxicDuration || 5000;
                let trailCount = 0;
                
                const trailEvt = _addEvent(scene, { delay: 120, loop: true, callback: () => {
                    if (!projGfx.active) { trailEvt.destroy(); return; }
                    trailCount++;
                    // Visual drip
                    const wobX = (Math.random() - 0.5) * 3;
                    const wobY = (Math.random() - 0.5) * 2;
                    const drip = _ellipse(scene, projGfx.x + wobX, projGfx.y + wobY, 5 + Math.random() * 3, 3 + Math.random() * 2, 0x44aa33, 0.35).setDepth(1);
                    _tween(scene, { targets: drip, alpha: 0.03, scaleX: 0.4, scaleY: 0.4, duration: trailDur,
                        onComplete: () => drip.destroy() });
                    // Hitbox
                    if (trailCount % 2 === 0 && scene.acidPuddles) {
                        const pb = _physSprite(scene, projGfx.x, projGfx.y, '__DEFAULT');
                        if (!pb) return;
                        pb.setVisible(false); if (pb.body) pb.body.setSize(12, 10);
                        pb._acidActive = true; pb._acidDmg = cfg.toxicDamage || 3; pb._tickRate = cfg.toxicTickRate || 500;
                        scene.acidPuddles.add(pb);
                        _delay(scene, trailDur, () => {
                            if (pb.active !== false) { pb._acidActive = false; scene.acidPuddles.remove(pb); pb.destroy(); }
                        });
                    }
                    if (trailCount > 18) trailEvt.destroy();
                }});
                
                // Player overlap
                _physOverlap(scene, projGfx, scene.player, () => {
                    const result = CombatHelper.damagePlayer(scene, projGfx._damage, {
                        color: '#aa5522', fontSize: 9, dot: 'toxic',
                        shake: { duration: 80, intensity: 0.01 },
                        iFrames: 300
                    });
                    if (!result.blocked) {
                        trailEvt.destroy();
                        projGfx.destroy();
                    }
                });
                
                _delay(scene, 2500, () => { if (projGfx.active) { trailEvt.destroy(); projGfx.destroy(); } });
            });
        }
        Blurbs.show(scene, e, 'THROW', { color: '#aa6633', fontSize: 8, duration: 400 });
    },
    
    // Power attack: 4 flesh chunks thrown UP off screen, red circle telegraphs appear, chunks fall DOWN into them
    _hostPowerAttack(scene, e, cfg) {
        if (!e.active || e._dying) return;
        const count = cfg.powerCount || 4;
        const dmg = Math.round((cfg.damage || 10) * 1.5 * (e._dmgMult || 1));
        const blastR = cfg.blastRadius || 35;
        const px = scene.player.x, py = scene.player.y;
        const cam = _camMain(scene);
        
        _setTint(e, 0xcc4444);
        _delay(scene, 300, () => { if (e.active) _restoreTint(e); });
        Blurbs.show(scene, e, 'BARRAGE', { color: '#cc4444', fontSize: 9, duration: 600 });
        
        for (let i = 0; i < count; i++) {
            // Landing position — wider scatter for readable telegraphs
            const scatter = 55 + Math.random() * 55;
            const sa = (Math.PI * 2 / count) * i + (Math.random() - 0.5) * 0.5; // evenly spaced angles with jitter
            const landX = px + Math.cos(sa) * scatter;
            const landY = py + Math.sin(sa) * scatter;
            const launchDelay = i * 250;
            const flightUpTime = 450;
            const hangTime = 500 + i * 120; // stagger the landings — more dodge room
            const fallTime = 800;
            
            _delay(scene, launchDelay, () => {
                if (!e.active) return;
                
                // === PHASE 1: Launch chunk UP from host ===
                const chunkUp = _gfx(scene).setDepth(35);
                chunkUp.setPosition(e.x, e.y - 8);
                chunkUp.fillStyle(0x7a4422, 0.9);
                chunkUp.fillRect(-4, -3, 8, 6);
                chunkUp.fillStyle(0x6a3318, 0.7);
                chunkUp.fillRect(-3, -4, 6, 2);
                chunkUp.fillStyle(0x44aa33, 0.4);
                chunkUp.fillRect(-1, 2, 3, 2); // toxic drip
                
                // Fly UP off screen
                const topY = cam.scrollY - 40;
                _tween(scene, {
                    targets: chunkUp,
                    y: topY,
                    scaleX: 0.4, scaleY: 0.4,
                    alpha: 0.5,
                    duration: flightUpTime,
                    ease: 'Cubic.easeIn',
                    onComplete: () => { chunkUp.destroy(); }
                });
                
                // === PHASE 2: After chunk goes off screen, show red circle telegraph ===
                _delay(scene, flightUpTime, () => {
                    const totalTelegraph = hangTime + fallTime;
                    
                    // Base danger zone circle — starts as stroke, fills with red
                    const telegraph = _circle(scene, landX, landY, blastR, 0xcc2222, 0).setDepth(2);
                    telegraph.setStrokeStyle(2, 0xcc2222, 0.5);
                    _tween(scene, { targets: telegraph, fillAlpha: 0.3, duration: totalTelegraph, ease: 'Cubic.easeIn' });
                    // Stroke pulses brighter as impact nears
                    const strokePulse = _addEvent(scene, { delay: 100, loop: true, callback: () => {
                        const progress = Math.min(1, (_now(scene) - strokePulse._startTime) / totalTelegraph);
                        const pulse = 0.4 + Math.sin(progress * 20 + _now(scene) * 0.008) * 0.2 * progress;
                        const width = 1.5 + progress * 1.5;
                        telegraph.setStrokeStyle(width, 0xcc2222, pulse);
                    }});
                    strokePulse._startTime = _now(scene);
                    
                    // Outer converging ring — shrinks to match inner circle
                    const outerRing = _circle(scene, landX, landY, blastR * 2.5, 0xff4444, 0).setStrokeStyle(1, 0xff4444, 0.3).setDepth(2);
                    _tween(scene, { targets: outerRing, scaleX: blastR / (blastR * 2.5), scaleY: blastR / (blastR * 2.5),
                        duration: totalTelegraph, ease: 'Cubic.easeIn', onComplete: () => outerRing.destroy() });
                    
                    // Second converging ring (offset timing for layered look)
                    const midRing = _circle(scene, landX, landY, blastR * 1.8, 0xff6644, 0).setStrokeStyle(1, 0xff6644, 0.2).setDepth(2);
                    _tween(scene, { targets: midRing, scaleX: blastR / (blastR * 1.8), scaleY: blastR / (blastR * 1.8),
                        duration: totalTelegraph * 0.8, delay: totalTelegraph * 0.2, ease: 'Cubic.easeIn', onComplete: () => midRing.destroy() });
                    
                    // Crosshair lines — subtle, pulse with urgency
                    const cross1 = _rect(scene, landX, landY, blastR * 1.6, 1, 0xff3333, 0.12).setDepth(2);
                    const cross2 = _rect(scene, landX, landY, 1, blastR * 1.6, 0xff3333, 0.12).setDepth(2);
                    _tween(scene, { targets: [cross1, cross2], alpha: 0.35, duration: totalTelegraph, ease: 'Cubic.easeIn' });
                    
                    // Center X mark
                    const xSize = 4;
                    const xMark = _gfx(scene).setDepth(2);
                    xMark.lineStyle(1, 0xff4444, 0.3);
                    xMark.lineBetween(landX - xSize, landY - xSize, landX + xSize, landY + xSize);
                    xMark.lineBetween(landX + xSize, landY - xSize, landX - xSize, landY + xSize);
                    
                    // === PHASE 3: After hang time, chunk falls DOWN from top of screen ===
                    _delay(scene, hangTime, () => {
                        const chunkDown = _gfx(scene).setDepth(35);
                        chunkDown.setPosition(landX, cam.scrollY - 20);
                        // Bigger chunk coming down (grows as it approaches)
                        chunkDown.fillStyle(0x7a4422, 0.9);
                        chunkDown.fillRect(-3, -2, 6, 5);
                        chunkDown.fillStyle(0x994433, 0.6);
                        chunkDown.fillRect(-2, -1, 4, 3);
                        chunkDown.fillStyle(0x44aa33, 0.5);
                        chunkDown.fillRect(-1, 2, 2, 2);
                        
                        // Growing shadow on ground
                        const shadow = _ellipse(scene, landX, landY, 4, 2, 0x000000, 0.15).setDepth(1);
                        _tween(scene, { targets: shadow, scaleX: 4, scaleY: 4, alpha: 0.3, duration: fallTime,
                            ease: 'Cubic.easeIn', onComplete: () => shadow.destroy() });
                        
                        // Fall down
                        _tween(scene, {
                            targets: chunkDown,
                            y: landY,
                            scaleX: 2, scaleY: 2,
                            duration: fallTime,
                            ease: 'Cubic.easeIn',
                            onComplete: () => {
                                chunkDown.destroy();
                                telegraph.destroy();
                                cross1.destroy();
                                cross2.destroy();
                                xMark.destroy();
                                strokePulse.destroy();
                                if (midRing.active !== false) midRing.destroy();
                                
                                // === IMPACT ===
                                _shake(scene, 100, 0.004);
                                
                                // Check player in blast
                                const dToP = _dist(landX, landY, scene.player.x, scene.player.y);
                                if (dToP < blastR) {
                                    CombatHelper.damagePlayer(scene, dmg, {
                                        source: e, color: '#cc4422', fontSize: 10, label: ' BLAST',
                                        dot: 'toxic', shake: { duration: 80, intensity: 0.01 }
                                    });
                                }
                                
                                // Explosion ring
                                const boom = _circle(scene, landX, landY, 5, 0xaa4422, 0.8).setDepth(25);
                                _tween(scene, { targets: boom, scaleX: 3.5, scaleY: 3.5, alpha: 0, duration: 350, onComplete: () => boom.destroy() });
                                // Inner flash
                                const flash = _circle(scene, landX, landY, 3, 0xffaa66, 0.6).setDepth(26);
                                _tween(scene, { targets: flash, scaleX: 2, scaleY: 2, alpha: 0, duration: 150, onComplete: () => flash.destroy() });
                                
                                // Debris chunks flying outward
                                for (let p = 0; p < 8; p++) {
                                    const pa = Math.random() * Math.PI * 2;
                                    const pd = 8 + Math.random() * 20;
                                    const pSize = 1.5 + Math.random() * 2;
                                    const bit = _gfx(scene).setDepth(26);
                                    bit.setPosition(landX, landY);
                                    bit.fillStyle(p < 4 ? 0x6a3a22 : 0x44aa33, 0.8);
                                    bit.fillRect(-pSize/2, -pSize/2, pSize, pSize);
                                    _tween(scene, {
                                        targets: bit,
                                        x: landX + Math.cos(pa) * pd,
                                        y: landY + Math.sin(pa) * pd - 5,
                                        alpha: 0, scaleX: 0.3, scaleY: 0.3,
                                        duration: 300 + Math.random() * 200,
                                        onComplete: () => bit.destroy()
                                    });
                                }
                                
                                // === PERSISTENT TOXIC ZONE — organic acid pool ===
                                const toxGfx = _gfx(scene).setDepth(1);
                                const toxBody = _physSprite(scene, landX, landY, '__DEFAULT');
                                if (!toxBody) return;
                                toxBody.setVisible(false);
                                if (toxBody.body) toxBody.body.setSize(blastR * 1.4, blastR * 1.4);
                                toxBody._acidActive = true;
                                toxBody._acidDmg = cfg.toxicDamage || 3;
                                toxBody._tickRate = cfg.toxicTickRate || 500;
                                scene.acidPuddles.add(toxBody);
                                
                                const toxDur = cfg.blastToxicDuration || 6000;
                                const toxStart = _now(scene);
                                const toxR = blastR * 0.9;
                                // Generate fixed edge wobble points for this pool
                                const edgePts = 12;
                                const edgeWobble = [];
                                for (let ep = 0; ep < edgePts; ep++) {
                                    edgeWobble.push(0.7 + Math.random() * 0.6); // radius multiplier per edge point
                                }
                                
                                const toxRender = _addEvent(scene, { delay: 140, loop: true, callback: () => {
                                    const age = (_now(scene) - toxStart) / toxDur;
                                    if (age >= 1) {
                                        toxRender.destroy(); toxGfx.destroy();
                                        scene.acidPuddles.remove(toxBody); toxBody.destroy();
                                        return;
                                    }
                                    toxGfx.clear();
                                    const fade = age < 0.4 ? 1 : 1 - (age - 0.4) / 0.6; // full opacity 40%, then fade
                                    const r = toxR * (1 - age * 0.2);
                                    const t = _now(scene) * 0.001;
                                    
                                    // Outer irregular blob — wobbled polygon
                                    toxGfx.fillStyle(0x2a6622, 0.25 * fade);
                                    toxGfx.beginPath();
                                    for (let ep = 0; ep < edgePts; ep++) {
                                        const ea = (Math.PI * 2 / edgePts) * ep;
                                        const er = r * 1.2 * edgeWobble[ep] * (1 + Math.sin(t * 1.5 + ep) * 0.08);
                                        const ex = landX + Math.cos(ea) * er;
                                        const ey = landY + Math.sin(ea) * er * 0.7; // isometric flatten
                                        if (ep === 0) toxGfx.moveTo(ex, ey); else toxGfx.lineTo(ex, ey);
                                    }
                                    toxGfx.closePath(); toxGfx.fill();
                                    
                                    // Inner brighter core — same shape, smaller
                                    toxGfx.fillStyle(0x44aa33, 0.35 * fade);
                                    toxGfx.beginPath();
                                    for (let ep = 0; ep < edgePts; ep++) {
                                        const ea = (Math.PI * 2 / edgePts) * ep;
                                        const er = r * 0.7 * edgeWobble[ep] * (1 + Math.sin(t * 2 + ep * 1.3) * 0.1);
                                        const ex = landX + Math.cos(ea) * er;
                                        const ey = landY + Math.sin(ea) * er * 0.7;
                                        if (ep === 0) toxGfx.moveTo(ex, ey); else toxGfx.lineTo(ex, ey);
                                    }
                                    toxGfx.closePath(); toxGfx.fill();
                                    
                                    // Bright hotspot in center
                                    toxGfx.fillStyle(0x55cc44, 0.2 * fade);
                                    toxGfx.fillEllipse(landX + Math.sin(t * 3) * 3, landY + Math.cos(t * 2) * 2, r * 0.5, r * 0.35);
                                    
                                    // Bubble highlights — scattered, pulsing
                                    const bCount = Math.floor(5 * fade);
                                    for (let b = 0; b < bCount; b++) {
                                        const ba = (t * 0.8 + b * 1.3) % (Math.PI * 2);
                                        const bd = r * 0.3 + Math.sin(ba * 2.5 + b) * r * 0.35;
                                        const bSize = 1 + Math.sin(t * 3 + b * 2) * 0.5;
                                        toxGfx.fillStyle(0x77ee55, 0.25 * fade);
                                        toxGfx.fillCircle(landX + Math.cos(ba) * bd, landY + Math.sin(ba) * bd * 0.7, bSize);
                                    }
                                    
                                    // Edge drip tendrils — small extensions from outer edge
                                    for (let ep = 0; ep < edgePts; ep += 3) {
                                        if (edgeWobble[ep] > 1.0) { // only on extended points
                                            const ea = (Math.PI * 2 / edgePts) * ep;
                                            const er = r * 1.3 * edgeWobble[ep];
                                            const ex = landX + Math.cos(ea) * er;
                                            const ey = landY + Math.sin(ea) * er * 0.7;
                                            const dripLen = 3 + Math.sin(t + ep) * 2;
                                            toxGfx.fillStyle(0x338822, 0.2 * fade);
                                            toxGfx.fillEllipse(ex + Math.cos(ea) * dripLen, ey + Math.sin(ea) * dripLen * 0.7, 2, 1.5);
                                        }
                                    }
                                }});
                                
                                // === SKITTERLINGS — 1-2 spawn from each impact ===
                                const skitCount = 1 + (Math.random() < 0.5 ? 1 : 0);
                                for (let sk = 0; sk < skitCount; sk++) {
                                    _delay(scene, 200 + sk * 300, () => {
                                        if (scene.enemies.getChildren().length >= 30) return; // cap
                                        const skAngle = Math.random() * Math.PI * 2;
                                        const skX = landX + Math.cos(skAngle) * 8;
                                        const skY = landY + Math.sin(skAngle) * 8;
                                        const skit = scene.spawnEnemy(skX, skY, 'skitterling');
                                        if (skit) {
                                            // Override default spawn tween with burst-out
                                            if (_R()) _R().killTweensOf(scene, skit);
                                            _setAlpha(skit, 0); _setScale(skit, 0.2);
                                            _setTint(skit, 0x44aa33);
                                            _tween(scene, {
                                                targets: skit,
                                                alpha: 1, scaleX: 1, scaleY: 1,
                                                duration: 250,
                                                ease: 'Back.easeOut',
                                                onComplete: () => { if (skit.active) _restoreTint(skit); }
                                            });
                                            // Small green burst
                                            for (let sp = 0; sp < 4; sp++) {
                                                const pa = Math.random() * Math.PI * 2;
                                                const dot = _circle(scene, skX, skY, 1.5, 0x44aa33, 0.6).setDepth(20);
                                                _tween(scene, { targets: dot, x: skX + Math.cos(pa) * 12, y: skY + Math.sin(pa) * 12, alpha: 0, duration: 300, onComplete: () => dot.destroy() });
                                            }
                                        }
                                    });
                                }
                            }
                        });
                    });
                });
            });
        }
    },
    
    
    // === REAPER AI — towering scrap knight, axe melee ===
    // CHECK ATTACKS FIRST, then movement only if no attack triggered.
    aiReaper(scene, e, cfg, dist, angle, delta) {
        if (e._staggered || e._reaperBuilding) {
            // LOCK velocity during all buildups — prevent physics pushing enemy
            if (e._reaperBuilding && !e._reaperDashing) e.setVelocity(0, 0);
            return;
        }
        const spdM = e._speedMult || 1;
        const dt = delta || 16;
        
        // Attack timers — tick FIRST
        if (!e._arcTimer) e._arcTimer = 1500;
        if (!e._dashTimer) e._dashTimer = 5000;
        if (!e._whirlTimer) e._whirlTimer = 7000;
        if (!e._dropTimer) e._dropTimer = 10000;
        e._arcTimer += dt;
        e._dashTimer += dt;
        e._whirlTimer += dt;
        e._dropTimer += dt;
        
        // Attack priority — compute fresh angle TO PLAYER, check BEFORE movement
        const freshA = _angle(e.x, e.y, scene.player.x, scene.player.y);
        
        // 1. INFERNO DROP — long CD, any range
        if (e._dropTimer >= (cfg.dropCooldown || 16000) && dist < 200) {
            e._dropTimer = 0;
            e.setVelocity(0, 0); // ZERO before attack starts
            EnemyAI._reaperDrop(scene, e, cfg);
            return;
        }
        // 2. WHIRLWIND — close range panic defense
        if (e._whirlTimer >= (cfg.whirlwindCooldown || 11000) && dist < (cfg.whirlwindRadius || 55) + 10) {
            e._whirlTimer = 0;
            e.setVelocity(0, 0);
            EnemyAI._reaperWhirlwind(scene, e, cfg);
            return;
        }
        // 3. DASH — medium range gap closer (TOWARD player)
        if (e._dashTimer >= (cfg.dashCooldown || 9000) && dist > 50 && dist < 180) {
            e._dashTimer = 0;
            e.setVelocity(0, 0);
            EnemyAI._reaperDash(scene, e, cfg, freshA);
            return;
        }
        // 4. LIGHT ARC — basic swing at axe range
        if (e._arcTimer >= (cfg.lightArcCooldown || 3000) && dist < (cfg.lightArcRange || 65) + 15) {
            e._arcTimer = 0;
            e.setVelocity(0, 0);
            EnemyAI._reaperLightArc(scene, e, cfg, freshA);
            return;
        }
        
        // No attack triggered — NOW do movement
        const keepDist = cfg.keepDist || 80;
        const fleeR = cfg.fleeRange || 35;
        if (dist < fleeR) {
            // Too close — back up
            const flee = angle + Math.PI;
            e.setVelocity(Math.cos(flee) * cfg.chaseSpeed * 1.1 * spdM, Math.sin(flee) * cfg.chaseSpeed * 1.1 * spdM);
        } else if (dist < keepDist - 10) {
            // Close but not too close — slow orbit
            if (!e._reaperDrift || Math.random() < 0.01) e._reaperDrift = angle + (Math.random() > 0.5 ? 1 : -1) * Math.PI / 2.5;
            e.setVelocity(Math.cos(e._reaperDrift) * cfg.speed * 0.35 * spdM, Math.sin(e._reaperDrift) * cfg.speed * 0.35 * spdM);
        } else if (dist > keepDist + 40) {
            // Far — fast walk to close gap
            e.setVelocity(Math.cos(angle) * cfg.chaseSpeed * spdM, Math.sin(angle) * cfg.chaseSpeed * spdM);
        } else {
            // In sweet spot — slow approach
            e.setVelocity(Math.cos(angle) * cfg.speed * 0.4 * spdM, Math.sin(angle) * cfg.speed * 0.4 * spdM);
        }
    },
    
    // Helper: swap reaper to attack sprite, returns revert function
    _reaperSwapSprite(scene, e, attackType, frame) {
        _buildSheet(scene, attackType);
        const atkKey = `enemy_${attackType}_sheet`;
        const walkKey = 'enemy_reaper_sheet';
        if (!_texExists(scene, atkKey)) return () => {};
        const dir = e._lastDir || 0;
        _stopAnim(e)
        _setTex(e, atkKey, dir * 3 + (frame || 0));
        return () => {
            if (!e.active) return;
            _stopAnim(e)
            _setTex(e, walkKey, 0);
            try { e.anims.play(`enemy_reaper_walk_down`, true); } catch(ex) {}
        };
    },
    
    // Light arc — quick axe sweep
    _reaperLightArc(scene, e, cfg, angle) {
        if (!e.active || e._dying) return;
        e._reaperBuilding = true;
        const buildTime = _telDur('fast');
        const range = cfg.lightArcRange || 65;
        const arcAngle = cfg.lightArcAngle || 1.1;
        const dmg = Math.round((cfg.lightArcDamage || 16) * (e._dmgMult || 1));
        
        e.setVelocity(0, 0);
        
        // Telegraph: TelegraphSystem cone
        const tel = _telegraph(scene, {
            shape: 'cone', tier: 'fast', color: 'neutral',
            source: e, radius: range, angle: angle, arc: arcAngle * 2
        });
        e._activeTelegraph = tel;
        
        // Sprite: windup frame
        const revert = EnemyAI._reaperSwapSprite(scene, e, 'reaper_slash', 0);
        
        _delay(scene, buildTime, () => {
            if (!e.active || e._dying) { e._reaperBuilding = false; revert(); return; }
            
            // Sprite: swing frame
            const dir = e._lastDir || 0;
            _setFrame(e, dir * 3 + 1);
            
            // Damage check — cone in front
            const dToP = _dist(e.x, e.y, scene.player.x, scene.player.y);
            const aToP = Math.atan2(scene.player.y - e.y, scene.player.x - e.x);
            let aDiff = Math.abs(aToP - angle);
            if (aDiff > Math.PI) aDiff = Math.PI * 2 - aDiff;
            
            if (dToP < range && aDiff < arcAngle) {
                CombatHelper.damagePlayer(scene, dmg, {
                    source: e, color: '#cc8844', fontSize: 9,
                    knockback: { angle: aToP, force: 120 },
                    vfx: { weight: 'medium', angle: angle }
                });
            }
            
            // Impact slash arc VFX
            const arc = _gfx(scene).setDepth(30);
            arc.fillStyle(0xcc8844, 0.35);
            arc.beginPath(); arc.moveTo(e.x, e.y);
            for (let s = 0; s <= 6; s++) {
                const a = angle - arcAngle + (arcAngle * 2 / 6) * s;
                arc.lineTo(e.x + Math.cos(a) * range, e.y + Math.sin(a) * range);
            }
            arc.closePath(); arc.fill();
            _tween(scene, { targets: arc, alpha: 0, duration: 200, onComplete: () => arc.destroy() });
            _shake(scene, 60, 0.003);
            
            // Sprite: follow-through frame, then revert
            _delay(scene, 120, () => {
                if (e.active && !e._dying) _setFrame(e, (e._lastDir || 0) * 3 + 2);
                _delay(scene, 200, () => { revert(); e._reaperBuilding = false; });
            });
        });
    },
    
    // Dash attack — wind up, then charge TOWARD PLAYER
    _reaperDash(scene, e, cfg, angle) {
        if (!e.active || e._dying) return;
        e._reaperBuilding = true;
        const buildTime = _telDur('standard');
        const dashSpd = cfg.dashSpeed || 280;
        const dashDur = cfg.dashDuration || 300;
        const dmg = Math.round((cfg.dashDamage || 28) * (e._dmgMult || 1));
        
        e.setVelocity(0, 0);
        
        // Sprite: dash pose
        const revert = EnemyAI._reaperSwapSprite(scene, e, 'reaper_dash', 0);
        
        // Telegraph: line from reaper toward player
        const tel = _telegraph(scene, {
            shape: 'line', tier: 'standard', color: 'physical',
            source: e, length: 120, angle: angle, width: 8
        });
        e._activeTelegraph = tel;
        
        // Windup VFX — stomp dust + red pulses (character animation, not telegraph)
        let pulseCount = 0;
        const windEvt = _addEvent(scene, { delay: 160, loop: true, callback: () => {
            if (!e.active || e._dying) { windEvt.destroy(); return; }
            e.setVelocity(0, 0); // KEEP LOCKED
            pulseCount++;
            _setTint(e, pulseCount % 2 === 0 ? 0xcc4422 : 0xaa6633);
            const dust = _circle(scene, e.x + (Math.random()-0.5)*12, e.y + 20, 2, 0x998877, 0.4).setDepth(1);
            _tween(scene, { targets: dust, alpha: 0, scaleX: 2.5, scaleY: 1.5, y: dust.y - 6, duration: 300, onComplete: () => dust.destroy() });
        }});
        
        _delay(scene, buildTime, () => {
            windEvt.destroy();
            if (!e.active || e._dying) { e._reaperBuilding = false; revert(); return; }
            _restoreTint(e);
            
            // Compute fresh angle TOWARD player at moment of dash
            const dashAngle = _angle(e.x, e.y, scene.player.x, scene.player.y);
            e._reaperDashing = true;
            e.setVelocity(Math.cos(dashAngle) * dashSpd, Math.sin(dashAngle) * dashSpd);
            _setTint(e, 0xff6644);
            
            // Sprite: lunge frame
            const dir = e._lastDir || 0;
            _setFrame(e, dir * 3 + 1);
            
            _delay(scene, dashDur, () => {
                if (!e.active) return;
                e.setVelocity(0, 0);
                _restoreTint(e);
                e._reaperDashing = false;
                e._reaperBuilding = false;
                
                // Sprite: impact frame, then revert
                _setFrame(e, (e._lastDir || 0) * 3 + 2);
                _delay(scene, 250, () => revert());
                
                // Hit check at end of dash
                const dToP = _dist(e.x, e.y, scene.player.x, scene.player.y);
                if (dToP < 50) {
                    const kbA = Math.atan2(scene.player.y - e.y, scene.player.x - e.x);
                    CombatHelper.damagePlayer(scene, dmg, {
                        source: e, color: '#cc4422', fontSize: 11,
                        knockback: { angle: kbA, force: 200 },
                        vfx: { weight: 'heavy', angle: dashAngle },
                        shake: { duration: 100, intensity: 0.005 }
                    });
                }
            });
        });
    },
    
    // Whirlwind — 360° spin, multiple ticks, STAYS IN PLACE
    _reaperWhirlwind(scene, e, cfg) {
        if (!e.active || e._dying) return;
        e._reaperBuilding = true;
        const buildTime = _telDur('fast');
        const spinDur = cfg.whirlwindDuration || 1200;
        const radius = cfg.whirlwindRadius || 55;
        const tickDmg = Math.round((cfg.whirlwindDamage || 4) * (e._dmgMult || 1));
        const ticks = cfg.whirlwindTicks || 3;
        
        e.setVelocity(0, 0);
        
        // Telegraph: TelegraphSystem circle showing spin radius
        const tel = _telegraph(scene, {
            shape: 'circle', tier: 'fast', color: 'neutral',
            source: e, radius: radius
        });
        e._activeTelegraph = tel;
        
        _setTint(e, 0xdd8833);
        
        _delay(scene, buildTime, () => {
            if (!e.active || e._dying) { e._reaperBuilding = false; return; }
            
            // Sprite: spin sheet
            _buildSheet(scene, 'reaper_spin');
            const spinKey = 'enemy_reaper_spin_sheet';
            const walkKey = 'enemy_reaper_sheet';
            if (_texExists(scene, spinKey)) {
                _stopAnim(e)
                _setTex(e, spinKey, 0);
            }
            
            // Spin VFX + damage
            const spinGfx = _gfx(scene).setDepth(25);
            let spinElapsed = 0;
            let tickCount = 0;
            const tickInterval = spinDur / ticks;
            let spinFrame = 0;
            
            const spinEvt = _addEvent(scene, { delay: 50, loop: true, callback: () => {
                if (!e.active || e._dying) { spinEvt.destroy(); spinGfx.destroy(); e._reaperBuilding = false; return; }
                e.setVelocity(0, 0); // LOCKED during spin
                spinElapsed += 50;
                const progress = spinElapsed / spinDur;
                
                // Cycle frames for spin animation
                const newFrame = Math.floor(spinElapsed / 100) % 3;
                if (newFrame !== spinFrame) {
                    spinFrame = newFrame;
                    const dir = e._lastDir || 0;
                    _setFrame(e, dir * 3 + spinFrame);
                }
                
                spinGfx.clear();
                const baseAngle = progress * Math.PI * 4;
                for (let i = 0; i < 3; i++) {
                    const a = baseAngle + (Math.PI * 2 / 3) * i;
                    spinGfx.lineStyle(2, 0xcc8844, 0.4 * (1 - progress * 0.5));
                    spinGfx.beginPath();
                    spinGfx.moveTo(e.x + Math.cos(a) * 8, e.y + Math.sin(a) * 8);
                    spinGfx.lineTo(e.x + Math.cos(a) * radius, e.y + Math.sin(a) * radius);
                    spinGfx.stroke();
                }
                spinGfx.lineStyle(1, 0xdd8833, 0.25);
                spinGfx.strokeCircle(e.x, e.y, radius);
                
                // Damage tick
                if (spinElapsed >= tickInterval * (tickCount + 1)) {
                    tickCount++;
                    const dToP = _dist(e.x, e.y, scene.player.x, scene.player.y);
                    if (dToP < radius) {
                        const kbA = Math.atan2(scene.player.y - e.y, scene.player.x - e.x);
                        CombatHelper.damagePlayer(scene, tickDmg, {
                            source: e, color: '#dd8833', fontSize: 8,
                            knockback: { angle: kbA, force: 100 },
                            shake: { duration: 60, intensity: 0.003 },
                            iFrames: 200
                        });
                    }
                }
                
                if (spinElapsed >= spinDur) {
                    spinEvt.destroy();
                    spinGfx.destroy();
                    e._reaperBuilding = false;
                    _restoreTint(e);
                    // Revert sprite
                    if (_texExists(scene, walkKey)) {
                        _stopAnim(e)
                        _setTex(e, walkKey, 0);
                        try { _playAnim(e, 'enemy_reaper_walk_down', true); } catch(ex) {}
                    }
                }
            }});
        });
    },
    
    // Inferno drop — crouch, jump offscreen, fire AoE on landing
    _reaperDrop(scene, e, cfg) {
        if (!e.active || e._dying) return;
        e._reaperBuilding = true;
        const buildTime = cfg.dropBuildup || 1800;
        const blastR = cfg.dropBlastRadius || 45;
        const dmg = Math.round((cfg.dropDamage || 22) * (e._dmgMult || 1));
        
        e.setVelocity(0, 0);
        
        // Sprite: crouch sequence
        _buildSheet(scene, 'reaper_crouch');
        const crouchKey = 'enemy_reaper_crouch_sheet';
        const walkKey = 'enemy_reaper_sheet';
        if (_texExists(scene, crouchKey)) {
            _stopAnim(e)
            _setTex(e, crouchKey, 0);
            const dir = e._lastDir || 0;
            _setFrame(e, dir * 3 + 0);
            // Animate crouch frames
            _delay(scene, buildTime * 0.33, () => { if (e.active && !e._dying) _setFrame(e, dir * 3 + 1); });
            _delay(scene, buildTime * 0.66, () => { if (e.active && !e._dying) _setFrame(e, dir * 3 + 2); });
        }
        
        _setTint(e, 0xff6622);
        Blurbs.show(scene, e, 'LEAP', { color: '#ff6622', fontSize: 10, duration: 800 });
        
        // Telegraph: TelegraphSystem circle during crouch buildup
        const tel = _telegraph(scene, {
            shape: 'circle', tier: 'heavy', color: 'fire',
            source: e, radius: blastR
        });
        e._activeTelegraph = tel;
        
        _delay(scene, buildTime, () => {
            if (!e.active || e._dying) { e._reaperBuilding = false; return; }
            
            // Snapshot landing target
            const landX = scene.player.x, landY = scene.player.y;
            
            // Jump UP offscreen
            const cam = _camMain(scene);
            if (e.body) e.body.enable = false;
            _tween(scene, {
                targets: e, y: cam.scrollY - 60, alpha: 0.3, scaleX: 0.5, scaleY: 0.5,
                duration: 450, ease: 'Quad.easeIn',
                onComplete: () => {
                    if (e) e.setVisible(false);
                    
                    // Telegraph on ground — red circle with converging ring + crosshair
                    const telCircle = _circle(scene, landX, landY, blastR, 0xff4422, 0).setDepth(2);
                    telCircle.setStrokeStyle(2, 0xff4422, 0.4);
                    _tween(scene, { targets: telCircle, fillAlpha: 0.25, duration: 1200, ease: 'Cubic.easeIn' });
                    
                    // Converging outer ring
                    const outerRing = _circle(scene, landX, landY, blastR * 2.5, 0xff6622, 0).setStrokeStyle(1.5, 0xff6622, 0.35).setDepth(2);
                    _tween(scene, { targets: outerRing, scaleX: 0.4, scaleY: 0.4, duration: 1200, ease: 'Cubic.easeIn', onComplete: () => outerRing.destroy() });
                    
                    // Pulsing stroke on inner circle
                    const strokePulse = _addEvent(scene, { delay: 50, loop: true, callback: () => {
                        const progress = Math.min(1, (_now(scene) - strokePulse._startTime) / 1200);
                        const pulse = 0.4 + Math.sin(progress * 20 + _now(scene) * 0.008) * 0.2 * progress;
                        telCircle.setStrokeStyle(1.5 + progress * 1.5, 0xff4422, pulse);
                    }});
                    strokePulse._startTime = _now(scene);
                    
                    // Crosshair lines
                    const crossGfx = _gfx(scene).setDepth(2);
                    const crossEvt = _addEvent(scene, { delay: 60, loop: true, callback: () => {
                        const prog = Math.min(1, (_now(scene) - strokePulse._startTime) / 1200);
                        crossGfx.clear();
                        crossGfx.lineStyle(1, 0xff4422, 0.12 + prog * 0.2);
                        const len = blastR * 0.8;
                        crossGfx.beginPath(); crossGfx.moveTo(landX - len, landY); crossGfx.lineTo(landX + len, landY); crossGfx.stroke();
                        crossGfx.beginPath(); crossGfx.moveTo(landX, landY - len); crossGfx.lineTo(landX, landY + len); crossGfx.stroke();
                    }});
                    
                    // Cleanup on scene shutdown (player dies mid-air)
                    const dropCleanup = () => {
                        if (strokePulse) strokePulse.destroy();
                        if (crossEvt) crossEvt.destroy();
                        if (crossGfx && crossGfx.scene) crossGfx.destroy();
                        if (telCircle && telCircle.scene) telCircle.destroy();
                        if (outerRing && outerRing.scene) outerRing.destroy();
                    };
                    scene.events.once('shutdown', dropCleanup);
                    
                    // Fall after hang time
                    _delay(scene, 1200, () => {
                        scene.events.off('shutdown', dropCleanup);
                        strokePulse.destroy(); crossEvt.destroy(); crossGfx.destroy();
                        telCircle.destroy();
                        
                        // Reaper SLAMS down — use landing sprite
                        _buildSheet(scene, 'reaper_land');
                        const landKey = 'enemy_reaper_land_sheet';
                        
                        e.x = landX; e.y = landY;
                        if (e) e.setVisible(true);
                        _setAlpha(e, 1);
                        _setScale(e, 1.8);
                        if (e.body) e.body.enable = true;
                        
                        if (_texExists(scene, landKey)) {
                            _stopAnim(e)
                            _setTex(e, landKey, 0);
                            _setFrame(e, 0); // descending frame
                            _delay(scene, 80, () => { if (e.active) _setFrame(e, 1); }); // impact
                            _delay(scene, 300, () => { if (e.active) _setFrame(e, 2); }); // shockwave
                        }
                        
                        _tween(scene, { targets: e, scaleX: 1, scaleY: 1, duration: 150, ease: 'Back.easeOut' });
                        _shake(scene, 200, 0.01);
                        _restoreTint(e);
                        
                        // Blast damage
                        const dToP = _dist(landX, landY, scene.player.x, scene.player.y);
                        if (dToP < blastR) {
                            const kbA = Math.atan2(scene.player.y - landY, scene.player.x - landX);
                            CombatHelper.damagePlayer(scene, dmg, {
                                source: e, color: '#ff4422', fontSize: 11, label: ' INFERNO',
                                knockback: { angle: kbA, force: 250 },
                                vfx: { weight: 'heavy', angle: kbA },
                                dot: 'burn'
                            });
                        }
                        
                        // Fire ring VFX
                        const ring = _circle(scene, landX, landY, 8, 0xff6622, 0.4).setDepth(25);
                        _tween(scene, { targets: ring, scaleX: blastR / 8, scaleY: blastR / 8, alpha: 0, duration: 400, onComplete: () => ring.destroy() });
                        
                        // Fire particles
                        for (let p = 0; p < 10; p++) {
                            const pa = Math.random() * Math.PI * 2;
                            const pd = 5 + Math.random() * blastR * 0.8;
                            const dot = _circle(scene, landX, landY, 2 + Math.random() * 2, [0xff4422, 0xff8833, 0xffcc44][p % 3], 0.6).setDepth(25);
                            _tween(scene, { targets: dot, x: landX + Math.cos(pa) * pd, y: landY + Math.sin(pa) * pd, alpha: 0, duration: 400 + Math.random() * 200, onComplete: () => dot.destroy() });
                        }
                        
                        // Revert to idle after landing animation
                        _delay(scene, 500, () => {
                            if (e.active && _texExists(scene, walkKey)) {
                                _stopAnim(e)
                                _setTex(e, walkKey, 0);
                                try { _playAnim(e, 'enemy_reaper_walk_down', true); } catch(ex) {}
                            }
                            e._reaperBuilding = false;
                        });
                        
                        // Lingering fire zone (burn DOT on contact)
                        const fireZone = _physSprite(scene, landX, landY, '__DEFAULT');
                        if (!fireZone) return;
                        fireZone.setVisible(false); if (fireZone.body) fireZone.body.setSize(blastR * 1.5, blastR * 1.5);
                        fireZone._fireActive = true;
                        const fireGfx = _gfx(scene).setDepth(1);
                        const fireStart = _now(scene);
                        const fireDur = cfg.dropBurnDuration || 4000;
                        
                        const fireRender = _addEvent(scene, { delay: 150, loop: true, callback: () => {
                            const age = (_now(scene) - fireStart) / fireDur;
                            if (age >= 1) { fireRender.destroy(); fireGfx.destroy(); fireZone.destroy(); return; }
                            fireGfx.clear();
                            const fade = age < 0.3 ? 1 : 1 - (age - 0.3) / 0.7;
                            const r = blastR * (1 - age * 0.3);
                            fireGfx.fillStyle(0xff4422, 0.12 * fade);
                            fireGfx.fillCircle(landX, landY, r);
                            fireGfx.fillStyle(0xff8833, 0.08 * fade);
                            fireGfx.fillCircle(landX + Math.sin(_now(scene) * 0.003) * 4, landY + Math.cos(_now(scene) * 0.004) * 3, r * 0.6);
                        }});
                        
                        _physOverlap(scene, scene.player, fireZone, () => {
                            if (scene.isInvincible || scene.state.dead || !fireZone._fireActive) return;
                            DOTSystem.applyToPlayer(scene, 'burn');
                        });
                        
                        _delay(scene, fireDur, () => {
                            if (fireZone.active) { fireZone._fireActive = false; fireZone.destroy(); }
                        });
                    });
                }
            });
        });
    },
    
    // Skitterling AI — beeline to player, leap attack at close range
    aiSkitter(scene, e, cfg, dist, angle, delta) {
        if (e._detaching) return; // being flung off after detach
        const jumpRange = cfg.jumpRange || 30;
        const speed = cfg.chaseSpeed || 160;
        
        // === LATCHED STATE: follow player, tick DOT, auto-detach ===
        if (e._latched) {
            if (!scene.player.active || scene.state.dead) { EnemyAI._detachSkitterling(scene, e); return; }
            e.x = scene.player.x + e._latchOffset.x;
            e.y = scene.player.y + e._latchOffset.y;
            // Wriggle
            e._latchOffset.x += (Math.random() - 0.5) * 0.6;
            e._latchOffset.y += (Math.random() - 0.5) * 0.4;
            e._latchOffset.x = _clamp(e._latchOffset.x, -12, 12);
            e._latchOffset.y = _clamp(e._latchOffset.y, -10, 6);
            // Re-apply toxic DOT every 1.5s
            if (!e._lastDotTick) e._lastDotTick = _now(scene);
            if (_now(scene) - e._lastDotTick > 1500) {
                e._lastDotTick = _now(scene);
                DOTSystem.applyToPlayer(scene, 'toxic');
                Blurbs.show(scene, scene.player, 'GNAW', { color: '#aa8833', fontSize: 7 });
            }
            // Auto-detach after 4s
            if (_now(scene) - e._latchTime > 4000) {
                EnemyAI._detachSkitterling(scene, e);
            }
            return;
        }
        
        // Init
        if (!e._skitterInit) {
            e._skitterInit = true;
            e._jumpCooldown = 0;
            e._isJumping = false;
            e._lifeTimer = 0;
        }
        
        // Short lifespan — die after 12s
        e._lifeTimer += delta;
        if (e._lifeTimer > 12000) {
            _setTint(e, 0x333333);
            _tween(scene, { targets: e, alpha: 0, scaleX: 0.3, scaleY: 0.3, duration: 300,
                onComplete: () => { scene.killEnemy(e); }
            });
            return;
        }
        
        // Jumping state
        if (e._isJumping) return;
        
        // Cooldown
        if (e._jumpCooldown > 0) e._jumpCooldown -= delta;
        
        // In jump range — leap attack with visible vertical arc
        if (dist < jumpRange && e._jumpCooldown <= 0) {
            e._isJumping = true;
            e._jumpCooldown = cfg.attackCooldown || 800;
            const jumpDur = cfg.jumpDuration || 250;
            const jAngle = angle;
            const jDist = Math.min(dist + 8, 45);
            const arcHeight = 20; // pixels the sprite rises at peak
            
            const startX = e.x, startY = e.y;
            const endX = startX + Math.cos(jAngle) * jDist;
            const endY = startY + Math.sin(jAngle) * jDist;
            
            e.setVelocity(0, 0);
            
            // Ground shadow — stays on ground plane, moves along ground path
            const shadow = _ellipse(scene, startX, startY + 4, 10, 4, 0x000000, 0.25).setDepth(1);
            
            // Landing target — small red circle at destination
            const target = _circle(scene, endX, endY, 8, 0xaa4422, 0).setStrokeStyle(1, 0xaa4422, 0.4).setDepth(1);
            _tween(scene, { targets: target, fillAlpha: 0.15, duration: jumpDur * 0.7 });
            
            // Trigger slowdown for dodge window
            
            // Manual arc — update position each frame
            const jumpStart = _now(scene);
            const jumpUpdate = _addEvent(scene, { delay: 16, loop: true, callback: () => {
                if (!e.active) { jumpUpdate.destroy(); shadow.destroy(); target.destroy(); return; }
                const elapsed = _now(scene) - jumpStart;
                const p = Math.min(1, elapsed / jumpDur); // 0→1 progress
                
                // Ground position (linear lerp)
                const groundX = startX + (endX - startX) * p;
                const groundY = startY + (endY - startY) * p;
                
                // Arc height — sine curve, peak at midpoint
                const arc = Math.sin(p * Math.PI) * arcHeight;
                
                // Apply — sprite goes UP (negative Y), shadow stays on ground
                e.x = groundX;
                e.y = groundY - arc;
                _setScale(e, 1 + arc * 0.015); // slight size increase at peak
                
                // Shadow follows ground, shrinks/grows inverse to height
                shadow.x = groundX;
                shadow.y = groundY + 4;
                _setScale2(shadow, 1 - arc * 0.02, 1 - arc * 0.03);
                _setAlpha(shadow, 0.25 - arc * 0.005);
                
                if (p >= 1) {
                    jumpUpdate.destroy();
                    shadow.destroy();
                    target.destroy();
                    _setScale(e, 1);
                    e.x = endX;
                    e.y = endY;
                    e._isJumping = false;
                    
                    // Squash on landing
                    _tween(scene, { targets: e, scaleX: 1.3, scaleY: 0.7, duration: 60, yoyo: true });
                    
                    // === LATCH CHECK: if landed on player, attach as parasite ===
                    const landDist = _dist(e.x, e.y, scene.player.x, scene.player.y);
                    if (landDist < 22 && !scene.isInvincible && !scene.state.dead) {
                        e._latched = true;
                        e._latchTime = _now(scene);
                        e._latchOffset = { x: (Math.random() - 0.5) * 14, y: (Math.random() - 0.5) * 10 - 4 };
                        _setDepth(e, 50); // on top of player
                        e.body.enable = false; // can't be shot while latched
                        if (!scene._latchedSkitterlings) scene._latchedSkitterlings = [];
                        scene._latchedSkitterlings.push(e);
                        Blurbs.show(scene, scene.player, 'LATCHED!', { color: '#cc8833', fontSize: 9 });
                        DOTSystem.applyToPlayer(scene, 'toxic');
                        // Initial bite damage
                        let d = cfg.damage || 5;
                        const eqs = ItemManager.getEquipmentStats(scene.state.equipment);
                        if (eqs.armor > 0) d = Math.max(1, Math.round(d * (1 - eqs.armor / 100)));
                        scene.state.health -= d;
                        scene._lastCombatTime = _now(scene);
                        scene.hud.updateHP(scene.state.health, scene.state.maxHealth);
                        Blurbs.show(scene, scene.player, `-${d}`, { color: '#aa7733', fontSize: 8 });
                        _R() && _R().attackVFXPlay(scene, e.x, e.y, angle, 'light');
                    }
                    // Dust puff on landing
                    const dust = _circle(scene, e.x, e.y + 4, 4, 0x888866, 0.35).setDepth(1);
                    _tween(scene, { targets: dust, scaleX: 2.5, scaleY: 1.5, alpha: 0, duration: 300, onComplete: () => dust.destroy() });
                    // Small debris
                    for (let db = 0; db < 3; db++) {
                        const da = Math.random() * Math.PI * 2;
                        const dot = _circle(scene, e.x + Math.cos(da) * 3, e.y + 3, 1, 0x776655, 0.5).setDepth(1);
                        _tween(scene, { targets: dot, x: dot.x + Math.cos(da) * 8, y: dot.y + Math.sin(da) * 4, alpha: 0, duration: 200, onComplete: () => dot.destroy() });
                    }
                }
            }});
            return;
        }
        
        // Beeline to player — fast, direct, no personality variance
        e.setVelocity(Math.cos(angle) * speed, Math.sin(angle) * speed);
    },
    
    // Detach a latched skitterling — pop off and die
    _detachSkitterling(scene, e) {
        if (!e._latched && !e.active) return;
        e._latched = false;
        e._detaching = true; // blocks AI during fling
        if (scene._latchedSkitterlings) {
            scene._latchedSkitterlings = scene._latchedSkitterlings.filter(s => s !== e);
        }
        // Fling off with small pop — keep body disabled so AI can't fight the tween
        const flingAngle = Math.random() * Math.PI * 2;
        const flingDist = 15 + Math.random() * 10;
        _setDepth(e, 25);
        // Green splat particles
        for (let p = 0; p < 4; p++) {
            const pa = flingAngle + (Math.random() - 0.5) * 2;
            const dot = _circle(scene, e.x, e.y, 1.5, 0x66aa44, 0.5).setDepth(25);
            _tween(scene, { targets: dot, x: e.x + Math.cos(pa) * 10, y: e.y + Math.sin(pa) * 8, alpha: 0, duration: 200, onComplete: () => dot.destroy() });
        }
        Blurbs.show(scene, e, 'POP', { color: '#66aa44', fontSize: 7 });
        _tween(scene, {
            targets: e,
            x: e.x + Math.cos(flingAngle) * flingDist,
            y: e.y + Math.sin(flingAngle) * flingDist,
            scaleX: 0.3, scaleY: 0.3, alpha: 0,
            duration: 250,
            onComplete: () => { scene.killEnemy(e); }
        });
    },
    
    // Shake off all latched skitterlings (called from dodge)
    _shakeOffLatched(scene) {
        if (!scene._latchedSkitterlings || scene._latchedSkitterlings.length === 0) return;
        const toDetach = [...scene._latchedSkitterlings];
        toDetach.forEach(s => { if (s.active) EnemyAI._detachSkitterling(scene, s); });
        scene._latchedSkitterlings = [];
    },
    
    // === DEADLOCK AI — trapper/rusher. Double charge with fire trail + ground slam fire cage ===
    aiDeadlock(scene, e, cfg, dist, angle, delta) {
        if (e._staggered) return;
        if (e._deadlockCharging || e._deadlockWindup || e._deadlockSlamming || e._deadlockSlamWindup) return;
        
        const spdM = e._speedMult || 1;
        
        // Initial slam delay — first attack should be a charge for visibility
        if (!e._deadlockInitialized) {
            e._deadlockInitialized = true;
            e._slamCooldown = true;
            _delay(scene, cfg.initialSlamDelay || 3000, () => { if (e.active) e._slamCooldown = false; });
        }
        
        // --- ATTACK PRIORITY: Check attacks FIRST, then movement only if no attack ---
        
        // DOUBLE CHARGE — two rapid charges leaving fire trail (2.5s cooldown, 25-200px)
        if (!e._chargeCooldown && dist < 200 && dist > 25) {
            e._deadlockWindup = true;
            e.setVelocity(0, 0);
            
            const buildTime = _telDur('standard');
            const tel = _telegraph(scene, {
                shape: 'line', tier: 'standard', color: 'fire',
                x: e.x, y: e.y, endX: scene.player.x, endY: scene.player.y, width: 14
            });
            e._activeTelegraph = tel;
            
            // Swap to charge sprite
            _buildSheet(scene, 'deadlock_charge');
            const chargeKey = 'enemy_deadlock_charge_sheet';
            if (_texExists(scene, chargeKey)) { _stopAnim(e); _setTex(e, chargeKey, 0); }
            
            // Squash anticipation
            _tween(scene, { targets: e, scaleX: 1.15, scaleY: 0.85, yoyo: true, repeat: 2, duration: 160 });
            
            _delay(scene, buildTime, () => {
                if (!e.active) { if (tel) tel.cancel(); return; }
                e._deadlockWindup = false;
                e._activeTelegraph = null;
                
                // Execute charge 1
                EnemyAI._deadlockExecuteCharge(scene, e, cfg, 1, () => {
                    if (!e.active) return;
                    e.setVelocity(0, 0);
                    _delay(scene, 250, () => {
                        if (!e.active) return;
                        // Charge 2 — re-aim at player
                        EnemyAI._deadlockExecuteCharge(scene, e, cfg, 2, () => {
                            if (!e.active) return;
                            e._deadlockCharging = false;
                            e.setVelocity(0, 0);
                            
                            const walkKey = 'enemy_deadlock_sheet';
                            if (_texExists(scene, walkKey)) { _stopAnim(e); _setTex(e, walkKey, 0); try { _playAnim(e, 'enemy_deadlock_idle', true); } catch(x2) {} }
                            _setScale(e, 1);
                            
                            e._chargeCooldown = true;
                            _delay(scene, cfg.attackCooldown || 2500, () => { if (e.active) e._chargeCooldown = false; });
                        });
                    });
                });
            });
            return;
        }
        
        // SLAM — ground pound fire cage (14s cooldown, any range < 130px)
        if (!e._slamCooldown && dist < 130) {
            e._deadlockSlamWindup = true;
            e.setVelocity(0, 0);
            
            _buildSheet(scene, 'deadlock_slam');
            const slamKey = 'enemy_deadlock_slam_sheet';
            if (_texExists(scene, slamKey)) { _stopAnim(e); _setTex(e, slamKey, 0); }
            
            const buildTime = _telDur('heavy');
            const tel = _telegraph(scene, {
                shape: 'circle', tier: 'heavy', color: 'fire',
                source: e, radius: cfg.slamRadius || 150
            });
            e._activeTelegraph = tel;
            
            _tween(scene, { targets: e, scaleX: 1.2, scaleY: 0.8, yoyo: true, repeat: 3, duration: 200 });
            
            _delay(scene, buildTime, () => {
                if (!e.active) { if (tel) tel.cancel(); return; }
                e._deadlockSlamWindup = false;
                e._deadlockSlamming = true;
                e._activeTelegraph = null;
                
                const slamX = e.x, slamY = e.y;
                const slamR = cfg.slamRadius || 150;
                
                // Camera shake
                _shake(scene, 300, 0.02);
                
                // Screen flash
                const flash = _rect(scene, _camMain(scene).scrollX + _camMain(scene).width/2,
                    _camMain(scene).scrollY + _camMain(scene).height/2,
                    _camMain(scene).width, _camMain(scene).height, 0xff6600, 0.25).setDepth(200).setScrollFactor(0);
                _tween(scene, { targets: flash, alpha: 0, duration: 400, onComplete: () => flash.destroy() });
                
                // Damage check — inner blast
                const pdist = _dist(slamX, slamY, scene.player.x, scene.player.y);
                if (pdist < slamR * 0.55) {
                    CombatHelper.damagePlayer(scene, 22, {
                        label: 'SLAM', color: '#ff6622', shake: { duration: 150, intensity: 0.012 },
                        dot: 'burn', knockAngle: _angle(slamX, slamY, scene.player.x, scene.player.y), knockForce: 220
                    });
                }
                
                // === FIRE WALL — persistent ring of tall isometric flames ===
                const wallGfx = _gfx(scene).setDepth(15);
                const wallDuration = 6000;
                const wallStart = _now(scene);
                const wallSegments = 28;
                // Randomize ring shape — organic wobble per segment
                const wobble = [];
                for (let i = 0; i < wallSegments; i++) wobble.push(0.88 + Math.random() * 0.24);
                // Per-segment flame height variation
                const flameH = [];
                for (let i = 0; i < wallSegments; i++) flameH.push(12 + Math.random() * 10);
                
                const wallEvt = _addEvent(scene, {
                    delay: 70, loop: true,
                    callback: () => {
                        const now = _now(scene);
                        const age = (now - wallStart) / wallDuration;
                        if (age >= 1 || !e.active) { wallGfx.destroy(); wallEvt.remove(); return; }
                        
                        const fadeAlpha = age > 0.65 ? (1 - age) / 0.35 : 1;
                        wallGfx.clear();
                        
                        const tick = now * 0.006; // animation clock
                        
                        for (let i = 0; i < wallSegments; i++) {
                            const a0 = (i / wallSegments) * Math.PI * 2;
                            const aMid = ((i + 0.5) / wallSegments) * Math.PI * 2;
                            const r = slamR * wobble[i];
                            const bx = slamX + Math.cos(aMid) * r;
                            const by = slamY + Math.sin(aMid) * r;
                            
                            // === ISOMETRIC FLAME PILLAR at each segment ===
                            // ¾ iso: flames are tall vertically, squished horizontally
                            const fh = flameH[i] * (1 - age * 0.3); // shrink as wall fades
                            const fw = 6 + Math.sin(tick + i * 1.3) * 2; // width flickers
                            const flicker = Math.sin(tick * 1.5 + i * 2.1) * 2; // vertical flicker
                            
                            // Ground glow — ellipse at base
                            wallGfx.fillStyle(0xff6600, 0.2 * fadeAlpha);
                            wallGfx.fillEllipse(bx, by + 2, fw * 2.5, fw * 0.8);
                            
                            // Flame base — dark orange, wide
                            wallGfx.fillStyle(0xaa4400, 0.55 * fadeAlpha);
                            wallGfx.fillRect(bx - fw/2, by - fh * 0.3, fw, fh * 0.4);
                            
                            // Flame body — bright orange, narrower
                            const bodyW = fw * 0.7;
                            wallGfx.fillStyle(0xff6622, 0.6 * fadeAlpha);
                            wallGfx.fillRect(bx - bodyW/2, by - fh * 0.6 + flicker, bodyW, fh * 0.4);
                            
                            // Flame mid — orange-yellow
                            const midW = fw * 0.5;
                            wallGfx.fillStyle(0xff8833, 0.5 * fadeAlpha);
                            wallGfx.fillRect(bx - midW/2, by - fh * 0.8 + flicker, midW, fh * 0.3);
                            
                            // Flame tip — yellow, thin, animated
                            const tipW = fw * 0.3;
                            const tipFlick = Math.sin(tick * 2 + i * 3.7) * 3;
                            wallGfx.fillStyle(0xffcc44, 0.45 * fadeAlpha);
                            wallGfx.fillRect(bx - tipW/2 + tipFlick * 0.3, by - fh + flicker + tipFlick, tipW, fh * 0.25);
                            
                            // Hot core line — bright yellow center
                            wallGfx.fillStyle(0xffdd66, 0.35 * fadeAlpha);
                            wallGfx.fillRect(bx - 1, by - fh * 0.7 + flicker, 2, fh * 0.4);
                            
                            // Ember sparks rising from each flame
                            if (i % 3 === 0 && age < 0.8) {
                                const sparkY = by - fh - Math.sin(tick + i) * 6;
                                const sparkX = bx + Math.cos(tick * 1.3 + i) * 4;
                                wallGfx.fillStyle(0xffaa22, 0.5 * fadeAlpha);
                                wallGfx.fillRect(sparkX - 1, sparkY - 1, 2, 2);
                                // Second spark offset
                                const s2y = by - fh * 0.5 - Math.sin(tick * 0.8 + i * 2) * 4;
                                wallGfx.fillStyle(0xff8811, 0.3 * fadeAlpha);
                                wallGfx.fillRect(bx + Math.cos(tick + i * 1.7) * 3 - 1, s2y, 2, 2);
                            }
                        }
                        
                        // Connecting ground fire between pillars — smoldering base ring
                        for (let i = 0; i < wallSegments; i++) {
                            const a0 = (i / wallSegments) * Math.PI * 2;
                            const a1 = ((i + 1) / wallSegments) * Math.PI * 2;
                            const r0 = slamR * wobble[i], r1 = slamR * wobble[(i + 1) % wallSegments];
                            const x0 = slamX + Math.cos(a0) * r0, y0 = slamY + Math.sin(a0) * r0;
                            const x1 = slamX + Math.cos(a1) * r1, y1 = slamY + Math.sin(a1) * r1;
                            
                            // Ground fire strip
                            const dx = x1 - x0, dy = y1 - y0;
                            const len = Math.sqrt(dx*dx + dy*dy);
                            if (len < 0.5) continue;
                            const nx = -dy/len, ny = dx/len;
                            const hw = 4;
                            wallGfx.fillStyle(0xcc5500, 0.3 * fadeAlpha);
                            wallGfx.beginPath();
                            wallGfx.moveTo(x0 + nx*hw, y0 + ny*hw); wallGfx.lineTo(x1 + nx*hw, y1 + ny*hw);
                            wallGfx.lineTo(x1 - nx*hw, y1 - ny*hw); wallGfx.lineTo(x0 - nx*hw, y0 - ny*hw);
                            wallGfx.closePath(); wallGfx.fill();
                            // Bright inner
                            wallGfx.fillStyle(0xff8822, 0.25 * fadeAlpha);
                            wallGfx.beginPath();
                            wallGfx.moveTo(x0 + nx*2, y0 + ny*2); wallGfx.lineTo(x1 + nx*2, y1 + ny*2);
                            wallGfx.lineTo(x1 - nx*2, y1 - ny*2); wallGfx.lineTo(x0 - nx*2, y0 - ny*2);
                            wallGfx.closePath(); wallGfx.fill();
                        }
                        
                        // === BURN DOT on player if overlapping the ring ===
                        if (!scene.isInvincible && !scene.state.dead) {
                            const pd = _dist(slamX, slamY, scene.player.x, scene.player.y);
                            const innerR = slamR * 0.78, outerR = slamR * 1.08;
                            if (pd > innerR && pd < outerR) {
                                CombatHelper.damagePlayer(scene, 6, {
                                    label: 'FIRE WALL', color: '#ff6622', fontSize: 9,
                                    dot: 'burn',
                                    iFrames: 400, shake: { duration: 80, intensity: 0.005 }
                                });
                            }
                        }
                    }
                });
                
                scene.events.once('shutdown', () => { wallGfx.destroy(); wallEvt.remove(); });
                
                // Swap back to walk sprite after impact
                _delay(scene, 400, () => {
                    if (!e.active) return;
                    e._deadlockSlamming = false;
                    const walkKey = 'enemy_deadlock_sheet';
                    if (_texExists(scene, walkKey)) { _stopAnim(e); _setTex(e, walkKey, 0); try { _playAnim(e, 'enemy_deadlock_idle', true); } catch(x2) {} }
                    _setScale(e, 1);
                });
                
                // Cooldown
                e._slamCooldown = true;
                _delay(scene, cfg.slamCooldown || 14000, () => { if (e.active) e._slamCooldown = false; });
            });
            return;
        }
        
        // --- MOVEMENT: aggressive approach, orbit at ~70px ---
        if (dist > 90) {
            e.setVelocity(Math.cos(angle) * cfg.chaseSpeed * spdM, Math.sin(angle) * cfg.chaseSpeed * spdM);
        } else if (dist > 45) {
            if (!e._orbitDir) e._orbitDir = Math.random() > 0.5 ? 1 : -1;
            if (Math.random() < 0.008) e._orbitDir *= -1;
            const orbAngle = angle + (Math.PI / 2.5) * e._orbitDir;
            e.setVelocity(Math.cos(orbAngle) * cfg.speed * spdM, Math.sin(orbAngle) * cfg.speed * spdM);
        } else {
            e.setVelocity(e.body.velocity.x * 0.7, e.body.velocity.y * 0.7);
        }
    },
    
    // Execute a single Deadlock charge — leaves fire trail
    _deadlockExecuteCharge(scene, e, cfg, chargeNum, onComplete) {
        e._deadlockCharging = true;
        
        const ca = _angle(e.x, e.y, scene.player.x, scene.player.y);
        const speed = cfg.chargeSpeed || 280;
        const duration = cfg.chargeDuration || 380;
        
        e.setVelocity(Math.cos(ca) * speed, Math.sin(ca) * speed);
        
        // === FIRE TRAIL — polyline matching toxic trail quality ===
        const trailGfx = _gfx(scene).setDepth(14);
        const trailPoints = [];
        const trailDur = 4000;
        const trailStart = _now(scene);
        let trailActive = true;
        
        const recordEvt = _addEvent(scene, {
            delay: 40, loop: true,
            callback: () => {
                if (!e.active || !trailActive) { recordEvt.remove(); return; }
                trailPoints.push({ x: e.x, y: e.y, t: _now(scene) });
            }
        });
        
        const renderEvt = _addEvent(scene, {
            delay: 70, loop: true,
            callback: () => {
                const now = _now(scene);
                while (trailPoints.length > 0 && now - trailPoints[0].t > trailDur) trailPoints.shift();
                
                if (trailPoints.length < 2) {
                    if (!trailActive && trailPoints.length === 0) {
                        trailGfx.destroy(); renderEvt.remove(); return;
                    }
                    trailGfx.clear(); return;
                }
                
                trailGfx.clear();
                const pts = trailPoints;
                const tick = now * 0.005;
                
                for (let i = 0; i < pts.length - 1; i++) {
                    const p0 = pts[i], p1 = pts[i + 1];
                    const age0 = (now - p0.t) / trailDur;
                    const age1 = (now - p1.t) / trailDur;
                    const alpha0 = Math.max(0, 1 - age0 * 0.6);
                    
                    const dx = p1.x - p0.x, dy = p1.y - p0.y;
                    const len = Math.sqrt(dx * dx + dy * dy);
                    if (len < 0.5) continue;
                    const nx = -dy / len, ny = dx / len;
                    
                    const w0 = (6 + Math.sin(i * 0.6) * 2) * (1 - age0 * 0.3);
                    const w1 = (6 + Math.sin((i + 1) * 0.6) * 2) * (1 - age1 * 0.3);
                    
                    // Outer fill — dark orange
                    trailGfx.fillStyle(0xcc5500, 0.35 * alpha0);
                    trailGfx.beginPath();
                    trailGfx.moveTo(p0.x + nx * w0, p0.y + ny * w0);
                    trailGfx.lineTo(p1.x + nx * w1, p1.y + ny * w1);
                    trailGfx.lineTo(p1.x - nx * w1, p1.y - ny * w1);
                    trailGfx.lineTo(p0.x - nx * w0, p0.y - ny * w0);
                    trailGfx.closePath(); trailGfx.fill();
                    
                    // Inner core — bright orange-yellow
                    const cw0 = w0 * 0.5, cw1 = w1 * 0.5;
                    trailGfx.fillStyle(0xff8822, 0.5 * alpha0);
                    trailGfx.beginPath();
                    trailGfx.moveTo(p0.x + nx * cw0, p0.y + ny * cw0);
                    trailGfx.lineTo(p1.x + nx * cw1, p1.y + ny * cw1);
                    trailGfx.lineTo(p1.x - nx * cw1, p1.y - ny * cw1);
                    trailGfx.lineTo(p0.x - nx * cw0, p0.y - ny * cw0);
                    trailGfx.closePath(); trailGfx.fill();
                }
                
                // Ember highlights + rising sparks
                for (let i = 0; i < pts.length; i += 3) {
                    const p = pts[i];
                    const age = (now - p.t) / trailDur;
                    if (age > 0.8) continue;
                    const a = Math.max(0, 0.4 * (1 - age));
                    trailGfx.fillStyle(0xffcc44, a);
                    trailGfx.fillRect(p.x - 1, p.y - 1, 3, 3);
                    const rise = Math.sin(tick + i) * 3;
                    trailGfx.fillStyle(0xffaa22, a * 0.6);
                    trailGfx.fillRect(p.x + rise, p.y - 3 - age * 6, 2, 2);
                }
                
                // === BURN DOT on player overlapping trail ===
                if (!scene.isInvincible && !scene.state.dead && pts.length > 1) {
                    for (let i = pts.length - 1; i >= Math.max(0, pts.length - 8); i--) {
                        const p = pts[i];
                        const age = (now - p.t) / trailDur;
                        if (age > 0.7) continue;
                        const pd = _dist(p.x, p.y, scene.player.x, scene.player.y);
                        if (pd < 14) {
                            CombatHelper.damagePlayer(scene, 5, {
                                label: 'FIRE', color: '#ff8822', fontSize: 9,
                                dot: 'burn',
                                iFrames: 500, shake: { duration: 60, intensity: 0.004 }
                            });
                            break;
                        }
                    }
                }
            }
        });
        
        scene.events.once('shutdown', () => { trailGfx.destroy(); recordEvt.remove(); renderEvt.remove(); });
        
        // Charge hit detection — contact during charge
        const chargeHitEvt = _addEvent(scene, {
            delay: 50, loop: true,
            callback: () => {
                if (!e.active || !e._deadlockCharging) { chargeHitEvt.remove(); return; }
                const pd = _dist(e.x, e.y, scene.player.x, scene.player.y);
                if (pd < 32) {
                    CombatHelper.damagePlayer(scene, cfg.damage || 30, {
                        label: 'CHARGE', color: '#ff6622',
                        dot: 'burn',
                        knockAngle: ca, knockForce: 280,
                        shake: { duration: 150, intensity: 0.012 },
                        iFrames: 600
                    });
                    chargeHitEvt.remove();
                }
            }
        });
        
        // End charge after duration
        _delay(scene, duration, () => {
            if (!e.active) return;
            trailActive = false;
            recordEvt.remove();
            chargeHitEvt.remove();
            if (onComplete) onComplete();
        });
    },
    
    aiFlank(scene, e, cfg, dist, angle) {
        if (e._staggered) return;
        e.aiState = 'chase';
        const flankDist = cfg.flankDist || 80;
        
        if (!e._flankSide) e._flankSide = Math.random() < 0.5 ? 1 : -1;
        
        if (dist > flankDist * 2) {
            // Too far — approach directly
            e.setVelocity(Math.cos(angle) * cfg.chaseSpeed, Math.sin(angle) * cfg.chaseSpeed);
        } else if (dist > flankDist * 0.5) {
            // Circle around player
            const flankAngle = angle + (Math.PI / 2.5) * e._flankSide;
            e.setVelocity(Math.cos(flankAngle) * cfg.chaseSpeed, Math.sin(flankAngle) * cfg.chaseSpeed);
            
            // Occasionally switch sides
            if (Math.random() < 0.005) e._flankSide *= -1;
        } else {
            // Close enough — lunge in
            e.setVelocity(Math.cos(angle) * cfg.chaseSpeed * 1.3, Math.sin(angle) * cfg.chaseSpeed * 1.3);
        }
    },
    
    // The Spawn — overseer AI: keeps distance, spawns husks/flickers, aura buffs nearby enemies
    aiOverseer(scene, e, cfg, dist, angle, delta) {
        const spdM = e._speedMult || 1;
        const dt = delta || 16;
        const keepDist = cfg.keepDist || 140;
        const fleeDist = cfg.fleeRange || 90;
        
        // --- MOVEMENT: maintain distance from player ---
        if (dist < fleeDist) {
            // Too close — flee directly away
            const fleeAngle = angle + Math.PI;
            const fleeSpd = cfg.chaseSpeed * 1.2 * spdM;
            e.setVelocity(Math.cos(fleeAngle) * fleeSpd, Math.sin(fleeAngle) * fleeSpd);
        } else if (dist < keepDist - 20) {
            // Drift away slowly
            const driftAngle = angle + Math.PI + (Math.random() - 0.5) * 0.6;
            e.setVelocity(Math.cos(driftAngle) * cfg.speed * 0.6 * spdM, Math.sin(driftAngle) * cfg.speed * 0.6 * spdM);
        } else if (dist > keepDist + 40) {
            // Too far — follow player to stay in range
            e.setVelocity(Math.cos(angle) * cfg.speed * spdM, Math.sin(angle) * cfg.speed * spdM);
        } else {
            // Sweet spot — slow lateral drift, watching
            if (!e._driftAngle || Math.random() < 0.01) {
                e._driftAngle = angle + (Math.random() > 0.5 ? 1 : -1) * Math.PI / 2;
            }
            e.setVelocity(Math.cos(e._driftAngle) * cfg.speed * 0.3 * spdM, Math.sin(e._driftAngle) * cfg.speed * 0.3 * spdM);
        }
        
        // --- SPAWN WAVES: buildup phase then burst ---
        if (!e._spawnTimer) e._spawnTimer = 0;
        if (!e._spawnBuilding) e._spawnBuilding = false;
        if (!e._buildupTimer) e._buildupTimer = 0;
        e._spawnTimer += dt;
        const spawnRate = cfg.spawnRate || 10000;
        const buildupTime = cfg.spawnBuildupTime || 2000;
        
        if (!e._spawnBuilding && e._spawnTimer >= spawnRate && dist < (cfg.sightRange || 300)) {
            // Start buildup phase
            e._spawnBuilding = true;
            e._buildupTimer = 0;
            e._spawnBuildup = 0;
        }
        
        if (e._spawnBuilding) {
            e._buildupTimer += dt;
            e._spawnBuildup = Math.min(1, e._buildupTimer / buildupTime);
            
            // Purple pulse intensifies during buildup
            if (Math.random() < 0.15) {
                const _r = 100 + Math.floor(e._spawnBuildup * 80);
                const _g = 40;
                const _b = 160 + Math.floor(e._spawnBuildup * 60);
                _setTint(e, (_r << 16) | (_g << 8) | _b);
                _delay(scene, 100, () => { if (e.active) _restoreTint(e); });
            }
            
            if (e._buildupTimer >= buildupTime) {
                // Buildup complete — spawn enemies
                e._spawnBuilding = false;
                e._spawnTimer = 0;
                e._spawnBuildup = 0;
                
                const burst = cfg.spawnBurst || 2;
                const types = cfg.spawnTypes || ['husk', 'husk', 'flicker'];
                
                // Visual: core flash + ring
                _setTint(e, 0xaa66dd);
                _delay(scene, 300, () => { if (e.active) _restoreTint(e); });
                
                if (scene.add) {
                    const ring = _circle(scene, e.x, e.y, 20, 0x8844cc, 0.3).setDepth(5);
                    _tween(scene, { targets: ring, scaleX: 2.5, scaleY: 2.5, alpha: 0, duration: 500, onComplete: () => ring.destroy() });
                }
                
                for (let i = 0; i < burst; i++) {
                    if (scene.enemies.getLength() < 25) {
                        const sa = (Math.PI * 2 / burst) * i + Math.random() * 0.5;
                        const sx = e.x + Math.cos(sa) * 30;
                        const sy = e.y + Math.sin(sa) * 30;
                        const spawnType = types[Math.floor(Math.random() * types.length)];
                        _delay(scene, i * 200, () => {
                            if (e.active && scene.enemies.getLength() < 25) {
                                const spawned = scene.spawnSingleEnemy ? scene.spawnSingleEnemy(sx, sy, spawnType) : scene.spawnEnemy(sx, sy, spawnType);
                                // Materialization animation — phase in from nothing
                                if (spawned && spawned.active) {
                                    if (_R()) _R().killTweensOf(scene, spawned); // Stop default spawn-in tween
                                    _setAlpha(spawned, 0); _setScale(spawned, 0.1); _setTint(spawned, 0x8844cc);
                                    _tween(scene, { targets: spawned, alpha: 0.4, scaleX: 1.3, scaleY: 1.3, duration: 200, ease: 'Power2',
                                        onComplete: () => {
                                            if (!spawned.active) return;
                                            _restoreTint(spawned);
                                            _tween(scene, { targets: spawned, alpha: 1, scaleX: 1, scaleY: 1, duration: 250, ease: 'Back.easeOut' });
                                        }
                                    });
                                    // Purple particle burst at spawn point
                                    for (let p = 0; p < 5; p++) {
                                        const pa = Math.random() * Math.PI * 2;
                                        const pr = 3 + Math.random() * 8;
                                        const pSize = 2 + Math.random() * 2;
                                        const particle = _circle(scene, sx + Math.cos(pa) * 4, sy + Math.sin(pa) * 4, pSize, 0x8844cc, 0.7).setDepth(25);
                                        _tween(scene, {
                                            targets: particle,
                                            x: sx + Math.cos(pa) * pr,
                                            y: sy + Math.sin(pa) * pr,
                                            alpha: 0, scaleX: 0.2, scaleY: 0.2,
                                            duration: 300 + Math.random() * 200,
                                            onComplete: () => particle.destroy()
                                        });
                                    }
                                }
                            }
                        });
                    }
                }
                
                Blurbs.show(scene, e, 'SUMMON', { color: '#aa66dd', fontSize: 8, duration: 600 });
            }
        } else {
            e._spawnBuildup = 0;
        }
        
        // --- AURA BUFF: boost nearby enemies ---
        if (!e._auraTimer) e._auraTimer = 0;
        e._auraTimer += dt;
        if (e._auraTimer > 500) { // Check every 500ms
            e._auraTimer = 0;
            const auraR = cfg.auraRadius || 100;
            const spdBuff = cfg.auraSpeedBuff || 1.3;
            const dmgBuff = cfg.auraDamageBuff || 1.25;
            
            scene.enemies.getChildren().forEach(other => {
                if (other === e || !other.active || other._dying) return;
                if (other.enemyType === 'spawn') return; // Don't buff other spawns
                const d = _dist(e.x, e.y, other.x, other.y);
                if (d < auraR) {
                    other._spawnBuffed = true;
                    other._speedMult = spdBuff;
                    other._dmgMult = dmgBuff;
                    // Purple tint to show buffed
                    if (!other._auraFlashed) {
                        other._auraFlashed = true;
                        _setTint(other, 0x9966cc);
                        _delay(scene, 200, () => {
                            if (other.active && !other._dying) _restoreTint(other);
                            other._auraFlashed = false;
                        });
                    }
                } else if (other._spawnBuffed) {
                    // Remove buff when out of range
                    other._spawnBuffed = false;
                    other._speedMult = 1;
                    other._dmgMult = 1;
                }
            });
        }
        
        // --- AURA VISUAL: subtle ring on ground ---
        if (!e._auraGfx) e._auraGfx = _gfx(scene).setDepth(1);
        const ag = e._auraGfx;
        ag.clear();
        const aR = cfg.auraRadius || 100;
        const aPulse = 0.08 + Math.sin(_now(scene) * 0.002) * 0.04;
        ag.lineStyle(1, 0x8844cc, aPulse);
        ag.strokeCircle(e.x, e.y, aR);
        ag.fillStyle(0x6633aa, aPulse * 0.3);
        ag.fillCircle(e.x, e.y, aR);
    },
    
    aiPatrol(scene, e, cfg) {
        if (e.patrolPauseTimer > 0) {
            e.patrolPauseTimer -= 16;
            e.setVelocity(0, 0);
        } else if (e.patrolTarget) {
            const distToTarget = _dist(e.x, e.y, e.patrolTarget.x, e.patrolTarget.y);
            if (distToTarget < 25) {
                e.patrolPauseTimer = _between(500, 1500);
                e.patrolTarget = scene.getValidPatrolPoint(e.x, e.y, true);
            } else {
                const ang = _angle(e.x, e.y, e.patrolTarget.x, e.patrolTarget.y);
                const lookAhead = 30;
                if (scene.isPointInWall(e.x + Math.cos(ang) * lookAhead, e.y + Math.sin(ang) * lookAhead)) {
                    e.patrolTarget = scene.getValidPatrolPoint(e.x, e.y, true);
                } else {
                    e.setVelocity(Math.cos(ang) * cfg.speed, Math.sin(ang) * cfg.speed);
                }
            }
        }
    },
};

// =================================================================
// ENEMY MANAGER — Shared spawn/kill/contact logic across scenes
// All methods take 'scene' as first parameter.
// =================================================================
