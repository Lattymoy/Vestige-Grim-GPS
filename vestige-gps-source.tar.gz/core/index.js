// Vestige GPS — Core Module Barrel
// 27 files, ~13,159 lines
// STRICT AUDIT: 26 clean, 1 near (combatHelper: 1 guarded scene.time), 0 heavy
// All Phaser creation/framework coupling eliminated.
import { Blurbs } from './blurbs.js';
import { BossAI } from './bossAI.js';
import { CombatHelper } from './combatHelper.js';
import { CombatSystem } from './combatSystem.js';
import { ConsumableSystem } from './consumableSystem.js';
import { DOTManager } from './dotManager.js';
import { DOTSystem } from './dotSystem.js';
import { EnemyAI } from './enemyAI.js';
import { EnemyManager } from './enemyManager.js';
import { EventBus } from './eventBus.js';
import { Haptics } from './haptics.js';
import { HavenShopManager } from './havenShopManager.js';
import { ItemManager } from './itemManager.js';
import { NPCManager } from './npcManager.js';
import { PlayerProgression } from './playerProgression.js';
import { RealtimeTOD } from './realtimeTOD.js';
import { RouteGenerator } from './routeGenerator.js';
import { SaveManager } from './saveManager.js';
import { SceneTransition } from './sceneTransition.js';
import { SignatureEffects } from './signatureEffects.js';
import { StatTracker } from './statTracker.js';
import { SurvivorGenerator } from './survivorGenerator.js';
import { TerrainGenerator } from './terrainGenerator.js';
import { WeatherSystem } from './weatherSystem.js';

// === CLEAN (0 strict refs) ===
export { biomeClassifier } from './biomeClassifier.js';
export { Blurbs } from './blurbs.js';
export { BossAI } from './bossAI.js';
export { CombatSystem } from './combatSystem.js';
export { ConsumableSystem } from './consumableSystem.js';
export { DOTManager } from './dotManager.js';
export { DOTSystem } from './dotSystem.js';
export { EnemyAI } from './enemyAI.js';
export { EnemyManager } from './enemyManager.js';
export { EventBus } from './eventBus.js';
export { Haptics } from './haptics.js';
export { HavenShopManager } from './havenShopManager.js';
export { ItemManager } from './itemManager.js';
export { NPCManager } from './npcManager.js';
export { PlayerProgression } from './playerProgression.js';
export { RealtimeTOD } from './realtimeTOD.js';
export { RouteGenerator } from './routeGenerator.js';
export { SaveManager } from './saveManager.js';
export { SceneTransition } from './sceneTransition.js';
export { SignatureEffects } from './signatureEffects.js';
export { StatTracker } from './statTracker.js';
export { SurvivorGenerator } from './survivorGenerator.js';
export { TerrainGenerator } from './terrainGenerator.js';
export { utils } from './utils.js';
export { WeatherSystem } from './weatherSystem.js';

// === NEAR (1 guarded ref) ===
export { CombatHelper } from './combatHelper.js';
