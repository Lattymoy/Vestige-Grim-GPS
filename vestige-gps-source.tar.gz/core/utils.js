// Vestige GPS — Utils
// Pure logic utilities — zero rendering dependencies
import { BootScene } from '../client/scenes/BootScene.js';
import { CONFIG } from '../data/config.js';

export const Utils = {
    // Seeded random number generator
    createRNG(seed) {
        let s = seed;
        return () => {
            s = (s * 1103515245 + 12345) & 0x7fffffff;
            return s / 0x7fffffff;
        };
    },
    
    // Create RNG methods bound to a context
    attachRNG(obj, seed) {
        obj._rng = Utils.createRNG(seed);
        obj.random = () => obj._rng();
        obj.randomInt = (min, max) => Math.floor(obj.random() * (max - min + 1)) + min;
        obj.randomFromArray = (arr) => arr[Math.floor(obj.random() * arr.length)];
    }
};

// uiPx — from monolith L3165
export function uiPx(basePx) {
    return Math.max(CONFIG.uiMinPx, Math.round(basePx * CONFIG.uiScale)) + 'px';
}

// _TEXT_RES — from monolith L3196
export const _TEXT_RES = 4;

// _OrigText — from monolith L3197
// NOTE: This monkey-patches Phaser.GameObjects.Text for higher resolution text.
// Must run AFTER Phaser is loaded. Kept here as reference; wired in BootScene.
export function applyTextResolutionPatch() {
    if (typeof Phaser === 'undefined') return;
    const Orig = Phaser.GameObjects.Text;
    Phaser.GameObjects.Text = function(scene, x, y, text, style) {
        const s = style || {};
        if (!s.resolution) s.resolution = _TEXT_RES;
        if (!s.fontStyle) s.fontStyle = 'bold';
        Orig.call(this, scene, x, y, text, s);
    };
    Phaser.GameObjects.Text.prototype = Orig.prototype;
}

// _restoreTint — from monolith L30430
// Ambient-tint-aware tint restoration (returns void, NOT chainable)
export function _restoreTint(sprite) {
    if (!sprite || !sprite.active) return;
    const tint = sprite.scene ? sprite.scene._ambientTint : null;
    if (tint && tint !== 0xffffff) sprite.setTint(tint);
    else sprite.clearTint();
}
