// Vestige GPS — SleepPanel
// Extracted from monolith lines 39686-39902
// TODO: convert internal global refs to imports

import { uiPx } from '../core/utils.js';
import { CONFIG } from '../data/config.js';
import { InteractHighlight } from './interactHighlight.js';
import { UIManager } from './uiManager.js';


export const SleepPanel = {
    showBed(scene) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panel = UIManager.createPanel(scene, W/2, H/2, 240, 200, {
            title: 'REST', accent: 0x6666aa, closable: true,
            onClose: () => { scene.popupActive = false; }, depth: 200
        });
        scene.currentPopup = panel;
        const cb = panel._contentBounds;
        const timeLabels = { dawn: ' Dawn', midday: ' Midday', dusk: ' Dusk', night: ' Night' };
        const timeColors = { dawn: '#ffaa66', midday: '#ffdd88', dusk: '#cc8866', night: '#6666aa' };
        const currentTime = CONFIG.timeOfDay || 'midday';
        panel.add(scene.add.text(0, cb.y + 6, `Current: ${timeLabels[currentTime]}`, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: timeColors[currentTime] }).setOrigin(0.5));
        panel.add(scene.add.text(0, cb.y + 30, 'REST', { fontSize: uiPx(32) }).setOrigin(0.5));
        panel.add(scene.add.text(0, cb.y + 60, 'Lie down and let time pass.', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#777766' }).setOrigin(0.5));
        panel.add(UIManager.createDivider(scene, 0, cb.y + 78, cb.w - 20, { depth: 201 }));
        const wr = scene.saveData.wellRested;
        const alreadyBuffed = wr && wr.active && wr.runsRemaining > 0;
        panel.add(scene.add.text(0, cb.y + 92, alreadyBuffed ? 'Refresh Well Rested buff' : 'Gain Well Rested: +15% currency', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#6688cc' }).setOrigin(0.5));
        panel.add(scene.add.text(0, cb.y + 106, 'Lasts 3 nodes  \u2022  Advances time of day', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#555544' }).setOrigin(0.5));
        const sleepBtn = UIManager.createButton(scene, 0, cb.y + 132, 'SLEEP', {
            width: 120, height: 30, style: 'confirm', fontSize: uiPx(12), depth: 201,
            onClick: () => { panel.destroy(); scene.popupActive = false; SleepPanel.executeSleep(scene); }
        });
        panel.add(sleepBtn);
    },

    executeSleep(scene) {
        // Advance time of day to next in cycle
        const times = ['dawn', 'midday', 'dusk', 'night'];
        const currentIdx = times.indexOf(CONFIG.timeOfDay || 'midday');
        const newIdx = (currentIdx + 1) % times.length;
        CONFIG.timeOfDay = times[newIdx];
        
        // Apply Well Rested buff (reset if already active)
        scene.saveData.wellRested = { active: true, runsRemaining: 3 };
        
        scene.saveSaveData();
        
        // Play sleep transition animation
        SleepPanel.showSleepTransition(scene, times, currentIdx, newIdx);
    },

    showSleepTransition(scene, times, fromIdx, toIdx) {
        const W = CONFIG.width;
        const H = CONFIG.height;
        const cam = scene.cameras.main;
        
        // Block interactions during transition
        scene.popupActive = true;
        InteractHighlight.hide(scene);
        
        // Use Phaser's native camera fade (always works regardless of scroll)
        cam.fadeOut(400, 0, 0, 0);
        
        cam.once('camerafadeoutcomplete', () => {
            // Clear the fade FX so we can render the clock visible
            cam.resetFX();
            
            // Update safehouse window to new time
            SleepPanel.updateSafehouseTime(scene);
            
            // Black background (fixed to camera, covers viewport)
            const blackBg = scene.add.rectangle(W/2, H/2, W + 40, H + 40, 0x000000, 1).setDepth(300).setScrollFactor(0);
            
            // Create clock animation container (fixed to camera)
            const container = scene.add.container(W/2, H/2).setDepth(301).setScrollFactor(0);
                
                // === ANIMATED PIXEL CLOCK ===
                const clockR = 32;
                const clockG = scene.add.graphics();
                container.add(clockG);
                
                // Draw static clock face
                const drawClockFace = () => {
                    clockG.clear();
                    // Face background
                    clockG.fillStyle(0x0a0a18, 0.95);
                    clockG.fillCircle(0, -10, clockR);
                    clockG.lineStyle(2, 0x4a4a6a, 0.8);
                    clockG.strokeCircle(0, -10, clockR);
                    // Inner ring
                    clockG.lineStyle(1, 0x3a3a5a, 0.4);
                    clockG.strokeCircle(0, -10, clockR - 4);
                    // Tick marks at 12 positions
                    for (let i = 0; i < 12; i++) {
                        const angle = (i / 12) * Math.PI * 2 - Math.PI / 2;
                        const isQuarter = i % 3 === 0;
                        const innerR = isQuarter ? clockR - 10 : clockR - 7;
                        const outerR = clockR - 3;
                        const thickness = isQuarter ? 1.5 : 0.8;
                        clockG.lineStyle(thickness, isQuarter ? 0x8888aa : 0x555577, 0.9);
                        clockG.lineBetween(
                            Math.cos(angle) * innerR, -10 + Math.sin(angle) * innerR,
                            Math.cos(angle) * outerR, -10 + Math.sin(angle) * outerR
                        );
                    }
                    // Center dot
                    clockG.fillStyle(0xaa8855, 1);
                    clockG.fillCircle(0, -10, 2);
                };
                
                const drawHands = (hourAngle, minuteAngle) => {
                    // Minute hand (long, thin)
                    const mLen = clockR - 8;
                    clockG.lineStyle(1.5, 0x8888aa, 0.9);
                    clockG.lineBetween(0, -10, Math.cos(minuteAngle) * mLen, -10 + Math.sin(minuteAngle) * mLen);
                    // Hour hand (short, thick)
                    const hLen = clockR - 16;
                    clockG.lineStyle(2.5, 0xcc9955, 0.95);
                    clockG.lineBetween(0, -10, Math.cos(hourAngle) * hLen, -10 + Math.sin(hourAngle) * hLen);
                };
                
                // Time-of-day label below clock
                const timeLabels = { dawn: 'DAWN', midday: 'MIDDAY', dusk: 'DUSK', night: 'NIGHT' };
                const timeColors = { dawn: '#ffaa66', midday: '#ffdd88', dusk: '#cc8866', night: '#6666aa' };
                const todLabel = scene.add.text(0, clockR + 10, timeLabels[times[fromIdx]], {
                    fontFamily: CONFIG.font, fontSize: uiPx(12), fill: timeColors[times[fromIdx]], fontStyle: 'bold'
                }).setOrigin(0.5).setAlpha(0);
                container.add(todLabel);
                
                // Fade in label
                scene.tweens.add({ targets: todLabel, alpha: 1, duration: 200 });
                
                // Animate clock hands spinning forward
                // Starting angle: map fromIdx to clock position (dawn=6, midday=12, dusk=6, night=12 ... or just use quarter positions)
                const startHourAngle = (fromIdx / 4) * Math.PI * 2 - Math.PI / 2;
                const endHourAngle = ((toIdx > fromIdx ? toIdx : toIdx + 4) / 4) * Math.PI * 2 - Math.PI / 2;
                const totalRotation = endHourAngle - startHourAngle;
                
                let elapsed = 0;
                const animDuration = 1800; // 1.8 seconds
                let currentTimeIdx = fromIdx;
                
                const clockTimer = scene.time.addEvent({
                    delay: 16,
                    repeat: Math.ceil(animDuration / 16),
                    callback: () => {
                        elapsed += 16;
                        const progress = Math.min(1, elapsed / animDuration);
                        const eased = Phaser.Math.Easing.Sine.InOut(progress);
                        
                        const hourA = startHourAngle + totalRotation * eased;
                        const minuteA = startHourAngle + totalRotation * eased * 4 - Math.PI / 2; // minute spins 4x faster
                        
                        drawClockFace();
                        drawHands(hourA, minuteA);
                        
                        // Update label as time cycles
                        const cycleProgress = Math.floor(eased * (toIdx > fromIdx ? toIdx - fromIdx : toIdx - fromIdx + 4));
                        const showIdx = (fromIdx + cycleProgress) % 4;
                        if (showIdx !== currentTimeIdx) {
                            currentTimeIdx = showIdx;
                            todLabel.setText(timeLabels[times[showIdx]]);
                            todLabel.setColor(timeColors[times[showIdx]]);
                        }
                        
                        // On completion, ensure final state
                        if (progress >= 1) {
                            todLabel.setText(timeLabels[times[toIdx]]);
                            todLabel.setColor(timeColors[times[toIdx]]);
                        }
                    }
                });
                
                // After clock animation: show "WELL RESTED" then fade back
                scene.time.delayedCall(animDuration + 200, () => {
                    // Fade out clock
                    scene.tweens.add({ targets: todLabel, alpha: 0, duration: 200 });
                    scene.tweens.add({ targets: clockG, alpha: 0, duration: 200 });
                    
                    scene.time.delayedCall(300, () => {
                        const buffText = scene.add.text(0, -5, 'WELL RESTED', {
                            fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#6688cc', fontStyle: 'bold'
                        }).setOrigin(0.5).setAlpha(0);
                        container.add(buffText);
                        
                        const subText = scene.add.text(0, 14, '+15% currency for 3 nodes', {
                            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#556688'
                        }).setOrigin(0.5).setAlpha(0);
                        container.add(subText);
                        
                        scene.tweens.add({ targets: [buffText, subText], alpha: 1, duration: 300 });
                        
                        // Hold, then fade back in
                        scene.time.delayedCall(600, () => {
                            // Fade out over the clock
                            scene.cameras.main.fadeOut(300, 0, 0, 0);
                            scene.cameras.main.once('camerafadeoutcomplete', () => {
                                container.destroy();
                                blackBg.destroy();
                                
                                // Rebuild exterior so scenescape reflects new time of day
                                scene._rebuildExterior();
                                
                                // Fade back in to safehouse
                                scene.cameras.main.fadeIn(400, 0, 0, 0);
                                scene.popupActive = false;
                            });
                        });
                    });
                });
        });
    },

    updateSafehouseTime(scene) {
        // Update the window view in safehouse to reflect new time
        // The window is drawn once at create — we update its tint/color
        if (scene.safehouseWindow) {
            const skyColors = { dawn: 0xff9966, midday: 0x4488cc, dusk: 0xcc6633, night: 0x112244 };
            const tod = CONFIG.timeOfDay || 'midday';
            scene.safehouseWindow.setFillStyle(skyColors[tod]);
        }
    }
};
