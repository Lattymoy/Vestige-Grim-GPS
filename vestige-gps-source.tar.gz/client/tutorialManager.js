// Vestige GPS — TutorialManager
// Extracted from monolith L27980-28256

import { Haptics } from '../core/haptics.js';
import { SaveManager } from '../core/saveManager.js';
import { uiPx } from '../core/utils.js';
import { CONFIG } from '../data/config.js';
import { AudioManager } from './audioManager.js';
import { UIAtlas } from './uiAtlas.js';


export const TutorialManager = {
    _queue: [],        // Pending tips to show
    _active: null,     // Currently displayed tip
    _scene: null,      // Active Phaser scene ref
    _objects: [],      // Rendered objects for current tip
    _seen: {},         // Runtime cache of seen tip IDs (backed by save)
    _enabled: true,
    
    // Tip registry — populated per-scene during polish passes
    // Format: { id, scene, trigger, target, text, anchor, offset, arrow }
    TIPS: {},
    
    // Register a tip definition
    register(tipDef) {
        this.TIPS[tipDef.id] = tipDef;
    },
    

    
    // Load seen-tips from save data
    loadFromSave() {
        try {
            const data = SaveManager.load();
            if (data && data.tutorials) {
                this._seen = {};
                for (const id of data.tutorials.seen || []) this._seen[id] = true;
                if (data.tutorials.disabled) this._enabled = false;
            }
        } catch(e) {}
    },
    
    // Persist seen-tips to save data
    _saveProgress() {
        try {
            const data = SaveManager._cache || SaveManager.load();
            if (!data.tutorials) data.tutorials = { seen: [], disabled: false };
            data.tutorials.seen = Object.keys(this._seen);
            SaveManager.save(data);
        } catch(e) {}
    },
    
    // Trigger: call this when an event happens (e.g. 'firstVisit', 'openCloset')
    // Shows matching tips that haven't been seen yet
    trigger(scene, triggerName) {
        if (!this._enabled) return;
        const matching = Object.values(this.TIPS).filter(t =>
            t.trigger === triggerName &&
            t.scene === scene.scene.key &&
            !this._seen[t.id]
        );
        if (matching.length === 0) return;
        
        // Queue them in order
        for (const tip of matching) {
            if (!this._queue.find(q => q.id === tip.id)) {
                this._queue.push(tip);
            }
        }
        
        // Start showing if nothing active
        if (!this._active) this._showNext(scene);
    },
    
    // Show a specific tip by ID (for manual triggering)
    show(scene, tipId) {
        if (!this._enabled) return;
        const tip = this.TIPS[tipId];
        if (!tip || this._seen[tipId]) return;
        this._queue.unshift(tip);
        if (!this._active) this._showNext(scene);
    },
    
    // ── Internal rendering ──
    
    _showNext(scene) {
        if (this._queue.length === 0) {
            this._active = null;
            return;
        }
        
        const tip = this._queue.shift();
        this._active = tip;
        this._scene = scene;
        this._render(scene, tip);
    },
    
    _render(scene, tip) {
        this._clearObjects();
        const W = CONFIG.width, H = CONFIG.height;
        const D = 950; // Above almost everything
        
        // Semi-transparent overlay with cutout if target specified
        const overlay = scene.add.rectangle(W/2, H/2, W, H, 0x000000, 0.55)
            .setScrollFactor(0).setDepth(D).setInteractive();
        this._objects.push(overlay);
        
        // Resolve target position (can be {x,y} coords, or a game object ref)
        let targetX = W / 2, targetY = H / 2;
        let hasTarget = false;
        
        if (tip.target && typeof tip.target === 'object' && tip.target.x !== undefined) {
            // Direct game object or {x,y} pair
            targetX = tip.target.x;
            targetY = tip.target.y;
            hasTarget = true;
        } else if (tip.targetPos) {
            targetX = tip.targetPos.x;
            targetY = tip.targetPos.y;
            hasTarget = true;
        }
        
        // Highlight cutout ring around target
        if (hasTarget) {
            const hlRadius = tip.highlightRadius || 28;
            const hl = scene.add.circle(targetX, targetY, hlRadius, 0x000000, 0)
                .setStrokeStyle(2, 0xcc8844, 0.8)
                .setScrollFactor(0).setDepth(D + 1);
            this._objects.push(hl);
            
            // Pulsing ring animation
            scene.tweens.add({
                targets: hl, scaleX: 1.15, scaleY: 1.15,
                duration: 600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
            });
        }
        
        // Tooltip box position
        const anchor = tip.anchor || 'below'; // 'above', 'below', 'left', 'right', 'center'
        const ox = (tip.offset && tip.offset.x) || 0;
        const oy = (tip.offset && tip.offset.y) || 0;
        
        // Measure text to size box
        const maxTextW = W - 60;
        const textObj = scene.add.text(0, 0, tip.text, {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#ddccbb',
            wordWrap: { width: maxTextW }, align: 'center', lineSpacing: 4
        }).setOrigin(0.5).setScrollFactor(0).setDepth(D + 3);
        
        const boxPad = 14;
        const boxW = Math.min(maxTextW + boxPad * 2, textObj.width + boxPad * 2);
        const boxH = textObj.height + boxPad * 2 + 14; // extra for "tap to continue"
        
        let bx, by;
        if (anchor === 'above') {
            bx = Math.max(boxW/2 + 4, Math.min(W - boxW/2 - 4, targetX + ox));
            by = Math.max(boxH/2 + 4, targetY - 44 + oy);
        } else if (anchor === 'below') {
            bx = Math.max(boxW/2 + 4, Math.min(W - boxW/2 - 4, targetX + ox));
            by = Math.min(H - boxH/2 - 4, targetY + 44 + oy);
        } else if (anchor === 'left') {
            bx = Math.max(boxW/2 + 4, targetX - 60 + ox);
            by = Math.max(boxH/2 + 4, Math.min(H - boxH/2 - 4, targetY + oy));
        } else if (anchor === 'right') {
            bx = Math.min(W - boxW/2 - 4, targetX + 60 + ox);
            by = Math.max(boxH/2 + 4, Math.min(H - boxH/2 - 4, targetY + oy));
        } else {
            bx = W / 2 + ox;
            by = H / 2 + oy;
        }
        
        // Tooltip background
        UIAtlas.build(scene);
        const bg = scene.add.nineslice(bx, by, 'ui_panel', null, boxW, boxH,
            UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME)
            .setScrollFactor(0).setDepth(D + 2).setAlpha(0.95);
        this._objects.push(bg);
        
        // Accent line at top
        const accent = scene.add.rectangle(bx, by - boxH/2 + UIAtlas.FRAME, boxW - UIAtlas.FRAME * 2, 2, 0xcc8844, 0.6)
            .setScrollFactor(0).setDepth(D + 3);
        this._objects.push(accent);
        
        // Position text
        textObj.setPosition(bx, by - 6);
        this._objects.push(textObj);
        
        // "Tap to continue" hint
        const hint = scene.add.text(bx, by + boxH/2 - 10, 'TAP TO CONTINUE', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#665544'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(D + 3);
        this._objects.push(hint);
        
        // Arrow pointing from box to target
        if (hasTarget) {
            const arrowAngle = Math.atan2(targetY - by, targetX - bx);
            const arrowDist = Math.sqrt((targetX - bx) ** 2 + (targetY - by) ** 2);
            if (arrowDist > 30) {
                const ax = bx + Math.cos(arrowAngle) * (boxW / 2 + 4);
                const ay = by + Math.sin(arrowAngle) * (boxH / 2 + 4);
                const arrow = scene.add.triangle(ax, ay, 0, -4, 8, 0, 0, 4, 0xcc8844, 0.8)
                    .setRotation(arrowAngle).setScrollFactor(0).setDepth(D + 3);
                this._objects.push(arrow);
            }
        }
        
        // Entrance animation
        const allObjs = this._objects;
        for (const obj of allObjs) {
            if (obj !== overlay) {
                obj.setAlpha(0);
                scene.tweens.add({ targets: obj, alpha: obj === bg ? 0.95 : (obj === hint ? 0.6 : 1), duration: 250, delay: 100 });
            }
        }
        overlay.setAlpha(0);
        scene.tweens.add({ targets: overlay, alpha: 0.55, duration: 200 });
        
        // Tap to dismiss
        overlay.once('pointerdown', () => {
            AudioManager.uiClick();
            Haptics.light();
            this._dismiss(scene, tip);
        });
    },
    
    _dismiss(scene, tip) {
        // Mark as seen
        this._seen[tip.id] = true;
        this._saveProgress();
        
        // Fade out
        for (const obj of this._objects) {
            if (obj && obj.active) {
                scene.tweens.add({
                    targets: obj, alpha: 0, duration: 150,
                    onComplete: () => { if (obj && obj.destroy) obj.destroy(); }
                });
            }
        }
        this._objects = [];
        this._active = null;
        
        // Show next in queue after short delay
        scene.time.delayedCall(200, () => {
            this._showNext(scene);
        });
    },
    
    _clearObjects() {
        for (const obj of this._objects) {
            if (obj && obj.destroy) obj.destroy();
        }
        this._objects = [];
    },
    
    // Skip all pending tips
    skipAll() {
        this._queue = [];
        if (this._active && this._scene) {
            this._clearObjects();
            this._active = null;
        }
    },
    

    
    // Disable tutorial system entirely
    disable() {
        this._enabled = false;
        this.skipAll();
        try {
            const data = SaveManager._cache || SaveManager.load();
            if (!data.tutorials) data.tutorials = { seen: [], disabled: false };
            data.tutorials.disabled = true;
            SaveManager.save(data);
        } catch(e) {}
    },
    
    // Enable tutorial system
    enable() {
        this._enabled = true;
        try {
            const data = SaveManager._cache || SaveManager.load();
            if (data.tutorials) data.tutorials.disabled = false;
            SaveManager.save(data);
        } catch(e) {}
    }
};

