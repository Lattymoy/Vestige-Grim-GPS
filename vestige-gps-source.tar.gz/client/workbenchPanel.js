// Vestige GPS — WorkbenchPanel
// Extracted from monolith lines 39906-40314
// TODO: convert internal global refs to imports

import { Haptics } from '../core/haptics.js';
import { ItemManager } from '../core/itemManager.js';
import { PlayerProgression } from '../core/playerProgression.js';
import { SurvivorGenerator } from '../core/survivorGenerator.js';
import { uiPx } from '../core/utils.js';
import { CONFIG } from '../data/config.js';
import { AudioManager } from './audioManager.js';
import { DynamicShadows } from './dynamicShadows.js';
import { SpriteManager } from './spriteManager.js';
import { UIManager } from './uiManager.js';


export const WorkbenchPanel = {
    showWorkbench(scene) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panel = UIManager.createPanel(scene, W/2, H/2, 230, 265, {
            title: 'WORKBENCH', accent: 'barter', closable: true,
            onClose: () => { scene.popupActive = false; }, depth: 200
        });
        scene.currentPopup = panel;
        const cb = panel._contentBounds;
        panel.add(scene.add.text(cb.x + cb.w, cb.y - 8, `${scene.saveData.stash.materials || 0}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866' }).setOrigin(1, 0));
        const options = [
            { label: 'ENHANCE', desc: 'Upgrade weapon to +1 (augment slot)', icon: '+1', action: () => { panel.destroy(); scene.popupActive = false; WorkbenchPanel.showEnhance(scene); } },
            { label: 'REFORGE', desc: 'Reroll weapon mods', icon: 'HMR', action: () => { panel.destroy(); scene.popupActive = false; WorkbenchPanel.showReforge(scene); } },
            { label: 'VEHICLE', desc: 'Craft vehicle upgrades', icon: 'VHC', action: () => { panel.destroy(); scene.popupActive = false; WorkbenchPanel.showVehicleMods(scene); } },
            { label: 'DISMANTLE', desc: 'Scrap items for materials', icon: '', action: () => { panel.destroy(); scene.popupActive = false; WorkbenchPanel.showDismantle(scene); } },
            { label: 'CUSTOMIZE', desc: 'Customize your safehouse', icon: 'KEY', action: () => { panel.destroy(); scene.popupActive = false; scene.showCustomizeSafehouse(); } }
        ];
        if (typeof PlayerProgression !== 'undefined' && PlayerProgression.hasPerk(scene.saveData, 'soulbound_craft')) {
            options.splice(3, 0, { label: 'SOULBIND', desc: 'Protect an item from death', icon: 'SHD', action: () => { panel.destroy(); scene.popupActive = false; WorkbenchPanel.showSoulbindCraft(scene); } });
        }
        options.forEach((opt, i) => {
            const ry = cb.y + 14 + i * 45;
            const row = scene.add.container(0, ry).setDepth(201);
            const bg = scene.add.rectangle(0, 0, cb.w, 42, 0x0c0c18, 0.6);
            row.add(bg);
            row.add(scene.add.text(-cb.w/2 + 8, -8, `${opt.icon}  ${opt.label}`, { fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#aab0cc', fontStyle: 'bold' }));
            row.add(scene.add.text(-cb.w/2 + 8, 7, opt.desc, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#556655' }));
            row.add(scene.add.text(cb.w/2 - 8, 0, '>', { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#555544' }).setOrigin(0.5));
            bg.setInteractive({ useHandCursor: true })
                .on('pointerover', () => bg.setFillStyle(0x14141e))
                .on('pointerout', () => bg.setFillStyle(0x0c0c18))
                .on('pointerdown', opt.action);
            panel.add(row);
        });
    },

    showEnhance(scene) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panelW = W - 20, panelH = H - 40;
        const panel = UIManager.createPanel(scene, W/2, H/2, panelW, panelH, {
            title: 'ENHANCE', accent: 'barter', closable: true,
            onClose: () => { scene.popupActive = false; WorkbenchPanel.showWorkbench(scene); }, depth: 200
        });
        scene.currentPopup = panel;
        const cb = panel._contentBounds;
        const cost = CONFIG.enhance.cost;
        const mats = scene.saveData.stash.materials || 0;
        panel.add(scene.add.text(cb.x + cb.w, cb.y - 8, `${mats}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866' }).setOrigin(1, 0));
        panel.add(scene.add.text(0, cb.y + 4, `Enhance a weapon or melee to +1  (${cost} materials)`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#555544' }).setOrigin(0.5));
        panel.add(scene.add.text(0, cb.y + 16, 'Unlocks the augment chip slot', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#6644aa' }).setOrigin(0.5));
        
        // Collect eligible weapons/melee from stash + equipped
        const weapons = [];
        const inv = scene.saveData.stash.inventory;
        inv.forEach((item, i) => {
            if (item && (item.category === 'weapon' || item.category === 'melee' || item.category === 'gear') && !(item.enhanceLevel >= 1)) {
                weapons.push({ item, index: i, slot: null });
            }
        });
        const eq = scene.saveData.equipment;
        if (eq.weapon && !(eq.weapon.enhanceLevel >= 1)) weapons.push({ item: eq.weapon, index: -1, slot: 'weapon' });
        if (eq.melee && !(eq.melee.enhanceLevel >= 1)) weapons.push({ item: eq.melee, index: -2, slot: 'melee' });
        if (eq.gear && !(eq.gear.enhanceLevel >= 1)) weapons.push({ item: eq.gear, index: -3, slot: 'gear' });
        
        if (weapons.length === 0) {
            panel.add(scene.add.text(0, 30, 'No un-enhanced equipment available.', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#555544' }).setOrigin(0.5));
            // Also show already-enhanced items
            const enhanced = [];
            inv.forEach((item, i) => {
                if (item && (item.category === 'weapon' || item.category === 'melee' || item.category === 'gear') && item.enhanceLevel >= 1) enhanced.push(item);
            });
            if (eq.weapon?.enhanceLevel >= 1) enhanced.push(eq.weapon);
            if (eq.melee?.enhanceLevel >= 1) enhanced.push(eq.melee);
            if (eq.gear?.enhanceLevel >= 1) enhanced.push(eq.gear);
            if (enhanced.length > 0) {
                panel.add(scene.add.text(0, 50, `${enhanced.length} item(s) already at +1`, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#446644' }).setOrigin(0.5));
            }
        } else {
            const maxShow = Math.min(weapons.length, 6);
            for (let w = 0; w < maxShow; w++) {
                const { item, index, slot } = weapons[w];
                const color = ItemManager.getItemColor(item);
                const hex = '#' + color.toString(16).padStart(6, '0');
                const canAfford = mats >= cost;
                const loc = slot ? '[Equipped]' : '[Stash]';
                const ry = cb.y + 32 + w * 48;
                const row = scene.add.container(0, ry + 14).setDepth(201);
                row.add(scene.add.rectangle(0, 0, cb.w, 42, 0x0c0c18, 0.5));
                row.add(scene.add.text(-cb.w/2 + 6, -10, `${item.name}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: hex, fontStyle: 'bold' }));
                row.add(scene.add.text(-cb.w/2 + 6, 4, `${item.tierLabel || CONFIG.tiers[item.tier]?.name || ''} ${item.category} ${loc}`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#555544' }));
                const btn = UIManager.createButton(scene, cb.w/2 - 36, 0, `${cost}`, {
                    width: 60, height: 22, style: canAfford ? 'confirm' : 'danger', fontSize: uiPx(7), depth: 202,
                    onClick: canAfford ? () => WorkbenchPanel.executeEnhance(scene, item, cost, panel) : null
                });
                row.add(btn);
                panel.add(row);
            }
        }
    },

    executeEnhance(scene, item, cost, popup) {
        scene.saveData.stash.materials -= cost;
        item.enhanceLevel = 1;
        // Update name to show +1
        if (!item.name.includes('+1')) {
            item.name = item.name + ' +1';
        }
        scene.saveSaveData();
        popup.destroy();
        scene.popupActive = false;
        scene.refreshLoadoutRack();
        WorkbenchPanel.showEnhance(scene);
    },

    showReforge(scene) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panelW = W - 20, panelH = H - 40;
        const panel = UIManager.createPanel(scene, W/2, H/2, panelW, panelH, {
            title: 'REFORGE', accent: 'barter', closable: true,
            onClose: () => { scene.popupActive = false; WorkbenchPanel.showWorkbench(scene); }, depth: 200
        });
        scene.currentPopup = panel;
        const cb = panel._contentBounds;
        panel.add(scene.add.text(cb.x + cb.w, cb.y - 8, `${scene.saveData.stash.materials || 0}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866' }).setOrigin(1, 0));
        panel.add(scene.add.text(0, cb.y + 4, 'Select equipment to reroll its mods', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#555544' }).setOrigin(0.5));
        const inv = scene.saveData.stash.inventory;
        const weapons = [];
        inv.forEach((item, i) => { if (item && (item.category === 'weapon' || item.category === 'melee' || item.category === 'gear')) weapons.push({ item, index: i }); });
        const eq = scene.saveData.equipment;
        if (eq.weapon) weapons.push({ item: eq.weapon, index: -1, slot: 'weapon' });
        if (eq.melee) weapons.push({ item: eq.melee, index: -2, slot: 'melee' });
        if (eq.gear) weapons.push({ item: eq.gear, index: -3, slot: 'gear' });
        if (weapons.length === 0) {
            panel.add(scene.add.text(0, 20, 'No equipment in stash or equipped.', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#555544' }).setOrigin(0.5));
        } else {
            const maxShow = Math.min(weapons.length, 6);
            for (let w = 0; w < maxShow; w++) {
                const { item, index, slot } = weapons[w];
                const color = ItemManager.getItemColor(item);
                const hex = '#' + color.toString(16).padStart(6, '0');
                const tier = item.tier || 1;
                const rerolls = item._reforgeCount || 0;
                const baseCost = CONFIG.reforge.baseCost[Math.min(tier, 6)] || 5;
                let cost = Math.floor(baseCost * Math.pow(CONFIG.reforge.escalation, Math.min(rerolls, CONFIG.reforge.maxEscalation)));
                if (PlayerProgression.hasPerk(scene.saveData, 'reforge_discount')) cost = Math.floor(cost * 0.8);
                const canAfford = (scene.saveData.stash.materials || 0) >= cost;
                const modCount = item.mods ? item.mods.length : 0;
                const ry = cb.y + 22 + w * 48;
                const row = scene.add.container(0, ry + 14).setDepth(201);
                row.add(scene.add.rectangle(0, 0, cb.w, 42, 0x0c0c18, 0.5));
                row.add(scene.add.text(-cb.w/2 + 6, -10, `${item.icon} ${item.name}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: hex, fontStyle: 'bold' }));
                const loc = slot ? '[Equipped]' : '[Stash]';
                row.add(scene.add.text(-cb.w/2 + 6, 4, `${item.tierLabel || ''} - ${modCount} mods - ${rerolls}x reforged ${loc}`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#555544' }));
                if (modCount > 0) {
                    const btn = UIManager.createButton(scene, cb.w/2 - 36, 0, `${cost}`, {
                        width: 60, height: 22, style: canAfford ? 'confirm' : 'danger', fontSize: uiPx(7), depth: 202,
                        onClick: canAfford ? () => WorkbenchPanel.executeReforge(scene, item, index, slot, cost, panel) : null
                    });
                    row.add(btn);
                } else {
                    row.add(scene.add.text(cb.w/2 - 36, 0, 'No mods', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#444433' }).setOrigin(0.5));
                }
                panel.add(row);
            }
        }
    },

    executeReforge(scene, item, index, slot, cost, popup) {
        // Deduct materials
        scene.saveData.stash.materials -= cost;
        
        // Track reroll count on the item
        item._reforgeCount = (item._reforgeCount || 0) + 1;
        
        // Track on deployed survivor for achievements
        const _rfSurv = (scene.saveData.survivors || []).find(s => s.deployed);
        if (_rfSurv) _rfSurv.reforges = (_rfSurv.reforges || 0) + 1;
        
        // Check achievements after stat update
        if (_rfSurv) SurvivorGenerator.checkSurvivorAchievements(_rfSurv, scene.saveData);
        
        // Reroll mods — keep mod count, reroll stat types and values
        if (item.mods) {
            const poolKey = item.category === 'gear' ? 'gear' : (item.category === 'melee' ? 'melee' : 'weapon');
            const pool = CONFIG.modPools[poolKey] || [];
            const nonSpecialPool = pool.filter(m => !m.special);
            
            item.mods = item.mods.map(mod => {
                if (mod.special) return mod; // Keep soulbound etc
                if (nonSpecialPool.length === 0) return mod;
                // Use the proper generateMod pipeline to get full mod metadata
                const newMod = ItemManager.generateMod(poolKey, item.tier || 1);
                if (newMod && !newMod.special) return newMod;
                return mod; // fallback
            });
        }
        
        scene.saveSaveData();
        
        // Rebuild reforge screen
        popup.destroy();
        scene.popupActive = false;
        scene.refreshLoadoutRack();
        WorkbenchPanel.showReforge(scene);
    },

    showVehicleMods(scene) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panelW = W - 20, panelH = H - 40;
        const panel = UIManager.createPanel(scene, W/2, H/2, panelW, panelH, {
            title: 'VEHICLE MODS', accent: 'barter', closable: true,
            onClose: () => { scene.popupActive = false; WorkbenchPanel.showWorkbench(scene); }, depth: 200
        });
        scene.currentPopup = panel;
        const cb = panel._contentBounds;
        panel.add(scene.add.text(cb.x + cb.w, cb.y - 8, `${scene.saveData.stash.materials || 0}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866' }).setOrigin(1, 0));
        const vMods = scene.saveData.vehicle.mods || { weapon: -1, armor: -1, fuel: -1, utility: -1 };
        const slotKeys = ['weapon', 'armor', 'fuel', 'utility'];
        let yOff = cb.y + 4;
        slotKeys.forEach(key => {
            const slotDef = CONFIG.vehicleMods[key];
            const currentTier = vMods[key] !== undefined ? vMods[key] : -1;
            const nextTier = currentTier + 1;
            const maxed = nextTier >= slotDef.tiers.length;
            const next = maxed ? null : slotDef.tiers[nextTier];
            const current = currentTier >= 0 ? slotDef.tiers[currentTier] : null;
            const canAfford = next ? (scene.saveData.stash.materials || 0) >= next.cost : false;
            const row = scene.add.container(0, yOff + 28).setDepth(201);
            row.add(scene.add.rectangle(0, 0, cb.w, 62, 0x0c0c18, 0.5));
            row.add(scene.add.text(-cb.w/2 + 6, -22, `${slotDef.icon} ${slotDef.name}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: slotDef.color, fontStyle: 'bold' }));
            const currentLabel = current ? current.name : 'Empty';
            row.add(scene.add.text(-cb.w/2 + 6, -8, `Current: ${currentLabel}`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: current ? '#888877' : '#444433' }));
            for (let p = 0; p < slotDef.tiers.length; p++) {
                row.add(scene.add.rectangle(-cb.w/2 + 8 + p * 10, 8, 8, 4, p <= currentTier ? Phaser.Display.Color.HexStringToColor(slotDef.color).color : 0x333333, p <= currentTier ? 0.9 : 0.3));
            }
            if (maxed) {
                row.add(scene.add.text(cb.w/2 - 8, -8, 'MAX', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#555544' }).setOrigin(1, 0));
            } else {
                row.add(scene.add.text(cb.w/2 - 8, -20, next.name, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#888877' }).setOrigin(1, 0));
                row.add(scene.add.text(cb.w/2 - 8, -8, next.desc, { fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#555544', wordWrap: { width: 120 }, align: 'right' }).setOrigin(1, 0));
                const btn = UIManager.createButton(scene, cb.w/2 - 32, 14, `${next.cost}`, {
                    width: 56, height: 18, style: canAfford ? 'confirm' : 'danger', fontSize: uiPx(8), depth: 202,
                    onClick: canAfford ? () => {
                        scene.saveData.stash.materials -= next.cost;
                        scene.saveData.vehicle.mods[key] = nextTier;
                        scene.saveSaveData();
                        if (scene.vehicleStation && scene.vehicleStationPos) {
                            const pos = scene.vehicleStationPos;
                            const oldIdx = scene.stations.indexOf(scene.vehicleStation);
                            if (oldIdx >= 0) scene.stations.splice(oldIdx, 1);
                            DynamicShadows.remove(scene, scene.vehicleStation);
                            scene.vehicleStation.destroy();
                            const vs = SpriteManager.createVehicle(scene, pos.x, pos.y, 'iso');
                            vs.setDepth(10).setScale(1.4);
                            const _scn2 = scene;
                            vs.config = { id: 'vehicle', x: pos.x, y: pos.y, width: 50, height: 30, get label() { return (_scn2.saveData?.activeRoute?.status === 'locked') ? 'DEPART' : 'VEHICLE'; }, action: () => scene.showVehicleMenu() };
                            scene.stations.push(vs); scene.vehicleStation = vs;
                            DynamicShadows.add(scene, vs, { offsetY: 18, scale: 1.2 });
                        }
                        panel.destroy(); scene.popupActive = false; WorkbenchPanel.showVehicleMods(scene);
                    } : null
                });
                row.add(btn);
            }
            panel.add(row);
            yOff += 68;
        });
    },

    showDismantle(scene) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panelW = W - 20, panelH = H - 40;
        const panel = UIManager.createPanel(scene, W/2, H/2, panelW, panelH, {
            title: 'DISMANTLE', accent: 'barter', closable: true,
            onClose: () => { scene.popupActive = false; WorkbenchPanel.showWorkbench(scene); }, depth: 200
        });
        scene.currentPopup = panel;
        const cb = panel._contentBounds;
        const mats = scene.saveData.stash.materials || 0;
        scene._dismantleMatsText = scene.add.text(cb.x + cb.w, cb.y - 8, `${mats}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866' }).setOrigin(1, 0);
        panel.add(scene._dismantleMatsText);
        const inv = scene.saveData.stash.inventory;
        const scrapItems = [];
        let totalYield = 0;
        inv.forEach((item, i) => {
            if (!item) return;
            if (item.isScrap || (item.category === 'scrap')) {
                const y = item.scrapValue || [0, 2, 5, 10, 20, 40, 80][Math.min(item.tier || 1, 6)] || 2;
                const count = item.stackCount || 1;
                scrapItems.push(i); totalYield += y * count;
            }
        });
        let gridOffsetY = 0;
        if (scrapItems.length > 0) {
            const autoBtn = UIManager.createButton(scene, 0, cb.y + 10, `AUTO-SCRAP ALL JUNK (${scrapItems.length} > +${totalYield} )`, {
                width: cb.w - 8, height: 22, style: 'confirm', fontSize: uiPx(8), depth: 201,
                onClick: () => {
                    AudioManager.scrap();
                    Haptics.medium();
                    scrapItems.forEach(idx => { scene.saveData.stash.inventory[idx] = null; });
                    scene.saveData.stash.materials = (scene.saveData.stash.materials || 0) + totalYield;
                    scene.saveSaveData(); panel.destroy(); scene.popupActive = false; WorkbenchPanel.showDismantle(scene);
                }
            });
            panel.add(autoBtn);
            gridOffsetY = 28;
        }
        const gridStartY = cb.y + 8 + gridOffsetY;
        const cols = 4, cellSize = 50, gridW = cols * cellSize, gridStartX = -gridW/2;
        const allItems = [];
        const dismantleCategories = { weapon: 1, melee: 1, gear: 1, scrap: 1 };
        inv.forEach((item, i) => { if (item && dismantleCategories[item.category]) allItems.push({ item, index: i }); });
        if (allItems.length === 0) {
            panel.add(scene.add.text(0, 20, 'No items to dismantle.', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#555544' }).setOrigin(0.5));
        } else {
            allItems.forEach((entry, w) => {
                const col = w % cols, row = Math.floor(w / cols);
                const cx = gridStartX + col * cellSize + cellSize/2;
                const cy = gridStartY + row * cellSize + cellSize/2;
                const { item, index } = entry;
                const color = ItemManager.getItemColor(item);
                const tier = item.tier || 1;
                const matYield = item.scrapValue || [0, 2, 5, 10, 20, 40, 80][Math.min(tier, 6)] || 2;
                const stackCount = item.stackCount || 1;
                const finalYield = (item.isBane ? matYield * 3 : matYield) * stackCount;
                const cellBg = scene.add.rectangle(cx, cy, cellSize - 4, cellSize - 4, 0x0c0c18, 0.8).setStrokeStyle(1, color, 0.6);
                panel.add(cellBg);
                panel.add(scene.add.text(cx, cy - 8, item.icon, { fontSize: uiPx(14) }).setOrigin(0.5));
                if (stackCount > 1) {
                    panel.add(scene.add.text(cx + 14, cy - 14, `×${stackCount}`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#cccccc', fontStyle: 'bold' }).setOrigin(0.5));
                }
                panel.add(scene.add.text(cx, cy + 12, `+${finalYield}`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#aa8866' }).setOrigin(0.5));
                cellBg.setInteractive({ useHandCursor: true })
                    .on('pointerover', () => cellBg.setStrokeStyle(1, 0xaa8866))
                    .on('pointerout', () => cellBg.setStrokeStyle(1, color, 0.6))
                    .on('pointerdown', () => {
                        // Eject slotted augment back to stash before dismantling
                        if (item.augment) {
                            ItemManager.addItem(scene.saveData.stash.inventory, item.augment);
                        }
                        scene.saveData.stash.materials = (scene.saveData.stash.materials || 0) + finalYield;
                        scene.saveData.stash.inventory[index] = null;
                        scene.saveSaveData(); panel.destroy(); scene.popupActive = false; WorkbenchPanel.showDismantle(scene);
                    });
            });
        }
    },

    showSoulbindCraft(scene) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panelW = 250, panelH = 260;
        const panel = UIManager.createPanel(scene, W/2, H/2, panelW, panelH, {
            title: 'SOULBIND', accent: 0x4488ff, closable: true,
            onClose: () => { scene.popupActive = false; }, depth: 200
        });
        scene.currentPopup = panel;
        const cb = panel._contentBounds;
        const soulbindCost = 100;
        const matCount = scene.saveData.stash.materials || 0;
        panel.add(scene.add.text(cb.x + cb.w, cb.y - 8, `${matCount}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866' }).setOrigin(1, 0));
        panel.add(scene.add.text(0, cb.y + 4, `Cost: ${soulbindCost} per item`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#556' }).setOrigin(0.5));
        panel.add(UIManager.createDivider(scene, 0, cb.y + 16, cb.w - 10, { depth: 201 }));
        const inv = scene.saveData.stash.inventory || [];
        const items = [];
        inv.forEach((item, i) => {
            if (!item) return;
            const hasSoulbound = item.mods && item.mods.some(m => m.id === 'soulbound');
            if (!hasSoulbound && (item.category === 'weapon' || item.category === 'melee' || item.category === 'gear')) items.push({ item, index: i });
        });
        if (items.length === 0) {
            panel.add(scene.add.text(0, 10, 'No eligible items.\nAll items already Soulbound\nor no weapons/gear in stash.', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#556', align: 'center' }).setOrigin(0.5));
        } else {
            items.slice(0, 5).forEach((entry, i) => {
                const iy = cb.y + 26 + i * 36;
                const row = scene.add.container(0, iy + 10).setDepth(201);
                row.add(scene.add.rectangle(0, 0, cb.w - 8, 30, 0x0c0c18).setStrokeStyle(1, 0x222244));
                const item = entry.item;
                const hex = '#' + (item.tierColor || 0x888888).toString(16).padStart(6, '0');
                row.add(scene.add.text(-cb.w/2 + 12, -5, `${item.icon || '?'} ${item.name}`, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: hex }));
                const canAfford = matCount >= soulbindCost;
                const btn = UIManager.createButton(scene, cb.w/2 - 36, 0, `${soulbindCost}`, {
                    width: 52, height: 18, style: canAfford ? 'confirm' : 'danger', fontSize: uiPx(7), depth: 202,
                    onClick: canAfford ? () => {
                        scene.saveData.stash.materials -= soulbindCost;
                        if (!item.mods) item.mods = [];
                        item.mods.push({ id: 'soulbound', name: 'Soulbound', stat: 'soulbound', value: 1, unit: '', tier: 4, tierName: 'Legendary', color: 0xffaa22, special: true });
                        scene.saveSaveData();
                        panel.destroy(); scene.popupActive = false;
                        if (scene.showNotification) scene.showNotification(`Soulbound: ${item.name}`, 'legendary');
                    } : null
                });
                row.add(btn);
                panel.add(row);
            });
        }
    }
};
