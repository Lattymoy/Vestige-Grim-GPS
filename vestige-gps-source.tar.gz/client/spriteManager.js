// Vestige GPS — SpriteManager
// Extracted from monolith lines 6313-14657
// TODO: convert internal global refs to imports

import { ItemManager } from '../core/itemManager.js';
import { SaveManager } from '../core/saveManager.js';
import { Utils } from '../core/utils.js';
import { CONFIG } from '../data/config.js';
import { CrownAura } from './rendering/crownAura.js';
import { VehicleFleet } from './vehicleFleet.js';


export const SpriteManager = {
    // Track which sprites are loaded
    loaded: {},
    playerSheetReady: false,
    playerSheetCanvas: null,
    
    // Generate pixel character frames programmatically
    generatePlayerSheet(custom = null, armed = false, weaponType = 'pistol', foundryId = null, weaponItem = null) {
        const frameWidth = 48;
        const frameHeight = 48;
        const numFrames = 24;
        
        const canvas = document.createElement('canvas');
        canvas.width = frameWidth * numFrames;
        canvas.height = frameHeight;
        const ctx = canvas.getContext('2d');
        
        // Resolve customization
        const c = custom || {};
        const skinDef = CONFIG.customization.skinTones.find(s => s.id === (c.skin || 'light')) || CONFIG.customization.skinTones[0];
        const hairDef = CONFIG.customization.hairColors.find(h => h.id === (c.hair || 'brown')) || CONFIG.customization.hairColors[1];
        const hairStyle = c.hairStyle || 'short';
        const shirtDef = (c.shirt && c.shirt.base) ? c.shirt : 
            CONFIG.customization.shirtColors.find(s => s.id === (c.shirt || 'green')) || CONFIG.customization.shirtColors[0];
        const pantsDef = (c.pants && c.pants.base) ? c.pants : 
            CONFIG.customization.pantsColors.find(p => p.id === (c.pants || 'dark')) || CONFIG.customization.pantsColors[0];
        
        const colors = {
            skin: skinDef.base, skinShade: skinDef.shade,
            hair: hairDef.base, hairHL: hairDef.highlight,
            shirt: shirtDef.base, shirtLight: shirtDef.light, shirtDark: shirtDef.dark || shirtDef.base,
            pants: pantsDef.base, pantsLight: pantsDef.light,
            boots: '#1a1a1a', bootsLight: '#2a2a2a', bootSole: '#0a0a0a',
            belt: '#3a3028', buckle: '#8a8a6a',
            outline: '#111111'
        };
        
        // Gear type for overlay drawing
        const gearType = c.gearType || null;
        const G = this.GearOverlays;
        
        // Weapon style — pull from foundry palette if available
        const ws = armed ? this.getFoundryWeaponStyle(weaponType, foundryId) : { body: '#444', dark: '#333', light: '#555', barrel: 5 };
        // Pre-render weapon art for in-hand composite
        if (armed && weaponItem) {
            ws._wpnCanvas = ItemManager.renderWeaponCanvas(weaponItem);
        }
        
        const B = this.PlayerBodyParts;
        
        for (let f = 0; f < 24; f++) {
            const ox = f * frameWidth;
            const dir = Math.floor(f / 3);
            const frame = f % 3;
            const bobY = (frame === 1 || frame === 2) ? -1 : 0;
            const legSpread = frame === 0 ? 0 : (frame === 1 ? 2 : -2);
            const armSwing = frame === 0 ? 0 : (frame === 1 ? 1 : -1);
            const p = { ox, dir, frame, bobY, legSpread, armSwing, armed, ws };
            
            B.drawShadow(ctx, p, colors);
            
            if (dir === 4 || dir === 3 || dir === 5) {
                // Facing away — arms/weapon go BEHIND the body
                if (armed) B.drawArmedArms(ctx, p, colors, ws);
                else B.drawArms(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawHead) G[gearType].drawHead(ctx, p, colors);
                else B.drawHead(ctx, p, colors);
                B.drawHair(ctx, p, colors, hairStyle);
                if (gearType && G[gearType] && G[gearType].drawHeadOverlay) G[gearType].drawHeadOverlay(ctx, p, colors);
                B.drawTorso(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawTorsoOverlay) G[gearType].drawTorsoOverlay(ctx, p, colors);
                B.drawBelt(ctx, p, colors);
                B.drawLegs(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawLegOverlay) G[gearType].drawLegOverlay(ctx, p, colors);
                B.drawBoots(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawBootOverlay) G[gearType].drawBootOverlay(ctx, p, colors);
            } else {
                if (gearType && G[gearType] && G[gearType].drawHead) G[gearType].drawHead(ctx, p, colors);
                else B.drawHead(ctx, p, colors);
                B.drawHair(ctx, p, colors, hairStyle);
                B.drawEyes(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawHeadOverlay) G[gearType].drawHeadOverlay(ctx, p, colors);
                B.drawTorso(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawTorsoOverlay) G[gearType].drawTorsoOverlay(ctx, p, colors);
                B.drawBelt(ctx, p, colors);
                if (armed) B.drawArmedArms(ctx, p, colors, ws);
                else B.drawArms(ctx, p, colors);
                B.drawLegs(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawLegOverlay) G[gearType].drawLegOverlay(ctx, p, colors);
                B.drawBoots(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawBootOverlay) G[gearType].drawBootOverlay(ctx, p, colors);
            }
        }
        
        return canvas;
    },
    
    // Generate melee swing sprite sheet — 24 frames (8 dirs × 3 swing phases)
    // Same layout as the walk sheets but frames are wind-up/strike/follow-through
    generateMeleeSheet(custom = null, meleeType = 'blade', meleeItem = null) {
        const frameWidth = 48;
        const frameHeight = 48;
        const numFrames = 24;
        
        const canvas = document.createElement('canvas');
        canvas.width = frameWidth * numFrames;
        canvas.height = frameHeight;
        const ctx = canvas.getContext('2d');
        
        const c = custom || {};
        const skinDef = CONFIG.customization.skinTones.find(s => s.id === (c.skin || 'light')) || CONFIG.customization.skinTones[0];
        const hairDef = CONFIG.customization.hairColors.find(h => h.id === (c.hair || 'brown')) || CONFIG.customization.hairColors[1];
        const hairStyle = c.hairStyle || 'short';
        const shirtDef = (c.shirt && c.shirt.base) ? c.shirt : 
            CONFIG.customization.shirtColors.find(s => s.id === (c.shirt || 'green')) || CONFIG.customization.shirtColors[0];
        const pantsDef = (c.pants && c.pants.base) ? c.pants : 
            CONFIG.customization.pantsColors.find(p => p.id === (c.pants || 'dark')) || CONFIG.customization.pantsColors[0];
        
        const colors = {
            skin: skinDef.base, skinShade: skinDef.shade,
            hair: hairDef.base, hairHL: hairDef.highlight,
            shirt: shirtDef.base, shirtLight: shirtDef.light, shirtDark: shirtDef.dark || shirtDef.base,
            pants: pantsDef.base, pantsLight: pantsDef.light,
            boots: '#1a1a1a', bootsLight: '#2a2a2a', bootSole: '#0a0a0a',
            belt: '#3a3028', buckle: '#8a8a6a',
            outline: '#111111'
        };
        
        // Melee style config per type
        const meleeStyles = {
            blade: { type: 'blade', handle: '#4a3a2a', handleDark: '#3a2a1a', body: '#7a8a9a', light: '#99aabb', dark: '#5a6a7a', guard: '#8a7a5a' },
            blunt: { type: 'blunt', handle: '#4a3a2a', handleDark: '#3a2a1a', body: '#6a6a6a', light: '#8a8a8a', dark: '#4a4a4a', guard: '#5a5a5a' },
            heavy: { type: 'heavy', handle: '#4a3a2a', handleDark: '#3a2a1a', body: '#5a5a5a', light: '#7a7a7a', dark: '#3a3a3a', guard: '#6a6a6a' }
        };
        const ms = meleeStyles[meleeType] || meleeStyles.blade;
        // Pre-render melee weapon art for in-hand composite
        if (meleeItem) {
            ms._wpnCanvas = ItemManager.renderWeaponCanvas(meleeItem);
        }
        
        const gearType = c.gearType || null;
        const G = this.GearOverlays;
        const B = this.PlayerBodyParts;
        
        for (let f = 0; f < numFrames; f++) {
            const ox = f * frameWidth;
            const dir = Math.floor(f / 3);
            const frame = f % 3; // 0=wind-up, 1=strike, 2=follow-through
            const bobY = frame === 1 ? -1 : 0; // Lunge bob on strike
            const legSpread = frame === 0 ? 0 : (frame === 1 ? 2 : -1);
            const p = { ox, dir, frame, bobY, legSpread, armSwing: 0, armed: false, ws: null };
            
            B.drawShadow(ctx, p, colors);
            
            if (dir === 4 || dir === 3 || dir === 5) {
                // Facing away: melee arm behind body, then head behind torso
                B.drawMeleeSwingArms(ctx, p, colors, ms);
                if (gearType && G[gearType] && G[gearType].drawHead) G[gearType].drawHead(ctx, p, colors);
                else B.drawHead(ctx, p, colors);
                B.drawHair(ctx, p, colors, hairStyle);
            }
            
            B.drawTorso(ctx, p, colors);
            if (gearType && G[gearType] && G[gearType].drawTorsoOverlay) G[gearType].drawTorsoOverlay(ctx, p, colors);
            B.drawBelt(ctx, p, colors);
            
            // Melee swing arms for front-facing dirs (drawn after torso = in front)
            if (dir !== 4 && dir !== 3 && dir !== 5) {
                B.drawMeleeSwingArms(ctx, p, colors, ms);
            }
            
            B.drawLegs(ctx, p, colors);
            if (gearType && G[gearType] && G[gearType].drawLegOverlay) G[gearType].drawLegOverlay(ctx, p, colors);
            B.drawBoots(ctx, p, colors);
            if (gearType && G[gearType] && G[gearType].drawBootOverlay) G[gearType].drawBootOverlay(ctx, p, colors);
            
            if (dir !== 4 && dir !== 3 && dir !== 5) {
                if (gearType && G[gearType] && G[gearType].drawHead) G[gearType].drawHead(ctx, p, colors);
                else B.drawHead(ctx, p, colors);
                B.drawHair(ctx, p, colors, hairStyle);
            }
        }
        
        return canvas;
    },
    // Dir: 0=D, 1=DR, 2=R, 3=UR, 4=U, 5=UL, 6=L, 7=DL
    PlayerBodyParts: {
        drawShadow(ctx, p, c) {
            const { ox } = p;
            ctx.fillStyle = 'rgba(0,0,0,0.18)';
            ctx.beginPath();
            ctx.ellipse(ox + 24, 44, 10, 4, 0, 0, Math.PI * 2);
            ctx.fill();
        },
        
        drawHead(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const o = c.outline;
            
            if (dir === 0) {
                // Outline block
                ctx.fillStyle = o; ctx.fillRect(ox+16,7+bobY,16,14);
                // Rounded-square corners — 3px radius feel
                // Top corners
                ctx.clearRect(ox+16,7+bobY,3,1); ctx.clearRect(ox+29,7+bobY,3,1);
                ctx.clearRect(ox+16,8+bobY,2,1); ctx.clearRect(ox+30,8+bobY,2,1);
                ctx.clearRect(ox+16,9+bobY,1,1); ctx.clearRect(ox+31,9+bobY,1,1);
                // Bottom corners (jaw)
                ctx.clearRect(ox+16,20+bobY,2,1); ctx.clearRect(ox+30,20+bobY,2,1);
                ctx.clearRect(ox+16,19+bobY,1,1); ctx.clearRect(ox+31,19+bobY,1,1);
                // Skin fill
                ctx.fillStyle = c.skin; ctx.fillRect(ox+17,8+bobY,14,12);
                // Extra skin to fill rounded outline interior
                ctx.fillRect(ox+18,7+bobY,12,1);
                ctx.fillRect(ox+17,19+bobY,14,1);
                // Forehead highlight
                ctx.fillStyle = c.skin; 
                ctx.fillRect(ox+19,8+bobY,10,2);
                // Jaw shading
                ctx.fillStyle = c.skinShade; ctx.fillRect(ox+17,17+bobY,14,2);
                ctx.fillRect(ox+19,19+bobY,10,1);
                // Ears
                ctx.fillStyle = c.skinShade;
                ctx.fillRect(ox+16,12+bobY,1,4); ctx.fillRect(ox+31,12+bobY,1,4);
                // Nose
                ctx.fillRect(ox+23,15+bobY,2,2);
                
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+17;
                ctx.fillStyle=o; ctx.fillRect(bx,7+bobY,15,13);
                // Top corners
                ctx.clearRect(bx,7+bobY,3,1); ctx.clearRect(bx+12,7+bobY,3,1);
                ctx.clearRect(bx,8+bobY,2,1); ctx.clearRect(bx+13,8+bobY,2,1);
                ctx.clearRect(bx,9+bobY,1,1); ctx.clearRect(bx+14,9+bobY,1,1);
                // Bottom corners
                ctx.clearRect(bx,19+bobY,2,1); ctx.clearRect(bx+13,19+bobY,2,1);
                ctx.clearRect(bx,18+bobY,1,1); ctx.clearRect(bx+14,18+bobY,1,1);
                // Skin
                ctx.fillStyle=c.skin; ctx.fillRect(bx+1,8+bobY,13,11);
                ctx.fillRect(bx+2,7+bobY,11,1);
                // Shading on far side
                ctx.fillStyle=c.skinShade;
                if(flip) ctx.fillRect(bx+10,8+bobY,4,10);
                else ctx.fillRect(bx+1,8+bobY,4,10);
                ctx.fillRect(bx+3,17+bobY,8,1);
                // Ear
                if(flip) ctx.fillRect(bx+14,12+bobY,1,3);
                else ctx.fillRect(bx,12+bobY,1,3);
                
            } else if (dir===2||dir===6) {
                const flip=dir===6, bx=flip?ox+13:ox+19;
                ctx.fillStyle=o; ctx.fillRect(bx,7+bobY,13,13);
                // Top corners
                ctx.clearRect(bx,7+bobY,3,1); ctx.clearRect(bx+10,7+bobY,3,1);
                ctx.clearRect(bx,8+bobY,2,1); ctx.clearRect(bx+11,8+bobY,2,1);
                ctx.clearRect(bx,9+bobY,1,1); ctx.clearRect(bx+12,9+bobY,1,1);
                // Bottom corners
                ctx.clearRect(bx,19+bobY,2,1); ctx.clearRect(bx+11,19+bobY,2,1);
                ctx.clearRect(bx,18+bobY,1,1); ctx.clearRect(bx+12,18+bobY,1,1);
                // Skin
                ctx.fillStyle=c.skin; ctx.fillRect(bx+1,8+bobY,11,11);
                ctx.fillRect(bx+2,7+bobY,9,1);
                ctx.fillStyle=c.skinShade;
                if(flip) ctx.fillRect(bx+8,8+bobY,4,10);
                else ctx.fillRect(bx+1,8+bobY,4,10);
                // Nose bump
                ctx.fillStyle=c.skin;
                if(flip) ctx.fillRect(bx-1,13+bobY,2,3);
                else ctx.fillRect(bx+12,13+bobY,2,3);
                ctx.fillStyle=c.skinShade; ctx.fillRect(bx+2,17+bobY,8,1);
                
            } else if (dir===3||dir===5) {
                const flip=dir===5, bx=flip?ox+14:ox+17;
                ctx.fillStyle=o; ctx.fillRect(bx,7+bobY,15,13);
                // Top corners
                ctx.clearRect(bx,7+bobY,3,1); ctx.clearRect(bx+12,7+bobY,3,1);
                ctx.clearRect(bx,8+bobY,2,1); ctx.clearRect(bx+13,8+bobY,2,1);
                ctx.clearRect(bx,9+bobY,1,1); ctx.clearRect(bx+14,9+bobY,1,1);
                // Bottom corners
                ctx.clearRect(bx,19+bobY,2,1); ctx.clearRect(bx+13,19+bobY,2,1);
                ctx.clearRect(bx,18+bobY,1,1); ctx.clearRect(bx+14,18+bobY,1,1);
                // Skin
                ctx.fillStyle=c.skinShade; ctx.fillRect(bx+1,8+bobY,13,11);
                ctx.fillRect(bx+2,7+bobY,11,1);
                ctx.fillStyle=c.skin;
                if(flip) ctx.fillRect(bx+1,14+bobY,3,4);
                else ctx.fillRect(bx+11,14+bobY,3,4);
                ctx.fillStyle=c.skinShade; ctx.fillRect(bx+4,18+bobY,6,2);
                
            } else if (dir===4) {
                ctx.fillStyle=o; ctx.fillRect(ox+16,7+bobY,16,14);
                // Top corners
                ctx.clearRect(ox+16,7+bobY,3,1); ctx.clearRect(ox+29,7+bobY,3,1);
                ctx.clearRect(ox+16,8+bobY,2,1); ctx.clearRect(ox+30,8+bobY,2,1);
                ctx.clearRect(ox+16,9+bobY,1,1); ctx.clearRect(ox+31,9+bobY,1,1);
                // Bottom corners
                ctx.clearRect(ox+16,20+bobY,2,1); ctx.clearRect(ox+30,20+bobY,2,1);
                ctx.clearRect(ox+16,19+bobY,1,1); ctx.clearRect(ox+31,19+bobY,1,1);
                // Skin
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+17,8+bobY,14,12);
                ctx.fillRect(ox+18,7+bobY,12,1);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+20,19+bobY,8,2);
            }
        },
        
        drawEyes(ctx, p, c) {
            const { ox, dir, bobY } = p;
            if (dir===0) {
                ctx.fillStyle='#e8e8e8'; ctx.fillRect(ox+19,13+bobY,4,3); ctx.fillRect(ox+25,13+bobY,4,3);
                ctx.fillStyle='#1a2a3a'; ctx.fillRect(ox+20,13+bobY,3,3); ctx.fillRect(ox+26,13+bobY,3,3);
                ctx.fillStyle='#ffffff'; ctx.fillRect(ox+21,13+bobY,1,1); ctx.fillRect(ox+27,13+bobY,1,1);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+18,12+bobY,5,1); ctx.fillRect(ox+24,12+bobY,5,1);
            } else if (dir===1) {
                ctx.fillStyle='#e8e8e8'; ctx.fillRect(ox+25,13+bobY,4,3);
                ctx.fillStyle='#1a2a3a'; ctx.fillRect(ox+26,13+bobY,3,3);
                ctx.fillStyle='#ffffff'; ctx.fillRect(ox+27,13+bobY,1,1);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+24,12+bobY,5,1);
            } else if (dir===7) {
                ctx.fillStyle='#e8e8e8'; ctx.fillRect(ox+18,13+bobY,4,3);
                ctx.fillStyle='#1a2a3a'; ctx.fillRect(ox+18,13+bobY,3,3);
                ctx.fillStyle='#ffffff'; ctx.fillRect(ox+19,13+bobY,1,1);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+18,12+bobY,5,1);
            } else if (dir===2) {
                ctx.fillStyle='#e8e8e8'; ctx.fillRect(ox+28,13+bobY,3,2);
                ctx.fillStyle='#1a2a3a'; ctx.fillRect(ox+29,13+bobY,2,2);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+27,12+bobY,4,1);
            } else if (dir===6) {
                ctx.fillStyle='#e8e8e8'; ctx.fillRect(ox+16,13+bobY,3,2);
                ctx.fillStyle='#1a2a3a'; ctx.fillRect(ox+16,13+bobY,2,2);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+16,12+bobY,4,1);
            }
        },
        
        drawHair(ctx, p, c, style) {
            const { ox, dir, bobY } = p;
            if (style==='bald') return;
            const h=c.hair, hl=c.hairHL;
            
            // Buzzed helper — thin stubble shadow on skull
            const buzzTint = (x, y, w, h2) => {
                ctx.fillStyle = h; ctx.globalAlpha = 0.35;
                ctx.fillRect(x, y, w, 2);
                ctx.globalAlpha = 0.25;
                ctx.fillRect(x+1, y+2, w-2, h2 || 1);
                ctx.globalAlpha = 1.0;
            };
            
            if (dir===0) {
                // FRONT — head is 16w (ox+16 to ox+32), top at y=7
                if(style==='mohawk'){
                    // Front view: seeing the fin edge-on — narrow but tall
                    ctx.fillStyle=h;
                    ctx.fillRect(ox+20,5+bobY,8,4);  // base sits on skull
                    ctx.fillRect(ox+21,2+bobY,6,4);  // mid rise
                    ctx.fillRect(ox+22,0+bobY,4,3);  // peak
                    ctx.fillStyle=hl;
                    ctx.fillRect(ox+21,3+bobY,6,3);  // highlight
                    ctx.fillRect(ox+23,1+bobY,2,2);  // tip highlight
                } else if(style==='long'){
                    // Full coverage top + side curtains past ears
                    ctx.fillStyle=h;
                    ctx.fillRect(ox+16,5+bobY,16,7);
                    ctx.fillRect(ox+15,7+bobY,1,5);
                    ctx.fillRect(ox+32,7+bobY,1,5);
                    ctx.fillRect(ox+15,10+bobY,3,9);
                    ctx.fillRect(ox+30,10+bobY,3,9);
                    ctx.fillStyle=hl;
                    ctx.fillRect(ox+17,6+bobY,14,4);
                    ctx.fillRect(ox+16,10+bobY,2,6);
                    ctx.fillRect(ox+30,10+bobY,2,6);
                } else if(style==='buzzed'){
                    buzzTint(ox+17,6+bobY,14,2);
                    ctx.fillStyle=h; ctx.globalAlpha=0.2;
                    ctx.fillRect(ox+16,9+bobY,1,3); ctx.fillRect(ox+31,9+bobY,1,3);
                    ctx.globalAlpha=1.0;
                } else {
                    // SHORT — full head of hair: top, sides wrapping down, bangs
                    ctx.fillStyle=h;
                    ctx.fillRect(ox+16,5+bobY,16,6); // top cap full width
                    ctx.fillRect(ox+15,7+bobY,2,6);  // left side wraps down past ear
                    ctx.fillRect(ox+31,7+bobY,2,6);  // right side wraps down past ear
                    ctx.fillStyle=hl;
                    ctx.fillRect(ox+17,6+bobY,14,4); // top highlight
                    ctx.fillRect(ox+16,8+bobY,1,4);  // left side highlight
                    ctx.fillRect(ox+31,8+bobY,1,4);  // right side highlight
                }
            } else if (dir===1||dir===7) {
                // DIAGONAL FRONT — head is 15w
                const flip=dir===7, bx=flip?ox+14:ox+17;
                if(style==='mohawk'){
                    // Diagonal front: ridge at angle across skull top
                    ctx.fillStyle=h;
                    ctx.fillRect(bx+3,5+bobY,9,3);   // base ridge
                    ctx.fillRect(bx+4,3+bobY,7,3);   // mid rise
                    ctx.fillRect(bx+5,1+bobY,5,3);   // peak
                    ctx.fillStyle=hl;
                    ctx.fillRect(bx+4,4+bobY,7,2);
                    ctx.fillRect(bx+6,2+bobY,3,2);
                } else if(style==='long'){
                    ctx.fillStyle=h;
                    ctx.fillRect(bx,5+bobY,15,7);
                    if(flip){ ctx.fillRect(bx+13,10+bobY,3,8); ctx.fillRect(bx-1,7+bobY,2,5); }
                    else { ctx.fillRect(bx-1,10+bobY,3,8); ctx.fillRect(bx+14,7+bobY,2,5); }
                    ctx.fillStyle=hl;
                    ctx.fillRect(bx+1,6+bobY,13,4);
                    if(flip) ctx.fillRect(bx+13,11+bobY,2,5);
                    else ctx.fillRect(bx,11+bobY,2,5);
                } else if(style==='buzzed'){
                    buzzTint(bx+1,6+bobY,13,2);
                } else {
                    // SHORT — full coverage with sides
                    ctx.fillStyle=h;
                    ctx.fillRect(bx,5+bobY,15,6); // top
                    if(flip){
                        ctx.fillRect(bx-1,7+bobY,2,6);  // near side wraps down
                        ctx.fillRect(bx+14,7+bobY,2,5);  // far side
                    } else {
                        ctx.fillRect(bx+14,7+bobY,2,6);
                        ctx.fillRect(bx-1,7+bobY,2,5);
                    }
                    ctx.fillStyle=hl;
                    ctx.fillRect(bx+1,6+bobY,13,4);
                }
            } else if (dir===2||dir===6) {
                // SIDE — head is 13w at bx. Face is at far end, back of skull at near end.
                // dir2: facing right, face=bx+12, back=bx. dir6: facing left, face=bx, back=bx+12
                const flip=dir===6, bx=flip?ox+13:ox+19;
                if(style==='mohawk'){
                    // Side view: mohawk ridge runs full length of head top
                    // Head is 13w (bx to bx+13), top at y=7
                    ctx.fillStyle=h;
                    ctx.fillRect(bx+1,5+bobY,11,3);  // base ridge across skull
                    ctx.fillRect(bx+2,3+bobY,9,3);   // mid rise
                    ctx.fillRect(bx+3,1+bobY,7,3);   // peak
                    ctx.fillRect(bx+4,0+bobY,5,2);   // tip
                    ctx.fillStyle=hl;
                    ctx.fillRect(bx+2,4+bobY,9,2);   // base highlight
                    ctx.fillRect(bx+3,2+bobY,7,2);   // mid highlight
                    ctx.fillRect(bx+5,0+bobY,3,2);   // tip highlight
                } else if(style==='long'){
                    // Hair covers back 2/3 of head + extends behind
                    ctx.fillStyle=h;
                    if(flip){
                        // Facing left: back of head is right side
                        ctx.fillRect(bx+3,5+bobY,11,6); // back-heavy coverage
                        ctx.fillRect(bx+12,6+bobY,2,5); // extends behind head
                        ctx.fillRect(bx+11,9+bobY,4,9); // back curtain hangs down
                    } else {
                        // Facing right: back of head is left side
                        ctx.fillRect(bx-1,5+bobY,11,6);
                        ctx.fillRect(bx-2,6+bobY,2,5);
                        ctx.fillRect(bx-2,9+bobY,4,9);
                    }
                    ctx.fillStyle=hl;
                    if(flip){
                        ctx.fillRect(bx+4,6+bobY,9,4);
                        ctx.fillRect(bx+12,10+bobY,2,6);
                    } else {
                        ctx.fillRect(bx,6+bobY,9,4);
                        ctx.fillRect(bx-1,10+bobY,2,6);
                    }
                } else if(style==='buzzed'){
                    if(flip) buzzTint(bx+3,6+bobY,9,2);
                    else buzzTint(bx+1,6+bobY,9,2);
                } else {
                    // SHORT — full hair from side: covers whole top, bangs in front, volume behind
                    ctx.fillStyle=h;
                    ctx.fillRect(bx,5+bobY,13,6); // full top coverage
                    if(flip){
                        ctx.fillRect(bx-1,8+bobY,2,3);  // bangs overhang toward face
                        ctx.fillRect(bx+12,7+bobY,2,5);  // back volume
                    } else {
                        ctx.fillRect(bx+12,8+bobY,2,3);  // bangs overhang toward face
                        ctx.fillRect(bx-1,7+bobY,2,5);   // back volume
                    }
                    ctx.fillStyle=hl;
                    ctx.fillRect(bx+1,6+bobY,11,4);
                }
            } else if (dir===3||dir===5) {
                // DIAGONAL BACK — head is 15w, mostly back of head
                const flip=dir===5, bx=flip?ox+14:ox+17;
                if(style==='mohawk'){
                    // Diagonal back: ridge across skull, more length visible
                    ctx.fillStyle=h;
                    ctx.fillRect(bx+3,5+bobY,9,4);   // base ridge
                    ctx.fillRect(bx+4,3+bobY,7,3);   // mid rise
                    ctx.fillRect(bx+5,1+bobY,5,3);   // peak
                    ctx.fillStyle=hl;
                    ctx.fillRect(bx+4,4+bobY,7,3);
                    ctx.fillRect(bx+6,2+bobY,3,2);
                } else if(style==='long'){
                    ctx.fillStyle=h;
                    ctx.fillRect(bx,5+bobY,15,9);
                    if(flip){ ctx.fillRect(bx+13,10+bobY,3,10); ctx.fillRect(bx-1,10+bobY,2,8); }
                    else { ctx.fillRect(bx-1,10+bobY,3,10); ctx.fillRect(bx+14,10+bobY,2,8); }
                    ctx.fillRect(bx+2,13+bobY,11,7);
                    ctx.fillStyle=hl;
                    ctx.fillRect(bx+1,6+bobY,13,7);
                    ctx.fillRect(bx+3,14+bobY,9,4);
                } else if(style==='buzzed'){
                    buzzTint(bx+1,6+bobY,13,3);
                } else {
                    // Short from back — full skull coverage with sides
                    ctx.fillStyle=h;
                    ctx.fillRect(bx,5+bobY,15,9);
                    if(flip){
                        ctx.fillRect(bx+14,7+bobY,2,6); // far side
                        ctx.fillRect(bx-1,7+bobY,2,5);  // near side
                    } else {
                        ctx.fillRect(bx-1,7+bobY,2,6);
                        ctx.fillRect(bx+14,7+bobY,2,5);
                    }
                    ctx.fillStyle=hl;
                    ctx.fillRect(bx+1,6+bobY,13,7);
                }
            } else if (dir===4) {
                // BACK — head is 16w (ox+16 to ox+32), full back visible
                if(style==='mohawk'){
                    // Back view: fin edge-on from behind, runs down skull
                    ctx.fillStyle=h;
                    ctx.fillRect(ox+20,5+bobY,8,6);  // base on skull
                    ctx.fillRect(ox+21,2+bobY,6,4);  // mid rise
                    ctx.fillRect(ox+22,0+bobY,4,3);  // peak
                    ctx.fillStyle=hl;
                    ctx.fillRect(ox+21,4+bobY,6,5);
                    ctx.fillRect(ox+23,1+bobY,2,3);
                } else if(style==='long'){
                    ctx.fillStyle=h;
                    ctx.fillRect(ox+15,5+bobY,18,10);
                    ctx.fillRect(ox+14,10+bobY,3,11);
                    ctx.fillRect(ox+31,10+bobY,3,11);
                    ctx.fillRect(ox+17,14+bobY,14,8);
                    ctx.fillStyle=hl;
                    ctx.fillRect(ox+16,6+bobY,16,8);
                    ctx.fillRect(ox+18,15+bobY,12,5);
                } else if(style==='buzzed'){
                    buzzTint(ox+17,7+bobY,14,3);
                } else {
                    // Short from back — full skull + sides wrapping
                    ctx.fillStyle=h;
                    ctx.fillRect(ox+15,5+bobY,18,10);
                    ctx.fillRect(ox+14,7+bobY,2,6); // left side wraps down
                    ctx.fillRect(ox+32,7+bobY,2,6); // right side wraps down
                    ctx.fillStyle=hl;
                    ctx.fillRect(ox+16,6+bobY,16,8);
                }
            }
        },
        
        drawTorso(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const o=c.outline;
            if (dir===0||dir===4) {
                // Shoulders: 22px wide (was 26)
                ctx.fillStyle=c.shirtLight; ctx.fillRect(ox+13,20+bobY,22,4);
                ctx.clearRect(ox+13,20+bobY,1,1); ctx.clearRect(ox+34,20+bobY,1,1);
                ctx.fillStyle=c.shirtDark; ctx.fillRect(ox+13,22+bobY,2,2); ctx.fillRect(ox+33,22+bobY,2,2);
                // Body: 22px wide, 10px tall
                ctx.fillStyle=o; ctx.fillRect(ox+13,23+bobY,22,10);
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+14,23+bobY,20,9);
                if(dir===0){
                    ctx.fillStyle=c.skinShade; ctx.fillRect(ox+20,20+bobY,8,3);
                    ctx.fillStyle=c.shirtDark; ctx.fillRect(ox+23,24+bobY,2,7);
                    ctx.fillRect(ox+16,26+bobY,4,3); ctx.fillRect(ox+28,26+bobY,4,3);
                    ctx.fillStyle=c.shirtLight; ctx.fillRect(ox+17,27+bobY,2,2); ctx.fillRect(ox+29,27+bobY,2,2);
                } else {
                    ctx.fillStyle=c.shirtDark; ctx.fillRect(ox+23,23+bobY,2,8);
                    ctx.fillRect(ox+16,24+bobY,5,4); ctx.fillRect(ox+27,24+bobY,5,4);
                }
            } else if (dir===1||dir===7) {
                const flip=dir===7,bx=flip?ox+14:ox+15,w=19;
                ctx.fillStyle=c.shirtLight; ctx.fillRect(bx,20+bobY,w,4);
                ctx.clearRect(bx,20+bobY,1,1); ctx.clearRect(bx+w-1,20+bobY,1,1);
                ctx.fillStyle=o; ctx.fillRect(bx,23+bobY,w,10);
                ctx.fillStyle=c.shirt; ctx.fillRect(bx+1,23+bobY,w-2,9);
                ctx.fillStyle=c.shirtDark;
                if(flip) ctx.fillRect(bx+w-6,23+bobY,5,8); else ctx.fillRect(bx+1,23+bobY,5,8);
                ctx.fillStyle=c.skinShade;
                if(flip) ctx.fillRect(bx+3,20+bobY,5,3); else ctx.fillRect(bx+w-8,20+bobY,5,3);
                ctx.fillStyle=c.shirtDark;
                if(flip) ctx.fillRect(bx+2,26+bobY,3,3); else ctx.fillRect(bx+w-5,26+bobY,3,3);
            } else if (dir===2||dir===6) {
                const flip=dir===6,bx=flip?ox+15:ox+17,w=14;
                ctx.fillStyle=c.shirtLight; ctx.fillRect(bx,20+bobY,w,4);
                ctx.clearRect(bx,20+bobY,1,1); ctx.clearRect(bx+w-1,20+bobY,1,1);
                ctx.fillStyle=o; ctx.fillRect(bx,23+bobY,w,10);
                ctx.fillStyle=c.shirt; ctx.fillRect(bx+1,23+bobY,w-2,9);
                ctx.fillStyle=c.shirtDark;
                if(flip) ctx.fillRect(bx+w-5,23+bobY,4,8); else ctx.fillRect(bx+1,23+bobY,4,8);
                ctx.fillRect(bx+6,23+bobY,1,8);
            } else {
                const flip=dir===5,bx=flip?ox+14:ox+15,w=19;
                ctx.fillStyle=c.shirtLight; ctx.fillRect(bx,20+bobY,w,4);
                ctx.clearRect(bx,20+bobY,1,1); ctx.clearRect(bx+w-1,20+bobY,1,1);
                ctx.fillStyle=o; ctx.fillRect(bx,23+bobY,w,10);
                ctx.fillStyle=c.shirt; ctx.fillRect(bx+1,23+bobY,w-2,9);
                ctx.fillStyle=c.shirtDark;
                if(flip) ctx.fillRect(bx+1,23+bobY,5,8); else ctx.fillRect(bx+w-6,23+bobY,5,8);
                ctx.fillRect(bx+7,24+bobY,5,4);
            }
        },
        
        drawBelt(ctx, p, c) {
            const { ox, dir, bobY } = p;
            if (dir===0||dir===4) {
                ctx.fillStyle=c.belt; ctx.fillRect(ox+14,32+bobY,20,2);
                if(dir===0){ctx.fillStyle=c.buckle; ctx.fillRect(ox+22,32+bobY,4,2);}
            } else if (dir===1||dir===7) {
                const flip=dir===7,bx=flip?ox+15:ox+16;
                ctx.fillStyle=c.belt; ctx.fillRect(bx,32+bobY,17,2);
                ctx.fillStyle=c.buckle; if(flip) ctx.fillRect(bx+1,32+bobY,3,2); else ctx.fillRect(bx+13,32+bobY,3,2);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+16:ox+18;
                ctx.fillStyle=c.belt; ctx.fillRect(bx,32+bobY,12,2);
            } else {
                const bx=(dir===5)?ox+15:ox+16;
                ctx.fillStyle=c.belt; ctx.fillRect(bx,32+bobY,17,2);
            }
        },
        
        drawArms(ctx, p, c) {
            const { ox, dir, bobY, armSwing } = p;
            if (dir===0) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+10+armSwing,21+bobY,5,6); ctx.fillRect(ox+33-armSwing,21+bobY,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+11+armSwing,26+bobY,3,3); ctx.fillRect(ox+34-armSwing,26+bobY,3,3);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+11+armSwing,28+bobY,3,1); ctx.fillRect(ox+34-armSwing,28+bobY,3,1);
            } else if (dir===1) {
                ctx.fillStyle=c.shirtDark; ctx.fillRect(ox+13+armSwing,21+bobY,4,5);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+14+armSwing,25+bobY,3,3);
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+31-armSwing,21+bobY,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+33-armSwing,26+bobY,3,3);
            } else if (dir===7) {
                ctx.fillStyle=c.shirtDark; ctx.fillRect(ox+29-armSwing,21+bobY,4,5);
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+30-armSwing,25+bobY,3,3);
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+11+armSwing,21+bobY,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+11+armSwing,26+bobY,3,3);
            } else if (dir===2) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+29,20+bobY+armSwing,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+30,25+bobY+armSwing,3,3);
            } else if (dir===6) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+14,20+bobY+armSwing,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+15,25+bobY+armSwing,3,3);
            } else if (dir===4) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+10-armSwing,21+bobY,5,6); ctx.fillRect(ox+33+armSwing,21+bobY,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+11-armSwing,26+bobY,3,2); ctx.fillRect(ox+34+armSwing,26+bobY,3,2);
            } else if (dir===3) {
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+14-armSwing,24+bobY,3,3);
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+32+armSwing,20+bobY,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+33+armSwing,25+bobY,3,2);
            } else if (dir===5) {
                ctx.fillStyle=c.skinShade; ctx.fillRect(ox+30+armSwing,24+bobY,3,3);
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+11-armSwing,20+bobY,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+12-armSwing,25+bobY,3,2);
            }
        },
        
        drawArmedArms(ctx, p, c, ws) {
            const { ox, dir, bobY } = p;
            const bl = ws.barrel;
            const wc = ws._wpnCanvas; // pre-rendered weapon canvas { canvas, gripX, gripY }
            
            // Rotation angles per direction (weapon points outward from character)
            const angles = [Math.PI/2, Math.PI/4, 0, -Math.PI/4, -Math.PI/2, -Math.PI*3/4, Math.PI, Math.PI*3/4];
            
            // Hand anchor positions per direction (where grip meets hand)
            const handAnchors = [
                { x: 24, y: 33 }, // 0: down
                { x: 35, y: 30 }, // 1: down_right
                { x: 35, y: 24 }, // 2: right
                { x: 38, y: 17 }, // 3: up_right
                { x: 24, y: 13 }, // 4: up
                { x: 9,  y: 17 }, // 5: up_left
                { x: 12, y: 24 }, // 6: left
                { x: 12, y: 30 }, // 7: down_left
            ];
            
            // Draw arms/hands (keep original arm drawing per direction)
            if (dir===0) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+16,25+bobY,5,6); ctx.fillRect(ox+27,25+bobY,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+17,30+bobY,4,3); ctx.fillRect(ox+27,30+bobY,4,3);
            } else if (dir===1) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+28,23+bobY,5,5);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+32,26+bobY,4,3);
            } else if (dir===7) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+14,23+bobY,5,5);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+11,26+bobY,4,3);
            } else if (dir===2) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+28,21+bobY,5,5);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+32,22+bobY,4,3);
            } else if (dir===6) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+14,21+bobY,5,5);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+11,22+bobY,4,3);
            } else if (dir===3) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+30,19+bobY,5,5);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+34,17+bobY,4,3);
            } else if (dir===5) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+12,19+bobY,5,5);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+9,17+bobY,4,3);
            } else if (dir===4) {
                ctx.fillStyle=c.shirt; ctx.fillRect(ox+16,17+bobY,5,6); ctx.fillRect(ox+27,17+bobY,5,6);
                ctx.fillStyle=c.skin; ctx.fillRect(ox+17,14+bobY,4,3); ctx.fillRect(ox+27,14+bobY,4,3);
            }
            
            // Composite pre-rendered weapon or fall back to simple geometry
            if (wc && wc.canvas) {
                const ha = handAnchors[dir];
                const angle = angles[dir];
                const inHandScale = Math.max(1.7, Math.min(2.0, bl * 0.17));
                // Left-facing dirs (5=up_left, 6=left, 7=down_left): flip Y so weapon isn't upside down
                const flipY = (dir >= 5 && dir <= 7) ? -1 : 1;
                
                ctx.save();
                ctx.translate(ox + ha.x, ha.y + bobY);
                ctx.rotate(angle);
                ctx.scale(inHandScale, inHandScale * flipY);
                // Draw weapon canvas with grip at origin
                ctx.drawImage(wc.canvas, -wc.gripX, -wc.gripY);
                ctx.restore();
            } else {
                // Fallback: original simple geometry (for weapons without item data)
                if (dir===0) {
                    ctx.fillStyle=ws.body; ctx.fillRect(ox+20,33+bobY,8,bl);
                    if(ws.wide) ctx.fillRect(ox+19,33+bobY,10,bl);
                    ctx.fillStyle=ws.dark; ctx.fillRect(ox+21,33+bl+bobY,6,2);
                    if(ws.stock){ctx.fillStyle=ws.stockColor;ctx.fillRect(ox+20,29+bobY,8,4);}
                    ctx.fillStyle=ws.light; ctx.fillRect(ox+22,33+bl+bobY,2,1);
                } else if (dir===1) {
                    ctx.fillStyle=ws.body; ctx.fillRect(ox+35,28+bobY,bl,4);
                    ctx.fillStyle=ws.dark; ctx.fillRect(ox+35+bl,29+bobY,2,3);
                    if(ws.stock){ctx.fillStyle=ws.stockColor;ctx.fillRect(ox+29,26+bobY,4,4);}
                } else if (dir===7) {
                    ctx.fillStyle=ws.body; ctx.fillRect(ox+11-bl,28+bobY,bl,4);
                    ctx.fillStyle=ws.dark; ctx.fillRect(ox+9-bl,29+bobY,2,3);
                    if(ws.stock){ctx.fillStyle=ws.stockColor;ctx.fillRect(ox+15,26+bobY,4,4);}
                } else if (dir===2) {
                    ctx.fillStyle=ws.body; ctx.fillRect(ox+35,22+bobY,bl,4);
                    ctx.fillStyle=ws.dark; ctx.fillRect(ox+35+bl,23+bobY,2,2);
                    if(ws.stock){ctx.fillStyle=ws.stockColor;ctx.fillRect(ox+26,22+bobY,4,4);}
                } else if (dir===6) {
                    ctx.fillStyle=ws.body; ctx.fillRect(ox+11-bl,22+bobY,bl,4);
                    ctx.fillStyle=ws.dark; ctx.fillRect(ox+9-bl,23+bobY,2,2);
                    if(ws.stock){ctx.fillStyle=ws.stockColor;ctx.fillRect(ox+18,22+bobY,4,4);}
                } else if (dir===3) {
                    ctx.fillStyle=ws.body; ctx.fillRect(ox+36,13+bobY,4,bl);
                    ctx.fillStyle=ws.dark; ctx.fillRect(ox+37,11+bobY,3,2);
                    if(ws.stock){ctx.fillStyle=ws.stockColor;ctx.fillRect(ox+31,21+bobY,4,4);}
                } else if (dir===5) {
                    ctx.fillStyle=ws.body; ctx.fillRect(ox+7,13+bobY,4,bl);
                    ctx.fillStyle=ws.dark; ctx.fillRect(ox+7,11+bobY,3,2);
                    if(ws.stock){ctx.fillStyle=ws.stockColor;ctx.fillRect(ox+13,21+bobY,4,4);}
                } else if (dir===4) {
                    ctx.fillStyle=ws.body; ctx.fillRect(ox+20,9+bobY,8,bl);
                    ctx.fillStyle=ws.dark; ctx.fillRect(ox+21,7+bobY,6,2);
                    if(ws.stock){ctx.fillStyle=ws.stockColor;ctx.fillRect(ox+20,14+bobY,8,4);}
                }
            }
        },
        
        // Melee swing arms — 3 phases: wind-up, strike, follow-through
        // meleeStyle: { type: 'blade'|'blunt'|'heavy', body, dark, light, guard, blade/head colors }
        drawMeleeSwingArms(ctx, p, c, ms) {
            const { ox, dir, bobY } = p;
            const phase = p.frame; // 0=wind-up, 1=strike, 2=follow-through
            const skin = c.skin;
            const shirt = c.shirt;
            const wc = ms._wpnCanvas; // pre-rendered weapon canvas
            
            // Melee weapon colors (fallback)
            const handle = ms.handle || '#4a3a2a';
            const wpnBody = ms.body || '#7a8a9a';
            const wpnLight = ms.light || '#99aabb';
            const wpnDark = ms.dark || '#5a6a7a';
            const guard = ms.guard || '#8a7a5a';
            const isLong = ms.type === 'heavy';
            const isBlunt = ms.type === 'blunt';
            const reach = isLong ? 14 : (isBlunt ? 10 : 12);
            
            // Swing angles per direction × phase (radians, 0 = pointing up, CW positive)
            // Weapon canvas is drawn pointing UP with grip at bottom
            const swingData = {
                // [handX, handY, angle] per phase
                0: [ // DOWN (front-facing) — swing left-to-right
                    [35, 24, -0.4],    // wind-up: weapon upper-right
                    [28, 32,  Math.PI], // strike: weapon pointing down
                    [10, 28,  Math.PI * 0.6] // follow-through: swept left
                ],
                1: [ // DOWN-RIGHT — diagonal swing
                    [36, 18, -0.2],     // wind-up: weapon up
                    [36, 28,  Math.PI * 0.6], // strike: weapon right-down
                    [16, 31,  Math.PI * 0.7] // follow-through: swept left-down
                ],
                2: [ // RIGHT — overhead to floor
                    [32, 14,  0],       // wind-up: weapon straight up
                    [36, 24,  Math.PI / 2], // strike: weapon pointing right
                    [32, 33,  Math.PI]  // follow-through: weapon down
                ],
                3: [ // UP-RIGHT
                    [34, 15, -0.2],     // wind-up: weapon up
                    [38, 17,  Math.PI * 0.4], // strike: weapon upper-right
                    [30, 33,  Math.PI]  // follow-through: weapon down
                ],
                4: [ // UP (back-facing) — swing right-to-left
                    [35, 18, -0.4],     // wind-up: weapon upper-right
                    [28, 10,  0],       // strike: weapon pointing up
                    [10, 22,  Math.PI * 0.6] // follow-through: swept left
                ],
                5: [ // UP-LEFT — mirror of up-right
                    [13, 15,  0.2],     // wind-up: weapon up
                    [8,  17, -Math.PI * 0.4], // strike: weapon upper-left
                    [18, 33,  Math.PI]  // follow-through: weapon down
                ],
                6: [ // LEFT — mirror of right
                    [15, 14,  0],       // wind-up: weapon straight up
                    [10, 24, -Math.PI / 2], // strike: weapon pointing left
                    [15, 33,  Math.PI]  // follow-through: weapon down
                ],
                7: [ // DOWN-LEFT — mirror of down-right
                    [11, 18,  0.2],     // wind-up: weapon up
                    [10, 28, -Math.PI * 0.6], // strike: weapon left-down
                    [30, 31, -Math.PI * 0.7] // follow-through: swept right-down
                ]
            };
            
            // ── Draw arms per direction × phase (same as before) ──
            if (dir === 0) {
                const armY = 25 + bobY;
                if (phase === 0) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+16, armY, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+17, armY+5, 4, 3);
                    ctx.fillStyle = shirt; ctx.fillRect(ox+28, armY-2, 6, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+33, armY-1, 4, 3);
                } else if (phase === 1) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+16, armY, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+17, armY+5, 4, 3);
                    ctx.fillStyle = shirt; ctx.fillRect(ox+25, armY+2, 6, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+26, armY+7, 5, 3);
                } else {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+16, armY+1, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+12, armY+3, 4, 3);
                    ctx.fillStyle = shirt; ctx.fillRect(ox+27, armY, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+27, armY+5, 4, 3);
                }
            } else if (dir === 4) {
                const armY = 17 + bobY;
                if (phase === 0) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+16, armY, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+17, armY+5, 4, 3);
                    ctx.fillStyle = shirt; ctx.fillRect(ox+28, armY-2, 6, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+33, armY-1, 4, 3);
                } else if (phase === 1) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+16, armY, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+17, armY-3, 4, 3);
                    ctx.fillStyle = shirt; ctx.fillRect(ox+25, armY-2, 6, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+26, armY-5, 5, 3);
                } else {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+16, armY+1, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+12, armY+2, 4, 3);
                    ctx.fillStyle = shirt; ctx.fillRect(ox+27, armY, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+27, armY+5, 4, 3);
                }
            } else if (dir === 2) {
                const armY = 21 + bobY;
                if (phase === 0) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+28, armY-4, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+30, armY-7, 4, 4);
                } else if (phase === 1) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+28, armY, 6, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+33, armY+1, 4, 3);
                } else {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+28, armY+3, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+30, armY+8, 4, 3);
                }
            } else if (dir === 6) {
                const armY = 21 + bobY;
                if (phase === 0) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+14, armY-4, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+13, armY-7, 4, 4);
                } else if (phase === 1) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+13, armY, 6, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+10, armY+1, 4, 3);
                } else {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+14, armY+3, 5, 6);
                    ctx.fillStyle = skin; ctx.fillRect(ox+13, armY+8, 4, 3);
                }
            } else if (dir === 1) {
                const armY = 23 + bobY;
                if (phase === 0) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+28, armY-3, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+32, armY-5, 4, 3);
                } else if (phase === 1) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+28, armY, 6, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+33, armY+2, 4, 3);
                } else {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+22, armY+4, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+18, armY+6, 4, 3);
                }
            } else if (dir === 7) {
                const armY = 23 + bobY;
                if (phase === 0) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+14, armY-3, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+11, armY-5, 4, 3);
                } else if (phase === 1) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+13, armY, 6, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+10, armY+2, 4, 3);
                } else {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+20, armY+4, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+25, armY+6, 4, 3);
                }
            } else if (dir === 3) {
                const armY = 19 + bobY;
                if (phase === 0) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+28, armY, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+32, armY-2, 4, 3);
                } else if (phase === 1) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+30, armY-3, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+34, armY-5, 4, 3);
                } else {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+26, armY+3, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+28, armY+7, 4, 3);
                }
            } else if (dir === 5) {
                const armY = 19 + bobY;
                if (phase === 0) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+14, armY, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+11, armY-2, 4, 3);
                } else if (phase === 1) {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+12, armY-3, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+9, armY-5, 4, 3);
                } else {
                    ctx.fillStyle = shirt; ctx.fillRect(ox+18, armY+3, 5, 5);
                    ctx.fillStyle = skin; ctx.fillRect(ox+16, armY+7, 4, 3);
                }
            }
            
            // ── Composite pre-rendered weapon or fallback geometry ──
            if (wc && wc.canvas) {
                const sd = swingData[dir];
                if (sd && sd[phase]) {
                    const [hx, hy, angle] = sd[phase];
                    const inHandScale = isLong ? 1.0 : (isBlunt ? 0.88 : 0.95);
                    
                    ctx.save();
                    ctx.translate(ox + hx, hy + bobY);
                    ctx.rotate(angle);
                    ctx.scale(inHandScale, inHandScale);
                    ctx.drawImage(wc.canvas, -wc.gripX, -wc.gripY);
                    ctx.restore();
                }
            } else {
                // ── Fallback: original simple geometry ──
                if (dir === 0) {
                    const armY = 25 + bobY;
                    if (phase === 0) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+36, armY-4, 3, 6);
                        ctx.fillStyle = guard; ctx.fillRect(ox+35, armY-5, 5, 2);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+36, armY-5-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+37, armY-4-reach, 1, reach-2);
                    } else if (phase === 1) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+27, armY+9, 3, 5);
                        ctx.fillStyle = guard; ctx.fillRect(ox+26, armY+9, 5, 2);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+27, armY+13, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+28, armY+14, 1, reach-2);
                        if(isBlunt) { ctx.fillStyle = wpnDark; ctx.fillRect(ox+25, armY+13+reach-4, 7, 5); ctx.fillStyle = wpnBody; ctx.fillRect(ox+26, armY+14+reach-4, 5, 3); }
                    } else {
                        ctx.fillStyle = handle; ctx.fillRect(ox+8, armY+2, 5, 3);
                        ctx.fillStyle = guard; ctx.fillRect(ox+7, armY+1, 2, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+7-reach, armY+2, reach, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+8-reach, armY+3, reach-2, 1);
                    }
                } else if (dir === 4) {
                    const armY = 17 + bobY;
                    if (phase === 0) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+36, armY-4, 3, 6);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+36, armY-4-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+37, armY-3-reach, 1, reach-2);
                    } else if (phase === 1) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+27, armY-9, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+27, armY-9-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+28, armY-8-reach, 1, reach-2);
                    } else {
                        ctx.fillStyle = handle; ctx.fillRect(ox+8, armY+1, 5, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+8-reach, armY+1, reach, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+9-reach, armY+2, reach-2, 1);
                    }
                } else if (dir === 2) {
                    const armY = 21 + bobY;
                    if (phase === 0) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+31, armY-11, 3, 5);
                        ctx.fillStyle = guard; ctx.fillRect(ox+30, armY-12, 5, 2);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+31, armY-12-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+32, armY-11-reach, 1, reach-2);
                    } else if (phase === 1) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+36, armY+1, 5, 3);
                        ctx.fillStyle = guard; ctx.fillRect(ox+35, armY, 2, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+40, armY+1, reach, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+41, armY+2, reach-2, 1);
                        if(isBlunt) { ctx.fillStyle = wpnDark; ctx.fillRect(ox+40+reach-3, armY-1, 5, 7); ctx.fillStyle = wpnBody; ctx.fillRect(ox+41+reach-3, armY, 3, 5); }
                    } else {
                        ctx.fillStyle = handle; ctx.fillRect(ox+31, armY+10, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+31, armY+14, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+32, armY+15, 1, reach-2);
                    }
                } else if (dir === 6) {
                    const armY = 21 + bobY;
                    if (phase === 0) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+13, armY-11, 3, 5);
                        ctx.fillStyle = guard; ctx.fillRect(ox+12, armY-12, 5, 2);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+13, armY-12-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+14, armY-11-reach, 1, reach-2);
                    } else if (phase === 1) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+6, armY+1, 5, 3);
                        ctx.fillStyle = guard; ctx.fillRect(ox+10, armY, 2, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+6-reach, armY+1, reach, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+7-reach, armY+2, reach-2, 1);
                        if(isBlunt) { ctx.fillStyle = wpnDark; ctx.fillRect(ox+5-reach, armY-1, 5, 7); ctx.fillStyle = wpnBody; ctx.fillRect(ox+6-reach, armY, 3, 5); }
                    } else {
                        ctx.fillStyle = handle; ctx.fillRect(ox+13, armY+10, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+13, armY+14, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+14, armY+15, 1, reach-2);
                    }
                } else if (dir === 1) {
                    const armY = 23 + bobY;
                    if (phase === 0) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+35, armY-8, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+35, armY-8-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+36, armY-7-reach, 1, reach-2);
                    } else if (phase === 1) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+36, armY+4, 4, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+39, armY+3, reach-2, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+38, armY+5, reach-2, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+40, armY+4, reach-4, 1);
                    } else {
                        ctx.fillStyle = handle; ctx.fillRect(ox+14, armY+7, 5, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+14-reach+4, armY+6, reach-2, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+15-reach+4, armY+8, reach-2, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+15-reach+4, armY+7, reach-4, 1);
                    }
                } else if (dir === 7) {
                    const armY = 23 + bobY;
                    if (phase === 0) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+10, armY-8, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+10, armY-8-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+11, armY-7-reach, 1, reach-2);
                    } else if (phase === 1) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+7, armY+4, 4, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+9-reach, armY+3, reach-2, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+8-reach, armY+5, reach-2, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+9-reach, armY+4, reach-4, 1);
                    } else {
                        ctx.fillStyle = handle; ctx.fillRect(ox+28, armY+7, 5, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+31, armY+6, reach-2, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+30, armY+8, reach-2, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+32, armY+7, reach-4, 1);
                    }
                } else if (dir === 3) {
                    const armY = 19 + bobY;
                    if (phase === 0) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+35, armY-5, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+35, armY-5-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+36, armY-4-reach, 1, reach-2);
                    } else if (phase === 1) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+37, armY-4, 4, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+40, armY-5, reach-2, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+39, armY-7, reach-2, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+41, armY-6, reach-4, 1);
                    } else {
                        ctx.fillStyle = handle; ctx.fillRect(ox+29, armY+9, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+29, armY+13, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+30, armY+14, 1, reach-2);
                    }
                } else if (dir === 5) {
                    const armY = 19 + bobY;
                    if (phase === 0) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+10, armY-5, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+10, armY-5-reach, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+11, armY-4-reach, 1, reach-2);
                    } else if (phase === 1) {
                        ctx.fillStyle = handle; ctx.fillRect(ox+6, armY-4, 4, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+8-reach, armY-5, reach-2, 3);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+7-reach, armY-7, reach-2, 3);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+8-reach, armY-6, reach-4, 1);
                    } else {
                        ctx.fillStyle = handle; ctx.fillRect(ox+16, armY+9, 3, 5);
                        ctx.fillStyle = wpnBody; ctx.fillRect(ox+16, armY+13, 3, reach);
                        ctx.fillStyle = wpnLight; ctx.fillRect(ox+17, armY+14, 1, reach-2);
                    }
                }
            }
        },
        
        drawLegs(ctx, p, c) {
            const { ox, dir, legSpread } = p;
            const o=c.outline;
            if (dir===0||dir===4) {
                const lx=dir===0?14:15, rx=dir===0?27:27;
                ctx.fillStyle=o; ctx.fillRect(ox+lx-legSpread,34,7,7); ctx.fillRect(ox+rx+legSpread,34,7,7);
                ctx.fillStyle=c.pants; ctx.fillRect(ox+lx+1-legSpread,34,5,6); ctx.fillRect(ox+rx+1+legSpread,34,5,6);
                ctx.fillStyle=c.pantsLight; ctx.fillRect(ox+lx+2-legSpread,34,2,4); ctx.fillRect(ox+rx+2+legSpread,34,2,4);
            } else if (dir===1||dir===7) {
                const flip=dir===7,lx=flip?13:15,rx=flip?24:26;
                ctx.fillStyle=o; ctx.fillRect(ox+lx-legSpread,34,6,7); ctx.fillRect(ox+rx+legSpread,34,6,7);
                ctx.fillStyle=c.pants; ctx.fillRect(ox+lx+1-legSpread,34,4,6); ctx.fillRect(ox+rx+1+legSpread,34,4,6);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+15:ox+17;
                ctx.fillStyle=c.pants; ctx.fillRect(bx+2+legSpread,34,5,6);
                ctx.fillStyle=o; ctx.fillRect(bx+4-legSpread,34,6,7);
                ctx.fillStyle=c.pants; ctx.fillRect(bx+5-legSpread,34,4,6);
                ctx.fillStyle=c.pantsLight; ctx.fillRect(bx+6-legSpread,34,2,4);
            } else {
                const flip=dir===5,lx=flip?13:16,rx=flip?23:26;
                ctx.fillStyle=o; ctx.fillRect(ox+lx+legSpread,34,6,7); ctx.fillRect(ox+rx-legSpread,34,6,7);
                ctx.fillStyle=c.pants; ctx.fillRect(ox+lx+1+legSpread,34,4,6); ctx.fillRect(ox+rx+1-legSpread,34,4,6);
            }
        },
        
        drawBoots(ctx, p, c) {
            const { ox, dir, legSpread } = p;
            if (dir===0||dir===4) {
                const lx=dir===0?13:14, rx=dir===0?27:27;
                ctx.fillStyle=c.boots; ctx.fillRect(ox+lx-legSpread,40,8,4); ctx.fillRect(ox+rx+legSpread,40,8,4);
                // Round boot toes
                ctx.clearRect(ox+lx-legSpread,40,1,1); ctx.clearRect(ox+lx+7-legSpread,40,1,1);
                ctx.clearRect(ox+rx+legSpread,40,1,1); ctx.clearRect(ox+rx+7+legSpread,40,1,1);
                ctx.fillStyle=c.bootsLight; ctx.fillRect(ox+lx+1-legSpread,40,5,1); ctx.fillRect(ox+rx+1+legSpread,40,5,1);
                ctx.fillStyle=c.bootSole; ctx.fillRect(ox+lx-legSpread,43,8,1); ctx.fillRect(ox+rx+legSpread,43,8,1);
                ctx.fillStyle='#0d0d0d'; ctx.fillRect(ox+lx+1-legSpread,43,2,1); ctx.fillRect(ox+lx+4-legSpread,43,2,1);
                ctx.fillRect(ox+rx+1+legSpread,43,2,1); ctx.fillRect(ox+rx+4+legSpread,43,2,1);
            } else if (dir===1||dir===7) {
                const flip=dir===7,lx=flip?12:14,rx=flip?23:26;
                ctx.fillStyle=c.boots; ctx.fillRect(ox+lx-legSpread,40,7,4); ctx.fillRect(ox+rx+legSpread,40,7,4);
                ctx.fillStyle=c.bootSole; ctx.fillRect(ox+lx-legSpread,43,7,1); ctx.fillRect(ox+rx+legSpread,43,7,1);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+14:ox+16;
                ctx.fillStyle=c.boots; ctx.fillRect(bx+1+legSpread,40,6,4); ctx.fillRect(bx+3-legSpread,40,7,4);
                ctx.fillStyle=c.bootSole; ctx.fillRect(bx+1+legSpread,43,6,1); ctx.fillRect(bx+3-legSpread,43,7,1);
                ctx.fillStyle=c.bootsLight;
                if(dir===2) ctx.fillRect(bx+8-legSpread,40,2,1); else ctx.fillRect(bx+3+legSpread,40,2,1);
            } else {
                const flip=dir===5,lx=flip?12:15,rx=flip?22:26;
                ctx.fillStyle=c.boots; ctx.fillRect(ox+lx+legSpread,40,7,4); ctx.fillRect(ox+rx-legSpread,40,7,4);
                ctx.fillStyle=c.bootSole; ctx.fillRect(ox+lx+legSpread,43,7,1); ctx.fillRect(ox+rx-legSpread,43,7,1);
            }
        }
    },
    
    // === GEAR OVERLAY SYSTEM ===
    // Each gear type provides overlay functions that draw ON TOP of base body parts.
    // drawTorsoOverlay: patches, armor plates, vests over the shirt
    // drawLegOverlay: leg guards, reinforced pants
    // drawBootOverlay: armored boots, greaves
    // drawHead: REPLACES base head entirely (for helmets)
    // Colors come from the outfit shirt/pants already applied to base colors.
    
    GearOverlays: {
        scrap: {
            // Scrap: rag wraps, stitched patches, exposed bindings
            drawTorsoOverlay(ctx, p, c) {
                const { ox, dir, bobY } = p;
                const patch = c.shirtDark;
                const stitch = '#7a6a5a';
                const wrap = '#6a5a48';
                const wrapDark = '#5a4a38';
                
                if (dir===0||dir===4) {
                    ctx.fillStyle = patch;
                    ctx.fillRect(ox+16,24+bobY,4,4);
                    ctx.fillRect(ox+28,25+bobY,4,3);
                    ctx.fillRect(ox+19,28+bobY,5,3);
                    ctx.fillStyle = stitch;
                    ctx.fillRect(ox+16,24+bobY,1,4);
                    ctx.fillRect(ox+19,24+bobY,1,4);
                    ctx.fillRect(ox+28,25+bobY,1,3);
                    ctx.fillRect(ox+31,25+bobY,1,3);
                    ctx.fillStyle = wrap;
                    ctx.fillRect(ox+13,20+bobY,3,3);
                    ctx.fillRect(ox+32,20+bobY,3,3);
                    ctx.fillStyle = wrapDark;
                    ctx.fillRect(ox+14,21+bobY,1,1);
                    ctx.fillRect(ox+33,21+bobY,1,1);
                    if (dir===0) {
                        ctx.fillStyle = wrap;
                        ctx.fillRect(ox+21,23+bobY,2,8);
                        ctx.fillRect(ox+25,23+bobY,2,8);
                    }
                } else if (dir===1||dir===7) {
                    const flip=dir===7, bx=flip?ox+14:ox+15;
                    ctx.fillStyle = patch;
                    ctx.fillRect(bx+3,25+bobY,3,3);
                    ctx.fillRect(bx+10,24+bobY,4,3);
                    ctx.fillStyle = stitch;
                    ctx.fillRect(bx+3,25+bobY,1,3);
                    ctx.fillRect(bx+5,25+bobY,1,3);
                    ctx.fillStyle = wrap;
                    if(flip) ctx.fillRect(bx+14,20+bobY,3,3);
                    else ctx.fillRect(bx,20+bobY,3,3);
                    ctx.fillStyle = wrapDark;
                    ctx.fillRect(bx+8,23+bobY,2,7);
                } else if (dir===2||dir===6) {
                    const flip=dir===6, bx=flip?ox+15:ox+17;
                    ctx.fillStyle = patch;
                    ctx.fillRect(bx+3,25+bobY,3,3);
                    ctx.fillRect(bx+7,27+bobY,3,3);
                    ctx.fillStyle = stitch;
                    ctx.fillRect(bx+3,25+bobY,1,3);
                    ctx.fillRect(bx+5,25+bobY,1,3);
                    ctx.fillStyle = wrap;
                    ctx.fillRect(bx+5,23+bobY,2,7);
                } else {
                    const flip=dir===5, bx=flip?ox+14:ox+15;
                    ctx.fillStyle = patch;
                    ctx.fillRect(bx+4,24+bobY,4,3);
                    ctx.fillRect(bx+10,26+bobY,4,3);
                    ctx.fillStyle = stitch;
                    ctx.fillRect(bx+4,24+bobY,1,3);
                    ctx.fillRect(bx+7,24+bobY,1,3);
                    ctx.fillStyle = wrap;
                    ctx.fillRect(bx+7,23+bobY,2,7);
                }
            },
            
            drawLegOverlay(ctx, p, c) {
                const { ox, dir, legSpread } = p;
                const wrap = '#6a5a48';
                if (dir===0||dir===4) {
                    const lx=dir===0?14:15, rx=dir===0?27:27;
                    ctx.fillStyle = wrap;
                    ctx.fillRect(ox+lx+1-legSpread,37,4,2);
                    ctx.fillRect(ox+rx+1+legSpread,37,4,2);
                } else if (dir===1||dir===7) {
                    const flip=dir===7,lx=flip?13:15,rx=flip?24:26;
                    ctx.fillStyle = wrap;
                    ctx.fillRect(ox+lx+1-legSpread,37,3,2);
                    ctx.fillRect(ox+rx+1+legSpread,37,3,2);
                } else if (dir===2||dir===6) {
                    const bx=dir===6?ox+15:ox+17;
                    ctx.fillStyle = wrap;
                    ctx.fillRect(bx+5-legSpread,37,3,2);
                }
            }
        },
        
        light: {
            // Light gear: leather vest straps, arm wraps
            drawTorsoOverlay(ctx, p, c) {
                const { ox, dir, bobY } = p;
                const strap = '#3a2218';
                const strapHL = '#4a3228';
                const buckle = '#8a7a5a';
                
                if (dir===0||dir===4) {
                    // X-cross leather straps
                    ctx.fillStyle = strap;
                    for(let i=0;i<8;i++) { ctx.fillRect(ox+16+i,23+i+bobY,2,1); ctx.fillRect(ox+30-i,23+i+bobY,2,1); }
                    // Buckle at cross point
                    ctx.fillStyle = buckle; ctx.fillRect(ox+22,27+bobY,4,2);
                    // Arm wraps
                    ctx.fillStyle = strap;
                    if(dir===0) { ctx.fillRect(ox+10,23+bobY,5,2); ctx.fillRect(ox+33,23+bobY,5,2); }
                } else if (dir===1||dir===7) {
                    const flip=dir===7, bx=flip?ox+14:ox+15;
                    ctx.fillStyle = strap;
                    for(let i=0;i<6;i++) { ctx.fillRect(bx+3+i,23+i+bobY,2,1); }
                    ctx.fillStyle = buckle; ctx.fillRect(bx+7,26+bobY,3,2);
                } else if (dir===2||dir===6) {
                    const flip=dir===6, bx=flip?ox+15:ox+17;
                    ctx.fillStyle = strap;
                    ctx.fillRect(bx+5,23+bobY,2,8);
                    ctx.fillStyle = buckle; ctx.fillRect(bx+4,26+bobY,4,2);
                } else {
                    const flip=dir===5, bx=flip?ox+14:ox+15;
                    ctx.fillStyle = strap;
                    for(let i=0;i<6;i++) { ctx.fillRect(bx+12-i,23+i+bobY,2,1); }
                    ctx.fillStyle = buckle; ctx.fillRect(bx+8,26+bobY,3,2);
                }
            },
            drawHeadOverlay(ctx, p, c) {
                const { ox, dir, bobY } = p;
                const bandana = '#5a2222';
                const bandanaDark = '#3a1212';
                // Bandana covers lower face — front and diagonal only
                if (dir===0) {
                    ctx.fillStyle = bandana; ctx.fillRect(ox+17,15+bobY,14,4);
                    ctx.fillStyle = bandanaDark; ctx.fillRect(ox+17,18+bobY,14,2);
                    ctx.fillRect(ox+19,19+bobY,10,1);
                } else if (dir===1||dir===7) {
                    const flip=dir===7, bx=flip?ox+14:ox+17;
                    ctx.fillStyle = bandana; ctx.fillRect(bx+1,15+bobY,13,3);
                    ctx.fillStyle = bandanaDark; ctx.fillRect(bx+1,17+bobY,13,2);
                } else if (dir===2||dir===6) {
                    const flip=dir===6, bx=flip?ox+13:ox+19;
                    ctx.fillStyle = bandana; ctx.fillRect(bx+1,15+bobY,11,3);
                    ctx.fillStyle = bandanaDark; ctx.fillRect(bx+1,17+bobY,11,1);
                }
            }
        },
        
        medium: {
            // Medium gear: trench coat — animated sway, popped collar, fold detail
            drawTorsoOverlay(ctx, p, c) {
                const { ox, dir, bobY, frame } = p;
                const coat = c.shirt;
                const coatDark = c.shirtDark;
                const coatLight = c.shirtLight;
                const lining = '#2a1a1a';
                const belt = '#3a3028';
                const buckle = '#8a8a6a';
                const sway = frame===0 ? 0 : (frame===1 ? 2 : -2);
                
                if (dir===0||dir===4) {
                    // Coat body — shoulders to shins
                    ctx.fillStyle = coatDark; ctx.fillRect(ox+12,21+bobY,24,20);
                    ctx.fillStyle = coat; ctx.fillRect(ox+13,21+bobY,22,19);
                    
                    if(dir===0) {
                        // Front split — clear gap, show lining
                        ctx.fillStyle = lining; ctx.fillRect(ox+23,34+bobY,2,7);
                        // Left flap with sway
                        ctx.fillStyle = coatDark; ctx.fillRect(ox+12-sway,37+bobY,12+sway,5);
                        ctx.fillStyle = coat; ctx.fillRect(ox+13-sway,37+bobY,10+sway,4);
                        // Right flap with sway
                        ctx.fillStyle = coatDark; ctx.fillRect(ox+24+sway,37+bobY,12-sway,5);
                        ctx.fillStyle = coat; ctx.fillRect(ox+25+sway,37+bobY,10-sway,4);
                        // Round flap bottoms
                        ctx.clearRect(ox+12-sway,41+bobY,1,1);
                        ctx.clearRect(ox+35+sway,41+bobY,1,1);
                        // Vertical fold lines
                        ctx.fillStyle = coatDark;
                        ctx.fillRect(ox+17,24+bobY,1,13); ctx.fillRect(ox+30,24+bobY,1,13);
                        // Lapels — V-shaped opening
                        ctx.fillStyle = coatLight;
                        ctx.fillRect(ox+15,22+bobY,3,7); ctx.fillRect(ox+30,22+bobY,3,7);
                        ctx.fillStyle = coat;
                        ctx.fillRect(ox+16,23+bobY,2,5); ctx.fillRect(ox+30,23+bobY,2,5);
                        // Inner shirt visible between lapels
                        ctx.fillStyle = lining;
                        ctx.fillRect(ox+19,23+bobY,10,4);
                        ctx.fillRect(ox+20,27+bobY,8,2);
                        // Hip pockets
                        ctx.fillStyle = coatDark;
                        ctx.fillRect(ox+14,30+bobY,5,3); ctx.fillRect(ox+29,30+bobY,5,3);
                        ctx.fillStyle = coatLight;
                        ctx.fillRect(ox+14,30+bobY,5,1); ctx.fillRect(ox+29,30+bobY,5,1);
                    } else {
                        // Back — solid panel with longer tail
                        ctx.fillStyle = coatDark; ctx.fillRect(ox+14,37+bobY,20,5+Math.abs(sway));
                        ctx.fillStyle = coat; ctx.fillRect(ox+15,37+bobY,18,4+Math.abs(sway));
                        // Round back tail
                        ctx.clearRect(ox+14,41+Math.abs(sway)+bobY,1,1);
                        ctx.clearRect(ox+33,41+Math.abs(sway)+bobY,1,1);
                        // Back seam
                        ctx.fillStyle = coatDark; ctx.fillRect(ox+23,22+bobY,2,16);
                        // Back fold lines
                        ctx.fillRect(ox+17,24+bobY,1,12); ctx.fillRect(ox+30,24+bobY,1,12);
                    }
                    // Popped collar — tall, stands above shoulders
                    ctx.fillStyle = coatLight;
                    ctx.fillRect(ox+13,18+bobY,4,4); ctx.fillRect(ox+31,18+bobY,4,4);
                    ctx.fillStyle = coat;
                    ctx.fillRect(ox+14,19+bobY,2,2); ctx.fillRect(ox+32,19+bobY,2,2);
                    // Belt across waist
                    ctx.fillStyle = belt; ctx.fillRect(ox+14,32+bobY,20,2);
                    ctx.fillStyle = buckle; ctx.fillRect(ox+22,32+bobY,4,2);
                    
                } else if (dir===1||dir===7) {
                    const flip=dir===7, bx=flip?ox+13:ox+14, w=20;
                    const sw = flip ? -sway : sway;
                    // Coat body
                    ctx.fillStyle = coatDark; ctx.fillRect(bx,21+bobY,w,20);
                    ctx.fillStyle = coat; ctx.fillRect(bx+1,21+bobY,w-2,19);
                    // Bottom sway — trailing edge extends more
                    ctx.fillStyle = coatDark; ctx.fillRect(bx-sw,37+bobY,w+Math.abs(sw)+1,5);
                    ctx.fillStyle = coat; ctx.fillRect(bx+1-sw,37+bobY,w-2+Math.abs(sw),4);
                    // Round bottom
                    ctx.clearRect(bx-sw,41+bobY,1,1);
                    ctx.clearRect(bx+w+Math.abs(sw),41+bobY,1,1);
                    // Fold line
                    ctx.fillStyle = coatDark; ctx.fillRect(bx+Math.floor(w/2),23+bobY,1,14);
                    // Popped collar — visible side
                    ctx.fillStyle = coatLight;
                    if(flip) { ctx.fillRect(bx+w-4,18+bobY,4,4); ctx.fillStyle=coat; ctx.fillRect(bx+w-3,19+bobY,2,2); }
                    else { ctx.fillRect(bx,18+bobY,4,4); ctx.fillStyle=coat; ctx.fillRect(bx+1,19+bobY,2,2); }
                    // Lapel on visible side
                    ctx.fillStyle = coatLight;
                    if(flip) ctx.fillRect(bx+w-4,22+bobY,3,6);
                    else ctx.fillRect(bx+1,22+bobY,3,6);
                    // Hip pocket
                    ctx.fillStyle = coatDark;
                    if(flip) ctx.fillRect(bx+2,30+bobY,4,3);
                    else ctx.fillRect(bx+w-6,30+bobY,4,3);
                    // Belt
                    ctx.fillStyle = belt; ctx.fillRect(bx+1,32+bobY,w-2,2);
                    ctx.fillStyle = buckle;
                    if(flip) ctx.fillRect(bx+2,32+bobY,3,2); else ctx.fillRect(bx+w-5,32+bobY,3,2);
                    
                } else if (dir===2||dir===6) {
                    const flip=dir===6, bx=flip?ox+14:ox+16, w=16;
                    const sw = flip ? -sway : sway;
                    // Side view — see thickness of coat
                    ctx.fillStyle = coatDark; ctx.fillRect(bx,21+bobY,w,20);
                    ctx.fillStyle = coat; ctx.fillRect(bx+1,21+bobY,w-2,19);
                    // Sway — back flap trails
                    ctx.fillStyle = coatDark;
                    if(flip) ctx.fillRect(bx+w-1,37+bobY,3+Math.abs(sway),5);
                    else ctx.fillRect(bx-2-Math.abs(sway),37+bobY,3+Math.abs(sway),5);
                    ctx.fillStyle = coat;
                    if(flip) ctx.fillRect(bx+w,37+bobY,2+Math.abs(sway),4);
                    else ctx.fillRect(bx-1-Math.abs(sway),37+bobY,2+Math.abs(sway),4);
                    // Main bottom
                    ctx.fillStyle = coatDark; ctx.fillRect(bx-sw,37+bobY,w+Math.abs(sw),5);
                    ctx.fillStyle = coat; ctx.fillRect(bx+1-sw,37+bobY,w-2+Math.abs(sw),4);
                    // Popped collar
                    ctx.fillStyle = coatLight;
                    if(flip) ctx.fillRect(bx+w-3,18+bobY,3,4);
                    else ctx.fillRect(bx,18+bobY,3,4);
                    // Fold
                    ctx.fillStyle = coatDark; ctx.fillRect(bx+Math.floor(w/2),23+bobY,1,14);
                    // Belt
                    ctx.fillStyle = belt; ctx.fillRect(bx+1,32+bobY,w-2,2);
                    
                } else {
                    const flip=dir===5, bx=flip?ox+13:ox+14, w=20;
                    const sw = flip ? -sway : sway;
                    // Back-facing ¾
                    ctx.fillStyle = coatDark; ctx.fillRect(bx,21+bobY,w,20);
                    ctx.fillStyle = coat; ctx.fillRect(bx+1,21+bobY,w-2,19);
                    // Back tail — longer, billows
                    ctx.fillStyle = coatDark; ctx.fillRect(bx-sw,37+bobY,w+Math.abs(sw)+1,5+Math.abs(sway));
                    ctx.fillStyle = coat; ctx.fillRect(bx+1-sw,37+bobY,w-2+Math.abs(sw),4+Math.abs(sway));
                    // Round bottom
                    ctx.clearRect(bx-sw,41+Math.abs(sway)+bobY,1,1);
                    ctx.clearRect(bx+w+Math.abs(sw),41+Math.abs(sway)+bobY,1,1);
                    // Back collar — high, popped
                    ctx.fillStyle = coatLight; ctx.fillRect(bx+2,18+bobY,w-4,4);
                    ctx.fillStyle = coat; ctx.fillRect(bx+3,19+bobY,w-6,2);
                    // Back seam
                    ctx.fillStyle = coatDark; ctx.fillRect(bx+Math.floor(w/2),22+bobY,1,14);
                    // Back fold lines
                    ctx.fillRect(bx+5,24+bobY,1,12); ctx.fillRect(bx+w-6,24+bobY,1,12);
                    // Belt
                    ctx.fillStyle = belt; ctx.fillRect(bx+1,32+bobY,w-2,2);
                }
            },
            
            // Outlaw coat hides legs — full-length trench coat
            drawLegOverlay(ctx, p, c) {
                const { ox, dir, bobY, frame } = p;
                const coat = c.shirt;
                const coatDark = c.shirtDark;
                const sway = frame===0 ? 0 : (frame===1 ? 2 : -2);
                
                if (dir===0) {
                    ctx.fillStyle = coatDark; ctx.fillRect(ox+12-sway, 34+bobY, 12+sway, 8);
                    ctx.fillStyle = coat; ctx.fillRect(ox+13-sway, 34+bobY, 10+sway, 7);
                    ctx.fillStyle = coatDark; ctx.fillRect(ox+24+sway, 34+bobY, 12-sway, 8);
                    ctx.fillStyle = coat; ctx.fillRect(ox+25+sway, 34+bobY, 10-sway, 7);
                    ctx.fillStyle = '#2a1a1a'; ctx.fillRect(ox+23, 34+bobY, 2, 7);
                    ctx.fillStyle = coatDark; ctx.fillRect(ox+17-sway, 35+bobY, 1, 5);
                    ctx.fillRect(ox+30+sway, 35+bobY, 1, 5);
                } else if (dir===4) {
                    ctx.fillStyle = coatDark; ctx.fillRect(ox+14, 34+bobY, 20, 8+Math.abs(sway));
                    ctx.fillStyle = coat; ctx.fillRect(ox+15, 34+bobY, 18, 7+Math.abs(sway));
                    ctx.fillStyle = coatDark; ctx.fillRect(ox+23, 34+bobY, 2, 6+Math.abs(sway));
                } else if (dir===1||dir===7) {
                    const flip = dir===7, bx = flip ? ox+13 : ox+14, w = 20;
                    const sw = flip ? -sway : sway;
                    ctx.fillStyle = coatDark; ctx.fillRect(bx-sw, 34+bobY, w+Math.abs(sw)+1, 8);
                    ctx.fillStyle = coat; ctx.fillRect(bx+1-sw, 34+bobY, w-2+Math.abs(sw), 7);
                } else if (dir===2||dir===6) {
                    const flip = dir===6, bx = flip ? ox+14 : ox+16, w = 16;
                    const sw = flip ? -sway : sway;
                    ctx.fillStyle = coatDark; ctx.fillRect(bx-Math.abs(sw)-2, 34+bobY, w+Math.abs(sw)+4, 8);
                    ctx.fillStyle = coat; ctx.fillRect(bx-Math.abs(sw)-1, 34+bobY, w+Math.abs(sw)+2, 7);
                    if (flip) {
                        ctx.fillStyle = coatDark; ctx.fillRect(bx+w-1, 34+bobY, 4+Math.abs(sway), 8);
                        ctx.fillStyle = coat; ctx.fillRect(bx+w, 34+bobY, 3+Math.abs(sway), 7);
                    } else {
                        ctx.fillStyle = coatDark; ctx.fillRect(bx-3-Math.abs(sway), 34+bobY, 4+Math.abs(sway), 8);
                        ctx.fillStyle = coat; ctx.fillRect(bx-2-Math.abs(sway), 34+bobY, 3+Math.abs(sway), 7);
                    }
                } else {
                    const flip = dir===5, bx = flip ? ox+13 : ox+14, w = 20;
                    const sw = flip ? -sway : sway;
                    ctx.fillStyle = coatDark; ctx.fillRect(bx-sw, 34+bobY, w+Math.abs(sw)+1, 8+Math.abs(sway));
                    ctx.fillStyle = coat; ctx.fillRect(bx+1-sw, 34+bobY, w-2+Math.abs(sw), 7+Math.abs(sway));
                }
            }
        },
        
        heavy: {
            // Heavy gear: tactical vest with pouches, shoulder pads, helmet
            drawTorsoOverlay(ctx, p, c) {
                const { ox, dir, bobY } = p;
                const vest = '#3a4a30';
                const vestDark = '#2a3a20';
                const vestLight = '#4a5a40';
                const pouch = '#2a3020';
                
                if (dir===0||dir===4) {
                    // Vest panel
                    ctx.fillStyle = vest; ctx.fillRect(ox+15,23+bobY,18,9);
                    ctx.fillStyle = vestDark; ctx.fillRect(ox+15,23+bobY,1,9); ctx.fillRect(ox+32,23+bobY,1,9);
                    // Shoulder pads
                    ctx.fillStyle = vestLight; ctx.fillRect(ox+12,20+bobY,5,3); ctx.fillRect(ox+31,20+bobY,5,3);
                    ctx.fillStyle = vestDark; ctx.fillRect(ox+12,22+bobY,5,1); ctx.fillRect(ox+31,22+bobY,5,1);
                    if(dir===0) {
                        // Front pouches
                        ctx.fillStyle = pouch;
                        ctx.fillRect(ox+16,27+bobY,4,4); ctx.fillRect(ox+28,27+bobY,4,4);
                        ctx.fillStyle = vestDark;
                        ctx.fillRect(ox+16,27+bobY,4,1); ctx.fillRect(ox+28,27+bobY,4,1);
                        // Zipper
                        ctx.fillStyle = '#5a5a4a'; ctx.fillRect(ox+23,23+bobY,2,9);
                    } else {
                        // Back panel — MOLLE webbing
                        ctx.fillStyle = vestDark;
                        ctx.fillRect(ox+17,25+bobY,14,1); ctx.fillRect(ox+17,28+bobY,14,1);
                    }
                } else if (dir===1||dir===7) {
                    const flip=dir===7, bx=flip?ox+14:ox+15, w=19;
                    ctx.fillStyle = vest; ctx.fillRect(bx+1,23+bobY,w-2,9);
                    ctx.fillStyle = vestLight;
                    if(flip) ctx.fillRect(bx+w-5,20+bobY,5,3);
                    else ctx.fillRect(bx,20+bobY,5,3);
                    ctx.fillStyle = vestDark;
                    if(flip) ctx.fillRect(bx+w-5,22+bobY,5,1);
                    else ctx.fillRect(bx,22+bobY,5,1);
                    ctx.fillStyle = pouch;
                    if(flip) ctx.fillRect(bx+2,27+bobY,4,4);
                    else ctx.fillRect(bx+w-6,27+bobY,4,4);
                } else if (dir===2||dir===6) {
                    const flip=dir===6, bx=flip?ox+15:ox+17, w=14;
                    ctx.fillStyle = vest; ctx.fillRect(bx+1,23+bobY,w-2,9);
                    ctx.fillStyle = vestLight;
                    if(flip) ctx.fillRect(bx+w-4,20+bobY,4,3);
                    else ctx.fillRect(bx,20+bobY,4,3);
                    ctx.fillStyle = pouch;
                    ctx.fillRect(bx+4,27+bobY,3,4);
                } else {
                    const flip=dir===5, bx=flip?ox+14:ox+15, w=19;
                    ctx.fillStyle = vest; ctx.fillRect(bx+1,23+bobY,w-2,9);
                    ctx.fillStyle = vestLight;
                    if(flip) ctx.fillRect(bx,20+bobY,5,3); else ctx.fillRect(bx+w-5,20+bobY,5,3);
                    ctx.fillStyle = vestDark;
                    ctx.fillRect(bx+3,25+bobY,w-6,1); ctx.fillRect(bx+3,28+bobY,w-6,1);
                }
            },
            drawHeadOverlay(ctx, p, c) {
                const { ox, dir, bobY } = p;
                const helm = '#3a4a30';
                const helmDark = '#2a3a20';
                const helmLight = '#4a5a40';
                // Helmet sits on top of head
                if (dir===0) {
                    ctx.fillStyle = helm; ctx.fillRect(ox+16,5+bobY,16,5);
                    ctx.fillStyle = helmLight; ctx.fillRect(ox+17,5+bobY,14,2);
                    ctx.fillStyle = helmDark; ctx.fillRect(ox+16,9+bobY,16,1);
                    // Brim
                    ctx.fillStyle = helmDark; ctx.fillRect(ox+15,9+bobY,18,2);
                } else if (dir===1||dir===7) {
                    const flip=dir===7, bx=flip?ox+14:ox+17;
                    ctx.fillStyle = helm; ctx.fillRect(bx,5+bobY,15,5);
                    ctx.fillStyle = helmLight; ctx.fillRect(bx+1,5+bobY,13,2);
                    ctx.fillStyle = helmDark; ctx.fillRect(bx-1,9+bobY,17,2);
                } else if (dir===2||dir===6) {
                    const flip=dir===6, bx=flip?ox+13:ox+19;
                    ctx.fillStyle = helm; ctx.fillRect(bx,5+bobY,13,5);
                    ctx.fillStyle = helmLight; ctx.fillRect(bx+1,5+bobY,11,2);
                    ctx.fillStyle = helmDark; ctx.fillRect(bx-1,9+bobY,15,2);
                } else if (dir===3||dir===5) {
                    const flip=dir===5, bx=flip?ox+14:ox+17;
                    ctx.fillStyle = helm; ctx.fillRect(bx,5+bobY,15,5);
                    ctx.fillStyle = helmLight; ctx.fillRect(bx+1,5+bobY,13,2);
                    ctx.fillStyle = helmDark; ctx.fillRect(bx,9+bobY,15,2);
                } else if (dir===4) {
                    ctx.fillStyle = helm; ctx.fillRect(ox+16,5+bobY,16,6);
                    ctx.fillStyle = helmLight; ctx.fillRect(ox+17,5+bobY,14,2);
                    ctx.fillStyle = helmDark; ctx.fillRect(ox+17,10+bobY,14,1);
                }
            },
            drawLegOverlay(ctx, p, c) {
                const { ox, dir, legSpread } = p;
                const cargo = '#3a4a2a';
                // Cargo pockets on thighs
                if (dir===0||dir===4) {
                    const lx=dir===0?14:15, rx=dir===0?27:27;
                    ctx.fillStyle = cargo;
                    ctx.fillRect(ox+lx-legSpread,36,5,3);
                    ctx.fillRect(ox+rx+legSpread,36,5,3);
                }
            }
        },
        
        riot: {
            // Heavy plate carrier, armored shoulders, riot visor, leg guards
            drawTorsoOverlay(ctx, p, c) {
                const { ox, dir, bobY } = p;
                const plate = '#3a3a44';
                const plateDark = '#2a2a34';
                const plateLight = '#4a4a54';
                const rivet = '#6a6a7a';
                
                if (dir===0||dir===4) {
                    // Plate carrier — thick, covers full torso
                    ctx.fillStyle = plateDark; ctx.fillRect(ox+13,22+bobY,22,10);
                    ctx.fillStyle = plate; ctx.fillRect(ox+14,22+bobY,20,9);
                    // Armored shoulder guards — wider than torso
                    ctx.fillStyle = plateLight; ctx.fillRect(ox+10,19+bobY,7,4); ctx.fillRect(ox+31,19+bobY,7,4);
                    ctx.fillStyle = plateDark; ctx.fillRect(ox+10,22+bobY,7,1); ctx.fillRect(ox+31,22+bobY,7,1);
                    // Rivets on shoulders
                    ctx.fillStyle = rivet;
                    ctx.fillRect(ox+12,20+bobY,1,1); ctx.fillRect(ox+15,20+bobY,1,1);
                    ctx.fillRect(ox+33,20+bobY,1,1); ctx.fillRect(ox+36,20+bobY,1,1);
                    if(dir===0) {
                        // Front plate detail
                        ctx.fillStyle = plateLight; ctx.fillRect(ox+16,23+bobY,6,7); ctx.fillRect(ox+26,23+bobY,6,7);
                        ctx.fillStyle = plateDark; ctx.fillRect(ox+23,23+bobY,2,8);
                        // Collar guard
                        ctx.fillStyle = plate; ctx.fillRect(ox+17,20+bobY,14,3);
                        ctx.fillStyle = plateDark; ctx.fillRect(ox+20,20+bobY,8,1);
                    } else {
                        ctx.fillStyle = plateDark;
                        ctx.fillRect(ox+17,24+bobY,14,1); ctx.fillRect(ox+17,27+bobY,14,1);
                    }
                } else if (dir===1||dir===7) {
                    const flip=dir===7, bx=flip?ox+13:ox+14, w=20;
                    ctx.fillStyle = plateDark; ctx.fillRect(bx,22+bobY,w,10);
                    ctx.fillStyle = plate; ctx.fillRect(bx+1,22+bobY,w-2,9);
                    // Shoulder guard
                    ctx.fillStyle = plateLight;
                    if(flip) ctx.fillRect(bx+w-2,19+bobY,6,4);
                    else ctx.fillRect(bx-4,19+bobY,6,4);
                    ctx.fillStyle = plateDark;
                    if(flip) ctx.fillRect(bx+w-2,22+bobY,6,1);
                    else ctx.fillRect(bx-4,22+bobY,6,1);
                    ctx.fillStyle = rivet;
                    if(flip) { ctx.fillRect(bx+w,20+bobY,1,1); ctx.fillRect(bx+w+2,20+bobY,1,1); }
                    else { ctx.fillRect(bx-3,20+bobY,1,1); ctx.fillRect(bx-1,20+bobY,1,1); }
                } else if (dir===2||dir===6) {
                    const flip=dir===6, bx=flip?ox+14:ox+16, w=16;
                    ctx.fillStyle = plateDark; ctx.fillRect(bx,22+bobY,w,10);
                    ctx.fillStyle = plate; ctx.fillRect(bx+1,22+bobY,w-2,9);
                    ctx.fillStyle = plateLight;
                    if(flip) ctx.fillRect(bx+w-1,19+bobY,5,4);
                    else ctx.fillRect(bx-4,19+bobY,5,4);
                    ctx.fillStyle = plateDark;
                    if(flip) ctx.fillRect(bx+w-1,22+bobY,5,1);
                    else ctx.fillRect(bx-4,22+bobY,5,1);
                } else {
                    const flip=dir===5, bx=flip?ox+13:ox+14, w=20;
                    ctx.fillStyle = plateDark; ctx.fillRect(bx,22+bobY,w,10);
                    ctx.fillStyle = plate; ctx.fillRect(bx+1,22+bobY,w-2,9);
                    ctx.fillStyle = plateLight;
                    if(flip) ctx.fillRect(bx-4,19+bobY,6,4); else ctx.fillRect(bx+w-2,19+bobY,6,4);
                    ctx.fillStyle = plateDark;
                    if(flip) ctx.fillRect(bx-4,22+bobY,6,1); else ctx.fillRect(bx+w-2,22+bobY,6,1);
                    ctx.fillStyle = plateDark;
                    ctx.fillRect(bx+3,24+bobY,w-6,1); ctx.fillRect(bx+3,27+bobY,w-6,1);
                }
            },
            drawHeadOverlay(ctx, p, c) {
                const { ox, dir, bobY } = p;
                const helm = '#3a3a44';
                const helmDark = '#2a2a34';
                const visor = '#556688';
                const visorDark = '#334466';
                // Riot helmet with visor
                if (dir===0) {
                    ctx.fillStyle = helm; ctx.fillRect(ox+15,5+bobY,18,6);
                    ctx.fillStyle = helmDark; ctx.fillRect(ox+16,5+bobY,16,2);
                    // Visor
                    ctx.fillStyle = visor; ctx.fillRect(ox+17,10+bobY,14,4);
                    ctx.fillStyle = visorDark; ctx.fillRect(ox+17,13+bobY,14,1);
                } else if (dir===1||dir===7) {
                    const flip=dir===7, bx=flip?ox+13:ox+17;
                    ctx.fillStyle = helm; ctx.fillRect(bx,5+bobY,16,6);
                    ctx.fillStyle = helmDark; ctx.fillRect(bx+1,5+bobY,14,2);
                    ctx.fillStyle = visor;
                    if(flip) ctx.fillRect(bx,10+bobY,8,3);
                    else ctx.fillRect(bx+8,10+bobY,8,3);
                } else if (dir===2||dir===6) {
                    const flip=dir===6, bx=flip?ox+12:ox+19;
                    ctx.fillStyle = helm; ctx.fillRect(bx,5+bobY,14,6);
                    ctx.fillStyle = helmDark; ctx.fillRect(bx+1,5+bobY,12,2);
                    ctx.fillStyle = visor;
                    if(flip) ctx.fillRect(bx-1,10+bobY,5,3);
                    else ctx.fillRect(bx+10,10+bobY,5,3);
                } else if (dir===3||dir===5) {
                    const flip=dir===5, bx=flip?ox+13:ox+17;
                    ctx.fillStyle = helm; ctx.fillRect(bx,5+bobY,16,7);
                    ctx.fillStyle = helmDark; ctx.fillRect(bx+1,5+bobY,14,2);
                } else if (dir===4) {
                    ctx.fillStyle = helm; ctx.fillRect(ox+15,5+bobY,18,7);
                    ctx.fillStyle = helmDark; ctx.fillRect(ox+16,5+bobY,16,2);
                    ctx.fillStyle = helmDark; ctx.fillRect(ox+17,11+bobY,14,1);
                }
            },
            drawLegOverlay(ctx, p, c) {
                const { ox, dir, legSpread } = p;
                const guard = '#3a3a44';
                const guardDark = '#2a2a34';
                // Shin guards on both legs
                if (dir===0||dir===4) {
                    const lx=dir===0?14:15, rx=dir===0?27:27;
                    ctx.fillStyle = guard;
                    ctx.fillRect(ox+lx-legSpread,35,6,5); ctx.fillRect(ox+rx+legSpread,35,6,5);
                    ctx.fillStyle = guardDark;
                    ctx.fillRect(ox+lx-legSpread,35,1,5); ctx.fillRect(ox+lx+5-legSpread,35,1,5);
                    ctx.fillRect(ox+rx+legSpread,35,1,5); ctx.fillRect(ox+rx+5+legSpread,35,1,5);
                } else if (dir===1||dir===7) {
                    const flip=dir===7,lx=flip?13:15,rx=flip?24:26;
                    ctx.fillStyle = guard;
                    ctx.fillRect(ox+lx-legSpread,35,5,5); ctx.fillRect(ox+rx+legSpread,35,5,5);
                } else if (dir===2||dir===6) {
                    const bx=dir===6?ox+15:ox+17;
                    ctx.fillStyle = guard;
                    ctx.fillRect(bx+4-legSpread,35,5,5);
                }
            },
            drawBootOverlay(ctx, p, c) {
                const { ox, dir, legSpread } = p;
                const boot = '#2a2a34';
                // Armored boot caps
                if (dir===0||dir===4) {
                    const lx=dir===0?13:14, rx=dir===0?27:27;
                    ctx.fillStyle = boot;
                    ctx.fillRect(ox+lx-legSpread,40,2,2); ctx.fillRect(ox+lx+6-legSpread,40,2,2);
                    ctx.fillRect(ox+rx+legSpread,40,2,2); ctx.fillRect(ox+rx+6+legSpread,40,2,2);
                }
            }
        }
    },
    
    robotic: {
        // Robotic: angular head, visor, panel lines, joint marks, antenna
        drawHeadOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const led = '#44ddff';
            const ledDim = '#2288aa';
            const panel = '#333344';
            
            if (dir===0) {
                // Visor band across eyes
                ctx.fillStyle = ledDim; ctx.fillRect(ox+17,12+bobY,14,3);
                ctx.fillStyle = led; ctx.fillRect(ox+18,13+bobY,3,1); ctx.fillRect(ox+27,13+bobY,3,1);
                // Antenna nub
                ctx.fillStyle = panel; ctx.fillRect(ox+23,6+bobY,2,2);
                ctx.fillStyle = led; ctx.fillRect(ox+23,5+bobY,2,1);
                // Jaw panel line
                ctx.fillStyle = panel; ctx.fillRect(ox+19,18+bobY,10,1);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+17;
                ctx.fillStyle = ledDim; ctx.fillRect(bx+1,12+bobY,12,3);
                ctx.fillStyle = led; ctx.fillRect(flip?bx+8:bx+2,13+bobY,3,1);
                ctx.fillStyle = panel; ctx.fillRect(bx+6,6+bobY,2,2);
                ctx.fillStyle = led; ctx.fillRect(bx+6,5+bobY,2,1);
                ctx.fillStyle = panel; ctx.fillRect(bx+3,17+bobY,8,1);
            } else if (dir===2||dir===6) {
                const flip=dir===6, bx=flip?ox+13:ox+19;
                ctx.fillStyle = ledDim; ctx.fillRect(bx+1,12+bobY,10,3);
                ctx.fillStyle = led; ctx.fillRect(flip?bx+7:bx+1,13+bobY,3,1);
                ctx.fillStyle = panel; ctx.fillRect(bx+5,6+bobY,2,2);
                ctx.fillStyle = led; ctx.fillRect(bx+5,5+bobY,2,1);
            } else if (dir===3||dir===5) {
                const flip=dir===5, bx=flip?ox+14:ox+17;
                // Back of head — panel seam
                ctx.fillStyle = panel; ctx.fillRect(bx+5,9+bobY,3,8);
                ctx.fillStyle = ledDim; ctx.fillRect(bx+6,10+bobY,1,6);
                ctx.fillStyle = panel; ctx.fillRect(bx+6,6+bobY,2,2);
                ctx.fillStyle = led; ctx.fillRect(bx+6,5+bobY,2,1);
            } else if (dir===4) {
                // Back center — seam + antenna
                ctx.fillStyle = panel; ctx.fillRect(ox+22,9+bobY,4,8);
                ctx.fillStyle = ledDim; ctx.fillRect(ox+23,10+bobY,2,6);
                ctx.fillStyle = panel; ctx.fillRect(ox+23,6+bobY,2,2);
                ctx.fillStyle = led; ctx.fillRect(ox+23,5+bobY,2,1);
            }
        },
        drawTorsoOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const panel = '#333344';
            const rivet = '#555566';
            const core = '#44ddff';
            
            if (dir===0) {
                // Chest panel lines
                ctx.fillStyle = panel;
                ctx.fillRect(ox+18,22+bobY,1,8); ctx.fillRect(ox+29,22+bobY,1,8);
                // Center core light
                ctx.fillStyle = core; ctx.fillRect(ox+22,24+bobY,4,2);
                // Rivets
                ctx.fillStyle = rivet;
                ctx.fillRect(ox+16,22+bobY,1,1); ctx.fillRect(ox+31,22+bobY,1,1);
                ctx.fillRect(ox+16,28+bobY,1,1); ctx.fillRect(ox+31,28+bobY,1,1);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+17;
                ctx.fillStyle = panel;
                ctx.fillRect(bx+3,22+bobY,1,8); ctx.fillRect(bx+10,22+bobY,1,8);
                ctx.fillStyle = core; ctx.fillRect(bx+5,24+bobY,3,2);
                ctx.fillStyle = rivet;
                ctx.fillRect(bx+1,22+bobY,1,1); ctx.fillRect(bx+12,22+bobY,1,1);
            } else if (dir===2||dir===6) {
                const flip=dir===6, bx=flip?ox+13:ox+19;
                ctx.fillStyle = panel; ctx.fillRect(bx+4,22+bobY,1,8);
                ctx.fillStyle = core; ctx.fillRect(flip?bx+6:bx+2,25+bobY,2,1);
            } else if (dir===4) {
                // Back panel seam
                ctx.fillStyle = panel;
                ctx.fillRect(ox+20,22+bobY,1,8); ctx.fillRect(ox+27,22+bobY,1,8);
                ctx.fillRect(ox+22,26+bobY,4,1);
                ctx.fillStyle = rivet;
                ctx.fillRect(ox+16,22+bobY,1,1); ctx.fillRect(ox+31,22+bobY,1,1);
            }
        },
        drawBootOverlay(ctx, p, c) {
            const { ox, dir, bobY, legSpread } = p;
            const joint = '#555566';
            // Joint circles at ankles
            if (dir===0||dir===4) {
                ctx.fillStyle = joint;
                ctx.fillRect(ox+15-legSpread,38,2,2); ctx.fillRect(ox+29+legSpread,38,2,2);
            }
        }
    },
    
    infected: {
        // Infected: glowing eye, growth patches, discolored veins
        drawHeadOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const glow = '#66ff44';
            const growth = '#4a6644';
            const vein = '#3a5533';
            
            if (dir===0) {
                // Glowing left eye
                ctx.fillStyle = glow; ctx.fillRect(ox+19,13+bobY,3,2);
                // Growth on right side of face
                ctx.fillStyle = growth;
                ctx.fillRect(ox+27,10+bobY,3,4); ctx.fillRect(ox+28,14+bobY,2,2);
                ctx.fillStyle = vein; ctx.fillRect(ox+27,11+bobY,1,3);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+17;
                ctx.fillStyle = glow; ctx.fillRect(flip?bx+8:bx+2,13+bobY,3,2);
                ctx.fillStyle = growth; ctx.fillRect(flip?bx+1:bx+10,10+bobY,3,4);
            } else if (dir===2||dir===6) {
                const flip=dir===6, bx=flip?ox+13:ox+19;
                ctx.fillStyle = glow; ctx.fillRect(flip?bx+7:bx+2,13+bobY,2,2);
                ctx.fillStyle = growth; ctx.fillRect(flip?bx+1:bx+9,10+bobY,2,5);
            }
        },
        drawTorsoOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const growth = '#4a6644';
            const vein = '#3a5533';
            
            if (dir===0||dir===4) {
                // Growth patches on shoulder
                ctx.fillStyle = growth;
                ctx.fillRect(ox+28,21+bobY,4,3); ctx.fillRect(ox+29,24+bobY,2,2);
                // Vein lines down arm
                ctx.fillStyle = vein;
                ctx.fillRect(ox+14,23+bobY,1,5); ctx.fillRect(ox+33,23+bobY,1,5);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+17;
                ctx.fillStyle = growth; ctx.fillRect(flip?bx+1:bx+10,21+bobY,3,3);
                ctx.fillStyle = vein; ctx.fillRect(flip?bx+12:bx+1,24+bobY,1,4);
            }
        }
    },
    
    // ── FOUNDRY GEAR OVERLAYS ──
    // Each foundry has a unique outfit drawn over the base character sprite.
    // Colors are pulled from the foundry palette at runtime via the preset.
    
    foundry_terracorp: {
        // Terracorp: Military tactical vest, red chevron patches, beret
        drawHeadOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const beret = '#3a4a32', beretDk = '#2a3a22', badge = '#8a2a2a';
            if (dir===0) {
                // Beret sits on top of head, tilted slightly right
                ctx.fillStyle = beret; ctx.fillRect(ox+18,7+bobY,12,4);
                ctx.fillStyle = beretDk; ctx.fillRect(ox+18,7+bobY,12,1);
                ctx.fillStyle = badge; ctx.fillRect(ox+27,8+bobY,2,2); // red pip
            } else if (dir===4) {
                ctx.fillStyle = beret; ctx.fillRect(ox+18,7+bobY,12,4);
                ctx.fillStyle = beretDk; ctx.fillRect(ox+18,10+bobY,12,1);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+16:ox+17;
                ctx.fillStyle = beret; ctx.fillRect(bx+2,7+bobY,10,4);
                ctx.fillStyle = beretDk; ctx.fillRect(bx+2,7+bobY,10,1);
                if(!flip) { ctx.fillStyle = badge; ctx.fillRect(bx+9,8+bobY,2,2); }
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+17:ox+20;
                ctx.fillStyle = beret; ctx.fillRect(bx,7+bobY,8,4);
                ctx.fillStyle = beretDk; ctx.fillRect(bx,7+bobY,8,1);
            } else {
                const flip=dir===5, bx=flip?ox+16:ox+17;
                ctx.fillStyle = beret; ctx.fillRect(bx+2,7+bobY,10,4);
                ctx.fillStyle = beretDk; ctx.fillRect(bx+2,10+bobY,10,1);
            }
        },
        drawTorsoOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const vest = '#3a4a32', vestDk = '#2a3a22', vestLt = '#4a5a42';
            const chevron = '#8a2a2a', pocket = '#2a3a22', buckle = '#4a4a4a';
            if (dir===0||dir===4) {
                // Tactical vest — front plate
                ctx.fillStyle = vestDk; ctx.fillRect(ox+15,21+bobY,18,10);
                ctx.fillStyle = vest; ctx.fillRect(ox+16,21+bobY,16,9);
                // Shoulder straps
                ctx.fillStyle = vestLt; ctx.fillRect(ox+14,20+bobY,4,2); ctx.fillRect(ox+30,20+bobY,4,2);
                if(dir===0) {
                    // Red chevron patch on left breast
                    ctx.fillStyle = chevron;
                    ctx.fillRect(ox+17,23+bobY,5,1); ctx.fillRect(ox+18,24+bobY,3,1); ctx.fillRect(ox+19,25+bobY,1,1);
                    // Breast pockets
                    ctx.fillStyle = pocket; ctx.fillRect(ox+25,23+bobY,5,3);
                    ctx.fillStyle = vestLt; ctx.fillRect(ox+25,23+bobY,5,1);
                    // Center buckle
                    ctx.fillStyle = buckle; ctx.fillRect(ox+23,26+bobY,2,3);
                } else {
                    // Back: horizontal strap
                    ctx.fillStyle = vestLt; ctx.fillRect(ox+17,25+bobY,14,2);
                }
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+15;
                ctx.fillStyle = vestDk; ctx.fillRect(bx+2,21+bobY,15,10);
                ctx.fillStyle = vest; ctx.fillRect(bx+3,21+bobY,13,9);
                ctx.fillStyle = vestLt;
                if(flip) ctx.fillRect(bx+14,20+bobY,3,2); else ctx.fillRect(bx+1,20+bobY,3,2);
                ctx.fillStyle = chevron; ctx.fillRect(bx+5,23+bobY,3,1); ctx.fillRect(bx+6,24+bobY,1,1);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+17:ox+19;
                ctx.fillStyle = vestDk; ctx.fillRect(bx,21+bobY,10,10);
                ctx.fillStyle = vest; ctx.fillRect(bx+1,21+bobY,8,9);
                ctx.fillStyle = buckle; ctx.fillRect(bx+4,27+bobY,2,2);
            } else {
                const flip=dir===5, bx=flip?ox+14:ox+15;
                ctx.fillStyle = vestDk; ctx.fillRect(bx+2,21+bobY,15,10);
                ctx.fillStyle = vest; ctx.fillRect(bx+3,21+bobY,13,9);
                ctx.fillStyle = vestLt; ctx.fillRect(bx+4,25+bobY,11,2);
            }
        },
        drawLegOverlay(ctx, p, c) {
            const { ox, dir, legSpread } = p;
            const pad = '#3a4a32', padDk = '#2a3a22';
            if (dir===0||dir===4) {
                // Knee pads
                ctx.fillStyle = pad;
                ctx.fillRect(ox+17-legSpread,36,4,3); ctx.fillRect(ox+27+legSpread,36,4,3);
                ctx.fillStyle = padDk;
                ctx.fillRect(ox+17-legSpread,38,4,1); ctx.fillRect(ox+27+legSpread,38,4,1);
            }
        }
    },
    
    foundry_ucr: {
        // UCR: Pre-war polished chrome plate, blue-trimmed shoulder guards, visor
        drawHeadOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const visor = '#6a8aaa', visorDk = '#4a6a8a', frame = '#5a5a6a';
            if (dir===0) {
                // Full face visor — blue-tinted transparent shield
                ctx.fillStyle = frame; ctx.fillRect(ox+17,9+bobY,14,2);
                ctx.fillStyle = visor; ctx.fillRect(ox+18,11+bobY,12,4);
                ctx.fillStyle = visorDk; ctx.fillRect(ox+18,14+bobY,12,1);
                // Highlight strip
                ctx.fillStyle = '#9abacc'; ctx.fillRect(ox+19,11+bobY,5,1);
            } else if (dir===4) {
                ctx.fillStyle = frame; ctx.fillRect(ox+17,9+bobY,14,2);
                ctx.fillStyle = '#4a4a5a'; ctx.fillRect(ox+18,11+bobY,12,3);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+16:ox+17;
                ctx.fillStyle = frame; ctx.fillRect(bx+2,9+bobY,11,2);
                ctx.fillStyle = visor; ctx.fillRect(bx+3,11+bobY,8,3);
                ctx.fillStyle = '#9abacc'; ctx.fillRect(bx+4,11+bobY,3,1);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+18:ox+20;
                ctx.fillStyle = frame; ctx.fillRect(bx,9+bobY,7,2);
                ctx.fillStyle = visor; ctx.fillRect(bx+1,11+bobY,5,3);
            } else {
                const flip=dir===5, bx=flip?ox+16:ox+17;
                ctx.fillStyle = frame; ctx.fillRect(bx+2,9+bobY,11,2);
                ctx.fillStyle = '#4a4a5a'; ctx.fillRect(bx+3,11+bobY,8,2);
            }
        },
        drawTorsoOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const plate = '#5a5a6a', plateLt = '#7a7a8a', plateDk = '#3a3a4a';
            const trim = '#6a8aaa', stencil = '#ddeeff';
            if (dir===0||dir===4) {
                // Polished chest plate
                ctx.fillStyle = plateDk; ctx.fillRect(ox+15,21+bobY,18,10);
                ctx.fillStyle = plate; ctx.fillRect(ox+16,22+bobY,16,8);
                // Chrome shoulder guards with blue trim
                ctx.fillStyle = plateLt; ctx.fillRect(ox+12,19+bobY,6,4); ctx.fillRect(ox+30,19+bobY,6,4);
                ctx.fillStyle = trim; ctx.fillRect(ox+12,22+bobY,6,1); ctx.fillRect(ox+30,22+bobY,6,1);
                if(dir===0) {
                    // UCR stencil on chest (white rectangle = simplified text)
                    ctx.fillStyle = stencil;
                    ctx.fillRect(ox+20,24+bobY,8,1);
                    ctx.fillRect(ox+21,25+bobY,6,1);
                    // Polish highlight
                    ctx.fillStyle = plateLt; ctx.fillRect(ox+17,22+bobY,4,2);
                } else {
                    ctx.fillStyle = plateDk;
                    ctx.fillRect(ox+18,24+bobY,12,1); ctx.fillRect(ox+18,27+bobY,12,1);
                }
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+15;
                ctx.fillStyle = plateDk; ctx.fillRect(bx+2,21+bobY,15,10);
                ctx.fillStyle = plate; ctx.fillRect(bx+3,22+bobY,13,8);
                ctx.fillStyle = plateLt;
                if(flip) ctx.fillRect(bx+14,19+bobY,4,4); else ctx.fillRect(bx,19+bobY,4,4);
                ctx.fillStyle = trim;
                if(flip) ctx.fillRect(bx+14,22+bobY,4,1); else ctx.fillRect(bx,22+bobY,4,1);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+17:ox+19;
                ctx.fillStyle = plateDk; ctx.fillRect(bx,21+bobY,10,10);
                ctx.fillStyle = plate; ctx.fillRect(bx+1,22+bobY,8,8);
                ctx.fillStyle = plateLt; ctx.fillRect(bx+1,22+bobY,3,2);
            } else {
                const flip=dir===5, bx=flip?ox+14:ox+15;
                ctx.fillStyle = plateDk; ctx.fillRect(bx+2,21+bobY,15,10);
                ctx.fillStyle = plate; ctx.fillRect(bx+3,22+bobY,13,8);
                ctx.fillStyle = plateDk; ctx.fillRect(bx+5,25+bobY,9,1);
            }
        }
    },
    
    foundry_deralict: {
        // Deralict: Heavy industrial welding gear, orange hazard stripes, welding mask
        drawHeadOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const mask = '#4a4038', maskLt = '#5a5048', lens = '#ccaa22', lensDk = '#aa8811';
            if (dir===0) {
                // Welding mask — flipped up, showing dark glass faceplate
                ctx.fillStyle = mask; ctx.fillRect(ox+16,8+bobY,16,4);
                ctx.fillStyle = maskLt; ctx.fillRect(ox+17,8+bobY,14,3);
                // Dark visor slit
                ctx.fillStyle = lensDk; ctx.fillRect(ox+18,9+bobY,12,2);
                ctx.fillStyle = lens; ctx.fillRect(ox+19,9+bobY,4,1); // reflection
            } else if (dir===4) {
                ctx.fillStyle = mask; ctx.fillRect(ox+16,8+bobY,16,4);
                ctx.fillStyle = '#3a3028'; ctx.fillRect(ox+17,9+bobY,14,2);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+15:ox+16;
                ctx.fillStyle = mask; ctx.fillRect(bx+2,8+bobY,12,4);
                ctx.fillStyle = lensDk; ctx.fillRect(bx+3,9+bobY,8,2);
                ctx.fillStyle = lens; ctx.fillRect(bx+4,9+bobY,3,1);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+17:ox+19;
                ctx.fillStyle = mask; ctx.fillRect(bx,8+bobY,8,4);
                ctx.fillStyle = lensDk; ctx.fillRect(bx+1,9+bobY,5,2);
            } else {
                const flip=dir===5, bx=flip?ox+15:ox+16;
                ctx.fillStyle = mask; ctx.fillRect(bx+2,8+bobY,12,4);
                ctx.fillStyle = '#3a3028'; ctx.fillRect(bx+3,9+bobY,8,2);
            }
        },
        drawTorsoOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const apron = '#3a3028', apronLt = '#4a4038', apronDk = '#2a2018';
            const hazard = '#cc6622', hazardDk = '#aa5511', buckle = '#5a4a3a';
            if (dir===0||dir===4) {
                // Heavy welding apron
                ctx.fillStyle = apronDk; ctx.fillRect(ox+14,21+bobY,20,11);
                ctx.fillStyle = apron; ctx.fillRect(ox+15,21+bobY,18,10);
                // Heavy shoulder guards
                ctx.fillStyle = apronLt; ctx.fillRect(ox+11,19+bobY,7,4); ctx.fillRect(ox+30,19+bobY,7,4);
                if(dir===0) {
                    // Orange hazard chevrons across chest
                    ctx.fillStyle = hazard;
                    ctx.fillRect(ox+16,25+bobY,16,2);
                    ctx.fillStyle = hazardDk;
                    ctx.fillRect(ox+16,27+bobY,16,1);
                    // Buckle/clasp
                    ctx.fillStyle = buckle; ctx.fillRect(ox+23,22+bobY,2,3);
                    // Tool loops
                    ctx.fillStyle = '#5a4a3a'; ctx.fillRect(ox+17,28+bobY,2,2); ctx.fillRect(ox+29,28+bobY,2,2);
                } else {
                    ctx.fillStyle = hazard; ctx.fillRect(ox+16,25+bobY,16,2);
                    ctx.fillStyle = apronDk; ctx.fillRect(ox+19,22+bobY,10,1);
                }
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+13:ox+14;
                ctx.fillStyle = apronDk; ctx.fillRect(bx+2,21+bobY,16,11);
                ctx.fillStyle = apron; ctx.fillRect(bx+3,21+bobY,14,10);
                ctx.fillStyle = hazard; ctx.fillRect(bx+3,25+bobY,14,2);
                ctx.fillStyle = apronLt;
                if(flip) ctx.fillRect(bx+15,19+bobY,4,4); else ctx.fillRect(bx,19+bobY,4,4);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+16:ox+18;
                ctx.fillStyle = apronDk; ctx.fillRect(bx,21+bobY,11,11);
                ctx.fillStyle = apron; ctx.fillRect(bx+1,21+bobY,9,10);
                ctx.fillStyle = hazard; ctx.fillRect(bx+1,25+bobY,9,2);
            } else {
                const flip=dir===5, bx=flip?ox+13:ox+14;
                ctx.fillStyle = apronDk; ctx.fillRect(bx+2,21+bobY,16,11);
                ctx.fillStyle = apron; ctx.fillRect(bx+3,21+bobY,14,10);
                ctx.fillStyle = hazard; ctx.fillRect(bx+3,25+bobY,14,2);
            }
        },
        drawLegOverlay(ctx, p, c) {
            const { ox, dir, legSpread } = p;
            const gaunt = '#4a4038';
            // Heavy gauntlets / leg wraps
            if (dir===0||dir===4) {
                ctx.fillStyle = gaunt;
                ctx.fillRect(ox+15-legSpread,35,6,3); ctx.fillRect(ox+27+legSpread,35,6,3);
            }
        }
    },
    
    foundry_sworn: {
        // Sworn: Rebel field gear — bandolier, green arm wraps, bandana
        drawHeadOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const bandana = '#4a6a3a', bandanaDk = '#3a5a2a';
            if (dir===0) {
                // Bandana tied around forehead
                ctx.fillStyle = bandana; ctx.fillRect(ox+17,9+bobY,14,3);
                ctx.fillStyle = bandanaDk; ctx.fillRect(ox+17,11+bobY,14,1);
                // Tied knot on right side
                ctx.fillStyle = bandana; ctx.fillRect(ox+30,10+bobY,3,2);
                ctx.fillStyle = bandanaDk; ctx.fillRect(ox+31,12+bobY,2,2);
            } else if (dir===4) {
                ctx.fillStyle = bandana; ctx.fillRect(ox+17,9+bobY,14,3);
                // Tails hanging down in back
                ctx.fillStyle = bandanaDk; ctx.fillRect(ox+22,11+bobY,2,4); ctx.fillRect(ox+25,11+bobY,2,3);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+16:ox+17;
                ctx.fillStyle = bandana; ctx.fillRect(bx+2,9+bobY,11,3);
                if(!flip) { ctx.fillStyle = bandanaDk; ctx.fillRect(bx+11,10+bobY,2,2); }
                else { ctx.fillStyle = bandanaDk; ctx.fillRect(bx+1,10+bobY,2,2); }
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+17:ox+20;
                ctx.fillStyle = bandana; ctx.fillRect(bx,9+bobY,8,3);
                ctx.fillStyle = bandanaDk; ctx.fillRect(bx,11+bobY,8,1);
            } else {
                const flip=dir===5, bx=flip?ox+16:ox+17;
                ctx.fillStyle = bandana; ctx.fillRect(bx+2,9+bobY,11,3);
                ctx.fillStyle = bandanaDk; ctx.fillRect(bx+5,11+bobY,2,3);
            }
        },
        drawTorsoOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const strap = '#4a3a28', bandolier = '#5a4a38', bullet = '#8a7a6a';
            const armWrap = '#4a6a3a', armWrapDk = '#3a5a2a';
            if (dir===0||dir===4) {
                // Diagonal bandolier — strap across chest
                ctx.fillStyle = bandolier;
                for(let i=0;i<9;i++) { ctx.fillRect(ox+16+i,21+Math.floor(i*0.9)+bobY,2,2); }
                // Bullet loops on bandolier
                if(dir===0) {
                    ctx.fillStyle = bullet;
                    for(let i=0;i<4;i++) { ctx.fillRect(ox+17+i*3,23+Math.floor(i*0.9)+bobY,1,2); }
                }
                // Arm wraps
                ctx.fillStyle = armWrap;
                ctx.fillRect(ox+12,22+bobY,3,2); ctx.fillRect(ox+33,22+bobY,3,2);
                ctx.fillRect(ox+12,25+bobY,3,2); ctx.fillRect(ox+33,25+bobY,3,2);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+15;
                ctx.fillStyle = bandolier;
                for(let i=0;i<7;i++) { ctx.fillRect(bx+3+i,22+Math.floor(i*0.8)+bobY,2,2); }
                ctx.fillStyle = armWrap;
                if(flip) ctx.fillRect(bx+14,23+bobY,3,2); else ctx.fillRect(bx,23+bobY,3,2);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+17:ox+19;
                ctx.fillStyle = bandolier; ctx.fillRect(bx+3,22+bobY,2,8);
                ctx.fillStyle = bullet; ctx.fillRect(bx+3,23+bobY,1,1); ctx.fillRect(bx+3,26+bobY,1,1);
            } else {
                const flip=dir===5, bx=flip?ox+14:ox+15;
                ctx.fillStyle = bandolier;
                for(let i=0;i<7;i++) { ctx.fillRect(bx+10-i,22+Math.floor(i*0.8)+bobY,2,2); }
            }
        }
    },
    
    foundry_blackreach: {
        // Blackreach: Shadow elite — hooded cloak, gold-trimmed collar, dark wrappings
        drawHeadOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const hood = '#1a1a22', hoodLt = '#2a2a32', gold = '#aa8833', goldDk = '#886622';
            if (dir===0) {
                // Hood — dark cowl framing face
                ctx.fillStyle = hood; ctx.fillRect(ox+15,7+bobY,18,6);
                ctx.fillStyle = hoodLt; ctx.fillRect(ox+17,8+bobY,14,4);
                // Gold trim at hood edge
                ctx.fillStyle = gold; ctx.fillRect(ox+16,12+bobY,16,1);
                // Hood opening shows face (leave center clear)
                ctx.fillStyle = hood; ctx.fillRect(ox+15,7+bobY,3,6); ctx.fillRect(ox+30,7+bobY,3,6);
            } else if (dir===4) {
                ctx.fillStyle = hood; ctx.fillRect(ox+15,7+bobY,18,8);
                ctx.fillStyle = hoodLt; ctx.fillRect(ox+17,8+bobY,14,5);
                ctx.fillStyle = gold; ctx.fillRect(ox+16,7+bobY,16,1);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+16;
                ctx.fillStyle = hood; ctx.fillRect(bx+1,7+bobY,14,6);
                ctx.fillStyle = hoodLt; ctx.fillRect(bx+3,8+bobY,10,4);
                ctx.fillStyle = gold; ctx.fillRect(bx+2,12+bobY,12,1);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+16:ox+19;
                ctx.fillStyle = hood; ctx.fillRect(bx,7+bobY,10,6);
                ctx.fillStyle = hoodLt; ctx.fillRect(bx+2,8+bobY,6,4);
                ctx.fillStyle = gold; ctx.fillRect(bx+1,12+bobY,8,1);
            } else {
                const flip=dir===5, bx=flip?ox+14:ox+16;
                ctx.fillStyle = hood; ctx.fillRect(bx+1,7+bobY,14,7);
                ctx.fillStyle = hoodLt; ctx.fillRect(bx+3,8+bobY,10,5);
                ctx.fillStyle = gold; ctx.fillRect(bx+2,7+bobY,12,1);
            }
        },
        drawTorsoOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const cloak = '#1a1a22', cloakLt = '#2a2a32', cloakDk = '#0a0a12';
            const gold = '#aa8833', goldDk = '#886622', purple = '#6a3a8a';
            if (dir===0||dir===4) {
                // Cloak over shoulders — draping panels
                ctx.fillStyle = cloak;
                ctx.fillRect(ox+12,20+bobY,6,11); ctx.fillRect(ox+30,20+bobY,6,11);
                ctx.fillStyle = cloakDk;
                ctx.fillRect(ox+13,20+bobY,1,11); ctx.fillRect(ox+34,20+bobY,1,11);
                // Gold collar
                ctx.fillStyle = gold;
                ctx.fillRect(ox+16,20+bobY,16,2);
                ctx.fillStyle = goldDk;
                ctx.fillRect(ox+16,21+bobY,16,1);
                if(dir===0) {
                    // Purple clasp gem
                    ctx.fillStyle = purple; ctx.fillRect(ox+23,20+bobY,2,2);
                }
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+13:ox+14;
                ctx.fillStyle = cloak;
                if(flip) ctx.fillRect(bx+15,20+bobY,4,11); else ctx.fillRect(bx,20+bobY,4,11);
                ctx.fillStyle = gold; ctx.fillRect(bx+3,20+bobY,13,2);
                ctx.fillStyle = goldDk; ctx.fillRect(bx+3,21+bobY,13,1);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+16:ox+18;
                ctx.fillStyle = cloak; ctx.fillRect(bx,20+bobY,3,11);
                ctx.fillStyle = gold; ctx.fillRect(bx+2,20+bobY,8,2);
            } else {
                const flip=dir===5, bx=flip?ox+13:ox+14;
                ctx.fillStyle = cloak;
                if(flip) ctx.fillRect(bx+15,20+bobY,4,11); else ctx.fillRect(bx,20+bobY,4,11);
                // Cloak back panel
                ctx.fillStyle = cloakLt; ctx.fillRect(bx+4,22+bobY,11,8);
                ctx.fillStyle = gold; ctx.fillRect(bx+3,20+bobY,13,2);
            }
        }
    },
    
    foundry_cephalon: {
        // Cephalon: Alien tech bodysuit — teal circuit lines, iridescent helm, glow patches
        drawHeadOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const helm = '#2a3a3a', helmLt = '#3a4a4a', teal = '#33aaaa', glow = '#44ddcc';
            if (dir===0) {
                // Smooth alien helm — wraps around head
                ctx.fillStyle = helm; ctx.fillRect(ox+16,7+bobY,16,7);
                ctx.fillStyle = helmLt; ctx.fillRect(ox+17,8+bobY,14,5);
                // Teal visor band
                ctx.fillStyle = teal; ctx.fillRect(ox+18,11+bobY,12,2);
                ctx.fillStyle = glow; ctx.fillRect(ox+19,11+bobY,3,1); // glow spot
                // Antenna nubs
                ctx.fillStyle = helmLt; ctx.fillRect(ox+17,7+bobY,2,2); ctx.fillRect(ox+29,7+bobY,2,2);
            } else if (dir===4) {
                ctx.fillStyle = helm; ctx.fillRect(ox+16,7+bobY,16,7);
                ctx.fillStyle = helmLt; ctx.fillRect(ox+17,8+bobY,14,5);
                ctx.fillStyle = teal; ctx.fillRect(ox+20,10+bobY,8,1);
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+15:ox+16;
                ctx.fillStyle = helm; ctx.fillRect(bx+1,7+bobY,13,7);
                ctx.fillStyle = helmLt; ctx.fillRect(bx+2,8+bobY,11,5);
                ctx.fillStyle = teal; ctx.fillRect(bx+3,11+bobY,8,2);
                ctx.fillStyle = glow; ctx.fillRect(bx+4,11+bobY,2,1);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+17:ox+19;
                ctx.fillStyle = helm; ctx.fillRect(bx,7+bobY,9,7);
                ctx.fillStyle = helmLt; ctx.fillRect(bx+1,8+bobY,7,5);
                ctx.fillStyle = teal; ctx.fillRect(bx+2,11+bobY,5,2);
            } else {
                const flip=dir===5, bx=flip?ox+15:ox+16;
                ctx.fillStyle = helm; ctx.fillRect(bx+1,7+bobY,13,7);
                ctx.fillStyle = helmLt; ctx.fillRect(bx+2,8+bobY,11,5);
                ctx.fillStyle = teal; ctx.fillRect(bx+4,10+bobY,6,1);
            }
        },
        drawTorsoOverlay(ctx, p, c) {
            const { ox, dir, bobY } = p;
            const suit = '#1a2a2a', suitLt = '#2a3a3a';
            const teal = '#33aaaa', glow = '#44ddcc';
            if (dir===0||dir===4) {
                // Bodysuit with teal circuit lines
                ctx.fillStyle = suit; ctx.fillRect(ox+15,20+bobY,18,11);
                ctx.fillStyle = suitLt; ctx.fillRect(ox+16,21+bobY,16,9);
                // Circuit traces
                ctx.fillStyle = teal;
                ctx.fillRect(ox+18,22+bobY,1,7); ctx.fillRect(ox+29,22+bobY,1,7);
                ctx.fillRect(ox+18,25+bobY,12,1);
                if(dir===0) {
                    // Central power node
                    ctx.fillStyle = glow; ctx.fillRect(ox+23,23+bobY,2,2);
                    ctx.fillStyle = teal;
                    ctx.fillRect(ox+21,24+bobY,2,1); ctx.fillRect(ox+25,24+bobY,2,1);
                    // Shoulder circuit pads
                    ctx.fillStyle = teal;
                    ctx.fillRect(ox+13,21+bobY,3,1); ctx.fillRect(ox+32,21+bobY,3,1);
                } else {
                    // Back spine trace
                    ctx.fillStyle = glow; ctx.fillRect(ox+23,22+bobY,2,7);
                }
            } else if (dir===1||dir===7) {
                const flip=dir===7, bx=flip?ox+14:ox+15;
                ctx.fillStyle = suit; ctx.fillRect(bx+2,20+bobY,15,11);
                ctx.fillStyle = suitLt; ctx.fillRect(bx+3,21+bobY,13,9);
                ctx.fillStyle = teal;
                ctx.fillRect(bx+5,22+bobY,1,7); ctx.fillRect(bx+5,26+bobY,8,1);
                ctx.fillStyle = glow; ctx.fillRect(bx+8,24+bobY,2,2);
            } else if (dir===2||dir===6) {
                const bx=dir===6?ox+17:ox+19;
                ctx.fillStyle = suit; ctx.fillRect(bx,20+bobY,10,11);
                ctx.fillStyle = suitLt; ctx.fillRect(bx+1,21+bobY,8,9);
                ctx.fillStyle = teal; ctx.fillRect(bx+4,22+bobY,1,7);
                ctx.fillStyle = glow; ctx.fillRect(bx+4,25+bobY,2,2);
            } else {
                const flip=dir===5, bx=flip?ox+14:ox+15;
                ctx.fillStyle = suit; ctx.fillRect(bx+2,20+bobY,15,11);
                ctx.fillStyle = suitLt; ctx.fillRect(bx+3,21+bobY,13,9);
                ctx.fillStyle = glow; ctx.fillRect(bx+8,22+bobY,2,7);
            }
        }
    },
    sprites: {
        player_top: { url: null, fallback: { type: 'custom', builder: 'buildPlayer' } },
        enemy_walker: { url: null, fallback: { type: 'custom', builder: 'buildWalker' } },
        enemy_crawler: { url: null, fallback: { type: 'custom', builder: 'buildCrawler' } },
        enemy_sprinter: { url: null, fallback: { type: 'custom', builder: 'buildSprinter' } },
        enemy_boss: { url: null, fallback: { type: 'custom', builder: 'buildBoss' } },
        enemy_host: { url: null, fallback: { type: 'custom', builder: 'buildHost' } },
        enemy_deadlock: { url: null, fallback: { type: 'custom', builder: 'buildDeadlock' } },
        enemy_stalker: { url: null, fallback: { type: 'custom', builder: 'buildStalker' } },
        enemy_spawn: { url: null, fallback: { type: 'custom', builder: 'buildSpawn' } },
    },
    
    // Initialize player spritesheet
    playerCustomization: null,
    
    initPlayerSheet(callback, custom = null) {
        if (custom) {
            this.playerCustomization = custom;
            // Store base outfit IDs for gear revert — handles both string IDs and {id, base, ...} objects
            if (custom.shirt) this._baseShirtId = typeof custom.shirt === 'string' ? custom.shirt : (custom.shirt.id || 'green');
            if (custom.pants) this._basePantsId = typeof custom.pants === 'string' ? custom.pants : (custom.pants.id || 'dark');
        }
        if (this.playerSheetReady && !custom) {
            if (callback) callback();
            return;
        }
        
        this.playerSheetCanvas = this.generatePlayerSheet(this.playerCustomization, false);
        // Generate armed sheets for each sprite weapon type
        // Multiple weapon baseIds map to same sprite type
        this.armedSheets = {};
        const weaponSpriteTypes = ['pistol', 'mini', 'rifle', 'heavy_rifle', 'handcannon', 'sniper'];
        weaponSpriteTypes.forEach(wt => {
            this.armedSheets[wt] = this.generatePlayerSheet(this.playerCustomization, true, wt);
        });
        
        // Generate melee swing sheets for each melee type
        this.meleeSheets = {};
        const meleeTypes = ['blade', 'blunt', 'heavy'];
        meleeTypes.forEach(mt => {
            this.meleeSheets[mt] = this.generateMeleeSheet(this.playerCustomization, mt);
        });
        
        this.playerSheetReady = true;
        this._dirty = true; // Flag textures for refresh in next scene
        if (callback) callback();
    },
    
    // Map any weapon baseId to its sprite type (for armed sheet lookup)
    getWeaponSpriteType(baseId) {
        const base = CONFIG.baseItems[baseId];
        if (base && base.sprite) return base.sprite;
        return 'pistol';
    },
    
    // Get foundry-tinted weapon style for armed sprite rendering
    // Falls back to default grey if no foundry
    getFoundryWeaponStyle(weaponType, foundryId) {
        // Base weapon shapes per type
        const baseShapes = {
            pistol: { barrel: 5, stock: false },
            mini:   { barrel: 4, stock: false },
            rifle:  { barrel: 9, stock: true },
            heavy_rifle: { barrel: 10, stock: true, wide: true },
            handcannon:  { barrel: 6, stock: false, thick: true },
            sniper: { barrel: 13, stock: true, scope: true }
        };
        const shape = baseShapes[weaponType] || baseShapes.pistol;
        
        if (foundryId && CONFIG.foundries[foundryId]) {
            const p = CONFIG.foundries[foundryId].palette;
            return {
                body: p.body,
                dark: p.bodyDark,
                light: p.bodyLight,
                barrel: shape.barrel,
                stock: shape.stock || false,
                stockColor: p.metal,
                wide: shape.wide || false,
                thick: shape.thick || false,
                scope: shape.scope || false,
                accent: p.accent,
                detail: p.detail,
                foundry: foundryId
            };
        }
        
        // Default grey (scrap / no foundry)
        const defaults = {
            pistol: { body: '#444444', dark: '#333333', light: '#555555' },
            mini:   { body: '#4a4a4a', dark: '#3a3a3a', light: '#5a5a5a' },
            rifle:  { body: '#3a3535', dark: '#2a2525', light: '#5a4a4a', stockColor: '#2a2015' },
            heavy_rifle: { body: '#3a3a3a', dark: '#2a2a2a', light: '#4a4a4a', stockColor: '#2a2520' },
            handcannon:  { body: '#4a4040', dark: '#3a3030', light: '#5a5050' },
            sniper: { body: '#353535', dark: '#252525', light: '#4a4a4a', stockColor: '#201a15' }
        };
        const d = defaults[weaponType] || defaults.pistol;
        return { ...d, ...shape };
    },
    
    // Regenerate all canvases from new customization.
    // Does NOT touch Phaser textures — just prepares fresh canvas data.
    // Textures are registered/refreshed in addPlayerSheetToScene.
    rebuildPlayerSheet(scene, custom) {
        try {
            this.playerCustomization = custom;
            this.playerSheetCanvas = this.generatePlayerSheet(custom, false);
            this.armedSheets = {};
            const wts = ['pistol', 'mini', 'rifle', 'heavy_rifle', 'handcannon', 'sniper'];
            wts.forEach(wt => {
                this.armedSheets[wt] = this.generatePlayerSheet(custom, true, wt);
            });
            
            // Rebuild melee swing sheets — pass current equipment melee item to preserve weapon art
            this.meleeSheets = {};
            const mts = ['blade', 'blunt', 'heavy'];
            // Find current melee item for weapon art preservation
            let currentMeleeItem = null;
            try {
                const gs = window.game && window.game.scene.scenes.find(s => { try { return s.scene.isActive() && s.state && s.state.equipment; } catch(e) { return false; } });
                if (gs && gs.state.equipment && gs.state.equipment.melee) currentMeleeItem = gs.state.equipment.melee;
            } catch(e) {}
            mts.forEach(mt => {
                this.meleeSheets[mt] = this.generateMeleeSheet(custom, mt, currentMeleeItem && (currentMeleeItem.baseId === mt || (mt === 'blade' && currentMeleeItem.baseId !== 'blunt' && currentMeleeItem.baseId !== 'heavy')) ? currentMeleeItem : null);
            });
            
            this.playerSheetReady = true;
            this._dirty = true; // Flag: canvases changed, textures need refresh
            
            // For the current scene: update existing textures in-place so sprite refreshes immediately
            try {
                // Update unarmed sheet
                if (scene.textures.exists('player_sheet')) {
                    const tex = scene.textures.get('player_sheet');
                    const src = tex.source[0];
                    if (src.image && src.image.getContext) {
                        const ctx = src.image.getContext('2d');
                        ctx.clearRect(0, 0, src.image.width, src.image.height);
                        ctx.drawImage(this.playerSheetCanvas, 0, 0);
                        src.update();
                    }
                }
                // Update all armed sheets too
                const wts = ['pistol', 'mini', 'rifle', 'heavy_rifle', 'handcannon', 'sniper'];
                wts.forEach(wt => {
                    const key = 'player_sheet_armed_' + wt;
                    if (scene.textures.exists(key) && this.armedSheets[wt]) {
                        const tex = scene.textures.get(key);
                        const src = tex.source[0];
                        if (src.image && src.image.getContext) {
                            const ctx = src.image.getContext('2d');
                            ctx.clearRect(0, 0, src.image.width, src.image.height);
                            ctx.drawImage(this.armedSheets[wt], 0, 0);
                            src.update();
                        }
                    }
                });
                // Update all melee sheets too — prevents flicker when gear outfit changes
                const mts2 = ['blade', 'blunt', 'heavy'];
                mts2.forEach(mt => {
                    const key = 'player_sheet_melee_' + mt;
                    if (scene.textures.exists(key) && this.meleeSheets[mt]) {
                        const tex = scene.textures.get(key);
                        const src = tex.source[0];
                        if (src.image && src.image.getContext) {
                            const ctx = src.image.getContext('2d');
                            ctx.clearRect(0, 0, src.image.width, src.image.height);
                            ctx.drawImage(this.meleeSheets[mt], 0, 0);
                            src.update();
                        }
                    }
                });
            } catch(e) {}
        } catch(e) {
            console.warn('rebuildPlayerSheet error:', e);
        }
    },
    
    // Register player textures + animations in a scene.
    // If canvases were regenerated (_dirty), wipe stale textures first.
    addPlayerSheetToScene(scene) {
        if (!this.playerSheetReady || !this.playerSheetCanvas) {
            this.initPlayerSheet();
        }
        
        // If canvases changed since last registration, wipe old textures + anims
        if (this._dirty) {
            const allKeys = ['player_sheet'];
            const wts = ['pistol', 'mini', 'rifle', 'heavy_rifle', 'handcannon', 'sniper'];
            wts.forEach(wt => allKeys.push('player_sheet_armed_' + wt));
            const mts = ['blade', 'blunt', 'heavy'];
            mts.forEach(mt => allKeys.push('player_sheet_melee_' + mt));
            allKeys.forEach(key => {
                if (scene.textures.exists(key)) scene.textures.remove(key);
            });
            // Remove player anims so they get re-created pointing at new textures
            const dirs = ['down','down_right','right','up_right','up','up_left','left','down_left'];
            dirs.forEach(d => {
                const wk = 'player_walk_' + d;
                if (scene.anims.exists(wk)) scene.anims.remove(wk);
            });
            if (scene.anims.exists('player_idle')) scene.anims.remove('player_idle');
            wts.forEach(wt => {
                dirs.forEach(d => {
                    const ak = `player_armed_${wt}_${d}`;
                    if (scene.anims.exists(ak)) scene.anims.remove(ak);
                });
                const ik = `player_armed_${wt}_idle`;
                if (scene.anims.exists(ik)) scene.anims.remove(ik);
            });
            this._dirty = false;
        }
        
        // Register textures if not present
        if (!scene.textures.exists('player_sheet')) {
            scene.textures.addSpriteSheet('player_sheet', this.playerSheetCanvas, {
                frameWidth: 48, frameHeight: 48
            });
        }
        
        const weaponTypes = ['pistol', 'mini', 'rifle', 'heavy_rifle', 'handcannon', 'sniper'];
        weaponTypes.forEach(wt => {
            const sheetKey = 'player_sheet_armed_' + wt;
            if (!scene.textures.exists(sheetKey) && this.armedSheets && this.armedSheets[wt]) {
                scene.textures.addSpriteSheet(sheetKey, this.armedSheets[wt], {
                    frameWidth: 48, frameHeight: 48
                });
            }
        });
        
        // Create animations if missing
        const directions = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
        directions.forEach((dir, i) => {
            const key = 'player_walk_' + dir;
            if (!scene.anims.exists(key)) {
                scene.anims.create({ key, frames: scene.anims.generateFrameNumbers('player_sheet', { start: i*3, end: i*3+2 }), frameRate: 8, repeat: -1 });
            }
        });
        if (!scene.anims.exists('player_idle')) {
            scene.anims.create({ key: 'player_idle', frames: [{ key: 'player_sheet', frame: 0 }], frameRate: 1 });
        }
        weaponTypes.forEach(wt => {
            const sheetKey = 'player_sheet_armed_' + wt;
            if (!scene.textures.exists(sheetKey)) return;
            directions.forEach((dir, i) => {
                const animKey = `player_armed_${wt}_${dir}`;
                if (!scene.anims.exists(animKey)) {
                    scene.anims.create({ key: animKey, frames: scene.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 8, repeat: -1 });
                }
            });
            if (!scene.anims.exists(`player_armed_${wt}_idle`)) {
                scene.anims.create({ key: `player_armed_${wt}_idle`, frames: [{ key: sheetKey, frame: 0 }], frameRate: 1 });
            }
        });
        
        // Register melee swing sheets
        const meleeTypes = ['blade', 'blunt', 'heavy'];
        meleeTypes.forEach(mt => {
            const sheetKey = 'player_sheet_melee_' + mt;
            if (!scene.textures.exists(sheetKey) && this.meleeSheets && this.meleeSheets[mt]) {
                scene.textures.addSpriteSheet(sheetKey, this.meleeSheets[mt], {
                    frameWidth: 48, frameHeight: 48
                });
            }
            if (!scene.textures.exists(sheetKey)) return;
            directions.forEach((dir, i) => {
                const animKey = `player_melee_${mt}_${dir}`;
                if (!scene.anims.exists(animKey)) {
                    scene.anims.create({ key: animKey, frames: scene.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 12, repeat: 0 });
                }
            });
        });
        
        return true;
    },
    
    // Create an animated player sprite with physics
    createPlayerSprite(scene, x, y, inventory = null, auraId = null) {
        this.addPlayerSheetToScene(scene);
        const player = scene.physics.add.sprite(x, y, 'player_sheet', 0);
        player.setDisplaySize(40, 40);
        player.setFrame(0); // Start facing down
        player.isMoving = false;
        player.lastDir = 'down';
        
        // Backpack always created if inventory present
        if (inventory) {
            player.backpack = this.createBackpackSprite(scene, player, inventory);
            player.backpackInventory = inventory;
        }
        // Crown aura for mastery-tier survivors (stacks with backpack)
        const auraDef = auraId && auraId !== 'none' ? CONFIG.survivorAuras[auraId] : null;
        if (auraDef && auraDef.tier === 'mastery') {
            const crown = CrownAura.createCrown(scene, player);
            if (crown) {
                player._crownSprite = crown;
                player._hasCrown = true;
            }
        }
        
        return player;
    },
    
    // Create a non-physics animated player sprite
    createPlayerSpriteNoPhysics(scene, x, y, inventory = null, auraId = null) {
        this.addPlayerSheetToScene(scene);
        const player = scene.add.sprite(x, y, 'player_sheet', 0);
        player.setDisplaySize(40, 40);
        player.setFrame(0); // Start facing down
        player.isMoving = false;
        player.lastDir = 'down';
        
        // Backpack always created if inventory present
        if (inventory) {
            player.backpack = this.createBackpackSprite(scene, player, inventory);
            player.backpackInventory = inventory;
        }
        // Crown aura for mastery-tier survivors (stacks with backpack)
        const auraDef = auraId && auraId !== 'none' ? CONFIG.survivorAuras[auraId] : null;
        if (auraDef && auraDef.tier === 'mastery') {
            const crown = CrownAura.createCrown(scene, player);
            if (crown) {
                player._crownSprite = crown;
                player._hasCrown = true;
            }
        }
        
        return player;
    },
    
    // Update player animation based on movement
    updatePlayerAnimation(player, vx, vy, scene) {
        if (!player || !player.anims) return;
        
        const len = Math.sqrt(vx * vx + vy * vy);
        const isMoving = len > 0.1;
        
        // Determine facing direction — from lock-on target if locked, otherwise from movement
        let dir = player.lastDir || 'down';
        if (scene && scene.lockedTarget && scene.lockedTarget.active) {
            // Face locked target regardless of movement
            const angle = Math.atan2(scene.lockedTarget.y - player.y, scene.lockedTarget.x - player.x) * (180 / Math.PI);
            if (angle >= -22.5 && angle < 22.5) dir = 'right';
            else if (angle >= 22.5 && angle < 67.5) dir = 'down_right';
            else if (angle >= 67.5 && angle < 112.5) dir = 'down';
            else if (angle >= 112.5 && angle < 157.5) dir = 'down_left';
            else if (angle >= 157.5 || angle < -157.5) dir = 'left';
            else if (angle >= -157.5 && angle < -112.5) dir = 'up_left';
            else if (angle >= -112.5 && angle < -67.5) dir = 'up';
            else if (angle >= -67.5 && angle < -22.5) dir = 'up_right';
        } else if (isMoving) {
            const angle = Math.atan2(vy, vx) * (180 / Math.PI);
            if (angle >= -22.5 && angle < 22.5) dir = 'right';
            else if (angle >= 22.5 && angle < 67.5) dir = 'down_right';
            else if (angle >= 67.5 && angle < 112.5) dir = 'down';
            else if (angle >= 112.5 && angle < 157.5) dir = 'down_left';
            else if (angle >= 157.5 || angle < -157.5) dir = 'left';
            else if (angle >= -157.5 && angle < -112.5) dir = 'up_left';
            else if (angle >= -112.5 && angle < -67.5) dir = 'up';
            else if (angle >= -67.5 && angle < -22.5) dir = 'up_right';
        }
        
        const directionChanged = (dir !== player.lastDir);
        
        // Update backpack position based on 8 directions
        if (player._hasCrown && player._crownSprite) {
            CrownAura.updateCrown(player);
        }
        if (player.backpack) {
            let offsetY = CONFIG.inventory.backpackOffset.y;
            let offsetX = CONFIG.inventory.backpackOffset.x;
            let newDepth = player.depth - 0.1;
            let flipX = false;
            
            if (dir === 'down') {
                offsetY += -2; newDepth = player.depth - 0.1;
            } else if (dir === 'up') {
                offsetY += 2; newDepth = player.depth + 0.1;
            } else if (dir === 'right') {
                offsetY += 0; offsetX = -3; newDepth = player.depth - 0.1;
            } else if (dir === 'left') {
                offsetY += 0; offsetX = 3; newDepth = player.depth - 0.1; flipX = true;
            } else if (dir === 'down_right') {
                offsetY += 0; offsetX = -2; newDepth = player.depth - 0.1;
            } else if (dir === 'down_left') {
                offsetY += 0; offsetX = 2; newDepth = player.depth - 0.1; flipX = true;
            } else if (dir === 'up_right') {
                offsetY += 3; offsetX = -2; newDepth = player.depth + 0.1;
            } else if (dir === 'up_left') {
                offsetY += 3; offsetX = 2; newDepth = player.depth + 0.1; flipX = true;
            }
            
            // Larger display — weapons need to be visible
            const sideViews = ['left', 'right', 'up_left', 'up_right', 'down_left', 'down_right'];
            const isSide = sideViews.includes(dir);
            const bpSize = isSide ? 32 : (dir === 'up' ? 34 : 36);
            player.backpack.setDisplaySize(bpSize, bpSize);
            
            player.backpack.setDepth(newDepth);
            player.backpack.setFlipX(flipX);
            
            if (directionChanged && player.backpackInventory) {
                this.updateBackpackSprite(scene, player.backpack, player.backpackInventory, dir);
            }
            
            player.backpack.x = player.x + offsetX;
            player.backpack.y = player.y + offsetY;
            
            // Update holster weapon sprites (position, visibility, flipX)
            this.updateHolsterSprites(player, dir);
        }
        
        if (!isMoving) {
            const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
            const targetFrame = frameMap[dir] || 0;
            if (player.isMoving || player._displayedDir !== dir) {
                player.anims.stop();
                let tex = player._isArmedTexture ? ('player_sheet_armed_' + (player.weaponType || 'pistol')) : 'player_sheet';
                if (scene && scene.textures.exists(tex)) {
                    // Verify texture has valid frames
                    const texObj = scene.textures.get(tex);
                    const frame = texObj.get(targetFrame);
                    if (frame && frame.data) {
                        player.setTexture(tex, targetFrame);
                    } else {
                        // Stale armed texture — fall back to base
                        player._isArmedTexture = false;
                        tex = 'player_sheet';
                        player.setTexture(tex, targetFrame);
                    }
                    player.setDisplaySize(40, 40);
                } else {
                    // Texture doesn't exist — reset to base
                    player._isArmedTexture = false;
                    if (scene && scene.textures.exists('player_sheet')) {
                        player.setTexture('player_sheet', targetFrame);
                        player.setDisplaySize(40, 40);
                    } else {
                        player.setFrame(targetFrame);
                    }
                }
                player.isMoving = false;
                player.lastDir = dir;
                player._displayedDir = dir;
            }
            return;
        }
        
        const prefix = player._isArmedTexture ? `player_armed_${player.weaponType || 'pistol'}_` : 'player_walk_';
        const animKey = prefix + dir;
        const currentAnim = player.anims.currentAnim ? player.anims.currentAnim.key : null;
        
        // Don't interrupt melee swing animation
        if (player._isMeleeSwinging) {
            player.lastDir = dir;
            return;
        }
        
        if (currentAnim !== animKey || !player.anims.isPlaying) {
            if (scene && scene.anims.exists(animKey)) {
                // Verify the animation's texture frames are valid before playing
                const anim = scene.anims.get(animKey);
                if (anim && anim.frames && anim.frames.length > 0 && anim.frames[0].frame && anim.frames[0].frame.data) {
                    player.play(animKey);
                } else {
                    // Animation frames are stale/null — reset to unarmed texture and animation
                    player._isArmedTexture = false;
                    if (scene.textures.exists('player_sheet')) {
                        player.setTexture('player_sheet', 0);
                        player.setDisplaySize(40, 40);
                    }
                    const fallbackKey = 'player_walk_' + dir;
                    if (scene.anims.exists(fallbackKey)) player.play(fallbackKey);
                }
            } else {
                // Animation doesn't exist — ensure unarmed texture
                if (player._isArmedTexture) {
                    player._isArmedTexture = false;
                    if (scene.textures.exists('player_sheet')) {
                        player.setTexture('player_sheet', 0);
                        player.setDisplaySize(40, 40);
                    }
                }
                const fallbackKey = 'player_walk_' + dir;
                if (scene.anims.exists(fallbackKey)) {
                    player.play(fallbackKey);
                }
            }
        }
        
        player.isMoving = true;
        player.lastDir = dir;
        player._displayedDir = null; // Reset so idle re-triggers on stop
    },
    
    // Generate fallback texture in a scene
    createFallback(scene, key) {
        if (scene.textures.exists(key)) return;
        
        const def = this.sprites[key];
        if (!def) return;
        
        const fb = def.fallback;
        const g = scene.make.graphics({ add: false });
        
        if (fb.type === 'rect') {
            g.fillStyle(fb.color, 1);
            g.fillRect(0, 0, fb.width, fb.height);
            g.generateTexture(key, fb.width, fb.height);
        } else if (fb.type === 'circle') {
            g.fillStyle(fb.color, 1);
            g.fillCircle(fb.radius, fb.radius, fb.radius);
            g.generateTexture(key, fb.radius * 2, fb.radius * 2);
        } else if (fb.type === 'custom' && this[fb.builder]) {
            this[fb.builder](scene, g, key);
        }
        
        g.destroy();
    },
    
    // === PLAYER SPRITES ===
    buildPlayer(scene, g, key) {
        const s = 32; // sprite size
        const cx = s/2, cy = s/2;
        
        // Shadow
        g.fillStyle(0x000000, 0.3);
        g.fillEllipse(cx, cy + 12, 14, 6);
        
        // Body (torso) - dark jacket
        g.fillStyle(0x2a4a5a, 1);
        g.fillRoundedRect(cx - 7, cy - 4, 14, 14, 3);
        
        // Body highlight
        g.fillStyle(0x3a5a6a, 1);
        g.fillRoundedRect(cx - 5, cy - 2, 4, 10, 2);
        
        // Head
        g.fillStyle(0xdaa878, 1); // skin tone
        g.fillCircle(cx, cy - 8, 6);
        
        // Hair
        g.fillStyle(0x3a2a1a, 1);
        g.fillRoundedRect(cx - 5, cy - 14, 10, 5, 2);
        
        // Arms
        g.fillStyle(0x2a4a5a, 1);
        g.fillRoundedRect(cx - 11, cy - 2, 5, 10, 2);
        g.fillRoundedRect(cx + 6, cy - 2, 5, 10, 2);
        
        // Hands
        g.fillStyle(0xdaa878, 1);
        g.fillCircle(cx - 8, cy + 8, 3);
        g.fillCircle(cx + 8, cy + 8, 3);
        
        // Legs
        g.fillStyle(0x2a3a4a, 1);
        g.fillRoundedRect(cx - 5, cy + 8, 4, 8, 2);
        g.fillRoundedRect(cx + 1, cy + 8, 4, 8, 2);
        
        // Boots
        g.fillStyle(0x1a1a1a, 1);
        g.fillRoundedRect(cx - 6, cy + 13, 5, 4, 1);
        g.fillRoundedRect(cx + 1, cy + 13, 5, 4, 1);
        
        g.generateTexture(key, s, s);
    },
    
    // === BACKPACK SPRITE (Separate, Detailed) ===
    // Creates a detailed backpack sprite that can be attached to player
    // fullness: 0.0 to 1.0 (affects visual weight/bulge)
    // direction: 'front', 'side' for different perspectives
    buildBackpack(scene, fullness = 0, direction = 'front', equipment = null) {
        const s = CONFIG.inventory.backpackSize;
        const canvas = document.createElement('canvas');
        canvas.width = s;
        canvas.height = s;
        const ctx = canvas.getContext('2d');
        
        const bpId = (SpriteManager.playerCustomization && SpriteManager.playerCustomization.backpack) || 'green';
        const bpDef = CONFIG.customization.backpackColors.find(c => c.id === bpId) || CONFIG.customization.backpackColors[0];
        
        // Determine if holster sides should swap based on direction
        // Physical model: weapon on pack's LEFT, melee on pack's RIGHT
        // Default drawing: weapon=screen-left, melee=screen-right
        // 
        // Back (up):       We see natural back. weapon=left, melee=right. No swap.
        // Front (down):    Mirrored view. weapon should appear screen-right, melee screen-left. Swap.
        // Right:           We see pack's right (melee) side. Side view natural. No swap.
        // Left (flipX):    We see pack's left (weapon) side. flipX mirrors, so draw natural → flip makes weapon visible. No swap.
        // Up-right:        Back + right. Natural. No swap.
        // Up-left (flipX): Back + left. flipX handles mirror. No swap.
        // Down-right:      Front + right. Swap (front is mirrored).
        // Down-left(flipX):Front + left. flipX + swap cancel out → No swap.
        //
        // Summary: swap for 'down' and 'down_right' only
        // (left-variants use flipX which already mirrors, so no swap needed)
        const swapSides = (direction === 'down' || direction === 'front' || direction === 'down_right' || direction === 'up_left');
        
        const sideViews = ['left', 'right', 'up_left', 'up_right', 'down_left', 'down_right'];
        const isSide = sideViews.includes(direction);
        
        if (isSide) {
            this.buildBackpackSideView(ctx, s, fullness, bpDef, equipment, swapSides);
        } else {
            this.buildBackpackFrontView(ctx, s, fullness, bpDef, equipment, swapSides);
        }
        
        return canvas;
    },
    
    buildBackpackFrontView(ctx, s, fullness, colors, equipment, swapSides = false) {
        const cx = Math.floor(s / 2);
        const cy = Math.floor(s / 2);
        const base = colors.base, dark = colors.dark, light = colors.light, accent = colors.accent;
        const o = '#0a0a0a';
        const bulge = Math.floor(fullness * 3);
        
        // Pack dimensions — larger in 48px canvas
        const pw = 16 + bulge; // width
        const ph = 18;
        const px = cx - Math.floor(pw/2);
        const py = cy - 5;
        
        // Outline
        ctx.fillStyle = o;
        ctx.fillRect(px-1, py-1, pw+2, ph+2);
        ctx.clearRect(px-1, py-1, 1, 1); ctx.clearRect(px+pw, py-1, 1, 1);
        ctx.clearRect(px-1, py+ph, 1, 1); ctx.clearRect(px+pw, py+ph, 1, 1);
        
        // Main body
        ctx.fillStyle = base;
        ctx.fillRect(px, py, pw, ph);
        
        // Top flap
        ctx.fillStyle = accent;
        ctx.fillRect(px, py, pw, 3);
        ctx.fillStyle = light;
        ctx.fillRect(px+1, py, pw-2, 2);
        
        // Left shadow
        ctx.fillStyle = dark;
        ctx.fillRect(px, py+3, 2, ph-3);
        
        // Right highlight  
        ctx.fillStyle = light;
        ctx.fillRect(px+pw-2, py+3, 2, ph-5);
        
        // Front pocket
        ctx.fillStyle = dark;
        ctx.fillRect(px+2, cy+2, pw-4, 6);
        ctx.fillStyle = base;
        ctx.fillRect(px+3, cy+2, pw-6, 5);
        ctx.fillStyle = accent;
        ctx.fillRect(px+2, cy+2, pw-4, 1);
        
        // Buckle
        ctx.fillStyle = '#7a7a7a';
        ctx.fillRect(cx-1, cy+2, 3, 2);
        ctx.fillStyle = '#999';
        ctx.fillRect(cx-1, cy+2, 3, 1);
        
        // Straps
        ctx.fillStyle = dark;
        ctx.fillRect(px+2, py-3, 3, 4);
        ctx.fillRect(px+pw-5, py-3, 3, 4);
        ctx.fillRect(px+2, py+ph-1, 3, 2);
        ctx.fillRect(px+pw-5, py+ph-1, 3, 2);
        
        // Compression straps when full
        if (fullness > 0.5) {
            ctx.fillStyle = dark;
            ctx.fillRect(px, cy-1, pw, 1);
            ctx.fillRect(px, cy+8, pw, 1);
        }
        
        // Holster weapons are separate sprites — not drawn on backpack canvas
    },
    
    
    buildBackpackSideView(ctx, s, fullness, colors, equipment, swapSides = false) {
        const cx = Math.floor(s / 2);
        const cy = Math.floor(s / 2);
        const base = colors.base, dark = colors.dark, light = colors.light, accent = colors.accent;
        const o = '#0a0a0a';
        
        // Side view — BEEFED UP: more depth, visible volume
        // ¾ perspective: we see mostly the side face (depth) with a sliver of front
        const depth = 10 + Math.floor(fullness * 3); // wider base depth
        const ph = 18;
        const frontSliver = 4; // the front face receding away
        const totalW = depth + frontSliver;
        const px = cx - Math.floor(totalW/2);
        const py = cy - 5;
        
        // === MAIN PACK BODY ===
        // Outline
        ctx.fillStyle = o;
        ctx.fillRect(px-1, py-1, totalW+2, ph+2);
        // Round corners
        ctx.clearRect(px-1, py-1, 1, 1); ctx.clearRect(px+totalW, py-1, 1, 1);
        ctx.clearRect(px-1, py+ph, 1, 1); ctx.clearRect(px+totalW, py+ph, 1, 1);
        
        // Side face (dominant — the depth of the pack)
        ctx.fillStyle = dark;
        ctx.fillRect(px, py, depth, ph);
        ctx.fillStyle = base;
        ctx.fillRect(px+1, py+1, depth-2, ph-2);
        // Depth shading — darker toward the back (left), lighter toward front (right)
        ctx.fillStyle = dark;
        ctx.fillRect(px, py, 2, ph);
        ctx.fillStyle = light;
        ctx.fillRect(px+depth-2, py+1, 1, ph-2);
        
        // Front face sliver (receding right — the "front" of the pack seen at angle)
        ctx.fillStyle = light;
        ctx.fillRect(px+depth, py, frontSliver, ph);
        ctx.fillStyle = base;
        ctx.fillRect(px+depth, py+1, frontSliver-1, ph-2);
        
        // Top flap with perspective
        ctx.fillStyle = accent;
        ctx.fillRect(px, py, totalW, 2);
        ctx.fillStyle = light;
        ctx.fillRect(px+1, py, totalW-2, 1);
        
        // === PACK DETAILS ===
        // Side pocket (on the depth face)
        ctx.fillStyle = dark;
        ctx.fillRect(px+1, cy+1, depth-3, 4);
        ctx.fillStyle = base;
        ctx.fillRect(px+2, cy+2, depth-5, 2);
        ctx.fillStyle = accent;
        ctx.fillRect(px+1, cy+1, depth-3, 1); // pocket flap
        
        // Front pocket (on the sliver face — small)
        ctx.fillStyle = dark;
        ctx.fillRect(px+depth, cy, frontSliver-1, 3);
        ctx.fillStyle = accent;
        ctx.fillRect(px+depth, cy, frontSliver-1, 1);
        
        // Strap — vertical band across side
        ctx.fillStyle = dark;
        ctx.fillRect(cx-1, py-3, 2, ph+5);
        ctx.fillStyle = base;
        ctx.fillRect(cx, py-2, 1, ph+3);
        
        // Buckle
        ctx.fillStyle = '#7a7a7a';
        ctx.fillRect(cx-1, cy+1, 3, 3);
        ctx.fillStyle = '#999';
        ctx.fillRect(cx-1, cy+1, 3, 1);
        
        // Compression strap when full
        if (fullness > 0.5) {
            ctx.fillStyle = dark;
            ctx.fillRect(px, cy-2, totalW, 1);
            ctx.fillRect(px, cy+5, totalW, 1);
        }
        
        // Bottom seam / reinforcement
        ctx.fillStyle = dark;
        ctx.fillRect(px+1, py+ph-2, totalW-2, 1);
        
        // Holster weapons are separate sprites — not drawn on backpack canvas
    },
    
    
    // Create backpack sprite for a scene
    createBackpackSprite(scene, player, inventory) {
        const filledSlots = ItemManager.getFilledCount(inventory);
        const totalSlots = inventory.length;
        const fullness = totalSlots > 0 ? filledSlots / totalSlots : 0;
        
        const dir = player.lastDir || 'down';
        
        // Get equipment for holster display — try calling scene first, then active scenes
        let equip = null;
        if (scene && scene.state && scene.state.equipment) {
            equip = scene.state.equipment;
        } else {
            const gs = window.game && window.game.scene.scenes.find(s => { try { return s.scene.isActive() && s.state && s.state.equipment; } catch(e) { return s.state && s.state.equipment; } });
            equip = gs ? gs.state.equipment : null;
        }
        
        // Pass full direction for correct holster positioning
        const canvas = this.buildBackpack(scene, fullness, dir, equip);
        
        const bpColorId = (SpriteManager.playerCustomization && SpriteManager.playerCustomization.backpack) || 'green';
        const eqHash = equip ? `${equip.weapon?(equip.weapon.id||equip.weapon.baseId):'n'}_${equip.melee?(equip.melee.id||equip.melee.baseId):'n'}` : 'n_n';
        const texKey = `backpack_${bpColorId}_${dir}_${Math.floor(fullness * 10)}_${eqHash}`;
        
        // Add to scene textures if not exists
        if (!scene.textures.exists(texKey)) {
            scene.textures.addCanvas(texKey, canvas);
        }
        
        // Create sprite
        const backpack = scene.add.sprite(
            player.x + CONFIG.inventory.backpackOffset.x,
            player.y + CONFIG.inventory.backpackOffset.y,
            texKey
        );
        
        backpack.setDisplaySize(36, 36);
        backpack.setDepth(player.depth - 0.001);
        
        // Assign early so holster sprites can find it during creation
        player.backpack = backpack;
        
        // Create holster weapon sprites (separate from backpack canvas)
        this.createHolsterSprites(scene, player, backpack, equip);
        
        return backpack;
    },
    
    
    // ==========================================
    // HOLSTER SPRITES — Static weapon/melee on backpack
    // Weapon always left, melee always right (from back view)
    // FlipX when facing camera for perspective shift
    // Visible in most directions — only hidden when body blocks that side
    // ==========================================
    createHolsterSprites(scene, player, backpack, equipment) {
        // Destroy old holster sprites if they exist
        if (player._holsterWeapon) { player._holsterWeapon.destroy(); player._holsterWeapon = null; }
        if (player._holsterMelee) { player._holsterMelee.destroy(); player._holsterMelee = null; }
        
        if (!equipment) return;
        
        const holsterScale = 1.5; // Weapon holster scale
        const meleeHolsterScale = 1.1; // Melee holster — slightly smaller
        
        // Ranged weapon holster
        if (equipment.weapon && ItemManager.renderWeaponCanvas) {
            const wc = equipment.weapon._holsterWC || ItemManager.renderWeaponCanvas(equipment.weapon);
            equipment.weapon._holsterWC = wc;
            if (wc && wc.canvas) {
                // Render rotated -90° (pointing UP) onto holster canvas
                const hCanvas = document.createElement('canvas');
                // After -90° rotation: width becomes height, height becomes width
                hCanvas.width = Math.ceil(wc.canvas.height * holsterScale);
                hCanvas.height = Math.ceil(wc.canvas.width * holsterScale);
                const hCtx = hCanvas.getContext('2d');
                hCtx.save();
                hCtx.translate(hCanvas.width / 2, hCanvas.height / 2);
                hCtx.rotate(-Math.PI / 2);
                hCtx.scale(holsterScale, holsterScale);
                hCtx.drawImage(wc.canvas, -wc.canvas.width / 2, -wc.canvas.height / 2);
                hCtx.restore();
                
                const texKey = `holster_wpn_${equipment.weapon.id || equipment.weapon.baseId}_${Date.now()}`;
                if (scene.textures.exists(texKey)) scene.textures.remove(texKey);
                scene.textures.addCanvas(texKey, hCanvas);
                
                const spr = scene.add.sprite(backpack.x, backpack.y, texKey);
                spr.setDisplaySize(hCanvas.width, hCanvas.height);
                spr.setDepth(backpack.depth - 0.002);
                player._holsterWeapon = spr;
            }
        }
        
        // Melee weapon holster (already points UP natively)
        if (equipment.melee && ItemManager.renderWeaponCanvas) {
            const mc = equipment.melee._holsterWC || ItemManager.renderWeaponCanvas(equipment.melee);
            equipment.melee._holsterWC = mc;
            if (mc && mc.canvas) {
                const hCanvas = document.createElement('canvas');
                hCanvas.width = Math.ceil(mc.canvas.width * meleeHolsterScale);
                hCanvas.height = Math.ceil(mc.canvas.height * meleeHolsterScale);
                const hCtx = hCanvas.getContext('2d');
                hCtx.save();
                hCtx.translate(hCanvas.width / 2, hCanvas.height / 2);
                hCtx.scale(meleeHolsterScale, meleeHolsterScale);
                hCtx.drawImage(mc.canvas, -mc.canvas.width / 2, -mc.canvas.height / 2);
                hCtx.restore();
                
                const texKey = `holster_mel_${equipment.melee.id || equipment.melee.baseId}_${Date.now()}`;
                if (scene.textures.exists(texKey)) scene.textures.remove(texKey);
                scene.textures.addCanvas(texKey, hCanvas);
                
                const spr = scene.add.sprite(backpack.x, backpack.y, texKey);
                spr.setDisplaySize(hCanvas.width, hCanvas.height);
                spr.setDepth(backpack.depth - 0.002);
                player._holsterMelee = spr;
            }
        }
        
        // Set initial position and visibility immediately
        this.updateHolsterSprites(player, player.lastDir || 'down');
    },
    
    // Update holster sprite positions, visibility, and flipX based on direction
    updateHolsterSprites(player, dir) {
        const hw = player._holsterWeapon;
        const hm = player._holsterMelee;
        if (!hw && !hm) return;
        
        const bp = player.backpack;
        if (!bp) return;
        
        // Physical model: weapon bolted to LEFT side, melee bolted to RIGHT side
        // Camera reveals whichever face it's looking at
        const cfg = {
            // Back face (wide) — both edges visible, weapon left, melee right
            up:         { wX: -8, wY: -8, mX: 8,  mY: 0,  wV: true,  mV: true,  flip: false, wD: -0.002, mD: -0.002 },
            // Back-left — weapon side rotating into view, melee starting to hide
            up_left:    { wX: -7, wY: -8, mX: 7,  mY: 0,  wV: true,  mV: true,  flip: false, wD: -0.002, mD: -0.003 },
            // Back-right — melee side rotating into view, weapon starting to hide
            up_right:   { wX: -7, wY: -8, mX: 7,  mY: 0,  wV: true,  mV: true,  flip: false, wD: -0.003, mD: -0.002 },
            // Left face (narrow) — staring directly at weapon mount. Push out from body
            left:       { wX: 5,  wY: -9, mX: 5,  mY: 1,  wV: true,  mV: false, flip: false, wD: 0.002,  mD: -0.002 },
            // Right face (narrow) — staring directly at melee mount. Push out from body
            right:      { wX: -5, wY: -9, mX: -5, mY: 1,  wV: false, mV: true,  flip: false, wD: -0.002, mD: 0.002 },
            // Front face (wide) — mirror of back. Weapon appears on right edge, melee on left
            down:       { wX: 8,  wY: -8, mX: -8, mY: 0,  wV: true,  mV: true,  flip: true,  wD: 0.002,  mD: 0.002 },
            // Front-left — weapon side visible, push out from body
            down_left:  { wX: 6,  wY: -9, mX: 6,  mY: 1,  wV: true,  mV: false, flip: true,  wD: 0.002,  mD: -0.002 },
            // Front-right — melee side visible, push out from body
            down_right: { wX: -6, wY: -9, mX: -6, mY: 1,  wV: false, mV: true,  flip: true,  wD: -0.002, mD: 0.002 }
        };
        
        const c = cfg[dir] || cfg.up;
        
        if (hw) {
            hw.setVisible(c.wV);
            hw.setFlipX(c.flip);
            hw.x = bp.x + c.wX;
            hw.y = bp.y + c.wY;
            hw.setDepth(bp.depth + c.wD);
        }
        if (hm) {
            hm.setVisible(c.mV);
            hm.setFlipX(c.flip);
            hm.x = bp.x + c.mX;
            hm.y = bp.y + c.mY;
            hm.setDepth(bp.depth + c.mD);
        }
    },
    
    // Update backpack visual based on inventory changes AND direction
    updateBackpackSprite(scene, backpackSprite, inventory, direction = 'down', equipOverride = null) {
        if (!backpackSprite || !inventory) return;
        
        const filledSlots = ItemManager.getFilledCount(inventory);
        const totalSlots = inventory.length;
        const fullness = totalSlots > 0 ? filledSlots / totalSlots : 0;
        
        const bpColorId = (SpriteManager.playerCustomization && SpriteManager.playerCustomization.backpack) || 'green';
        
        // Get equipment — prefer override, then active scene, then scene finder
        let equip = equipOverride;
        if (!equip) {
            if (scene && scene.state && scene.state.equipment) {
                equip = scene.state.equipment;
            } else {
                const gs = window.game && window.game.scene.scenes.find(s => { try { return s.scene.isActive() && s.state && s.state.equipment; } catch(e) { return s.state && s.state.equipment; } });
                equip = gs ? gs.state.equipment : null;
            }
        }
        
        // Check if weapon/melee is actively in use — hide from holster
        let holsterEquip = equip;
        if (equip && scene && scene.player) {
            const p = scene.player;
            const weaponOut = p._isArmedTexture || false;
            const meleeOut = p._isMeleeSwinging || false;
            if (weaponOut || meleeOut) {
                holsterEquip = { ...equip };
                if (weaponOut) holsterEquip.weapon = null;
                if (meleeOut) holsterEquip.melee = null;
            }
        }
        
        const eqHash = holsterEquip ? `${holsterEquip.weapon?(holsterEquip.weapon.id||holsterEquip.weapon.baseId):'n'}_${holsterEquip.melee?(holsterEquip.melee.id||holsterEquip.melee.baseId):'n'}` : 'n_n';
        const texKey = `backpack_${bpColorId}_${direction}_${Math.floor(fullness * 10)}_${eqHash}`;
        
        if (!scene.textures.exists(texKey)) {
            const canvas = this.buildBackpack(scene, fullness, direction, holsterEquip);
            scene.textures.addCanvas(texKey, canvas);
        }
        
        backpackSprite.setTexture(texKey);
        
        // Refresh holster sprites if equipment changed
        if (scene && scene.player) {
            const p = scene.player;
            // Hide holster for weapon/melee that's actively in-hand
            const weaponOut = p._isArmedTexture || false;
            const meleeOut = p._isMeleeSwinging || false;
            
            // Only recreate if needed (equipment changed or first time)
            const currentEqHash = `${holsterEquip.weapon?(holsterEquip.weapon.id||''):'n'}_${holsterEquip.melee?(holsterEquip.melee.id||''):'n'}`;
            if (p._lastHolsterHash !== currentEqHash) {
                this.createHolsterSprites(scene, p, backpackSprite, holsterEquip);
                p._lastHolsterHash = currentEqHash;
            }
            
            // Toggle visibility for in-hand weapons
            if (p._holsterWeapon) p._holsterWeapon.setVisible(!weaponOut && p._holsterWeapon.visible);
            if (p._holsterMelee) p._holsterMelee.setVisible(!meleeOut && p._holsterMelee.visible);
        }
    },
    
    // === ENEMY SPRITES ===
    // ============================
    // ANIMATED ENEMY SPRITESHEETS
    // ============================
    // Each enemy gets a 4-direction × 3-frame spritesheet (12 frames total)
    // Directions: down(0), right(1), up(2), left(3) — 3 walk frames each
    // Built on HTML canvas like the player, registered as Phaser spritesheets
    
    enemySheetsBuilt: {},
    
    buildEnemySheet(scene, type) {
        // Include biome in cache key so tint changes per biome
        const biomeType = CONFIG.currentBiome?.type || 'grassy';
        const cacheKey = type + '_' + biomeType;
        if (this.enemySheetsBuilt[cacheKey]) return;
        const key = 'enemy_' + type + '_sheet';
        if (scene.textures.exists(key)) { this.enemySheetsBuilt[cacheKey] = true; return; }
        
        const cfg = CONFIG.enemyTypes[type];
        // Allow visual-only types (stumble variants) without CONFIG entry
        if (!cfg && !this.enemyDrawers[type]) return;
        const s = (CONFIG.enemyTypes[type]?.canvasSize) || (CONFIG.spriteCanvasSize?.[type]) || 32;
        const frames = 12; // 4 dirs × 3 frames
        
        const canvas = document.createElement('canvas');
        canvas.width = s * frames;
        canvas.height = s;
        const ctx = canvas.getContext('2d');
        
        const drawer = this.enemyDrawers[type];
        if (!drawer) return;
        
        for (let f = 0; f < frames; f++) {
            const dir = Math.floor(f / 3); // 0=down, 1=right, 2=up, 3=left
            const frame = f % 3; // walk cycle: 0=neutral, 1=step left, 2=step right
            ctx.save();
            ctx.translate(f * s, 0);
            drawer(ctx, s, dir, frame);
            ctx.restore();
        }
        
        // === BIOME COSMETIC TINT — subtle color shift per biome ===
        // Overgrown: mossy green cast, Wasteland: dusty amber/sand, Anomalous: purple corruption
        const biomeTints = {
            grassy:      { r: 60, g: 90, b: 50, a: 0.08 },   // green moss
            barren:      { r: 100, g: 80, b: 50, a: 0.10 },   // dust/sand
            apocalyptic: { r: 80, g: 40, b: 100, a: 0.12 }    // corruption purple
        };
        const tint = biomeTints[biomeType];
        if (tint) {
            ctx.save();
            ctx.globalCompositeOperation = 'source-atop';
            ctx.fillStyle = `rgba(${tint.r},${tint.g},${tint.b},${tint.a})`;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.restore();
        }
        
        // === BIOME COSMETIC DETAILS — distinctive per-biome enemy markings ===
        // Only apply to combat enemy types, not UI or special types
        const detailTypes = ['husk', 'husk_crawl', 'husk_stumble', 'flicker', 'flicker_attack', 'flicker_maimed', 'host', 'deadlock', 'reaper', 'spawn', 'skitterling'];
        if (detailTypes.includes(type)) {
            ctx.save();
            ctx.globalCompositeOperation = 'source-atop';
            
            for (let f = 0; f < frames; f++) {
                const fx = f * s;
                const cx = fx + s / 2;
                const cy = s / 2;
                // Same seed per frame so details don't jump during animation
                const detailRng = Utils.createRNG(type.length * 31 + (biomeType.length * 17));
                const dr = () => detailRng();
                
                if (biomeType === 'grassy') {
                    // Overgrown: vine tendrils + moss patches
                    ctx.strokeStyle = 'rgba(50,120,40,0.25)';
                    ctx.lineWidth = 1;
                    // Vine trailing from shoulder area
                    ctx.beginPath();
                    ctx.moveTo(cx - 3, cy - 4);
                    ctx.lineTo(cx - 5 - dr() * 3, cy + 4 + dr() * 4);
                    ctx.stroke();
                    // Small moss dots on body
                    ctx.fillStyle = 'rgba(40,100,30,0.3)';
                    ctx.fillRect(cx + 2 + Math.floor(dr() * 4), cy - 2 + Math.floor(dr() * 3), 2, 2);
                    ctx.fillRect(cx - 4 + Math.floor(dr() * 3), cy + 1 + Math.floor(dr() * 2), 1, 2);
                } else if (biomeType === 'barren') {
                    // Wasteland: dust coating + cracked skin patches
                    ctx.fillStyle = 'rgba(140,120,80,0.15)';
                    // Dust film on lower body
                    ctx.fillRect(fx, cy + 2, s, s / 2 - 2);
                    // Cracked lighter patches
                    ctx.strokeStyle = 'rgba(160,140,100,0.2)';
                    ctx.lineWidth = 0.5;
                    ctx.beginPath();
                    ctx.moveTo(cx - 2, cy - 1);
                    ctx.lineTo(cx + 1, cy + 2);
                    ctx.lineTo(cx + 3, cy);
                    ctx.stroke();
                } else if (biomeType === 'apocalyptic') {
                    // Anomalous: corruption veins + crystal growths
                    ctx.strokeStyle = 'rgba(100,40,160,0.35)';
                    ctx.lineWidth = 1;
                    // Corruption vein running down torso
                    ctx.beginPath();
                    ctx.moveTo(cx, cy - 6);
                    ctx.lineTo(cx + 1, cy);
                    ctx.lineTo(cx - 1, cy + 5);
                    ctx.stroke();
                    // Small cyan crystal protrusion
                    ctx.fillStyle = 'rgba(60,200,200,0.3)';
                    ctx.fillRect(cx + 3 + Math.floor(dr() * 2), cy - 3 - Math.floor(dr() * 2), 2, 3);
                    // Faint glow dot
                    ctx.fillStyle = 'rgba(100,50,180,0.2)';
                    ctx.fillRect(cx - 2, cy - 4, 1, 1);
                }
            }
            
            ctx.restore();
        }
        
        scene.textures.addSpriteSheet(key, canvas, { frameWidth: s, frameHeight: s });
        
        // Create animations
        const dirs = ['down', 'right', 'up', 'left'];
        const animFps = (type === 'flicker' || type === 'flicker_attack') ? 10 : 6;
        dirs.forEach((dirName, di) => {
            const animKey = `enemy_${type}_walk_${dirName}`;
            if (!scene.anims.exists(animKey)) {
                scene.anims.create({
                    key: animKey,
                    frames: scene.anims.generateFrameNumbers(key, { start: di * 3, end: di * 3 + 2 }),
                    frameRate: animFps,
                    repeat: -1
                });
            }
        });
        const idleKey = `enemy_${type}_idle`;
        if (!scene.anims.exists(idleKey)) {
            scene.anims.create({ key: idleKey, frames: [{ key, frame: 0 }], frameRate: 1 });
        }
        
        this.enemySheetsBuilt[type + '_' + biomeType] = true;
    },
    
    updateEnemyAnimation(enemy) {
        if (!enemy || !enemy.anims || !enemy.enemyType) return;
        // Don't override manual frame control during flicker attack, stumble, reaper attacks, or deadlock attacks
        if (enemy._stumbling) return;
        // Data-driven animation lock — enemies with manual frame control during attacks
        const _alFlags = CONFIG.enemyTypes[enemy.enemyType]?.animLockFlags;
        if (_alFlags && _alFlags.some(f => enemy[f])) return;
        const type = enemy.enemyType;
        const vx = enemy.body?.velocity?.x || 0;
        const vy = enemy.body?.velocity?.y || 0;
        const speed = Math.sqrt(vx * vx + vy * vy);
        
        if (speed < 5) {
            const idleKey = `enemy_${type}_idle`;
            if (enemy.anims.currentAnim?.key !== idleKey) {
                try { enemy.anims.play(idleKey, true); } catch(e) {}
            }
            enemy.setFlipX(false);
            return;
        }
        
        // Determine 4-way direction
        const angle = Math.atan2(vy, vx) * (180 / Math.PI);
        let dir;
        if (angle >= -45 && angle < 45) dir = 'right';
        else if (angle >= 45 && angle < 135) dir = 'down';
        else if (angle >= -135 && angle < -45) dir = 'up';
        else dir = 'left';
        
        // Track numeric direction for frame-based systems (stumble)
        const dirNum = dir === 'down' ? 0 : dir === 'right' ? 1 : dir === 'up' ? 2 : 3;
        enemy._lastDir = dirNum;
        
        const animKey = `enemy_${type}_walk_${dir}`;
        enemy.setFlipX(false);
        if (enemy.anims.currentAnim?.key !== animKey) {
            try { enemy.anims.play(animKey, true); } catch(e) {}
        }
    },
    
    // === ENEMY DRAWING FUNCTIONS ===
    // Each takes (ctx, size, dir, frame) where dir: 0=down,1=right,2=up,3=left
    enemyDrawers: {
        walker(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const bob = frame === 1 ? -1 : frame === 2 ? -1 : 0;
            const legL = frame === 1 ? 2 : frame === 2 ? -2 : 0;
            const armSwing = frame === 1 ? 2 : frame === 2 ? -2 : 0;
            
            // Shadow
            ctx.fillStyle = 'rgba(0,0,0,0.25)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 13, 7, 3, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // Down
                // Legs
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(cx - 4 + legL, cy + 7 + bob, 4, 8);
                ctx.fillRect(cx + legL * -1, cy + 7 + bob, 4, 8);
                // Body
                ctx.fillStyle = '#4a3a3a';
                ctx.fillRect(cx - 6, cy - 3 + bob, 12, 12);
                // Torn shirt
                ctx.fillStyle = '#6a4a4a';
                ctx.fillRect(cx - 4, cy - 1 + bob, 3, 8);
                ctx.fillStyle = '#5a3535';
                ctx.fillRect(cx + 2, cy + 2 + bob, 3, 5);
                // Arms
                ctx.fillStyle = '#7a8a7a';
                ctx.fillRect(cx - 10, cy - 2 + bob + armSwing, 5, 10);
                ctx.fillRect(cx + 5, cy - 2 + bob - armSwing, 5, 10);
                // Head
                ctx.fillStyle = '#7a8a7a';
                ctx.beginPath(); ctx.arc(cx, cy - 7 + bob, 6, 0, Math.PI * 2); ctx.fill();
                // Eyes
                ctx.fillStyle = '#2a1a1a';
                ctx.fillRect(cx - 3, cy - 9 + bob, 2, 3);
                ctx.fillRect(cx + 1, cy - 9 + bob, 2, 3);
                ctx.fillStyle = '#cc3333';
                ctx.fillRect(cx - 3, cy - 8 + bob, 1, 1);
                ctx.fillRect(cx + 2, cy - 8 + bob, 1, 1);
                // Mouth
                ctx.fillStyle = '#3a1a1a';
                ctx.fillRect(cx - 2, cy - 4 + bob, 4, 2);
            } else if (dir === 1) { // Right
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(cx - 1 + legL, cy + 7 + bob, 4, 8);
                ctx.fillRect(cx - 1 - legL, cy + 7 + bob, 4, 8);
                ctx.fillStyle = '#4a3a3a';
                ctx.fillRect(cx - 4, cy - 3 + bob, 10, 12);
                ctx.fillStyle = '#5a3535';
                ctx.fillRect(cx - 2, cy + 1 + bob, 6, 5);
                // Arm (front)
                ctx.fillStyle = '#7a8a7a';
                ctx.fillRect(cx + 4, cy - 1 + bob + armSwing, 4, 10);
                // Head
                ctx.fillStyle = '#7a8a7a';
                ctx.beginPath(); ctx.arc(cx + 1, cy - 7 + bob, 6, 0, Math.PI * 2); ctx.fill();
                // Eye
                ctx.fillStyle = '#2a1a1a';
                ctx.fillRect(cx + 3, cy - 8 + bob, 2, 3);
                ctx.fillStyle = '#cc3333';
                ctx.fillRect(cx + 3, cy - 7 + bob, 1, 1);
                // Mouth
                ctx.fillStyle = '#3a1a1a';
                ctx.fillRect(cx + 2, cy - 4 + bob, 3, 2);
                // Back arm
                ctx.fillStyle = '#6a7a6a';
                ctx.fillRect(cx - 6, cy + bob - armSwing, 4, 10);
            } else if (dir === 2) { // Up
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(cx - 4 + legL, cy + 7 + bob, 4, 8);
                ctx.fillRect(cx - legL, cy + 7 + bob, 4, 8);
                ctx.fillStyle = '#4a3a3a';
                ctx.fillRect(cx - 6, cy - 3 + bob, 12, 12);
                ctx.fillStyle = '#3a2a2a';
                ctx.fillRect(cx - 4, cy + 2 + bob, 8, 5);
                // Arms
                ctx.fillStyle = '#7a8a7a';
                ctx.fillRect(cx - 10, cy - 2 + bob - armSwing, 5, 10);
                ctx.fillRect(cx + 5, cy - 2 + bob + armSwing, 5, 10);
                // Head (back)
                ctx.fillStyle = '#6a7a6a';
                ctx.beginPath(); ctx.arc(cx, cy - 7 + bob, 6, 0, Math.PI * 2); ctx.fill();
                // Matted hair
                ctx.fillStyle = '#4a5a4a';
                ctx.fillRect(cx - 5, cy - 12 + bob, 10, 5);
            } else { // Left (mirror of right)
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(cx - 3 - legL, cy + 7 + bob, 4, 8);
                ctx.fillRect(cx - 3 + legL, cy + 7 + bob, 4, 8);
                ctx.fillStyle = '#4a3a3a';
                ctx.fillRect(cx - 6, cy - 3 + bob, 10, 12);
                ctx.fillStyle = '#5a3535';
                ctx.fillRect(cx - 4, cy + 1 + bob, 6, 5);
                ctx.fillStyle = '#7a8a7a';
                ctx.fillRect(cx - 8, cy - 1 + bob + armSwing, 4, 10);
                ctx.fillStyle = '#7a8a7a';
                ctx.beginPath(); ctx.arc(cx - 1, cy - 7 + bob, 6, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#2a1a1a';
                ctx.fillRect(cx - 5, cy - 8 + bob, 2, 3);
                ctx.fillStyle = '#cc3333';
                ctx.fillRect(cx - 4, cy - 7 + bob, 1, 1);
                ctx.fillStyle = '#3a1a1a';
                ctx.fillRect(cx - 5, cy - 4 + bob, 3, 2);
                ctx.fillStyle = '#6a7a6a';
                ctx.fillRect(cx + 2, cy + bob - armSwing, 4, 10);
            }
        },
        
        crawler(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const bob = frame === 1 ? -1 : 0;
            const legPush = frame === 1 ? 2 : frame === 2 ? -2 : 0;
            const bodyPulse = frame === 1 ? 1 : 0;
            
            ctx.fillStyle = 'rgba(0,0,0,0.25)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 6, 9, 4, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0 || dir === 2) { // Down/Up
                const faceDown = dir === 0;
                // Back legs
                ctx.fillStyle = '#4a5a3a';
                ctx.fillRect(cx - 10 + legPush, cy + 5 + bob, 6, 4);
                ctx.fillRect(cx + 4 - legPush, cy + 5 + bob, 6, 4);
                // Body
                ctx.fillStyle = '#3a4a2a';
                ctx.beginPath(); ctx.ellipse(cx, cy + 2 + bob, 8 + bodyPulse, 5 + bodyPulse, 0, 0, Math.PI * 2); ctx.fill();
                // Spine ridges
                ctx.fillStyle = '#4a5a3a';
                for (let i = 0; i < 4; i++) ctx.fillRect(cx - 6 + i * 4, cy - 1 + bob, 2, 2);
                // Front arms
                ctx.fillStyle = '#5a6a4a';
                ctx.fillRect(cx - 13 - legPush, cy - 3 + bob, 7, 3);
                ctx.fillRect(cx + 6 + legPush, cy - 3 + bob, 7, 3);
                // Claws
                ctx.fillStyle = '#3a3a2a';
                ctx.fillRect(cx - 15 - legPush, cy - 4 + bob, 3, 5);
                ctx.fillRect(cx + 12 + legPush, cy - 4 + bob, 3, 5);
                // Head
                ctx.fillStyle = '#5a6a4a';
                ctx.beginPath(); ctx.arc(cx, cy - 7 + bob, 5, 0, Math.PI * 2); ctx.fill();
                if (faceDown) {
                    ctx.fillStyle = '#ccaa33'; ctx.fillRect(cx - 3, cy - 9 + bob, 2, 2); ctx.fillRect(cx + 1, cy - 9 + bob, 2, 2);
                    ctx.fillStyle = '#1a1a0a'; ctx.fillRect(cx - 3, cy - 5 + bob, 6, 2); // mouth
                } else {
                    ctx.fillStyle = '#4a5a3a'; ctx.fillRect(cx - 4, cy - 11 + bob, 8, 4); // back of head
                }
            } else { // Right(1) / Left(3)
                const flip = dir === 3 ? -1 : 1;
                ctx.fillStyle = '#4a5a3a';
                ctx.fillRect(cx - 3 * flip + legPush, cy + 5 + bob, 5, 4);
                ctx.fillRect(cx - 3 * flip - legPush, cy + 3 + bob, 5, 4);
                ctx.fillStyle = '#3a4a2a';
                ctx.beginPath(); ctx.ellipse(cx, cy + 1 + bob, 7 + bodyPulse, 5, 0, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#4a5a3a';
                for (let i = 0; i < 3; i++) ctx.fillRect(cx - 4 + i * 3, cy - 2 + bob, 2, 2);
                // Front arms
                ctx.fillStyle = '#5a6a4a';
                ctx.fillRect(cx + 3 * flip + legPush * flip, cy - 4 + bob, 6 * flip, 3);
                // Head
                ctx.fillStyle = '#5a6a4a';
                ctx.beginPath(); ctx.arc(cx + 4 * flip, cy - 5 + bob, 5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#ccaa33'; ctx.fillRect(cx + 5 * flip, cy - 7 + bob, 2, 2);
                ctx.fillStyle = '#1a1a0a'; ctx.fillRect(cx + 4 * flip, cy - 3 + bob, 3, 2);
            }
        },
        
        sprinter(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const bob = frame === 1 ? -2 : frame === 2 ? -1 : 0;
            const legL = frame === 1 ? 3 : frame === 2 ? -3 : 0;
            const armSwing = frame === 1 ? 3 : frame === 2 ? -3 : 0;
            
            ctx.fillStyle = 'rgba(0,0,0,0.2)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 13, 5, 3, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // Down
                ctx.fillStyle = '#4a2a3a';
                ctx.fillRect(cx - 4 + legL, cy + 6 + bob, 3, 10);
                ctx.fillRect(cx + 1 - legL, cy + 6 + bob, 3, 10);
                ctx.fillStyle = '#5a3a4a';
                ctx.fillRect(cx - 5, cy - 4 + bob, 10, 12);
                // Ribs
                ctx.fillStyle = '#4a2a3a';
                for (let i = 0; i < 3; i++) ctx.fillRect(cx - 3, cy - 2 + i * 3 + bob, 6, 1);
                // Arms (long, thin, reaching)
                ctx.fillStyle = '#8a6a7a';
                ctx.fillRect(cx - 9, cy - 3 + bob + armSwing, 4, 14);
                ctx.fillRect(cx + 5, cy - 3 + bob - armSwing, 4, 14);
                // Claws
                ctx.fillStyle = '#6a4a5a';
                ctx.fillRect(cx - 10, cy + 10 + bob + armSwing, 5, 3);
                ctx.fillRect(cx + 5, cy + 10 + bob - armSwing, 5, 3);
                // Head
                ctx.fillStyle = '#8a6a7a';
                ctx.beginPath(); ctx.arc(cx, cy - 8 + bob, 5, 0, Math.PI * 2); ctx.fill();
                // Wild eyes
                ctx.fillStyle = '#ff4444';
                ctx.fillRect(cx - 3, cy - 9 + bob, 2, 2);
                ctx.fillRect(cx + 1, cy - 9 + bob, 2, 2);
                // Screaming mouth
                ctx.fillStyle = '#2a0a0a';
                ctx.beginPath(); ctx.arc(cx, cy - 4 + bob, 2, 0, Math.PI * 2); ctx.fill();
            } else if (dir === 1) { // Right
                ctx.fillStyle = '#4a2a3a';
                ctx.fillRect(cx - 1 + legL, cy + 6 + bob, 3, 10);
                ctx.fillRect(cx - 1 - legL, cy + 6 + bob, 3, 10);
                ctx.fillStyle = '#5a3a4a';
                ctx.fillRect(cx - 4, cy - 4 + bob, 8, 12);
                ctx.fillStyle = '#8a6a7a';
                ctx.fillRect(cx + 2, cy - 2 + bob + armSwing, 4, 13);
                ctx.fillStyle = '#6a4a5a';
                ctx.fillRect(cx + 2, cy + 10 + bob + armSwing, 5, 3);
                ctx.fillStyle = '#8a6a7a';
                ctx.beginPath(); ctx.arc(cx + 1, cy - 8 + bob, 5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#ff4444';
                ctx.fillRect(cx + 3, cy - 9 + bob, 2, 2);
                ctx.fillStyle = '#2a0a0a';
                ctx.fillRect(cx + 3, cy - 5 + bob, 2, 3);
                ctx.fillStyle = '#7a5a6a';
                ctx.fillRect(cx - 6, cy - 1 + bob - armSwing, 3, 12);
            } else if (dir === 2) { // Up
                ctx.fillStyle = '#4a2a3a';
                ctx.fillRect(cx - 4 + legL, cy + 6 + bob, 3, 10);
                ctx.fillRect(cx + 1 - legL, cy + 6 + bob, 3, 10);
                ctx.fillStyle = '#5a3a4a';
                ctx.fillRect(cx - 5, cy - 4 + bob, 10, 12);
                ctx.fillStyle = '#8a6a7a';
                ctx.fillRect(cx - 9, cy - 3 + bob - armSwing, 4, 14);
                ctx.fillRect(cx + 5, cy - 3 + bob + armSwing, 4, 14);
                ctx.fillStyle = '#7a5a6a';
                ctx.beginPath(); ctx.arc(cx, cy - 8 + bob, 5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#4a2a3a';
                ctx.fillRect(cx - 4, cy - 12 + bob, 8, 4);
            } else { // Left
                ctx.fillStyle = '#4a2a3a';
                ctx.fillRect(cx - 2 - legL, cy + 6 + bob, 3, 10);
                ctx.fillRect(cx - 2 + legL, cy + 6 + bob, 3, 10);
                ctx.fillStyle = '#5a3a4a';
                ctx.fillRect(cx - 4, cy - 4 + bob, 8, 12);
                ctx.fillStyle = '#8a6a7a';
                ctx.fillRect(cx - 6, cy - 2 + bob + armSwing, 4, 13);
                ctx.fillStyle = '#6a4a5a';
                ctx.fillRect(cx - 7, cy + 10 + bob + armSwing, 5, 3);
                ctx.fillStyle = '#8a6a7a';
                ctx.beginPath(); ctx.arc(cx - 1, cy - 8 + bob, 5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#ff4444';
                ctx.fillRect(cx - 5, cy - 9 + bob, 2, 2);
                ctx.fillStyle = '#2a0a0a';
                ctx.fillRect(cx - 5, cy - 5 + bob, 2, 3);
                ctx.fillStyle = '#7a5a6a';
                ctx.fillRect(cx + 3, cy - 1 + bob - armSwing, 3, 12);
            }
        },
        
        // ¾ CAMERA RULE — Host: large 4-armed fleshy ranged enemy
        // Down: front face wide — bloated asymmetric torso, exposed muscle fiber striations,
        //   upper arms (large, outer) with bulging bicep/tricep and 3-claw hands,
        //   lower arms (smaller, inner) with thinner forearms and 2-claw grippers,
        //   stumpy digitigrade legs, small head sunk into shoulders, sunken eye sockets
        // Up: back — spine ridge with vertebrae bumps, shoulder blade mounds, scapula ridges,
        //   arms from behind showing tricep bulk, back of skull plate
        // Side: side face dominant (torso depth), front compressed sliver,
        //   near arms show full profile (upper arm bulk + forearm + claws),
        //   far arms partial behind body mass
        host(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const bob = frame === 1 ? -1 : 0;
            const legL = frame === 1 ? 1 : frame === 2 ? -1 : 0;
            const armUp = frame === 1 ? -2 : frame === 2 ? 1 : 0; // upper arms swing
            const armLo = frame === 1 ? 1 : frame === 2 ? -1 : 0; // lower arms counter-swing
            
            // Shadow
            ctx.fillStyle = 'rgba(0,0,0,0.3)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 16, 11, 5, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // === DOWN — front face ===
                // Stumpy digitigrade legs
                ctx.fillStyle = '#4a3322';
                ctx.fillRect(cx - 6 + legL, cy + 10 + bob, 5, 7);  // left thigh
                ctx.fillRect(cx + 1 - legL, cy + 10 + bob, 5, 7);  // right thigh
                // Knee joints
                ctx.fillStyle = '#3a2818';
                ctx.fillRect(cx - 5 + legL, cy + 14 + bob, 3, 2);
                ctx.fillRect(cx + 2 - legL, cy + 14 + bob, 3, 2);
                // Lower leg (angled forward — digitigrade)
                ctx.fillStyle = '#4a3322';
                ctx.fillRect(cx - 7 + legL, cy + 15 + bob, 4, 4);
                ctx.fillRect(cx + 3 - legL, cy + 15 + bob, 4, 4);
                // Feet — broad, splayed
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx - 8 + legL, cy + 18 + bob, 6, 2);
                ctx.fillRect(cx + 2 - legL, cy + 18 + bob, 6, 2);
                // Toe claws
                ctx.fillStyle = '#2a1a0e';
                ctx.fillRect(cx - 8 + legL, cy + 19 + bob, 2, 1);
                ctx.fillRect(cx - 4 + legL, cy + 19 + bob, 2, 1);
                ctx.fillRect(cx + 2 - legL, cy + 19 + bob, 2, 1);
                ctx.fillRect(cx + 6 - legL, cy + 19 + bob, 2, 1);
                
                // Bloated torso — asymmetric mass
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 10, cy - 6 + bob, 20, 18);
                // Left side slightly bulkier (asymmetry)
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx - 11, cy - 4 + bob, 3, 12);
                // Muscle fiber striations — horizontal across chest
                ctx.fillStyle = '#6a4a35';
                ctx.fillRect(cx - 8, cy - 4 + bob, 16, 2); // pec line
                ctx.fillRect(cx - 7, cy - 1 + bob, 14, 1); // mid fiber
                ctx.fillRect(cx - 8, cy + 2 + bob, 16, 1); // lower fiber
                // Exposed muscle — red-pink undertone showing through
                ctx.fillStyle = '#6a3a2a';
                ctx.fillRect(cx - 6, cy - 3 + bob, 5, 4); // left exposed patch
                ctx.fillRect(cx + 2, cy - 1 + bob, 4, 3); // right exposed patch
                // Connective tissue / tendon lines
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 1, cy - 5 + bob, 2, 14); // center seam
                ctx.fillRect(cx - 9, cy + 3 + bob, 18, 1); // horizontal tendon
                // Belly mass — distended
                ctx.fillStyle = '#6a4833';
                ctx.fillRect(cx - 8, cy + 5 + bob, 16, 6);
                ctx.fillStyle = '#7a5840';
                ctx.fillRect(cx - 6, cy + 6 + bob, 12, 4);
                // Belly button / rupture scar
                ctx.fillStyle = '#4a2a18';
                ctx.fillRect(cx - 1, cy + 7 + bob, 2, 2);
                
                // === UPPER ARMS (large, outer) ===
                // Left upper arm — shoulder joint
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 12, cy - 6 + bob, 3, 4); // deltoid cap
                // Bicep bulk
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx - 15, cy - 3 + bob + armUp, 6, 8);
                // Muscle definition on bicep
                ctx.fillStyle = '#6a4835';
                ctx.fillRect(cx - 14, cy - 2 + bob + armUp, 4, 3); // bicep peak
                // Forearm
                ctx.fillStyle = '#4a3020';
                ctx.fillRect(cx - 16, cy + 4 + bob + armUp, 5, 6);
                // Tendon ridges on forearm
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 15, cy + 5 + bob + armUp, 1, 4);
                ctx.fillRect(cx - 13, cy + 5 + bob + armUp, 1, 4);
                // Wrist joint
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx - 16, cy + 9 + bob + armUp, 5, 2);
                // 3-claw hand
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 17, cy + 10 + bob + armUp, 2, 4); // outer claw
                ctx.fillRect(cx - 14, cy + 10 + bob + armUp, 2, 4); // mid claw
                ctx.fillRect(cx - 11, cy + 10 + bob + armUp, 2, 3); // inner claw
                // Claw tips — darker
                ctx.fillStyle = '#2a1208';
                ctx.fillRect(cx - 17, cy + 13 + bob + armUp, 1, 1);
                ctx.fillRect(cx - 14, cy + 13 + bob + armUp, 1, 1);
                ctx.fillRect(cx - 11, cy + 12 + bob + armUp, 1, 1);
                
                // Right upper arm — mirror
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 9, cy - 6 + bob, 3, 4);
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx + 9, cy - 3 + bob - armUp, 6, 8);
                ctx.fillStyle = '#6a4835';
                ctx.fillRect(cx + 10, cy - 2 + bob - armUp, 4, 3);
                ctx.fillStyle = '#4a3020';
                ctx.fillRect(cx + 11, cy + 4 + bob - armUp, 5, 6);
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 12, cy + 5 + bob - armUp, 1, 4);
                ctx.fillRect(cx + 14, cy + 5 + bob - armUp, 1, 4);
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx + 11, cy + 9 + bob - armUp, 5, 2);
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx + 10, cy + 10 + bob - armUp, 2, 4);
                ctx.fillRect(cx + 13, cy + 10 + bob - armUp, 2, 4);
                ctx.fillRect(cx + 16, cy + 10 + bob - armUp, 2, 3);
                ctx.fillStyle = '#2a1208';
                ctx.fillRect(cx + 10, cy + 13 + bob - armUp, 1, 1);
                ctx.fillRect(cx + 13, cy + 13 + bob - armUp, 1, 1);
                ctx.fillRect(cx + 16, cy + 12 + bob - armUp, 1, 1);
                
                // === LOWER ARMS (smaller, inner, tucked) ===
                // Left lower arm — emerges from under chest
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx - 11, cy + 1 + bob + armLo, 3, 6); // thin upper
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx - 12, cy + 6 + bob + armLo, 3, 4); // forearm
                // 2-claw gripper
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 13, cy + 9 + bob + armLo, 2, 3);
                ctx.fillRect(cx - 10, cy + 9 + bob + armLo, 2, 3);
                ctx.fillStyle = '#2a1208';
                ctx.fillRect(cx - 13, cy + 11 + bob + armLo, 1, 1);
                ctx.fillRect(cx - 10, cy + 11 + bob + armLo, 1, 1);
                
                // Right lower arm
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx + 8, cy + 1 + bob - armLo, 3, 6);
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx + 9, cy + 6 + bob - armLo, 3, 4);
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx + 8, cy + 9 + bob - armLo, 2, 3);
                ctx.fillRect(cx + 11, cy + 9 + bob - armLo, 2, 3);
                ctx.fillStyle = '#2a1208';
                ctx.fillRect(cx + 8, cy + 11 + bob - armLo, 1, 1);
                ctx.fillRect(cx + 11, cy + 11 + bob - armLo, 1, 1);
                
                // === HEAD — small, sunk into shoulder mass ===
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 5, cy - 13 + bob, 10, 9);
                // Skull plate on top
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx - 4, cy - 14 + bob, 8, 3);
                // Brow ridge
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx - 5, cy - 11 + bob, 10, 2);
                // Sunken eye sockets — deep dark pits
                ctx.fillStyle = '#1a0a05';
                ctx.fillRect(cx - 4, cy - 10 + bob, 3, 2);
                ctx.fillRect(cx + 1, cy - 10 + bob, 3, 2);
                // Dim ember glow deep in sockets
                ctx.fillStyle = '#884422';
                ctx.fillRect(cx - 3, cy - 9 + bob, 1, 1);
                ctx.fillRect(cx + 2, cy - 9 + bob, 1, 1);
                // Jaw — heavy, slightly open
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 4, cy - 7 + bob, 8, 3);
                ctx.fillStyle = '#3a1a10';
                ctx.fillRect(cx - 3, cy - 6 + bob, 6, 2); // mouth cavity
                // Shoulder mounds flanking head
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 8, cy - 8 + bob, 4, 4);
                ctx.fillRect(cx + 4, cy - 8 + bob, 4, 4);
                
            } else if (dir === 2) { // === UP — back view ===
                // Legs from behind
                ctx.fillStyle = '#4a3322';
                ctx.fillRect(cx - 6 + legL, cy + 10 + bob, 5, 7);
                ctx.fillRect(cx + 1 - legL, cy + 10 + bob, 5, 7);
                ctx.fillStyle = '#3a2818';
                ctx.fillRect(cx - 7 + legL, cy + 15 + bob, 4, 4);
                ctx.fillRect(cx + 3 - legL, cy + 15 + bob, 4, 4);
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx - 8 + legL, cy + 18 + bob, 6, 2);
                ctx.fillRect(cx + 2 - legL, cy + 18 + bob, 6, 2);
                
                // Back torso — darker, more uniform
                ctx.fillStyle = '#4a2e20';
                ctx.fillRect(cx - 10, cy - 6 + bob, 20, 18);
                ctx.fillStyle = '#4a2a1e';
                ctx.fillRect(cx - 11, cy - 4 + bob, 3, 12);
                // Spine ridge — prominent vertebrae
                ctx.fillStyle = '#3a2015';
                ctx.fillRect(cx - 1, cy - 5 + bob, 2, 16);
                ctx.fillStyle = '#5a3a28';
                for (let v = 0; v < 5; v++) {
                    ctx.fillRect(cx - 2, cy - 4 + v * 3 + bob, 4, 2); // vertebrae bumps
                }
                // Scapula ridges
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx - 8, cy - 4 + bob, 5, 5);
                ctx.fillRect(cx + 3, cy - 4 + bob, 5, 5);
                // Scapula edges
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 8, cy - 4 + bob, 1, 5);
                ctx.fillRect(cx + 7, cy - 4 + bob, 1, 5);
                // Back muscle bands
                ctx.fillStyle = '#4a2e20';
                ctx.fillRect(cx - 9, cy + 2 + bob, 8, 1);
                ctx.fillRect(cx + 1, cy + 2 + bob, 8, 1);
                
                // Upper arms from behind (tricep visible)
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 15, cy - 3 + bob + armUp, 6, 8);
                ctx.fillRect(cx + 9, cy - 3 + bob - armUp, 6, 8);
                // Tricep bulk
                ctx.fillStyle = '#4a2e20';
                ctx.fillRect(cx - 14, cy - 1 + bob + armUp, 4, 4);
                ctx.fillRect(cx + 10, cy - 1 + bob - armUp, 4, 4);
                // Forearms + claws from behind
                ctx.fillStyle = '#4a3020';
                ctx.fillRect(cx - 16, cy + 4 + bob + armUp, 5, 6);
                ctx.fillRect(cx + 11, cy + 4 + bob - armUp, 5, 6);
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 17, cy + 10 + bob + armUp, 7, 3);
                ctx.fillRect(cx + 10, cy + 10 + bob - armUp, 7, 3);
                
                // Lower arms from behind
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx - 11, cy + 1 + bob + armLo, 3, 6);
                ctx.fillRect(cx + 8, cy + 1 + bob - armLo, 3, 6);
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx - 12, cy + 6 + bob + armLo, 3, 4);
                ctx.fillRect(cx + 9, cy + 6 + bob - armLo, 3, 4);
                
                // Back of head — skull plate
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 5, cy - 13 + bob, 10, 9);
                ctx.fillStyle = '#3a1a10';
                ctx.fillRect(cx - 3, cy - 12 + bob, 6, 6); // darker skull rear
                // Ridge at base of skull
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx - 4, cy - 6 + bob, 8, 2);
                
            } else { // === SIDE — dir 1 (right) / dir 3 (left) ===
                const flip = dir === 3 ? -1 : 1;
                
                // Legs from side
                ctx.fillStyle = '#4a3322';
                ctx.fillRect(cx - 2 + legL * flip, cy + 10 + bob, 4, 7); // near leg
                ctx.fillRect(cx - 2 - legL * flip, cy + 11 + bob, 4, 6); // far leg
                ctx.fillStyle = '#3a2818';
                ctx.fillRect(cx - 3 + legL * flip, cy + 15 + bob, 4, 4);
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx - 4 + legL * flip, cy + 18 + bob, 6, 2);
                
                // Side torso (DEPTH face dominant — seeing thickness)
                ctx.fillStyle = '#4a2e20';
                ctx.fillRect(cx - 7, cy - 6 + bob, 14, 18);
                // Front sliver (compressed, facing away)
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 6 * flip, cy - 5 + bob, 3, 16);
                // Muscle striations on side
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx - 5, cy - 3 + bob, 10, 1);
                ctx.fillRect(cx - 5, cy + 0 + bob, 10, 1);
                ctx.fillRect(cx - 4, cy + 3 + bob, 8, 1);
                // Exposed patch on side
                ctx.fillStyle = '#6a3a2a';
                ctx.fillRect(cx - 3, cy - 2 + bob, 4, 3);
                // Rib shadow
                ctx.fillStyle = '#3a2015';
                ctx.fillRect(cx - 6, cy + 1 + bob, 12, 1);
                // Belly bulge
                ctx.fillStyle = '#6a4833';
                ctx.fillRect(cx - 5, cy + 5 + bob, 11, 5);
                ctx.fillStyle = '#7a5840';
                ctx.fillRect(cx - 3, cy + 6 + bob, 8, 3);
                
                // === NEAR UPPER ARM (full profile) ===
                // Shoulder cap
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 6 * flip, cy - 6 + bob, 4 * flip, 4);
                // Upper arm — bicep mass from side
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx + 7 * flip, cy - 3 + bob + armUp, 5 * flip, 7);
                // Bicep peak
                ctx.fillStyle = '#6a4835';
                ctx.fillRect(cx + 8 * flip, cy - 2 + bob + armUp, 3 * flip, 3);
                // Elbow joint
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx + 7 * flip, cy + 3 + bob + armUp, 4 * flip, 2);
                // Forearm
                ctx.fillStyle = '#4a3020';
                ctx.fillRect(cx + 7 * flip, cy + 4 + bob + armUp, 4 * flip, 5);
                // Tendon lines on forearm
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 8 * flip, cy + 5 + bob + armUp, 1, 3);
                ctx.fillRect(cx + 10 * flip, cy + 5 + bob + armUp, 1, 3);
                // 3-claw hand
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx + 6 * flip, cy + 8 + bob + armUp, 2, 4);
                ctx.fillRect(cx + 9 * flip, cy + 8 + bob + armUp, 2, 4);
                ctx.fillRect(cx + 12 * flip, cy + 8 + bob + armUp, 2, 3);
                ctx.fillStyle = '#2a1208';
                ctx.fillRect(cx + 6 * flip, cy + 11 + bob + armUp, 1, 1);
                ctx.fillRect(cx + 9 * flip, cy + 11 + bob + armUp, 1, 1);
                
                // === NEAR LOWER ARM (smaller, closer to body) ===
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx + 3 * flip, cy + 0 + bob + armLo, 3 * flip, 5);
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx + 3 * flip, cy + 4 + bob + armLo, 3 * flip, 4);
                // 2-claw gripper
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx + 2 * flip, cy + 7 + bob + armLo, 2, 3);
                ctx.fillRect(cx + 5 * flip, cy + 7 + bob + armLo, 2, 3);
                
                // === FAR UPPER ARM — partial behind body ===
                ctx.fillStyle = '#4a2e20';
                ctx.fillRect(cx - 8 * flip, cy - 2 + bob - armUp, 3, 8);
                // Far forearm peeking
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx - 9 * flip, cy + 5 + bob - armUp, 3, 4);
                
                // === FAR LOWER ARM — barely visible ===
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 6 * flip, cy + 2 + bob - armLo, 2, 5);
                
                // Head from side
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 2 + 2 * flip, cy - 13 + bob, 8, 9);
                // Skull plate
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx - 1 + 2 * flip, cy - 14 + bob, 6, 3);
                // Brow ridge from side
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx + 1 * flip, cy - 11 + bob, 5, 2);
                // Eye socket
                ctx.fillStyle = '#1a0a05';
                ctx.fillRect(cx + 3 * flip, cy - 10 + bob, 2, 2);
                ctx.fillStyle = '#884422';
                ctx.fillRect(cx + 3 * flip, cy - 9 + bob, 1, 1);
                // Jaw from side
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx + 1 * flip, cy - 7 + bob, 4, 3);
                ctx.fillStyle = '#3a1a10';
                ctx.fillRect(cx + 2 * flip, cy - 6 + bob, 2, 1);
                // Shoulder mound
                ctx.fillStyle = '#5a3828';
                ctx.fillRect(cx + 0, cy - 8 + bob, 5, 3);
            }
        },
        
        // ¾ CAMERA RULE — Host slam: 4-arm melee cone attack animation
        // Frame 0 (WINDUP): all 4 arms raised high above head, body crouches, menacing gather
        // Frame 1 (SWING): arms coming down in arc, body lunges forward, motion blur feel
        // Frame 2 (IMPACT): arms extended forward into ground, dust implied, body hunched over
        host_slam(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            
            // Shadow
            ctx.fillStyle = 'rgba(0,0,0,0.3)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 16, 11, 5, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // === DOWN — front face ===
                // Legs — planted wide, braced
                ctx.fillStyle = '#4a3322';
                ctx.fillRect(cx - 7, cy + 10, 5, 8);
                ctx.fillRect(cx + 2, cy + 10, 5, 8);
                ctx.fillStyle = '#3a2215';
                ctx.fillRect(cx - 8, cy + 17, 7, 2);
                ctx.fillRect(cx + 1, cy + 17, 7, 2);
                
                // Torso
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 10, cy - 4 + (frame === 2 ? 3 : 0), 20, 16);
                ctx.fillStyle = '#6a4a35';
                ctx.fillRect(cx - 8, cy - 2 + (frame === 2 ? 3 : 0), 16, 2);
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 1, cy - 3 + (frame === 2 ? 3 : 0), 2, 12);
                // Belly
                ctx.fillStyle = '#6a4833';
                ctx.fillRect(cx - 8, cy + 4 + (frame === 2 ? 3 : 0), 16, 6);
                
                if (frame === 0) {
                    // === WINDUP — all arms raised above head ===
                    // Head ducked down
                    ctx.fillStyle = '#5a3a28';
                    ctx.fillRect(cx - 4, cy - 10, 8, 7);
                    ctx.fillStyle = '#1a0a05';
                    ctx.fillRect(cx - 3, cy - 8, 2, 2);
                    ctx.fillRect(cx + 1, cy - 8, 2, 2);
                    ctx.fillStyle = '#884422';
                    ctx.fillRect(cx - 2, cy - 7, 1, 1);
                    ctx.fillRect(cx + 2, cy - 7, 1, 1);
                    
                    // Upper arms — raised high, claws skyward
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx - 16, cy - 18, 6, 14); // left upper
                    ctx.fillRect(cx + 10, cy - 18, 6, 14); // right upper
                    // Bicep bulge
                    ctx.fillStyle = '#6a4835';
                    ctx.fillRect(cx - 15, cy - 16, 4, 4);
                    ctx.fillRect(cx + 11, cy - 16, 4, 4);
                    // Claws raised — splayed outward
                    ctx.fillStyle = '#4a2a1a';
                    ctx.fillRect(cx - 18, cy - 21, 2, 4);
                    ctx.fillRect(cx - 15, cy - 22, 2, 5);
                    ctx.fillRect(cx - 12, cy - 20, 2, 3);
                    ctx.fillRect(cx + 10, cy - 20, 2, 3);
                    ctx.fillRect(cx + 13, cy - 22, 2, 5);
                    ctx.fillRect(cx + 16, cy - 21, 2, 4);
                    // Claw tips
                    ctx.fillStyle = '#2a1208';
                    ctx.fillRect(cx - 18, cy - 22, 1, 2);
                    ctx.fillRect(cx - 15, cy - 23, 1, 2);
                    ctx.fillRect(cx + 14, cy - 23, 1, 2);
                    ctx.fillRect(cx + 17, cy - 22, 1, 2);
                    
                    // Lower arms — also raised, inner
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx - 11, cy - 14, 4, 10);
                    ctx.fillRect(cx + 7, cy - 14, 4, 10);
                    // 2-claw grippers raised
                    ctx.fillStyle = '#4a2a1a';
                    ctx.fillRect(cx - 12, cy - 16, 2, 3);
                    ctx.fillRect(cx - 9, cy - 16, 2, 3);
                    ctx.fillRect(cx + 7, cy - 16, 2, 3);
                    ctx.fillRect(cx + 10, cy - 16, 2, 3);
                    
                } else if (frame === 1) {
                    // === MID-SWING — arms sweeping down, body lurching ===
                    // Head — forward
                    ctx.fillStyle = '#5a3a28';
                    ctx.fillRect(cx - 4, cy - 10, 8, 7);
                    ctx.fillStyle = '#1a0a05';
                    ctx.fillRect(cx - 3, cy - 8, 2, 2);
                    ctx.fillRect(cx + 1, cy - 8, 2, 2);
                    ctx.fillStyle = '#cc4422'; // eyes flare during swing
                    ctx.fillRect(cx - 2, cy - 7, 1, 1);
                    ctx.fillRect(cx + 2, cy - 7, 1, 1);
                    
                    // Upper arms — mid-arc, angled ~45° forward-down
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx - 16, cy - 8, 7, 10);
                    ctx.fillRect(cx + 9, cy - 8, 7, 10);
                    ctx.fillStyle = '#6a4835';
                    ctx.fillRect(cx - 15, cy - 6, 5, 4);
                    ctx.fillRect(cx + 10, cy - 6, 5, 4);
                    // Claws in arc
                    ctx.fillStyle = '#4a2a1a';
                    ctx.fillRect(cx - 18, cy, 3, 5);
                    ctx.fillRect(cx - 14, cy, 3, 5);
                    ctx.fillRect(cx + 11, cy, 3, 5);
                    ctx.fillRect(cx + 15, cy, 3, 5);
                    
                    // Lower arms — mid arc, closer to body
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx - 12, cy - 4, 4, 8);
                    ctx.fillRect(cx + 8, cy - 4, 4, 8);
                    ctx.fillStyle = '#4a2a1a';
                    ctx.fillRect(cx - 13, cy + 2, 2, 4);
                    ctx.fillRect(cx - 10, cy + 2, 2, 4);
                    ctx.fillRect(cx + 8, cy + 2, 2, 4);
                    ctx.fillRect(cx + 11, cy + 2, 2, 4);
                    
                    // Motion blur lines
                    ctx.fillStyle = 'rgba(90,58,40,0.25)';
                    ctx.fillRect(cx - 14, cy - 12, 2, 6);
                    ctx.fillRect(cx + 12, cy - 12, 2, 6);
                    
                } else {
                    // === IMPACT — arms slammed forward into ground ===
                    // Head — ducked behind shoulders
                    ctx.fillStyle = '#5a3a28';
                    ctx.fillRect(cx - 4, cy - 6, 8, 6);
                    ctx.fillStyle = '#1a0a05';
                    ctx.fillRect(cx - 3, cy - 5, 2, 2);
                    ctx.fillRect(cx + 1, cy - 5, 2, 2);
                    ctx.fillStyle = '#cc4422';
                    ctx.fillRect(cx - 2, cy - 4, 1, 1);
                    ctx.fillRect(cx + 2, cy - 4, 1, 1);
                    
                    // Upper arms — extended forward and DOWN (we see them stretching toward camera)
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx - 16, cy + 2, 8, 8);
                    ctx.fillRect(cx + 8, cy + 2, 8, 8);
                    ctx.fillStyle = '#6a4835';
                    ctx.fillRect(cx - 14, cy + 4, 5, 4);
                    ctx.fillRect(cx + 9, cy + 4, 5, 4);
                    // Claws dug into ground — splayed wide
                    ctx.fillStyle = '#4a2a1a';
                    ctx.fillRect(cx - 19, cy + 9, 3, 5);
                    ctx.fillRect(cx - 15, cy + 9, 3, 5);
                    ctx.fillRect(cx - 11, cy + 9, 2, 4);
                    ctx.fillRect(cx + 9, cy + 9, 2, 4);
                    ctx.fillRect(cx + 12, cy + 9, 3, 5);
                    ctx.fillRect(cx + 16, cy + 9, 3, 5);
                    // Claw tips dug in
                    ctx.fillStyle = '#2a1208';
                    ctx.fillRect(cx - 19, cy + 13, 2, 2);
                    ctx.fillRect(cx - 15, cy + 13, 2, 2);
                    ctx.fillRect(cx + 13, cy + 13, 2, 2);
                    ctx.fillRect(cx + 17, cy + 13, 2, 2);
                    
                    // Lower arms — also extended
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx - 12, cy + 4, 5, 6);
                    ctx.fillRect(cx + 7, cy + 4, 5, 6);
                    ctx.fillStyle = '#4a2a1a';
                    ctx.fillRect(cx - 13, cy + 9, 2, 3);
                    ctx.fillRect(cx - 10, cy + 9, 2, 3);
                    ctx.fillRect(cx + 8, cy + 9, 2, 3);
                    ctx.fillRect(cx + 11, cy + 9, 2, 3);
                    
                    // Ground crack lines at impact
                    ctx.fillStyle = 'rgba(60,40,20,0.4)';
                    ctx.fillRect(cx - 20, cy + 14, 40, 1);
                    ctx.fillRect(cx - 16, cy + 15, 32, 1);
                    // Dust particles
                    ctx.fillStyle = 'rgba(120,100,70,0.3)';
                    ctx.fillRect(cx - 22, cy + 12, 2, 2);
                    ctx.fillRect(cx + 20, cy + 12, 2, 2);
                    ctx.fillRect(cx - 18, cy + 10, 1, 2);
                    ctx.fillRect(cx + 17, cy + 10, 1, 2);
                }
                
            } else if (dir === 2) { // === UP — back view ===
                // Simplified — same torso, arms vary by frame
                ctx.fillStyle = '#4a3322';
                ctx.fillRect(cx - 7, cy + 10, 5, 8);
                ctx.fillRect(cx + 2, cy + 10, 5, 8);
                ctx.fillStyle = '#4a2e20';
                ctx.fillRect(cx - 10, cy - 4, 20, 16);
                ctx.fillStyle = '#3a2015';
                ctx.fillRect(cx - 1, cy - 3, 2, 14);
                
                if (frame === 0) {
                    // Arms up behind head
                    ctx.fillStyle = '#5a3a28';
                    ctx.fillRect(cx - 16, cy - 18, 6, 14);
                    ctx.fillRect(cx + 10, cy - 18, 6, 14);
                    ctx.fillRect(cx - 11, cy - 14, 4, 10);
                    ctx.fillRect(cx + 7, cy - 14, 4, 10);
                } else if (frame === 1) {
                    ctx.fillStyle = '#5a3a28';
                    ctx.fillRect(cx - 16, cy - 8, 7, 10);
                    ctx.fillRect(cx + 9, cy - 8, 7, 10);
                    ctx.fillRect(cx - 12, cy - 4, 4, 8);
                    ctx.fillRect(cx + 8, cy - 4, 4, 8);
                } else {
                    ctx.fillStyle = '#5a3a28';
                    ctx.fillRect(cx - 16, cy + 2, 8, 8);
                    ctx.fillRect(cx + 8, cy + 2, 8, 8);
                    ctx.fillRect(cx - 12, cy + 4, 5, 6);
                    ctx.fillRect(cx + 7, cy + 4, 5, 6);
                }
                ctx.fillStyle = '#4a2a1a';
                ctx.fillRect(cx - 5, cy - 10, 10, 8);
                
            } else { // === SIDE ===
                const flip = dir === 3 ? -1 : 1;
                ctx.fillStyle = '#4a3322';
                ctx.fillRect(cx - 2, cy + 10, 4, 8);
                ctx.fillStyle = '#4a2e20';
                ctx.fillRect(cx - 7, cy - 4, 14, 16);
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 6 * flip, cy - 3, 3, 14);
                
                if (frame === 0) {
                    // Arms raised — near arm shows full profile UP
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx + 6 * flip, cy - 18, 5 * flip, 14);
                    ctx.fillRect(cx + 3 * flip, cy - 14, 3 * flip, 10);
                    ctx.fillStyle = '#4a2e20';
                    ctx.fillRect(cx - 7 * flip, cy - 16, 3, 12);
                } else if (frame === 1) {
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx + 6 * flip, cy - 8, 6 * flip, 10);
                    ctx.fillRect(cx + 3 * flip, cy - 4, 4 * flip, 8);
                    ctx.fillStyle = '#4a2e20';
                    ctx.fillRect(cx - 7 * flip, cy - 6, 3, 10);
                } else {
                    ctx.fillStyle = '#5a3828';
                    ctx.fillRect(cx + 5 * flip, cy + 2, 8 * flip, 8);
                    ctx.fillRect(cx + 3 * flip, cy + 4, 5 * flip, 6);
                    ctx.fillStyle = '#4a2a1a';
                    ctx.fillRect(cx + 8 * flip, cy + 9, 4 * flip, 5);
                    ctx.fillRect(cx + 4 * flip, cy + 9, 3 * flip, 4);
                    ctx.fillStyle = '#4a2e20';
                    ctx.fillRect(cx - 7 * flip, cy + 3, 3, 8);
                    // Ground crack
                    ctx.fillStyle = 'rgba(60,40,20,0.4)';
                    ctx.fillRect(cx + 5 * flip, cy + 14, 12 * flip, 1);
                }
                
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 1 + 2 * flip, cy - 10, 7, 7);
                ctx.fillStyle = '#1a0a05';
                ctx.fillRect(cx + 3 * flip, cy - 8, 2, 2);
                ctx.fillStyle = frame >= 1 ? '#cc4422' : '#884422';
                ctx.fillRect(cx + 3 * flip, cy - 7, 1, 1);
            }
        },
        // Down: small oval body, 6 spindly legs splayed out, two pincers at front, beady eyes
        // Up: chitinous back plate with ridges, legs from behind
        // Side: low flat profile, legs on near side layered, far side partial
        skitterling(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const legA = frame === 0 ? 0 : frame === 1 ? 1 : -1;
            
            // Tiny shadow
            ctx.fillStyle = 'rgba(0,0,0,0.25)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 4, 5, 2, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // === DOWN — top-ish view, legs splayed ===
                // Legs — 3 pairs, spindly, animated
                ctx.fillStyle = '#4a3a22';
                // Back pair
                ctx.fillRect(cx - 6 - legA, cy + 1, 4, 1);
                ctx.fillRect(cx + 2 + legA, cy + 1, 4, 1);
                // Mid pair
                ctx.fillRect(cx - 7 + legA, cy - 1, 5, 1);
                ctx.fillRect(cx + 2 - legA, cy - 1, 5, 1);
                // Front pair
                ctx.fillRect(cx - 6 - legA, cy - 3, 4, 1);
                ctx.fillRect(cx + 2 + legA, cy - 3, 4, 1);
                // Leg tips (tiny feet)
                ctx.fillStyle = '#3a2a15';
                ctx.fillRect(cx - 7 - legA, cy + 1, 1, 1);
                ctx.fillRect(cx + 6 + legA, cy + 1, 1, 1);
                ctx.fillRect(cx - 8 + legA, cy - 1, 1, 1);
                ctx.fillRect(cx + 7 - legA, cy - 1, 1, 1);
                
                // Body — oval chitinous
                ctx.fillStyle = '#5a4422';
                ctx.fillRect(cx - 4, cy - 3, 8, 7);
                ctx.fillStyle = '#6a5433';
                ctx.fillRect(cx - 3, cy - 2, 6, 5);
                // Chitin plate ridges
                ctx.fillStyle = '#4a3818';
                ctx.fillRect(cx - 3, cy - 1, 6, 1);
                ctx.fillRect(cx - 2, cy + 1, 4, 1);
                // Head
                ctx.fillStyle = '#5a4422';
                ctx.fillRect(cx - 2, cy - 5, 4, 3);
                // Beady eyes
                ctx.fillStyle = '#aa6622';
                ctx.fillRect(cx - 2, cy - 5, 1, 1);
                ctx.fillRect(cx + 1, cy - 5, 1, 1);
                // Pincers
                ctx.fillStyle = '#3a2a15';
                ctx.fillRect(cx - 3, cy - 6, 1, 2);
                ctx.fillRect(cx + 2, cy - 6, 1, 2);
                
            } else if (dir === 2) { // === UP — back view ===
                ctx.fillStyle = '#4a3a22';
                ctx.fillRect(cx - 6, cy + 1, 4, 1); ctx.fillRect(cx + 2, cy + 1, 4, 1);
                ctx.fillRect(cx - 7, cy - 1, 5, 1); ctx.fillRect(cx + 2, cy - 1, 5, 1);
                ctx.fillRect(cx - 6, cy - 3, 4, 1); ctx.fillRect(cx + 2, cy - 3, 4, 1);
                // Back plate
                ctx.fillStyle = '#4a3818';
                ctx.fillRect(cx - 4, cy - 3, 8, 7);
                ctx.fillStyle = '#5a4422';
                ctx.fillRect(cx - 3, cy - 2, 6, 5);
                // Ridges more prominent from behind
                ctx.fillStyle = '#3a2a12';
                ctx.fillRect(cx - 1, cy - 2, 2, 5);
                ctx.fillRect(cx - 3, cy, 6, 1);
                // Back of head
                ctx.fillStyle = '#4a3818';
                ctx.fillRect(cx - 2, cy - 5, 4, 3);
                
            } else { // === SIDE ===
                const flip = dir === 3 ? -1 : 1;
                // Near legs (3)
                ctx.fillStyle = '#4a3a22';
                ctx.fillRect(cx + 2 * flip - legA, cy + 2, 3, 1);
                ctx.fillRect(cx + 3 * flip + legA, cy, 3, 1);
                ctx.fillRect(cx + 2 * flip - legA, cy - 2, 3, 1);
                // Far legs (partial)
                ctx.fillStyle = '#3a2a18';
                ctx.fillRect(cx - 3 * flip, cy + 1, 2, 1);
                ctx.fillRect(cx - 4 * flip, cy - 1, 2, 1);
                // Low flat body from side
                ctx.fillStyle = '#5a4422';
                ctx.fillRect(cx - 3, cy - 2, 7, 4);
                ctx.fillStyle = '#6a5433';
                ctx.fillRect(cx - 2, cy - 1, 5, 2);
                // Chitin ridge
                ctx.fillStyle = '#4a3818';
                ctx.fillRect(cx - 2, cy - 2, 5, 1);
                // Head
                ctx.fillStyle = '#5a4422';
                ctx.fillRect(cx + 3 * flip, cy - 3, 2, 3);
                // Eye
                ctx.fillStyle = '#aa6622';
                ctx.fillRect(cx + 4 * flip, cy - 3, 1, 1);
                // Pincer
                ctx.fillStyle = '#3a2a15';
                ctx.fillRect(cx + 5 * flip, cy - 2, 1, 2);
            }
        },
        
        // ¾ CAMERA RULE: Camera above + south. DOWN=front face wide. UP=back. RIGHT/LEFT=depth face dominant, front is narrow sliver.
        // Reaper: Towering fleshy knight in scrap armor (car parts, road signs, rebar). One elongated arm with massive scrap axe. 64px canvas.
        // dir: 0=down, 1=right, 2=up, 3=left
        reaper(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const bob = frame === 1 ? -1 : 0;
            const legL = frame === 1 ? 1 : frame === 2 ? -1 : 0;
            const armSwing = frame === 1 ? -2 : frame === 2 ? 2 : 0;
            const axeSwing = frame === 1 ? 1 : frame === 2 ? -1 : 0;
            
            // Shadow — large, towering enemy
            ctx.fillStyle = 'rgba(0,0,0,0.35)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 21, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // === DOWN — front face wide, player sees chest ===
                // Legs — flesh with makeshift greaves (license plate strips)
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 7 + legL, cy + 9 + bob, 6, 10); // left thigh
                ctx.fillRect(cx + 1 - legL, cy + 9 + bob, 6, 10); // right thigh
                ctx.fillStyle = '#6a6a6a'; // metal greave plates
                ctx.fillRect(cx - 7 + legL, cy + 11 + bob, 6, 5);
                ctx.fillRect(cx + 1 - legL, cy + 11 + bob, 6, 5);
                ctx.fillStyle = '#7a7a7a'; // greave highlight
                ctx.fillRect(cx - 6 + legL, cy + 11 + bob, 4, 2);
                ctx.fillRect(cx + 2 - legL, cy + 11 + bob, 4, 2);
                ctx.fillStyle = '#555555'; // rivets on greaves
                ctx.fillRect(cx - 5 + legL, cy + 13 + bob, 1, 1);
                ctx.fillRect(cx - 3 + legL, cy + 14 + bob, 1, 1);
                ctx.fillRect(cx + 3 - legL, cy + 13 + bob, 1, 1);
                ctx.fillRect(cx + 5 - legL, cy + 14 + bob, 1, 1);
                // Knee joints — exposed flesh/tendon
                ctx.fillStyle = '#6a4030';
                ctx.fillRect(cx - 6 + legL, cy + 16 + bob, 4, 2);
                ctx.fillRect(cx + 2 - legL, cy + 16 + bob, 4, 2);
                // Feet — scrap boots
                ctx.fillStyle = '#4a4a4a';
                ctx.fillRect(cx - 8 + legL, cy + 18 + bob, 7, 3);
                ctx.fillRect(cx + 1 - legL, cy + 18 + bob, 7, 3);
                ctx.fillStyle = '#3a3a3a'; // boot sole
                ctx.fillRect(cx - 8 + legL, cy + 20 + bob, 7, 1);
                ctx.fillRect(cx + 1 - legL, cy + 20 + bob, 7, 1);
                
                // Torso — dented car hood chestplate over raw flesh
                ctx.fillStyle = '#5a3a28'; // flesh base visible at edges
                ctx.fillRect(cx - 10, cy - 7 + bob, 20, 17);
                ctx.fillStyle = '#6a4030'; // exposed muscle at sides
                ctx.fillRect(cx - 10, cy - 2 + bob, 2, 8);
                ctx.fillRect(cx + 8, cy - 2 + bob, 2, 8);
                ctx.fillStyle = '#7a7a7a'; // main chest plate
                ctx.fillRect(cx - 8, cy - 6 + bob, 16, 14);
                ctx.fillStyle = '#8a8a8a'; // plate highlight band
                ctx.fillRect(cx - 7, cy - 5 + bob, 14, 3);
                ctx.fillStyle = '#606060'; // dent lines (impact damage)
                ctx.fillRect(cx - 6, cy - 2 + bob, 12, 1);
                ctx.fillRect(cx - 3, cy + 1 + bob, 8, 1);
                ctx.fillRect(cx - 5, cy + 4 + bob, 4, 1);
                ctx.fillStyle = '#555555'; // corner rivets
                ctx.fillRect(cx - 7, cy - 4 + bob, 1, 1);
                ctx.fillRect(cx + 6, cy - 4 + bob, 1, 1);
                ctx.fillRect(cx - 7, cy + 5 + bob, 1, 1);
                ctx.fillRect(cx + 6, cy + 5 + bob, 1, 1);
                ctx.fillStyle = '#bb3300'; // rust streaks
                ctx.fillRect(cx - 4, cy - 3 + bob, 2, 1);
                ctx.fillRect(cx + 3, cy + 2 + bob, 3, 1);
                // Belly gap — exposed flesh between plates
                ctx.fillStyle = '#6a4030';
                ctx.fillRect(cx - 5, cy + 7 + bob, 10, 3);
                ctx.fillStyle = '#7a4838'; // stretch marks/scars
                ctx.fillRect(cx - 3, cy + 8 + bob, 1, 1);
                ctx.fillRect(cx + 1, cy + 7 + bob, 1, 1);
                ctx.fillRect(cx + 3, cy + 8 + bob, 1, 1);
                // Hanging chain belt
                ctx.fillStyle = '#888888';
                ctx.fillRect(cx - 6, cy + 6 + bob, 12, 1);
                ctx.fillStyle = '#777777';
                ctx.fillRect(cx - 3, cy + 7 + bob, 1, 2);
                ctx.fillRect(cx + 2, cy + 7 + bob, 1, 3);
                
                // Shoulder pauldrons — crushed car panels, bolted on
                ctx.fillStyle = '#888888'; // left pauldron
                ctx.fillRect(cx - 14, cy - 8 + bob, 7, 6);
                ctx.fillStyle = '#999999';
                ctx.fillRect(cx - 13, cy - 7 + bob, 5, 4);
                ctx.fillStyle = '#666666'; // shadow edge
                ctx.fillRect(cx - 14, cy - 3 + bob, 7, 1);
                ctx.fillStyle = '#555555'; // bolts
                ctx.fillRect(cx - 12, cy - 6 + bob, 1, 1);
                ctx.fillRect(cx - 10, cy - 5 + bob, 1, 1);
                ctx.fillStyle = '#888888'; // right pauldron
                ctx.fillRect(cx + 7, cy - 8 + bob, 7, 6);
                ctx.fillStyle = '#999999';
                ctx.fillRect(cx + 8, cy - 7 + bob, 5, 4);
                ctx.fillStyle = '#666666';
                ctx.fillRect(cx + 7, cy - 3 + bob, 7, 1);
                ctx.fillStyle = '#555555';
                ctx.fillRect(cx + 9, cy - 6 + bob, 1, 1);
                ctx.fillStyle = '#bb3300'; // rust on right pauldron
                ctx.fillRect(cx + 11, cy - 5 + bob, 2, 1);
                // Rebar spikes jutting from pauldrons
                ctx.fillStyle = '#4a4a4a';
                ctx.fillRect(cx - 14, cy - 10 + bob, 2, 3); // left spike
                ctx.fillRect(cx + 12, cy - 10 + bob, 2, 3); // right spike
                ctx.fillStyle = '#5a5a5a';
                ctx.fillRect(cx - 13, cy - 10 + bob, 1, 2);
                ctx.fillRect(cx + 12, cy - 10 + bob, 1, 2);
                
                // Left arm (normal, gauntleted)
                ctx.fillStyle = '#5a3a28'; // upper arm flesh
                ctx.fillRect(cx - 14, cy - 2 + bob + armSwing, 5, 7);
                ctx.fillStyle = '#707070'; // forearm gauntlet
                ctx.fillRect(cx - 14, cy + 4 + bob + armSwing, 5, 5);
                ctx.fillStyle = '#7a7a7a';
                ctx.fillRect(cx - 13, cy + 5 + bob + armSwing, 3, 3);
                ctx.fillStyle = '#5a5a5a'; // fist
                ctx.fillRect(cx - 13, cy + 8 + bob + armSwing, 4, 3);
                
                // Right arm (ELONGATED — grotesquely long, extends well past knee)
                ctx.fillStyle = '#5a3a28'; // upper arm
                ctx.fillRect(cx + 9, cy - 2 + bob - armSwing, 5, 8);
                ctx.fillStyle = '#6a4030'; // swollen elbow joint
                ctx.fillRect(cx + 8, cy + 4 + bob - armSwing, 7, 3);
                ctx.fillStyle = '#6a4030'; // lower arm — thicker, veiny
                ctx.fillRect(cx + 9, cy + 5 + bob - armSwing, 5, 10);
                ctx.fillStyle = '#7a4838'; // vein ridges
                ctx.fillRect(cx + 10, cy + 7 + bob - armSwing, 1, 5);
                ctx.fillRect(cx + 12, cy + 6 + bob - armSwing, 1, 4);
                ctx.fillStyle = '#8a5040'; // raised tendon
                ctx.fillRect(cx + 11, cy + 9 + bob - armSwing, 1, 3);
                ctx.fillStyle = '#555555'; // wrist wrap
                ctx.fillRect(cx + 9, cy + 14 + bob - armSwing, 5, 2);
                ctx.fillStyle = '#4a4a4a'; // wrap detail
                ctx.fillRect(cx + 10, cy + 15 + bob - armSwing, 3, 1);
                
                // AXE — massive scrap blade, welded rebar handle
                ctx.fillStyle = '#5a5a5a'; // handle (rebar)
                ctx.fillRect(cx + 10, cy + 4 + bob + axeSwing, 2, 18);
                ctx.fillStyle = '#4a4a4a'; // handle grip wrap
                ctx.fillRect(cx + 10, cy + 10 + bob + axeSwing, 2, 3);
                ctx.fillStyle = '#3a3a3a'; // wire spiral on handle
                ctx.fillRect(cx + 10, cy + 7 + bob + axeSwing, 1, 1);
                ctx.fillRect(cx + 11, cy + 8 + bob + axeSwing, 1, 1);
                ctx.fillRect(cx + 10, cy + 13 + bob + axeSwing, 1, 1);
                ctx.fillRect(cx + 11, cy + 14 + bob + axeSwing, 1, 1);
                ctx.fillStyle = '#999999'; // axe head — wide blade
                ctx.fillRect(cx + 12, cy + 2 + bob + axeSwing, 9, 5);
                ctx.fillRect(cx + 12, cy + 7 + bob + axeSwing, 8, 3);
                ctx.fillStyle = '#aaaaaa'; // cutting edge highlight
                ctx.fillRect(cx + 19, cy + 2 + bob + axeSwing, 2, 5);
                ctx.fillStyle = '#bbbbbb'; // edge gleam
                ctx.fillRect(cx + 20, cy + 3 + bob + axeSwing, 1, 3);
                ctx.fillStyle = '#777777'; // blade spine/back
                ctx.fillRect(cx + 12, cy + 4 + bob + axeSwing, 1, 6);
                // Notched edge (battle damage)
                ctx.fillStyle = '#777777';
                ctx.fillRect(cx + 20, cy + 5 + bob + axeSwing, 1, 1);
                ctx.fillRect(cx + 19, cy + 1 + bob + axeSwing, 1, 1);
                ctx.fillStyle = '#bb3300'; // rust patches on blade
                ctx.fillRect(cx + 14, cy + 3 + bob + axeSwing, 2, 1);
                ctx.fillRect(cx + 16, cy + 7 + bob + axeSwing, 2, 1);
                ctx.fillStyle = '#993300'; // deep rust
                ctx.fillRect(cx + 15, cy + 5 + bob + axeSwing, 1, 1);
                
                // Head — crude scrap helm (road sign bent into shape)
                ctx.fillStyle = '#6a6a6a'; // helm base
                ctx.fillRect(cx - 6, cy - 16 + bob, 12, 10);
                ctx.fillStyle = '#7a7a7a'; // helm front plate
                ctx.fillRect(cx - 5, cy - 15 + bob, 10, 8);
                ctx.fillStyle = '#8a8a8a'; // forehead highlight
                ctx.fillRect(cx - 4, cy - 15 + bob, 8, 3);
                ctx.fillStyle = '#555555'; // visor slit — dark
                ctx.fillRect(cx - 4, cy - 11 + bob, 8, 2);
                ctx.fillStyle = '#aa4400'; // smoldering glow spill above visor
                ctx.fillRect(cx - 3, cy - 12 + bob, 6, 1);
                ctx.fillStyle = '#cc6600'; // eye glow behind visor
                ctx.fillRect(cx - 3, cy - 11 + bob, 2, 1);
                ctx.fillRect(cx + 1, cy - 11 + bob, 2, 1);
                ctx.fillStyle = '#ff8800'; // bright eye center
                ctx.fillRect(cx - 2, cy - 11 + bob, 1, 1);
                ctx.fillRect(cx + 2, cy - 11 + bob, 1, 1);
                ctx.fillStyle = '#ffaa22'; // eye flicker (frame-dependent)
                if (frame === 1) ctx.fillRect(cx - 2, cy - 10 + bob, 1, 1);
                if (frame === 2) ctx.fillRect(cx + 2, cy - 10 + bob, 1, 1);
                ctx.fillStyle = '#4a4a4a'; // chin guard
                ctx.fillRect(cx - 4, cy - 7 + bob, 8, 2);
                ctx.fillStyle = '#3a3a3a'; // chin shadow
                ctx.fillRect(cx - 3, cy - 6 + bob, 6, 1);
                // Helm crest — welded fin
                ctx.fillStyle = '#999999';
                ctx.fillRect(cx - 1, cy - 18 + bob, 2, 4);
                ctx.fillStyle = '#aaaaaa';
                ctx.fillRect(cx, cy - 19 + bob, 1, 2);
                // Helm damage — dent + scratches
                ctx.fillStyle = '#555555';
                ctx.fillRect(cx + 2, cy - 14 + bob, 1, 3);
                ctx.fillRect(cx - 4, cy - 13 + bob, 1, 2); // second scratch
                ctx.fillStyle = '#606060'; // dent shadow
                ctx.fillRect(cx + 3, cy - 13 + bob, 2, 1);
                
            } else if (dir === 1) { // === RIGHT — side view, depth face dominant ===
                // Near leg (right)
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 1 + legL, cy + 9 + bob, 5, 10);
                ctx.fillStyle = '#6a6a6a';
                ctx.fillRect(cx - 1 + legL, cy + 11 + bob, 5, 4);
                ctx.fillStyle = '#4a4a4a';
                ctx.fillRect(cx - 2 + legL, cy + 18 + bob, 6, 3);
                // Far leg (partial behind body)
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx - 3 - legL, cy + 10 + bob, 3, 9);
                ctx.fillStyle = '#5a5a5a';
                ctx.fillRect(cx - 3 - legL, cy + 12 + bob, 3, 3);
                
                // Torso side — depth face wide (thick body)
                ctx.fillStyle = '#5a3a28'; // flesh
                ctx.fillRect(cx - 6, cy - 7 + bob, 12, 17);
                ctx.fillStyle = '#7a7a7a'; // side armor plate
                ctx.fillRect(cx - 5, cy - 6 + bob, 10, 14);
                ctx.fillStyle = '#606060'; // dent/seam
                ctx.fillRect(cx - 3, cy - 1 + bob, 6, 1);
                ctx.fillRect(cx - 2, cy + 3 + bob, 4, 1);
                ctx.fillStyle = '#555555'; // rivets
                ctx.fillRect(cx - 4, cy - 4 + bob, 1, 1);
                ctx.fillRect(cx + 3, cy + 5 + bob, 1, 1);
                // Front sliver — narrow compressed facing edge
                ctx.fillStyle = '#888888';
                ctx.fillRect(cx + 6, cy - 5 + bob, 2, 13);
                ctx.fillStyle = '#999999';
                ctx.fillRect(cx + 6, cy - 4 + bob, 1, 4);
                // Flesh gap
                ctx.fillStyle = '#6a4030';
                ctx.fillRect(cx - 1, cy + 7 + bob, 6, 2);
                
                // Pauldron — near side prominent
                ctx.fillStyle = '#888888';
                ctx.fillRect(cx - 4, cy - 9 + bob, 10, 5);
                ctx.fillStyle = '#999999';
                ctx.fillRect(cx - 3, cy - 8 + bob, 8, 3);
                ctx.fillStyle = '#666666';
                ctx.fillRect(cx - 4, cy - 5 + bob, 10, 1);
                
                // Elongated arm (RIGHT arm near when facing right) + AXE
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 4, cy - 2 + bob - armSwing, 5, 8);
                ctx.fillStyle = '#6a4030';
                ctx.fillRect(cx + 4, cy + 5 + bob - armSwing, 5, 10);
                ctx.fillStyle = '#7a4838'; // veins
                ctx.fillRect(cx + 5, cy + 7 + bob - armSwing, 1, 4);
                ctx.fillStyle = '#555555'; // wrist
                ctx.fillRect(cx + 4, cy + 14 + bob - armSwing, 5, 2);
                // Axe — FLAT FACE visible (wide blade from side)
                ctx.fillStyle = '#5a5a5a'; // handle
                ctx.fillRect(cx + 5, cy + 5 + bob + axeSwing, 2, 16);
                ctx.fillStyle = '#999999'; // blade flat face
                ctx.fillRect(cx + 7, cy + 2 + bob + axeSwing, 7, 8);
                ctx.fillStyle = '#aaaaaa'; // edge
                ctx.fillRect(cx + 12, cy + 2 + bob + axeSwing, 2, 8);
                ctx.fillStyle = '#777777'; // spine
                ctx.fillRect(cx + 7, cy + 5 + bob + axeSwing, 1, 5);
                ctx.fillStyle = '#bb3300'; // rust
                ctx.fillRect(cx + 9, cy + 4 + bob + axeSwing, 2, 1);
                
                // Short arm far side (behind body, partial)
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx - 7, cy + 0 + bob + armSwing, 3, 7);
                ctx.fillStyle = '#606060';
                ctx.fillRect(cx - 7, cy + 2 + bob + armSwing, 3, 4);
                
                // Head side
                ctx.fillStyle = '#6a6a6a';
                ctx.fillRect(cx - 4, cy - 16 + bob, 9, 10);
                ctx.fillStyle = '#7a7a7a';
                ctx.fillRect(cx - 3, cy - 15 + bob, 7, 8);
                ctx.fillStyle = '#555555'; // visor from side
                ctx.fillRect(cx + 2, cy - 11 + bob, 3, 2);
                ctx.fillStyle = '#cc6600'; // eye glow
                ctx.fillRect(cx + 3, cy - 11 + bob, 1, 1);
                ctx.fillStyle = '#999999'; // crest
                ctx.fillRect(cx, cy - 18 + bob, 2, 4);
                ctx.fillStyle = '#4a4a4a'; // chin
                ctx.fillRect(cx - 2, cy - 7 + bob, 6, 2);
                
            } else if (dir === 2) { // === UP — back view ===
                // Legs from behind
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 7 + legL, cy + 9 + bob, 6, 10);
                ctx.fillRect(cx + 1 - legL, cy + 9 + bob, 6, 10);
                ctx.fillStyle = '#606060'; // back of greaves
                ctx.fillRect(cx - 7 + legL, cy + 11 + bob, 6, 4);
                ctx.fillRect(cx + 1 - legL, cy + 11 + bob, 6, 4);
                ctx.fillStyle = '#4a4a4a';
                ctx.fillRect(cx - 8 + legL, cy + 18 + bob, 7, 3);
                ctx.fillRect(cx + 1 - legL, cy + 18 + bob, 7, 3);
                
                // Torso back — welded plate with seams
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 10, cy - 7 + bob, 20, 17);
                ctx.fillStyle = '#6a6a6a'; // back plate
                ctx.fillRect(cx - 8, cy - 5 + bob, 16, 13);
                ctx.fillStyle = '#555555'; // center weld seam
                ctx.fillRect(cx, cy - 4 + bob, 1, 11);
                ctx.fillStyle = '#555555'; // cross seam
                ctx.fillRect(cx - 6, cy + 0 + bob, 12, 1);
                ctx.fillStyle = '#606060'; // plate overlap shadow
                ctx.fillRect(cx - 6, cy + 4 + bob, 12, 1);
                // Hanging chain scraps from belt
                ctx.fillStyle = '#888888';
                ctx.fillRect(cx - 4, cy + 8 + bob, 1, 4);
                ctx.fillRect(cx + 3, cy + 8 + bob, 1, 5);
                ctx.fillRect(cx, cy + 9 + bob, 1, 3);
                // Scratch marks on back plate
                ctx.fillStyle = '#555555';
                ctx.fillRect(cx - 5, cy - 3 + bob, 1, 4);
                ctx.fillRect(cx + 4, cy - 2 + bob, 1, 3);
                
                // Pauldrons from behind
                ctx.fillStyle = '#7a7a7a';
                ctx.fillRect(cx - 14, cy - 8 + bob, 7, 6);
                ctx.fillRect(cx + 7, cy - 8 + bob, 7, 6);
                ctx.fillStyle = '#666666';
                ctx.fillRect(cx - 14, cy - 3 + bob, 7, 1);
                ctx.fillRect(cx + 7, cy - 3 + bob, 7, 1);
                
                // Arms from behind (reversed layering)
                ctx.fillStyle = '#5a3a28'; // left (short)
                ctx.fillRect(cx - 14, cy - 2 + bob + armSwing, 5, 9);
                ctx.fillStyle = '#606060';
                ctx.fillRect(cx - 14, cy + 2 + bob + armSwing, 5, 4);
                ctx.fillStyle = '#5a3a28'; // right (long)
                ctx.fillRect(cx + 9, cy - 2 + bob - armSwing, 5, 16);
                ctx.fillStyle = '#555555'; // wrist
                ctx.fillRect(cx + 9, cy + 12 + bob - armSwing, 5, 2);
                // Axe handle + partial head from behind
                ctx.fillStyle = '#5a5a5a';
                ctx.fillRect(cx + 10, cy + 4 + bob + axeSwing, 2, 14);
                ctx.fillStyle = '#888888'; // axe head edge (thin from behind)
                ctx.fillRect(cx + 12, cy + 3 + bob + axeSwing, 7, 2);
                
                // Helm from behind
                ctx.fillStyle = '#5a5a5a';
                ctx.fillRect(cx - 6, cy - 16 + bob, 12, 10);
                ctx.fillStyle = '#6a6a6a';
                ctx.fillRect(cx - 5, cy - 15 + bob, 10, 8);
                ctx.fillStyle = '#999999'; // crest
                ctx.fillRect(cx - 1, cy - 18 + bob, 2, 4);
                // Neck gap
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 3, cy - 7 + bob, 6, 2);
                
            } else { // === LEFT — mirror of right ===
                // Near leg (left)
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 4 + legL, cy + 9 + bob, 5, 10);
                ctx.fillStyle = '#6a6a6a';
                ctx.fillRect(cx - 4 + legL, cy + 11 + bob, 5, 4);
                ctx.fillStyle = '#4a4a4a';
                ctx.fillRect(cx - 4 + legL, cy + 18 + bob, 6, 3);
                // Far leg
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx + 1 - legL, cy + 10 + bob, 3, 9);
                ctx.fillStyle = '#5a5a5a';
                ctx.fillRect(cx + 1 - legL, cy + 12 + bob, 3, 3);
                
                // Torso side
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 6, cy - 7 + bob, 12, 17);
                ctx.fillStyle = '#7a7a7a';
                ctx.fillRect(cx - 5, cy - 6 + bob, 10, 14);
                ctx.fillStyle = '#606060';
                ctx.fillRect(cx - 3, cy - 1 + bob, 6, 1);
                // Front sliver — recedes RIGHT
                ctx.fillStyle = '#888888';
                ctx.fillRect(cx - 8, cy - 5 + bob, 2, 13);
                // Flesh gap
                ctx.fillStyle = '#6a4030';
                ctx.fillRect(cx - 5, cy + 7 + bob, 6, 2);
                
                // Pauldron
                ctx.fillStyle = '#888888';
                ctx.fillRect(cx - 6, cy - 9 + bob, 10, 5);
                ctx.fillStyle = '#999999';
                ctx.fillRect(cx - 5, cy - 8 + bob, 8, 3);
                ctx.fillStyle = '#666666';
                ctx.fillRect(cx - 6, cy - 5 + bob, 10, 1);
                
                // Short arm near side (LEFT arm)
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 9, cy - 2 + bob + armSwing, 5, 8);
                ctx.fillStyle = '#707070';
                ctx.fillRect(cx - 9, cy + 4 + bob + armSwing, 5, 5);
                ctx.fillStyle = '#5a5a5a';
                ctx.fillRect(cx - 9, cy + 8 + bob + armSwing, 5, 3);
                
                // Elongated arm far side + axe EDGE only (thin line)
                ctx.fillStyle = '#4a2e1e';
                ctx.fillRect(cx + 4, cy + 0 + bob - armSwing, 3, 14);
                ctx.fillStyle = '#999999'; // axe edge (1px thin)
                ctx.fillRect(cx + 5, cy + 3 + bob + axeSwing, 1, 12);
                
                // Head side — facing left
                ctx.fillStyle = '#6a6a6a';
                ctx.fillRect(cx - 5, cy - 16 + bob, 9, 10);
                ctx.fillStyle = '#7a7a7a';
                ctx.fillRect(cx - 4, cy - 15 + bob, 7, 8);
                ctx.fillStyle = '#555555';
                ctx.fillRect(cx - 5, cy - 11 + bob, 3, 2);
                ctx.fillStyle = '#cc6600';
                ctx.fillRect(cx - 4, cy - 11 + bob, 1, 1);
                ctx.fillStyle = '#999999';
                ctx.fillRect(cx - 2, cy - 18 + bob, 2, 4);
                ctx.fillStyle = '#4a4a4a';
                ctx.fillRect(cx - 4, cy - 7 + bob, 6, 2);
            }
        },
        
        // Reaper SLASH — 3 frames: windup (axe raised overhead), swing (axe sweeping forward), follow-through (axe low)
        reaper_slash(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            // Shadow
            ctx.fillStyle = 'rgba(0,0,0,0.35)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 21, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // DOWN
                // Legs — planted stance, wider
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 8, cy + 9, 6, 11); ctx.fillRect(cx + 2, cy + 9, 6, 11);
                ctx.fillStyle = '#6a6a6a';
                ctx.fillRect(cx - 8, cy + 11, 6, 4); ctx.fillRect(cx + 2, cy + 11, 6, 4);
                ctx.fillStyle = '#4a4a4a';
                ctx.fillRect(cx - 9, cy + 19, 7, 2); ctx.fillRect(cx + 2, cy + 19, 7, 2);
                // Torso
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 10, cy - 7, 20, 17);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 8, cy - 6, 16, 14);
                ctx.fillStyle = '#8a8a8a'; ctx.fillRect(cx - 7, cy - 5, 14, 3);
                ctx.fillStyle = '#606060'; ctx.fillRect(cx - 6, cy - 2, 12, 1);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx - 7, cy - 4, 1, 1); ctx.fillRect(cx + 6, cy - 4, 1, 1);
                ctx.fillStyle = '#6a4030'; ctx.fillRect(cx - 5, cy + 7, 10, 3);
                // Pauldrons
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 14, cy - 8, 7, 6); ctx.fillRect(cx + 7, cy - 8, 7, 6);
                // Left arm (short, guarding)
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 14, cy - 2, 5, 10);
                ctx.fillStyle = '#707070'; ctx.fillRect(cx - 14, cy + 3, 5, 5);
                
                if (frame === 0) { // WINDUP — axe raised high above head
                    ctx.fillStyle = '#5a3a28'; // right arm reaching up
                    ctx.fillRect(cx + 9, cy - 2, 5, 6);
                    ctx.fillStyle = '#6a4030';
                    ctx.fillRect(cx + 6, cy - 12, 5, 12);
                    ctx.fillStyle = '#5a5a5a'; // handle going up
                    ctx.fillRect(cx + 7, cy - 18, 2, 14);
                    ctx.fillStyle = '#999999'; // axe head above helm
                    ctx.fillRect(cx - 2, cy - 22, 9, 5);
                    ctx.fillRect(cx - 1, cy - 18, 8, 3);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx - 2, cy - 21, 2, 4);
                    ctx.fillStyle = '#bb3300'; ctx.fillRect(cx + 3, cy - 20, 2, 1);
                } else if (frame === 1) { // MID-SWING — axe sweeping forward-right
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy - 2, 5, 8);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 9, cy + 3, 5, 6);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy - 2, 2, 12);
                    ctx.fillStyle = '#999999'; // axe head mid-sweep
                    ctx.fillRect(cx + 12, cy - 4, 10, 6);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 20, cy - 4, 2, 6);
                    ctx.fillStyle = '#bbbbbb'; ctx.fillRect(cx + 21, cy - 2, 1, 3);
                    ctx.fillStyle = '#bb3300'; ctx.fillRect(cx + 15, cy - 2, 2, 1);
                    // Motion lines
                    ctx.fillStyle = 'rgba(204,136,68,0.3)';
                    ctx.fillRect(cx + 10, cy - 8, 8, 1); ctx.fillRect(cx + 12, cy - 6, 6, 1);
                } else { // FOLLOW-THROUGH — axe low, swept past
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy - 1, 5, 10);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 9, cy + 7, 5, 8);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy + 6, 2, 14);
                    ctx.fillStyle = '#999999'; // axe head low
                    ctx.fillRect(cx + 12, cy + 10, 9, 5);
                    ctx.fillRect(cx + 12, cy + 14, 8, 3);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 19, cy + 10, 2, 5);
                    ctx.fillStyle = '#bb3300'; ctx.fillRect(cx + 14, cy + 12, 2, 1);
                }
                // Head (same for all frames)
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 6, cy - 16, 12, 10);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 5, cy - 15, 10, 8);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx - 4, cy - 11, 8, 2);
                ctx.fillStyle = '#cc6600'; ctx.fillRect(cx - 3, cy - 11, 2, 1); ctx.fillRect(cx + 1, cy - 11, 2, 1);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 1, cy - 18, 2, 4);
            } else if (dir === 1) { // RIGHT
                // Legs
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 1, cy + 9, 5, 11); ctx.fillRect(cx - 4, cy + 10, 3, 10);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 1, cy + 11, 5, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 2, cy + 19, 6, 2);
                // Torso
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 6, cy - 7, 12, 17);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 5, cy - 6, 10, 14);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx + 6, cy - 5, 2, 13);
                // Pauldron
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 4, cy - 9, 10, 5);
                // Short arm far side
                ctx.fillStyle = '#4a2e1e'; ctx.fillRect(cx - 7, cy + 0, 3, 7);
                
                if (frame === 0) { // WINDUP — arm up
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 4, cy - 2, 5, 6);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 3, cy - 14, 5, 14);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 4, cy - 20, 2, 14);
                    ctx.fillStyle = '#999999'; ctx.fillRect(cx + 6, cy - 22, 7, 8);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 11, cy - 22, 2, 8);
                } else if (frame === 1) { // SWING — arm forward
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 4, cy - 2, 5, 8);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 6, cy + 2, 5, 6);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 8, cy - 4, 2, 12);
                    ctx.fillStyle = '#999999'; ctx.fillRect(cx + 10, cy - 6, 7, 8);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 15, cy - 6, 2, 8);
                    ctx.fillStyle = 'rgba(204,136,68,0.3)'; ctx.fillRect(cx + 8, cy - 10, 6, 1);
                } else { // FOLLOW-THROUGH — axe low
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 4, cy, 5, 10);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 4, cy + 8, 5, 8);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 5, cy + 6, 2, 14);
                    ctx.fillStyle = '#999999'; ctx.fillRect(cx + 7, cy + 12, 7, 6);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 12, cy + 12, 2, 6);
                }
                // Head
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 4, cy - 16, 9, 10);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx + 2, cy - 11, 3, 2);
                ctx.fillStyle = '#cc6600'; ctx.fillRect(cx + 3, cy - 11, 1, 1);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx, cy - 18, 2, 4);
            } else if (dir === 2) { // UP
                // Legs
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 7, cy + 9, 6, 11); ctx.fillRect(cx + 1, cy + 9, 6, 11);
                ctx.fillStyle = '#606060'; ctx.fillRect(cx - 7, cy + 11, 6, 4); ctx.fillRect(cx + 1, cy + 11, 6, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 8, cy + 19, 7, 2); ctx.fillRect(cx + 1, cy + 19, 7, 2);
                // Torso
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 10, cy - 7, 20, 17);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 8, cy - 5, 16, 13);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx, cy - 4, 1, 11); ctx.fillRect(cx - 6, cy + 0, 12, 1);
                // Pauldrons
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 14, cy - 8, 7, 6); ctx.fillRect(cx + 7, cy - 8, 7, 6);
                // Left arm
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 14, cy - 2, 5, 9);
                ctx.fillStyle = '#606060'; ctx.fillRect(cx - 14, cy + 2, 5, 4);
                
                if (frame === 0) { // WINDUP — axe behind and up
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy - 4, 5, 8);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 7, cy - 14, 5, 12);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 8, cy - 18, 2, 10);
                    ctx.fillStyle = '#888888'; ctx.fillRect(cx + 4, cy - 20, 7, 2);
                } else if (frame === 1) { // SWING
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy - 2, 5, 12);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy - 4, 2, 14);
                    ctx.fillStyle = '#888888'; ctx.fillRect(cx + 12, cy - 2, 6, 2);
                } else { // FOLLOW-THROUGH
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy + 2, 5, 14);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy + 6, 2, 12);
                    ctx.fillStyle = '#888888'; ctx.fillRect(cx + 12, cy + 10, 6, 2);
                }
                // Head
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx - 6, cy - 16, 12, 10);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 1, cy - 18, 2, 4);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 3, cy - 7, 6, 2);
            } else { // LEFT — mirror of right
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 4, cy + 9, 5, 11); ctx.fillRect(cx + 1, cy + 10, 3, 10);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 4, cy + 11, 5, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 4, cy + 19, 6, 2);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 6, cy - 7, 12, 17);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 5, cy - 6, 10, 14);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 8, cy - 5, 2, 13);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 6, cy - 9, 10, 5);
                ctx.fillStyle = '#4a2e1e'; ctx.fillRect(cx + 4, cy + 0, 3, 7);
                if (frame === 0) {
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 9, cy - 2, 5, 6);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx - 8, cy - 14, 5, 14);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx - 6, cy - 20, 2, 14);
                    ctx.fillStyle = '#999999'; ctx.fillRect(cx - 13, cy - 22, 7, 8);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx - 13, cy - 22, 2, 8);
                } else if (frame === 1) {
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 9, cy - 2, 5, 8);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx - 11, cy + 2, 5, 6);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx - 10, cy - 4, 2, 12);
                    ctx.fillStyle = '#999999'; ctx.fillRect(cx - 17, cy - 6, 7, 8);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx - 17, cy - 6, 2, 8);
                    ctx.fillStyle = 'rgba(204,136,68,0.3)'; ctx.fillRect(cx - 14, cy - 10, 6, 1);
                } else {
                    ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 9, cy, 5, 10);
                    ctx.fillStyle = '#6a4030'; ctx.fillRect(cx - 9, cy + 8, 5, 8);
                    ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx - 7, cy + 6, 2, 14);
                    ctx.fillStyle = '#999999'; ctx.fillRect(cx - 14, cy + 12, 7, 6);
                    ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx - 14, cy + 12, 2, 6);
                }
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 5, cy - 16, 9, 10);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx - 5, cy - 11, 3, 2);
                ctx.fillStyle = '#cc6600'; ctx.fillRect(cx - 4, cy - 11, 1, 1);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 2, cy - 18, 2, 4);
            }
        },
        
        // Reaper SPIN — whirlwind, axe extended outward, body twisted
        reaper_spin(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const rot = frame * (Math.PI * 2 / 3); // 120° per frame
            ctx.fillStyle = 'rgba(0,0,0,0.3)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 21, 16, 5, 0, 0, Math.PI * 2); ctx.fill();
            // Body core — crouched spin stance (same all dirs since spinning)
            ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 7, cy + 10, 5, 9); ctx.fillRect(cx + 2, cy + 10, 5, 9);
            ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 7, cy + 12, 5, 3); ctx.fillRect(cx + 2, cy + 12, 5, 3);
            ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 8, cy + 18, 6, 2); ctx.fillRect(cx + 2, cy + 18, 6, 2);
            ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 9, cy - 5, 18, 16);
            ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 7, cy - 4, 14, 12);
            ctx.fillStyle = '#606060'; ctx.fillRect(cx - 5, cy, 10, 1);
            // Pauldrons
            ctx.fillStyle = '#888888'; ctx.fillRect(cx - 12, cy - 6, 6, 4); ctx.fillRect(cx + 6, cy - 6, 6, 4);
            // Helm
            ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 5, cy - 14, 10, 9);
            ctx.fillStyle = '#555555'; ctx.fillRect(cx - 3, cy - 9, 6, 2);
            ctx.fillStyle = '#ff8800'; ctx.fillRect(cx - 2, cy - 9, 1, 1); ctx.fillRect(cx + 2, cy - 9, 1, 1);
            ctx.fillStyle = '#999999'; ctx.fillRect(cx - 1, cy - 16, 2, 3);
            // Axe arm — rotates around body center
            const axeDist = 18;
            const axeA = rot + [0, 0.3, -0.3, 0.6][dir]; // slight offset per dir
            const ax = cx + Math.cos(axeA) * axeDist;
            const ay = cy + Math.sin(axeA) * (axeDist * 0.6); // squished for ¾ perspective
            // Arm reaching to axe
            ctx.fillStyle = '#6a4030';
            ctx.fillRect(Math.min(cx + 4, ax), Math.min(cy - 1, ay), Math.abs(ax - cx - 4) + 4, 4);
            // Axe head at arm tip
            ctx.fillStyle = '#999999';
            ctx.fillRect(ax - 4, ay - 3, 8, 6);
            ctx.fillStyle = '#aaaaaa';
            ctx.fillRect(ax + 3, ay - 3, 2, 6);
            ctx.fillStyle = '#bb3300';
            ctx.fillRect(ax - 2, ay - 1, 2, 1);
            // Motion blur arcs
            ctx.fillStyle = 'rgba(170,170,170,0.15)';
            const trailA = axeA - 0.8;
            ctx.fillRect(cx + Math.cos(trailA) * 16 - 3, cy + Math.sin(trailA) * 10 - 1, 6, 2);
            const trailB = axeA - 1.5;
            ctx.fillRect(cx + Math.cos(trailB) * 14 - 2, cy + Math.sin(trailB) * 8, 4, 1);
        },
        
        // Reaper DASH — leaning forward charge pose
        reaper_dash(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const lunge = frame === 1 ? 3 : frame === 2 ? 1 : 0;
            ctx.fillStyle = 'rgba(0,0,0,0.35)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 21, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // DOWN — charging toward camera
                // Legs — wide stride
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 9, cy + 8 + lunge, 6, 12); ctx.fillRect(cx + 3, cy + 10, 6, 10);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 9, cy + 11 + lunge, 6, 4); ctx.fillRect(cx + 3, cy + 12, 6, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 10, cy + 19 + lunge, 7, 2); ctx.fillRect(cx + 3, cy + 19, 7, 2);
                // Torso — leaning forward (shifted down)
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 10, cy - 4 + lunge, 20, 15);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 8, cy - 3 + lunge, 16, 12);
                ctx.fillStyle = '#8a8a8a'; ctx.fillRect(cx - 7, cy - 2 + lunge, 14, 3);
                ctx.fillStyle = '#606060'; ctx.fillRect(cx - 6, cy + 1 + lunge, 12, 1);
                ctx.fillStyle = '#6a4030'; ctx.fillRect(cx - 5, cy + 8 + lunge, 10, 2);
                // Pauldrons — lowered from lean
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 14, cy - 5 + lunge, 7, 5); ctx.fillRect(cx + 7, cy - 5 + lunge, 7, 5);
                // Left arm braced
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 14, cy + 0 + lunge, 5, 9);
                ctx.fillStyle = '#707070'; ctx.fillRect(cx - 14, cy + 4 + lunge, 5, 4);
                // Right arm — axe leveled forward like a lance
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy + 0 + lunge, 5, 7);
                ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 9, cy + 5 + lunge, 5, 6);
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy + 4 + lunge, 2, 14);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx + 12, cy + 6 + lunge, 9, 5);
                ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 19, cy + 6 + lunge, 2, 5);
                ctx.fillStyle = '#bb3300'; ctx.fillRect(cx + 14, cy + 8 + lunge, 2, 1);
                // Head — ducked forward
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 6, cy - 12 + lunge, 12, 9);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 5, cy - 11 + lunge, 10, 7);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx - 4, cy - 8 + lunge, 8, 2);
                ctx.fillStyle = '#ff4422'; ctx.fillRect(cx - 3, cy - 8 + lunge, 2, 1); ctx.fillRect(cx + 1, cy - 8 + lunge, 2, 1);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 1, cy - 14 + lunge, 2, 3);
                // Dust trail behind (frames 1-2)
                if (frame > 0) {
                    ctx.fillStyle = 'rgba(153,136,119,0.3)';
                    ctx.fillRect(cx - 5, cy - 16, 3, 2); ctx.fillRect(cx + 3, cy - 14, 2, 2);
                }
            } else if (dir === 1) { // RIGHT
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 2, cy + 8, 5, 12); ctx.fillRect(cx - 5, cy + 10, 3, 10);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 2, cy + 11, 5, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 3, cy + 19, 6, 2);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 5, cy - 5 + lunge, 12, 16);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 4, cy - 4 + lunge, 10, 13);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx + 6, cy - 3 + lunge, 2, 12);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 3, cy - 7 + lunge, 9, 4);
                ctx.fillStyle = '#4a2e1e'; ctx.fillRect(cx - 7, cy + 1 + lunge, 3, 7);
                // Axe arm leveled right
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 5, cy + 0 + lunge, 5, 6);
                ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 8, cy + 2 + lunge, 6, 4);
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy + 0 + lunge, 2, 10);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx + 12, cy - 2 + lunge, 7, 8);
                ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 17, cy - 2 + lunge, 2, 8);
                ctx.fillStyle = '#bb3300'; ctx.fillRect(cx + 14, cy + 1 + lunge, 2, 1);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 3, cy - 14 + lunge, 8, 9);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx + 2, cy - 9 + lunge, 3, 2);
                ctx.fillStyle = '#ff4422'; ctx.fillRect(cx + 3, cy - 9 + lunge, 1, 1);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx, cy - 16 + lunge, 2, 3);
                if (frame > 0) { ctx.fillStyle = 'rgba(153,136,119,0.3)'; ctx.fillRect(cx - 10, cy + 2, 3, 2); }
            } else if (dir === 2) { // UP — charging away
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 7, cy + 8, 6, 12); ctx.fillRect(cx + 1, cy + 10, 6, 10);
                ctx.fillStyle = '#606060'; ctx.fillRect(cx - 7, cy + 11, 6, 4); ctx.fillRect(cx + 1, cy + 12, 6, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 8, cy + 19, 7, 2); ctx.fillRect(cx + 1, cy + 19, 7, 2);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 10, cy - 4, 20, 13);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 8, cy - 3, 16, 11);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx, cy - 2, 1, 9);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 14, cy - 5, 7, 5); ctx.fillRect(cx + 7, cy - 5, 7, 5);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 14, cy + 0, 5, 8);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy + 0, 5, 14);
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy + 4, 2, 12);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx + 12, cy + 3, 6, 2);
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx - 6, cy - 12, 12, 9);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 1, cy - 14, 2, 3);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 3, cy - 4, 6, 2);
                if (frame > 0) { ctx.fillStyle = 'rgba(153,136,119,0.3)'; ctx.fillRect(cx - 4, cy + 20, 3, 2); ctx.fillRect(cx + 2, cy + 21, 2, 2); }
            } else { // LEFT — mirror of right
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 3, cy + 8, 5, 12); ctx.fillRect(cx + 2, cy + 10, 3, 10);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 3, cy + 11, 5, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 3, cy + 19, 6, 2);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 7, cy - 5 + lunge, 12, 16);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 6, cy - 4 + lunge, 10, 13);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 8, cy - 3 + lunge, 2, 12);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 6, cy - 7 + lunge, 9, 4);
                ctx.fillStyle = '#4a2e1e'; ctx.fillRect(cx + 4, cy + 1 + lunge, 3, 7);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 10, cy + 0 + lunge, 5, 6);
                ctx.fillStyle = '#6a4030'; ctx.fillRect(cx - 14, cy + 2 + lunge, 6, 4);
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx - 12, cy + 0 + lunge, 2, 10);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 19, cy - 2 + lunge, 7, 8);
                ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx - 19, cy - 2 + lunge, 2, 8);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 5, cy - 14 + lunge, 8, 9);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx - 5, cy - 9 + lunge, 3, 2);
                ctx.fillStyle = '#ff4422'; ctx.fillRect(cx - 4, cy - 9 + lunge, 1, 1);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 2, cy - 16 + lunge, 2, 3);
                if (frame > 0) { ctx.fillStyle = 'rgba(153,136,119,0.3)'; ctx.fillRect(cx + 7, cy + 2, 3, 2); }
            }
        },
        
        // Reaper CROUCH — pre-leap squat, 3 frames: standing→half→full crouch
        reaper_crouch(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const squat = frame === 0 ? 0 : frame === 1 ? 4 : 8; // increasingly compressed
            const widen = frame === 0 ? 0 : frame === 1 ? 2 : 4;
            ctx.fillStyle = 'rgba(0,0,0,0.35)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 21, 14 + widen, 5, 0, 0, Math.PI * 2); ctx.fill();
            // Legs — spread wider as crouch deepens
            ctx.fillStyle = '#5a3a28';
            ctx.fillRect(cx - 8 - widen, cy + 8 + squat, 6, 11 - squat/2);
            ctx.fillRect(cx + 2 + widen, cy + 8 + squat, 6, 11 - squat/2);
            ctx.fillStyle = '#6a6a6a';
            ctx.fillRect(cx - 8 - widen, cy + 10 + squat, 6, 4);
            ctx.fillRect(cx + 2 + widen, cy + 10 + squat, 6, 4);
            ctx.fillStyle = '#4a4a4a';
            ctx.fillRect(cx - 9 - widen, cy + 18, 7, 3); ctx.fillRect(cx + 2 + widen, cy + 18, 7, 3);
            // Torso — compressed downward
            ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 10, cy - 5 + squat, 20, 14 - squat/2);
            ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 8, cy - 4 + squat, 16, 11 - squat/2);
            ctx.fillStyle = '#8a8a8a'; ctx.fillRect(cx - 7, cy - 3 + squat, 14, 3);
            ctx.fillStyle = '#606060'; ctx.fillRect(cx - 6, cy + squat, 12, 1);
            ctx.fillStyle = '#6a4030'; ctx.fillRect(cx - 5, cy + 5 + squat, 10, 2);
            // Pauldrons — rise as body squishes
            ctx.fillStyle = '#888888'; ctx.fillRect(cx - 14, cy - 6 + squat/2, 7, 5); ctx.fillRect(cx + 7, cy - 6 + squat/2, 7, 5);
            // Arms — tucked in
            ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 13, cy - 1 + squat, 4, 8);
            ctx.fillStyle = '#707070'; ctx.fillRect(cx - 13, cy + 3 + squat, 4, 4);
            // Right arm + axe pulled in
            ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy - 1 + squat, 5, 8);
            ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 9, cy + 5 + squat, 5, 4);
            ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy + 2 + squat, 2, 10);
            ctx.fillStyle = '#999999'; ctx.fillRect(cx + 12, cy + 4 + squat, 6, 4);
            ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 16, cy + 4 + squat, 2, 4);
            // Helm — head ducks between pauldrons
            ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 5, cy - 12 + squat, 10, 8);
            ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 4, cy - 11 + squat, 8, 6);
            ctx.fillStyle = '#555555'; ctx.fillRect(cx - 3, cy - 8 + squat, 6, 2);
            ctx.fillStyle = '#ff6622'; ctx.fillRect(cx - 2, cy - 8 + squat, 2, 1); ctx.fillRect(cx + 1, cy - 8 + squat, 2, 1);
            ctx.fillStyle = '#999999'; ctx.fillRect(cx - 1, cy - 14 + squat, 2, 3);
            // Glow intensifies in later frames
            if (frame >= 1) { ctx.fillStyle = 'rgba(255,102,34,0.15)'; ctx.fillRect(cx - 12, cy + squat, 24, 10); }
            if (frame >= 2) { ctx.fillStyle = 'rgba(255,68,34,0.2)'; ctx.fillRect(cx - 14, cy - 2 + squat, 28, 14); }
        },
        
        // Reaper LAND — slamming down from above, 3 frames: airborne/descending, impact, shockwave
        reaper_land(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            ctx.fillStyle = 'rgba(0,0,0,0.35)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 21, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
            
            if (frame === 0) { // DESCENDING — small, above center, axe overhead
                const sc = 0.7;
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 5, cy - 4, 10, 12);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 4, cy - 3, 8, 10);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 7, cy - 5, 5, 4); ctx.fillRect(cx + 2, cy - 5, 5, 4);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 3, cy - 10, 6, 6);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx - 2, cy - 7, 4, 1);
                ctx.fillStyle = '#ff6622'; ctx.fillRect(cx - 1, cy - 7, 1, 1); ctx.fillRect(cx + 1, cy - 7, 1, 1);
                // Axe overhead
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 2, cy - 14, 2, 8);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 3, cy - 16, 8, 3);
                ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx - 3, cy - 16, 2, 3);
                // Fire trail above
                ctx.fillStyle = 'rgba(255,102,34,0.4)'; ctx.fillRect(cx - 3, cy - 20, 2, 3); ctx.fillRect(cx + 1, cy - 19, 2, 4);
                ctx.fillStyle = 'rgba(255,200,68,0.3)'; ctx.fillRect(cx - 1, cy - 22, 2, 3);
            } else if (frame === 1) { // IMPACT — full size, crouched, axe embedded in ground
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 9, cy + 10, 6, 10); ctx.fillRect(cx + 3, cy + 10, 6, 10);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 9, cy + 12, 6, 4); ctx.fillRect(cx + 3, cy + 12, 6, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 10, cy + 19, 7, 2); ctx.fillRect(cx + 3, cy + 19, 7, 2);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 10, cy - 2, 20, 13);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 8, cy - 1, 16, 10);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 13, cy - 3, 6, 4); ctx.fillRect(cx + 7, cy - 3, 6, 4);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 13, cy + 1, 4, 8);
                ctx.fillStyle = '#707070'; ctx.fillRect(cx - 13, cy + 4, 4, 4);
                // Axe arm down, embedded
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy, 5, 10);
                ctx.fillStyle = '#6a4030'; ctx.fillRect(cx + 9, cy + 8, 5, 6);
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy + 8, 2, 12);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx + 12, cy + 14, 8, 4);
                ctx.fillStyle = '#aaaaaa'; ctx.fillRect(cx + 18, cy + 14, 2, 4);
                // Ground cracks
                ctx.fillStyle = '#444444'; ctx.fillRect(cx + 8, cy + 18, 16, 1); ctx.fillRect(cx + 14, cy + 16, 1, 5);
                ctx.fillRect(cx + 4, cy + 19, 10, 1);
                // Head
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 5, cy - 9, 10, 8);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx - 3, cy - 5, 6, 2);
                ctx.fillStyle = '#ff4422'; ctx.fillRect(cx - 2, cy - 5, 2, 1); ctx.fillRect(cx + 1, cy - 5, 2, 1);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 1, cy - 11, 2, 3);
                // Fire burst
                ctx.fillStyle = 'rgba(255,68,34,0.3)'; ctx.fillRect(cx - 14, cy + 14, 28, 6);
                ctx.fillStyle = 'rgba(255,136,51,0.2)'; ctx.fillRect(cx - 10, cy + 12, 20, 3);
            } else { // SHOCKWAVE — standing up, fire ring expanding
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 7, cy + 9, 6, 11); ctx.fillRect(cx + 1, cy + 9, 6, 11);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 7, cy + 11, 6, 4); ctx.fillRect(cx + 1, cy + 11, 6, 4);
                ctx.fillStyle = '#4a4a4a'; ctx.fillRect(cx - 8, cy + 19, 7, 2); ctx.fillRect(cx + 1, cy + 19, 7, 2);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 10, cy - 6, 20, 16);
                ctx.fillStyle = '#7a7a7a'; ctx.fillRect(cx - 8, cy - 5, 16, 13);
                ctx.fillStyle = '#888888'; ctx.fillRect(cx - 13, cy - 7, 6, 5); ctx.fillRect(cx + 7, cy - 7, 6, 5);
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx - 13, cy - 1, 4, 9); // left arm
                ctx.fillStyle = '#5a3a28'; ctx.fillRect(cx + 9, cy - 1, 5, 14); // right arm
                ctx.fillStyle = '#5a5a5a'; ctx.fillRect(cx + 10, cy + 6, 2, 14);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx + 12, cy + 8, 7, 4);
                ctx.fillStyle = '#6a6a6a'; ctx.fillRect(cx - 5, cy - 14, 10, 9);
                ctx.fillStyle = '#555555'; ctx.fillRect(cx - 3, cy - 9, 6, 2);
                ctx.fillStyle = '#cc6600'; ctx.fillRect(cx - 2, cy - 9, 2, 1); ctx.fillRect(cx + 1, cy - 9, 2, 1);
                ctx.fillStyle = '#999999'; ctx.fillRect(cx - 1, cy - 16, 2, 3);
                // Expanding fire ring on ground
                ctx.fillStyle = 'rgba(255,68,34,0.2)';
                ctx.beginPath(); ctx.ellipse(cx, cy + 19, 22, 8, 0, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = 'rgba(255,136,51,0.15)';
                ctx.beginPath(); ctx.ellipse(cx, cy + 19, 28, 10, 0, 0, Math.PI * 2); ctx.fill();
            }
        },
        
        deadlock(ctx, s, dir, frame) {
            // Deadlock — large mechanical flesh construct with busted CRT head on fire
            // 56px canvas. Bolted scrap plates over exposed muscle, thick armored legs,
            // cables running to boxy CRT monitor head with cracked green-static screen, flames licking up.
            const cx = s/2, cy = s/2;
            const bob = frame === 1 ? -1 : frame === 2 ? 1 : 0;
            const legL = frame === 1 ? 3 : frame === 2 ? -3 : 0;
            const armSwing = frame === 1 ? 3 : frame === 2 ? -3 : 0;
            const fl = frame === 1 ? 0 : frame === 2 ? 2 : 1; // CRT static flicker shift
            
            // Ground shadow
            ctx.fillStyle = 'rgba(0,0,0,0.4)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 22, 15, 6, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // === DOWN — front-facing ¾ ===
                // Legs — stocky, armored shin guards
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 9 + legL, cy + 14 + bob, 8, 10);
                ctx.fillRect(cx + 1 - legL, cy + 14 + bob, 8, 10);
                ctx.fillStyle = '#5a5a50'; // shin plates
                ctx.fillRect(cx - 8 + legL, cy + 16 + bob, 6, 6);
                ctx.fillRect(cx + 2 - legL, cy + 16 + bob, 6, 6);
                ctx.fillStyle = '#888'; // rivets
                ctx.fillRect(cx - 6 + legL, cy + 18 + bob, 1, 1);
                ctx.fillRect(cx + 4 - legL, cy + 18 + bob, 1, 1);
                
                // Torso — mechanical flesh: exposed muscle with bolted metal plates
                ctx.fillStyle = '#5a3a28'; // organic base
                ctx.fillRect(cx - 16, cy - 4 + bob, 32, 20);
                // Muscle striations
                ctx.fillStyle = '#6a4433';
                ctx.fillRect(cx - 12, cy + 2 + bob, 4, 8);
                ctx.fillRect(cx + 8, cy + 2 + bob, 4, 8);
                ctx.fillStyle = '#7a5040';
                ctx.fillRect(cx - 6, cy - 2 + bob, 12, 4);
                // Metal chest plate — dented, riveted
                ctx.fillStyle = '#6a6a60';
                ctx.fillRect(cx - 10, cy - 2 + bob, 20, 14);
                ctx.fillStyle = '#7a7a70';
                ctx.fillRect(cx - 8, cy + 0 + bob, 16, 10);
                // Plate dents
                ctx.fillStyle = '#585850';
                ctx.fillRect(cx - 4, cy + 2 + bob, 5, 3);
                ctx.fillRect(cx + 3, cy + 6 + bob, 4, 2);
                // Rivets across chest
                ctx.fillStyle = '#999';
                ctx.fillRect(cx - 9, cy - 1 + bob, 2, 2);
                ctx.fillRect(cx + 7, cy - 1 + bob, 2, 2);
                ctx.fillRect(cx - 9, cy + 11 + bob, 2, 2);
                ctx.fillRect(cx + 7, cy + 11 + bob, 2, 2);
                ctx.fillRect(cx - 1, cy - 1 + bob, 2, 2);
                // Exposed tendons at torso edges
                ctx.fillStyle = '#8a4433';
                ctx.fillRect(cx - 15, cy + 4 + bob, 3, 6);
                ctx.fillRect(cx + 12, cy + 4 + bob, 3, 6);
                
                // Shoulder pauldrons — heavy scrap
                ctx.fillStyle = '#5a5a52';
                ctx.fillRect(cx - 20, cy - 6 + bob, 10, 12);
                ctx.fillRect(cx + 10, cy - 6 + bob, 10, 12);
                ctx.fillStyle = '#7a7a72'; // highlight edge
                ctx.fillRect(cx - 19, cy - 5 + bob, 8, 2);
                ctx.fillRect(cx + 11, cy - 5 + bob, 8, 2);
                ctx.fillStyle = '#aaa'; // bolts
                ctx.fillRect(cx - 16, cy - 2 + bob, 2, 2);
                ctx.fillRect(cx + 14, cy - 2 + bob, 2, 2);
                
                // Arms — thick with metal bracers
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 24, cy + 0 + bob + armSwing, 8, 18);
                ctx.fillRect(cx + 16, cy + 0 + bob - armSwing, 8, 18);
                ctx.fillStyle = '#6a6a5a'; // bracers
                ctx.fillRect(cx - 23, cy + 6 + bob + armSwing, 6, 6);
                ctx.fillRect(cx + 17, cy + 6 + bob - armSwing, 6, 6);
                // Fists — mechanical gauntlets, not circles
                // Left fist
                const lfy = cy + 19 + bob + armSwing, lfx = cx - 20;
                ctx.fillStyle = '#6a5a4a'; // knuckle plate
                ctx.fillRect(lfx - 5, lfy - 3, 10, 6);
                ctx.fillStyle = '#7a6a58'; // plate highlight
                ctx.fillRect(lfx - 4, lfy - 2, 8, 3);
                ctx.fillStyle = '#555'; // finger stubs
                ctx.fillRect(lfx - 4, lfy + 3, 3, 3);
                ctx.fillRect(lfx - 0, lfy + 3, 3, 3);
                ctx.fillRect(lfx + 4, lfy + 3, 2, 2);
                ctx.fillStyle = '#999'; // knuckle rivets
                ctx.fillRect(lfx - 3, lfy - 2, 1, 1);
                ctx.fillRect(lfx + 2, lfy - 2, 1, 1);
                // Right fist
                const rfy = cy + 19 + bob - armSwing, rfx = cx + 20;
                ctx.fillStyle = '#6a5a4a';
                ctx.fillRect(rfx - 5, rfy - 3, 10, 6);
                ctx.fillStyle = '#7a6a58';
                ctx.fillRect(rfx - 4, rfy - 2, 8, 3);
                ctx.fillStyle = '#555';
                ctx.fillRect(rfx - 4, rfy + 3, 3, 3);
                ctx.fillRect(rfx - 0, rfy + 3, 3, 3);
                ctx.fillRect(rfx + 4, rfy + 3, 2, 2);
                ctx.fillStyle = '#999';
                ctx.fillRect(rfx - 3, rfy - 2, 1, 1);
                ctx.fillRect(rfx + 2, rfy - 2, 1, 1);
                // Tendon detail on arms
                ctx.fillStyle = '#8a4a33';
                ctx.fillRect(cx - 22, cy + 2 + bob + armSwing, 2, 4);
                ctx.fillRect(cx + 20, cy + 2 + bob - armSwing, 2, 4);
                
                // Cables — torso to head
                ctx.fillStyle = '#333';
                ctx.fillRect(cx - 4, cy - 6 + bob, 2, 4);
                ctx.fillRect(cx + 2, cy - 6 + bob, 2, 4);
                ctx.fillStyle = '#444';
                ctx.fillRect(cx - 2, cy - 8 + bob, 4, 3);
                
                // === CRT HEAD — busted monitor, cracked screen, on fire ===
                ctx.fillStyle = '#4a4a42'; // casing
                ctx.fillRect(cx - 10, cy - 20 + bob, 20, 16);
                // Bezel frame
                ctx.fillStyle = '#3a3a34';
                ctx.fillRect(cx - 11, cy - 21 + bob, 22, 2);
                ctx.fillRect(cx - 11, cy - 21 + bob, 2, 18);
                ctx.fillRect(cx + 9, cy - 21 + bob, 2, 18);
                ctx.fillRect(cx - 11, cy - 5 + bob, 22, 2);
                // Screen — dark with green static
                ctx.fillStyle = '#112211';
                ctx.fillRect(cx - 8, cy - 18 + bob, 16, 12);
                // Scan lines (shift per frame)
                ctx.fillStyle = '#224422';
                ctx.fillRect(cx - 8, cy - 17 + fl + bob, 16, 1);
                ctx.fillRect(cx - 8, cy - 13 + fl + bob, 16, 1);
                ctx.fillRect(cx - 8, cy - 9 + fl + bob, 16, 1);
                // Bright static pixels
                ctx.fillStyle = '#33aa33';
                ctx.fillRect(cx - 4 + fl, cy - 16 + bob, 2, 1);
                ctx.fillRect(cx + 2 - fl, cy - 12 + bob, 3, 1);
                ctx.fillRect(cx - 6 + fl, cy - 10 + bob, 2, 1);
                // Crack across screen
                ctx.fillStyle = '#556655';
                ctx.fillRect(cx - 7, cy - 15 + bob, 1, 8);
                ctx.fillRect(cx - 6, cy - 14 + bob, 3, 1);
                ctx.fillRect(cx - 4, cy - 11 + bob, 4, 1);
                // Hole in glass — ember glow visible through
                ctx.fillStyle = '#0a0a0a';
                ctx.fillRect(cx + 3, cy - 16 + bob, 3, 3);
                ctx.fillStyle = '#994422';
                ctx.fillRect(cx + 4, cy - 15 + bob, 1, 1);
                
                // === FIRE licking up from CRT head ===
                ctx.fillStyle = '#cc5500'; // base flames
                ctx.fillRect(cx - 8, cy - 23 + bob, 4, 4);
                ctx.fillRect(cx + 0, cy - 24 + bob, 3, 5);
                ctx.fillRect(cx + 5, cy - 22 + bob, 4, 3);
                ctx.fillStyle = '#ff8822'; // tips
                ctx.fillRect(cx - 6, cy - 25 + bob - fl, 3, 3);
                ctx.fillRect(cx + 1, cy - 26 + bob - fl, 2, 3);
                ctx.fillRect(cx + 6, cy - 24 + bob - fl, 2, 3);
                ctx.fillStyle = '#ffcc44'; // hot core
                ctx.fillRect(cx - 5, cy - 24 + bob, 2, 2);
                ctx.fillRect(cx + 2, cy - 25 + bob, 1, 2);
                // Side flames
                ctx.fillStyle = '#cc5500';
                ctx.fillRect(cx - 11, cy - 18 + bob, 2, 3);
                ctx.fillRect(cx + 9, cy - 17 + bob, 2, 3);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx - 11, cy - 20 + bob - fl, 2, 2);
                ctx.fillRect(cx + 9, cy - 19 + bob - fl, 2, 2);
                
            } else if (dir === 2) { // === UP — back-facing ===
                // Legs
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 9 + legL, cy + 14 + bob, 8, 10);
                ctx.fillRect(cx + 1 - legL, cy + 14 + bob, 8, 10);
                ctx.fillStyle = '#5a5a50';
                ctx.fillRect(cx - 8 + legL, cy + 16 + bob, 6, 6);
                ctx.fillRect(cx + 2 - legL, cy + 16 + bob, 6, 6);
                // Torso back — spine ridge visible
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 16, cy - 4 + bob, 32, 20);
                ctx.fillStyle = '#4a2a1a'; // spine ridge
                ctx.fillRect(cx - 2, cy - 2 + bob, 4, 16);
                ctx.fillStyle = '#6a4a38'; // vertebrae bumps
                ctx.fillRect(cx - 1, cy + 0 + bob, 2, 2);
                ctx.fillRect(cx - 1, cy + 4 + bob, 2, 2);
                ctx.fillRect(cx - 1, cy + 8 + bob, 2, 2);
                // Back plates
                ctx.fillStyle = '#6a6a60';
                ctx.fillRect(cx - 8, cy + 2 + bob, 6, 10);
                ctx.fillRect(cx + 2, cy + 2 + bob, 6, 10);
                // Pauldrons
                ctx.fillStyle = '#5a5a52';
                ctx.fillRect(cx - 20, cy - 6 + bob, 10, 12);
                ctx.fillRect(cx + 10, cy - 6 + bob, 10, 12);
                // Arms
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 24, cy + 0 + bob - armSwing, 8, 18);
                ctx.fillRect(cx + 16, cy + 0 + bob + armSwing, 8, 18);
                // Cables from behind
                ctx.fillStyle = '#333';
                ctx.fillRect(cx - 3, cy - 6 + bob, 2, 3);
                ctx.fillRect(cx + 1, cy - 7 + bob, 2, 4);
                // CRT back — vent slats
                ctx.fillStyle = '#4a4a42';
                ctx.fillRect(cx - 10, cy - 20 + bob, 20, 16);
                ctx.fillStyle = '#3a3a34';
                ctx.fillRect(cx - 6, cy - 18 + bob, 12, 10);
                ctx.fillStyle = '#2a2a24';
                for (let v = 0; v < 4; v++) ctx.fillRect(cx - 4, cy - 16 + v * 3 + bob, 8, 1);
                // Fire on top
                ctx.fillStyle = '#cc5500';
                ctx.fillRect(cx - 7, cy - 23 + bob, 4, 4);
                ctx.fillRect(cx + 1, cy - 24 + bob, 3, 5);
                ctx.fillRect(cx + 5, cy - 22 + bob, 3, 3);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx - 5, cy - 25 + bob - fl, 3, 3);
                ctx.fillRect(cx + 2, cy - 26 + bob - fl, 2, 3);
                ctx.fillStyle = '#ffcc44';
                ctx.fillRect(cx - 4, cy - 24 + bob, 2, 2);
                
            } else { // === RIGHT(1) / LEFT(3) — side ¾ ===
                // Side view: depth face dominant, screen face foreshortened
                const flip = dir === 3 ? -1 : 1;
                // Legs
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 4 + legL * flip, cy + 14 + bob, 8, 10);
                ctx.fillRect(cx - 4 - legL * flip + 2 * flip, cy + 14 + bob, 7, 10);
                ctx.fillStyle = '#5a5a50'; // near shin plate
                ctx.fillRect(cx - 3 + legL * flip, cy + 16 + bob, 6, 6);
                // Torso
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 12, cy - 4 + bob, 26, 20);
                // Side plate — dominant
                ctx.fillStyle = '#6a6a60';
                ctx.fillRect(cx - 4 * flip, cy - 2 + bob, 14, 14);
                ctx.fillStyle = '#585850'; // dent
                ctx.fillRect(cx + 2 * flip, cy + 4 + bob, 4, 3);
                ctx.fillStyle = '#999'; // rivets
                ctx.fillRect(cx - 2 * flip, cy + 0 + bob, 2, 2);
                ctx.fillRect(cx - 2 * flip, cy + 10 + bob, 2, 2);
                // Exposed tendons far side
                ctx.fillStyle = '#8a4433';
                ctx.fillRect(cx - 11 * flip, cy + 2 + bob, 3, 8);
                // Near shoulder
                ctx.fillStyle = '#5a5a52';
                ctx.fillRect(cx + 8 * flip, cy - 6 + bob, 8, 12);
                // Near arm
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 10 * flip, cy + 0 + bob + armSwing, 8, 18);
                ctx.fillStyle = '#6a6a5a'; // bracer
                ctx.fillRect(cx + 11 * flip, cy + 6 + bob + armSwing, 6, 6);
                // Fist — side profile gauntlet
                const sfx = cx + 14 * flip, sfy = cy + 19 + bob + armSwing;
                ctx.fillStyle = '#6a5a4a';
                ctx.fillRect(sfx - 3, sfy - 3, 6, 7);
                ctx.fillStyle = '#7a6a58';
                ctx.fillRect(sfx - 2, sfy - 2, 4, 3);
                ctx.fillStyle = '#555'; // finger stubs
                ctx.fillRect(sfx - 2, sfy + 4, 2, 3);
                ctx.fillRect(sfx + 1, sfy + 4, 2, 2);
                ctx.fillStyle = '#999'; // rivet
                ctx.fillRect(sfx, sfy - 2, 1, 1);
                // Cables
                ctx.fillStyle = '#333';
                ctx.fillRect(cx + 1 * flip, cy - 7 + bob, 3, 4);
                // CRT side — depth face is dominant panel, screen foreshortened
                ctx.fillStyle = '#4a4a42'; // casing depth
                ctx.fillRect(cx - 4 * flip, cy - 20 + bob, 12, 16);
                // Screen sliver
                ctx.fillStyle = '#112211';
                ctx.fillRect(cx + 7 * flip, cy - 18 + bob, 3, 12);
                ctx.fillStyle = '#33aa33'; // static dots on edge
                ctx.fillRect(cx + 8 * flip, cy - 16 + fl + bob, 1, 1);
                ctx.fillRect(cx + 8 * flip, cy - 12 + fl + bob, 1, 1);
                // Bezel
                ctx.fillStyle = '#3a3a34';
                ctx.fillRect(cx - 5 * flip, cy - 21 + bob, 14, 2);
                ctx.fillRect(cx - 5 * flip, cy - 5 + bob, 14, 2);
                // Fire
                ctx.fillStyle = '#cc5500';
                ctx.fillRect(cx - 2 * flip, cy - 23 + bob, 4, 4);
                ctx.fillRect(cx + 4 * flip, cy - 24 + bob, 3, 5);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx + 0, cy - 25 + bob - fl, 3, 3);
                ctx.fillRect(cx + 5 * flip, cy - 26 + bob - fl, 2, 3);
                ctx.fillStyle = '#ffcc44';
                ctx.fillRect(cx + 1 * flip, cy - 24 + bob, 2, 2);
            }
        },
        
        // Deadlock CHARGE — lowered CRT, forward lean, heat distortion trails
        // 3 frames: f0 = windup crouch, f1 = mid-charge, f2 = full lunge
        deadlock_charge(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const lunge = frame === 0 ? 0 : frame === 1 ? 3 : 2;
            const fl = frame % 2; // fire flicker
            
            ctx.fillStyle = 'rgba(0,0,0,0.4)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 22, 14, 5, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // DOWN — charging toward camera
                // Legs — wide power stride
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 10, cy + 10 + lunge, 8, 12);
                ctx.fillRect(cx + 2, cy + 12, 8, 10);
                ctx.fillStyle = '#5a5a50';
                ctx.fillRect(cx - 9, cy + 13 + lunge, 6, 5);
                ctx.fillRect(cx + 3, cy + 14, 6, 5);
                // Torso — hunched forward
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 15, cy - 2 + lunge, 30, 16);
                ctx.fillStyle = '#6a6a60'; // chest plate
                ctx.fillRect(cx - 10, cy + 0 + lunge, 20, 12);
                ctx.fillStyle = '#7a7a70';
                ctx.fillRect(cx - 8, cy + 2 + lunge, 16, 8);
                ctx.fillStyle = '#585850'; // dent
                ctx.fillRect(cx - 3, cy + 4 + lunge, 6, 3);
                ctx.fillStyle = '#999'; // rivets
                ctx.fillRect(cx - 9, cy + 1 + lunge, 2, 2);
                ctx.fillRect(cx + 7, cy + 1 + lunge, 2, 2);
                // Pauldrons — lowered
                ctx.fillStyle = '#5a5a52';
                ctx.fillRect(cx - 19, cy - 3 + lunge, 9, 10);
                ctx.fillRect(cx + 10, cy - 3 + lunge, 9, 10);
                // Arms — thrust forward
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 22, cy + 2 + lunge, 8, 14);
                ctx.fillRect(cx + 14, cy + 2 + lunge, 8, 14);
                ctx.fillStyle = '#6a5a4a'; // fists — mechanical gauntlets
                ctx.fillRect(cx - 23, cy + 14 + lunge, 10, 6);
                ctx.fillRect(cx + 13, cy + 14 + lunge, 10, 6);
                ctx.fillStyle = '#7a6a58';
                ctx.fillRect(cx - 22, cy + 15 + lunge, 8, 3);
                ctx.fillRect(cx + 14, cy + 15 + lunge, 8, 3);
                ctx.fillStyle = '#555';
                ctx.fillRect(cx - 22, cy + 20 + lunge, 3, 3); ctx.fillRect(cx - 18, cy + 20 + lunge, 3, 3);
                ctx.fillRect(cx + 15, cy + 20 + lunge, 3, 3); ctx.fillRect(cx + 19, cy + 20 + lunge, 3, 3);
                ctx.fillStyle = '#999';
                ctx.fillRect(cx - 20, cy + 15 + lunge, 1, 1); ctx.fillRect(cx + 17, cy + 15 + lunge, 1, 1);
                // Cables
                ctx.fillStyle = '#333';
                ctx.fillRect(cx - 3, cy - 4 + lunge, 2, 3);
                ctx.fillRect(cx + 1, cy - 4 + lunge, 2, 3);
                // CRT head — tilted down/forward (ducked)
                ctx.fillStyle = '#4a4a42';
                ctx.fillRect(cx - 9, cy - 16 + lunge, 18, 14);
                ctx.fillStyle = '#3a3a34'; // bezel
                ctx.fillRect(cx - 10, cy - 17 + lunge, 20, 2);
                ctx.fillRect(cx - 10, cy - 3 + lunge, 20, 2);
                // Screen
                ctx.fillStyle = '#112211';
                ctx.fillRect(cx - 7, cy - 14 + lunge, 14, 10);
                ctx.fillStyle = '#224422'; // scan lines
                ctx.fillRect(cx - 7, cy - 13 + fl + lunge, 14, 1);
                ctx.fillRect(cx - 7, cy - 9 + fl + lunge, 14, 1);
                ctx.fillStyle = '#33aa33';
                ctx.fillRect(cx - 3 + fl, cy - 12 + lunge, 2, 1);
                ctx.fillRect(cx + 2, cy - 8 + lunge, 3, 1);
                // Crack
                ctx.fillStyle = '#556655';
                ctx.fillRect(cx - 5, cy - 13 + lunge, 1, 6);
                ctx.fillRect(cx - 4, cy - 10 + lunge, 3, 1);
                // Fire — intensified during charge
                ctx.fillStyle = '#cc5500';
                ctx.fillRect(cx - 7, cy - 19 + lunge, 5, 4);
                ctx.fillRect(cx + 0, cy - 20 + lunge, 4, 5);
                ctx.fillRect(cx + 5, cy - 18 + lunge, 4, 3);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx - 5, cy - 21 + lunge - fl, 4, 3);
                ctx.fillRect(cx + 1, cy - 22 + lunge - fl, 3, 3);
                ctx.fillRect(cx + 6, cy - 20 + lunge - fl, 3, 3);
                ctx.fillStyle = '#ffcc44';
                ctx.fillRect(cx - 4, cy - 20 + lunge, 2, 2);
                ctx.fillRect(cx + 2, cy - 21 + lunge, 2, 2);
                // Heat distortion trail (frame 1+)
                if (frame > 0) {
                    ctx.fillStyle = 'rgba(204,85,0,0.25)';
                    ctx.fillRect(cx - 8, cy - 22, 4, 2);
                    ctx.fillRect(cx + 4, cy - 20, 3, 2);
                    ctx.fillStyle = 'rgba(255,136,34,0.15)';
                    ctx.fillRect(cx - 3, cy - 24, 6, 2);
                }
            } else if (dir === 2) { // UP — charging away
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 8, cy + 10, 8, 12);
                ctx.fillRect(cx + 0, cy + 12, 8, 10);
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 15, cy - 2, 30, 14);
                ctx.fillStyle = '#6a6a60';
                ctx.fillRect(cx - 8, cy + 0, 16, 10);
                ctx.fillStyle = '#4a2a1a'; // spine
                ctx.fillRect(cx - 1, cy + 0, 3, 10);
                ctx.fillStyle = '#5a5a52'; // pauldrons
                ctx.fillRect(cx - 19, cy - 4, 9, 10);
                ctx.fillRect(cx + 10, cy - 4, 9, 10);
                ctx.fillStyle = '#5a3a28'; // arms
                ctx.fillRect(cx - 22, cy + 0, 8, 14);
                ctx.fillRect(cx + 14, cy + 0, 8, 14);
                // CRT back
                ctx.fillStyle = '#4a4a42';
                ctx.fillRect(cx - 9, cy - 16, 18, 14);
                ctx.fillStyle = '#3a3a34';
                ctx.fillRect(cx - 5, cy - 14, 10, 8);
                ctx.fillStyle = '#2a2a24';
                for (let v = 0; v < 3; v++) ctx.fillRect(cx - 3, cy - 12 + v * 3, 6, 1);
                // Fire
                ctx.fillStyle = '#cc5500';
                ctx.fillRect(cx - 6, cy - 19, 4, 4);
                ctx.fillRect(cx + 1, cy - 20, 3, 5);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx - 4, cy - 21 - fl, 3, 3);
                ctx.fillRect(cx + 2, cy - 22 - fl, 2, 3);
                ctx.fillStyle = '#ffcc44';
                ctx.fillRect(cx - 3, cy - 20, 2, 2);
                // Heat trail
                if (frame > 0) {
                    ctx.fillStyle = 'rgba(204,85,0,0.25)';
                    ctx.fillRect(cx - 5, cy + 22, 4, 2);
                    ctx.fillRect(cx + 2, cy + 21, 3, 2);
                }
            } else { // RIGHT(1)/LEFT(3)
                const flip = dir === 3 ? -1 : 1;
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 3, cy + 10, 8, 12);
                ctx.fillRect(cx - 3 + 3 * flip, cy + 12, 6, 10);
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 10, cy - 2 + lunge, 24, 16);
                ctx.fillStyle = '#6a6a60';
                ctx.fillRect(cx - 3 * flip, cy + 0 + lunge, 12, 12);
                ctx.fillStyle = '#5a5a52'; // near shoulder
                ctx.fillRect(cx + 8 * flip, cy - 4 + lunge, 8, 10);
                ctx.fillStyle = '#5a3a28'; // near arm
                ctx.fillRect(cx + 10 * flip, cy + 2 + lunge, 8, 14);
                ctx.fillStyle = '#6a5a4a'; // fist — side profile gauntlet
                const cfx = cx + 14 * flip, cfy = cy + 17 + lunge;
                ctx.fillRect(cfx - 3, cfy - 3, 6, 7);
                ctx.fillStyle = '#7a6a58';
                ctx.fillRect(cfx - 2, cfy - 2, 4, 3);
                ctx.fillStyle = '#555';
                ctx.fillRect(cfx - 2, cfy + 4, 2, 3); ctx.fillRect(cfx + 1, cfy + 4, 2, 2);
                ctx.fillStyle = '#999';
                ctx.fillRect(cfx, cfy - 2, 1, 1);
                // CRT side
                ctx.fillStyle = '#4a4a42';
                ctx.fillRect(cx - 3 * flip, cy - 16 + lunge, 10, 14);
                ctx.fillStyle = '#112211'; // screen sliver
                ctx.fillRect(cx + 6 * flip, cy - 14 + lunge, 3, 10);
                ctx.fillStyle = '#33aa33';
                ctx.fillRect(cx + 7 * flip, cy - 12 + fl + lunge, 1, 1);
                // Bezel
                ctx.fillStyle = '#3a3a34';
                ctx.fillRect(cx - 4 * flip, cy - 17 + lunge, 12, 2);
                // Fire
                ctx.fillStyle = '#cc5500';
                ctx.fillRect(cx - 1 * flip, cy - 19 + lunge, 4, 4);
                ctx.fillRect(cx + 4 * flip, cy - 20 + lunge, 3, 5);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx + 0, cy - 21 + lunge - fl, 3, 3);
                ctx.fillRect(cx + 5 * flip, cy - 22 + lunge - fl, 2, 3);
                ctx.fillStyle = '#ffcc44';
                ctx.fillRect(cx + 1 * flip, cy - 20 + lunge, 2, 2);
                if (frame > 0) {
                    ctx.fillStyle = 'rgba(204,85,0,0.25)';
                    ctx.fillRect(cx - 10 * flip, cy + 4, 3, 2);
                }
            }
        },
        
        // Deadlock SLAM — raised fists overhead, ground-pound compression, shockwave
        // 3 frames: f0 = fists raised, f1 = mid-slam, f2 = ground impact + shockwave ring
        deadlock_slam(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const fl = frame % 2;
            // f0: fists raised high. f1: mid-descent. f2: impact + ground cracks
            const raise = frame === 0 ? -8 : frame === 1 ? -3 : 2;
            const squash = frame === 2 ? 2 : 0; // body compresses on impact
            
            ctx.fillStyle = 'rgba(0,0,0,0.45)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 22 + squash, 16 + squash, 6 + squash, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // DOWN — front
                // Legs — braced wide on impact
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 11, cy + 14 + squash, 9, 10);
                ctx.fillRect(cx + 2, cy + 14 + squash, 9, 10);
                ctx.fillStyle = '#5a5a50';
                ctx.fillRect(cx - 10, cy + 16 + squash, 6, 6);
                ctx.fillRect(cx + 4, cy + 16 + squash, 6, 6);
                // Torso — compressed on f2
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 16, cy - 2 + squash, 32, 18 + squash);
                ctx.fillStyle = '#6a6a60';
                ctx.fillRect(cx - 10, cy + 0 + squash, 20, 12 + squash);
                ctx.fillStyle = '#7a7a70';
                ctx.fillRect(cx - 8, cy + 2 + squash, 16, 8);
                ctx.fillStyle = '#999'; // rivets
                ctx.fillRect(cx - 9, cy + 1 + squash, 2, 2);
                ctx.fillRect(cx + 7, cy + 1 + squash, 2, 2);
                // Pauldrons — raised
                ctx.fillStyle = '#5a5a52';
                ctx.fillRect(cx - 20, cy - 6 + raise, 10, 10);
                ctx.fillRect(cx + 10, cy - 6 + raise, 10, 10);
                ctx.fillStyle = '#aaa';
                ctx.fillRect(cx - 16, cy - 2 + raise, 2, 2);
                ctx.fillRect(cx + 14, cy - 2 + raise, 2, 2);
                // Arms — raised high then slam down
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 22, cy - 10 + raise, 8, 20 - raise);
                ctx.fillRect(cx + 14, cy - 10 + raise, 8, 20 - raise);
                ctx.fillStyle = '#6a6a5a'; // bracers
                ctx.fillRect(cx - 21, cy - 6 + raise, 6, 6);
                ctx.fillRect(cx + 15, cy - 6 + raise, 6, 6);
                // Fists — overhead gauntlets, bottom/palm visible when raised
                ctx.fillStyle = '#6a5a4a';
                const slfy = cy - 12 + raise;
                ctx.fillRect(cx - 24, slfy - 4, 12, 8);
                ctx.fillRect(cx + 12, slfy - 4, 12, 8);
                ctx.fillStyle = '#7a6a58'; // knuckle ridges
                ctx.fillRect(cx - 23, slfy - 3, 10, 3);
                ctx.fillRect(cx + 13, slfy - 3, 10, 3);
                ctx.fillStyle = '#555'; // finger curls
                ctx.fillRect(cx - 23, slfy + 4, 3, 3); ctx.fillRect(cx - 19, slfy + 4, 3, 3); ctx.fillRect(cx - 15, slfy + 4, 3, 2);
                ctx.fillRect(cx + 14, slfy + 4, 3, 3); ctx.fillRect(cx + 18, slfy + 4, 3, 3); ctx.fillRect(cx + 22, slfy + 4, 2, 2);
                ctx.fillStyle = '#aaa'; // top studs
                ctx.fillRect(cx - 20, slfy - 3, 2, 2); ctx.fillRect(cx + 17, slfy - 3, 2, 2);
                // Cables
                ctx.fillStyle = '#333';
                ctx.fillRect(cx - 3, cy - 4 + squash, 2, 3);
                ctx.fillRect(cx + 1, cy - 5 + squash, 2, 3);
                // CRT — shakes on impact
                const shake = frame === 2 ? (Math.random() > 0.5 ? 1 : -1) : 0;
                ctx.fillStyle = '#4a4a42';
                ctx.fillRect(cx - 10 + shake, cy - 20 + squash, 20, 16);
                ctx.fillStyle = '#3a3a34';
                ctx.fillRect(cx - 11 + shake, cy - 21 + squash, 22, 2);
                ctx.fillRect(cx - 11 + shake, cy - 5 + squash, 22, 2);
                ctx.fillStyle = '#112211';
                ctx.fillRect(cx - 8 + shake, cy - 18 + squash, 16, 12);
                // Screen static — more intense on impact
                ctx.fillStyle = frame === 2 ? '#55cc55' : '#224422';
                ctx.fillRect(cx - 8 + shake, cy - 17 + fl + squash, 16, 1);
                ctx.fillRect(cx - 8 + shake, cy - 13 + fl + squash, 16, 1);
                ctx.fillStyle = frame === 2 ? '#77ff77' : '#33aa33';
                ctx.fillRect(cx - 4 + fl + shake, cy - 16 + squash, 3, 1);
                ctx.fillRect(cx + 1 + shake, cy - 10 + squash, 4, 1);
                // Fire — flares on impact
                ctx.fillStyle = frame === 2 ? '#ff6600' : '#cc5500';
                ctx.fillRect(cx - 8 + shake, cy - 23 + squash, 5, 5);
                ctx.fillRect(cx + 0 + shake, cy - 24 + squash, 4, 6);
                ctx.fillRect(cx + 5 + shake, cy - 22 + squash, 4, 4);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx - 6 + shake, cy - 26 + squash - fl, 4, 4);
                ctx.fillRect(cx + 1 + shake, cy - 27 + squash - fl, 3, 4);
                ctx.fillRect(cx + 6 + shake, cy - 24 + squash - fl, 3, 3);
                ctx.fillStyle = '#ffcc44';
                ctx.fillRect(cx - 5 + shake, cy - 25 + squash, 2, 2);
                ctx.fillRect(cx + 2 + shake, cy - 26 + squash, 2, 2);
                // Impact shockwave ring on f2
                if (frame === 2) {
                    ctx.strokeStyle = 'rgba(255,102,0,0.4)';
                    ctx.lineWidth = 2;
                    ctx.beginPath(); ctx.ellipse(cx, cy + 20, 22, 8, 0, 0, Math.PI * 2); ctx.stroke();
                    // Ground crack lines
                    ctx.strokeStyle = 'rgba(255,136,34,0.3)';
                    ctx.lineWidth = 1;
                    ctx.beginPath(); ctx.moveTo(cx - 18, cy + 22); ctx.lineTo(cx - 24, cy + 26); ctx.stroke();
                    ctx.beginPath(); ctx.moveTo(cx + 18, cy + 22); ctx.lineTo(cx + 24, cy + 26); ctx.stroke();
                    ctx.beginPath(); ctx.moveTo(cx, cy + 24); ctx.lineTo(cx, cy + 27); ctx.stroke();
                }
            } else if (dir === 2) { // UP — back
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 11, cy + 14 + squash, 9, 10);
                ctx.fillRect(cx + 2, cy + 14 + squash, 9, 10);
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 16, cy - 2 + squash, 32, 18 + squash);
                ctx.fillStyle = '#4a2a1a'; // spine
                ctx.fillRect(cx - 1, cy + 0 + squash, 3, 14);
                ctx.fillStyle = '#6a6a60';
                ctx.fillRect(cx - 8, cy + 2 + squash, 6, 8);
                ctx.fillRect(cx + 2, cy + 2 + squash, 6, 8);
                ctx.fillStyle = '#5a5a52'; // pauldrons
                ctx.fillRect(cx - 20, cy - 6 + raise, 10, 10);
                ctx.fillRect(cx + 10, cy - 6 + raise, 10, 10);
                ctx.fillStyle = '#5a3a28'; // arms
                ctx.fillRect(cx - 22, cy - 10 + raise, 8, 20 - raise);
                ctx.fillRect(cx + 14, cy - 10 + raise, 8, 20 - raise);
                ctx.fillStyle = '#6a5a4a'; // fists — back of gauntlet visible
                const sufy = cy - 12 + raise;
                ctx.fillRect(cx - 24, sufy - 4, 12, 8);
                ctx.fillRect(cx + 12, sufy - 4, 12, 8);
                ctx.fillStyle = '#7a6a58';
                ctx.fillRect(cx - 23, sufy - 3, 10, 3);
                ctx.fillRect(cx + 13, sufy - 3, 10, 3);
                ctx.fillStyle = '#555';
                ctx.fillRect(cx - 23, sufy + 4, 3, 3); ctx.fillRect(cx - 19, sufy + 4, 3, 2);
                ctx.fillRect(cx + 14, sufy + 4, 3, 3); ctx.fillRect(cx + 18, sufy + 4, 3, 2);
                ctx.fillStyle = '#aaa';
                ctx.fillRect(cx - 20, sufy - 3, 2, 2); ctx.fillRect(cx + 17, sufy - 3, 2, 2);
                ctx.fillStyle = '#4a4a42';
                ctx.fillRect(cx - 10, cy - 20 + squash, 20, 16);
                ctx.fillStyle = '#3a3a34';
                ctx.fillRect(cx - 6, cy - 18 + squash, 12, 10);
                ctx.fillStyle = '#2a2a24';
                for (let v = 0; v < 3; v++) ctx.fillRect(cx - 4, cy - 16 + v * 3 + squash, 8, 1);
                // Fire
                ctx.fillStyle = frame === 2 ? '#ff6600' : '#cc5500';
                ctx.fillRect(cx - 7, cy - 23 + squash, 5, 5);
                ctx.fillRect(cx + 1, cy - 24 + squash, 4, 6);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx - 5, cy - 26 + squash - fl, 3, 4);
                ctx.fillRect(cx + 2, cy - 27 + squash - fl, 3, 3);
                ctx.fillStyle = '#ffcc44';
                ctx.fillRect(cx - 4, cy - 25 + squash, 2, 2);
                if (frame === 2) {
                    ctx.strokeStyle = 'rgba(255,102,0,0.4)';
                    ctx.lineWidth = 2;
                    ctx.beginPath(); ctx.ellipse(cx, cy + 20, 22, 8, 0, 0, Math.PI * 2); ctx.stroke();
                }
            } else { // RIGHT(1)/LEFT(3)
                const flip = dir === 3 ? -1 : 1;
                ctx.fillStyle = '#4a3828';
                ctx.fillRect(cx - 5, cy + 14 + squash, 8, 10);
                ctx.fillRect(cx + 1 * flip, cy + 14 + squash, 7, 10);
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx - 12, cy - 2 + squash, 26, 18 + squash);
                ctx.fillStyle = '#6a6a60';
                ctx.fillRect(cx - 3 * flip, cy + 0 + squash, 12, 12);
                ctx.fillStyle = '#5a5a52'; // near shoulder
                ctx.fillRect(cx + 8 * flip, cy - 6 + raise, 8, 10);
                // Arms raised
                ctx.fillStyle = '#5a3a28';
                ctx.fillRect(cx + 10 * flip, cy - 10 + raise, 8, 20 - raise);
                ctx.fillStyle = '#6a5a4a'; // fist — side gauntlet raised
                const ssfy = cy - 12 + raise, ssfx = cx + 14 * flip;
                ctx.fillRect(ssfx - 4, ssfy - 4, 8, 9);
                ctx.fillStyle = '#7a6a58';
                ctx.fillRect(ssfx - 3, ssfy - 3, 6, 3);
                ctx.fillStyle = '#555';
                ctx.fillRect(ssfx - 3, ssfy + 5, 3, 3); ctx.fillRect(ssfx + 1, ssfy + 5, 2, 2);
                ctx.fillStyle = '#aaa';
                ctx.fillRect(ssfx, ssfy - 3, 1, 1);
                // CRT side
                ctx.fillStyle = '#4a4a42';
                ctx.fillRect(cx - 3 * flip, cy - 20 + squash, 10, 16);
                ctx.fillStyle = '#112211';
                ctx.fillRect(cx + 6 * flip, cy - 18 + squash, 3, 10);
                ctx.fillStyle = frame === 2 ? '#55cc55' : '#33aa33';
                ctx.fillRect(cx + 7 * flip, cy - 16 + fl + squash, 1, 1);
                ctx.fillStyle = '#3a3a34';
                ctx.fillRect(cx - 4 * flip, cy - 21 + squash, 12, 2);
                // Fire
                ctx.fillStyle = frame === 2 ? '#ff6600' : '#cc5500';
                ctx.fillRect(cx - 1 * flip, cy - 23 + squash, 4, 5);
                ctx.fillRect(cx + 4 * flip, cy - 24 + squash, 3, 6);
                ctx.fillStyle = '#ff8822';
                ctx.fillRect(cx + 0, cy - 26 + squash - fl, 3, 4);
                ctx.fillRect(cx + 5 * flip, cy - 27 + squash - fl, 2, 3);
                ctx.fillStyle = '#ffcc44';
                ctx.fillRect(cx + 1 * flip, cy - 25 + squash, 2, 2);
                if (frame === 2) {
                    ctx.strokeStyle = 'rgba(255,102,0,0.4)';
                    ctx.lineWidth = 2;
                    ctx.beginPath(); ctx.ellipse(cx, cy + 20, 18, 7, 0, 0, Math.PI * 2); ctx.stroke();
                }
            }
        },
        
        stalker(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const bob = frame === 1 ? -1 : 0;
            const legL = frame === 1 ? 2 : frame === 2 ? -2 : 0;
            const shimmer = frame === 1 ? 0.7 : frame === 2 ? 0.8 : 0.75;
            
            ctx.globalAlpha = shimmer;
            ctx.fillStyle = 'rgba(0,0,0,0.15)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 11, 5, 2, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // Down
                ctx.fillStyle = '#223344';
                ctx.fillRect(cx - 4 + legL, cy + 7 + bob, 3, 6);
                ctx.fillRect(cx + 1 - legL, cy + 7 + bob, 3, 6);
                ctx.fillStyle = '#334455';
                ctx.fillRect(cx - 5, cy - 3 + bob, 10, 12);
                ctx.fillStyle = '#445566';
                ctx.fillRect(cx - 3, cy - 1 + bob, 6, 8);
                // Long arms with claws
                ctx.fillStyle = '#334455';
                ctx.fillRect(cx - 9, cy - 1 + bob, 4, 10);
                ctx.fillRect(cx + 5, cy - 1 + bob, 4, 10);
                ctx.fillStyle = '#88bbdd';
                ctx.fillRect(cx - 10, cy + 8 + bob, 5, 3);
                ctx.fillRect(cx + 5, cy + 8 + bob, 5, 3);
                // Head
                ctx.fillStyle = '#334455';
                ctx.beginPath(); ctx.arc(cx, cy - 7 + bob, 5, 0, Math.PI * 2); ctx.fill();
                // Slit eyes
                ctx.fillStyle = '#44aaff';
                ctx.fillRect(cx - 4, cy - 8 + bob, 3, 1);
                ctx.fillRect(cx + 1, cy - 8 + bob, 3, 1);
            } else if (dir === 2) { // Up
                ctx.fillStyle = '#223344';
                ctx.fillRect(cx - 4 + legL, cy + 7 + bob, 3, 6);
                ctx.fillRect(cx + 1 - legL, cy + 7 + bob, 3, 6);
                ctx.fillStyle = '#334455';
                ctx.fillRect(cx - 5, cy - 3 + bob, 10, 12);
                ctx.fillStyle = '#334455';
                ctx.fillRect(cx - 9, cy - 1 + bob, 4, 10);
                ctx.fillRect(cx + 5, cy - 1 + bob, 4, 10);
                ctx.fillStyle = '#2a3a4a';
                ctx.beginPath(); ctx.arc(cx, cy - 7 + bob, 5, 0, Math.PI * 2); ctx.fill();
            } else { // Right(1)/Left(3)
                const flip = dir === 3 ? -1 : 1;
                ctx.fillStyle = '#223344';
                ctx.fillRect(cx - 1 + legL * flip, cy + 7 + bob, 3, 6);
                ctx.fillRect(cx - 1 - legL * flip, cy + 7 + bob, 3, 6);
                ctx.fillStyle = '#334455';
                ctx.fillRect(cx - 4, cy - 3 + bob, 8, 12);
                ctx.fillStyle = '#334455';
                ctx.fillRect(cx + 2 * flip, cy - 1 + bob, 5, 10);
                ctx.fillStyle = '#88bbdd';
                ctx.fillRect(cx + 3 * flip, cy + 8 + bob, 4, 3);
                ctx.fillStyle = '#334455';
                ctx.beginPath(); ctx.arc(cx + 1 * flip, cy - 7 + bob, 5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#44aaff';
                ctx.fillRect(cx + 3 * flip, cy - 8 + bob, 3, 1);
            }
            ctx.globalAlpha = 1;
        },
        
        // ¾ CAMERA RULE — The Spawn: fleshy/mechanical hovering cube mass
        // Down: front face wide (cube face visible, organic growths, core glow, mechanical seams)
        // Up: back face (vent slits, cable bundles, spine ridge)
        // Side: side face dominant, front compressed sliver
        spawn(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const bob = frame === 0 ? 0 : frame === 1 ? -2 : -1; // hover bob
            const pulse = frame === 1 ? 1.5 : frame === 2 ? 0.5 : 0;
            const cubeY = cy - 6 + bob; // cube floats above center
            const cubeW = 22, cubeH = 20;
            
            // Shadow on ground (stays fixed, doesn't bob)
            ctx.fillStyle = 'rgba(40,20,60,0.3)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 14, 12, 5, 0, 0, Math.PI * 2); ctx.fill();
            // Shadow inner
            ctx.fillStyle = 'rgba(80,40,120,0.15)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 14, 8, 3, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0 || dir === 2) { // Down / Up — front/back face wide
                // Main cube body — dark flesh base
                ctx.fillStyle = '#3a2244';
                ctx.fillRect(cx - cubeW/2, cubeY - cubeH/2, cubeW, cubeH);
                // Top face (foreshortened 3px strip)
                ctx.fillStyle = '#4a3355';
                ctx.fillRect(cx - cubeW/2, cubeY - cubeH/2 - 3, cubeW, 3);
                // Mechanical edge seams
                ctx.fillStyle = '#2a1833';
                ctx.fillRect(cx - cubeW/2, cubeY - cubeH/2, cubeW, 1); // top edge
                ctx.fillRect(cx - cubeW/2, cubeY + cubeH/2 - 1, cubeW, 1); // bottom edge
                ctx.fillRect(cx - cubeW/2, cubeY - cubeH/2, 1, cubeH); // left edge
                ctx.fillRect(cx + cubeW/2 - 1, cubeY - cubeH/2, 1, cubeH); // right edge
                // Cross seams (mechanical bolts)
                ctx.fillStyle = '#5a4466';
                ctx.fillRect(cx - 1, cubeY - cubeH/2, 2, cubeH); // vertical center seam
                ctx.fillRect(cx - cubeW/2, cubeY - 1, cubeW, 2); // horizontal center seam
                // Corner rivets
                ctx.fillStyle = '#7a6688';
                const rivets = [[-9,-8],[9,-8],[-9,8],[9,8]];
                rivets.forEach(([rx, ry]) => { ctx.fillRect(cx + rx, cubeY + ry, 2, 2); });
                
                // Fleshy growths — organic matter clinging to cube surface
                ctx.fillStyle = '#6a3355';
                ctx.fillRect(cx - 8, cubeY + 4, 5, 4); // lower-left growth
                ctx.fillRect(cx + 4, cubeY - 6, 4, 5); // upper-right growth
                ctx.fillStyle = '#7a4466';
                ctx.fillRect(cx - 7, cubeY + 5, 3, 2); // growth highlight
                ctx.fillRect(cx + 5, cubeY - 5, 2, 3);
                // Tendrils hanging from bottom
                ctx.fillStyle = '#5a2244';
                ctx.fillRect(cx - 5, cubeY + cubeH/2, 2, 4 + pulse);
                ctx.fillRect(cx + 3, cubeY + cubeH/2, 2, 3 + pulse);
                ctx.fillRect(cx - 1, cubeY + cubeH/2, 1, 5 + pulse);
                
                // Core glow — pulsing energy at center
                const coreAlpha = 0.5 + pulse * 0.12;
                ctx.fillStyle = `rgba(136,68,204,${coreAlpha})`;
                ctx.beginPath(); ctx.arc(cx, cubeY, 5 + pulse * 0.5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = `rgba(200,140,255,${coreAlpha + 0.15})`;
                ctx.beginPath(); ctx.arc(cx, cubeY, 2.5, 0, Math.PI * 2); ctx.fill();
                // Core inner bright pip
                ctx.fillStyle = '#eeccff';
                ctx.fillRect(cx - 1, cubeY - 1, 2, 2);
                
                if (dir === 2) { // Up — back face differences
                    // Vent slits on back
                    ctx.fillStyle = '#1a0e22';
                    for (let v = 0; v < 3; v++) {
                        ctx.fillRect(cx - 6 + v * 5, cubeY + 3, 3, 1);
                    }
                    // Cable bundle on back
                    ctx.fillStyle = '#4a3355';
                    ctx.fillRect(cx - 2, cubeY - cubeH/2 - 3, 4, 3);
                }
            } else { // Side — side face dominant, front compressed
                const sideW = 18, frontW = 6;
                const fDir = dir === 1 ? 1 : -1; // 1=right, -1=left
                const sideX = cx - (fDir > 0 ? sideW/2 + frontW/2 : sideW/2 - frontW/2);
                
                // Side face (dominant)
                ctx.fillStyle = '#352040';
                ctx.fillRect(cx - sideW/2, cubeY - cubeH/2, sideW, cubeH);
                // Top face strip
                ctx.fillStyle = '#4a3355';
                ctx.fillRect(cx - sideW/2, cubeY - cubeH/2 - 3, sideW, 3);
                // Front sliver
                ctx.fillStyle = '#3a2244';
                ctx.fillRect(cx + fDir * sideW/2, cubeY - cubeH/2, frontW * fDir, cubeH);
                
                // Mechanical seams on side
                ctx.fillStyle = '#2a1833';
                ctx.fillRect(cx - sideW/2, cubeY - 1, sideW, 1);
                ctx.fillStyle = '#5a4466';
                ctx.fillRect(cx - 1, cubeY - cubeH/2, 1, cubeH);
                // Rivets
                ctx.fillStyle = '#7a6688';
                ctx.fillRect(cx - 7, cubeY - 7, 2, 2);
                ctx.fillRect(cx + 5, cubeY + 5, 2, 2);
                
                // Fleshy growth on side face
                ctx.fillStyle = '#6a3355';
                ctx.fillRect(cx - 6, cubeY + 3, 4, 4);
                ctx.fillStyle = '#7a4466';
                ctx.fillRect(cx - 5, cubeY + 4, 2, 2);
                
                // Tendrils
                ctx.fillStyle = '#5a2244';
                ctx.fillRect(cx - 3, cubeY + cubeH/2, 2, 3 + pulse);
                ctx.fillRect(cx + 2, cubeY + cubeH/2, 1, 4 + pulse);
                
                // Core glow — visible from side
                const csAlpha = 0.4 + pulse * 0.1;
                ctx.fillStyle = `rgba(136,68,204,${csAlpha})`;
                ctx.beginPath(); ctx.arc(cx - fDir * 2, cubeY, 4 + pulse * 0.5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = `rgba(200,140,255,${csAlpha + 0.1})`;
                ctx.beginPath(); ctx.arc(cx - fDir * 2, cubeY, 2, 0, Math.PI * 2); ctx.fill();
            }
        },
        
        boss(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const bob = frame === 1 ? -1 : 0;
            const armSwing = frame === 1 ? 3 : frame === 2 ? -3 : 0;
            const pulse = frame === 1 ? 1 : 0;
            
            ctx.fillStyle = 'rgba(0,0,0,0.35)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 24, 18, 8, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // Down
                // Legs
                ctx.fillStyle = '#3a1a4a';
                ctx.fillRect(cx - 10, cy + 18 + bob, 8, 12);
                ctx.fillRect(cx + 2, cy + 18 + bob, 8, 12);
                // Body
                ctx.fillStyle = '#4a2a5a';
                ctx.fillRect(cx - 16, cy - 8 + bob, 32, 28);
                ctx.fillStyle = '#5a3a6a';
                ctx.fillRect(cx - 12, cy - 4 + bob, 24, 8);
                ctx.fillRect(cx - 10, cy + 6 + bob, 20, 8);
                // Glowing core
                ctx.fillStyle = `rgba(170,68,204,${0.6 + pulse * 0.2})`;
                ctx.beginPath(); ctx.arc(cx, cy + 2 + bob, 6 + pulse, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#dd66ff';
                ctx.beginPath(); ctx.arc(cx, cy + 2 + bob, 3, 0, Math.PI * 2); ctx.fill();
                // Arms
                ctx.fillStyle = '#5a3a6a';
                ctx.fillRect(cx - 24, cy - 6 + bob + armSwing, 10, 24);
                ctx.fillRect(cx + 14, cy - 6 + bob - armSwing, 10, 24);
                // Fists
                ctx.fillStyle = '#6a4a7a';
                ctx.fillRect(cx - 26, cy + 16 + bob + armSwing, 12, 10);
                ctx.fillRect(cx + 14, cy + 16 + bob - armSwing, 12, 10);
                // Head
                ctx.fillStyle = '#6a4a7a';
                ctx.fillRect(cx - 10, cy - 20 + bob, 20, 16);
                // Multiple eyes
                ctx.fillStyle = '#1a0a1a';
                ctx.fillRect(cx - 7, cy - 16 + bob, 4, 4);
                ctx.fillRect(cx + 3, cy - 16 + bob, 4, 4);
                ctx.fillRect(cx - 2, cy - 12 + bob, 4, 4);
                ctx.fillStyle = '#ff44ff';
                ctx.fillRect(cx - 6, cy - 15 + bob, 2, 2);
                ctx.fillRect(cx + 4, cy - 15 + bob, 2, 2);
                ctx.fillRect(cx - 1, cy - 11 + bob, 2, 2);
            } else if (dir === 2) { // Up
                ctx.fillStyle = '#3a1a4a';
                ctx.fillRect(cx - 10, cy + 18 + bob, 8, 12);
                ctx.fillRect(cx + 2, cy + 18 + bob, 8, 12);
                ctx.fillStyle = '#4a2a5a';
                ctx.fillRect(cx - 16, cy - 8 + bob, 32, 28);
                ctx.fillStyle = '#3a1a4a';
                ctx.fillRect(cx - 12, cy + 2 + bob, 24, 12);
                ctx.fillStyle = '#5a3a6a';
                ctx.fillRect(cx - 24, cy - 6 + bob - armSwing, 10, 24);
                ctx.fillRect(cx + 14, cy - 6 + bob + armSwing, 10, 24);
                ctx.fillStyle = '#5a3a6a';
                ctx.fillRect(cx - 10, cy - 20 + bob, 20, 16);
            } else { // Right(1)/Left(3)
                const flip = dir === 3 ? -1 : 1;
                ctx.fillStyle = '#3a1a4a';
                ctx.fillRect(cx - 4, cy + 18 + bob, 8, 12);
                ctx.fillStyle = '#4a2a5a';
                ctx.fillRect(cx - 12, cy - 8 + bob, 26, 28);
                ctx.fillStyle = `rgba(170,68,204,${0.6 + pulse * 0.2})`;
                ctx.beginPath(); ctx.arc(cx + 2 * flip, cy + 2 + bob, 5 + pulse, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#5a3a6a';
                ctx.fillRect(cx + 10 * flip, cy - 4 + bob + armSwing, 10, 22);
                ctx.fillStyle = '#6a4a7a';
                ctx.fillRect(cx + 10 * flip, cy + 16 + bob + armSwing, 12, 10);
                ctx.fillStyle = '#6a4a7a';
                ctx.fillRect(cx - 6 + 2 * flip, cy - 20 + bob, 16, 16);
                ctx.fillStyle = '#ff44ff';
                ctx.fillRect(cx + 4 * flip, cy - 15 + bob, 2, 2);
                ctx.fillRect(cx + 4 * flip, cy - 11 + bob, 2, 2);
            }
        },
        
        husk(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            // Jerky uneven movement — lurching gait
            const bob = frame === 1 ? -2 : frame === 2 ? 1 : 0;
            const legL = frame === 1 ? 3 : frame === 2 ? -2 : 0;
            const armSwing = frame === 1 ? 4 : frame === 2 ? -3 : 0;
            const headTilt = frame === 1 ? -0.18 : frame === 2 ? 0.12 : -0.06;
            // Shoulder hunch — one side higher
            const hunchL = -1, hunchR = 1;
            
            // Shadow
            ctx.fillStyle = 'rgba(0,0,0,0.3)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 13, 8, 3, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // Down — ¾ front face, 70% front 30% top
                // Legs — uneven length, one bent wrong
                ctx.fillStyle = '#4a3a32';
                ctx.fillRect(cx - 5 + legL, cy + 5 + bob, 4, 10);
                ctx.fillStyle = '#3e3028';
                ctx.fillRect(cx + 1 - legL, cy + 6 + bob, 4, 11); // longer leg
                // Feet — bare, splayed
                ctx.fillStyle = '#3a2a22';
                ctx.fillRect(cx - 6 + legL, cy + 14 + bob, 6, 2);
                ctx.fillRect(cx - legL, cy + 16 + bob, 6, 2);
                // Body — gaunt torso, shoulders visible (top strip)
                ctx.fillStyle = '#5a4a40';
                ctx.fillRect(cx - 7, cy - 5 + bob, 14, 12);
                // Top of shoulders (foreshortened top face)
                ctx.fillStyle = '#4e4038';
                ctx.fillRect(cx - 8, cy - 6 + bob, 16, 2);
                // Rib cage — visible through stretched skin
                ctx.fillStyle = '#4a3830';
                for (let i = 0; i < 3; i++) {
                    ctx.fillRect(cx - 5, cy - 1 + i * 3 + bob, 10, 1);
                }
                // Cube corruption veins — purple threads
                ctx.fillStyle = 'rgba(130,50,170,0.35)';
                ctx.fillRect(cx + 3, cy - 4 + bob, 1, 10);
                ctx.fillRect(cx - 4, cy + 0 + bob, 1, 7);
                ctx.fillRect(cx - 1, cy + 4 + bob, 5, 1);
                // Arms — too long, hanging past knees, different lengths
                ctx.fillStyle = '#6a5a4e';
                ctx.fillRect(cx - 11, cy - 4 + bob + hunchL + armSwing, 4, 15);
                ctx.fillRect(cx + 7, cy - 3 + bob + hunchR - armSwing, 4, 16); // right arm longer
                // Hands — clawed, bony
                ctx.fillStyle = '#3a2a20';
                ctx.fillRect(cx - 12, cy + 10 + bob + armSwing, 5, 4);
                ctx.fillRect(cx + 7, cy + 12 + bob - armSwing, 5, 4);
                // Claw details
                ctx.fillStyle = '#2a1a14';
                ctx.fillRect(cx - 12, cy + 13 + bob + armSwing, 2, 2);
                ctx.fillRect(cx - 9, cy + 13 + bob + armSwing, 2, 2);
                ctx.fillRect(cx + 7, cy + 15 + bob - armSwing, 2, 2);
                ctx.fillRect(cx + 10, cy + 15 + bob - armSwing, 2, 2);
                // Head — tilted wrong, jaw slack
                ctx.save();
                ctx.translate(cx, cy - 9 + bob);
                ctx.rotate(headTilt);
                // Skull shape — slightly elongated
                ctx.fillStyle = '#6a5a4e';
                ctx.fillRect(-5, -5, 10, 8);
                ctx.beginPath(); ctx.arc(0, -4, 5, Math.PI, 0); ctx.fill();
                // Sunken eye sockets
                ctx.fillStyle = '#1a0a08';
                ctx.fillRect(-4, -3, 3, 3);
                ctx.fillRect(1, -3, 3, 3);
                // Dim red glow deep in sockets
                ctx.fillStyle = '#993322';
                ctx.fillRect(-3, -2, 1, 1);
                ctx.fillRect(2, -2, 1, 1);
                // Mouth — gaping, dark
                ctx.fillStyle = '#1a0a08';
                ctx.fillRect(-3, 2, 6, 3);
                // Teeth fragments
                ctx.fillStyle = '#8a8070';
                ctx.fillRect(-2, 2, 1, 1);
                ctx.fillRect(1, 2, 1, 1);
                ctx.fillRect(3, 3, 1, 1);
                ctx.restore();
            } else if (dir === 2) { // Up — back view, spine + shoulder blades
                ctx.fillStyle = '#4a3a32';
                ctx.fillRect(cx - 5 + legL, cy + 5 + bob, 4, 10);
                ctx.fillRect(cx + 1 - legL, cy + 6 + bob, 4, 11);
                ctx.fillStyle = '#3a2a22';
                ctx.fillRect(cx - 6 + legL, cy + 14 + bob, 6, 2);
                ctx.fillRect(cx - legL, cy + 16 + bob, 6, 2);
                // Body
                ctx.fillStyle = '#50423a';
                ctx.fillRect(cx - 7, cy - 5 + bob, 14, 12);
                // Spine — visible bumps down center
                ctx.fillStyle = '#3e3028';
                for (let i = 0; i < 4; i++) {
                    ctx.fillRect(cx - 1, cy - 4 + i * 3 + bob, 2, 2);
                }
                // Shoulder blades poking through skin
                ctx.fillStyle = '#4a3a30';
                ctx.fillRect(cx - 6, cy - 3 + bob, 3, 4);
                ctx.fillRect(cx + 3, cy - 3 + bob, 3, 4);
                // Cube vein on back
                ctx.fillStyle = 'rgba(130,50,170,0.3)';
                ctx.fillRect(cx + 1, cy - 2 + bob, 1, 8);
                // Arms
                ctx.fillStyle = '#6a5a4e';
                ctx.fillRect(cx - 11, cy - 4 + bob - armSwing, 4, 15);
                ctx.fillRect(cx + 7, cy - 3 + bob + armSwing, 4, 16);
                // Back of head — matted, wrong shape
                ctx.save();
                ctx.translate(cx, cy - 9 + bob);
                ctx.rotate(-headTilt);
                ctx.fillStyle = '#50423a';
                ctx.fillRect(-5, -5, 10, 8);
                ctx.beginPath(); ctx.arc(0, -4, 5, Math.PI, 0); ctx.fill();
                // Patchy hair/tissue
                ctx.fillStyle = '#3a2820';
                ctx.fillRect(-4, -6, 3, 3);
                ctx.fillRect(1, -5, 3, 2);
                ctx.fillRect(-2, -4, 4, 2);
                ctx.restore();
            } else { // Right(1) / Left(3) — side view, depth face dominant
                const flip = dir === 3 ? -1 : 1;
                // Legs — side profile, staggered
                ctx.fillStyle = '#4a3a32';
                ctx.fillRect(cx - 2 + legL * flip, cy + 5 + bob, 4, 10);
                ctx.fillStyle = '#3e3028';
                ctx.fillRect(cx - 2 - legL * flip, cy + 6 + bob, 4, 11);
                // Feet
                ctx.fillStyle = '#3a2a22';
                ctx.fillRect(cx - 2 + legL * flip + flip, cy + 14 + bob, 4, 2);
                // Body — thin side profile
                ctx.fillStyle = '#5a4a40';
                ctx.fillRect(cx - 4, cy - 5 + bob, 8, 12);
                // Side ribs
                ctx.fillStyle = '#4a3830';
                ctx.fillRect(cx - 3, cy - 1 + bob, 6, 1);
                ctx.fillRect(cx - 3, cy + 2 + bob, 6, 1);
                // Cube vein
                ctx.fillStyle = 'rgba(130,50,170,0.35)';
                ctx.fillRect(cx + 1 * flip, cy - 3 + bob, 1, 9);
                // Far arm (behind body)
                ctx.fillStyle = '#5a4a3e';
                ctx.fillRect(cx - 3 * flip, cy - 3 + bob - armSwing, 3, 14);
                // Near arm (in front, longer)
                ctx.fillStyle = '#6a5a4e';
                ctx.fillRect(cx + 2 * flip, cy - 3 + bob + armSwing, 4, 16);
                // Claw
                ctx.fillStyle = '#3a2a20';
                ctx.fillRect(cx + 2 * flip, cy + 12 + bob + armSwing, 4, 4);
                ctx.fillStyle = '#2a1a14';
                ctx.fillRect(cx + 2 * flip, cy + 15 + bob + armSwing, 2, 2);
                ctx.fillRect(cx + 4 * flip, cy + 15 + bob + armSwing, 2, 2);
                // Head — side profile, jaw hanging
                ctx.save();
                ctx.translate(cx + 2 * flip, cy - 9 + bob);
                ctx.rotate(headTilt * flip);
                ctx.fillStyle = '#6a5a4e';
                // Side skull — front narrow sliver, side face dominant
                ctx.fillRect(-3 * flip, -5, 6, 8);
                ctx.beginPath(); ctx.arc(0, -4, 5, 0, Math.PI * 2); ctx.fill();
                // Eye socket (side)
                ctx.fillStyle = '#1a0a08';
                ctx.fillRect(2 * flip, -3, 2, 3);
                ctx.fillStyle = '#993322';
                ctx.fillRect(2 * flip, -2, 1, 1);
                // Jaw — hanging open
                ctx.fillStyle = '#50423a';
                ctx.fillRect(-1, 2, 4, 3);
                ctx.fillStyle = '#1a0a08';
                ctx.fillRect(0, 3, 3, 2);
                ctx.restore();
            }
        },
        
        husk_crawl(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            // Lurching drag — one arm pulls, body follows
            const pull = frame === 1 ? 4 : frame === 2 ? -2 : 1;
            const bodyDrag = frame === 1 ? -1 : frame === 2 ? 1 : 0;
            const headLift = frame === 1 ? -3 : frame === 2 ? 0 : -1;
            
            // Ground blood smear under body
            ctx.fillStyle = 'rgba(60,10,8,0.25)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 5, 10, 5, 0, 0, Math.PI * 2); ctx.fill();
            // Darker center smear
            ctx.fillStyle = 'rgba(80,12,8,0.2)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 6, 6, 3, 0, 0, Math.PI * 2); ctx.fill();
            
            if (dir === 0) { // Down — dragging toward camera, ¾ view
                // === GORE TRAIL — ragged stump where legs were ===
                // Torn flesh hanging
                ctx.fillStyle = '#4a1510';
                ctx.fillRect(cx - 5, cy + 5 + bodyDrag, 3, 4);
                ctx.fillRect(cx - 1, cy + 6 + bodyDrag, 4, 3);
                ctx.fillRect(cx + 2, cy + 4 + bodyDrag, 3, 5);
                // Exposed muscle/innards at tear line
                ctx.fillStyle = '#6a2018';
                ctx.fillRect(cx - 6, cy + 3 + bodyDrag, 12, 3);
                // Wet blood at stump
                ctx.fillStyle = '#551010';
                ctx.fillRect(cx - 4, cy + 5 + bodyDrag, 8, 2);
                
                // === TORSO — same as husk but flat on ground ===
                ctx.fillStyle = '#5a4a40';
                ctx.fillRect(cx - 7, cy - 3 + bodyDrag, 14, 8);
                // Foreshortened top (shoulders visible from above)
                ctx.fillStyle = '#4e4038';
                ctx.fillRect(cx - 8, cy - 4 + bodyDrag, 16, 2);
                // Rib cage pressing through
                ctx.fillStyle = '#4a3830';
                ctx.fillRect(cx - 5, cy - 1 + bodyDrag, 10, 1);
                ctx.fillRect(cx - 5, cy + 2 + bodyDrag, 10, 1);
                // Cube corruption veins — same as husk
                ctx.fillStyle = 'rgba(130,50,170,0.35)';
                ctx.fillRect(cx + 3, cy - 3 + bodyDrag, 1, 7);
                ctx.fillRect(cx - 4, cy + 0 + bodyDrag, 1, 5);
                ctx.fillRect(cx - 1, cy + 3 + bodyDrag, 5, 1);
                
                // === ARMS — same long husk arms, reaching forward, clawing ground ===
                // Left arm reaching
                ctx.fillStyle = '#6a5a4e';
                ctx.fillRect(cx - 11 + pull, cy - 8 + headLift, 4, 8);
                // Right arm pulling
                ctx.fillRect(cx + 6 - pull, cy - 6, 4, 7);
                // Clawed hands digging in — same bony detail as husk
                ctx.fillStyle = '#3a2a20';
                ctx.fillRect(cx - 13 + pull, cy - 9 + headLift, 5, 3);
                ctx.fillRect(cx + 9 - pull, cy - 7, 5, 3);
                // Claw fingers
                ctx.fillStyle = '#2a1a14';
                ctx.fillRect(cx - 14 + pull, cy - 10 + headLift, 2, 2);
                ctx.fillRect(cx - 11 + pull, cy - 10 + headLift, 2, 2);
                ctx.fillRect(cx + 9 - pull, cy - 8, 2, 2);
                ctx.fillRect(cx + 12 - pull, cy - 8, 2, 2);
                
                // === HEAD — lifted, same husk skull, brighter eyes (desperate) ===
                ctx.fillStyle = '#6a5a4e';
                ctx.fillRect(cx - 5, cy - 13 + headLift, 10, 8);
                ctx.beginPath(); ctx.arc(cx, cy - 12 + headLift, 5, Math.PI, 0); ctx.fill();
                // Sunken eye sockets — same as husk but glow brighter
                ctx.fillStyle = '#1a0a08';
                ctx.fillRect(cx - 4, cy - 14 + headLift, 3, 3);
                ctx.fillRect(cx + 1, cy - 14 + headLift, 3, 3);
                // Brighter red glow — more desperate
                ctx.fillStyle = '#dd4433';
                ctx.fillRect(cx - 3, cy - 13 + headLift, 1, 1);
                ctx.fillRect(cx + 2, cy - 13 + headLift, 1, 1);
                // Gaping mouth — jaw wrenched open
                ctx.fillStyle = '#1a0a08';
                ctx.fillRect(cx - 3, cy - 8 + headLift, 6, 3);
                ctx.fillStyle = '#8a8070';
                ctx.fillRect(cx - 2, cy - 8 + headLift, 1, 1);
                ctx.fillRect(cx + 1, cy - 8 + headLift, 1, 1);
                
            } else if (dir === 2) { // Up — dragging away from camera
                // Gore trail visible from behind
                ctx.fillStyle = '#4a1510';
                ctx.fillRect(cx - 4, cy + 4 + bodyDrag, 3, 4);
                ctx.fillRect(cx + 1, cy + 5 + bodyDrag, 3, 3);
                ctx.fillStyle = '#6a2018';
                ctx.fillRect(cx - 6, cy + 3 + bodyDrag, 12, 3);
                ctx.fillStyle = '#551010';
                ctx.fillRect(cx - 3, cy + 5 + bodyDrag, 6, 2);
                // Torso from behind
                ctx.fillStyle = '#50423a';
                ctx.fillRect(cx - 7, cy - 3 + bodyDrag, 14, 8);
                // Spine visible
                ctx.fillStyle = '#3e3028';
                ctx.fillRect(cx - 1, cy - 2 + bodyDrag, 2, 6);
                // Shoulder blades
                ctx.fillStyle = '#4a3a30';
                ctx.fillRect(cx - 6, cy - 2 + bodyDrag, 3, 3);
                ctx.fillRect(cx + 3, cy - 2 + bodyDrag, 3, 3);
                // Cube vein on back
                ctx.fillStyle = 'rgba(130,50,170,0.3)';
                ctx.fillRect(cx + 2, cy - 1 + bodyDrag, 1, 5);
                // Arms reaching forward (away)
                ctx.fillStyle = '#6a5a4e';
                ctx.fillRect(cx - 10 + pull, cy - 7 + headLift, 4, 6);
                ctx.fillRect(cx + 6 - pull, cy - 6, 4, 5);
                // Back of head
                ctx.fillStyle = '#50423a';
                ctx.beginPath(); ctx.arc(cx, cy - 10 + headLift, 5, 0, Math.PI * 2); ctx.fill();
                ctx.fillStyle = '#3a2820';
                ctx.fillRect(cx - 3, cy - 14 + headLift, 6, 3);
                
            } else { // Right(1) / Left(3) — side view dragging
                const flip = dir === 3 ? -1 : 1;
                // Gore trail behind body
                ctx.fillStyle = '#4a1510';
                ctx.fillRect(cx - 7 * flip, cy + 3 + bodyDrag, 5, 3);
                ctx.fillRect(cx - 5 * flip, cy + 5 + bodyDrag, 4, 2);
                ctx.fillStyle = '#6a2018';
                ctx.fillRect(cx - 4 * flip, cy + 2 + bodyDrag, 4, 3);
                ctx.fillStyle = '#551010';
                ctx.fillRect(cx - 3 * flip, cy + 4 + bodyDrag, 3, 2);
                
                // Torso — side profile, same husk proportions flat on ground
                ctx.fillStyle = '#5a4a40';
                ctx.fillRect(cx - 5, cy - 2 + bodyDrag, 10, 6);
                // Side ribs
                ctx.fillStyle = '#4a3830';
                ctx.fillRect(cx - 3, cy - 1 + bodyDrag, 7, 1);
                ctx.fillRect(cx - 3, cy + 2 + bodyDrag, 7, 1);
                // Cube vein
                ctx.fillStyle = 'rgba(130,50,170,0.35)';
                ctx.fillRect(cx + 1 * flip, cy - 2 + bodyDrag, 1, 6);
                
                // Far arm — trailing, limp
                ctx.fillStyle = '#5a4a3e';
                ctx.fillRect(cx - 3 * flip, cy - 3, 3, 5);
                // Near arm — reaching forward, pulling
                ctx.fillStyle = '#6a5a4e';
                ctx.fillRect(cx + 3 * flip + pull * flip, cy - 6 + headLift, 5, 4);
                // Claw on reaching arm
                ctx.fillStyle = '#3a2a20';
                ctx.fillRect(cx + 7 * flip + pull * flip, cy - 7 + headLift, 4, 3);
                ctx.fillStyle = '#2a1a14';
                ctx.fillRect(cx + 10 * flip + pull * flip, cy - 8 + headLift, 2, 2);
                ctx.fillRect(cx + 8 * flip + pull * flip, cy - 8 + headLift, 2, 2);
                
                // Head — side profile, same husk skull
                ctx.fillStyle = '#6a5a4e';
                ctx.beginPath(); ctx.arc(cx + 4 * flip, cy - 8 + headLift, 5, 0, Math.PI * 2); ctx.fill();
                // Eye socket
                ctx.fillStyle = '#1a0a08';
                ctx.fillRect(cx + 6 * flip, cy - 10 + headLift, 2, 3);
                ctx.fillStyle = '#dd4433';
                ctx.fillRect(cx + 6 * flip, cy - 9 + headLift, 1, 1);
                // Jaw hanging open — side view
                ctx.fillStyle = '#50423a';
                ctx.fillRect(cx + 3 * flip, cy - 4 + headLift, 4, 3);
                ctx.fillStyle = '#1a0a08';
                ctx.fillRect(cx + 4 * flip, cy - 3 + headLift, 3, 2);
            }
        },
        
        // Stumble sprite — husk caught off-balance, arms flailing
        husk_stumble(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            // frame 0=FALLING, 1=PRONE (on ground), 2=GETTING UP
            
            if (frame === 0) {
                // === FALLING — body pitching forward, arms reaching out ===
                ctx.fillStyle = 'rgba(0,0,0,0.15)';
                ctx.beginPath(); ctx.ellipse(cx, cy + 13, 9, 3, 0, 0, Math.PI * 2); ctx.fill();
                
                ctx.save();
                ctx.translate(cx, cy);
                
                if (dir === 0) { // Down — falling toward camera
                    ctx.rotate(0.35);
                    // Trailing legs — kicking up behind
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(-5, -12, 4, 8);
                    ctx.fillRect(2, -10, 4, 7);
                    // Torso — pitched forward
                    ctx.fillStyle = '#5a4a40';
                    ctx.fillRect(-7, -4, 14, 10);
                    ctx.fillStyle = '#4e4038';
                    ctx.fillRect(-8, -5, 16, 2); // shoulder strip
                    // Ribs
                    ctx.fillStyle = '#4a3830';
                    ctx.fillRect(-5, 0, 10, 1);
                    ctx.fillRect(-5, 3, 10, 1);
                    // Cube veins
                    ctx.fillStyle = 'rgba(130,50,170,0.35)';
                    ctx.fillRect(3, -3, 1, 8);
                    // Arms — reaching forward to break fall
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(-10, 4, 4, 14);
                    ctx.fillRect(5, 5, 4, 13);
                    // Claw hands reaching
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(-11, 17, 5, 4);
                    ctx.fillRect(5, 17, 5, 4);
                    ctx.fillStyle = '#2a1a10';
                    ctx.fillRect(-12, 18, 2, 2);
                    ctx.fillRect(10, 18, 2, 2);
                    // Head — dipping down
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(-5, 7, 10, 7);
                    ctx.beginPath(); ctx.arc(0, 8, 5, Math.PI, 0); ctx.fill();
                    ctx.fillStyle = '#1a0a08';
                    ctx.fillRect(-3, 10, 6, 3); // gaping mouth
                    ctx.fillStyle = '#993322';
                    ctx.fillRect(-3, 8, 1, 1); // eye glow
                    ctx.fillRect(2, 8, 1, 1);
                } else if (dir === 2) { // Up — falling away from camera
                    ctx.rotate(-0.3);
                    // Legs trailing toward us
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(-5, 5, 4, 8);
                    ctx.fillRect(2, 6, 4, 7);
                    // Torso
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(-7, -5, 14, 11);
                    // Spine bumps
                    ctx.fillStyle = '#3e3028';
                    for (let i = 0; i < 3; i++) ctx.fillRect(-1, -3 + i * 3, 2, 2);
                    // Shoulder blades
                    ctx.fillStyle = '#4a3a30';
                    ctx.fillRect(-6, -3, 3, 4);
                    ctx.fillRect(3, -3, 3, 4);
                    // Arms forward (away from camera)
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(-10, -14, 4, 12);
                    ctx.fillRect(5, -13, 4, 11);
                    // Head pitching away
                    ctx.fillStyle = '#50423a';
                    ctx.beginPath(); ctx.arc(0, -10, 5, 0, Math.PI * 2); ctx.fill();
                    ctx.fillStyle = '#3a2820';
                    ctx.fillRect(-4, -14, 8, 4);
                } else { // Right(1) / Left(3)
                    const flip = dir === 3 ? -1 : 1;
                    ctx.rotate(0.4 * flip);
                    // Legs trailing
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(-2, -10, 4, 8);
                    ctx.fillRect(-2, -8, 4, 6);
                    // Torso
                    ctx.fillStyle = '#5a4a40';
                    ctx.fillRect(-4, -3, 8, 10);
                    ctx.fillStyle = '#4a3830';
                    ctx.fillRect(-3, 1, 6, 1);
                    ctx.fillRect(-3, 4, 6, 1);
                    // Cube veins
                    ctx.fillStyle = 'rgba(130,50,170,0.35)';
                    ctx.fillRect(1 * flip, -2, 1, 8);
                    // Arms reaching forward
                    ctx.fillStyle = '#5a4a3e';
                    ctx.fillRect(-2 * flip, 5, 3, 12);
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(2 * flip, 6, 4, 11);
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(2 * flip, 16, 4, 3);
                    // Head
                    ctx.fillStyle = '#6a5a4e';
                    ctx.beginPath(); ctx.arc(2 * flip, 8, 5, 0, Math.PI * 2); ctx.fill();
                    ctx.fillStyle = '#1a0a08';
                    ctx.fillRect(4 * flip, 6, 2, 3);
                    ctx.fillStyle = '#993322';
                    ctx.fillRect(4 * flip, 7, 1, 1);
                }
                ctx.restore();
                
            } else if (frame === 1) {
                // === PRONE — face-down on ground, seen from ¾ overhead ===
                // Body is WIDE and FLAT — fundamentally different from standing
                ctx.fillStyle = 'rgba(0,0,0,0.12)';
                ctx.beginPath(); ctx.ellipse(cx, cy + 2, 12, 5, 0, 0, Math.PI * 2); ctx.fill();
                
                if (dir === 0) { // Down — face down, head toward camera (bottom)
                    // Body mass — wide flat torso on ground
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(cx - 7, cy - 3, 14, 7); // back surface visible
                    ctx.fillStyle = '#5a4a40';
                    ctx.fillRect(cx - 6, cy - 2, 12, 5); // lighter back
                    // Spine ridge down center
                    ctx.fillStyle = '#3e3028';
                    ctx.fillRect(cx - 1, cy - 3, 2, 7);
                    // Shoulder blades — prominent bumps when prone
                    ctx.fillStyle = '#4a3a30';
                    ctx.fillRect(cx - 5, cy - 2, 3, 3);
                    ctx.fillRect(cx + 2, cy - 2, 3, 3);
                    // Cube veins on back
                    ctx.fillStyle = 'rgba(130,50,170,0.3)';
                    ctx.fillRect(cx + 3, cy - 1, 1, 4);
                    ctx.fillRect(cx - 4, cy + 1, 1, 3);
                    // Arms — splayed out to sides
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(cx - 14, cy - 1, 8, 3);  // left arm
                    ctx.fillRect(cx + 6, cy - 2, 8, 3);   // right arm
                    // Claw hands flat on ground
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(cx - 16, cy - 1, 4, 4);
                    ctx.fillRect(cx + 12, cy - 2, 4, 4);
                    ctx.fillStyle = '#2a1a10';
                    ctx.fillRect(cx - 17, cy, 2, 2);
                    ctx.fillRect(cx + 15, cy - 1, 2, 2);
                    // Legs — trailing behind (toward top of screen = further from camera)
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(cx - 5, cy - 8, 4, 6);
                    ctx.fillRect(cx + 1, cy - 7, 4, 5);
                    ctx.fillStyle = '#3a2a22';
                    ctx.fillRect(cx - 6, cy - 9, 5, 2);   // foot
                    ctx.fillRect(cx + 1, cy - 8, 5, 2);    // foot
                    // Head — face down, top of skull visible (toward bottom of screen)
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(cx - 4, cy + 4, 8, 4);
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(cx - 3, cy + 4, 6, 3);    // top of skull
                    // Matted hair/tissue
                    ctx.fillStyle = '#3a2820';
                    ctx.fillRect(cx - 3, cy + 5, 6, 2);
                } else if (dir === 2) { // Up — face down, head away from camera
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(cx - 7, cy - 3, 14, 7);
                    ctx.fillStyle = '#5a4a40';
                    ctx.fillRect(cx - 6, cy - 2, 12, 5);
                    ctx.fillStyle = '#3e3028';
                    ctx.fillRect(cx - 1, cy - 3, 2, 7);
                    ctx.fillStyle = '#4a3a30';
                    ctx.fillRect(cx - 5, cy - 2, 3, 3);
                    ctx.fillRect(cx + 2, cy - 2, 3, 3);
                    ctx.fillStyle = 'rgba(130,50,170,0.3)';
                    ctx.fillRect(cx + 3, cy - 1, 1, 4);
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(cx - 14, cy, 8, 3);
                    ctx.fillRect(cx + 6, cy - 1, 8, 3);
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(cx - 16, cy, 4, 4);
                    ctx.fillRect(cx + 12, cy - 1, 4, 4);
                    // Legs toward bottom (closer to camera)
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(cx - 5, cy + 4, 4, 6);
                    ctx.fillRect(cx + 1, cy + 5, 4, 5);
                    ctx.fillStyle = '#3a2a22';
                    ctx.fillRect(cx - 6, cy + 9, 5, 2);
                    ctx.fillRect(cx + 1, cy + 9, 5, 2);
                    // Head away — top of skull
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(cx - 4, cy - 7, 8, 4);
                    ctx.fillStyle = '#3a2820';
                    ctx.fillRect(cx - 3, cy - 6, 6, 2);
                } else { // Right(1) / Left(3) — side view of body flat on ground
                    const flip = dir === 3 ? -1 : 1;
                    // ¾ overhead looking at body on ground from side:
                    // Torso has depth (front-to-back visible as height), ribcage curves, hips have mass
                    const headX = cx + 6 * flip;
                    const feetX = cx - 7 * flip;
                    
                    // Shadow under body
                    ctx.fillStyle = 'rgba(0,0,0,0.1)';
                    ctx.beginPath(); ctx.ellipse(cx, cy + 4, 11, 4, 0, 0, Math.PI * 2); ctx.fill();
                    
                    // Legs trailing — two legs, one bent at knee
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(feetX - 2 * flip, cy - 2, 5, 4);       // near leg
                    ctx.fillStyle = '#3e3028';
                    ctx.fillRect(feetX - 4 * flip, cy, 4, 3);           // far leg (behind)
                    ctx.fillStyle = '#3a2a22';
                    ctx.fillRect(feetX - 3 * flip, cy + 3, 4, 2);       // near foot, splayed
                    ctx.fillRect(feetX - 5 * flip, cy + 2, 3, 2);       // far foot
                    
                    // Torso — main body mass, seen from side shows depth
                    // Back surface (top in ¾) — wide strip
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(cx - 6, cy - 4, 12, 9);                // full torso block
                    ctx.fillStyle = '#5a4a40';
                    ctx.fillRect(cx - 5, cy - 3, 10, 7);                // lighter inner
                    // Spine ridge along top edge (back surface)
                    ctx.fillStyle = '#3e3028';
                    ctx.fillRect(cx - 4, cy - 4, 8, 1.5);
                    // Ribcage visible — curved lines on side face
                    ctx.fillStyle = '#4a3830';
                    ctx.fillRect(cx - 4, cy - 1, 8, 1);
                    ctx.fillRect(cx - 3, cy + 1, 7, 1);
                    ctx.fillRect(cx - 2, cy + 3, 6, 1);
                    // Cube veins running along torso
                    ctx.fillStyle = 'rgba(130,50,170,0.3)';
                    ctx.fillRect(cx + 2 * flip, cy - 3, 1, 6);
                    ctx.fillRect(cx - 1 * flip, cy + 1, 1, 3);
                    // Shoulder bump — visible mass at top
                    ctx.fillStyle = '#4a3a30';
                    ctx.fillRect(cx + 2 * flip, cy - 5, 4, 2);
                    // Hip bump — lower body mass
                    ctx.fillStyle = '#4a3a30';
                    ctx.fillRect(cx - 4 * flip, cy + 2, 3, 3);
                    
                    // Near arm — splayed forward, reaching
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(headX - 2 * flip, cy - 4, 6 * flip, 3);    // upper arm
                    ctx.fillRect(headX + 3 * flip, cy - 5, 4 * flip, 3);    // forearm reaching
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(headX + 6 * flip, cy - 5, 3 * flip, 3);    // claw hand
                    ctx.fillStyle = '#2a1a10';
                    ctx.fillRect(headX + 8 * flip, cy - 5, 2, 2);           // claw tips
                    // Far arm — pinned under body, barely visible
                    ctx.fillStyle = '#5a4a3e';
                    ctx.fillRect(cx - 1 * flip, cy + 4, 4, 2);
                    
                    // Head — side profile on ground, cheek pressed down
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(headX, cy - 4, 5 * flip, 6);               // skull side
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(headX + 1 * flip, cy - 3, 3 * flip, 4);    // face area
                    // Eye socket
                    ctx.fillStyle = '#1a0a08';
                    ctx.fillRect(headX + 3 * flip, cy - 3, 2, 2);
                    ctx.fillStyle = '#993322';
                    ctx.fillRect(headX + 3 * flip, cy - 2, 1, 1);           // dim glow
                    // Open jaw pressed against ground
                    ctx.fillStyle = '#1a0a08';
                    ctx.fillRect(headX + 2 * flip, cy + 1, 3, 2);
                }
                
            } else {
                // === GETTING UP — pushing off ground, torso half-risen ===
                ctx.fillStyle = 'rgba(0,0,0,0.18)';
                ctx.beginPath(); ctx.ellipse(cx, cy + 10, 10, 4, 0, 0, Math.PI * 2); ctx.fill();
                
                ctx.save();
                ctx.translate(cx, cy);
                
                if (dir === 0) { // Down — rising toward camera
                    // Legs still on ground
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(-5, 6, 4, 6);
                    ctx.fillRect(2, 7, 4, 5);
                    ctx.fillStyle = '#3a2a22';
                    ctx.fillRect(-6, 11, 5, 2);
                    ctx.fillRect(2, 11, 5, 2);
                    // Lower torso still flat
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(-7, 2, 14, 5);
                    // Upper torso — rising, tilted up
                    ctx.fillStyle = '#5a4a40';
                    ctx.fillRect(-7, -4, 14, 8);
                    ctx.fillStyle = '#4e4038';
                    ctx.fillRect(-8, -5, 16, 2);
                    // Ribs
                    ctx.fillStyle = '#4a3830';
                    ctx.fillRect(-5, -1, 10, 1);
                    ctx.fillRect(-5, 2, 10, 1);
                    // Cube veins
                    ctx.fillStyle = 'rgba(130,50,170,0.35)';
                    ctx.fillRect(3, -3, 1, 7);
                    // Left arm — propping up, bracing on ground
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(-12, -2, 5, 14);
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(-13, 10, 5, 4); // hand flat on ground
                    ctx.fillStyle = '#2a1a10';
                    ctx.fillRect(-14, 11, 2, 2);
                    // Right arm — dangling limp
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(7, -3, 4, 10);
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(7, 6, 5, 3);
                    // Head — lifting, eyes refocusing
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(-5, -12, 10, 8);
                    ctx.beginPath(); ctx.arc(0, -11, 5, Math.PI, 0); ctx.fill();
                    ctx.fillStyle = '#1a0a08';
                    ctx.fillRect(-4, -12, 3, 3);
                    ctx.fillRect(1, -12, 3, 3);
                    ctx.fillStyle = '#993322';
                    ctx.fillRect(-3, -11, 1, 1);
                    ctx.fillRect(2, -11, 1, 1);
                    ctx.fillStyle = '#1a0a08';
                    ctx.fillRect(-3, -6, 6, 3);
                } else if (dir === 2) { // Up — rising, back to camera
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(-5, 7, 4, 5);
                    ctx.fillRect(2, 8, 4, 5);
                    ctx.fillStyle = '#3a2a22';
                    ctx.fillRect(-6, 11, 5, 2);
                    ctx.fillRect(2, 12, 5, 2);
                    // Lower flat
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(-7, 3, 14, 5);
                    // Upper rising
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(-7, -4, 14, 9);
                    ctx.fillStyle = '#3e3028';
                    for (let i = 0; i < 3; i++) ctx.fillRect(-1, -3 + i * 3, 2, 2);
                    ctx.fillStyle = '#4a3a30';
                    ctx.fillRect(-6, -3, 3, 4);
                    ctx.fillRect(3, -3, 3, 4);
                    // Arms — one propping, one dangling
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(-12, -1, 5, 13);
                    ctx.fillRect(7, -2, 4, 9);
                    // Head rising
                    ctx.fillStyle = '#50423a';
                    ctx.beginPath(); ctx.arc(0, -9, 5, 0, Math.PI * 2); ctx.fill();
                    ctx.fillStyle = '#3a2820';
                    ctx.fillRect(-4, -13, 8, 4);
                } else { // Right(1) / Left(3)
                    const flip = dir === 3 ? -1 : 1;
                    // Legs still on ground
                    ctx.fillStyle = '#4a3a32';
                    ctx.fillRect(-3 * flip, 6, 4, 6);
                    ctx.fillRect(-5 * flip, 7, 4, 5);
                    ctx.fillStyle = '#3a2a22';
                    ctx.fillRect(-5 * flip - flip, 11, 4, 2);
                    // Lower torso flat
                    ctx.fillStyle = '#50423a';
                    ctx.fillRect(-3, 3, 6, 5);
                    // Upper rising — torso lifting at angle
                    ctx.save();
                    ctx.rotate(-0.25 * flip);
                    ctx.fillStyle = '#5a4a40';
                    ctx.fillRect(-4, -5, 8, 10);
                    ctx.fillStyle = '#4a3830';
                    ctx.fillRect(-3, -1, 6, 1);
                    ctx.fillRect(-3, 2, 6, 1);
                    ctx.fillStyle = 'rgba(130,50,170,0.35)';
                    ctx.fillRect(1 * flip, -3, 1, 8);
                    // Prop arm — bracing on ground
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(-5 * flip, 2, 3, 11);
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(-5 * flip, 11, 4, 3);
                    // Dangling arm
                    ctx.fillStyle = '#6a5a4e';
                    ctx.fillRect(3 * flip, -2, 4, 8);
                    ctx.fillStyle = '#3a2a20';
                    ctx.fillRect(3 * flip, 5, 4, 3);
                    // Head
                    ctx.fillStyle = '#6a5a4e';
                    ctx.beginPath(); ctx.arc(2 * flip, -8, 5, 0, Math.PI * 2); ctx.fill();
                    ctx.fillStyle = '#1a0a08';
                    ctx.fillRect(4 * flip, -10, 2, 3);
                    ctx.fillStyle = '#993322';
                    ctx.fillRect(4 * flip, -9, 1, 1);
                    ctx.fillStyle = '#1a0a08';
                    ctx.fillRect(1 * flip, -4, 3, 2);
                    ctx.restore();
                }
                ctx.restore();
            }
        },
        
        // === FLICKER — blade-armed tendril creature, no Raumian semblance ===
        // NOTE TO SELF: ¾ CAMERA RULE — side views must be FUNDAMENTALLY DIFFERENT drawings.
        // Side = we see the SIDE FACE (depth/thickness), not a squished front.
        // Near blade shows its FLAT face (wide), far blade shows EDGE (thin line).
        // Torso side shows ribcage depth, spine ridge. Legs show digitigrade bend.
        // Every direction must feel like a full 3D creature viewed from that angle.
        // Stutter built into frame offsets: each frame jitters position/tendrils
        flicker(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            // Stutter jitter per frame — twitchy, broken signal
            const jx = frame === 0 ? -1 : frame === 1 ? 2 : -1;
            const jy = frame === 0 ? 0 : frame === 1 ? -1 : 1;
            const twitchR = frame === 0 ? -0.06 : frame === 1 ? 0.08 : -0.04;
            const ta = frame === 0 ? 0 : frame === 1 ? 3 : -2;
            const tb = frame === 0 ? 2 : frame === 1 ? -1 : 3;
            const legL = frame === 1 ? 2 : frame === 2 ? -2 : 0;
            
            ctx.fillStyle = 'rgba(0,0,0,0.15)';
            ctx.beginPath(); ctx.ellipse(cx + jx, cy + 12, 6, 2.5, 0, 0, Math.PI * 2); ctx.fill();
            
            ctx.save();
            ctx.translate(cx + jx, cy + jy);
            ctx.rotate(twitchR);
            
            if (dir === 0) { // Down — facing camera, front face wide and dominant
                // Digitigrade legs — thin, bent backward, pointed feet
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-4, 4 + legL, 2, 7);
                ctx.fillRect(2, 4 - legL, 2, 7);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-5, 10 + legL, 2, 4);
                ctx.fillRect(3, 10 - legL, 2, 4);
                // Knee joint bumps
                ctx.fillStyle = '#4a3a4e';
                ctx.fillRect(-5, 9 + legL, 3, 2);
                ctx.fillRect(2, 9 - legL, 3, 2);
                // Pointed feet — talons
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(-6, 13 + legL, 2, 2);
                ctx.fillRect(4, 13 - legL, 2, 2);
                ctx.fillRect(-5, 14 + legL, 1, 1);          // talon tip
                ctx.fillRect(4, 14 - legL, 1, 1);
                
                // Torso — narrow, skeletal, dark purple-black
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-4, -4, 8, 10);
                ctx.fillStyle = '#4a3a5a';
                ctx.fillRect(-3, -3, 6, 8);
                // Ribcage ridges — warped, inhuman, curved
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-3, -2, 6, 1);
                ctx.fillRect(-3, 0, 6, 1);
                ctx.fillRect(-3, 2, 6, 1);
                ctx.fillRect(-2, 4, 4, 1);
                // Sternum line
                ctx.fillStyle = '#221833';
                ctx.fillRect(0, -3, 1, 8);
                // Cube fracture veins — bright network
                ctx.fillStyle = 'rgba(136,68,204,0.6)';
                ctx.fillRect(-2, -3, 1, 9);
                ctx.fillRect(2, -1, 1, 7);
                ctx.fillStyle = 'rgba(170,85,238,0.4)';
                ctx.fillRect(0, 0, 3, 1);
                ctx.fillRect(-3, 3, 2, 1);
                ctx.fillRect(1, -2, 2, 1);
                // Shoulder joints — angular bone protrusions
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-6, -4, 3, 3);
                ctx.fillRect(3, -4, 3, 3);
                ctx.fillStyle = '#4a3a5a';
                ctx.fillRect(-5, -3, 2, 2);
                ctx.fillRect(3, -3, 2, 2);
                
                // === LEFT BLADE ARM — crystallized bone-metal ===
                // Upper arm segment
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(-10, -3, 5, 3);
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(-10, -2, 5, 1);               // arm shadow
                // Elbow joint — knobby crystal growth
                ctx.fillStyle = '#5a5a6a';
                ctx.fillRect(-12, -2, 3, 3);
                ctx.fillStyle = '#6a4a8a';
                ctx.fillRect(-12, -1, 1, 1);               // crystal at elbow
                // Blade body — long, serrated edge
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(-14, 0, 4, 11);
                // Inner blade face detail
                ctx.fillStyle = '#555565';
                ctx.fillRect(-13, 1, 2, 9);
                // Edge — bright, sharp
                ctx.fillStyle = '#6a6a7a';
                ctx.fillRect(-14, 0, 1, 11);
                // Serrations along edge
                ctx.fillStyle = '#7a7a8a';
                ctx.fillRect(-15, 1, 1, 2);
                ctx.fillRect(-15, 4, 1, 2);
                ctx.fillRect(-15, 7, 1, 2);
                // Vein network in blade
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(-13, 2, 1, 7);
                ctx.fillStyle = 'rgba(170,85,238,0.35)';
                ctx.fillRect(-12, 4, 1, 3);
                // Crystal facets — bright spots
                ctx.fillStyle = 'rgba(170,102,238,0.4)';
                ctx.fillRect(-12, 1, 1, 1);
                ctx.fillRect(-13, 6, 1, 1);
                // Blade tip — tapered
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(-14, 10, 3, 2);
                ctx.fillRect(-13, 11, 2, 1);
                ctx.fillRect(-12, 12, 1, 1);
                
                // === RIGHT BLADE ARM (mirror) ===
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(5, -3, 5, 3);
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(5, -2, 5, 1);
                ctx.fillStyle = '#5a5a6a';
                ctx.fillRect(9, -2, 3, 3);
                ctx.fillStyle = '#6a4a8a';
                ctx.fillRect(11, -1, 1, 1);
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(10, 0, 4, 11);
                ctx.fillStyle = '#555565';
                ctx.fillRect(11, 1, 2, 9);
                ctx.fillStyle = '#6a6a7a';
                ctx.fillRect(13, 0, 1, 11);
                ctx.fillStyle = '#7a7a8a';
                ctx.fillRect(14, 1, 1, 2);
                ctx.fillRect(14, 4, 1, 2);
                ctx.fillRect(14, 7, 1, 2);
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(12, 2, 1, 7);
                ctx.fillStyle = 'rgba(170,85,238,0.35)';
                ctx.fillRect(11, 4, 1, 3);
                ctx.fillStyle = 'rgba(170,102,238,0.4)';
                ctx.fillRect(11, 1, 1, 1);
                ctx.fillRect(12, 6, 1, 1);
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(11, 10, 3, 2);
                ctx.fillRect(11, 11, 2, 1);
                ctx.fillRect(11, 12, 1, 1);
                
                // Tendril head — mass of writhing tendrils
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -8, 6, 5);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-2, -7, 4, 3);
                // Tendrils — 5 whip-like, different positions per frame
                ctx.fillStyle = '#4a2a6a';
                ctx.fillRect(-4 + ta, -14, 2, 7);
                ctx.fillRect(-1 + tb, -15, 1, 8);
                ctx.fillRect(0, -13, 1, 6);
                ctx.fillRect(1 - tb, -15, 1, 8);
                ctx.fillRect(3 - ta, -14, 2, 7);
                // Tendril tips — glowing
                ctx.fillStyle = 'rgba(170,85,238,0.7)';
                ctx.fillRect(-4 + ta, -15, 1, 2);
                ctx.fillRect(-1 + tb, -16, 1, 2);
                ctx.fillRect(0, -14, 1, 2);
                ctx.fillRect(1 - tb, -16, 1, 2);
                ctx.fillRect(4 - ta, -15, 1, 2);
                // Tendril base texture
                ctx.fillStyle = '#3a1a5a';
                ctx.fillRect(-3, -9, 1, 2);
                ctx.fillRect(2, -9, 1, 2);
                // Core glow where eyes would be
                ctx.fillStyle = 'rgba(136,68,204,0.9)';
                ctx.fillRect(-2, -8, 1, 1);
                ctx.fillRect(1, -8, 1, 1);
                ctx.fillStyle = 'rgba(170,85,238,0.4)';
                ctx.fillRect(-1, -8, 2, 1);
                
            } else if (dir === 2) { // Up — facing away, back visible
                // Legs
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-4, 4 + legL, 2, 7);
                ctx.fillRect(2, 4 - legL, 2, 7);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-5, 10 + legL, 2, 4);
                ctx.fillRect(3, 10 - legL, 2, 4);
                ctx.fillStyle = '#4a3a4e';
                ctx.fillRect(-5, 9 + legL, 3, 2);
                ctx.fillRect(2, 9 - legL, 3, 2);
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(-6, 13 + legL, 2, 2);
                ctx.fillRect(4, 13 - legL, 2, 2);
                
                // Torso back — spine ridge with crystal growths
                ctx.fillStyle = '#352545';
                ctx.fillRect(-4, -4, 8, 10);
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -3, 6, 8);
                // Spine ridge — prominent bony line down center
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-1, -3, 2, 9);
                // Vertebrae bumps
                ctx.fillStyle = '#221833';
                ctx.fillRect(-1, -3, 2, 1);
                ctx.fillRect(-1, -1, 2, 1);
                ctx.fillRect(-1, 1, 2, 1);
                ctx.fillRect(-1, 3, 2, 1);
                ctx.fillRect(-1, 5, 2, 1);
                // Crystal growths sprouting from spine
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(-1, -2, 1, 2);
                ctx.fillRect(0, 2, 1, 2);
                ctx.fillRect(-1, 5, 1, 1);
                ctx.fillStyle = 'rgba(170,85,238,0.35)';
                ctx.fillRect(1, 0, 1, 1);
                ctx.fillRect(-2, 4, 1, 1);
                // Shoulder blades — angular, inhuman
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-4, -3, 2, 4);
                ctx.fillRect(2, -3, 2, 4);
                ctx.fillStyle = '#352545';
                ctx.fillRect(-3, -2, 1, 2);
                ctx.fillRect(2, -2, 1, 2);
                
                // Blade arms from behind — edge visible, not flat
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(-10, -2, 5, 3);
                ctx.fillRect(-12, 0, 3, 2);
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(-13, 1, 3, 9);
                ctx.fillRect(-12, 9, 2, 2);
                ctx.fillRect(-11, 10, 1, 1);
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(5, -2, 5, 3);
                ctx.fillRect(9, 0, 3, 2);
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(10, 1, 3, 9);
                ctx.fillRect(10, 9, 2, 2);
                ctx.fillRect(10, 10, 1, 1);
                // Veins on back-facing blades
                ctx.fillStyle = 'rgba(136,68,204,0.35)';
                ctx.fillRect(-12, 3, 1, 4);
                ctx.fillRect(11, 3, 1, 4);
                
                // Tendril mass from behind — bunched up
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -8, 6, 5);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-2, -7, 4, 3);
                ctx.fillStyle = '#4a2a6a';
                ctx.fillRect(-3 + ta, -13, 2, 6);
                ctx.fillRect(0, -12, 1, 5);
                ctx.fillRect(2 - ta, -13, 2, 6);
                ctx.fillStyle = 'rgba(170,85,238,0.5)';
                ctx.fillRect(-2 + ta, -14, 1, 2);
                ctx.fillRect(0, -13, 1, 2);
                ctx.fillRect(2 - ta, -14, 1, 2);
                
            } else { // Right(1) / Left(3) — SIDE VIEW: different face of the creature
                // ¾ RULE: Side shows torso DEPTH (ribcage curves, spine ridge at back edge),
                // near blade FLAT face (wide 5px), far blade EDGE only (1px behind body).
                // This is a fundamentally different drawing from front view.
                const flip = dir === 3 ? -1 : 1;
                
                // Legs — digitigrade side profile, bend clearly visible
                // Near leg — full side: upper thigh, knee joint, lower leg angled back, talon
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-1 * flip, 3 + legL, 3, 5);   // near upper thigh
                ctx.fillStyle = '#4a3a4e';
                ctx.fillRect(-1 * flip, 7 + legL, 3, 2);    // knee joint bump
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-2 * flip, 8 + legL, 2, 5);    // lower leg angled
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(-3 * flip, 12 + legL, 2, 2);   // talon
                ctx.fillRect(-3 * flip, 13 + legL, 1, 1);   // talon tip
                // Far leg — partially hidden behind body
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(1 * flip, 4 - legL, 2, 5);     // far upper
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(1 * flip, 8 - legL, 2, 5);     // far lower
                ctx.fillRect(0, 12 - legL, 2, 2);           // far talon
                
                // Torso — SIDE FACE: we see the depth/thickness of the body
                // This is ~6px wide (depth) and 10px tall, NOT the 8px-wide front face
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -4, 6, 10);                // body block from side
                ctx.fillStyle = '#4a3a5a';
                ctx.fillRect(-2, -3, 4, 8);                 // lighter inner
                // Ribcage curves visible from side — horizontal arcs
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-2, -2, 4, 1);                 // rib 1
                ctx.fillRect(-2, 0, 4, 1);                  // rib 2
                ctx.fillRect(-2, 2, 4, 1);                  // rib 3
                ctx.fillRect(-1, 4, 3, 1);                  // lower rib
                // Spine ridge along back edge
                ctx.fillStyle = '#221833';
                ctx.fillRect(-3 * flip, -3, 1, 8);          // spine at back
                // Spine bumps
                ctx.fillStyle = '#1a0a28';
                ctx.fillRect(-3 * flip, -2, 1, 1);
                ctx.fillRect(-3 * flip, 0, 1, 1);
                ctx.fillRect(-3 * flip, 2, 1, 1);
                ctx.fillRect(-3 * flip, 4, 1, 1);
                // Crystal growths on spine — small protrusions from back
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(-4 * flip, -1, 1, 2);          // crystal spike
                ctx.fillRect(-4 * flip, 3, 1, 1);           // crystal nub
                // Cube veins visible on side
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(1 * flip, -3, 1, 8);           // main vein
                ctx.fillStyle = 'rgba(170,85,238,0.35)';
                ctx.fillRect(0, 1, 1, 3);                   // branch vein
                // Shoulder joint visible from side
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(2 * flip, -4, 2, 3);
                ctx.fillStyle = '#4a3a5a';
                ctx.fillRect(2 * flip, -3, 1, 2);
                
                // === NEAR BLADE ARM — we see the FLAT FACE of the blade (wide) ===
                // This is the key ¾ rule: from side, blade flat is dominant, 5px wide
                // Upper arm from side
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(3 * flip, -2, 3 * flip, 3);    // upper arm
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(3 * flip, -1, 3 * flip, 1);    // shadow
                // Elbow joint
                ctx.fillStyle = '#5a5a6a';
                ctx.fillRect(5 * flip, 0, 2 * flip, 2);
                ctx.fillStyle = '#6a4a8a';
                ctx.fillRect(6 * flip, 0, 1, 1);            // crystal at elbow
                // Blade — FLAT FACE visible (5px wide, 10px long)
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(4 * flip, 1, 5, 10);           // blade flat face
                // Surface detail on flat — this is the blade's main surface
                ctx.fillStyle = '#555565';
                ctx.fillRect(4 * flip + 1, 2, 3, 8);        // inner surface
                // Fuller groove down center of blade
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(4 * flip + 2, 2, 1, 7);        // fuller/blood groove
                // Edge along forward side
                ctx.fillStyle = '#6a6a7a';
                ctx.fillRect(4 * flip + 4, 1, 1, 10);       // leading edge
                // Serrations on edge
                ctx.fillStyle = '#7a7a8a';
                ctx.fillRect(4 * flip + 5, 2, 1, 1);
                ctx.fillRect(4 * flip + 5, 5, 1, 1);
                ctx.fillRect(4 * flip + 5, 8, 1, 1);
                // Vein network on flat face
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(4 * flip + 1, 3, 1, 5);        // main vein
                ctx.fillStyle = 'rgba(170,85,238,0.35)';
                ctx.fillRect(4 * flip + 3, 5, 1, 3);        // branch
                // Crystal facets — bright spots on flat
                ctx.fillStyle = 'rgba(170,102,238,0.4)';
                ctx.fillRect(4 * flip + 1, 2, 1, 1);
                ctx.fillRect(4 * flip + 3, 7, 1, 1);
                // Blade tip
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(4 * flip + 1, 10, 3, 2);
                ctx.fillRect(4 * flip + 2, 11, 2, 1);
                
                // === FAR BLADE — behind body, only EDGE visible (1px thin line) ===
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(-3 * flip, -1, 1, 9);          // just the edge
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(-3 * flip, 0, 1, 1);           // glint
                
                // Tendrils — side profile, extending forward and up
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-1, -8, 4, 5);                 // neck/anchor mass
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(0, -7, 2, 3);                  // dark center
                ctx.fillStyle = '#4a2a6a';
                ctx.fillRect(1 * flip + ta, -14, 1, 7);     // forward tendril 1
                ctx.fillRect(2 * flip + tb, -13, 1, 6);     // forward tendril 2
                ctx.fillRect(0, -12, 1, 5);                 // center tendril
                ctx.fillRect(-1 * flip - ta, -11, 1, 4);    // back tendril
                // Tips
                ctx.fillStyle = 'rgba(170,85,238,0.7)';
                ctx.fillRect(1 * flip + ta, -15, 1, 2);
                ctx.fillRect(2 * flip + tb, -14, 1, 2);
                // Eye glow — single visible from side
                ctx.fillStyle = 'rgba(136,68,204,0.9)';
                ctx.fillRect(1 * flip, -7, 1, 1);
                ctx.fillStyle = 'rgba(170,85,238,0.4)';
                ctx.fillRect(1 * flip, -8, 1, 1);           // upper glow
            }
            
            ctx.restore();
        },
        
        // === FLICKER ATTACK — wind up triple blade slash ===
        // NOTE: Same ¾ rules apply. Side attack shows blade flat sweeping, not edge.
        // frame 0=WINDUP (blades raised), 1=SLASH (X-cross), 2=FOLLOW-THROUGH
        flicker_attack(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            
            ctx.fillStyle = 'rgba(0,0,0,0.15)';
            ctx.beginPath(); ctx.ellipse(cx, cy + 12, 7, 3, 0, 0, Math.PI * 2); ctx.fill();
            
            ctx.save();
            ctx.translate(cx, cy);
            
            if (dir === 0) { // Down — attacking toward camera
                // Legs planted wide
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-5, 4, 2, 7);
                ctx.fillRect(3, 4, 2, 7);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-6, 10, 2, 4);
                ctx.fillRect(4, 10, 2, 4);
                
                // Torso — tensed, slightly forward
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-4, -3, 8, 9);
                ctx.fillStyle = '#4a3a5a';
                ctx.fillRect(-3, -2, 6, 7);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-3, 0, 6, 1);
                ctx.fillRect(-3, 2, 6, 1);
                ctx.fillStyle = '#221833';
                ctx.fillRect(0, -2, 1, 7);
                ctx.fillStyle = 'rgba(136,68,204,0.7)';
                ctx.fillRect(-2, -2, 1, 8);
                ctx.fillRect(2, 0, 1, 6);
                
                if (frame === 0) {
                    // WINDUP — blades raised high, serrations visible
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(-10, -6, 5, 3);
                    ctx.fillRect(-12, -13, 4, 8);
                    ctx.fillStyle = '#555565';
                    ctx.fillRect(-11, -12, 2, 6);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(-12, -13, 1, 8);
                    ctx.fillStyle = '#7a7a8a';
                    ctx.fillRect(-13, -12, 1, 2);
                    ctx.fillRect(-13, -9, 1, 2);
                    ctx.fillStyle = 'rgba(136,68,204,0.5)';
                    ctx.fillRect(-11, -11, 1, 5);
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(5, -6, 5, 3);
                    ctx.fillRect(8, -13, 4, 8);
                    ctx.fillStyle = '#555565';
                    ctx.fillRect(9, -12, 2, 6);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(11, -13, 1, 8);
                    ctx.fillStyle = '#7a7a8a';
                    ctx.fillRect(12, -12, 1, 2);
                    ctx.fillRect(12, -9, 1, 2);
                    ctx.fillStyle = 'rgba(136,68,204,0.5)';
                    ctx.fillRect(10, -11, 1, 5);
                    // Tendrils flared — anticipation
                    ctx.fillStyle = '#3a2a4a';
                    ctx.fillRect(-3, -7, 6, 4);
                    ctx.fillStyle = '#4a2a6a';
                    ctx.fillRect(-5, -15, 2, 9);
                    ctx.fillRect(-1, -16, 1, 10);
                    ctx.fillRect(1, -16, 1, 10);
                    ctx.fillRect(4, -15, 2, 9);
                    ctx.fillStyle = 'rgba(170,85,238,0.7)';
                    ctx.fillRect(-5, -16, 1, 2);
                    ctx.fillRect(-1, -17, 1, 2);
                    ctx.fillRect(1, -17, 1, 2);
                    ctx.fillRect(5, -16, 1, 2);
                } else if (frame === 1) {
                    // SLASH — blades sweep X-cross, slash trails
                    ctx.fillStyle = 'rgba(136,68,204,0.3)';
                    ctx.fillRect(-12, -8, 24, 2);
                    ctx.fillRect(-10, -6, 20, 2);
                    // Left blade sweeps right-down
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(-6, -4, 4, 3);
                    ctx.fillRect(-2, -2, 13, 3);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(-2, -2, 13, 1);
                    ctx.fillStyle = '#7a7a8a';
                    ctx.fillRect(10, -2, 1, 1);             // tip serration
                    ctx.fillStyle = 'rgba(136,68,204,0.5)';
                    ctx.fillRect(2, -1, 5, 1);
                    // Right blade sweeps left-down
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(2, -4, 4, 3);
                    ctx.fillRect(-11, 0, 13, 3);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(-11, 2, 13, 1);
                    ctx.fillStyle = '#7a7a8a';
                    ctx.fillRect(-11, 0, 1, 1);
                    ctx.fillStyle = 'rgba(136,68,204,0.5)';
                    ctx.fillRect(-7, 1, 5, 1);
                    // Tendrils whipping forward
                    ctx.fillStyle = '#3a2a4a';
                    ctx.fillRect(-3, -7, 6, 4);
                    ctx.fillStyle = '#4a2a6a';
                    ctx.fillRect(-3, -5, 1, 14);
                    ctx.fillRect(0, -5, 1, 16);
                    ctx.fillRect(3, -5, 1, 14);
                    ctx.fillStyle = 'rgba(170,85,238,0.6)';
                    ctx.fillRect(-3, 7, 1, 3);
                    ctx.fillRect(0, 9, 1, 3);
                    ctx.fillRect(3, 7, 1, 3);
                } else {
                    // FOLLOW-THROUGH — blades extended wide
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(-6, -3, 4, 3);
                    ctx.fillRect(-15, 1, 11, 3);
                    ctx.fillStyle = '#555565';
                    ctx.fillRect(-14, 2, 9, 1);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(-15, 3, 11, 1);
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(2, -3, 4, 3);
                    ctx.fillRect(4, 1, 11, 3);
                    ctx.fillStyle = '#555565';
                    ctx.fillRect(5, 2, 9, 1);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(4, 3, 11, 1);
                    // Tendrils settling
                    ctx.fillStyle = '#3a2a4a';
                    ctx.fillRect(-3, -7, 6, 4);
                    ctx.fillStyle = '#4a2a6a';
                    ctx.fillRect(-3, -12, 2, 6);
                    ctx.fillRect(0, -11, 1, 5);
                    ctx.fillRect(2, -12, 2, 6);
                    ctx.fillStyle = 'rgba(170,85,238,0.5)';
                    ctx.fillRect(-3, -13, 1, 2);
                    ctx.fillRect(3, -13, 1, 2);
                }
                ctx.fillStyle = 'rgba(170,85,238,0.9)';
                ctx.fillRect(-2, -7, 1, 1);
                ctx.fillRect(1, -7, 1, 1);
                
            } else if (dir === 2) { // Up — attacking away from camera
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-5, 4, 2, 7);
                ctx.fillRect(3, 4, 2, 7);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-6, 10, 2, 4);
                ctx.fillRect(4, 10, 2, 4);
                
                ctx.fillStyle = '#352545';
                ctx.fillRect(-4, -3, 8, 9);
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -2, 6, 7);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-1, -2, 2, 8);
                
                if (frame === 0) {
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(-10, -5, 5, 3);
                    ctx.fillRect(-12, -12, 4, 8);
                    ctx.fillStyle = '#3a3a4a';
                    ctx.fillRect(-12, -11, 1, 6);
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(5, -5, 5, 3);
                    ctx.fillRect(8, -12, 4, 8);
                    ctx.fillStyle = '#3a3a4a';
                    ctx.fillRect(11, -11, 1, 6);
                    ctx.fillStyle = '#3a2a4a';
                    ctx.fillRect(-3, -7, 6, 4);
                    ctx.fillStyle = '#4a2a6a';
                    ctx.fillRect(-3, -14, 2, 8);
                    ctx.fillRect(0, -13, 1, 7);
                    ctx.fillRect(2, -14, 2, 8);
                } else if (frame === 1) {
                    ctx.fillStyle = 'rgba(136,68,204,0.25)';
                    ctx.fillRect(-12, -7, 24, 2);
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(-4, -3, 3, 3);
                    ctx.fillRect(-2, -1, 13, 3);
                    ctx.fillRect(1, -3, 3, 3);
                    ctx.fillRect(-11, 1, 13, 3);
                    ctx.fillStyle = '#3a2a4a';
                    ctx.fillRect(-3, -7, 6, 4);
                    ctx.fillStyle = '#4a2a6a';
                    ctx.fillRect(-2, -7, 1, 13);
                    ctx.fillRect(0, -7, 1, 14);
                    ctx.fillRect(2, -7, 1, 13);
                } else {
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(-15, 1, 11, 3);
                    ctx.fillRect(4, 1, 11, 3);
                    ctx.fillStyle = '#3a2a4a';
                    ctx.fillRect(-3, -7, 6, 4);
                    ctx.fillStyle = '#4a2a6a';
                    ctx.fillRect(-2, -11, 2, 5);
                    ctx.fillRect(0, -10, 1, 4);
                    ctx.fillRect(1, -11, 2, 5);
                }
                
            } else { // Right(1) / Left(3) — side attack
                // ¾ RULE: Near blade flat face sweeps, far blade edge only
                const flip = dir === 3 ? -1 : 1;
                
                // Legs
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-1, 4, 2, 7);
                ctx.fillRect(0, 4, 2, 7);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-2, 10, 2, 4);
                ctx.fillRect(1, 10, 2, 4);
                
                // Torso side — ribs and spine visible
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -3, 6, 9);
                ctx.fillStyle = '#4a3a5a';
                ctx.fillRect(-2, -2, 4, 7);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-2, -1, 4, 1);
                ctx.fillRect(-2, 1, 4, 1);
                ctx.fillRect(-2, 3, 4, 1);
                ctx.fillStyle = '#221833';
                ctx.fillRect(-3 * flip, -2, 1, 7);          // spine
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(1 * flip, -2, 1, 7);
                
                if (frame === 0) {
                    // Windup — blade flat raised behind, wide visible face
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(2 * flip, -3, 3, 3);       // shoulder
                    // Blade raised — flat face visible (5px wide)
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(3 * flip, -13, 5, 11);
                    ctx.fillStyle = '#555565';
                    ctx.fillRect(3 * flip + 1, -12, 3, 9);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(3 * flip + 4, -13, 1, 11);
                    ctx.fillStyle = '#7a7a8a';
                    ctx.fillRect(3 * flip + 5, -12, 1, 2);
                    ctx.fillRect(3 * flip + 5, -9, 1, 2);
                    ctx.fillStyle = 'rgba(136,68,204,0.5)';
                    ctx.fillRect(3 * flip + 1, -10, 1, 6);
                    // Far blade edge behind
                    ctx.fillStyle = '#3a3a4a';
                    ctx.fillRect(-2 * flip, -2, 1, 8);
                } else if (frame === 1) {
                    // Slash — blade flat sweeping forward
                    ctx.fillStyle = 'rgba(136,68,204,0.25)';
                    ctx.fillRect(0, -6, 12 * flip, 2);
                    // Near blade — flat face visible sweeping
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(2 * flip, -2, 3, 3);
                    ctx.fillRect(4 * flip, -2, 9 * flip, 4);// blade flat sweeping
                    ctx.fillStyle = '#555565';
                    ctx.fillRect(4 * flip + 1, -1, 7, 2);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(4 * flip, -2, 9 * flip, 1);// leading edge
                    ctx.fillStyle = '#7a7a8a';
                    ctx.fillRect(12 * flip, -2, 1, 1);      // tip serration
                    ctx.fillStyle = 'rgba(136,68,204,0.4)';
                    ctx.fillRect(6 * flip, 0, 4, 1);
                    // Far blade edge sweeping under
                    ctx.fillStyle = '#3a3a4a';
                    ctx.fillRect(-1 * flip, 1, 1, 9);
                    // Tendril whip forward
                    ctx.fillStyle = '#4a2a6a';
                    ctx.fillRect(2 * flip, -7, 7 * flip, 1);
                    ctx.fillRect(3 * flip, -6, 5 * flip, 1);
                    ctx.fillStyle = 'rgba(170,85,238,0.6)';
                    ctx.fillRect(8 * flip, -7, 2, 1);
                } else {
                    // Follow-through — blade flat extended past
                    ctx.fillStyle = '#4a4a5a';
                    ctx.fillRect(2 * flip, -1, 3, 3);
                    ctx.fillRect(4 * flip, 1, 9 * flip, 4); // blade flat low
                    ctx.fillStyle = '#555565';
                    ctx.fillRect(4 * flip + 1, 2, 7, 2);
                    ctx.fillStyle = '#6a6a7a';
                    ctx.fillRect(4 * flip, 4, 9 * flip, 1); // edge
                    // Far blade edge
                    ctx.fillStyle = '#3a3a4a';
                    ctx.fillRect(-2 * flip, 0, 1, 7);
                }
                
                // Tendrils (not during frame 1 whip)
                if (frame !== 1) {
                    ctx.fillStyle = '#3a2a4a';
                    ctx.fillRect(-1, -7, 4, 4);
                    ctx.fillStyle = '#4a2a6a';
                    ctx.fillRect(1 * flip, -13, 1, 7);
                    ctx.fillRect(2 * flip, -12, 1, 6);
                    ctx.fillRect(0, -11, 1, 5);
                    ctx.fillStyle = 'rgba(170,85,238,0.7)';
                    ctx.fillRect(1 * flip, -14, 1, 2);
                }
                ctx.fillStyle = 'rgba(170,85,238,0.9)';
                ctx.fillRect(1 * flip, -7, 1, 1);
            }
            
            ctx.restore();
        },
        
        // === FLICKER MAIMED — blades severed, acid dripping from stumps ===
        // NOTE: ¾ CAMERA RULE applies. Side shows torso depth, stump cross-sections.
        // No blades. Arm stumps are ragged, leaking green-purple acid.
        flicker_maimed(ctx, s, dir, frame) {
            const cx = s/2, cy = s/2;
            const jx = frame === 0 ? -1 : frame === 1 ? 2 : -1;
            const jy = frame === 0 ? 0 : frame === 1 ? -1 : 1;
            const twitchR = frame === 0 ? -0.08 : frame === 1 ? 0.1 : -0.06; // more erratic without arms
            const ta = frame === 0 ? 0 : frame === 1 ? 3 : -2;
            const tb = frame === 0 ? 2 : frame === 1 ? -1 : 3;
            const legL = frame === 1 ? 2 : frame === 2 ? -2 : 0;
            // Acid drip variation per frame
            const dripY = frame === 0 ? 2 : frame === 1 ? 5 : 0;
            const dripX = frame === 0 ? 0 : frame === 1 ? 1 : -1;
            
            ctx.fillStyle = 'rgba(0,0,0,0.15)';
            ctx.beginPath(); ctx.ellipse(cx + jx, cy + 12, 6, 2.5, 0, 0, Math.PI * 2); ctx.fill();
            
            ctx.save();
            ctx.translate(cx + jx, cy + jy);
            ctx.rotate(twitchR);
            
            if (dir === 0) { // Down — facing camera
                // Legs
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-4, 4 + legL, 2, 7);
                ctx.fillRect(2, 4 - legL, 2, 7);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-5, 10 + legL, 2, 4);
                ctx.fillRect(3, 10 - legL, 2, 4);
                ctx.fillStyle = '#4a3a4e';
                ctx.fillRect(-5, 9 + legL, 3, 2);
                ctx.fillRect(2, 9 - legL, 3, 2);
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(-6, 13 + legL, 2, 2);
                ctx.fillRect(4, 13 - legL, 2, 2);
                
                // Torso — same as flicker but more damaged
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-4, -4, 8, 10);
                ctx.fillStyle = '#4a3a5a';
                ctx.fillRect(-3, -3, 6, 8);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-3, -2, 6, 1);
                ctx.fillRect(-3, 0, 6, 1);
                ctx.fillRect(-3, 2, 6, 1);
                ctx.fillStyle = '#221833';
                ctx.fillRect(0, -3, 1, 8);
                ctx.fillStyle = 'rgba(136,68,204,0.6)';
                ctx.fillRect(-2, -3, 1, 9);
                ctx.fillRect(2, -1, 1, 7);
                // Damage — cracks where arms were torn
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(-4, -3, 1, 3);
                ctx.fillRect(3, -3, 1, 3);
                
                // Shoulder joints — torn, exposed
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-6, -4, 3, 3);
                ctx.fillRect(3, -4, 3, 3);
                
                // === LEFT ARM STUMP — ragged break, dripping acid ===
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(-8, -3, 3, 3);                 // upper arm remnant
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(-9, -2, 2, 2);                 // broken end
                // Exposed cross-section — bone and crystal
                ctx.fillStyle = '#5a5a6a';
                ctx.fillRect(-9, -2, 1, 1);                 // bone core
                ctx.fillStyle = 'rgba(136,68,204,0.7)';
                ctx.fillRect(-9, -1, 1, 1);                 // crystal in break
                // Acid drip — green-purple fluid
                ctx.fillStyle = 'rgba(80,180,60,0.6)';
                ctx.fillRect(-9 + dripX, 0 + dripY, 1, 3);  // drip strand
                ctx.fillStyle = 'rgba(100,200,80,0.4)';
                ctx.fillRect(-9 + dripX, 2 + dripY, 2, 1);  // drip bulge
                ctx.fillRect(-8, 1, 1, 2);                  // seeping from stump
                
                // === RIGHT ARM STUMP (mirror) ===
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(5, -3, 3, 3);
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(7, -2, 2, 2);
                ctx.fillStyle = '#5a5a6a';
                ctx.fillRect(8, -2, 1, 1);
                ctx.fillStyle = 'rgba(136,68,204,0.7)';
                ctx.fillRect(8, -1, 1, 1);
                ctx.fillStyle = 'rgba(80,180,60,0.6)';
                ctx.fillRect(8 - dripX, 0 + dripY, 1, 3);
                ctx.fillStyle = 'rgba(100,200,80,0.4)';
                ctx.fillRect(8 - dripX, 2 + dripY, 2, 1);
                ctx.fillRect(7, 1, 1, 2);
                
                // Tendrils — more agitated without arms
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -8, 6, 5);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-2, -7, 4, 3);
                ctx.fillStyle = '#4a2a6a';
                ctx.fillRect(-4 + ta, -14, 2, 7);
                ctx.fillRect(-1 + tb, -15, 1, 8);
                ctx.fillRect(0, -13, 1, 6);
                ctx.fillRect(1 - tb, -15, 1, 8);
                ctx.fillRect(3 - ta, -14, 2, 7);
                // Extra agitated tendrils — flailing wider
                ctx.fillRect(-5 + tb, -12, 1, 5);
                ctx.fillRect(5 - tb, -12, 1, 5);
                ctx.fillStyle = 'rgba(170,85,238,0.7)';
                ctx.fillRect(-4 + ta, -15, 1, 2);
                ctx.fillRect(-1 + tb, -16, 1, 2);
                ctx.fillRect(0, -14, 1, 2);
                ctx.fillRect(1 - tb, -16, 1, 2);
                ctx.fillRect(4 - ta, -15, 1, 2);
                // Eyes — brighter, panicked
                ctx.fillStyle = 'rgba(170,85,238,1.0)';
                ctx.fillRect(-2, -8, 1, 1);
                ctx.fillRect(1, -8, 1, 1);
                ctx.fillStyle = 'rgba(200,120,255,0.5)';
                ctx.fillRect(-1, -8, 2, 1);
                
            } else if (dir === 2) { // Up — back view
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-4, 4 + legL, 2, 7);
                ctx.fillRect(2, 4 - legL, 2, 7);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-5, 10 + legL, 2, 4);
                ctx.fillRect(3, 10 - legL, 2, 4);
                ctx.fillStyle = '#4a3a4e';
                ctx.fillRect(-5, 9 + legL, 3, 2);
                ctx.fillRect(2, 9 - legL, 3, 2);
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(-6, 13 + legL, 2, 2);
                ctx.fillRect(4, 13 - legL, 2, 2);
                
                ctx.fillStyle = '#352545';
                ctx.fillRect(-4, -4, 8, 10);
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -3, 6, 8);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-1, -3, 2, 9);
                ctx.fillStyle = '#221833';
                ctx.fillRect(-1, -3, 2, 1);
                ctx.fillRect(-1, -1, 2, 1);
                ctx.fillRect(-1, 1, 2, 1);
                ctx.fillRect(-1, 3, 2, 1);
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(-1, -2, 1, 2);
                ctx.fillRect(0, 2, 1, 2);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-4, -3, 2, 4);
                ctx.fillRect(2, -3, 2, 4);
                
                // Arm stumps from behind
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(-8, -2, 3, 3);
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(-9, -1, 2, 2);
                ctx.fillStyle = 'rgba(80,180,60,0.5)';
                ctx.fillRect(-9 + dripX, 1, 1, 2 + dripY);
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(5, -2, 3, 3);
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(7, -1, 2, 2);
                ctx.fillStyle = 'rgba(80,180,60,0.5)';
                ctx.fillRect(8 - dripX, 1, 1, 2 + dripY);
                
                // Tendrils bunched
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -8, 6, 5);
                ctx.fillStyle = '#4a2a6a';
                ctx.fillRect(-3 + ta, -13, 2, 6);
                ctx.fillRect(0, -12, 1, 5);
                ctx.fillRect(2 - ta, -13, 2, 6);
                ctx.fillRect(-4 + tb, -11, 1, 4);
                ctx.fillRect(4 - tb, -11, 1, 4);
                ctx.fillStyle = 'rgba(170,85,238,0.5)';
                ctx.fillRect(-2 + ta, -14, 1, 2);
                ctx.fillRect(0, -13, 1, 2);
                ctx.fillRect(2 - ta, -14, 1, 2);
                
            } else { // Right(1) / Left(3) — SIDE: stump cross-section visible
                const flip = dir === 3 ? -1 : 1;
                
                // Legs side profile
                ctx.fillStyle = '#3a2a3e';
                ctx.fillRect(-1 * flip, 3 + legL, 3, 5);
                ctx.fillStyle = '#4a3a4e';
                ctx.fillRect(-1 * flip, 7 + legL, 3, 2);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(-2 * flip, 8 + legL, 2, 5);
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(-3 * flip, 12 + legL, 2, 2);
                ctx.fillStyle = '#2a1a2e';
                ctx.fillRect(1 * flip, 4 - legL, 2, 5);
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(1 * flip, 8 - legL, 2, 5);
                ctx.fillRect(0, 12 - legL, 2, 2);
                
                // Torso SIDE FACE — depth with ribs and spine
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-3, -4, 6, 10);
                ctx.fillStyle = '#4a3a5a';
                ctx.fillRect(-2, -3, 4, 8);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(-2, -2, 4, 1);
                ctx.fillRect(-2, 0, 4, 1);
                ctx.fillRect(-2, 2, 4, 1);
                ctx.fillRect(-1, 4, 3, 1);
                ctx.fillStyle = '#221833';
                ctx.fillRect(-3 * flip, -3, 1, 8);
                ctx.fillStyle = '#1a0a28';
                ctx.fillRect(-3 * flip, -2, 1, 1);
                ctx.fillRect(-3 * flip, 0, 1, 1);
                ctx.fillRect(-3 * flip, 2, 1, 1);
                ctx.fillStyle = 'rgba(136,68,204,0.5)';
                ctx.fillRect(1 * flip, -3, 1, 8);
                // Damage at shoulder
                ctx.fillStyle = '#1a0a1e';
                ctx.fillRect(2 * flip, -4, 1, 3);
                
                // === NEAR ARM STUMP — cross-section visible from side ===
                // Upper arm remnant, then ragged break showing circular bone/crystal cross-section
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(3 * flip, -2, 2, 3);           // short upper arm remnant
                // Cross-section at break — circular bone, inner crystal
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(4 * flip, 0, 3, 3);            // break face
                ctx.fillStyle = '#5a5a6a';
                ctx.fillRect(5 * flip, 0, 2, 2);            // bone ring
                ctx.fillStyle = '#4a4a5a';
                ctx.fillRect(5 * flip, 1, 1, 1);            // marrow
                ctx.fillStyle = 'rgba(136,68,204,0.7)';
                ctx.fillRect(6 * flip, 0, 1, 1);            // crystal in cross-section
                // Acid dripping from stump
                ctx.fillStyle = 'rgba(80,180,60,0.6)';
                ctx.fillRect(5 * flip + dripX, 2 + dripY, 1, 3);
                ctx.fillStyle = 'rgba(100,200,80,0.4)';
                ctx.fillRect(5 * flip, 3, 1, 2);            // seeping
                ctx.fillRect(4 * flip, 2, 1, 1);            // drip on arm
                
                // Far stump — just the break edge visible behind body
                ctx.fillStyle = '#3a3a4a';
                ctx.fillRect(-3 * flip, -1, 1, 3);
                ctx.fillStyle = 'rgba(80,180,60,0.4)';
                ctx.fillRect(-3 * flip, 2, 1, 2 + dripY);
                
                // Tendrils — agitated, from side
                ctx.fillStyle = '#3a2a4a';
                ctx.fillRect(-1, -8, 4, 5);
                ctx.fillStyle = '#2a1a3a';
                ctx.fillRect(0, -7, 2, 3);
                ctx.fillStyle = '#4a2a6a';
                ctx.fillRect(1 * flip + ta, -14, 1, 7);
                ctx.fillRect(2 * flip + tb, -13, 1, 6);
                ctx.fillRect(0, -12, 1, 5);
                ctx.fillRect(-1 * flip - ta, -11, 1, 4);
                ctx.fillRect(-2 * flip + tb, -10, 1, 3);    // extra agitated tendril
                ctx.fillStyle = 'rgba(170,85,238,0.7)';
                ctx.fillRect(1 * flip + ta, -15, 1, 2);
                ctx.fillRect(2 * flip + tb, -14, 1, 2);
                ctx.fillStyle = 'rgba(170,85,238,1.0)';
                ctx.fillRect(1 * flip, -7, 1, 1);
                ctx.fillStyle = 'rgba(200,120,255,0.5)';
                ctx.fillRect(1 * flip, -8, 1, 1);
            }
            
            ctx.restore();
        }
    },
    
    // Get or create a sprite texture
    getTexture(scene, key) {
        if (!scene.textures.exists(key)) {
            this.createFallback(scene, key);
        }
        return key;
    },
    
    // Create a sprite with fallback
    createSprite(scene, x, y, key, group = null) {
        this.getTexture(scene, key);
        const sprite = scene.physics.add.sprite(x, y, key);
        if (group) group.add(sprite);
        return sprite;
    },
    
    // Create player vehicle (side view for traversal, top view for safehouse/gamescene)
    createVehicle(scene, x, y, view = 'side', mods = null) {
        const container = scene.add.container(x, y);
        
        // Get vehicle color from customization
        const vehId = (SpriteManager.playerCustomization && SpriteManager.playerCustomization.vehicle) || 'blue';
        const vehDef = CONFIG.customization.vehicleColors.find(c => c.id === vehId) || CONFIG.customization.vehicleColors[0];

        // === NEW: Use fleet spritesheet for the base vehicle ===
        VehicleFleet.registerTextures(scene);
        // Player vehicle is a pickup, facing right for both side and iso views
        const dir = (view === 'side') ? 'right' : 'right';
        const baseSprite = scene.add.sprite(0, 0, 'fleet_all', VehicleFleet.getFrame('pickup', dir, false));
        container.add(baseSprite);
        // Store reference for frame swapping if needed
        container._fleetSprite = baseSprite;
        container._fleetType = 'pickup';
        
        const bodyMain = parseInt(vehDef.body.replace('#', ''), 16);
        const bodyDark = parseInt(vehDef.dark.replace('#', ''), 16);
        const bodyLight = parseInt(vehDef.light.replace('#', ''), 16);
        const windowColor = 0x2a3a4a;
        const wheelColor = 0x1a1a1a;
        const metalColor = 0x3a3a3a;
        
        // Load mods from save data if not provided
        if (!mods) {
            try { mods = SaveManager.load().vehicle?.mods || {}; } catch(e) { mods = {}; }
        }
        const armorTier = (mods.armor !== undefined && mods.armor >= 0) ? mods.armor : -1;
        const weaponTier = (mods.weapon !== undefined && mods.weapon >= 0) ? mods.weapon : -1;
        const fuelTier = (mods.fuel !== undefined && mods.fuel >= 0) ? mods.fuel : -1;
        const utilityTier = (mods.utility !== undefined && mods.utility >= 0) ? mods.utility : -1;
        
        if (view === 'side') {
            // Base vehicle is now the fleet sprite above
            
            // === VEHICLE MODS — SIDE VIEW ===
            // ARMOR PLATING
            if (armorTier >= 0) {
                const ac = [0x4a4a4a, 0x5a5a5a, 0x6a6a7a, 0x7a7a8a][armorTier];
                // Front fender plate
                container.add(scene.add.rectangle(18, 6, 8, 6, ac));
                container.add(scene.add.rectangle(18, 4, 7, 2, ac + 0x111111));
                // Rear fender plate
                container.add(scene.add.rectangle(-18, 6, 8, 6, ac));
                container.add(scene.add.rectangle(-18, 4, 7, 2, ac + 0x111111));
                // Door panel reinforcement
                container.add(scene.add.rectangle(0, 4, 20, 3, ac, 0.7));
                if (armorTier >= 2) {
                    // Side skirt
                    container.add(scene.add.rectangle(0, 8, 40, 3, ac));
                    container.add(scene.add.rectangle(0, 7, 38, 1, ac + 0x111111));
                }
                if (armorTier >= 3) {
                    // Bull bar
                    container.add(scene.add.rectangle(30, 4, 3, 12, 0x5a5a5a));
                    container.add(scene.add.rectangle(31, 0, 2, 6, 0x6a6a6a));
                }
            }
            
            // WEAPON MOUNT
            if (weaponTier >= 0) {
                const wc = [0x4a4a44, 0x5a5a54, 0x6a6a64, 0x7a7a74][weaponTier];
                // Roof mount base
                container.add(scene.add.rectangle(-2, -18, 10, 3, 0x3a3a3a));
                container.add(scene.add.rectangle(-2, -19, 8, 1, 0x4a4a4a));
                // Gun barrel
                const barrelLen = 8 + weaponTier * 4;
                container.add(scene.add.rectangle(-2 + barrelLen/2, -20, barrelLen, 3, wc));
                container.add(scene.add.rectangle(-2 + barrelLen/2, -21, barrelLen - 2, 1, wc + 0x111111));
                if (weaponTier >= 2) {
                    // Muzzle brake
                    container.add(scene.add.rectangle(-2 + barrelLen + 1, -20, 3, 5, 0x3a3a3a));
                }
                if (weaponTier >= 3) {
                    // Second barrel
                    container.add(scene.add.rectangle(-2 + barrelLen/2, -23, barrelLen - 2, 2, wc));
                }
            }
            
            // FUEL TANK
            if (fuelTier >= 0) {
                const tankW = 6 + fuelTier * 2;
                const tankH = 6 + fuelTier;
                // Tank body strapped to rear
                container.add(scene.add.rectangle(-26 - tankW/2, 4, tankW, tankH, 0x445544));
                container.add(scene.add.rectangle(-26 - tankW/2, 3, tankW - 2, 2, 0x556655));
                // Strap
                container.add(scene.add.rectangle(-26 - tankW/2, 1, tankW + 2, 1, 0x3a3a3a));
                container.add(scene.add.rectangle(-26 - tankW/2, 7, tankW + 2, 1, 0x3a3a3a));
                // Cap
                container.add(scene.add.circle(-26 - tankW/2, 0, 2, 0x666666));
            }
            
            // UTILITY RACK
            if (utilityTier >= 0) {
                // Roof rack bars
                container.add(scene.add.rectangle(-2, -17, 26, 1, 0x4a4a3a));
                container.add(scene.add.rectangle(-10, -17, 2, 3, 0x3a3a2a));
                container.add(scene.add.rectangle(6, -17, 2, 3, 0x3a3a2a));
                if (utilityTier >= 1) {
                    // Cargo bag
                    container.add(scene.add.rectangle(-6, -20, 14, 4, 0x5a4a3a));
                    container.add(scene.add.rectangle(-6, -21, 12, 2, 0x6a5a4a));
                }
                if (utilityTier >= 2) {
                    // Side bags
                    container.add(scene.add.rectangle(-22, 0, 5, 8, 0x5a4a3a));
                    container.add(scene.add.rectangle(-22, -1, 4, 2, 0x6a5a4a));
                }
                if (utilityTier >= 3) {
                    // Rear cargo box
                    container.add(scene.add.rectangle(-30, -2, 6, 10, 0x5a4a3a));
                    container.add(scene.add.rectangle(-30, -3, 5, 2, 0x6a5a4a));
                }
            }
            
        } else if (view === 'iso') {
            // Base vehicle is now the fleet sprite above
            
            // === VEHICLE MODS — ISO VIEW ===
            // ARMOR PLATING
            if (armorTier >= 0) {
                const ac = [0x4a4a4a, 0x5a5a5a, 0x6a6a7a, 0x7a7a8a][armorTier];
                // Front fender armor
                container.add(scene.add.rectangle(16, 8, 8, 5, ac));
                container.add(scene.add.rectangle(16, 6, 7, 2, ac + 0x111111));
                // Rear fender armor
                container.add(scene.add.rectangle(-18, 8, 8, 5, ac));
                container.add(scene.add.rectangle(-18, 6, 7, 2, ac + 0x111111));
                // Side plate
                container.add(scene.add.rectangle(0, 6, 22, 3, ac, 0.7));
                if (armorTier >= 2) {
                    // Running board armor
                    container.add(scene.add.rectangle(0, 10, 38, 2, ac));
                    container.add(scene.add.rectangle(0, 9, 36, 1, ac + 0x111111));
                }
                if (armorTier >= 3) {
                    // Bull bar
                    container.add(scene.add.rectangle(29, 6, 3, 10, 0x5a5a5a));
                    container.add(scene.add.rectangle(30, 2, 2, 5, 0x6a6a6a));
                }
            }
            
            // WEAPON MOUNT
            if (weaponTier >= 0) {
                const wc = [0x4a4a44, 0x5a5a54, 0x6a6a64, 0x7a7a74][weaponTier];
                // Turret base on roof
                container.add(scene.add.rectangle(-2, -15, 10, 4, 0x3a3a3a));
                container.add(scene.add.rectangle(-2, -16, 8, 2, 0x4a4a4a));
                // Gun barrel pointing right (forward)
                const barrelLen = 10 + weaponTier * 4;
                container.add(scene.add.rectangle(-2 + barrelLen/2, -17, barrelLen, 3, wc));
                container.add(scene.add.rectangle(-2 + barrelLen/2, -18, barrelLen - 2, 1, wc + 0x111111));
                if (weaponTier >= 2) {
                    container.add(scene.add.rectangle(-2 + barrelLen + 1, -17, 3, 5, 0x3a3a3a));
                }
                if (weaponTier >= 3) {
                    container.add(scene.add.rectangle(-2 + barrelLen/2, -20, barrelLen - 2, 2, wc));
                }
            }
            
            // FUEL TANK
            if (fuelTier >= 0) {
                const tw = 6 + fuelTier * 2;
                const th = 5 + fuelTier;
                // Tank strapped to rear quarter
                container.add(scene.add.rectangle(-25 - tw/2, 6, tw, th, 0x445544));
                container.add(scene.add.rectangle(-25 - tw/2, 5, tw - 2, 2, 0x556655));
                // Straps
                container.add(scene.add.rectangle(-25 - tw/2, 3, tw + 2, 1, 0x3a3a3a));
                container.add(scene.add.rectangle(-25 - tw/2, 9, tw + 2, 1, 0x3a3a3a));
                container.add(scene.add.circle(-25 - tw/2, 2, 2, 0x666666));
            }
            
            // UTILITY RACK
            if (utilityTier >= 0) {
                // Roof rack crossbars
                container.add(scene.add.rectangle(-2, -14, 24, 1, 0x4a4a3a));
                container.add(scene.add.rectangle(-8, -14, 2, 3, 0x3a3a2a));
                container.add(scene.add.rectangle(4, -14, 2, 3, 0x3a3a2a));
                if (utilityTier >= 1) {
                    // Duffel bag on roof
                    container.add(scene.add.rectangle(-4, -17, 12, 4, 0x5a4a3a));
                    container.add(scene.add.rectangle(-4, -18, 10, 2, 0x6a5a4a));
                }
                if (utilityTier >= 2) {
                    // Side panniers
                    container.add(scene.add.rectangle(-20, 2, 4, 8, 0x5a4a3a));
                    container.add(scene.add.rectangle(-20, 1, 3, 2, 0x6a5a4a));
                }
                if (utilityTier >= 3) {
                    // Rear cargo crate
                    container.add(scene.add.rectangle(-28, 0, 5, 10, 0x5a4a3a));
                    container.add(scene.add.rectangle(-28, -1, 4, 2, 0x6a5a4a));
                    // Rope detail
                    container.add(scene.add.rectangle(-28, 4, 6, 1, 0x8a7a6a));
                }
            }
            
        }
        
        return container;
    },

    // ============================================
    // NPC SPRITE SYSTEM
    // Uses identical PlayerBodyParts pipeline for visual consistency
    // NPCs get unique clothing, skin, hair — same quality as the player
    // ============================================
    
    // Predefined NPC appearance sets for variety
    npcPresets: [
        // Haven civilians
        { id: 'settler_a', skin: 'medium', hair: 'brown', hairStyle: 'short', shirt: { base: '#5a5040', light: '#6a6050', dark: '#4a4030' }, pants: { base: '#3a3a40', light: '#4a4a50' } },
        { id: 'settler_b', skin: 'tan', hair: 'black', hairStyle: 'buzzed', shirt: { base: '#4a4a52', light: '#5a5a62', dark: '#3a3a42' }, pants: { base: '#4a3a28', light: '#5a4a38' } },
        { id: 'settler_c', skin: 'light', hair: 'auburn', hairStyle: 'long', shirt: { base: '#6a3a3a', light: '#7a4a4a', dark: '#5a2a2a' }, pants: { base: '#2a3a4a', light: '#3a4a5a' } },
        { id: 'settler_d', skin: 'brown', hair: 'grey', hairStyle: 'short', shirt: { base: '#3a5a5a', light: '#4a6a6a', dark: '#2a4a4a' }, pants: { base: '#3a4a2a', light: '#4a5a3a' } },
        { id: 'settler_e', skin: 'dark', hair: 'black', hairStyle: 'bald', shirt: { base: '#5a4a30', light: '#6a5a40', dark: '#4a3a20' }, pants: { base: '#1a1a22', light: '#2a2a32' } },
        { id: 'settler_f', skin: 'deep', hair: 'white', hairStyle: 'short', shirt: { base: '#4a5a2a', light: '#5a6a3a', dark: '#3a4a1a' }, pants: { base: '#6a6040', light: '#7a7050' } },
        // Guards / military types
        { id: 'guard_a', skin: 'tan', hair: 'black', hairStyle: 'buzzed', shirt: { base: '#3a4a30', light: '#4a5a40', dark: '#2a3a20' }, pants: { base: '#3a4a2a', light: '#4a5a3a' }, gearType: 'light_armor' },
        { id: 'guard_b', skin: 'medium', hair: 'brown', hairStyle: 'short', shirt: { base: '#3a4a30', light: '#4a5a40', dark: '#2a3a20' }, pants: { base: '#3a4a2a', light: '#4a5a3a' }, gearType: 'light_armor' },
        // Vendor / specialist types
        { id: 'vendor_a', skin: 'light', hair: 'blond', hairStyle: 'long', shirt: { base: '#2a3a5a', light: '#3a4a6a', dark: '#1a2a4a' }, pants: { base: '#2a3a4a', light: '#3a4a5a' } },
        { id: 'vendor_b', skin: 'brown', hair: 'auburn', hairStyle: 'mohawk', shirt: { base: '#5a3a2a', light: '#6a4a3a', dark: '#4a2a1a' }, pants: { base: '#1a1a22', light: '#2a2a32' } },
        // Foundry soldiers — each foundry has 3 NPCs (guard, patrol, mechanic)
        // Terracorp — military olive + red chevron
        { id: 'tc_guard',    skin: 'tan',    hair: 'black',  hairStyle: 'buzzed', shirt: { base: '#3a4a32', light: '#4a5a42', dark: '#2a3a22' }, pants: { base: '#2a3a22', light: '#3a4a32' }, gearType: 'foundry_terracorp' },
        { id: 'tc_patrol',   skin: 'medium', hair: 'brown',  hairStyle: 'short',  shirt: { base: '#3a4a32', light: '#4a5a42', dark: '#2a3a22' }, pants: { base: '#2a3a22', light: '#3a4a32' }, gearType: 'foundry_terracorp' },
        { id: 'tc_mechanic', skin: 'brown',  hair: 'grey',   hairStyle: 'short',  shirt: { base: '#3a4a32', light: '#4a5a42', dark: '#2a3a22' }, pants: { base: '#2a3a22', light: '#3a4a32' }, gearType: 'foundry_terracorp' },
        // UCR — steel blue + chrome
        { id: 'ucr_guard',    skin: 'light',  hair: 'blond',  hairStyle: 'short',  shirt: { base: '#3a3a4a', light: '#4a4a5a', dark: '#2a2a3a' }, pants: { base: '#2a2a3a', light: '#3a3a4a' }, gearType: 'foundry_ucr' },
        { id: 'ucr_patrol',   skin: 'medium', hair: 'brown',  hairStyle: 'buzzed', shirt: { base: '#3a3a4a', light: '#4a4a5a', dark: '#2a2a3a' }, pants: { base: '#2a2a3a', light: '#3a3a4a' }, gearType: 'foundry_ucr' },
        { id: 'ucr_mechanic', skin: 'tan',    hair: 'auburn', hairStyle: 'short',  shirt: { base: '#3a3a4a', light: '#4a4a5a', dark: '#2a2a3a' }, pants: { base: '#2a2a3a', light: '#3a3a4a' }, gearType: 'foundry_ucr' },
        // Deralict — dark iron + orange hazard
        { id: 'drl_guard',    skin: 'brown',  hair: 'black',  hairStyle: 'bald',   shirt: { base: '#3a3028', light: '#4a4038', dark: '#2a2018' }, pants: { base: '#2a2018', light: '#3a3028' }, gearType: 'foundry_deralict' },
        { id: 'drl_patrol',   skin: 'dark',   hair: 'black',  hairStyle: 'buzzed', shirt: { base: '#3a3028', light: '#4a4038', dark: '#2a2018' }, pants: { base: '#2a2018', light: '#3a3028' }, gearType: 'foundry_deralict' },
        { id: 'drl_mechanic', skin: 'tan',    hair: 'grey',   hairStyle: 'short',  shirt: { base: '#3a3028', light: '#4a4038', dark: '#2a2018' }, pants: { base: '#2a2018', light: '#3a3028' }, gearType: 'foundry_deralict' },
        // Sworn — earth tones + green
        { id: 'swn_guard',    skin: 'medium', hair: 'auburn', hairStyle: 'long',   shirt: { base: '#5a4a38', light: '#6a5a48', dark: '#4a3a28' }, pants: { base: '#4a3a28', light: '#5a4a38' }, gearType: 'foundry_sworn' },
        { id: 'swn_patrol',   skin: 'tan',    hair: 'brown',  hairStyle: 'short',  shirt: { base: '#5a4a38', light: '#6a5a48', dark: '#4a3a28' }, pants: { base: '#4a3a28', light: '#5a4a38' }, gearType: 'foundry_sworn' },
        { id: 'swn_mechanic', skin: 'light',  hair: 'blond',  hairStyle: 'mohawk', shirt: { base: '#5a4a38', light: '#6a5a48', dark: '#4a3a28' }, pants: { base: '#4a3a28', light: '#5a4a38' }, gearType: 'foundry_sworn' },
        // Blackreach — deep black + gold
        { id: 'blk_guard',    skin: 'deep',   hair: 'white',  hairStyle: 'short',  shirt: { base: '#1a1a22', light: '#2a2a32', dark: '#0a0a12' }, pants: { base: '#0a0a12', light: '#1a1a22' }, gearType: 'foundry_blackreach' },
        { id: 'blk_patrol',   skin: 'dark',   hair: 'black',  hairStyle: 'buzzed', shirt: { base: '#1a1a22', light: '#2a2a32', dark: '#0a0a12' }, pants: { base: '#0a0a12', light: '#1a1a22' }, gearType: 'foundry_blackreach' },
        { id: 'blk_mechanic', skin: 'medium', hair: 'black',  hairStyle: 'long',   shirt: { base: '#1a1a22', light: '#2a2a32', dark: '#0a0a12' }, pants: { base: '#0a0a12', light: '#1a1a22' }, gearType: 'foundry_blackreach' },
        // Cephalon — dark carbon + teal
        { id: 'cph_guard',    skin: 'light',  hair: 'white',  hairStyle: 'buzzed', shirt: { base: '#1a2a2a', light: '#2a3a3a', dark: '#0a1a1a' }, pants: { base: '#0a1a1a', light: '#1a2a2a' }, gearType: 'foundry_cephalon' },
        { id: 'cph_patrol',   skin: 'tan',    hair: 'auburn', hairStyle: 'short',  shirt: { base: '#1a2a2a', light: '#2a3a3a', dark: '#0a1a1a' }, pants: { base: '#0a1a1a', light: '#1a2a2a' }, gearType: 'foundry_cephalon' },
        { id: 'cph_mechanic', skin: 'brown',  hair: 'grey',   hairStyle: 'bald',   shirt: { base: '#1a2a2a', light: '#2a3a3a', dark: '#0a1a1a' }, pants: { base: '#0a1a1a', light: '#1a2a2a' }, gearType: 'foundry_cephalon' },
    ],
    
    _npcSheetCache: {},
    
    generateNPCSheet(npcCustom) {
        const frameWidth = 48, frameHeight = 48, numFrames = 24;
        const canvas = document.createElement('canvas');
        canvas.width = frameWidth * numFrames;
        canvas.height = frameHeight;
        const ctx = canvas.getContext('2d');
        
        const c = npcCustom || {};
        const skinDef = CONFIG.customization.skinTones.find(s => s.id === (c.skin || 'medium')) || CONFIG.customization.skinTones[1];
        const hairDef = CONFIG.customization.hairColors.find(h => h.id === (c.hair || 'brown')) || CONFIG.customization.hairColors[1];
        const hairStyle = c.hairStyle || 'short';
        const shirtDef = (c.shirt && c.shirt.base) ? c.shirt :
            CONFIG.customization.shirtColors.find(s => s.id === (c.shirt || 'grey')) || CONFIG.customization.shirtColors[1];
        const pantsDef = (c.pants && c.pants.base) ? c.pants :
            CONFIG.customization.pantsColors.find(p => p.id === (c.pants || 'dark')) || CONFIG.customization.pantsColors[0];
        
        const colors = {
            skin: skinDef.base, skinShade: skinDef.shade,
            hair: hairDef.base, hairHL: hairDef.highlight,
            shirt: shirtDef.base, shirtLight: shirtDef.light || shirtDef.base, shirtDark: shirtDef.dark || shirtDef.base,
            pants: pantsDef.base, pantsLight: pantsDef.light || pantsDef.base,
            boots: '#1a1a1a', bootsLight: '#2a2a2a', bootSole: '#0a0a0a',
            belt: '#3a3028', buckle: '#8a8a6a',
            outline: '#111111'
        };
        
        const gearType = c.gearType || null;
        const G = this.GearOverlays;
        const B = this.PlayerBodyParts;
        
        for (let f = 0; f < 24; f++) {
            const ox = f * frameWidth;
            const dir = Math.floor(f / 3);
            const frame = f % 3;
            const bobY = (frame === 1 || frame === 2) ? -1 : 0;
            const legSpread = frame === 0 ? 0 : (frame === 1 ? 2 : -2);
            const armSwing = frame === 0 ? 0 : (frame === 1 ? 1 : -1);
            const p = { ox, dir, frame, bobY, legSpread, armSwing, armed: false, ws: null };
            
            B.drawShadow(ctx, p, colors);
            
            if (dir === 4 || dir === 3 || dir === 5) {
                if (gearType && G[gearType] && G[gearType].drawHead) G[gearType].drawHead(ctx, p, colors);
                else B.drawHead(ctx, p, colors);
                B.drawHair(ctx, p, colors, hairStyle);
                if (gearType && G[gearType] && G[gearType].drawHeadOverlay) G[gearType].drawHeadOverlay(ctx, p, colors);
                B.drawArms(ctx, p, colors);
                B.drawTorso(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawTorsoOverlay) G[gearType].drawTorsoOverlay(ctx, p, colors);
                B.drawBelt(ctx, p, colors);
                B.drawLegs(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawLegOverlay) G[gearType].drawLegOverlay(ctx, p, colors);
                B.drawBoots(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawBootOverlay) G[gearType].drawBootOverlay(ctx, p, colors);
            } else {
                if (gearType && G[gearType] && G[gearType].drawHead) G[gearType].drawHead(ctx, p, colors);
                else B.drawHead(ctx, p, colors);
                B.drawHair(ctx, p, colors, hairStyle);
                B.drawEyes(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawHeadOverlay) G[gearType].drawHeadOverlay(ctx, p, colors);
                B.drawTorso(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawTorsoOverlay) G[gearType].drawTorsoOverlay(ctx, p, colors);
                B.drawBelt(ctx, p, colors);
                B.drawArms(ctx, p, colors);
                B.drawLegs(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawLegOverlay) G[gearType].drawLegOverlay(ctx, p, colors);
                B.drawBoots(ctx, p, colors);
                if (gearType && G[gearType] && G[gearType].drawBootOverlay) G[gearType].drawBootOverlay(ctx, p, colors);
            }
        }
        
        return canvas;
    },
    
    getNPCSheet(presetId) {
        if (this._npcSheetCache[presetId]) return this._npcSheetCache[presetId];
        const preset = this.npcPresets.find(p => p.id === presetId);
        if (!preset) return this.generateNPCSheet({});
        const canvas = this.generateNPCSheet(preset);
        this._npcSheetCache[presetId] = canvas;
        return canvas;
    },
    
    addNPCSheetToScene(scene, presetId) {
        const texKey = 'npc_sheet_' + presetId;
        if (!scene.textures.exists(texKey)) {
            const canvas = this.getNPCSheet(presetId);
            scene.textures.addSpriteSheet(texKey, canvas, { frameWidth: 48, frameHeight: 48 });
        }
        const directions = ['down','down_right','right','up_right','up','up_left','left','down_left'];
        directions.forEach((dir, i) => {
            const key = `npc_walk_${presetId}_${dir}`;
            if (!scene.anims.exists(key)) {
                scene.anims.create({ key, frames: scene.anims.generateFrameNumbers(texKey, { start: i*3, end: i*3+2 }), frameRate: 6, repeat: -1 });
            }
        });
        const idleKey = `npc_idle_${presetId}`;
        if (!scene.anims.exists(idleKey)) {
            scene.anims.create({ key: idleKey, frames: [{ key: texKey, frame: 0 }], frameRate: 1 });
        }
    },
    
    createNPCSprite(scene, x, y, presetId) {
        this.addNPCSheetToScene(scene, presetId);
        const texKey = 'npc_sheet_' + presetId;
        const npc = scene.add.sprite(x, y, texKey, 0);
        npc.setDisplaySize(40, 40);
        npc.setFrame(0);
        npc._npcPreset = presetId;
        npc._npcDir = 'down';
        // Auto-apply ambient tint so all NPCs match time-of-day
        if (scene._ambientTint && scene._ambientTint !== 0xffffff) npc.setTint(scene._ambientTint);
        return npc;
    },
    
    playNPCWalk(npc, dir) {
        if (!npc || !npc._npcPreset) return;
        const key = `npc_walk_${npc._npcPreset}_${dir}`;
        if (npc.anims && npc.scene && npc.scene.anims.exists(key)) {
            npc._npcDir = dir;
            npc.play(key, true);
        }
    },
    
    stopNPC(npc) {
        if (!npc || !npc._npcPreset) return;
        const dirMap = { down:0, down_right:1, right:2, up_right:3, up:4, up_left:5, left:6, down_left:7 };
        const dirIdx = dirMap[npc._npcDir || 'down'] || 0;
        npc.stop();
        npc.setFrame(dirIdx * 3);
    },
    
};
