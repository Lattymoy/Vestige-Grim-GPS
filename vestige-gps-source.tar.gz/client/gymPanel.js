// Vestige GPS — GymPanel
// Extracted from monolith lines 38962-39682
// TODO: convert internal global refs to imports

import { SurvivorGenerator } from '../core/survivorGenerator.js';
import { uiPx } from '../core/utils.js';
import { CONFIG } from '../data/config.js';
import { UIAtlas } from './uiAtlas.js';


export const GymPanel = {
    showTraining(scene) {
        // Clean up any existing gym cards
        GymPanel._closeGymUI(scene);
        if (scene._activeTrainCard) { scene._activeTrainCard.destroy(); scene._activeTrainCard = null; }
        scene._gymCards = [];
        scene._gymDetail = null;
        scene.popupActive = true; // Block station interactions + highlight
        const gcAdd = (o) => { scene._gymCards.push(o); o.setScrollFactor(0); scene.cameras.main.ignore(o); return o; };
        
        // Active buff — show status blurb (world-space) and bail
        const activeBuff = scene.saveData.gymBuff;
        if (activeBuff && activeBuff.remainingMs > 0) {
            // Debounce — don't stack messages
            if (scene._gymActiveMsg && scene._gymActiveMsg.active) { scene.popupActive = false; return; }
            const catDef = CONFIG.gym.categories[activeBuff.category];
            const mins = Math.ceil(activeBuff.remainingMs / 60000);
            const msg = scene.add.text(scene.player.x, scene.player.y - 30,
                `${catDef.name} active — ${mins}m left`, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: catDef.color,
                stroke: '#000000', strokeThickness: 2
            }).setOrigin(0.5).setDepth(100);
            scene._gymActiveMsg = msg;
            scene._gymCards = [msg];
            scene.popupActive = false; // Not a real popup, just a float msg
            scene.tweens.add({ targets: msg, y: msg.y - 20, alpha: 0, duration: 2000, delay: 800,
                onComplete: () => { msg.destroy(); scene._gymActiveMsg = null; } });
            return;
        }
        
        // Apply camera blur to game world
        try {
            if (scene.cameras.main.postFX) {
                scene._gymBlur = scene.cameras.main.postFX.addBlur(0, 2, 2, 1);
            }
        } catch(e) {}
        
        // Create clean overlay camera for gym UI (no blur)
        const W = CONFIG.width, H = CONFIG.height;
        scene._gymCam = scene.cameras.add(0, 0, W, H).setName('gymOverlay');
        scene._gymCam.setScroll(scene.cameras.main.scrollX, scene.cameras.main.scrollY);
        
        // Cost calculation
        const gs = scene.saveData.gymSession;
        const now = Date.now();
        const today = Math.floor(now / 86400000);
        if (gs.lastSessionDay !== today) { gs.sessionCount = 0; gs.lastSessionDay = today; }
        const isFree = (now - gs.lastFreeUse) >= CONFIG.gym.freeCooldown;
        const cost = isFree ? 0 : Math.floor(CONFIG.gym.baseCost * Math.pow(CONFIG.gym.costScale, gs.sessionCount));
        const canAfford = isFree || scene.saveData.stash.bits >= cost;
        
        // Energy drink check
        const edIdx = (scene.saveData.stash.inventory || []).findIndex(i => i && i.id === 'energy_drink');
        const hasED = edIdx >= 0;
        
        const GD = 250;
        
        // Dim overlay (on clean camera)
        const overlay = gcAdd(scene.add.rectangle(W/2, H/2, W, H, 0x000000, 0.5).setDepth(GD));
        overlay.setInteractive();
        overlay.on('pointerdown', () => {
            if (scene._gymDetail) { GymPanel._closeGymDetail(scene); return; }
            GymPanel._closeGymUI(scene);
        });
        
        // Screen-center card layout
        const cardW = 72, cardH = 100, cardGap = 10;
        const totalW = 3 * cardW + 2 * cardGap;
        const startX = W / 2 - totalW / 2 + cardW / 2;
        const baseY = H / 2;
        
        // Cost label
        const costStr = isFree ? 'FREE' : `${cost} BITS`;
        const costColor = isFree ? '#44ff88' : (canAfford ? '#ffcc44' : '#ff4444');
        const gymSub = hasED ? `${costStr}  ·  BOOST READY` : costStr;
        gcAdd(scene.add.text(W/2, baseY - cardH/2 - 22, gymSub, {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: costColor, fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(GD+1));
        
        // Hint
        gcAdd(scene.add.text(W/2, baseY - cardH/2 - 10, 'TAP TO TRAIN  ·  HOLD FOR DETAILS', {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#556677'
        }).setOrigin(0.5).setDepth(GD+1));
        
        // Pixel art drawing functions per category (scaled up ~1.5x)
        const drawCore = (g, ox, oy) => {
            const p = (x,y,w,h,c) => g.fillStyle(c).fillRect(ox+x, oy+y, w, h);
            // Outer shell
            p(-15,-21,30,3,0x661111);
            p(-18,-18,3,27,0x661111);
            p(15,-18,3,27,0x661111);
            p(-15,9,6,6,0x661111);
            p(9,9,6,6,0x661111);
            p(-9,15,3,6,0x661111);
            p(6,15,3,6,0x661111);
            p(-3,21,6,3,0x661111);
            // Fill — front face
            p(-15,-18,30,27,0xaa2222);
            p(-9,9,18,6,0xaa2222);
            p(-6,15,12,6,0x992222);
            p(-3,18,6,3,0x882222);
            // Highlights
            p(-12,-15,9,3,0xcc4444);
            p(3,-15,9,3,0xcc4444);
            p(-3,-9,6,12,0xcc3333);
            p(-9,-6,3,9,0x993333);
            p(6,-6,3,9,0x993333);
            // Top strip
            p(-15,-24,30,3,0xcc3333);
            p(-12,-24,24,2,0xdd4444);
        };
        const drawArms = (g, ox, oy) => {
            const p = (x,y,w,h,c) => g.fillStyle(c).fillRect(ox+x, oy+y, w, h);
            // Left weight plate
            p(-21,-12,9,24,0xaa6622);
            p(-21,-15,9,3,0xcc7722);
            p(-21,12,9,3,0x885511);
            p(-18,-9,3,18,0xcc8833);
            // Bar
            p(-12,-3,24,6,0x888888);
            p(-12,-3,24,2,0xaaaaaa);
            p(-12,3,24,2,0x666666);
            // Right weight plate
            p(12,-12,9,24,0xaa6622);
            p(12,-15,9,3,0xcc7722);
            p(12,12,9,3,0x885511);
            p(15,-9,3,18,0xcc8833);
            // Grip
            p(-6,-2,12,3,0x777777);
            p(-6,0,12,2,0x999999);
            // Top edges
            p(-21,-18,9,3,0xdd8833);
            p(12,-18,9,3,0xdd8833);
        };
        const drawLegs = (g, ox, oy) => {
            const p = (x,y,w,h,c) => g.fillStyle(c).fillRect(ox+x, oy+y, w, h);
            // Boot shaft
            p(-6,-21,12,18,0x2255aa);
            p(-6,-21,12,3,0x3377cc);
            p(-6,-21,3,18,0x1a4488);
            p(3,-21,3,18,0x3366bb);
            // Ankle
            p(-6,-3,15,6,0x2244aa);
            // Sole
            p(-6,3,21,6,0x222233);
            p(-6,9,21,3,0x111122);
            p(-6,3,21,2,0x334455);
            // Toe box
            p(9,0,6,6,0x2255aa);
            p(12,0,3,2,0x3377cc);
            // Heel
            p(-9,3,3,6,0x222233);
            p(-9,9,3,3,0x111122);
            // Laces
            p(-3,-15,6,2,0x88bbee);
            p(-3,-11,6,2,0x88bbee);
            p(-3,-6,6,2,0x88bbee);
            // Top strip
            p(-6,-24,12,3,0x3388dd);
            // Speed lines
            p(-18,-12,6,2,0x44aaff);
            p(-21,-6,9,2,0x44aaff);
            p(-15,0,6,2,0x44aaff);
        };
        const drawFns = { core: drawCore, arms: drawArms, legs: drawLegs };
        
        // 3 category cards
        const cats = CONFIG.gym.categories;
        const catKeys = Object.keys(cats);
        
        catKeys.forEach((key, i) => {
            const cat = cats[key];
            const bx = startX + i * (cardW + cardGap);
            const by = baseY;
            const catHex = Phaser.Display.Color.HexStringToColor(cat.color).color;
            const dimAlpha = canAfford ? 1 : 0.35;
            
            // Card background
            const cardBg = gcAdd(scene.add.rectangle(bx, by, cardW, cardH, 0x0c0c18, 0.92)
                .setStrokeStyle(1.5, catHex, canAfford ? 0.8 : 0.2)
                .setDepth(GD+2));
            
            // Inner frame line
            gcAdd(scene.add.rectangle(bx, by, cardW - 6, cardH - 6, 0x000000, 0)
                .setStrokeStyle(0.5, catHex, canAfford ? 0.2 : 0.05)
                .setDepth(GD+2));
            
            // Pixel art icon
            const iconG = gcAdd(scene.add.graphics().setDepth(GD+3).setAlpha(dimAlpha));
            if (drawFns[key]) drawFns[key](iconG, bx, by - 16);
            
            // Category name
            gcAdd(scene.add.text(bx, by + 24, cat.name, {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: cat.color, fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(GD+3).setAlpha(dimAlpha));
            
            // Tagline
            gcAdd(scene.add.text(bx, by + 37, cat.tagline, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#667788'
            }).setOrigin(0.5).setDepth(GD+3).setAlpha(dimAlpha));
            
            // Hold-to-view + tap-to-select
            cardBg.setInteractive({ useHandCursor: canAfford });
            let holdTimer = null;
            
            cardBg.on('pointerdown', () => {
                if (!canAfford) return;
                holdTimer = scene.time.delayedCall(350, () => {
                    holdTimer = null;
                    GymPanel._showGymDetail(scene, cat, key, bx, by, catHex, hasED);
                });
            });
            cardBg.on('pointerup', () => {
                if (holdTimer) {
                    holdTimer.remove();
                    holdTimer = null;
                    if (scene._gymDetail) { GymPanel._closeGymDetail(scene); return; }
                    
                    // ── CARD SELECTED: keep this card, dismiss the rest ──
                    GymPanel._closeGymDetail(scene);
                    
                    // Create standalone training card container at this card's screen position
                    const trainCard = scene.add.container(bx, by).setDepth(GD+5).setScrollFactor(0);
                    scene._activeTrainCard = trainCard; // Track for cleanup
                    
                    // Card bg
                    const tcBg = scene.add.rectangle(0, 0, cardW, cardH, 0x0c0c18, 0.95)
                        .setStrokeStyle(2, catHex, 0.9);
                    trainCard.add(tcBg);
                    
                    // Inner frame
                    trainCard.add(scene.add.rectangle(0, 0, cardW - 6, cardH - 6, 0x000000, 0)
                        .setStrokeStyle(0.5, catHex, 0.2));
                    
                    // Icon
                    const tcIcon = scene.add.graphics();
                    if (drawFns[key]) drawFns[key](tcIcon, 0, -16);
                    trainCard.add(tcIcon);
                    
                    // Name + tagline
                    trainCard.add(scene.add.text(0, 24, cat.name, {
                        fontFamily: CONFIG.font, fontSize: uiPx(10), fill: cat.color, fontStyle: 'bold'
                    }).setOrigin(0.5));
                    trainCard.add(scene.add.text(0, 37, cat.tagline, {
                        fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#667788'
                    }).setOrigin(0.5));
                    
                    // Store front elements for flip later
                    trainCard._frontEls = trainCard.list.slice();
                    
                    // Destroy all gym UI (overlay, other cards, titles)
                    GymPanel._closeGymUI(scene);
                    
                    // Slide card to right side of screen
                    const targetX = W * 0.68;
                    const targetY = H / 2;
                    scene.tweens.add({
                        targets: trainCard,
                        x: targetX, y: targetY,
                        duration: 350, ease: 'Power2',
                        onComplete: () => {
                            GymPanel.performGymTraining(scene, key, cost, isFree, hasED ? edIdx : -1, trainCard);
                        }
                    });
                }
            });
            cardBg.on('pointerout', () => {
                if (holdTimer) { holdTimer.remove(); holdTimer = null; }
            });
        });
    },

    _showGymDetail(scene, cat, key, bx, by, catHex, hasED) {
        GymPanel._closeGymDetail(scene);
        const els = [];
        const GD = 260;
        const add = (o) => { els.push(o); o.setScrollFactor(0); try { scene.cameras.main.ignore(o); } catch(e) {} return o; };
        
        const dW = 140, dH = 100;
        const dx = bx, dy = by - 70;
        
        const F = UIAtlas.FRAME;
        UIAtlas.build(scene);
        add(scene.add.nineslice(dx, dy, 'ui_panel', null, dW, dH, F, F, F, F)
            .setDepth(GD).setAlpha(0.97));
        
        // Title
        add(scene.add.text(dx, dy - dH/2 + 12, cat.name + ' — ' + cat.tagline, {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: cat.color, fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(GD+1));
        
        // Subtitle
        const detailSub = hasED ? 'Boost guarantees peak tier:' : 'All buffs at a random tier:';
        add(scene.add.text(dx, dy - dH/2 + 25, detailSub, {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: hasED ? '#44ffaa' : '#778899'
        }).setOrigin(0.5).setDepth(GD+1));
        
        // Buff details
        let ly = dy - dH/2 + 40;
        Object.values(cat.buffs).forEach(buff => {
            const range = hasED ? `${buff.high}${buff.unit}` : `${buff.low}-${buff.high}${buff.unit}`;
            add(scene.add.text(dx - dW/2 + 12, ly, buff.name, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#aabbcc'
            }).setOrigin(0, 0.5).setDepth(GD+1));
            add(scene.add.text(dx + dW/2 - 12, ly, `+${range}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: cat.color
            }).setOrigin(1, 0.5).setDepth(GD+1));
            ly += 14;
        });
        
        // Duration
        add(scene.add.text(dx, ly + 4, 'Duration: 5-15m', {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#556677'
        }).setOrigin(0.5).setDepth(GD+1));
        
        scene._gymDetail = els;
    },

    _closeGymUI(scene) {
        GymPanel._closeGymDetail(scene);
        if (scene._gymCards) { scene._gymCards.forEach(e => { if (e && e.destroy) e.destroy(); }); }
        scene._gymCards = [];
        // Remove camera blur
        if (scene._gymBlur) {
            try { scene.cameras.main.postFX.remove(scene._gymBlur); } catch(e) {}
            scene._gymBlur = null;
        }
        // Remove overlay camera
        if (scene._gymCam) {
            try { scene.cameras.remove(scene._gymCam); } catch(e) {}
            scene._gymCam = null;
        }
        // Keep popupActive true if training card is animating, otherwise release
        if (!scene._activeTrainCard && !scene._gymAnimating) {
            scene.popupActive = false;
        }
    },

    _closeGymDetail(scene) {
        if (scene._gymDetail) {
            scene._gymDetail.forEach(e => { if (e && e.destroy) e.destroy(); });
            scene._gymDetail = null;
        }
    },

    performGymTraining(scene, categoryKey, cost, isFree, edIdx, trainCard) {
        // Deduct cost
        if (!isFree) scene.saveData.stash.bits -= cost;
        
        // Update session tracking
        const gs = scene.saveData.gymSession;
        const now = Date.now();
        if (isFree) gs.lastFreeUse = now;
        gs.sessionCount++;
        gs.lastSessionDay = Math.floor(now / 86400000);
        
        // Track on deployed survivor for achievements
        const _gymSurv = (scene.saveData.survivors || []).find(s => s.deployed);
        if (_gymSurv) _gymSurv.gymSessions = (_gymSurv.gymSessions || 0) + 1;
        
        // Check achievements after stat update
        if (_gymSurv) SurvivorGenerator.checkSurvivorAchievements(_gymSurv, scene.saveData);
        
        // Consume energy drink if available
        const boosted = edIdx >= 0;
        if (boosted && scene.saveData.stash.inventory) {
            scene.saveData.stash.inventory[edIdx] = null;
        }
        
        // Roll tier — all buffs in category at this tier
        const cat = CONFIG.gym.categories[categoryKey];
        const tiers = ['low', 'mid', 'high'];
        let tier;
        if (boosted) {
            tier = 'high';
        } else {
            // Weighted: 25% low, 45% mid, 30% high
            const r = Math.random();
            tier = r < 0.25 ? 'low' : r < 0.70 ? 'mid' : 'high';
        }
        const buffs = {};
        Object.entries(cat.buffs).forEach(([key, def]) => {
            buffs[key] = def[tier];
        });
        
        // Roll duration
        const durations = CONFIG.gym.durations;
        const duration = durations[Math.floor(Math.random() * durations.length)];
        
        // Set buff
        scene.saveData.gymBuff = {
            category: categoryKey,
            buffs: buffs,
            remainingMs: duration * 60 * 1000,
            duration: duration,
            tier: tier,
            boosted: boosted
        };
        
        scene.saveSaveData();
        
        // Lock input during animation
        scene._gymAnimating = true;
        if (scene.inputHandler) scene.inputHandler.enabled = false;
        
        // Move player to the specific gym tool for this category
        const gym = scene.stations.find(s => s._handcraftedType === 'gym');
        if (!gym) {
            scene.time.delayedCall(400, () => {
                GymPanel._finishGymAnim(scene, cat, buffs, tier, duration, boosted, trainCard);
            });
            return;
        }
        
        // Walk to category-specific tool position
        const toolPos = gym._toolPositions && gym._toolPositions[categoryKey];
        const targetX = toolPos ? toolPos.x : gym.x + 28;
        const targetY = toolPos ? toolPos.y : gym.y;
        
        // Calculate walk distance for duration
        const dx = targetX - scene.player.x, dy = targetY - scene.player.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        const walkDur = Math.max(300, Math.min(800, dist * 2));
        
        // Tween player to specific tool
        scene.tweens.add({
            targets: scene.player,
            x: targetX,
            y: targetY,
            duration: walkDur,
            ease: 'Power2',
            onComplete: () => GymPanel._playGymAnimation(scene, cat.animType, categoryKey, () => {
                GymPanel._finishGymAnim(scene, cat, buffs, tier, duration, boosted, trainCard);
            })
        });
    },

    _playGymAnimation(scene, animType, categoryKey, onDone) {
        const p = scene.player;
        const origX = p.x, origY = p.y;
        const origScaleX = p.scaleX;
        const origScaleY = p.scaleY;
        const reps = 5;
        const repDur = 450;
        
        // ── Strain eyes (> <) as pixel chevrons at sprite eye position ──
        const eyeG = scene.add.graphics().setDepth(p.depth + 1);
        
        const drawStrainEyes = () => {
            eyeG.clear();
            const ex = p.x, ey = p.y - 9;
            eyeG.fillStyle(0xffffff);
            eyeG.fillRect(ex - 6, ey, 1, 3);
            eyeG.fillRect(ex - 5, ey + 1, 1, 1);
            eyeG.fillRect(ex - 4, ey, 1, 1);
            eyeG.fillRect(ex - 4, ey + 2, 1, 1);
            eyeG.fillRect(ex + 3, ey + 1, 1, 1);
            eyeG.fillRect(ex + 4, ey, 1, 1);
            eyeG.fillRect(ex + 4, ey + 2, 1, 1);
            eyeG.fillRect(ex + 5, ey, 1, 3);
        };
        drawStrainEyes();
        
        const eyeTracker = scene.time.addEvent({
            delay: 16, loop: true,
            callback: () => { if (eyeG.active) drawStrainEyes(); }
        });
        
        // ── Sweat droplets ──
        const spawnSweat = () => {
            const side = Math.random() > 0.5 ? 1 : -1;
            const sx = p.x + side * (7 + Math.random() * 5);
            const sy = p.y - 12 - Math.random() * 4;
            const drop = scene.add.graphics().setDepth(p.depth + 1);
            drop.fillStyle(0x66ccff);
            drop.fillRect(sx, sy, 1, 1);
            drop.fillRect(sx - 1, sy + 1, 3, 2);
            drop.fillRect(sx, sy + 3, 1, 1);
            drop.fillStyle(0xaaeeff);
            drop.fillRect(sx, sy + 1, 1, 1);
            scene.tweens.add({
                targets: { t: 0 }, t: 1,
                duration: 350 + Math.random() * 150, ease: 'Power2',
                onUpdate: (tw, target) => {
                    const prog = target.t;
                    drop.setPosition(side * prog * 12, -prog * 10 + prog * prog * 6);
                    drop.setAlpha(1 - prog * 0.8);
                },
                onComplete: () => drop.destroy()
            });
        };
        
        // ── Impact flash (small white rect at hit point) ──
        const spawnImpact = (ix, iy) => {
            const flash = scene.add.rectangle(ix, iy, 4, 4, 0xffffff, 0.8).setDepth(p.depth + 2);
            scene.tweens.add({
                targets: flash, scaleX: 2, scaleY: 2, alpha: 0,
                duration: 150, ease: 'Power2',
                onComplete: () => flash.destroy()
            });
        };
        
        const cleanup = () => {
            eyeTracker.remove();
            eyeG.destroy();
            p.x = origX; p.y = origY;
            p.setScale(origScaleX, origScaleY);
            p.alpha = 1;
            onDone();
        };
        
        const gym = scene.stations.find(s => s._handcraftedType === 'gym');
        
        if (categoryKey === 'arms') {
            // PUNCHING BAG — player leans forward, bag sways on hit
            let rep = 0;
            const bagRef = gym && gym._bagBody;
            const bagOrigX = bagRef ? bagRef.x : 0;
            const doPunch = () => {
                if (rep >= reps) { cleanup(); return; }
                spawnSweat();
                const side = rep % 2 === 0 ? -1 : 1; // alternate left/right punch
                // Player leans toward bag
                scene.tweens.add({
                    targets: p,
                    x: origX + side * 2,
                    scaleX: origScaleX * (side > 0 ? 0.95 : 1.05),
                    duration: repDur * 0.3, ease: 'Power2',
                    onComplete: () => {
                        // Impact
                        spawnImpact(p.x + side * 12, p.y - 4);
                        // Bag sway
                        if (bagRef) {
                            scene.tweens.add({
                                targets: bagRef,
                                x: bagOrigX + side * 3,
                                duration: repDur * 0.25, yoyo: true, ease: 'Sine.easeOut',
                                onComplete: () => { bagRef.x = bagOrigX; }
                            });
                        }
                        // Player recoil
                        scene.tweens.add({
                            targets: p,
                            x: origX, scaleX: origScaleX,
                            duration: repDur * 0.4, ease: 'Sine.easeInOut',
                            onComplete: () => { rep++; scene.time.delayedCall(repDur * 0.15, doPunch); }
                        });
                    }
                });
            };
            doPunch();
            
        } else if (categoryKey === 'core') {
            // AB ROLLER / CRUNCH — player compresses, rolls forward then back
            let rep = 0;
            const doCrunch = () => {
                if (rep >= reps) { cleanup(); return; }
                spawnSweat();
                // Down phase — compress + slight forward
                scene.tweens.add({
                    targets: p,
                    scaleY: origScaleY * 0.7, y: origY + 4, x: origX - 3,
                    duration: repDur * 0.4, ease: 'Sine.easeIn',
                    onComplete: () => {
                        // Up phase — extend back
                        scene.tweens.add({
                            targets: p,
                            scaleY: origScaleY, y: origY, x: origX,
                            duration: repDur * 0.45, ease: 'Sine.easeOut',
                            onComplete: () => { rep++; scene.time.delayedCall(repDur * 0.15, doCrunch); }
                        });
                    }
                });
            };
            doCrunch();
            
        } else if (categoryKey === 'legs') {
            // JUMP ROPE — player bounces up with short hang time, rope whooshes
            let rep = 0;
            const doJump = () => {
                if (rep >= reps) { cleanup(); return; }
                spawnSweat();
                // Jump up
                scene.tweens.add({
                    targets: p,
                    y: origY - 8,
                    scaleY: origScaleY * 1.1,
                    scaleX: origScaleX * 0.92,
                    duration: repDur * 0.35, ease: 'Sine.easeOut',
                    onComplete: () => {
                        // Rope whoosh arc (visual)
                        const arc = scene.add.graphics().setDepth(p.depth - 1);
                        arc.lineStyle(1.5, 0x888877, 0.5);
                        arc.beginPath();
                        for (let a = 0; a < Math.PI; a += 0.2) {
                            const ax = p.x - 10 + Math.cos(a) * 20;
                            const ay = p.y + 6 - Math.sin(a) * 12;
                            if (a === 0) arc.moveTo(ax, ay); else arc.lineTo(ax, ay);
                        }
                        arc.strokePath();
                        scene.tweens.add({ targets: arc, alpha: 0, duration: 200, onComplete: () => arc.destroy() });
                        
                        // Land
                        scene.tweens.add({
                            targets: p,
                            y: origY + 2, scaleY: origScaleY * 0.85, scaleX: origScaleX * 1.06,
                            duration: repDur * 0.25, ease: 'Power2',
                            onComplete: () => {
                                // Recover
                                scene.tweens.add({
                                    targets: p,
                                    y: origY, scaleY: origScaleY, scaleX: origScaleX,
                                    duration: repDur * 0.2, ease: 'Sine.easeOut',
                                    onComplete: () => { rep++; scene.time.delayedCall(repDur * 0.1, doJump); }
                                });
                            }
                        });
                    }
                });
            };
            doJump();
        } else {
            cleanup();
        }
    },

    _finishGymAnim(scene, cat, buffs, tier, duration, boosted, trainCard) {
        scene._gymAnimating = false;
        if (scene.inputHandler) scene.inputHandler.enabled = true;
        
        // Play sound
        if (typeof SoundManager !== 'undefined') SoundManager.play('heal');
        
        // If no card (fallback), just return
        if (!trainCard || !trainCard.active) return;
        
        const catHex = Phaser.Display.Color.HexStringToColor(cat.color).color;
        const cardW = 72, cardH = 100;
        
        // ── Build back side elements (hidden, added to container) ──
        const backEls = [];
        
        const bBg = scene.add.rectangle(0, 0, cardW, cardH, 0x0c0c18, 0.95)
            .setStrokeStyle(2, catHex, 0.9).setVisible(false);
        backEls.push(bBg);
        
        // Inner frame
        backEls.push(scene.add.rectangle(0, 0, cardW - 6, cardH - 6, 0x000000, 0)
            .setStrokeStyle(0.5, catHex, 0.2).setVisible(false));
        
        const tierLabel = boosted ? 'BOOSTED' : (tier === 'high' ? 'PEAK' : tier === 'mid' ? 'SOLID' : 'LIGHT');
        const tierColor = boosted ? '#44ffaa' : (tier === 'high' ? '#ffdd44' : tier === 'mid' ? '#aaddaa' : '#889988');
        
        // Category name
        backEls.push(scene.add.text(0, -cardH/2 + 10, cat.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: cat.color
        }).setOrigin(0.5).setVisible(false));
        
        // Tier label
        backEls.push(scene.add.text(0, -cardH/2 + 22, tierLabel, {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: tierColor, fontStyle: 'bold'
        }).setOrigin(0.5).setVisible(false));
        
        let ly = -cardH/2 + 38;
        Object.entries(buffs).forEach(([stat, val]) => {
            const buffDef = cat.buffs[stat];
            const label = buffDef ? buffDef.name : stat;
            const unit = buffDef ? buffDef.unit : '';
            backEls.push(scene.add.text(0, ly, `+${val}${unit} ${label}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: cat.color
            }).setOrigin(0.5).setVisible(false));
            ly += 13;
        });
        
        backEls.push(scene.add.text(0, ly + 2, `${duration}m`, {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#667788'
        }).setOrigin(0.5).setVisible(false));
        
        // Tap to dismiss hint
        backEls.push(scene.add.text(0, cardH/2 - 8, 'tap to dismiss', {
            fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#445566'
        }).setOrigin(0.5).setVisible(false));
        
        backEls.forEach(e => trainCard.add(e));
        
        // ── FLIP: scaleX 1→0 (front shrinks), swap, scaleX 0→1 (back expands) ──
        const frontEls = trainCard._frontEls || [];
        
        scene.tweens.add({
            targets: trainCard, scaleX: 0,
            duration: 150, ease: 'Sine.easeIn',
            onComplete: () => {
                frontEls.forEach(e => { if (e && e.setVisible) e.setVisible(false); });
                backEls.forEach(e => e.setVisible(true));
                
                scene.tweens.add({
                    targets: trainCard, scaleX: 1,
                    duration: 150, ease: 'Sine.easeOut',
                    onComplete: () => {
                        // ── TAP TO DISMISS (card or anywhere) ──
                        const dismissCard = () => {
                            if (scene._gymDismissBg) { scene._gymDismissBg.destroy(); scene._gymDismissBg = null; }
                            scene.tweens.add({
                                targets: trainCard, alpha: 0, scaleX: 0.9, scaleY: 0.9,
                                duration: 200, ease: 'Power2',
                                onComplete: () => { trainCard.destroy(); scene._activeTrainCard = null; scene.popupActive = false; }
                            });
                        };
                        // Fullscreen tap target behind the card
                        const W = CONFIG.width, H = CONFIG.height;
                        scene._gymDismissBg = scene.add.rectangle(W/2, H/2, W, H, 0x000000, 0.01)
                            .setDepth(trainCard.depth - 1).setScrollFactor(0).setInteractive();
                        scene._gymDismissBg.on('pointerdown', dismissCard);
                        bBg.setInteractive();
                        bBg.on('pointerdown', dismissCard);
                    }
                });
            }
        });
    }
};
