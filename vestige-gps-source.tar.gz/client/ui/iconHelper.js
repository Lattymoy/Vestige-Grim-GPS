// Vestige GPS — IconHelper
// Extracted from monolith L32905-33035

import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';


export const IconHelper = {
    // Emoji → atlas texture key or text fallback
    MAP: {
        '▪': { atlas: 'ui_icon_ammo' },
        '◈': { atlas: 'ui_icon_bits' },
        '☠': { atlas: 'ui_icon_skull' },
        '⚔': { atlas: 'ui_icon_weapon' },
        '⚙': { text: 'GER', color: '#887766' },
        '⚠': { atlas: 'ui_icon_warning' },
        '⚡': { text: 'ZAP', color: '#44aaff' },
        '⛪': { text: 'CHR', color: '#8888aa' },
        '⛰': { text: 'MTN', color: '#889988' },
        '⛽': { atlas: 'ui_icon_fuel' },
        '✦': { atlas: 'ui_icon_star' },
        '✨': { text: 'SPK', color: '#ffcc88' },
        '❓': { text: '?', color: '#aaaaaa' },
        '❤': { atlas: 'ui_icon_health' },
        '➤': { atlas: 'ui_icon_arrow' },
        '🌅': { text: 'DWN', color: '#cc8844' },
        '🍽': { text: 'DIN', color: '#aa8866' },
        '🎒': { atlas: 'ui_icon_backpack' },
        '🎖': { text: 'MDL', color: '#ccaa44' },
        '🎯': { text: 'AIM', color: '#ffaa44' },
        '🎲': { text: 'RNG', color: '#44ff88' },
        '🏕': { text: 'HVN', color: '#4488cc' },
        '🏚': { text: 'RUN', color: '#886644' },
        '🏠': { text: 'HSE', color: '#88aa88' },
        '🏢': { text: 'OFC', color: '#8888aa' },
        '🏫': { text: 'SCH', color: '#88aa88' },
        '👑': { text: 'CRN', color: '#ffcc44' },
        '👕': { text: 'ARM', color: '#6a8aaa' },
        '💀': { atlas: 'ui_icon_skull' },
        '💉': { text: 'STM', color: '#44aacc' },
        '💊': { atlas: 'ui_icon_heal' },
        '💣': { text: 'GRD', color: '#cc6644' },
        '💥': { atlas: 'ui_icon_explosion' },
        '💰': { text: 'BUY', color: '#ccaa44' },
        '💾': { atlas: 'ui_icon_chip' },
        '📖': { text: 'BKS', color: '#aa8866' },
        '📜': { text: 'STR', color: '#aa44aa' },
        '📦': { atlas: 'ui_icon_package' },
        '📬': { text: 'BOX', color: '#aa8866' },
        '📰': { text: 'PPR', color: '#888888' },
        '🔁': { text: 'RPT', color: '#88aacc' },
        '🔌': { text: 'WRE', color: '#888888' },
        '🔍': { atlas: 'ui_icon_search' },
        '🔑': { text: 'KEY', color: '#ccaa44' },
        '🔒': { atlas: 'ui_icon_lock' },
        '🔓': { atlas: 'ui_icon_unlock' },
        '🔥': { text: 'FRE', color: '#ff6622' },
        '🔧': { atlas: 'ui_icon_wrench' },
        '🔨': { text: 'HMR', color: '#888888' },
        '🔩': { text: 'PRT', color: '#aa8866' },
        '🔪': { text: 'KNF', color: '#aaaaaa' },
        '🔫': { text: 'GUN', color: '#aa6644' },
        '🔬': { text: 'LAB', color: '#44aaaa' },
        '🔮': { text: 'RLC', color: '#aa44ff' },
        '🔲': { atlas: 'ui_icon_cube' },
        '🕳': { text: 'VLT', color: '#666666' },
        '🗑': { text: 'BIN', color: '#888888' },
        '🗡': { text: 'BLD', color: '#cc6633' },
        '🗺': { text: 'MAP', color: '#88aa88' },
        '🗼': { text: 'TWR', color: '#aaaaaa' },
        '🚔': { text: 'PLC', color: '#4466aa' },
        '🚗': { atlas: 'ui_icon_vehicle' },
        '🚛': { atlas: 'ui_icon_vehicle' },
        '🚧': { text: 'BAR', color: '#cc8844' },
        '🛏': { text: 'HTL', color: '#8888aa' },
        '🛒': { text: 'CRT', color: '#88aa88' },
        '🛡': { atlas: 'ui_icon_shield' },
        '🛢': { text: 'DRM', color: '#886644' },
        '🧣': { text: 'ARM', color: '#aa8866' },
        '🧥': { text: 'ARM', color: '#6a8aaa' },
        '🧵': { text: 'CLT', color: '#aa8866' },
        // Bracket codes from loreSeries/faction purge
        '[W]': { text: '[W]', color: '#8888aa' },
        '[T]': { text: '[T]', color: '#8a2a2a' },
        '[U]': { text: '[U]', color: '#6a8aaa' },
        '[D]': { text: '[D]', color: '#cc6622' },
        '[S]': { text: '[S]', color: '#4a6a3a' },
        '[B]': { text: '[B]', color: '#aa8833' },
        '[C]': { text: '[C]', color: '#33aaaa' },
    },

    /**
     * Resolve an icon string to its display form.
     * Returns { type: 'atlas'|'text', key/text, color? }
     */
    resolve(iconStr) {
        if (!iconStr) return { type: 'text', text: '?', color: '#666666' };
        const entry = this.MAP[iconStr];
        if (entry) {
            if (entry.atlas) return { type: 'atlas', key: entry.atlas };
            return { type: 'text', text: entry.text, color: entry.color || '#aaaaaa' };
        }
        // Unknown icon — strip emoji, use first char or '?'
        const clean = iconStr.replace(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{27BF}]/gu, '').trim();
        return { type: 'text', text: clean || '?', color: '#888888' };
    },

    /**
     * Place an icon at (x, y) in scene. Returns the created game object.
     * opts: { scale, depth, alpha, scrollFactor, origin, fontSize }
     */
    render(scene, x, y, iconStr, opts = {}) {
        const info = this.resolve(iconStr);
        const { scale = 1, depth = 10, alpha = 1, scrollFactor = 1, origin = 0.5, fontSize = uiPx(12) } = opts;

        if (info.type === 'atlas' && scene.textures.exists(info.key)) {
            return scene.add.image(x, y, info.key)
                .setScale(scale).setDepth(depth).setAlpha(alpha)
                .setScrollFactor(scrollFactor).setOrigin(origin);
        }

        return scene.add.text(x, y, info.text, {
            fontFamily: CONFIG.font, fontSize: fontSize, fill: info.color || '#aaaaaa',
            fontStyle: 'bold'
        }).setOrigin(origin).setDepth(depth).setAlpha(alpha).setScrollFactor(scrollFactor);
    },

    /**
     * Get text-safe version of an icon (for inline use in template strings).
     * Returns the text fallback even for atlas-mapped icons.
     */

    /**
     * Replace emoji in a string with text equivalents (for safe add.text usage).
     * Handles template strings like "${item.icon} ${item.name}"
     */

};

