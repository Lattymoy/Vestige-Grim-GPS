// Vestige GPS — MenuHeader
// Extracted from monolith L33040-33121

import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';


export const MenuHeader = {
    /**
     * Draw a styled header panel for overlay menus.
     * @param {Function} addFn - gcAdd/acAdd helper that registers + configures the element
     * @param {Phaser.Scene} scene
     * @param {number} cx - center X
     * @param {number} y - top edge Y of the header
     * @param {object} opts - { title, subtitle, hint, accent (hex int), depth, width }
     * @returns {{ bottom: number }} - bottom Y of the header for content layout
     */
    draw(addFn, scene, cx, y, opts = {}) {
        const {
            title = 'MENU', subtitle = '', hint = '',
            accent = 0xccaa55, depth = 251, width = 180
        } = opts;
        const aHex = '#' + accent.toString(16).padStart(6, '0');
        const aHexDim = '#' + Math.max(0, accent - 0x222222).toString(16).padStart(6, '0');
        const D = depth;
        const pw = width, left = cx - pw / 2, right = cx + pw / 2;
        
        // === Panel background ===
        const g = addFn(scene.add.graphics().setDepth(D));
        // Main body
        g.fillStyle(0x0e0e14, 0.88);
        g.fillRoundedRect(left, y, pw, 52, { tl: 4, tr: 4, bl: 0, br: 0 });
        // Inner highlight band (top third)
        g.fillStyle(0x16161e, 0.5);
        g.fillRect(left + 1, y + 1, pw - 2, 18);
        // Accent top edge
        g.fillStyle(accent, 0.7);
        g.fillRect(left + 8, y, pw - 16, 1.5);
        // Accent left stripe
        g.fillStyle(accent, 0.45);
        g.fillRect(left + 3, y + 6, 1.5, 40);
        // Subtle corner dots
        g.fillStyle(accent, 0.3);
        g.fillCircle(left + 8, y + 8, 1.5);
        g.fillCircle(right - 8, y + 8, 1.5);
        // Bottom border line
        g.lineStyle(0.5, accent, 0.2);
        g.beginPath(); g.moveTo(left + 6, y + 52); g.lineTo(right - 6, y + 52); g.stroke();
        // Subtle noise texture (tiny dots)
        for (let i = 0; i < 12; i++) {
            const nx = left + 10 + Math.random() * (pw - 20);
            const ny = y + 4 + Math.random() * 44;
            g.fillStyle(0xffffff, 0.02);
            g.fillRect(nx, ny, 1, 1);
        }
        
        // === Title text ===
        addFn(scene.add.text(cx + 2, y + 12, title.toUpperCase(), {
            fontFamily: CONFIG.font, fontSize: uiPx(13), fill: aHex, fontStyle: 'bold',
            stroke: '#000000', strokeThickness: 2
        }).setOrigin(0.5).setDepth(D + 1));
        
        // === Subtitle ===
        if (subtitle) {
            addFn(scene.add.text(cx + 2, y + 28, subtitle.toUpperCase(), {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#bbccdd',
                stroke: '#000000', strokeThickness: 1
            }).setOrigin(0.5).setDepth(D + 1));
        }
        
        // === Hint (bottom of panel) ===
        if (hint) {
            const hg = addFn(scene.add.graphics().setDepth(D));
            const hintText = scene.add.text(0, 0, hint.toUpperCase(), {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#99aabb',
                stroke: '#000000', strokeThickness: 1
            }).setOrigin(0.5);
            const htW = hintText.width + 16;
            const htY = y + 42;
            hg.fillStyle(0x08080c, 0.6);
            hg.fillRoundedRect(cx - htW / 2, htY - 6, htW, 13, 2);
            hg.lineStyle(0.5, accent, 0.12);
            hg.strokeRoundedRect(cx - htW / 2, htY - 6, htW, 13, 2);
            addFn(hintText.setPosition(cx, htY + 0.5).setDepth(D + 1));
        }
        
        return { bottom: y + 56 };
    }
};

