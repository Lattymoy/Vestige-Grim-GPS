// Vestige GPS — InventoryUI
// Extracted from monolith L24292-26453

import { Haptics } from '../../core/haptics.js';
import { ItemManager } from '../../core/itemManager.js';
import { SaveManager } from '../../core/saveManager.js';
import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { AudioManager } from '../audioManager.js';
import { SpriteManager } from '../spriteManager.js';
import { UIAtlas } from '../uiAtlas.js';
import { GameScene } from '../scenes/GameScene.js';
import { InteriorScene } from '../scenes/InteriorScene.js';
import { SafehouseScene } from '../scenes/SafehouseScene.js';


export class InventoryUI {
    constructor(scene, arg1, arg2, arg3OrOnClose, arg4, arg5) {
        this.scene = scene;
        this.elements = [];
        this.slotElements = [];
        this._open = true;
        
        // Detect mode: new loadout (backpack + equipment) vs legacy two-panel (leftInv, rightInv, labels)
        if (typeof arg3OrOnClose === 'function') {
            // New mode: InventoryUI(scene, backpack, equipment, onClose)
            this.mode = 'loadout';
            this.backpack = arg1;
            this.equipment = arg2;
            this.onClose = arg3OrOnClose;
        } else {
            // Legacy mode: InventoryUI(scene, leftInv, rightInv, leftLabel, rightLabel, onClose)
            this.mode = 'transfer';
            this.leftInv = arg1;
            this.rightInv = arg2;
            this.leftLabel = arg3OrOnClose;
            this.rightLabel = arg4;
            this.onClose = arg5;
        }
        
        this.build();
    }
    
    add(gameObj) {
        gameObj.setScrollFactor(0);
        this.elements.push(gameObj);
        return gameObj;
    }
    
    build() {
        if (this.mode === 'loadout') {
            this.buildLoadout();
        } else {
            this.buildTransfer();
        }
    }
    
    buildTransfer() {
        const W = CONFIG.width;
        const H = CONFIG.height;
        const s = this.scene;
        const D = 500;
        
        const bg = this.add(s.add.rectangle(W/2, H/2, W, H, 0x000000, 0.85).setDepth(D));
        bg.setInteractive();
        bg.on('pointerdown', () => this.close());
        
        const panelH = 340;
        const panelY = H/2 - 10;
        UIAtlas.build(s);
        const panelBg = s.add.nineslice(W/2, panelY, 'ui_panel', null, W - 20, panelH, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME);
        panelBg.setInteractive(); // absorb taps on panel
        this.add(panelBg.setDepth(D+1));
        this.add(s.add.rectangle(W/2, panelY - panelH/2 + UIAtlas.FRAME - 1, W - 20 - UIAtlas.FRAME*2, 1, 0x3a3a4a, 0.5).setDepth(D+1.5));
        
        this.add(s.add.text(W/2, panelY - panelH/2 + 16, 'TRANSFER', {
            fontFamily: CONFIG.font, fontSize: uiPx(13), fill: '#8888aa', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(D+2));
        
        const divY = panelY - panelH/2 + 30;
        this.add(s.add.rectangle(W/2, divY, W - 36, 1, 0x2a2a3a).setDepth(D+2));
        
        const gridStartY = divY + 24;
        this.buildTransferPanel(W/2 - 80, gridStartY, this.leftLabel, this.leftInv, 'left', D);
        this.buildTransferPanel(W/2 + 80, gridStartY, this.rightLabel, this.rightInv, 'right', D);
        
        this.add(s.add.rectangle(W/2, gridStartY + 80, 1, 180, 0x2a2a3a).setDepth(D+2));
        this.add(s.add.text(W/2, gridStartY + 65, '⇄', {
            fontFamily: CONFIG.font, fontSize: uiPx(16), fill: '#556677'
        }).setOrigin(0.5).setDepth(D+2));
        
        this.infoText = this.add(s.add.text(W/2, panelY + panelH/2 - 16, 'Tap item to transfer', {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#555566'
        }).setOrigin(0.5).setDepth(D+2));
    }
    
    buildTransferPanel(cx, startY, label, inventory, side, D) {
        const s = this.scene;
        const cols = 3, slotSize = 38, gap = 5;
        const gridW = cols * (slotSize + gap) - gap;
        
        this.add(s.add.text(cx, startY, label, {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#8888aa'
        }).setOrigin(0.5).setDepth(D+2));
        
        const filled = ItemManager.getFilledCount(inventory);
        this.add(s.add.text(cx, startY + 14, `${filled}/${inventory.length}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#555566'
        }).setOrigin(0.5).setDepth(D+2));
        
        const gridStartX = cx - gridW / 2 + slotSize / 2;
        const gridStartY = startY + 30;
        
        for (let i = 0; i < inventory.length; i++) {
            const col = i % cols;
            const row = Math.floor(i / cols);
            const sx = gridStartX + col * (slotSize + gap);
            const sy = gridStartY + row * (slotSize + gap);
            this.buildTransferSlot(sx, sy, slotSize, inventory, i, side, D);
        }
    }
    
    buildTransferSlot(x, y, size, inventory, index, side, D) {
        const s = this.scene;
        const item = inventory[index];
        
        const slotBg = this.add(s.add.rectangle(x, y, size, size, item ? 0x1a1a28 : 0x111118, 0.9)
            .setStrokeStyle(1, item ? 0x3a3a55 : 0x1a1a22).setDepth(D+3));
        slotBg.setInteractive({ useHandCursor: true });
        
        if (item) {
            const itemColor = ItemManager.getItemColor(item);
            slotBg.setStrokeStyle(1, itemColor);
            const isAngledType = (item.category === 'weapon' || item.category === 'melee');
            if (item.flair && isAngledType) {
                InventoryUI.addFlairShimmer(s, (o) => this.add(o), x, y, size - 4, item.flair, D+3);
            } else if (isAngledType) {
                this.add(s.add.rectangle(x, y, size - 4, size - 4, itemColor, 0.06)
                    .setStrokeStyle(0.5, itemColor, 0.25).setDepth(D+2));
            }
            
            if (isAngledType && ItemManager.renderWeaponCanvas) {
                const wc = ItemManager.renderWeaponCanvas(item);
                if (wc) {
                    const crop = InventoryUI._cropWeaponIcon(wc, item, size, 1.4);
                    const texKey = '_trSlot_' + side + '_' + index + '_' + (item.id || Math.random());
                    if (s.textures.exists(texKey)) s.textures.remove(texKey);
                    s.textures.addCanvas(texKey, crop);
                    this.add(s.add.image(x, y, texKey).setDepth(D+2.5));
                }
            } else if (!isAngledType) {
                const iconContainer = s.add.container(0, 0).setDepth(D+2.5);
                this.add(iconContainer);
                ItemManager.drawItemPixelArt(s, iconContainer, x, y - 4, item, 1.4, 0);
            }
            
            // Stack count badge — bottom-right of slot, only for actual stacks
            if (item.stackCount && item.stackCount > 1) {
                const badgeX = x + size/2 - 8, badgeY = y + size/2 - 7;
                this.add(s.add.rectangle(badgeX, badgeY, 20, 14, 0x000000, 0.85)
                    .setStrokeStyle(0.5, 0x888888, 0.5).setDepth(D+4));
                this.add(s.add.text(badgeX, badgeY, `×${item.stackCount}`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#ffcc44', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(D+5));
            }
            
            
            let holdTimer = null, didHold = false;
            slotBg.on('pointerdown', () => {
                didHold = false;
                holdTimer = this.scene.time.delayedCall(400, () => { didHold = true; this.showItemCard(item); });
            });
            slotBg.on('pointerup', () => {
                if (holdTimer) { holdTimer.remove(); holdTimer = null; }
                if (!didHold) {
                    const targetInv = (side === 'left') ? this.rightInv : this.leftInv;
                    if (ItemManager.transferItem(inventory, index, targetInv)) {
                        this.refresh();
                    } else {
                        this.infoText.setText('No space!');
                        this.infoText.setFill('#ff4444');
                        this.scene.time.delayedCall(1000, () => {
                            if (this.infoText && this.infoText.active) { this.infoText.setText('Tap item to transfer'); this.infoText.setFill('#555566'); }
                        });
                    }
                }
            });
            slotBg.on('pointerout', () => { if (holdTimer) { holdTimer.remove(); holdTimer = null; } });
        }
    }
    
    buildLoadout() {
        const W = CONFIG.width;
        const H = CONFIG.height;
        const s = this.scene;
        const D = 500;
        
        // Dim backdrop — tap outside to dismiss
        const bg = this.add(s.add.rectangle(W/2, H/2, W, H, 0x000000, 0.88).setDepth(D));
        bg.setInteractive();
        bg.on('pointerdown', () => this.close());
        
        // Full-height panel
        const panelW = W - 16;
        const panelH = H - 60;
        const panelY = H/2;
        UIAtlas.build(s);
        const panelBg = s.add.nineslice(W/2, panelY, 'ui_panel', null, panelW, panelH, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME);
        panelBg.setInteractive(); // absorb taps on panel
        this.add(panelBg.setDepth(D+1));
        this.add(s.add.rectangle(W/2, panelY - panelH/2 + UIAtlas.FRAME - 1, panelW - UIAtlas.FRAME*2, 1, 0x3a3a4a, 0.5).setDepth(D+1.5));
        
        // Title
        this.add(s.add.text(W/2, panelY - panelH/2 + 20, 'LOADOUT', {
            fontFamily: CONFIG.font, fontSize: uiPx(16), fill: '#8888bb', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(D+2));
        
        const contentY = panelY - panelH/2 + 42;
        
        // === EQUIPMENT SECTION (top) ===
        this.add(s.add.text(14, contentY, 'EQUIPPED', {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#667788', fontStyle: 'bold'
        }).setDepth(D+2));
        
        const equipSlots = ['weapon', 'melee', 'gear', 'consumable'];
        const eqSlotSize = 52; // square slots matching icon size
        const eqGap = 8;
        const totalEqW = equipSlots.length * eqSlotSize + (equipSlots.length - 1) * eqGap;
        const eqStartX = (W - totalEqW) / 2;
        const eqY = contentY + 18;
        
        equipSlots.forEach((slot, i) => {
            const sx = eqStartX + i * (eqSlotSize + eqGap) + eqSlotSize / 2;
            this.buildEquipSlot(sx, eqY + eqSlotSize / 2, eqSlotSize, eqSlotSize, slot, D);
        });
        
        // Divider
        const dividerY = eqY + eqSlotSize + 12;
        this.add(s.add.rectangle(W/2, dividerY, panelW - 16, 1, 0x2a2a3a).setDepth(D+2));
        
        // === BACKPACK SECTION (bottom) ===
        const bpY = dividerY + 6;
        const filled = ItemManager.getFilledCount(this.backpack);
        this.add(s.add.text(14, bpY, `BACKPACK  ${filled}/${this.backpack.length}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#667788', fontStyle: 'bold'
        }).setDepth(D+2));
        
        const bpGridY = bpY + 18;
        const bpAvailH = (panelY + panelH/2 - 28) - bpGridY;
        
        // Calculate optimal grid
        const cols = 4;
        const rows = Math.ceil(this.backpack.length / cols);
        const maxSlotH = (bpAvailH - (rows - 1) * 5) / rows;
        const bpSlotSize = Math.min(Math.floor((panelW - 20 - (cols - 1) * 5) / cols), Math.floor(maxSlotH));
        const bpGap = 5;
        const gridW = cols * (bpSlotSize + bpGap) - bpGap;
        const gridStartX = W/2 - gridW/2 + bpSlotSize/2;
        
        for (let i = 0; i < this.backpack.length; i++) {
            const col = i % cols;
            const row = Math.floor(i / cols);
            const sx = gridStartX + col * (bpSlotSize + bpGap);
            const sy = bpGridY + row * (bpSlotSize + bpGap) + bpSlotSize/2;
            this.buildBackpackSlot(sx, sy, bpSlotSize, i, D);
        }
        
        // Info text
        this.infoText = this.add(s.add.text(W/2, panelY + panelH/2 - 14, 'Tap: equip  ·  Hold: inspect', {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#556666'
        }).setOrigin(0.5).setDepth(D+2));
    }
    
    buildEquipSlot(x, y, w, h, slot, D) {
        const s = this.scene;
        const item = this.equipment ? this.equipment[slot] : null;
        const slotDef = CONFIG.equipmentSlots[slot];
        
        const bg = this.add(s.add.rectangle(x, y, w, h, item ? 0x181828 : 0x0c0c14, 0.95)
            .setStrokeStyle(1, item ? 0x000000 : 0x222233, item ? 0 : 1).setDepth(D+3));
        bg.setInteractive({ useHandCursor: true });
        
        if (item) {
            const itemColor = ItemManager.getItemColor(item);
            const isAngledEq = (item.category === 'weapon' || item.category === 'melee');
            
            if (item.flair && isAngledEq) {
                InventoryUI.addFlairShimmer(s, (o) => this.add(o), x, y, Math.min(w, h) - 4, item.flair, D+3.2);
            } else if (isAngledEq) {
                this.add(s.add.rectangle(x, y, Math.min(w, h) - 4, Math.min(w, h) - 4, itemColor, 0.06)
                    .setStrokeStyle(0.5, itemColor, 0.25).setDepth(D+3.2));
            }
            
            if (isAngledEq && ItemManager.renderWeaponCanvas) {
                // Render weapon to canvas → single image (clips naturally)
                const wc = ItemManager.renderWeaponCanvas(item);
                if (wc) {
                    const crop = InventoryUI._cropWeaponIcon(wc, item, Math.min(w, h), 1.8);
                    const texKey = '_eqSlot_' + (item.id || Math.random());
                    if (s.textures.exists(texKey)) s.textures.remove(texKey);
                    s.textures.addCanvas(texKey, crop);
                    this.add(s.add.image(x, y, texKey).setDepth(D+3.5));
                }
            } else if (!isAngledEq) {
                const eqIconC = s.add.container(0, 0).setDepth(D+3.5);
                this.add(eqIconC);
                ItemManager.drawItemPixelArt(s, eqIconC, x, y - 6, item, 1.8, 0);
            }
            
            // Border frame ON TOP of sprite
            this.add(s.add.rectangle(x, y, w, h, 0x000000, 0)
                .setStrokeStyle(1, itemColor).setDepth(D+4.5));
            
            
            // Tier pip
            if (item.tier && item.tier > 1) {
                const tierDef = CONFIG.tiers[item.tier];
                if (tierDef) this.add(s.add.rectangle(x - w/2 + 6, y - h/2 + 6, 6, 6, tierDef.color, 0.9).setDepth(D+5));
                if (item.tier === 5) this.add(s.add.rectangle(x, y, w - 2, h - 2, 0xff2244, 0.06).setDepth(D+3.5));
                if (item.tier === 6) { this.add(s.add.rectangle(x, y, w - 2, h - 2, 0x8800ff, 0.1).setDepth(D+3.5)); this.add(s.add.rectangle(x, y, w, h, 0xaa44ff, 0.06).setDepth(D+3.4)); }
            }
            
            // Tap to unequip, hold to inspect
            let holdTimer = null, didHold = false;
            bg.on('pointerdown', () => {
                didHold = false;
                holdTimer = this.scene.time.delayedCall(400, () => {
                    didHold = true;
                    holdTimer = null;
                    this.showItemCard(item);
                });
            });
            bg.on('pointerup', () => {
                if (holdTimer) { holdTimer.remove(); holdTimer = null; }
                if (!didHold) {
                    if (ItemManager.unequipItem(this.equipment, this.backpack, slot)) {
                        AudioManager.equip();
                        Haptics.light();
                        if (slot === 'gear') {
                            const custom = Object.assign({}, SpriteManager.playerCustomization);
                            const defaults = CONFIG.customization;
                            const shirtDef = defaults.shirtColors.find(c => c.id === (SpriteManager._baseShirtId || 'green')) || defaults.shirtColors[0];
                            const pantsDef = defaults.pantsColors.find(c => c.id === (SpriteManager._basePantsId || 'dark')) || defaults.pantsColors[0];
                            custom.shirt = shirtDef; custom.pants = pantsDef;
                            custom.gearType = null;
                            SpriteManager.rebuildPlayerSheet(s, custom);
                        }
                        this.showActionFeedback(`Unequipped`, '#887766');
                        this.refresh();
                    } else {
                        this.showActionFeedback('Backpack full!', '#ff4444');
                    }
                }
            });
            bg.on('pointerout', () => { if (holdTimer) { holdTimer.remove(); holdTimer = null; } });
        } else {
            // Empty slot
            this.add(s.add.text(x, y - 6, slotDef.icon, { fontFamily: CONFIG.font, fontSize: uiPx(16), fill: '#222233', fontStyle: 'bold' }).setOrigin(0.5).setDepth(D+4).setAlpha(0.5));
            this.add(s.add.text(x, y + 14, slotDef.label, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#333344'
            }).setOrigin(0.5).setDepth(D+4));
        }
    }
    
    buildBackpackSlot(x, y, size, index, D) {
        const s = this.scene;
        const item = this.backpack[index];
        
        // Background fill (no stroke)
        const slotBg = this.add(s.add.rectangle(x, y, size, size, item ? 0x161624 : 0x0c0c14, 0.95)
            .setDepth(D+3));
        slotBg.setInteractive({ useHandCursor: true });
        
        if (item) {
            const itemColor = ItemManager.getItemColor(item);
            
            const isAngledStash = (item.category === 'weapon' || item.category === 'melee');
            if (item.flair && isAngledStash) {
                InventoryUI.addFlairShimmer(s, (o) => this.add(o), x, y, size - 4, item.flair, D+3.2);
            } else if (isAngledStash) {
                this.add(s.add.rectangle(x, y, size - 4, size - 4, itemColor, 0.06)
                    .setStrokeStyle(0.5, itemColor, 0.25).setDepth(D+3.2));
            }
            
            if (isAngledStash && ItemManager.renderWeaponCanvas) {
                const wc = ItemManager.renderWeaponCanvas(item);
                if (wc) {
                    const baseScale = Math.min(size / 22, 3.2);
                    const crop = InventoryUI._cropWeaponIcon(wc, item, size, baseScale);
                    const texKey = '_bpSlot_' + index + '_' + (item.id || Math.random());
                    if (s.textures.exists(texKey)) s.textures.remove(texKey);
                    s.textures.addCanvas(texKey, crop);
                    this.add(s.add.image(x, y, texKey).setDepth(D+3.5));
                }
            } else if (!isAngledStash) {
                const stashIconC = s.add.container(0, 0).setDepth(D+3.5);
                this.add(stashIconC);
                const baseScale = Math.min(size / 22, 3.2);
                ItemManager.drawItemPixelArt(s, stashIconC, x, y - 4, item, baseScale, 0);
            }
            
            // Border frame ON TOP of sprite
            this.add(s.add.rectangle(x, y, size, size, 0x000000, 0)
                .setStrokeStyle(1, itemColor).setDepth(D+4.5));
            
            // Stack count badge — bottom-right of slot, only for actual stacks
            if (item.stackCount && item.stackCount > 1) {
                const badgeX = x + size/2 - 8, badgeY = y + size/2 - 7;
                this.add(s.add.rectangle(badgeX, badgeY, 20, 14, 0x000000, 0.85)
                    .setStrokeStyle(0.5, 0x888888, 0.5).setDepth(D+5));
                this.add(s.add.text(badgeX, badgeY, `×${item.stackCount}`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#ffcc44', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(D+5.5));
            }
            
            // Tier pip
            if (item.tier && item.tier > 1) {
                const tierDef = CONFIG.tiers[item.tier];
                if (tierDef) {
                    this.add(s.add.rectangle(x - size/2 + 5, y - size/2 + 5, 6, 6, tierDef.color, 0.9).setDepth(D+5));
                    if (item.mods && item.mods.length > 0) {
                        const dotStartX = x - ((item.mods.length - 1) * 5) / 2;
                        item.mods.forEach((mod, mi) => {
                            this.add(s.add.circle(dotStartX + mi * 5, y + size/2 - 5, 2, mod.color, 0.9).setDepth(D+5));
                        });
                    }
                    if (item.tier === 5) {
                        this.add(s.add.rectangle(x, y, size - 2, size - 2, 0xff2244, 0.06).setDepth(D+3.5));
                    }
                }
            }
            
            // Tap to equip, hold to inspect
            let holdTimer = null, didHold = false;
            slotBg.on('pointerdown', () => {
                didHold = false;
                holdTimer = this.scene.time.delayedCall(400, () => {
                    didHold = true;
                    holdTimer = null;
                    this.showItemCard(item);
                });
            });
            slotBg.on('pointerup', () => {
                if (holdTimer) { holdTimer.remove(); holdTimer = null; }
                if (!didHold) this.handleBackpackTap(index);
            });
            slotBg.on('pointerout', () => { if (holdTimer) { holdTimer.remove(); holdTimer = null; } });
        } else {
            // Empty slot border
            this.add(s.add.rectangle(x, y, size, size, 0x000000, 0)
                .setStrokeStyle(1, 0x1a1a22).setDepth(D+4.5));
        }
        
        this.slotElements.push({ bg: slotBg, index });
    }
    
    handleBackpackTap(index) {
        const item = this.backpack[index];
        if (!item) return;
        
        const gs = this.scene;
        
        // Consumables — equip to consumable slot (swap)
        if (item.category === 'consumable' && this.equipment) {
            ItemManager.equipItem(this.equipment, this.backpack, index);
            AudioManager.equip();
            Haptics.light();
            this.showActionFeedback(`Readied ${item.name}`, '#44aa44');
            this.refresh();
            return;
        }
        
        // Equippable items (weapon, melee, gear)
        if (['weapon', 'melee', 'gear'].includes(item.category) && this.equipment) {
            // If slot is empty, equip immediately
            const currentItem = this.equipment[item.category];
            if (!currentItem) {
                this._doEquip(index);
                return;
            }
            // Otherwise, show compare card
            this.showCompareCard(item, currentItem, index);
            return;
        }
        
        // Non-equippable items (keys etc) — just show card
        this.showItemCard(item);
    }
    
    _doEquip(index) {
        const item = this.backpack[index];
        if (!item) return;
        const gs = this.scene;
        
        ItemManager.equipItem(this.equipment, this.backpack, index);
        AudioManager.equip();
        Haptics.light();
        
        // Apply gear outfit to sprite
        if (item.category === 'gear') {
            const outfit = item.outfit || (item.baseId && CONFIG.baseItems[item.baseId] ? CONFIG.baseItems[item.baseId].outfit : null);
            if (outfit) {
                const custom = Object.assign({}, SpriteManager.playerCustomization);
                custom.shirt = outfit.shirt;
                custom.pants = outfit.pants;
                custom.gearType = item.gearClass || item.baseId;
                SpriteManager.rebuildPlayerSheet(gs, custom);
            }
        }
        
        // Update weapon sprite type + foundry + flair
        if (item.category === 'weapon') {
            const wt = SpriteManager.getWeaponSpriteType(item.baseId);
            if (gs.player) {
                gs.player.weaponType = wt;
                gs.player.weaponFoundry = item.foundry || null;
                gs.player.weaponFlair = item.flair || null;
                // Rebuild armed sheet with weapon art
                {
                    SpriteManager.armedSheets[wt] = SpriteManager.generatePlayerSheet(SpriteManager.playerCustomization, true, wt, item.foundry || null, item);
                    const sheetKey = 'player_sheet_armed_' + wt;
                    if (gs.textures.exists(sheetKey)) gs.textures.remove(sheetKey);
                    gs.textures.addSpriteSheet(sheetKey, SpriteManager.armedSheets[wt], { frameWidth: 48, frameHeight: 48 });
                    const dirs = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
                    dirs.forEach((dir, i) => {
                        const animKey = `player_armed_${wt}_${dir}`;
                        if (gs.anims.exists(animKey)) gs.anims.remove(animKey);
                        gs.anims.create({ key: animKey, frames: gs.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 8, repeat: -1 });
                    });
                    const idleKey = `player_armed_${wt}_idle`;
                    if (gs.anims.exists(idleKey)) gs.anims.remove(idleKey);
                    gs.anims.create({ key: idleKey, frames: [{ key: sheetKey, frame: 0 }], frameRate: 1 });
                }
            }
        }
        if (item.category === 'melee' && gs.player) {
            gs.player.meleeFlair = item.flair || null;
            // Rebuild melee sheet with weapon art
            const mt = (item.baseId === 'blunt') ? 'blunt' : (item.baseId === 'heavy') ? 'heavy' : 'blade';
            {
                SpriteManager.meleeSheets[mt] = SpriteManager.generateMeleeSheet(SpriteManager.playerCustomization, mt, item);
                const sheetKey = 'player_sheet_melee_' + mt;
                if (gs.textures.exists(sheetKey)) gs.textures.remove(sheetKey);
                gs.textures.addSpriteSheet(sheetKey, SpriteManager.meleeSheets[mt], { frameWidth: 48, frameHeight: 48 });
                const dirs = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
                dirs.forEach((dir, i) => {
                    const animKey = `player_melee_${mt}_${dir}`;
                    if (gs.anims.exists(animKey)) gs.anims.remove(animKey);
                    gs.anims.create({ key: animKey, frames: gs.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 10, repeat: 0 });
                });
            }
        }
        
        this.showActionFeedback(`Equipped ${item.name}`, '#aaccff');
        this.refresh();
    }
    
    showCompareCard(newItem, currentItem, backpackIndex) {
        this.closeItemCard();
        
        const s = this.scene;
        const W = CONFIG.width;
        const H = CONFIG.height;
        const D = 600;
        const F = UIAtlas.FRAME;
        
        this.itemCard = [];
        const addC = (obj) => { this.itemCard.push(obj); return obj; };
        
        // Stat display config
        const STAT_DISPLAY = {
            damage: { label: 'Damage', max: 100 },
            fireRate: { label: 'Fire Rate', max: 100 },
            accuracy: { label: 'Accuracy', max: 100 },
            crit: { label: 'Crit', max: 200, unit: '%', displayDiv: 2 },
            mag: { label: 'Mag', max: 100 },
            reload: { label: 'Reload', max: 100, invert: true },
            pierce: { label: 'Pierce', max: 5 },
            targetRange: { label: 'Target Range', max: 5 },
            attackSpeed: { label: 'Attack Speed', max: 100 },
            reach: { label: 'Reach', max: 100 },
            stagger: { label: 'Stagger', max: 100, unit: '%' },
            shieldAttack: { label: 'Shield Atk', max: 5 },
            armor: { label: 'Armor', max: 50, unit: '%' },
            health: { label: 'Health', max: 550 },
            speed: { label: 'Speed', max: 120, unit: '%' },
            luck: { label: 'Luck', max: 10 },
            backpack: { label: 'Backpack', max: 20 },
            maxHealth: { label: 'Health+', max: 200 },
            damageResist: { label: 'Resist', max: 50, unit: '%' },
            lootLuck: { label: 'Luck', max: 50 },
            healBonus: { label: 'Heal+', max: 50, unit: '%' },
            dodge: { label: 'Dodge', max: 20, unit: '%' }
        };
        
        // Collect all stat keys from both items
        const allStatKeys = new Set();
        if (newItem.stats) Object.keys(newItem.stats).forEach(k => { if (STAT_DISPLAY[k] && newItem.stats[k] !== 0) allStatKeys.add(k); });
        if (currentItem.stats) Object.keys(currentItem.stats).forEach(k => { if (STAT_DISPLAY[k] && currentItem.stats[k] !== 0) allStatKeys.add(k); });
        const statKeys = Array.from(allStatKeys);
        
        // Card sizing
        const cardW = W - 32;
        const cx = W / 2;
        const cardLeft = cx - cardW / 2;
        const iconColW = 36; // left column: icon
        const headerH = 96; // two item rows @ 40px each + 16px gap
        const statsH = statKeys.length * 18 + 24;
        const btnH = 38;
        const cardH = headerH + statsH + btnH + 16;
        const cy = H / 2;
        const cardTop = cy - cardH / 2;
        
        // Dim overlay
        const overlay = addC(s.add.rectangle(W/2, H/2, W, H, 0x000000, 0.75).setDepth(D).setScrollFactor(0));
        overlay.setInteractive();
        overlay.on('pointerdown', () => this.closeItemCard());
        
        // Card background
        addC(s.add.nineslice(cx, cy, 'ui_panel', null, cardW, cardH, F, F, F, F).setDepth(D+1).setScrollFactor(0));
        
        // ── NEW ITEM row ──
        const newColor = (newItem.tier ? CONFIG.tiers[newItem.tier]?.color : 0x888888) || 0x888888;
        const newHex = '#' + newColor.toString(16).padStart(6, '0');
        const newRowY = cardTop + 22;
        const iconX = cardLeft + iconColW / 2 + 4;
        const textX = cardLeft + iconColW + 10;
        const textW = cardW - iconColW - 20;

        // NEW badge
        addC(s.add.text(iconX, newRowY - 12, 'NEW', {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: newHex, fontStyle: 'bold'
        }).setOrigin(0.5, 0.5).setDepth(D+3).setScrollFactor(0));

        // New item icon — depth D+3 clears card bg at D+1
        if (newItem.flair && newItem.procedural) {
            InventoryUI.addFlairShimmer(s, addC, iconX, newRowY + 4, 28, newItem.flair, D + 2);
        }
        const newIconC = addC(s.add.container(iconX, newRowY + 4).setDepth(D+3).setScrollFactor(0));
        if (newItem.procedural && newItem.category !== 'augment') {
            ItemManager.drawItemPixelArt(s, newIconC, 0, 0, newItem, 1.5, 0);
            if (newItem.category === 'weapon' || newItem.category === 'melee') {
                newIconC.setRotation(newItem.category === 'melee' ? Math.PI / 4 : -Math.PI / 4);
            }
        } else {
            newIconC.add(s.add.text(0, 0, newItem.icon || '?', { fontSize: uiPx(14) }).setOrigin(0.5));
        }

        // New item name + type — left-aligned beside icon
        const newTier = newItem.tier ? CONFIG.tiers[newItem.tier] : null;
        const newBase = newItem.baseId ? CONFIG.baseItems[newItem.baseId] : null;
        const newTypeLbl = newBase ? newBase.name : newItem.category;
        const newRarity = newTier ? newTier.name : '';
        addC(s.add.text(textX, newRowY - 2, newItem.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#eeeeee', fontStyle: 'bold',
            wordWrap: { width: textW }
        }).setOrigin(0, 0.5).setDepth(D+3).setScrollFactor(0));
        addC(s.add.text(textX, newRowY + 12, `${newRarity} ${newTypeLbl}`.trim(), {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: newHex
        }).setOrigin(0, 0.5).setDepth(D+3).setScrollFactor(0));

        // ── Divider ──
        const divY = newRowY + 30;
        addC(s.add.rectangle(cx, divY, cardW - 24, 1, 0x334455, 0.6).setDepth(D+2).setScrollFactor(0));

        // ── CURRENT ITEM row ──
        const curColor = (currentItem.tier ? CONFIG.tiers[currentItem.tier]?.color : 0x888888) || 0x888888;
        const curHex = '#' + curColor.toString(16).padStart(6, '0');
        const curRowY = divY + 18;

        // EQUIPPED badge
        addC(s.add.text(iconX, curRowY - 10, 'EQUIPPED', {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#556677', fontStyle: 'bold'
        }).setOrigin(0.5, 0.5).setDepth(D+3).setScrollFactor(0));

        // Current item icon
        const curIconC = addC(s.add.container(iconX, curRowY + 4).setDepth(D+3).setScrollFactor(0));
        if (currentItem.procedural && currentItem.category !== 'augment') {
            ItemManager.drawItemPixelArt(s, curIconC, 0, 0, currentItem, 1.5, 0);
            if (currentItem.category === 'weapon' || currentItem.category === 'melee') {
                curIconC.setRotation(currentItem.category === 'melee' ? Math.PI / 4 : -Math.PI / 4);
            }
        } else {
            curIconC.add(s.add.text(0, 0, currentItem.icon || '?', { fontSize: uiPx(14) }).setOrigin(0.5).setAlpha(0.5));
        }

        // Current item name + type — subdued
        const curTier = currentItem.tier ? CONFIG.tiers[currentItem.tier] : null;
        const curBase = currentItem.baseId ? CONFIG.baseItems[currentItem.baseId] : null;
        const curTypeLbl = curBase ? curBase.name : currentItem.category;
        const curRarity = curTier ? curTier.name : '';
        addC(s.add.text(textX, curRowY - 2, currentItem.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#889999',
            wordWrap: { width: textW }
        }).setOrigin(0, 0.5).setDepth(D+3).setScrollFactor(0));
        addC(s.add.text(textX, curRowY + 12, `${curRarity} ${curTypeLbl}`.trim(), {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: curHex
        }).setOrigin(0, 0.5).setDepth(D+3).setScrollFactor(0));

        // ── STAT section starts below both headers ──
        const curY = curRowY + 22;
        
        // ── STAT COMPARISON ──
        const frameY = curY + 20;
        const labelW = 60;
        const barMaxW = cardW - labelW - 70;
        const barH = 8;
        let sy = frameY;
        
        statKeys.forEach(key => {
            const def = STAT_DISPLAY[key];
            if (!def) return;
            const newVal = (newItem.stats && newItem.stats[key]) || 0;
            const curVal = (currentItem.stats && currentItem.stats[key]) || 0;
            const diff = newVal - curVal;
            
            // For inverted stats (reload time), lower is better
            const isBetter = def.invert ? diff < -0.01 : diff > 0.01;
            const isWorse = def.invert ? diff > 0.01 : diff < -0.01;
            
            // Label
            addC(s.add.text(cx - cardW/2 + 10, sy, def.label, {
                fontFamily: CONFIG.font, fontSize: uiPx(8),
                fill: isBetter ? '#66dd66' : isWorse ? '#dd5555' : '#8899aa'
            }).setOrigin(0, 0.5).setDepth(D+4).setScrollFactor(0));
            
            // New item bar (bright)
            const barLeft = cx - cardW/2 + labelW + 4;
            addC(s.add.rectangle(barLeft + barMaxW/2, sy, barMaxW, barH, 0x0e0e1a, 0.9)
                .setStrokeStyle(0.5, 0x1a1a2a).setDepth(D+3).setScrollFactor(0));
            
            const newPct = def.invert
                ? Math.max(0.05, Math.min(1, (def.max - newVal) / def.max))
                : Math.max(0.05, Math.min(1, newVal / def.max));
            const newFillW = Math.max(4, Math.floor(barMaxW * newPct));
            const barCol = isBetter ? 0x44cc44 : isWorse ? 0xcc4444 : 0xccccdd;
            addC(s.add.rectangle(barLeft + newFillW/2, sy, newFillW, barH - 2, barCol, 0.8)
                .setDepth(D+4).setScrollFactor(0));
            
            // Old bar ghost outline
            const curPct = def.invert
                ? Math.max(0.05, Math.min(1, (def.max - curVal) / def.max))
                : Math.max(0.05, Math.min(1, curVal / def.max));
            const curFillW = Math.max(4, Math.floor(barMaxW * curPct));
            addC(s.add.rectangle(barLeft + curFillW/2, sy, curFillW, barH - 2, 0xffffff, 0)
                .setStrokeStyle(1, 0xffffff, 0.2).setDepth(D+4).setScrollFactor(0));
            
            // Delta text
            let absDiff = Math.abs(diff);
            if (def.displayDiv) absDiff = absDiff / def.displayDiv;
            const diffUnit = def.unit || '';
            const diffStr = absDiff < 0.01 ? '=' : (isBetter ? '+' : '-') + (absDiff % 1 ? absDiff.toFixed(1) : Math.round(absDiff)) + diffUnit;
            const diffCol = isBetter ? '#66dd66' : isWorse ? '#dd5555' : '#667788';
            addC(s.add.text(cx + cardW/2 - 14, sy, diffStr, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: diffCol, fontStyle: 'bold'
            }).setOrigin(1, 0.5).setDepth(D+4).setScrollFactor(0));
            
            sy += 18;
        });
        
        // ── EQUIP BUTTON ──
        const btnY = cy + cardH/2 - 24;
        const btnW = cardW - 40;
        const btnBg = addC(s.add.rectangle(cx, btnY, btnW, 28, newColor, 0.25)
            .setStrokeStyle(1, newColor, 0.6).setDepth(D+2).setScrollFactor(0));
        btnBg.setInteractive();
        addC(s.add.text(cx, btnY, 'EQUIP', {
            fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#eeeeee', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(D+3).setScrollFactor(0));
        
        btnBg.on('pointerdown', () => {
            this.closeItemCard();
            this._doEquip(backpackIndex);
        });
    }
    
    showActionFeedback(text, color) {
        const s = this.scene;
        const fb = s.add.text(CONFIG.width/2, CONFIG.height/2 - 80, text, {
            fontFamily: CONFIG.font, fontSize: uiPx(12), fill: color, fontStyle: 'bold'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(650);
        s.tweens.add({ targets: fb, y: fb.y - 25, alpha: 0, duration: 800, onComplete: () => fb.destroy() });
    }
    
    // ── Flair Effect — animated per-flair particles orbiting sprite ──
    static addFlairShimmer(scene, addC, x, y, size, flair, D, scrollFixed = true) {
        if (!flair) return;
        const fc = flair.color;
        const hs = size / 2;
        const sf = scrollFixed ? 0 : undefined;
        
        // Background square with flair tint + border
        const bg = scene.add.rectangle(x, y, size, size, fc, 0.08)
            .setStrokeStyle(1, fc, 0.3).setDepth(D);
        if (sf !== undefined) bg.setScrollFactor(sf);
        addC(bg);
        
        // Shimmer overlay — graphics object clipped to the square bounds
        const g = scene.add.graphics().setDepth(D + 1);
        if (sf !== undefined) g.setScrollFactor(sf);
        addC(g);
        
        const L = x - hs, T = y - hs, S = size; // left, top, size
        
        if (flair.id === 'ember') {
            // Fire shimmer: warm glow that rises from bottom, pulses
            scene.tweens.addCounter({
                from: 0, to: 1, duration: 1800, repeat: -1, yoyo: true,
                ease: 'Sine.easeInOut',
                onUpdate: (tw) => {
                    if (!g.scene) return;
                    g.clear();
                    const v = tw.getValue();
                    // Rising heat band — bottom third glows and shifts up
                    const bandY = T + S * (0.9 - v * 0.6);
                    const bandH = S * 0.25;
                    for (let i = 0; i < 4; i++) {
                        const a = (0.06 + v * 0.08) * (1 - i * 0.22);
                        g.fillStyle(fc, a);
                        g.fillRect(L + i * 1, bandY + i * 2, S - i * 2, bandH - i * 2);
                    }
                    // Flickering hot spots along bottom edge
                    const flicker = Math.sin(Date.now() * 0.008) * 0.5 + 0.5;
                    g.fillStyle(fc, 0.04 + flicker * 0.06);
                    g.fillRect(L + S * 0.1, T + S * 0.75, S * 0.3, S * 0.2);
                    g.fillRect(L + S * 0.55, T + S * 0.8, S * 0.25, S * 0.15);
                }
            });
            
        } else if (flair.id === 'electric') {
            // Lightning shimmer: erratic horizontal flash bands + random crackle
            scene.tweens.addCounter({
                from: 0, to: 1, duration: 120, repeat: -1,
                onUpdate: () => {
                    if (!g.scene) return;
                    g.clear();
                    const t = Date.now();
                    // Random flash band — appears briefly at random Y
                    if ((t % 400) < 60) {
                        const fy = T + (((t * 7) % 100) / 100) * S;
                        g.fillStyle(fc, 0.12 + Math.random() * 0.1);
                        g.fillRect(L, fy, S, 2);
                        g.fillStyle(0xffffff, 0.08 + Math.random() * 0.08);
                        g.fillRect(L, fy, S, 1);
                    }
                    // Secondary quick flash
                    if ((t % 700) < 40) {
                        const fy2 = T + (((t * 13) % 100) / 100) * S;
                        g.fillStyle(fc, 0.1);
                        g.fillRect(L, fy2, S, 1.5);
                    }
                    // Corner crackle
                    if ((t % 1100) < 30) {
                        g.lineStyle(0.5, fc, 0.3);
                        const cx2 = L + ((t * 3) % S);
                        const cy2 = T + ((t * 7) % S);
                        for (let j = 0; j < 2; j++) {
                            const nx = cx2 + (Math.random() - 0.5) * S * 0.4;
                            const ny = cy2 + (Math.random() - 0.5) * S * 0.3;
                            g.lineBetween(cx2, cy2, nx, ny);
                        }
                    }
                }
            });
            
        } else if (flair.id === 'void') {
            // Void shimmer: dark edges pulse inward, center darkens
            scene.tweens.addCounter({
                from: 0, to: 1, duration: 2800, repeat: -1, yoyo: true,
                ease: 'Sine.easeInOut',
                onUpdate: (tw) => {
                    if (!g.scene) return;
                    g.clear();
                    const v = tw.getValue();
                    // Edge vignette — grows inward
                    const inset = S * (0.05 + v * 0.15);
                    g.fillStyle(fc, 0.04 + v * 0.06);
                    g.fillRect(L, T, S, inset); // top
                    g.fillRect(L, T + S - inset, S, inset); // bottom
                    g.fillRect(L, T + inset, inset, S - inset * 2); // left
                    g.fillRect(L + S - inset, T + inset, inset, S - inset * 2); // right
                    // Dark center pulse
                    g.fillStyle(0x110022, 0.03 + v * 0.04);
                    const cs = S * (0.3 + v * 0.15);
                    g.fillRect(x - cs / 2, y - cs / 2, cs, cs);
                }
            });
            
        } else if (flair.id === 'frost') {
            // Ice shimmer: slow diagonal sweep of white shimmer + sparkle dots
            scene.tweens.addCounter({
                from: 0, to: 1, duration: 2400, repeat: -1,
                ease: 'Linear',
                onUpdate: (tw) => {
                    if (!g.scene) return;
                    g.clear();
                    const v = tw.getValue();
                    // Diagonal sweep band — top-left to bottom-right
                    const bandW = S * 0.2;
                    const sweep = L - bandW + (S + bandW * 2) * v;
                    for (let row = 0; row < S; row++) {
                        const rx = sweep + row * 0.5; // diagonal offset
                        if (rx > L && rx < L + S - 2) {
                            const dist = Math.min(row / S, 1 - row / S) * 2;
                            g.fillStyle(0xffffff, 0.06 * dist);
                            g.fillRect(rx, T + row, bandW * 0.3, 1);
                            g.fillStyle(fc, 0.04 * dist);
                            g.fillRect(rx - 1, T + row, bandW * 0.5, 1);
                        }
                    }
                    // Static sparkle dots — twinkle based on time
                    const t = Date.now();
                    const dots = [[0.2,0.3],[0.7,0.2],[0.4,0.7],[0.8,0.6],[0.15,0.8]];
                    dots.forEach(([dx, dy], i) => {
                        const twinkle = Math.sin(t * 0.004 + i * 1.8) * 0.5 + 0.5;
                        if (twinkle > 0.6) {
                            g.fillStyle(0xffffff, (twinkle - 0.6) * 0.35);
                            g.fillCircle(L + dx * S, T + dy * S, 0.5);
                        }
                    });
                }
            });
            
        } else if (flair.id === 'gilded') {
            // Gold shimmer: classic diagonal shine sweep
            scene.tweens.addCounter({
                from: 0, to: 1, duration: 2000, repeat: -1,
                repeatDelay: 800, ease: 'Linear',
                onUpdate: (tw) => {
                    if (!g.scene) return;
                    g.clear();
                    const v = tw.getValue();
                    if (v > 0.9) return; // pause at end before repeat
                    const norm = v / 0.9;
                    // Diagonal band sweeps from top-left to bottom-right
                    const bandW = S * 0.3;
                    const sweep = L - bandW + (S + bandW * 2) * norm;
                    for (let row = 0; row < S; row++) {
                        const rx = sweep + row * 0.7;
                        if (rx > L && rx + 2 < L + S) {
                            const dist = Math.min(row / S, 1 - row / S) * 2;
                            // Bright core
                            g.fillStyle(0xffffff, 0.1 * dist);
                            g.fillRect(rx, T + row, 2, 1);
                            // Gold glow on sides
                            g.fillStyle(fc, 0.07 * dist);
                            g.fillRect(rx - 3, T + row, 3, 1);
                            g.fillRect(rx + 2, T + row, 3, 1);
                        }
                    }
                }
            });
            
        } else if (flair.id === 'spectral') {
            // Ghost shimmer: edges glow and breathe, faint inner ripple
            scene.tweens.addCounter({
                from: 0, to: 1, duration: 2400, repeat: -1, yoyo: true,
                ease: 'Sine.easeInOut',
                onUpdate: (tw) => {
                    if (!g.scene) return;
                    g.clear();
                    const v = tw.getValue();
                    // Edge glow — all four edges breathe
                    const edgeW = 2 + v * 2;
                    g.fillStyle(fc, 0.04 + v * 0.06);
                    g.fillRect(L, T, S, edgeW); // top
                    g.fillRect(L, T + S - edgeW, S, edgeW); // bottom
                    g.fillRect(L, T, edgeW, S); // left
                    g.fillRect(L + S - edgeW, T, edgeW, S); // right
                    // Inner ripple — expands from center
                    const t = Date.now();
                    const ripple = (t % 3000) / 3000;
                    const rSize = S * 0.2 + S * 0.6 * ripple;
                    const rAlpha = 0.06 * (1 - ripple);
                    if (rAlpha > 0.01) {
                        g.lineStyle(0.5, fc, rAlpha);
                        g.strokeRect(x - rSize / 2, y - rSize / 2, rSize, rSize);
                    }
                }
            });
        }
    }
    
    // ══════════════════════════════════════════════════════════════════
    // FOUNDRY BADGE — D2-style emblem tracker, right-aligned compact strip
    // ══════════════════════════════════════════════════════════════════
    static drawFoundryBadge(scene, addC, rightX, y, foundryId, flairObj, D) {
        const foundry = CONFIG.foundries[foundryId];
        if (!foundry) return 0;
        const p = foundry.palette;
        const bgColor = parseInt(p.bodyDark.replace('#', ''), 16);
        const accentColor = parseInt(p.accent.replace('#', ''), 16);
        const bodyLight = parseInt(p.bodyLight.replace('#', ''), 16);
        const metalColor = parseInt(p.metal.replace('#', ''), 16);
        
        const badgeH = 16;
        const nameW = foundry.name.length * 5.5 + 6;
        const iconW = 14;
        const flairW = flairObj ? 18 : 0;
        const badgeW = 4 + iconW + nameW + flairW + 4; // accent + icon + text + flair + pad
        const bx = rightX - badgeW; // left edge
        const by = y - badgeH / 2;
        
        const g = scene.add.graphics().setDepth(D).setScrollFactor(0);
        addC(g);
        
        // Badge background — dark strip with subtle roundedness
        g.fillStyle(0x0a0a12, 0.85);
        g.fillRoundedRect(bx, by, badgeW, badgeH, 2);
        // Inner border
        g.lineStyle(0.5, accentColor, 0.3);
        g.strokeRoundedRect(bx, by, badgeW, badgeH, 2);
        
        // Accent bar — left edge color stripe
        g.fillStyle(accentColor, 0.8);
        g.fillRect(bx, by + 1, 3, badgeH - 2);
        // Accent glow
        g.fillStyle(accentColor, 0.15);
        g.fillRect(bx + 3, by + 1, 4, badgeH - 2);
        
        // Mini foundry icon (10x10 centered in iconW area)
        const ix = bx + 4 + iconW / 2;
        const iy = y;
        InventoryUI._drawMiniFoundryLogo(g, ix, iy, foundryId, accentColor, bgColor, bodyLight, metalColor);
        
        // Foundry name text
        const nameX = bx + 4 + iconW + 2;
        addC(scene.add.text(nameX, y, foundry.name.toUpperCase(), {
            fontFamily: CONFIG.font, fontSize: '7px', fill: '#' + accentColor.toString(16).padStart(6, '0'),
            fontStyle: 'bold'
        }).setOrigin(0, 0.5).setDepth(D + 1).setScrollFactor(0).setAlpha(0.85));
        
        // Flair icon (if present)
        if (flairObj) {
            const fx = rightX - 12;
            InventoryUI.drawFlairIcon(g, fx, iy, flairObj, 5);
            // Separator dot
            g.fillStyle(accentColor, 0.2);
            g.fillCircle(fx - 8, iy, 1);
        }
        
        return badgeH;
    }
    
    // Mini foundry logo (8px) for badge
    static _drawMiniFoundryLogo(g, x, y, id, ac, bg, light, metal) {
        if (id === 'terracorp') {
            // Shield
            g.fillStyle(ac, 0.5);
            g.beginPath();
            g.moveTo(x, y - 4); g.lineTo(x + 4, y - 1); g.lineTo(x + 4, y + 2);
            g.lineTo(x, y + 5); g.lineTo(x - 4, y + 2); g.lineTo(x - 4, y - 1);
            g.closePath(); g.fillPath();
            g.lineStyle(0.4, ac, 0.7);
            g.beginPath();
            g.moveTo(x, y - 4); g.lineTo(x + 4, y - 1); g.lineTo(x + 4, y + 2);
            g.lineTo(x, y + 5); g.lineTo(x - 4, y + 2); g.lineTo(x - 4, y - 1);
            g.closePath(); g.strokePath();
            g.fillStyle(ac, 0.8);
            g.fillRect(x - 2, y - 3, 4, 1); // T bar
            g.fillRect(x - 0.5, y - 3, 1, 5); // T stem
        } else if (id === 'ucr') {
            // Reticle
            g.lineStyle(0.6, ac, 0.5);
            g.strokeCircle(x, y, 4);
            g.lineStyle(0.4, ac, 0.7);
            g.lineBetween(x, y - 5, x, y - 2); g.lineBetween(x, y + 2, x, y + 5);
            g.lineBetween(x - 5, y, x - 2, y); g.lineBetween(x + 2, y, x + 5, y);
            g.fillStyle(ac, 0.6);
            g.fillCircle(x, y, 1);
        } else if (id === 'deralict') {
            // Gear
            g.lineStyle(0.8, ac, 0.5);
            g.strokeCircle(x, y, 4);
            g.lineStyle(0.5, ac, 0.6);
            g.lineBetween(x - 3, y - 3, x + 3, y + 3);
            g.lineBetween(x + 3, y - 3, x - 3, y + 3);
            g.fillStyle(metal, 0.7);
            g.fillCircle(x, y, 1.5);
        } else if (id === 'sworn') {
            // Fist
            g.fillStyle(ac, 0.6);
            g.fillRect(x - 2, y - 1, 4, 5); // palm
            g.fillRect(x - 2, y - 5, 1.5, 4); // finger
            g.fillRect(x - 0.5, y - 5, 1.5, 5); // finger
            g.fillRect(x + 1, y - 4, 1.5, 4); // finger
            // Chain
            g.lineStyle(0.4, metal, 0.4);
            g.strokeCircle(x - 4, y + 1, 1.5);
            g.strokeCircle(x + 4, y + 1, 1.5);
        } else if (id === 'blackreach') {
            // Diamond
            g.lineStyle(0.6, ac, 0.6);
            g.beginPath();
            g.moveTo(x, y - 5); g.lineTo(x + 5, y); g.lineTo(x, y + 5); g.lineTo(x - 5, y);
            g.closePath(); g.strokePath();
            g.fillStyle(ac, 0.3);
            g.beginPath();
            g.moveTo(x, y - 3); g.lineTo(x + 3, y); g.lineTo(x, y + 3); g.lineTo(x - 3, y);
            g.closePath(); g.fillPath();
            g.fillStyle(light, 0.5);
            g.fillCircle(x, y, 1);
        } else if (id === 'cephalon') {
            // Hexagon
            g.lineStyle(0.5, ac, 0.5);
            g.beginPath();
            for (let i = 0; i < 6; i++) {
                const a = i * Math.PI / 3 - Math.PI / 6;
                const px = x + Math.cos(a) * 5, py = y + Math.sin(a) * 5;
                if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
            }
            g.closePath(); g.strokePath();
            g.fillStyle(ac, 0.5);
            g.fillCircle(x, y, 1.5);
            g.fillStyle(0xffffff, 0.3);
            g.fillCircle(x, y, 0.5);
        }
    }
    
    // Large foundry watermark for item card — bottom-right, semi-transparent
    // Pre-rotate weapon canvas into a clipped square for slot/card icons
    // Returns a canvas of clipSize×clipSize with the weapon centered, rotated, scaled, and cropped
    static _cropWeaponIcon(wc, item, clipSize, scale) {
        const crop = document.createElement('canvas');
        crop.width = clipSize; crop.height = clipSize;
        const ctx = crop.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.translate(clipSize / 2, clipSize / 2);
        const rot = item.category === 'melee' ? Math.PI / 4 : -Math.PI / 4;
        ctx.rotate(rot);
        ctx.scale(scale, scale);
        // Weapons: center on grip (weapon body centered around grip)
        // Melee: center on canvas center (grip is offset for hand position)
        const ox = wc.isMelee ? wc.canvas.width / 2 : wc.gripX;
        const oy = wc.isMelee ? wc.canvas.height / 2 : wc.gripY;
        ctx.drawImage(wc.canvas, -ox, -oy);
        return crop;
    }
    
    static _drawFoundryWatermark(scene, addC, x, y, foundryId, D) {
        const foundry = CONFIG.foundries[foundryId];
        if (!foundry) return;
        const p = foundry.palette;
        const ac = parseInt(p.accent.replace('#', ''), 16);
        const light = parseInt(p.bodyLight.replace('#', ''), 16);
        const metal = parseInt(p.metal.replace('#', ''), 16);
        const det = parseInt(p.detail.replace('#', ''), 16);
        
        const g = scene.add.graphics().setDepth(D).setScrollFactor(0).setAlpha(0.16);
        addC(g);
        const S = 5;
        
        // Each foundry: detailed logo shape + name text with unique font
        const fontMap = {
            terracorp:  { font: 'Impact, "Arial Narrow", sans-serif', style: 'normal', spacing: 3 },
            ucr:        { font: '"Segoe UI", Helvetica, Arial, sans-serif', style: 'normal', spacing: 2 },
            deralict:   { font: '"Courier New", Courier, monospace', style: 'bold', spacing: 1 },
            sworn:      { font: 'Georgia, "Times New Roman", serif', style: 'italic', spacing: 1 },
            blackreach: { font: '"Palatino Linotype", "Book Antiqua", Palatino, serif', style: 'normal', spacing: 2 },
            cephalon:   { font: '"Lucida Console", Monaco, monospace', style: 'normal', spacing: 3 }
        };
        const fStyle = fontMap[foundryId] || fontMap.terracorp;
        const acHex = '#' + ac.toString(16).padStart(6, '0');
        
        if (foundryId === 'terracorp') {
            // Shield with cross + inner detail
            g.fillStyle(ac, 0.4);
            g.beginPath();
            g.moveTo(x, y - 4*S); g.lineTo(x + 4*S, y - 1*S); g.lineTo(x + 4*S, y + 2*S);
            g.lineTo(x, y + 5*S); g.lineTo(x - 4*S, y + 2*S); g.lineTo(x - 4*S, y - 1*S);
            g.closePath(); g.fillPath();
            g.lineStyle(1.2, ac, 0.8);
            g.beginPath();
            g.moveTo(x, y - 4*S); g.lineTo(x + 4*S, y - 1*S); g.lineTo(x + 4*S, y + 2*S);
            g.lineTo(x, y + 5*S); g.lineTo(x - 4*S, y + 2*S); g.lineTo(x - 4*S, y - 1*S);
            g.closePath(); g.strokePath();
            // Cross
            g.fillStyle(ac, 0.9);
            g.fillRect(x - 2*S, y - 2.5*S, 4*S, 1*S);
            g.fillRect(x - 0.5*S, y - 2.5*S, 1*S, 4.5*S);
            // Inner border
            g.lineStyle(0.5, light, 0.35);
            g.beginPath();
            g.moveTo(x, y - 2.5*S); g.lineTo(x + 2.5*S, y - 0.5*S); g.lineTo(x + 2.5*S, y + 1.5*S);
            g.lineTo(x, y + 3.5*S); g.lineTo(x - 2.5*S, y + 1.5*S); g.lineTo(x - 2.5*S, y - 0.5*S);
            g.closePath(); g.strokePath();
        } else if (foundryId === 'ucr') {
            // Crosshair reticle
            g.lineStyle(1.5, ac, 0.5);
            g.strokeCircle(x, y, 4*S);
            g.lineStyle(0.5, ac, 0.3);
            g.strokeCircle(x, y, 2.5*S);
            g.lineStyle(1, ac, 0.7);
            g.lineBetween(x, y - 5*S, x, y - 2*S); g.lineBetween(x, y + 2*S, x, y + 5*S);
            g.lineBetween(x - 5*S, y, x - 2*S, y); g.lineBetween(x + 2*S, y, x + 5*S, y);
            // Tick marks on circle
            for (let i = 0; i < 4; i++) {
                const a = i * Math.PI / 2 + Math.PI / 4;
                g.lineStyle(0.5, ac, 0.5);
                g.lineBetween(x + Math.cos(a)*3.5*S, y + Math.sin(a)*3.5*S, x + Math.cos(a)*4.5*S, y + Math.sin(a)*4.5*S);
            }
            g.fillStyle(ac, 0.6);
            g.fillCircle(x, y, 1*S);
        } else if (foundryId === 'deralict') {
            // Gear/cog with hazard X
            g.lineStyle(2, ac, 0.5);
            g.strokeCircle(x, y, 3.5*S);
            // Gear teeth
            g.lineStyle(2, metal, 0.6);
            for (let i = 0; i < 8; i++) {
                const a = i * Math.PI / 4;
                const ix = x + Math.cos(a) * 3*S, iy = y + Math.sin(a) * 3*S;
                const ox = x + Math.cos(a) * 5*S, oy = y + Math.sin(a) * 5*S;
                g.lineBetween(ix, iy, ox, oy);
            }
            // Hazard X
            g.lineStyle(1.5, ac, 0.7);
            g.lineBetween(x - 2.5*S, y - 2.5*S, x + 2.5*S, y + 2.5*S);
            g.lineBetween(x + 2.5*S, y - 2.5*S, x - 2.5*S, y + 2.5*S);
            g.fillStyle(metal, 0.7);
            g.fillCircle(x, y, 1.5*S);
            // Hazard stripes
            g.lineStyle(0.5, det, 0.4);
            g.lineBetween(x - 2*S, y + 4*S, x + 2*S, y + 4*S);
            g.lineBetween(x - 1.5*S, y + 4.5*S, x + 1.5*S, y + 4.5*S);
        } else if (foundryId === 'sworn') {
            // Raised fist
            g.fillStyle(ac, 0.5);
            g.fillRect(x - 2*S, y - 1*S, 4*S, 5*S);
            g.fillRect(x - 2*S, y - 5*S, 1.5*S, 4*S);
            g.fillRect(x - 0.5*S, y - 5*S, 1.5*S, 5*S);
            g.fillRect(x + 1*S, y - 4*S, 1.5*S, 4*S);
            g.lineStyle(0.8, ac, 0.7);
            g.strokeRect(x - 2*S, y - 1*S, 4*S, 5*S);
            // Star flanks
            g.lineStyle(1, metal, 0.5);
            g.strokeCircle(x - 4*S, y + 1*S, 1.5*S);
            g.strokeCircle(x + 4*S, y + 1*S, 1.5*S);
            g.fillStyle(metal, 0.6);
            g.fillCircle(x - 4*S, y + 1*S, 0.5*S);
            g.fillCircle(x + 4*S, y + 1*S, 0.5*S);
            // Underline bar
            g.fillStyle(ac, 0.4);
            g.fillRect(x - 4*S, y + 4.5*S, 8*S, 0.5*S);
        } else if (foundryId === 'blackreach') {
            // Double diamond with eye
            g.lineStyle(1.5, ac, 0.6);
            g.beginPath();
            g.moveTo(x, y - 5*S); g.lineTo(x + 5*S, y); g.lineTo(x, y + 5*S); g.lineTo(x - 5*S, y);
            g.closePath(); g.strokePath();
            g.fillStyle(ac, 0.2);
            g.beginPath();
            g.moveTo(x, y - 3*S); g.lineTo(x + 3*S, y); g.lineTo(x, y + 3*S); g.lineTo(x - 3*S, y);
            g.closePath(); g.fillPath();
            g.lineStyle(0.5, ac, 0.4);
            g.beginPath();
            g.moveTo(x, y - 3*S); g.lineTo(x + 3*S, y); g.lineTo(x, y + 3*S); g.lineTo(x - 3*S, y);
            g.closePath(); g.strokePath();
            // Eye
            g.fillStyle(light, 0.5);
            g.fillCircle(x, y, 1.2*S);
            g.fillStyle(0x000000, 0.4);
            g.fillCircle(x, y, 0.5*S);
            // Corner filigree dots
            g.fillStyle(ac, 0.3);
            g.fillCircle(x, y - 4.2*S, 0.4*S);
            g.fillCircle(x, y + 4.2*S, 0.4*S);
        } else if (foundryId === 'cephalon') {
            // Hexagon with circuit lines
            g.lineStyle(1.2, ac, 0.5);
            g.beginPath();
            for (let i = 0; i < 6; i++) {
                const a = i * Math.PI / 3 - Math.PI / 6;
                const px = x + Math.cos(a) * 5*S, py = y + Math.sin(a) * 5*S;
                if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
            }
            g.closePath(); g.strokePath();
            // Inner hex
            g.lineStyle(0.5, ac, 0.25);
            g.beginPath();
            for (let i = 0; i < 6; i++) {
                const a = i * Math.PI / 3 - Math.PI / 6;
                const px = x + Math.cos(a) * 3*S, py = y + Math.sin(a) * 3*S;
                if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
            }
            g.closePath(); g.strokePath();
            // Circuit lines
            g.lineStyle(0.5, ac, 0.35);
            for (let i = 0; i < 6; i++) {
                const a = i * Math.PI / 3 - Math.PI / 6;
                g.lineBetween(x + Math.cos(a)*1.5*S, y + Math.sin(a)*1.5*S, x + Math.cos(a)*3*S, y + Math.sin(a)*3*S);
            }
            // Node dots at vertices
            g.fillStyle(ac, 0.4);
            for (let i = 0; i < 6; i++) {
                const a = i * Math.PI / 3 - Math.PI / 6;
                g.fillCircle(x + Math.cos(a)*3*S, y + Math.sin(a)*3*S, 0.5*S);
            }
            g.fillStyle(ac, 0.5);
            g.fillCircle(x, y, 1.5*S);
            g.fillStyle(0xffffff, 0.3);
            g.fillCircle(x, y, 0.5*S);
        }
        
        // Foundry name centered on logo
        const nameCol = foundryId === 'blackreach' ? '#ddc866' : 
                        foundryId === 'cephalon' ? '#88ffee' :
                        foundryId === 'deralict' ? '#ffcc44' :
                        foundryId === 'sworn' ? '#aabb88' :
                        foundryId === 'ucr' ? '#ddeeff' : '#eeddcc';
        addC(scene.add.text(x, y, foundry.name.toUpperCase(), {
            fontFamily: fStyle.font, fontSize: uiPx(6), fill: nameCol,
            fontStyle: fStyle.style, letterSpacing: fStyle.spacing
        }).setOrigin(0.5).setDepth(D + 0.5).setScrollFactor(0).setAlpha(0.35));
    }
    
    // ══════════════════════════════════════════════════════════════════
    // FLAIR ICON — detailed per-flair-type icon drawn at size
    // ══════════════════════════════════════════════════════════════════
    static drawFlairIcon(g, x, y, flair, size) {
        if (!flair) return;
        const fc = flair.color;
        const s = size;
        
        if (flair.id === 'ember') {
            // Flame — tear shape with inner core (no quadraticCurveTo — Phaser doesn't have it)
            g.fillStyle(fc, 0.7);
            g.beginPath();
            g.moveTo(x, y - s);                     // tip
            g.lineTo(x + s * 0.6, y + s * 0.2);    // right
            g.lineTo(x + s * 0.45, y + s * 0.55);  // right curve approx
            g.lineTo(x + s * 0.2, y + s * 0.75);   // right bottom
            g.lineTo(x, y + s * 0.7);               // center bottom
            g.lineTo(x - s * 0.2, y + s * 0.75);   // left bottom
            g.lineTo(x - s * 0.45, y + s * 0.55);  // left curve approx
            g.lineTo(x - s * 0.6, y + s * 0.2);    // left
            g.closePath(); g.fillPath();
            // Inner flame
            g.fillStyle(0xffdd44, 0.5);
            g.beginPath();
            g.moveTo(x, y - s * 0.4);
            g.lineTo(x + s * 0.25, y + s * 0.3);
            g.lineTo(x + s * 0.1, y + s * 0.5);
            g.lineTo(x, y + s * 0.45);
            g.lineTo(x - s * 0.1, y + s * 0.5);
            g.lineTo(x - s * 0.25, y + s * 0.3);
            g.closePath(); g.fillPath();
            // Hot core
            g.fillStyle(0xffffff, 0.4);
            g.fillCircle(x, y + s * 0.15, s * 0.15);
        } else if (flair.id === 'electric') {
            // Lightning bolt
            g.fillStyle(fc, 0.8);
            g.beginPath();
            g.moveTo(x + s * 0.1, y - s);          // top
            g.lineTo(x + s * 0.5, y - s);
            g.lineTo(x - s * 0.05, y - s * 0.1);   // middle left
            g.lineTo(x + s * 0.3, y - s * 0.1);
            g.lineTo(x - s * 0.3, y + s);           // bottom point
            g.lineTo(x + s * 0.05, y + s * 0.05);   // middle right
            g.lineTo(x - s * 0.25, y + s * 0.05);
            g.closePath(); g.fillPath();
            // Bright center line
            g.lineStyle(0.5, 0xffffff, 0.5);
            g.lineBetween(x + s * 0.2, y - s * 0.7, x - s * 0.1, y + s * 0.5);
        } else if (flair.id === 'void') {
            // Vortex spiral
            g.lineStyle(1, fc, 0.6);
            g.beginPath();
            for (let t = 0; t < Math.PI * 4; t += 0.2) {
                const r = s * 0.15 + t * s * 0.08;
                const px = x + Math.cos(t) * r;
                const py = y + Math.sin(t) * r;
                if (t === 0) g.moveTo(px, py); else g.lineTo(px, py);
            }
            g.strokePath();
            // Dark core
            g.fillStyle(0x220033, 0.6);
            g.fillCircle(x, y, s * 0.3);
            g.fillStyle(fc, 0.4);
            g.fillCircle(x, y, s * 0.15);
        } else if (flair.id === 'frost') {
            // Snowflake/crystal — 6-armed
            g.lineStyle(0.6, fc, 0.7);
            for (let i = 0; i < 6; i++) {
                const a = i * Math.PI / 3;
                g.lineBetween(x, y, x + Math.cos(a) * s, y + Math.sin(a) * s);
                // Branches
                const bx = x + Math.cos(a) * s * 0.55;
                const by = y + Math.sin(a) * s * 0.55;
                g.lineBetween(bx, by, bx + Math.cos(a + 0.7) * s * 0.3, by + Math.sin(a + 0.7) * s * 0.3);
                g.lineBetween(bx, by, bx + Math.cos(a - 0.7) * s * 0.3, by + Math.sin(a - 0.7) * s * 0.3);
            }
            // Center gem
            g.fillStyle(0xffffff, 0.3);
            g.fillCircle(x, y, s * 0.2);
        } else if (flair.id === 'gilded') {
            // Gold ingot / bar
            g.fillStyle(fc, 0.7);
            // Trapezoid top face
            g.beginPath();
            g.moveTo(x - s * 0.5, y - s * 0.1);
            g.lineTo(x - s * 0.3, y - s * 0.6);
            g.lineTo(x + s * 0.3, y - s * 0.6);
            g.lineTo(x + s * 0.5, y - s * 0.1);
            g.closePath(); g.fillPath();
            // Front face
            g.fillStyle(fc, 0.5);
            g.fillRect(x - s * 0.5, y - s * 0.1, s, s * 0.7);
            // Shine
            g.fillStyle(0xffffff, 0.25);
            g.beginPath();
            g.moveTo(x - s * 0.2, y - s * 0.5);
            g.lineTo(x, y - s * 0.5);
            g.lineTo(x + s * 0.1, y - s * 0.1);
            g.lineTo(x - s * 0.1, y - s * 0.1);
            g.closePath(); g.fillPath();
        } else if (flair.id === 'spectral') {
            // Ghost wisp
            g.fillStyle(fc, 0.4);
            // Head
            g.fillCircle(x, y - s * 0.3, s * 0.4);
            // Body — wavy trail downward (lineTo approximation)
            g.beginPath();
            g.moveTo(x - s * 0.4, y - s * 0.3);
            g.lineTo(x - s * 0.35, y + s * 0.5);
            g.lineTo(x - s * 0.2, y + s * 0.35);
            g.lineTo(x, y + s * 0.6);
            g.lineTo(x + s * 0.2, y + s * 0.45);
            g.lineTo(x + s * 0.35, y + s * 0.5);
            g.lineTo(x + s * 0.4, y - s * 0.3);
            g.closePath(); g.fillPath();
            // Eyes
            g.fillStyle(0xffffff, 0.5);
            g.fillCircle(x - s * 0.15, y - s * 0.35, s * 0.1);
            g.fillCircle(x + s * 0.15, y - s * 0.35, s * 0.1);
        }
    }
    
    // ══════════════════════════════════════════════════════════════════
    // FLAIR RACK ANIMATION — animated effects for safehouse loadout rack
    // ══════════════════════════════════════════════════════════════════
    static addFlairRackEffect(scene, container, x, y, flair) {
        if (!flair) return;
        const fc = flair.color;
        
        if (flair.id === 'ember') {
            // Rising ember particles
            for (let i = 0; i < 4; i++) {
                const spark = scene.add.circle(
                    x - 3 + Math.random() * 6,
                    y + 2,
                    0.5 + Math.random() * 0.5,
                    fc, 0.6
                );
                container.add(spark);
                scene.tweens.add({
                    targets: spark,
                    y: y - 8 - Math.random() * 6,
                    x: spark.x + (Math.random() - 0.5) * 4,
                    alpha: 0,
                    duration: 1200 + Math.random() * 800,
                    delay: i * 400 + Math.random() * 300,
                    repeat: -1,
                    ease: 'Sine.easeOut'
                });
            }
            // Warm underglow
            const glow = scene.add.circle(x, y + 2, 5, fc, 0.12);
            container.add(glow);
            scene.tweens.add({
                targets: glow, alpha: { from: 0.08, to: 0.18 },
                duration: 800, yoyo: true, repeat: -1
            });
        } else if (flair.id === 'electric') {
            // Periodic arc flash
            const arcG = scene.add.graphics();
            container.add(arcG);
            const flashArc = () => {
                arcG.clear();
                arcG.lineStyle(0.5, fc, 0.6);
                let ax = x - 4, ay = y - 2 + Math.random() * 4;
                for (let j = 0; j < 3; j++) {
                    const nx = ax + 2 + Math.random() * 3;
                    const ny = ay + (Math.random() - 0.5) * 6;
                    arcG.lineBetween(ax, ay, nx, ny);
                    ax = nx; ay = ny;
                }
                // Flash dot
                arcG.fillStyle(0xffffff, 0.5);
                arcG.fillCircle(ax, ay, 0.8);
                scene.time.delayedCall(80, () => arcG.clear());
            };
            scene.time.addEvent({
                delay: 600 + Math.random() * 400,
                callback: flashArc,
                loop: true
            });
        } else if (flair.id === 'void') {
            // Pulsing dark aura
            const aura = scene.add.circle(x, y, 6, 0x220033, 0.15);
            container.add(aura);
            scene.tweens.add({
                targets: aura, scaleX: { from: 0.8, to: 1.3 },
                scaleY: { from: 0.8, to: 1.3 }, alpha: { from: 0.15, to: 0.05 },
                duration: 1500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
            });
            // Wisps
            for (let i = 0; i < 2; i++) {
                const wisp = scene.add.circle(x, y, 0.8, fc, 0.3);
                container.add(wisp);
                const ang = i * Math.PI;
                scene.tweens.add({
                    targets: wisp,
                    x: { from: x + Math.cos(ang) * 3, to: x + Math.cos(ang + Math.PI) * 3 },
                    y: { from: y + Math.sin(ang) * 3, to: y + Math.sin(ang + Math.PI) * 3 },
                    alpha: { from: 0.3, to: 0.1 },
                    duration: 2000, yoyo: true, repeat: -1, delay: i * 500,
                    ease: 'Sine.easeInOut'
                });
            }
        } else if (flair.id === 'frost') {
            // Ice shimmer particles
            const iceG = scene.add.graphics();
            container.add(iceG);
            iceG.fillStyle(fc, 0.15);
            iceG.fillCircle(x, y, 5);
            // Sparkle cycle
            const sparkle = () => {
                iceG.clear();
                iceG.fillStyle(fc, 0.1);
                iceG.fillCircle(x, y, 5);
                for (let i = 0; i < 3; i++) {
                    const sx = x - 4 + Math.random() * 8;
                    const sy = y - 4 + Math.random() * 8;
                    iceG.fillStyle(0xffffff, 0.2 + Math.random() * 0.2);
                    iceG.fillCircle(sx, sy, 0.3 + Math.random() * 0.3);
                }
            };
            scene.time.addEvent({ delay: 800, callback: sparkle, loop: true });
            sparkle();
        } else if (flair.id === 'gilded') {
            // Gold gleam sweep
            const gleam = scene.add.rectangle(x - 6, y, 2, 10, fc, 0.3);
            container.add(gleam);
            scene.tweens.add({
                targets: gleam,
                x: { from: x - 6, to: x + 6 },
                alpha: { from: 0.0, to: 0.35 },
                duration: 1200, repeat: -1, repeatDelay: 2000,
                ease: 'Sine.easeInOut',
                yoyo: true
            });
        } else if (flair.id === 'spectral') {
            // Ghostly pulse
            const ghost = scene.add.circle(x, y, 5, fc, 0.08);
            container.add(ghost);
            scene.tweens.add({
                targets: ghost,
                alpha: { from: 0.05, to: 0.2 },
                scaleX: { from: 1, to: 1.4 },
                scaleY: { from: 1, to: 1.4 },
                duration: 1800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
            });
            // Afterimage flicker
            const after = scene.add.circle(x + 1, y - 1, 3, fc, 0.06);
            container.add(after);
            scene.tweens.add({
                targets: after,
                x: { from: x + 1, to: x + 3 }, alpha: { from: 0.06, to: 0.15 },
                duration: 2200, yoyo: true, repeat: -1, delay: 600
            });
        }
    }
    
    // ══════════════════════════════════════════════════════════════════
    // SHARED ITEM CARD RENDERER — single source of truth for card layout
    // Called by showItemCard (loadout) and _showQuickCard (HUD dropdown)
    // opts: { interactive: bool, inventoryUI: ref, equipment: ref, backpack: ref }
    // ══════════════════════════════════════════════════════════════════
    static renderItemCard(s, item, addC, cx, cy, cardW, cardH, D, opts = {}) {
        const GAP = 6;
        const isWM = (item.category === 'weapon' || item.category === 'melee');
        const itemColor = ItemManager.getItemColor(item);
        const tierColorHex = '#' + itemColor.toString(16).padStart(6, '0');
        const hasBanner = item.foundry && CONFIG.foundries[item.foundry];
        
        // Corner bracket helper
        const _brackets = (x1, y1, x2, y2, w, h, len, color, alpha) => {
            const l = x1, r = x2, t = y1, b = y2;
            [[l,t,l+len,t],[l,t,l,t+len],[r,t,r-len,t],[r,t,r,t+len],
             [l,b,l+len,b],[l,b,l,b-len],[r,b,r-len,b],[r,b,r,b-len]
            ].forEach(([a,b,c,d]) => {
                addC(s.add.line(0,0,a,b,c,d,color,alpha).setOrigin(0).setDepth(D+3).setScrollFactor(0));
            });
        };
        
        // ── ICON (top-left, fixed) ──
        const iconY = cy - cardH/2 + 30;
        const iconX = cx - cardW/2 + 30;
        if (item.procedural && (isWM || item.category === 'gear')) {
            if (item.flair) {
                InventoryUI.addFlairShimmer(s, addC, iconX, iconY, 36, item.flair, D + 1.3);
            } else {
                addC(s.add.rectangle(iconX, iconY, 36, 36, itemColor, 0.06)
                    .setStrokeStyle(0.5, itemColor, 0.25).setDepth(D + 1.2).setScrollFactor(0));
            }
        }
        const iconC = addC(s.add.container(iconX, iconY).setDepth(D+1.5).setScrollFactor(0));
        if (item.procedural) {
            if (item.category === 'augment') {
                addC(s.add.rectangle(iconX, iconY, 36, 36, 0xaa44ff, 0.06)
                    .setStrokeStyle(0.5, 0xaa44ff, 0.25).setDepth(D + 1.2).setScrollFactor(0));
                ItemManager.drawItemPixelArt(s, iconC, 0, 0, item, 2.5, 0);
            } else if (isWM && ItemManager.renderWeaponCanvas) {
                const wc = ItemManager.renderWeaponCanvas(item);
                if (wc) {
                    const crop = InventoryUI._cropWeaponIcon(wc, item, 36, 2.0);
                    const texKey = '_cardIcon_' + (item.id || Math.random());
                    if (s.textures.exists(texKey)) s.textures.remove(texKey);
                    s.textures.addCanvas(texKey, crop);
                    addC(s.add.image(iconX, iconY, texKey).setDepth(D+1.5).setScrollFactor(0));
                }
            } else if (item.category === 'gear') {
                ItemManager.drawItemPixelArt(s, iconC, 0, 0, item, 2.8, 0);
            } else {
                ItemManager.drawItemPixelArt(s, iconC, 0, 0, item, 2.0, 0);
                if (isWM) iconC.setRotation(item.category === 'melee' ? Math.PI / 4 : -Math.PI / 4);
            }
        } else if (item.category === 'consumable' || item.category === 'key_item' || item.category === 'scrap' || item.category === 'cube' || item.category === 'key') {
            // Consumable / key_item / scrap / cube / key — use pixel art sprites
            const cBg = ItemManager.getItemColor(item);
            addC(s.add.rectangle(iconX, iconY, 36, 36, cBg, 0.06)
                .setStrokeStyle(0.5, cBg, 0.2).setDepth(D + 1.2).setScrollFactor(0));
            ItemManager.drawItemPixelArt(s, iconC, 0, 0, item, 2.2, 0);
        } else {
            iconC.add(s.add.text(0, 0, item.icon || '?', { fontSize: uiPx(16) }).setOrigin(0.5));
        }
        
        // ── WATERMARK (top-right) ──
        if (hasBanner) {
            InventoryUI._drawFoundryWatermark(s, addC, cx + cardW/2 - 38, cy - cardH/2 + 36, item.foundry, D + 1);
        }
        
        // ── NAME + SUBTITLE (right of icon, bounded so no overlap) ──
        let displayName = item.name;
        if (isWM && item.flair && displayName.startsWith(item.flair.name + ' ')) {
            displayName = displayName.slice(item.flair.name.length + 1);
        }
        // +1 indicator for enhanced weapons
        if (item.enhanceLevel >= 1) displayName += ` +${item.enhanceLevel}`;
        const textL = iconX + 26, textR = cx + cardW/2 - 14;
        const textAvailW = textR - textL;
        
        // Flair name above weapon name (small, in flair color)
        let nameYOffset = -4;
        if (isWM && item.flair) {
            const flairHex = '#' + item.flair.color.toString(16).padStart(6, '0');
            addC(s.add.text(cx, iconY - 16, item.flair.name, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: flairHex, fontStyle: 'italic'
            }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
            nameYOffset = -2;
        }
        
        const nameObj = addC(s.add.text(cx, iconY + nameYOffset, displayName, {
            fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#eeeeee', fontStyle: 'bold',
            wordWrap: { width: textAvailW }
        }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
        let nSz = 14;
        while (nameObj.width > textAvailW && nSz > 9) { nSz--; nameObj.setFontSize(uiPx(nSz)); }
        
        // Subtitle: [Rarity] - [Type]
        const tierDef = item.tier ? CONFIG.tiers[item.tier] : null;
        // Weapons/melee/gear use crafting-tier names (Standard, Military, Forged...)
        // Everything else uses rarity labels (Common, Uncommon, Rare, Legendary...)
        const isWMG = isWM || item.category === 'gear';
        const rarityLabel = tierDef
            ? (isWMG ? tierDef.name : tierDef.label)
            : (item.tierName || (item.rarity ? item.rarity.charAt(0).toUpperCase() + item.rarity.slice(1) : ''));
        const rarityHex = tierDef ? '#' + tierDef.color.toString(16).padStart(6, '0') : tierColorHex;
        let subtitleParts = [rarityLabel];
        if (isWMG && item.frameName) subtitleParts.push(item.frameName);
        else if (item.category === 'augment') {
            const augType = item.relicType === 'active' ? 'Active' : 'Passive';
            subtitleParts.push(`${augType} Augment`);
        } else if (item.category === 'consumable') {
            const subtypeLabels = { bandage: 'Bandage', medkit: 'Medical', grenade: 'Grenade', pylon: 'Pylon', energy_drink: 'Supplement' };
            subtitleParts.push(subtypeLabels[item.subtype] || 'Consumable');
        } else if (item.category === 'cube') {
            subtitleParts.push('Encrypted Cube');
        } else if (item.category === 'key_item') {
            subtitleParts.push('Key Item');
        } else if (item.category === 'scrap') {
            subtitleParts.push('Salvage');
        } else if (item.category === 'key') {
            subtitleParts.push('Access Key');
        } else {
            const catDef = CONFIG.itemCategories[item.category];
            const baseDef = item.baseId ? CONFIG.baseItems[item.baseId] : null;
            let typeLabel = baseDef ? baseDef.name : (catDef ? catDef.label : item.category);
            if (item.category === 'weapon' && CONFIG.itemCategories?.weapon?.label === 'Weapon')
                typeLabel = baseDef ? baseDef.name : 'Gun';
            subtitleParts.push(typeLabel);
        }
        const subObj = addC(s.add.text(cx, iconY + nameYOffset + 16, subtitleParts.filter(Boolean).join(' - '), {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: rarityHex
        }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
        let sSz = 9;
        while (subObj.width > textAvailW && sSz > 6) { sSz--; subObj.setFontSize(uiPx(sSz)); }
        
        // ── FLAVOR TEXT ──
        let yPos = iconY + 26;
        let flavorStr = item.flavorText;
        const isProceduralItem = isWM || item.category === 'gear';
        if (isProceduralItem && !flavorStr && CONFIG.weaponFlavor) {
            const _p = (a) => a[Math.floor(Math.random() * a.length)];
            const fp = CONFIG.weaponFlavor;
            if (item.flair && fp.flair[item.flair.id]) flavorStr = Math.random() < 0.55 ? _p(fp.flair[item.flair.id]) : _p(fp.generic);
            else if (item.foundry && fp.foundry[item.foundry]) flavorStr = Math.random() < 0.5 ? _p(fp.foundry[item.foundry]) : _p(fp.generic);
            else if (item.category === 'melee') flavorStr = Math.random() < 0.45 ? _p(fp.melee) : _p(fp.universal || fp.generic);
            else if (item.category === 'gear' && fp.gear) flavorStr = Math.random() < 0.45 ? _p(fp.gear) : _p(fp.generic);
            else flavorStr = _p(fp.generic);
            item.flavorText = flavorStr;
        }
        if (isProceduralItem && flavorStr) {
            const flavorCol = '#778899';  // always neutral — readability first
            addC(s.add.text(cx, yPos, `"${flavorStr}"`, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: flavorCol,
                fontStyle: 'italic', wordWrap: { width: cardW - 30 }, align: 'center'
            }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0).setAlpha(0.7));
            yPos += 12;
        }
        yPos += GAP;
        
        // ── STAT BARS ──
        const STAT_DISPLAY = {
            damage: { label: 'Damage', max: 100 }, fireRate: { label: 'Fire Rate', max: 100 },
            accuracy: { label: 'Accuracy', max: 100 }, crit: { label: 'Crit', max: 200, unit: '%', displayDiv: 2 },
            mag: { label: 'Mag', max: 100 }, reload: { label: 'Reload', max: 100, invert: true },
            pierce: { label: 'Pierce', max: 5 }, targetRange: { label: 'Target Range', max: 5 },
            attackSpeed: { label: 'Attack Speed', max: 100 }, reach: { label: 'Reach', max: 100 },
            stagger: { label: 'Stagger', max: 100, unit: '%' }, shieldAttack: { label: 'Shield Attack', max: 5 },
            armor: { label: 'Armor', max: 50, unit: '%' },
            health: { label: 'Health', max: 550 }, speed: { label: 'Speed', max: 120, unit: '%' },
            luck: { label: 'Luck', max: 10 }, backpack: { label: 'Backpack', max: 20 },
            maxHealth: { label: 'Health+', max: 200 },
            damageResist: { label: 'Resistance', max: 50, unit: '%' }, lootLuck: { label: 'Loot Luck', max: 50 },
            healBonus: { label: 'Heal Bonus', max: 50, unit: '%' },
            dodge: { label: 'Dodge', max: 20, unit: '%' }
        };
        const modBonuses = {};
        const MOD_TO_STAT = {
            damage: 'damage', meleeDamage: 'damage', fireRate: 'fireRate', reload: 'reload',
            accuracy: 'accuracy', crit: 'crit', mag: 'mag', pierce: 'pierce',
            targetRange: 'targetRange', attackSpeed: 'attackSpeed', stagger: 'stagger',
            reach: 'reach', lifesteal: null, massAttack: null, shieldAttack: 'shieldAttack',
            maxHealth: 'health', carryCapacity: 'backpack', damageResist: null,
            sightline: null, burnResist: null, poisonResist: null, bleedResist: null
        };
        if (item.mods) item.mods.forEach(mod => {
            if (!mod || mod.special) return;
            const m = MOD_TO_STAT[mod.stat]; if (!m) return;
            if (typeof m === 'string') modBonuses[m] = (modBonuses[m] || 0) + mod.value;
        });
        
        const statKeys = item.stats ? Object.keys(item.stats).filter(k => STAT_DISPLAY[k] && (item.stats[k] !== 0 || (modBonuses[k] && modBonuses[k] > 0))) : [];
        if (statKeys.length > 0) {
            const fIn = 12, fW = cardW - fIn * 2;
            const fH = statKeys.length * 15 + 18;
            const fY = yPos + fH / 2 - 2;
            addC(s.add.rectangle(cx, fY, fW, fH, 0x0a0a14, 0.9).setStrokeStyle(0.5, 0x2a2a44).setDepth(D+2).setScrollFactor(0));
            _brackets(cx - fW/2, fY - fH/2, cx + fW/2, fY + fH/2, fW, fH, 6, 0x4466aa, 0.5);
            const lW = 82, nW = 28, bL = cx - fW/2 + lW + 4, bMW = fW - lW - nW - 12, bH = 8;
            let sy = fY - fH/2 + 10;
            statKeys.forEach(key => {
                const bv = item.stats[key], def = STAT_DISPLAY[key]; if (!def) return;
                const bon = modBonuses[key] || 0, tv = bv + bon, hb = Math.abs(bon) > 0.001;
                addC(s.add.text(cx - fW/2 + 8, sy, def.label, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: hb ? '#ddcc66' : '#aabbcc', fontStyle: 'bold' }).setOrigin(0, 0.5).setDepth(D+4).setScrollFactor(0));
                addC(s.add.rectangle(bL + bMW/2, sy, bMW, bH, 0x0e0e1a, 0.95).setStrokeStyle(0.5, 0x1a1a2a).setDepth(D+3).setScrollFactor(0));
                const bp = def.invert ? Math.max(0.05, Math.min(1, (def.max - bv) / def.max)) : Math.max(0.05, Math.min(1, bv / def.max));
                const bfW = Math.max(4, Math.floor(bMW * bp));
                addC(s.add.rectangle(bL + bfW/2, sy, bfW, bH - 2, 0xccccdd, 0.7).setDepth(D+4).setScrollFactor(0));
                if (hb) {
                    const tp = def.invert ? Math.max(0.05, Math.min(1, (def.max - tv) / def.max)) : Math.max(0.05, Math.min(1, tv / def.max));
                    const tfW = Math.max(bfW, Math.floor(bMW * tp)), eW = tfW - bfW;
                    if (eW > 0) addC(s.add.rectangle(bL + bfW + eW/2, sy, eW, bH - 2, 0xddaa33, 0.85).setDepth(D+4).setScrollFactor(0));
                }
                let dv = tv;
                if (def.displayDiv) dv = dv / def.displayDiv;
                dv = typeof dv === 'number' ? (dv % 1 ? dv.toFixed(1) : Math.round(dv)) : dv;
                const dvUnit = def.unit || '';
                addC(s.add.text(cx + fW/2 - 8, sy, `${dv}${dvUnit}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: hb ? '#ffcc44' : '#eeeeff', fontStyle: 'bold' }).setOrigin(1, 0.5).setDepth(D+5).setScrollFactor(0));
                sy += 15;
            });
            yPos = fY + fH/2 + GAP;
        }
        
        // ── MODS + AUGMENT ──
        const hasMods = item.mods && item.mods.length > 0;
        const hasSig = !!item.signatureMod;
        const isAugmentable = isWM || item.category === 'gear';
        // Build combined mod list (regular mods + signature at end)
        const allModEntries = [];
        if (hasMods) item.mods.forEach(mod => {
            const mh = '#' + mod.color.toString(16).padStart(6, '0');
            const tt = mod.tierName ? `[${mod.tierName}]` : '';
            const dv = mod.displayDiv ? (mod.value / mod.displayDiv).toFixed(1) : mod.value;
            allModEntries.push({ text: `${tt} +${dv}${mod.unit || ''} ${mod.name}`, color: mh });
        });
        if (hasSig) {
            const sigType = item.signatureMod.modType === 'active' ? ' [ACTIVE]' : '';
            allModEntries.push({ text: item.signatureMod.name + sigType, color: '#ff4466', bold: true });
            allModEntries.push({ text: item.signatureMod.desc, color: '#cc6688', size: 8 });
            allModEntries.push({ text: '', color: '#cc6688', size: 4 }); // spacer for word-wrap overflow
        }
        const hasAnyMods = allModEntries.length > 0;
        if (hasAnyMods || isAugmentable) {
            const mIn = 12, augW = isAugmentable ? 80 : 0, gap = (hasAnyMods && isAugmentable) ? 6 : 0;
            const MAX_VIS_MODS = 3;
            const modsContentH = hasAnyMods ? (allModEntries.length * 15 + 22) : 0;
            const modsVisH = hasAnyMods ? Math.min(modsContentH, MAX_VIS_MODS * 15 + 22) : 0;
            const needsScroll = modsContentH > modsVisH;
            const augH = isAugmentable ? Math.max(modsVisH, 60) : 0;
            const panelH = Math.max(modsVisH, augH);
            let mfl, mfr;
            
            if (hasAnyMods) {
                const mW = cardW - mIn * 2 - augW - gap;
                const mX = cx - cardW/2 + mIn + mW / 2;
                const mY = yPos + panelH / 2;
                addC(s.add.rectangle(mX, mY, mW, panelH, 0x0a0a14, 0.9).setStrokeStyle(0.5, 0x2a2a44).setDepth(D+2).setScrollFactor(0));
                mfl = mX - mW/2; mfr = mX + mW/2;
                _brackets(mfl, mY - panelH/2, mfr, mY + panelH/2, mW, panelH, 6, 0x4466aa, 0.5);
                addC(s.add.text(mX, mY - panelH/2 + 8, 'MODS', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#556677' }).setOrigin(0.5).setDepth(D+3).setScrollFactor(0));
                
                const modTexts = [];
                allModEntries.forEach((entry, i) => {
                    const sz = entry.size || 10;
                    const t = s.add.text(0, i * 15, entry.text, {
                        fontFamily: CONFIG.font, fontSize: uiPx(sz), fill: entry.color,
                        fontStyle: entry.bold ? 'bold' : '', wordWrap: { width: mW - 20 }
                    }).setOrigin(0, 0.5).setDepth(D+3).setScrollFactor(0);
                    modTexts.push(t);
                });
                
                const clipTop = mY - panelH/2 + 16;
                const clipH = panelH - 16;
                const clipLeft = mfl + 8;
                
                if (needsScroll) {
                    // Put texts in a container positioned at clip region
                    const modContainer = s.add.container(clipLeft, clipTop + 8).setDepth(D+3).setScrollFactor(0);
                    modTexts.forEach(t => modContainer.add(t));
                    addC(modContainer);
                    
                    // Geometry mask to clip overflow
                    const maskShape = s.add.graphics().setScrollFactor(0);
                    maskShape.fillStyle(0xffffff);
                    maskShape.fillRect(clipLeft - 2, clipTop, mW - 6, clipH);
                    const geoMask = maskShape.createGeometryMask();
                    modContainer.setMask(geoMask);
                    maskShape.setVisible(false);
                    addC(maskShape);
                    
                    // Scroll state
                    const maxScroll = modsContentH - 22 - clipH;
                    let scrollY = 0;
                    
                    // Scrollbar track + thumb
                    const sbX = mfr - 6;
                    const sbTrackH = clipH - 4;
                    const sbTrackTop = clipTop + 2;
                    addC(s.add.rectangle(sbX, sbTrackTop + sbTrackH/2, 3, sbTrackH, 0x1a1a2a, 0.8).setDepth(D+3.5).setScrollFactor(0));
                    const thumbH = Math.max(8, sbTrackH * (clipH / (modsContentH - 22)));
                    const sbThumb = addC(s.add.rectangle(sbX, sbTrackTop + thumbH/2, 3, thumbH, 0x4466aa, 0.7).setDepth(D+4).setScrollFactor(0));
                    
                    const updateScroll = () => {
                        scrollY = Math.max(0, Math.min(maxScroll, scrollY));
                        modContainer.y = clipTop + 8 - scrollY;
                        const pct = maxScroll > 0 ? scrollY / maxScroll : 0;
                        sbThumb.y = sbTrackTop + thumbH/2 + pct * (sbTrackH - thumbH);
                    };
                    
                    // Interactive scroll zone — eats pointer so card doesn't close
                    const scrollZone = addC(s.add.rectangle(mX, mY, mW, panelH, 0x000000, 0.001)
                        .setDepth(D+5).setScrollFactor(0).setInteractive());
                    let dragging = false, dragStartY = 0, dragStartScroll = 0;
                    scrollZone.on('pointerdown', (p) => {
                        dragging = true;
                        dragStartY = p.y;
                        dragStartScroll = scrollY;
                    });
                    const onMove = (p) => {
                        if (!dragging) return;
                        scrollY = dragStartScroll + (dragStartY - p.y);
                        updateScroll();
                    };
                    const onUp = () => { dragging = false; };
                    s.input.on('pointermove', onMove);
                    s.input.on('pointerup', onUp);
                    // Cleanup: remove listeners + destroy mask when card closes
                    addC({ destroy: () => {
                        s.input.off('pointermove', onMove);
                        s.input.off('pointerup', onUp);
                        geoMask.destroy();
                    }});
                } else {
                    // No scroll needed — position texts directly
                    modTexts.forEach((t, i) => {
                        t.setPosition(clipLeft, clipTop + 8 + i * 15);
                        addC(t);
                    });
                }
            }
            
            if (isAugmentable) {
                const aW = hasAnyMods ? augW : 120;
                const aX = hasAnyMods ? (mfr + gap + augW / 2) : cx;
                const aY = yPos + panelH / 2;
                const locked = !(item.enhanceLevel >= 1);
                const aug = item.augment || null;
                addC(s.add.rectangle(aX, aY, aW, panelH, 0x0a0a14, 0.9).setStrokeStyle(0.5, locked ? 0x1a1a2a : 0x2a2a44).setDepth(D+2).setScrollFactor(0));
                const al = aX - aW/2, ar = aX + aW/2, at = aY - panelH/2, ab = aY + panelH/2;
                _brackets(al, at, ar, ab, aW, panelH, 6, locked ? 0x2a2a44 : 0x4466aa, 0.5);
                const slotLabel = item.category === 'gear' ? 'AURA' : 'AUGMENT';
                addC(s.add.text(aX, at + 8, slotLabel, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: locked ? '#333344' : '#556677' }).setOrigin(0.5).setDepth(D+3).setScrollFactor(0));
                const asS = 36, asY = aY + 2;
                if (locked) {
                    addC(s.add.rectangle(aX, asY, asS, asS, 0x0a0a12, 0.95).setStrokeStyle(0.5, 0x1a1a2a).setDepth(D+3).setScrollFactor(0));
                    addC(s.add.rectangle(aX, asY - 2, 8, 6, 0x000000, 0).setStrokeStyle(1.5, 0x333344).setDepth(D+4).setScrollFactor(0));
                    addC(s.add.rectangle(aX, asY + 4, 10, 8, 0x333344).setDepth(D+4).setScrollFactor(0));
                    addC(s.add.text(aX, ab - 8, '+1', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#2a2a3a' }).setOrigin(0.5).setDepth(D+4).setScrollFactor(0));
                } else if (aug) {
                    const ac = CONFIG.tiers[5]?.color || 0xff2244;
                    addC(s.add.rectangle(aX, asY, asS, asS, 0x12101e, 0.95).setStrokeStyle(1, ac, 0.5).setDepth(D+3).setScrollFactor(0));
                    const cc = s.add.container(aX, asY).setDepth(D+4).setScrollFactor(0); addC(cc);
                    ItemManager.drawItemPixelArt(s, cc, 0, 0, aug, 1.8, 0);
                    addC(s.add.text(aX, ab - 8, aug.name || 'Chip', { fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#88aacc' }).setOrigin(0.5).setDepth(D+4).setScrollFactor(0));
                    if (opts.interactive && opts.inventoryUI) {
                        const hit = addC(s.add.rectangle(aX, asY, asS, asS, 0x000000, 0.001).setDepth(D+5).setScrollFactor(0).setInteractive({ useHandCursor: true }));
                        hit.on('pointerdown', () => {
                            const ui = opts.inventoryUI;
                            if (ui.backpack && ItemManager.addItem(ui.backpack, aug)) {
                                item.augment = null; AudioManager.equip(); Haptics.light();
                                ui.closeItemCard(); ui.refresh();
                            }
                        });
                    }
                } else {
                    const slotBg = addC(s.add.rectangle(aX, asY, asS, asS, 0x0e0e1a, 0.95).setStrokeStyle(0.5, 0x2a2a44).setDepth(D+3).setScrollFactor(0));
                    addC(s.add.text(aX, asY, '+', { fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#446688' }).setOrigin(0.5).setDepth(D+4).setScrollFactor(0));
                    addC(s.add.text(aX, ab - 8, 'Empty', { fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#334455' }).setOrigin(0.5).setDepth(D+4).setScrollFactor(0));
                    if (opts.interactive && opts.inventoryUI && opts.inventoryUI.backpack) {
                        const isEq = opts.equipment && (opts.equipment.weapon === item || opts.equipment.melee === item || opts.equipment.gear === item);
                        if (isEq && item.category !== 'gear') {
                            slotBg.setInteractive({ useHandCursor: true });
                            slotBg.on('pointerdown', () => opts.inventoryUI._showAugmentPicker(item));
                        }
                    }
                }
            }
            yPos += panelH + GAP;
        }
        
        // ── DESCRIPTION / HEAL ──
        let hasDescShown = false;
        if ((!item.procedural || item.category === 'augment') && item.description) {
            addC(s.add.text(cx, yPos, item.description, { fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#888899', wordWrap: { width: cardW - 30 } }).setOrigin(0.5, 0).setDepth(D+2).setScrollFactor(0));
            hasDescShown = true;
            yPos += 18;
        }
        if (!hasDescShown && item.healPercent) {
            addC(s.add.text(cx, yPos, `Restores ${item.healPercent}% HP`, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#44aa44' }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
        } else if (!hasDescShown && item.healAmount) {
            addC(s.add.text(cx, yPos, `Restores ${item.healAmount} HP`, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#44aa44' }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
        }
        
        // ── KILL COUNTER ──
        if (isWM) {
            const kcW = cardW - 24, kcH = 20, kcY = yPos + kcH / 2;
            addC(s.add.rectangle(cx, kcY, kcW, kcH, 0x0a0a14, 0.9).setStrokeStyle(0.5, 0x2a2a44).setDepth(D+2).setScrollFactor(0));
            _brackets(cx - kcW/2, kcY - kcH/2, cx + kcW/2, kcY + kcH/2, kcW, kcH, 5, 0x4466aa, 0.5);
            const kc = item.kills || 0;
            addC(s.add.text(cx - kcW/2 + 10, kcY, 'KILLS', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#556677' }).setOrigin(0, 0.5).setDepth(D+3).setScrollFactor(0));
            addC(s.add.text(cx + kcW/2 - 10, kcY, `${kc}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: kc > 0 ? '#cc4444' : '#334455', fontStyle: 'bold' }).setOrigin(1, 0.5).setDepth(D+3).setScrollFactor(0));
        }
    }
    
    // Card height calculator — must match renderItemCard layout exactly
    static calcCardHeight(item) {
        const isWM = (item.category === 'weapon' || item.category === 'melee');
        const isProceduralItem = isWM || item.category === 'gear';
        const GAP = 6;
        let h = 56; // icon header area
        if (isProceduralItem && (item.flavorText || CONFIG.weaponFlavor)) h += 12;
        h += GAP;
        const STAT_DISPLAY = { damage:1, fireRate:1, accuracy:1, crit:1, mag:1, reload:1, pierce:1, targetRange:1, attackSpeed:1, reach:1, stagger:1, shieldAttack:1, armor:1, health:1, speed:1, luck:1, backpack:1, maxHealth:1, damageResist:1, lootLuck:1, healBonus:1, dodge:1 };
        const statKeys = item.stats ? Object.keys(item.stats).filter(k => STAT_DISPLAY[k] && item.stats[k] !== 0) : [];
        if (statKeys.length > 0) h += statKeys.length * 15 + 18 + GAP;
        // Combined mod entries (regular + signature)
        let modEntryCount = (item.mods && item.mods.length > 0) ? item.mods.length : 0;
        if (item.signatureMod) modEntryCount += 3; // name + desc + wrap spacer
        const hasAnyMods = modEntryCount > 0;
        const isAugCalc = isWM || item.category === 'gear';
        if (hasAnyMods || isAugCalc) {
            const MAX_VIS_MODS = 3;
            const modsContentH = hasAnyMods ? (modEntryCount * 15 + 22) : 0;
            const modsVisH = hasAnyMods ? Math.min(modsContentH, MAX_VIS_MODS * 15 + 22) : 0;
            const augH = isAugCalc ? Math.max(modsVisH, 60) : 0;
            h += Math.max(modsVisH, augH) + GAP;
        }
        const hasDesc = (!item.procedural || item.category === 'augment') && item.description;
        if (hasDesc) h += item.category === 'augment' ? 45 : 20;
        else if (item.healAmount || item.healPercent) h += 18;
        if (isWM) h += 20 + GAP;
        return h;
    }

    showItemCard(item) {
        this.closeItemCard();
        const s = this.scene;
        const W = CONFIG.width, H = CONFIG.height, D = 600;
        this.itemCard = [];
        const addC = (obj) => { this.itemCard.push(obj); return obj; };
        const overlay = addC(s.add.rectangle(W/2, H/2, W, H, 0x000000, 0.7).setDepth(D).setScrollFactor(0));
        overlay.setInteractive();
        overlay.on('pointerdown', () => this.closeItemCard());
        const cardW = W - 40, cx = W / 2;
        const cardH = InventoryUI.calcCardHeight(item);
        const cy = H / 2;
        UIAtlas.build(s);
        addC(s.add.nineslice(cx, cy, 'ui_panel', null, cardW, cardH, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME).setDepth(D+1).setScrollFactor(0));
        InventoryUI.renderItemCard(s, item, addC, cx, cy, cardW, cardH, D, {
            interactive: true, inventoryUI: this, equipment: this.equipment, backpack: this.backpack
        });
        
        // ── USE button for key_items with useAction ──
        if (item.category === 'key_item' && item.useAction && item.useAction !== 'lockpick' && item.useAction !== 'toolkit') {
            const btnY = cy + cardH / 2 + 18;
            const btnW = 80, btnH = 24;
            const btnBg = addC(s.add.rectangle(cx, btnY, btnW, btnH, 0x227744, 0.9)
                .setStrokeStyle(1, 0x44aa66).setDepth(D + 5).setScrollFactor(0).setInteractive());
            addC(s.add.text(cx, btnY, 'USE', {
                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#aaffcc', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(D + 6).setScrollFactor(0));
            
            btnBg.on('pointerdown', () => {
                // Resolve correct state object — run state in GameScene/InteriorScene, stash in SafehouseScene
                const state = s.state || (s.saveData ? s.saveData.stash : null);
                if (!state) return;
                const result = ItemManager.useKeyItem(s, state, item, s.player);
                if (result) {
                    // Remove from backpack
                    const bp = this.backpack;
                    for (let i = 0; i < bp.length; i++) {
                        if (bp[i] === item) { bp[i] = null; break; }
                    }
                    // Save if in safehouse
                    if (s.saveData && typeof SaveManager !== 'undefined') SaveManager.save(s.saveData);
                    this.closeItemCard();
                    this.refresh();
                }
            });
        }
    }
    
    _showAugmentPicker(targetItem) {
        // Show a mini picker of augment chips from backpack
        this.closeItemCard();
        const s = this.scene;
        const W = CONFIG.width, H = CONFIG.height;
        const D = 700;
        this.itemCard = [];
        const addC = (obj) => { this.itemCard.push(obj); return obj; };
        
        // Find augments in backpack
        const augments = [];
        this.backpack.forEach((item, i) => {
            if (item && item.category === 'augment') augments.push({ item, index: i });
        });
        
        const panelH = Math.max(100, augments.length * 48 + 60);
        const panelW = W - 40;
        const cy = H / 2, cx = W / 2;
        
        // Overlay
        const overlay = addC(s.add.rectangle(cx, cy, W, H, 0x000000, 0.8).setDepth(D).setScrollFactor(0));
        overlay.setInteractive();
        overlay.on('pointerdown', () => this.closeItemCard());
        
        // Panel bg
        UIAtlas.build(s);
        addC(s.add.nineslice(cx, cy, 'ui_panel', null, panelW, panelH, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME).setDepth(D+1).setScrollFactor(0));
        
        // Title
        addC(s.add.text(cx, cy - panelH/2 + 16, 'SLOT AUGMENT', {
            fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#8866aa', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
        
        addC(s.add.text(cx, cy - panelH/2 + 30, `Into: ${targetItem.name}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#555566'
        }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
        
        if (augments.length === 0) {
            addC(s.add.text(cx, cy, 'No augment chips in backpack', {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#444455'
            }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
        } else {
            let ry = cy - panelH/2 + 50;
            augments.forEach(({ item: aug, index: bpIdx }) => {
                const rowBg = addC(s.add.rectangle(cx, ry + 16, panelW - 16, 40, 0x0c0c18, 0.6)
                    .setDepth(D+2).setScrollFactor(0).setInteractive({ useHandCursor: true }));
                // Chip icon
                const chipC = s.add.container(cx - panelW/2 + 28, ry + 16).setDepth(D+3).setScrollFactor(0);
                addC(chipC);
                ItemManager.drawItemPixelArt(s, chipC, 0, 0, aug, 1.5, 0);
                // Name + desc
                addC(s.add.text(cx - panelW/2 + 50, ry + 10, aug.name, {
                    fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#cc88ee', fontStyle: 'bold'
                }).setOrigin(0, 0.5).setDepth(D+3).setScrollFactor(0));
                addC(s.add.text(cx - panelW/2 + 50, ry + 24, aug.desc || aug.description || '', {
                    fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#666677',
                    wordWrap: { width: panelW - 80 }
                }).setOrigin(0, 0.5).setDepth(D+3).setScrollFactor(0));
                
                rowBg.on('pointerover', () => rowBg.setFillStyle(0x14141e));
                rowBg.on('pointerout', () => rowBg.setFillStyle(0x0c0c18));
                rowBg.on('pointerdown', () => {
                    const oldAug = targetItem.augment;
                    // Free the backpack slot first so it can receive old augment
                    this.backpack[bpIdx] = null;
                    // Return old augment to backpack if one exists
                    if (oldAug) {
                        if (!ItemManager.addItem(this.backpack, oldAug)) {
                            // Backpack truly full — restore and abort
                            this.backpack[bpIdx] = aug;
                            return;
                        }
                    }
                    // Slot the new augment into the weapon
                    targetItem.augment = aug;
                    AudioManager.equip();
                    Haptics.light();
                    this.closeItemCard();
                    this.refresh();
                });
                ry += 48;
            });
        }
    }
    
    closeItemCard() {
        if (this.itemCard) {
            this.itemCard.forEach(obj => { if (obj && obj.destroy) obj.destroy(); });
            this.itemCard = null;
        }
    }
    
    refresh() {
        this.elements.forEach(e => { if (e && e.destroy) e.destroy(); });
        this.elements = [];
        this.slotElements = [];
        this.build();
    }
    
    close() {
        this.closeItemCard();
        this.elements.forEach(e => { if (e && e.destroy) e.destroy(); });
        this.elements = [];
        this.slotElements = [];
        this._open = false;
        if (this.onClose) this.onClose();
    }
    
    isOpen() {
        return this._open;
    }
}

