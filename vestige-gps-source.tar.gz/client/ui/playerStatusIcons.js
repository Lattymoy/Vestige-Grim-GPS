// Vestige GPS — PlayerStatusIcons
// Extracted from monolith L21494-21543

import { CONFIG } from '../../data/config.js';


export const PlayerStatusIcons = {
    _icons: [],
    
    // Call each frame from scene update
    update(scene) {
        if (!scene.player || !scene.player.active) return;
        
        // Gather active statuses
        const statuses = [];
        if (scene.state._firepowerActive)    statuses.push({ color: 0xff6622, label: 'FP' });
        if (scene.state._sharpshooterActive) statuses.push({ color: 0x44ccff, label: 'SS' });
        if (scene._hardenedActive)           statuses.push({ color: 0xccaa44, label: 'HD' });
        if (scene._shelteredActive)          statuses.push({ color: 0x44aaff, label: 'SH' });
        if (scene._phantomInvis)             statuses.push({ color: 0xaa44ff, label: 'PH' });
        if ((scene.state._parasiticRounds || 0) > 0) statuses.push({ color: 0x44cc44, label: `${scene.state._parasiticRounds}` });
        if (scene._gymBuffLocal && scene._gymBuffLocal.remainingMs > 0) {
            const gc = { core: 0xff4444, arms: 0xffaa44, legs: 0x44aaff }[scene._gymBuffLocal.category] || 0x888888;
            statuses.push({ color: gc, label: 'GY' });
        }
        
        // Destroy old icons
        this._icons.forEach(i => { if (i.active) i.destroy(); });
        this._icons = [];
        
        if (statuses.length === 0) return;
        
        // Position below player
        const baseY = scene.player.y + (scene.player.displayHeight ? scene.player.displayHeight / 2 + 6 : 16);
        const totalW = statuses.length * 12;
        const startX = scene.player.x - totalW / 2 + 6;
        
        statuses.forEach((s, idx) => {
            // Background pip
            const pip = scene.add.rectangle(startX + idx * 12, baseY, 10, 10, s.color, 0.7)
                .setDepth(32).setStrokeStyle(0.5, 0x000000, 0.4);
            this._icons.push(pip);
            
            // Label text (tiny)
            const lt = scene.add.text(startX + idx * 12, baseY, s.label, {
                fontFamily: CONFIG.font, fontSize: '5px', fill: '#ffffff'
            }).setOrigin(0.5).setDepth(33);
            this._icons.push(lt);
        });
    },
    
    reset() {
        this._icons.forEach(i => { if (i.active) i.destroy(); });
        this._icons = [];
    }
};

