// Vestige GPS — GameHUD
// Extracted from monolith L33123-33780

import { ItemManager } from '../../core/itemManager.js';
import { SaveManager } from '../../core/saveManager.js';
import { SurvivorGenerator } from '../../core/survivorGenerator.js';
import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { GrimFont } from '../../data/grimFont.js';
import { InventoryUI } from '../ui/inventoryUI.js';
import { UIAtlas } from '../uiAtlas.js';


export const GameHUD = {
    DEPTH: 100,

    create(scene, config = {}) {
        UIAtlas.build(scene);
        GrimFont.build(scene);

        const W = CONFIG.width;
        const D = this.DEPTH;
        const F = UIAtlas.FRAME;
        const refs = { _scene: scene, _texts: {}, _icons: {}, _expanded: false, _dropdown: null };

        // ── Resolve player info from deployed survivor ──
        let saveData = null;
        try { saveData = SaveManager.load(); } catch(e) {}
        const surv = config.survivor || null;
        const playerName = surv ? surv.name : (saveData?.profile?.name || 'WANDERER');
        const rank = surv ? SurvivorGenerator.getRank(surv) : null;

        // ── Dynamic panel width: name + insignia ──
        const nameW = playerName.length * 7;
        const insigniaW = rank ? 20 : 0;
        const survTitleForSize = surv ? (surv.equippedTitle || null) : null;
        const titleW = survTitleForSize ? survTitleForSize.length * 5.5 : 0;
        const nameSectionW = Math.max(60, Math.max(nameW, titleW) + insigniaW + 16);
        const panelW = Math.max(90, nameSectionW);
        const hasSurvTitle = !!survTitleForSize;
        const panelH = hasSurvTitle ? 34 : 28;
        const margin = 4;
        const panelX = W - margin - panelW / 2;
        const panelY = margin + panelH / 2;
        refs._config = config;

        // ── Panel background ──
        const bg = scene.add.nineslice(
            panelX, panelY, 'ui_panel', null,
            panelW, panelH, F, F, F, F
        ).setScrollFactor(0).setDepth(D).setAlpha(0.92);
        bg.setInteractive({ useHandCursor: true });
        refs._bg = bg;

        // ── Row 1: Name (left) + Insignia (right) ──
        const nameX = panelX - panelW / 2 + 8;
        const nameY = hasSurvTitle ? panelY - 7 : panelY;
        const nameFontSize = hasSurvTitle ? uiPx(10) : uiPx(11);
        
        const rDef = surv ? SurvivorGenerator.RARITIES[surv.rarity] : null;
        const nameColor = rDef ? ('#' + rDef.color.toString(16).padStart(6, '0')) : '#ccddee';
        const nameText = scene.add.text(nameX, nameY, playerName, {
            fontFamily: CONFIG.font, fontSize: nameFontSize, fill: nameColor, fontStyle: 'bold'
        }).setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 1);
        // Dynamic name scaling: shrink if name overflows panel
        const maxNameW = panelW - (rank ? 28 : 12);
        if (nameText.width > maxNameW) {
            nameText.setScale(maxNameW / nameText.width, 1);
        }
        refs._nameText = nameText;
        
        let insigniaImg = null;
        if (rank) {
            const rankIconKey = SurvivorGenerator.generateRankIcon(scene, rank.level);
            const insigniaX = panelX + panelW / 2 - 10;
            insigniaImg = scene.add.image(insigniaX, nameY, rankIconKey)
                .setDisplaySize(16, 16).setScrollFactor(0).setDepth(D + 1);
        }
        refs._insignia = insigniaImg;
        refs._panelX = panelX;
        refs._panelY = panelY;
        refs._panelW = panelW;

        // ── Row 2: Player title (below name, clear and readable) ──
        const survTitle = surv ? (surv.equippedTitle || null) : null;
        const playerTitle = survTitle || (saveData?.profile?.title || '');
        if (playerTitle && hasSurvTitle) {
            const titleDef = CONFIG.survivorTitles ? CONFIG.survivorTitles[playerTitle] : null;
            const titleColor = titleDef ? titleDef.color : '#bbaa66';
            const row2Y = panelY + 6;
            const hudTitle = scene.add.text(nameX, row2Y, playerTitle.toUpperCase(), {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: titleColor, 
                fontStyle: 'bold', letterSpacing: 1, stroke: '#000000', strokeThickness: 1
            }).setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 1);
            const maxTitleW = panelW - (insigniaImg ? 28 : 12);
            if (hudTitle.width > maxTitleW) {
                hudTitle.setScale(maxTitleW / hudTitle.width, 1);
            }
            refs._hudTitle = hudTitle;
        } else if (playerTitle) {
            const titleDef = CONFIG.survivorTitles ? CONFIG.survivorTitles[playerTitle] : null;
            const titleColor = titleDef ? titleDef.color : '#bbaa66';
            const row2Y = panelY + 7;
            const hudTitle = scene.add.text(nameX, row2Y, playerTitle.toUpperCase(), {
                fontFamily: CONFIG.font, fontSize: uiPx(6.5), fill: titleColor,
                stroke: '#000000', strokeThickness: 1
            }).setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 1);
            const maxTitleW = panelW - 16;
            if (hudTitle.width > maxTitleW) {
                hudTitle.setScale(maxTitleW / hudTitle.width, 1);
            }
            refs._hudTitle = hudTitle;
        }

        // ── HP bar (combat mode — below panel) ──
        let barStackY = panelY + panelH / 2 + 4;
        if (config.combat) {
            const hpW = panelW - 8, hpH = 4;
            const hpX = panelX - panelW / 2 + 4;
            const hpY = barStackY;
            scene.add.rectangle(hpX + hpW / 2, hpY, hpW + 2, hpH + 2, 0x111111)
                .setScrollFactor(0).setDepth(D);
            refs._hpBar = scene.add.rectangle(hpX, hpY, hpW, hpH, 0x44aa44)
                .setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 1);
            refs._hpBarW = hpW;
            barStackY += hpH + 3;
        }

        // ── XP bar (below HP bar or below panel if no combat) ──
        if (surv) {
            const xpW = panelW - 8, xpH = 3;
            const xpX = panelX - panelW / 2 + 4;
            const xpY = barStackY;
            scene.add.rectangle(xpX + xpW / 2, xpY, xpW + 2, xpH + 2, 0x0a0a10)
                .setScrollFactor(0).setDepth(D);
            // Calculate XP progress within current rank
            let xpPct = 0;
            if (rank) {
                const nextRank = SurvivorGenerator.RANKS.find(r => r.level === rank.level + 1);
                if (nextRank) {
                    const prevXP = rank.xpNeeded;
                    const nextXP = nextRank.xpNeeded;
                    xpPct = nextXP > prevXP ? Math.min(1, (surv.xp - prevXP) / (nextXP - prevXP)) : 1;
                } else {
                    xpPct = 1; // max rank
                }
            }
            const xpFillW = Math.max(1, (xpW - 2) * xpPct);
            refs._xpBar = scene.add.rectangle(xpX, xpY, xpFillW, xpH, 0xcc8844)
                .setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 1);
            refs._xpBarMaxW = xpW - 2;
            barStackY += xpH + 3;
        }

        // ── Card tab (left of panel, opens survivor card) ──
        if (surv) {
            const tabW = 16, tabH = panelH;
            const tabX = panelX - panelW / 2 - tabW / 2 + 1; // overlaps panel edge by 1px
            const tabY = panelY;
            const rarCol = rDef ? rDef.color : 0x556677;
            
            // Tab background — same nineslice as panel for seamless look
            const tabBg = scene.add.nineslice(
                tabX, tabY, 'ui_panel', null,
                tabW, tabH, F, F, F, F
            ).setScrollFactor(0).setDepth(D - 0.1).setAlpha(0.92);
            
            // Rarity accent line on left edge
            const tabAccent = scene.add.rectangle(tabX - tabW/2 + 1, tabY, 2, tabH - 4, rarCol, 0.7)
                .setScrollFactor(0).setDepth(D + 0.5);
            
            // Tiny card icon (4×6 white rectangle with notch)
            const iconG = scene.add.graphics().setScrollFactor(0).setDepth(D + 1);
            const ix = tabX - 2, iy = tabY - 4;
            iconG.fillStyle(0x8899aa, 0.8);
            iconG.fillRect(ix, iy, 5, 7);
            iconG.fillStyle(0x0a0a14, 1);
            iconG.fillRect(ix + 3, iy, 2, 2); // corner fold
            iconG.fillStyle(0x8899aa, 0.5);
            iconG.fillRect(ix + 1, iy + 3, 3, 1); // line detail
            
            tabBg.setInteractive({ useHandCursor: true });
            tabBg.on('pointerdown', () => {
                if (refs._onCardOpen) refs._onCardOpen();
            });
            tabBg.on('pointerover', () => tabAccent.setFillStyle(rarCol, 1.0));
            tabBg.on('pointerout', () => tabAccent.setFillStyle(rarCol, 0.7));
            refs._idTab = tabBg;
            refs._idTabAccent = tabAccent;
            refs._idTabIcon = iconG;
        }

        // ── Tap to expand/collapse (offset accounts for bars) ──
        const dropdownTopY = barStackY;
        refs._barStackY = barStackY;
        refs._panelW = panelW;
        bg.on('pointerdown', () => {
            if (refs._expanded) {
                this._collapseDropdown(refs);
            } else {
                this._expandDropdown(scene, refs, panelX, dropdownTopY, panelW);
            }
        });

        // ── Scene title (GrimFont centered, separate from HUD panel) ──
        if (config.title) {
            const titleY = 46;
            const titleContainer = GrimFont.drawText(scene, W / 2, titleY, config.title.toUpperCase(), {
                scale: 0.55, rust: true, depth: D + 2, center: true
            });
            titleContainer.setScrollFactor(0);

            if (config.persist) {
                titleContainer.setAlpha(0.5);
            } else {
                titleContainer.setAlpha(0);
                scene.tweens.add({
                    targets: titleContainer, alpha: 0.85, duration: 600, ease: 'Sine.easeIn',
                    onComplete: () => {
                        scene.time.delayedCall(2500, () => {
                            scene.tweens.add({
                                targets: titleContainer, alpha: 0, duration: 1200, ease: 'Sine.easeOut'
                            });
                        });
                    }
                });
            }
            refs._title = titleContainer;

            if (config.subtitle) {
                const sub = scene.add.text(W / 2, titleY + 14, config.subtitle, {
                    fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#887766', fontStyle: 'italic'
                }).setOrigin(0.5).setScrollFactor(0).setDepth(D + 1).setAlpha(0);
                scene.tweens.add({
                    targets: sub, alpha: 0.6, duration: 800, delay: 400,
                    onComplete: () => {
                        scene.time.delayedCall(2000, () => {
                            scene.tweens.add({ targets: sub, alpha: 0, duration: 1200 });
                        });
                    }
                });
            }
        }

        // ── Public API ──
        refs.updateResource = (key, val) => {
            if (refs._config && refs._config.resources) refs._config.resources[key] = val;
            if (refs._texts[key]) refs._texts[key].setText(`${val}`);
        };
        refs.updateHP = (cur, max) => {
            if (refs._hpBar) {
                const pct = Math.max(0, cur / max);
                refs._hpBar.displayWidth = refs._hpBarW * pct;
                refs._hpBar.setFillStyle(pct > 0.5 ? 0x44aa44 : pct > 0.25 ? 0xaaaa44 : 0xaa4444);
            }
        };
        refs.updateXP = (pct) => {
            if (refs._xpBar) {
                refs._xpBar.displayWidth = Math.max(1, refs._xpBarMaxW * Math.min(1, pct));
            }
        };
        refs.flashXP = () => {
            if (refs._xpBar) {
                scene.tweens.add({
                    targets: refs._xpBar, alpha: 0.4, duration: 100, yoyo: true, repeat: 2,
                    onComplete: () => { refs._xpBar.setAlpha(1); }
                });
            }
        };

        refs.updateSurvivor = (newSurv) => {
            if (!newSurv) return;
            const sc = refs._scene;
            // Update name text + color
            const rd = SurvivorGenerator.RARITIES[newSurv.rarity];
            const nc = rd ? ('#' + rd.color.toString(16).padStart(6, '0')) : '#ccddee';
            if (refs._nameText && refs._nameText.active) {
                refs._nameText.setText(newSurv.name);
                refs._nameText.setStyle({ fill: nc });
            }
            // Update insignia
            const newRank = SurvivorGenerator.getRank(newSurv);
            if (refs._insignia && refs._insignia.active) {
                const rik = SurvivorGenerator.generateRankIcon(sc, newRank.level);
                refs._insignia.setTexture(rik);
            } else if (newRank) {
                const rik = SurvivorGenerator.generateRankIcon(sc, newRank.level);
                const iX = refs._panelX + refs._panelW / 2 - 10;
                refs._insignia = sc.add.image(iX, refs._panelY, rik)
                    .setDisplaySize(16, 16).setScrollFactor(0).setDepth(D + 1);
            }
            // Update XP bar fill
            if (refs._xpBar && refs._xpBar.active && newRank) {
                const nextR = SurvivorGenerator.RANKS.find(r => r.level === newRank.level + 1);
                let pct = 1;
                if (nextR) {
                    pct = nextR.xpNeeded > newRank.xpNeeded
                        ? Math.min(1, (newSurv.xp - newRank.xpNeeded) / (nextR.xpNeeded - newRank.xpNeeded)) : 1;
                }
                refs._xpBar.displayWidth = Math.max(1, refs._xpBarMaxW * pct);
            }
            // Update title display
            if (refs._hudTitle && refs._hudTitle.active) {
                const newTitle = newSurv.equippedTitle || '';
                if (newTitle) {
                    const tDef = CONFIG.survivorTitles ? CONFIG.survivorTitles[newTitle] : null;
                    refs._hudTitle.setText(newTitle.toUpperCase());
                    refs._hudTitle.setStyle({ fill: tDef ? tDef.color : '#bbaa66', fontStyle: 'bold', stroke: '#000000', strokeThickness: 1 });
                    const maxTW = refs._panelW - (refs._insignia ? 28 : 12);
                    refs._hudTitle.setScale(refs._hudTitle.width > maxTW ? maxTW / refs._hudTitle.width : 1, 1);
                    refs._hudTitle.setVisible(true);
                } else {
                    refs._hudTitle.setVisible(false);
                }
            }
        };

        return refs;
    },

    // ── Square action button (atlas-backed) ──
    createActionButton(scene, x, y, opts = {}) {
        const { size = 34, iconKey = null, label = '', depth = 99, visible = true } = opts;
        const F = UIAtlas.FRAME;
        const container = scene.add.container(x, y).setScrollFactor(0).setDepth(depth).setVisible(visible);

        // Atlas nine-slice background
        const bg = scene.add.nineslice(0, 0, 'ui_panel_sm', null, size, size, F, F, F, F).setAlpha(0.9);
        container.add(bg);

        // Icon (atlas image, centered)
        let icon = null;
        if (iconKey && scene.textures.exists(iconKey)) {
            icon = scene.add.image(0, label ? -3 : 0, iconKey).setScale(1.2);
            container.add(icon);
        }

        // Label below icon (or centered if no icon)
        let txt = null;
        if (label) {
            txt = scene.add.text(0, icon ? 9 : 0, label, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#ccddee'
            }).setOrigin(0.5);
            container.add(txt);
        }

        // Interactive hit area on the background
        bg.setInteractive({ useHandCursor: true });

        // Expose refs
        container._bg = bg;
        container._icon = icon;
        container._label = txt;
        container._size = size;

        // Helper to swap icon
        container.setIcon = (newKey) => {
            if (icon && scene.textures.exists(newKey)) {
                icon.setTexture(newKey);
            }
        };
        container.setLabel = (newLabel) => {
            if (txt) txt.setText(newLabel);
        };

        return container;
    },

    _expandDropdown(scene, refs, px, topY, pw) {
        if (refs._dropdown) return;
        refs._expanded = true;
        if (refs._arrow) refs._arrow.setText('^');

        let saveData = null;
        try { saveData = SaveManager.load(); } catch(e) {}
        if (!saveData) return;

        const D = this.DEPTH + 10;
        const F = UIAtlas.FRAME;
        const ddW = Math.max(pw, 190);
        // Build content first, measure height, then size panel
        const ddX = CONFIG.width - 4 - ddW / 2;
        
        // Pre-calculate height
        let preH = 12; // top padding
        const cfg = refs._config || {};
        const resKeys = cfg.resources ? Object.keys(cfg.resources).filter(k => cfg.resources[k] !== undefined && cfg.resources[k] !== null) : [];
        if (resKeys.length > 0) preH += 18;
        
        const gymBuff = saveData.gymBuff;
        const wrBuff2 = saveData.wellRested;
        let buffLines = 1; // default '--'
        if (gymBuff && gymBuff.remainingMs > 0) buffLines = Object.keys(gymBuff.buffs).length + 1;
        if (wrBuff2 && wrBuff2.active && wrBuff2.runsRemaining > 0) buffLines += 2;
        if (buffLines > 1) buffLines = Math.max(buffLines, 2); // at least show something
        preH += 10 + buffLines * 9 + 10; // headers + content + divider
        preH += 12 + 32 + 16 + 8; // LOADOUT header + slots + labels + divider
        
        const equipment = saveData.equipment || {};
        const eqTotal = ItemManager.getEquipmentStats(equipment);
        // Compute effective damage with gym bonus baked in
        let effDmg = eqTotal.damage || CONFIG.player.gunDamage;
        let effMelee = eqTotal.meleeDamage || CONFIG.player.meleeDamage;
        if (eqTotal.gymDamageBonus) {
            effDmg = Math.round(effDmg * (1 + eqTotal.gymDamageBonus / 100));
            effMelee = Math.round(effMelee * (1 + eqTotal.gymDamageBonus / 100));
        }
        const baseSpeed = CONFIG.player.speed || 150;
        const speedPct = Math.round(eqTotal.moveSpeed || 100);
        const critPct = Math.round(((eqTotal.crit || 0) / 200) * 100 * 10) / 10;
        
        const defC = '#66bbaa', offC = '#cc9966', utlC = '#9999cc';
        const statRows = [
            { l: 'HP',      v: `${CONFIG.player.health + (eqTotal.maxHealth || 0)}`, c: defC },
            { l: 'Armor',   v: `${eqTotal.armor || 0}%`,      c: defC },
            { l: 'Resist',  v: `${eqTotal.damageResist || 0}%`, c: defC },
            { l: 'Dodge',   v: `${eqTotal.dodgeChance || 0}%`, c: defC },
            { l: 'Speed',   v: `${speedPct}%`,                 c: utlC },
            { l: 'Dmg',     v: `${effDmg}`,                    c: offC },
            { l: 'Melee',   v: `${effMelee}`,                  c: offC },
            { l: 'Crit',    v: `${critPct}%`,                  c: offC },
            { l: 'Acc',     v: `${Math.round(50 + (eqTotal.accuracy || 0) / 2)}%`, c: offC },
            { l: 'Luck',    v: `${eqTotal.lootLuck || 0}`,     c: utlC },
            { l: 'Carry',   v: `${(eqTotal.carryCapacity || 0) + CONFIG.inventory.backpackSlots}`, c: utlC },
        ];
        preH += 11 + Math.ceil(statRows.length / 2) * 10 + 8; // TOTAL STATS
        
        const ddH = preH;
        const ddY = topY + 4 + ddH / 2;
        
        const container = scene.add.container(ddX, ddY).setScrollFactor(0).setDepth(D);
        refs._dropdown = container;

        const panel = scene.add.nineslice(0, 0, 'ui_panel', null, ddW, ddH, F, F, F, F).setAlpha(0.95);
        container.add(panel);
        panel.setInteractive();

        let cy = -ddH / 2 + 12;
        const lx = -ddW / 2 + 10;
        const halfW = (ddW - 24) / 2;
        const buffColCx = lx + halfW / 2;
        const debuffColCx = lx + halfW + 8 + halfW / 2;

        // ── CURRENCIES ──
        if (resKeys.length > 0) {
            const iconMap = {
                bits: 'ui_icon_bits', fuel: 'ui_icon_fuel',
                mag: 'ui_icon_ammo', materials: 'ui_icon_materials',
                health: 'ui_icon_health'
            };
            const colorMap = {
                bits: '#ffcc44', fuel: '#dd8844',
                mag: '#aaaacc', materials: '#88aacc',
                health: '#44aa44'
            };
            const totalAvail = ddW - 20;
            const slotW = Math.floor(totalAvail / resKeys.length);
            resKeys.forEach((key, ki) => {
                const rx = lx + ki * slotW;
                const val = cfg.resources[key];
                const texKey = iconMap[key];
                if (texKey && scene.textures.exists(texKey)) {
                    container.add(scene.add.image(rx + 6, cy, texKey).setScale(0.8));
                }
                const txt = scene.add.text(rx + 14, cy, `${val}`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: colorMap[key] || '#aaa'
                }).setOrigin(0, 0.5);
                container.add(txt);
                refs._texts[key] = txt;
            });
            cy += 14;
            container.add(scene.add.rectangle(0, cy - 4, ddW - 20, 1, 0x334455, 0.4));
            cy += 4;
        }

        // ── BUFFS / DEBUFFS — always visible, centered in columns ──
        const hdrColor = '#8899aa';
        const lblColor = '#778899';
        const dimColor = '#334455';
        container.add(scene.add.text(buffColCx, cy, 'BUFFS', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#55aa77', fontStyle: 'bold'
        }).setOrigin(0.5, 0.5));
        container.add(scene.add.text(debuffColCx, cy, 'DEBUFFS', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#aa5555', fontStyle: 'bold'
        }).setOrigin(0.5, 0.5));
        cy += 10;
        const divTopY = cy;
        
        // Buffs column (left)
        let buffY = cy;
        if (gymBuff && gymBuff.remainingMs > 0) {
            const catDef = CONFIG.gym.categories[gymBuff.category];
            const catColor = catDef ? catDef.color : '#aaaaaa';
            const mins = Math.ceil(gymBuff.remainingMs / 60000);
            Object.entries(gymBuff.buffs).forEach(([stat, val]) => {
                const buffDef = catDef ? catDef.buffs[stat] : null;
                const label = buffDef ? buffDef.name : stat;
                const unit = buffDef ? buffDef.unit : '';
                container.add(scene.add.text(buffColCx, buffY, `+${val}${unit} ${label}`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(6), fill: catColor
                }).setOrigin(0.5, 0.5));
                buffY += 9;
            });
            container.add(scene.add.text(buffColCx, buffY, `${mins}m`, {
                fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#556666'
            }).setOrigin(0.5, 0.5));
            buffY += 9;
        }
        // Well Rested buff
        const wrBuff = saveData.wellRested;
        if (wrBuff && wrBuff.active && wrBuff.runsRemaining > 0) {
            container.add(scene.add.text(buffColCx, buffY, '+15% Currency', {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#6688cc'
            }).setOrigin(0.5, 0.5));
            buffY += 9;
            container.add(scene.add.text(buffColCx, buffY, `${wrBuff.runsRemaining} nodes`, {
                fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#556666'
            }).setOrigin(0.5, 0.5));
            buffY += 9;
        }
        if (buffY === cy) {
            container.add(scene.add.text(buffColCx, buffY, '--', {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: dimColor
            }).setOrigin(0.5, 0.5));
            buffY += 9;
        }
        
        // Debuffs column (right)
        let debuffY = cy;
        container.add(scene.add.text(debuffColCx, debuffY, '--', {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: dimColor
        }).setOrigin(0.5, 0.5));
        debuffY += 9;
        
        cy = Math.max(buffY, debuffY) + 2;
        const divX = lx + halfW + 4;
        container.add(scene.add.rectangle(divX, (divTopY + cy) / 2, 1, cy - divTopY, 0x334455, 0.4));
        container.add(scene.add.rectangle(0, cy, ddW - 20, 1, 0x334455, 0.4));
        cy += 8;

        // ── LOADOUT ──
        container.add(scene.add.text(0, cy, 'LOADOUT', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: hdrColor, fontStyle: 'bold'
        }).setOrigin(0.5, 0.5));
        cy += 12;

        const slotDefs = [
            { key: 'weapon', label: 'Gun', icon: 'ui_icon_weapon' },
            { key: 'melee', label: 'Melee', icon: 'ui_icon_weapon' },
            { key: 'gear', label: 'Gear', icon: 'ui_icon_shield' },
            { key: 'consumable', label: 'Item', icon: 'ui_icon_heal' }
        ];

        const slotSize = 32, slotGap = 4;
        const totalSlotW = slotDefs.length * (slotSize + slotGap) - slotGap;
        const slotStartX = -totalSlotW / 2 + slotSize / 2;

        slotDefs.forEach((sd, i) => {
            const sx = slotStartX + i * (slotSize + slotGap);
            const sy = cy + slotSize / 2;
            const item = equipment[sd.key];

            if (item) {
                const itemColor = ItemManager.getItemColor(item);
                const slotBg = scene.add.rectangle(sx, sy, slotSize, slotSize, itemColor, 0.1)
                    .setStrokeStyle(1, itemColor, 0.6);
                container.add(slotBg);
                
                const isAngledLo = (item.category === 'weapon' || item.category === 'melee');
                if (isAngledLo) {
                    const spriteC = scene.add.container(sx, sy);
                    container.add(spriteC);
                    ItemManager.drawItemPixelArt(scene, spriteC, 0, 0, item, 1.4, 0);
                    spriteC.setRotation(item.category === 'melee' ? Math.PI / 4 : -Math.PI / 4);
                } else {
                    ItemManager.drawItemPixelArt(scene, container, sx, sy - 2, item, 1.4, 0);
                }
                
                if (item.flair && (item.category === 'weapon' || item.category === 'melee')) {
                    InventoryUI.addFlairShimmer(scene, (o) => { container.add(o); return o; }, sx, sy, slotSize - 4, item.flair, 0, false);
                }
                
                slotBg.setInteractive({ useHandCursor: true });
                let holdTimer = null;
                slotBg.on('pointerdown', () => {
                    holdTimer = scene.time.delayedCall(400, () => {
                        holdTimer = null;
                        GameHUD._showQuickCard(scene, item);
                    });
                });
                slotBg.on('pointerup', () => { if (holdTimer) { holdTimer.remove(); holdTimer = null; } });
                slotBg.on('pointerout', () => { if (holdTimer) { holdTimer.remove(); holdTimer = null; } });
            } else {
                const slotBg = scene.add.rectangle(sx, sy, slotSize, slotSize, 0x111118).setStrokeStyle(0.5, 0x333344);
                container.add(slotBg);
                if (scene.textures.exists(sd.icon)) {
                    container.add(scene.add.image(sx, sy, sd.icon).setAlpha(0.2));
                }
            }

            container.add(scene.add.text(sx, sy + slotSize / 2 + 6, sd.label, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: lblColor
            }).setOrigin(0.5));
        });
        cy += slotSize + 16;
        container.add(scene.add.rectangle(0, cy, ddW - 20, 1, 0x334455, 0.4));
        cy += 8;
        
        // ── TOTAL STATS — all buffs baked in ──
        container.add(scene.add.text(0, cy, 'TOTAL STATS', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: hdrColor, fontStyle: 'bold'
        }).setOrigin(0.5, 0.5));
        cy += 11;
        
        const statCols = 2, statColW = (ddW - 20) / statCols;
        statRows.forEach((sr, si) => {
            const col = si % statCols, row = Math.floor(si / statCols);
            const stx = lx + col * statColW;
            const sty = cy + row * 10;
            container.add(scene.add.text(stx, sty, sr.l, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: lblColor
            }).setOrigin(0, 0.5));
            container.add(scene.add.text(stx + statColW - 4, sty, sr.v, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: sr.c
            }).setOrigin(1, 0.5));
        });
        cy += Math.ceil(statRows.length / statCols) * 10 + 4;

        container.setAlpha(0);
        scene.tweens.add({ targets: container, alpha: 1, duration: 200, ease: 'Sine.easeOut' });
    },

    _showQuickCard(scene, item) {
        GameHUD._closeQuickCard(scene);
        const W = CONFIG.width, H = CONFIG.height, D = 700;
        scene._quickCard = [];
        const add = (obj) => { scene._quickCard.push(obj); return obj; };
        const ov = add(scene.add.rectangle(W/2, H/2, W, H, 0x000000, 0.7).setDepth(D).setScrollFactor(0));
        ov.setInteractive();
        ov.on('pointerdown', () => GameHUD._closeQuickCard(scene));
        const cardW = W - 40, cx = W / 2;
        const cardH = InventoryUI.calcCardHeight(item);
        const cy = H / 2;
        UIAtlas.build(scene);
        const F = UIAtlas.FRAME;
        add(scene.add.nineslice(cx, cy, 'ui_panel', null, cardW, cardH, F, F, F, F).setDepth(D+1).setScrollFactor(0));
        InventoryUI.renderItemCard(scene, item, add, cx, cy, cardW, cardH, D, { interactive: false });
    },
    
    _closeQuickCard(scene) {
        if (scene._quickCard) {
            scene._quickCard.forEach(el => { if (el && el.destroy) el.destroy(); });
            scene._quickCard = null;
        }
    },

    _collapseDropdown(refs) {
        refs._expanded = false;
        if (refs._arrow) refs._arrow.setText('v');
        if (refs._dropdown) {
            const dd = refs._dropdown;
            // Clean up geometry masks (not in container)
            if (dd._sweepMasks) dd._sweepMasks.forEach(m => m.destroy());
            refs._scene.tweens.add({
                targets: dd, alpha: 0, duration: 150,
                onComplete: () => dd.destroy()
            });
            refs._dropdown = null;
        }
    }
};

