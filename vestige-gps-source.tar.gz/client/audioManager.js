// Vestige GPS — AudioManager
// Extracted from monolith lines 27372-27951
// TODO: convert internal global refs to imports

export const AudioManager = {
    _ctx: null,
    _masterGain: null,
    _volume: 0.3,      // 0-1
    _muted: false,
    _enabled: true,
    
    // Lazy-init AudioContext (must be triggered by user gesture)
    _init() {
        if (this._ctx) return true;
        try {
            this._ctx = new (window.AudioContext || window.webkitAudioContext)();
            this._masterGain = this._ctx.createGain();
            this._masterGain.gain.value = this._volume;
            this._masterGain.connect(this._ctx.destination);
            return true;
        } catch (e) {
            this._enabled = false;
            return false;
        }
    },
    
    // Resume context after user gesture (required by browsers)
    resume() {
        if (this._ctx && this._ctx.state === 'suspended') this._ctx.resume();
    },
    

    
    mute(val) {
        this._muted = val !== undefined ? val : !this._muted;
        if (this._masterGain) this._masterGain.gain.value = this._muted ? 0 : this._volume;
    },
    
    // Low-level: play a tone
    _tone(freq, duration, type, vol, delay) {
        if (!this._enabled || this._muted) return;
        if (!this._init()) return;
        const ctx = this._ctx;
        const t = ctx.currentTime + (delay || 0);
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = type || 'square';
        osc.frequency.setValueAtTime(freq, t);
        gain.gain.setValueAtTime((vol || 0.3) * this._volume, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
        osc.connect(gain);
        gain.connect(this._masterGain);
        osc.start(t);
        osc.stop(t + duration);
    },
    
    // Low-level: play noise burst
    _noise(duration, vol, delay) {
        if (!this._enabled || this._muted) return;
        if (!this._init()) return;
        const ctx = this._ctx;
        const t = ctx.currentTime + (delay || 0);
        const bufferSize = ctx.sampleRate * duration;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
        const src = ctx.createBufferSource();
        src.buffer = buffer;
        const gain = ctx.createGain();
        gain.gain.setValueAtTime((vol || 0.15) * this._volume, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
        src.connect(gain);
        gain.connect(this._masterGain);
        src.start(t);
    },
    
    // ── Named SFX library ──
    
    // Combat
    shoot()       { this._noise(0.06, 0.25); this._tone(220, 0.05, 'square', 0.15); },
    melee()       { this._noise(0.08, 0.2); this._tone(120, 0.1, 'sawtooth', 0.2); },
    hit()         { this._tone(180, 0.08, 'square', 0.2); this._noise(0.04, 0.15, 0.02); },
    enemyDeath()  { this._tone(400, 0.06, 'square', 0.15); this._tone(200, 0.1, 'square', 0.12, 0.05); },
    playerHit()   { this._tone(100, 0.15, 'sawtooth', 0.25); this._noise(0.08, 0.2, 0.03); },
    playerDeath() { this._tone(200, 0.3, 'sawtooth', 0.3); this._tone(100, 0.5, 'sawtooth', 0.2, 0.15); },
    
    // Weapons
    reload()      { this._tone(600, 0.04, 'square', 0.1); this._tone(800, 0.04, 'square', 0.1, 0.06); },
    emptyClip()   { this._tone(300, 0.05, 'triangle', 0.15); },
    
    // Items / Loot
    pickup()      { this._tone(523, 0.06, 'sine', 0.2); this._tone(659, 0.06, 'sine', 0.2, 0.06); },
    pickupRare()  { this._tone(523, 0.06, 'sine', 0.2); this._tone(659, 0.06, 'sine', 0.2, 0.06); this._tone(784, 0.1, 'sine', 0.25, 0.12); },
    equip()       { this._tone(440, 0.05, 'square', 0.12); this._tone(550, 0.05, 'square', 0.12, 0.04); },
    scrap()       { this._noise(0.1, 0.15); this._tone(150, 0.08, 'sawtooth', 0.1); },
    
    // UI
    uiClick()     { this._tone(800, 0.03, 'square', 0.1); },
    uiOpen()      { this._tone(400, 0.04, 'sine', 0.15); this._tone(600, 0.04, 'sine', 0.15, 0.03); },
    uiClose()     { this._tone(600, 0.04, 'sine', 0.12); this._tone(400, 0.04, 'sine', 0.12, 0.03); },

    
    // CRT Terminal
    crtBeep()     { this._tone(800, 0.04, 'square', 0.08); },
    crtBoot()     { this._tone(400, 0.15, 'sawtooth', 0.06); this._tone(250, 0.2, 'sawtooth', 0.05, 0.1); this._noise(0.08, 0.04, 0.05); },
    crtType()     { this._tone(1200, 0.015, 'square', 0.04); },
    
    // Exploration
    doorOpen()    { this._tone(300, 0.1, 'triangle', 0.12); this._noise(0.06, 0.08, 0.05); },
    lootCrate()   { this._noise(0.05, 0.12); this._tone(500, 0.04, 'sine', 0.15, 0.04); },

    
    // Ambient stings
    bossSpawn()   { this._tone(80, 0.4, 'sawtooth', 0.3); this._tone(60, 0.6, 'sawtooth', 0.2, 0.2); this._noise(0.3, 0.1, 0.1); },
    phaseShift()  { this._tone(300, 0.15, 'sine', 0.2); this._tone(600, 0.1, 'sine', 0.15, 0.08); },

    stun()        { this._tone(250, 0.1, 'square', 0.15); this._noise(0.06, 0.1); },
    heal()        { this._tone(523, 0.08, 'sine', 0.2); this._tone(784, 0.12, 'sine', 0.2, 0.06); },
    levelUp()     { this._tone(523, 0.08, 'sine', 0.2); this._tone(659, 0.08, 'sine', 0.2, 0.08); this._tone(784, 0.08, 'sine', 0.2, 0.16); this._tone(1047, 0.15, 'sine', 0.25, 0.24); },
    
    // Vehicle
    engineStart() { this._noise(0.15, 0.12); this._tone(80, 0.2, 'sawtooth', 0.15, 0.05); this._tone(120, 0.3, 'sawtooth', 0.12, 0.15); },
    crash()       { this._noise(0.2, 0.3); this._tone(80, 0.15, 'sawtooth', 0.2); },
    
    // ── Ambient Music System ──
    _music: null,       // Current music state { nodes: [], timers: [], id }
    _musicVolume: 0.4,  // Separate music volume
    
    stopMusic(fadeMs) {
        if (!this._music) return;
        const m = this._music;
        this._music = null;
        const fade = (fadeMs || 800) / 1000;
        const t = this._ctx ? this._ctx.currentTime : 0;
        for (const n of m.nodes) {
            try {
                if (n.gain) { n.gain.gain.linearRampToValueAtTime(0, t + fade); }
                if (n.stop) { try { n.stop(t + fade + 0.1); } catch(e){} }
                if (n.source && n.source.stop) { try { n.source.stop(t + fade + 0.1); } catch(e){} }
            } catch(e) {}
        }
        for (const timer of m.timers) clearInterval(timer);
    },
    
    // ── MENU THEME — dark ambient drone with evolving layers ──
    playMenuTheme() {
        if (!this._enabled) return;
        if (!this._init()) return;
        if (this._music && this._music.id === 'menu') return; // already playing
        this.stopMusic(200);
        
        const ctx = this._ctx;
        const now = ctx.currentTime;
        const vol = this._musicVolume * this._volume;
        const nodes = [];
        const timers = [];
        this._music = { nodes, timers, id: 'menu' };
        
        // === LAYER 1: Deep sub-bass drone (C1 ~32Hz) ===
        const subOsc = ctx.createOscillator();
        const subGain = ctx.createGain();
        subOsc.type = 'sine';
        subOsc.frequency.setValueAtTime(32.7, now);
        // Slow pitch drift — feels unstable, ominous
        subOsc.frequency.linearRampToValueAtTime(30.5, now + 8);
        subOsc.frequency.linearRampToValueAtTime(34, now + 16);
        subOsc.frequency.setValueAtTime(34, now + 16);
        subGain.gain.setValueAtTime(0, now);
        subGain.gain.linearRampToValueAtTime(vol * 0.35, now + 3);
        subOsc.connect(subGain);
        subGain.connect(this._masterGain);
        subOsc.start(now);
        nodes.push({ stop: () => { try{subOsc.stop();}catch(e){} }, gain: subGain });
        
        // Cycle the sub drift
        const subDrift = setInterval(() => {
            if (!this._music || this._music.id !== 'menu') return;
            const t = ctx.currentTime;
            subOsc.frequency.cancelScheduledValues(t);
            subOsc.frequency.setValueAtTime(subOsc.frequency.value, t);
            const target = 30 + Math.random() * 6;
            subOsc.frequency.linearRampToValueAtTime(target, t + 12 + Math.random() * 8);
        }, 14000);
        timers.push(subDrift);
        
        // === LAYER 2: Dissonant pad (two detuned saws, very quiet) ===
        const padFreqs = [55, 55.8]; // A1 with ~14 cent detune = beating
        const padGains = [];
        for (const freq of padFreqs) {
            const osc = ctx.createOscillator();
            const g = ctx.createGain();
            const filt = ctx.createBiquadFilter();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(freq, now);
            filt.type = 'lowpass';
            filt.frequency.setValueAtTime(200, now);
            filt.Q.setValueAtTime(2, now);
            g.gain.setValueAtTime(0, now);
            g.gain.linearRampToValueAtTime(vol * 0.08, now + 5);
            osc.connect(filt);
            filt.connect(g);
            g.connect(this._masterGain);
            osc.start(now);
            padGains.push(g);
            nodes.push({ stop: () => { try{osc.stop();}catch(e){} }, gain: g });
        }
        
        // Slowly sweep the pad filter — opens and closes like breathing
        const padSweep = setInterval(() => {
            if (!this._music || this._music.id !== 'menu') return;
            const t = ctx.currentTime;
            for (const g of padGains) {
                // Volume swell
                const peak = vol * (0.06 + Math.random() * 0.06);
                g.gain.cancelScheduledValues(t);
                g.gain.setValueAtTime(g.gain.value, t);
                g.gain.linearRampToValueAtTime(peak, t + 4);
                g.gain.linearRampToValueAtTime(vol * 0.03, t + 10);
            }
        }, 11000);
        timers.push(padSweep);
        
        // === LAYER 3: Wind noise — filtered, slow swell ===
        const noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 4, ctx.sampleRate);
        const noiseData = noiseBuf.getChannelData(0);
        for (let i = 0; i < noiseData.length; i++) noiseData[i] = Math.random() * 2 - 1;
        
        const noiseSrc = ctx.createBufferSource();
        noiseSrc.buffer = noiseBuf;
        noiseSrc.loop = true;
        const noiseFilt = ctx.createBiquadFilter();
        noiseFilt.type = 'bandpass';
        noiseFilt.frequency.setValueAtTime(400, now);
        noiseFilt.Q.setValueAtTime(0.5, now);
        const noiseGain = ctx.createGain();
        noiseGain.gain.setValueAtTime(0, now);
        noiseGain.gain.linearRampToValueAtTime(vol * 0.06, now + 6);
        noiseSrc.connect(noiseFilt);
        noiseFilt.connect(noiseGain);
        noiseGain.connect(this._masterGain);
        noiseSrc.start(now);
        nodes.push({ source: noiseSrc, gain: noiseGain, stop: () => { try{noiseSrc.stop();}catch(e){} } });
        
        // Wind gusts — bandpass sweeps
        const windGust = setInterval(() => {
            if (!this._music || this._music.id !== 'menu') return;
            const t = ctx.currentTime;
            const centerFreq = 200 + Math.random() * 800;
            noiseFilt.frequency.cancelScheduledValues(t);
            noiseFilt.frequency.setValueAtTime(noiseFilt.frequency.value, t);
            noiseFilt.frequency.linearRampToValueAtTime(centerFreq, t + 2);
            noiseFilt.frequency.linearRampToValueAtTime(300, t + 6);
            noiseGain.gain.cancelScheduledValues(t);
            noiseGain.gain.setValueAtTime(noiseGain.gain.value, t);
            noiseGain.gain.linearRampToValueAtTime(vol * (0.04 + Math.random() * 0.06), t + 1.5);
            noiseGain.gain.linearRampToValueAtTime(vol * 0.03, t + 5);
        }, 7000 + Math.random() * 4000);
        timers.push(windGust);
        
        // === LAYER 4: Eerie high harmonics — sine tones that fade in/out ===
        const eerieNotes = [
            329.6,  // E4
            311.1,  // Eb4 (dissonant with E)
            466.2,  // Bb4
            277.2,  // C#4
            493.9,  // B4
            415.3,  // Ab4
        ];
        
        const eerieInterval = setInterval(() => {
            if (!this._music || this._music.id !== 'menu') return;
            if (Math.random() > 0.5) return; // 50% chance each cycle
            const t = ctx.currentTime;
            const freq = eerieNotes[Math.floor(Math.random() * eerieNotes.length)];
            const dur = 3 + Math.random() * 5;
            const osc = ctx.createOscillator();
            const g = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, t);
            // Slow vibrato
            osc.frequency.linearRampToValueAtTime(freq * (1 + (Math.random() - 0.5) * 0.02), t + dur);
            g.gain.setValueAtTime(0, t);
            g.gain.linearRampToValueAtTime(vol * (0.02 + Math.random() * 0.03), t + dur * 0.3);
            g.gain.linearRampToValueAtTime(0, t + dur);
            osc.connect(g);
            g.connect(this._masterGain);
            osc.start(t);
            osc.stop(t + dur + 0.1);
        }, 4000 + Math.random() * 3000);
        timers.push(eerieInterval);
        
        // === LAYER 5: Distant metallic impacts — irregular ===
        const impactInterval = setInterval(() => {
            if (!this._music || this._music.id !== 'menu') return;
            if (Math.random() > 0.35) return; // ~35% chance
            const t = ctx.currentTime;
            // Metallic ring: short noise + resonant sine
            const nBuf = ctx.createBuffer(1, ctx.sampleRate * 0.08, ctx.sampleRate);
            const nD = nBuf.getChannelData(0);
            for (let i = 0; i < nD.length; i++) nD[i] = (Math.random() * 2 - 1) * (1 - i / nD.length);
            const ns = ctx.createBufferSource();
            ns.buffer = nBuf;
            const ng = ctx.createGain();
            ng.gain.setValueAtTime(vol * 0.06, t);
            ng.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
            const nf = ctx.createBiquadFilter();
            nf.type = 'highpass';
            nf.frequency.setValueAtTime(2000, t);
            ns.connect(nf);
            nf.connect(ng);
            ng.connect(this._masterGain);
            ns.start(t);
            
            // Resonant ring
            const ringFreq = 800 + Math.random() * 1200;
            const ringOsc = ctx.createOscillator();
            const ringG = ctx.createGain();
            ringOsc.type = 'sine';
            ringOsc.frequency.setValueAtTime(ringFreq, t);
            ringG.gain.setValueAtTime(vol * 0.03, t);
            ringG.gain.exponentialRampToValueAtTime(0.001, t + 1.5);
            ringOsc.connect(ringG);
            ringG.connect(this._masterGain);
            ringOsc.start(t);
            ringOsc.stop(t + 1.6);
        }, 5000 + Math.random() * 6000);
        timers.push(impactInterval);
        
        // === LAYER 6: Very low rumble pulses — like distant explosions ===
        const rumbleInterval = setInterval(() => {
            if (!this._music || this._music.id !== 'menu') return;
            if (Math.random() > 0.3) return;
            const t = ctx.currentTime;
            const rOsc = ctx.createOscillator();
            const rG = ctx.createGain();
            rOsc.type = 'sawtooth';
            rOsc.frequency.setValueAtTime(25 + Math.random() * 15, t);
            rOsc.frequency.exponentialRampToValueAtTime(18, t + 2);
            const rFilt = ctx.createBiquadFilter();
            rFilt.type = 'lowpass';
            rFilt.frequency.setValueAtTime(80, t);
            rG.gain.setValueAtTime(0, t);
            rG.gain.linearRampToValueAtTime(vol * 0.12, t + 0.3);
            rG.gain.linearRampToValueAtTime(0, t + 2.5);
            rOsc.connect(rFilt);
            rFilt.connect(rG);
            rG.connect(this._masterGain);
            rOsc.start(t);
            rOsc.stop(t + 2.6);
        }, 8000 + Math.random() * 7000);
        timers.push(rumbleInterval);
    },
    
    // ── Biome Ambient Audio System ──
    _ambient: null, // { nodes: [], timers: [], id }
    _ambientVolume: 0.15,
    
    stopAmbient(fadeMs) {
        if (!this._ambient) return;
        const a = this._ambient;
        this._ambient = null;
        const fade = (fadeMs || 600) / 1000;
        const t = this._ctx ? this._ctx.currentTime : 0;
        for (const n of a.nodes) {
            try {
                if (n.gain) n.gain.gain.linearRampToValueAtTime(0, t + fade);
                if (n.stop) { try { n.stop(t + fade + 0.1); } catch(e){} }
                if (n.source && n.source.stop) { try { n.source.stop(t + fade + 0.1); } catch(e){} }
            } catch(e) {}
        }
        for (const timer of a.timers) clearInterval(timer);
    },
    
    playBiomeAmbient(biomeType) {
        if (!this._enabled) return;
        if (!this._init()) return;
        const id = 'ambient_' + biomeType;
        if (this._ambient && this._ambient.id === id) return;
        this.stopAmbient(200);
        
        const ctx = this._ctx;
        const now = ctx.currentTime;
        const vol = this._ambientVolume * this._volume;
        const nodes = [];
        const timers = [];
        this._ambient = { nodes, timers, id };
        
        if (biomeType === 'grassy') {
            // === OVERGROWN: Insects, bird warbles, gentle breeze ===
            
            // Breeze — filtered noise, very low
            const bLen = 8;
            const bBuf = ctx.createBuffer(1, ctx.sampleRate * bLen, ctx.sampleRate);
            const bData = bBuf.getChannelData(0);
            for (let i = 0; i < bData.length; i++) bData[i] = (Math.random() * 2 - 1) * 0.5;
            const bSrc = ctx.createBufferSource();
            bSrc.buffer = bBuf; bSrc.loop = true;
            const bFilt = ctx.createBiquadFilter();
            bFilt.type = 'lowpass'; bFilt.frequency.setValueAtTime(400, now); bFilt.Q.setValueAtTime(0.5, now);
            const bGain = ctx.createGain();
            bGain.gain.setValueAtTime(0, now);
            bGain.gain.linearRampToValueAtTime(vol * 0.3, now + 2);
            bSrc.connect(bFilt); bFilt.connect(bGain); bGain.connect(this._masterGain);
            bSrc.start(now);
            nodes.push({ stop: () => { try{bSrc.stop();}catch(e){} }, gain: bGain });
            
            // Insect chirps — periodic high-frequency bursts
            const chirpInterval = setInterval(() => {
                if (!this._ambient || this._ambient.id !== id) return;
                const t = ctx.currentTime;
                const freq = 3000 + Math.random() * 2000;
                const dur = 0.03 + Math.random() * 0.04;
                const o = ctx.createOscillator();
                const g = ctx.createGain();
                o.type = 'sine'; o.frequency.setValueAtTime(freq, t);
                g.gain.setValueAtTime(vol * (0.05 + Math.random() * 0.05), t);
                g.gain.exponentialRampToValueAtTime(0.001, t + dur);
                o.connect(g); g.connect(this._masterGain);
                o.start(t); o.stop(t + dur + 0.01);
                // Double chirp
                if (Math.random() < 0.6) {
                    const o2 = ctx.createOscillator();
                    const g2 = ctx.createGain();
                    o2.type = 'sine'; o2.frequency.setValueAtTime(freq * 1.02, t + dur + 0.02);
                    g2.gain.setValueAtTime(vol * 0.04, t + dur + 0.02);
                    g2.gain.exponentialRampToValueAtTime(0.001, t + dur * 2 + 0.02);
                    o2.connect(g2); g2.connect(this._masterGain);
                    o2.start(t + dur + 0.02); o2.stop(t + dur * 2 + 0.04);
                }
            }, 1500 + Math.random() * 2000);
            timers.push(chirpInterval);
            
            // Bird warble — occasional descending tone
            const birdInterval = setInterval(() => {
                if (!this._ambient || this._ambient.id !== id) return;
                if (Math.random() > 0.4) return;
                const t = ctx.currentTime;
                const o = ctx.createOscillator();
                const g = ctx.createGain();
                o.type = 'sine';
                o.frequency.setValueAtTime(1800 + Math.random() * 600, t);
                o.frequency.linearRampToValueAtTime(1200 + Math.random() * 400, t + 0.15);
                g.gain.setValueAtTime(vol * 0.06, t);
                g.gain.exponentialRampToValueAtTime(0.001, t + 0.2);
                o.connect(g); g.connect(this._masterGain);
                o.start(t); o.stop(t + 0.22);
            }, 5000 + Math.random() * 4000);
            timers.push(birdInterval);
            
        } else if (biomeType === 'barren') {
            // === WASTELAND: Wind howl, sand hiss, distant creaking ===
            
            // Wind — filtered noise with LFO modulating volume
            const wLen = 6;
            const wBuf = ctx.createBuffer(1, ctx.sampleRate * wLen, ctx.sampleRate);
            const wData = wBuf.getChannelData(0);
            for (let i = 0; i < wData.length; i++) wData[i] = (Math.random() * 2 - 1);
            const wSrc = ctx.createBufferSource();
            wSrc.buffer = wBuf; wSrc.loop = true;
            const wFilt = ctx.createBiquadFilter();
            wFilt.type = 'bandpass'; wFilt.frequency.setValueAtTime(600, now); wFilt.Q.setValueAtTime(2, now);
            const wGain = ctx.createGain();
            wGain.gain.setValueAtTime(0, now);
            wGain.gain.linearRampToValueAtTime(vol * 0.35, now + 2);
            wSrc.connect(wFilt); wFilt.connect(wGain); wGain.connect(this._masterGain);
            wSrc.start(now);
            nodes.push({ stop: () => { try{wSrc.stop();}catch(e){} }, gain: wGain });
            
            // Wind gusts — modulate filter frequency
            const gustInterval = setInterval(() => {
                if (!this._ambient || this._ambient.id !== id) return;
                const t = ctx.currentTime;
                const target = 300 + Math.random() * 800;
                wFilt.frequency.cancelScheduledValues(t);
                wFilt.frequency.setValueAtTime(wFilt.frequency.value, t);
                wFilt.frequency.linearRampToValueAtTime(target, t + 2 + Math.random() * 3);
                wGain.gain.cancelScheduledValues(t);
                wGain.gain.setValueAtTime(wGain.gain.value, t);
                wGain.gain.linearRampToValueAtTime(vol * (0.2 + Math.random() * 0.25), t + 1.5);
            }, 3000 + Math.random() * 3000);
            timers.push(gustInterval);
            
            // Sand hiss — high-frequency filtered noise
            const sLen = 4;
            const sBuf = ctx.createBuffer(1, ctx.sampleRate * sLen, ctx.sampleRate);
            const sData = sBuf.getChannelData(0);
            for (let i = 0; i < sData.length; i++) sData[i] = (Math.random() * 2 - 1) * 0.3;
            const sSrc = ctx.createBufferSource();
            sSrc.buffer = sBuf; sSrc.loop = true;
            const sFilt = ctx.createBiquadFilter();
            sFilt.type = 'highpass'; sFilt.frequency.setValueAtTime(3000, now);
            const sGain = ctx.createGain();
            sGain.gain.setValueAtTime(vol * 0.08, now);
            sSrc.connect(sFilt); sFilt.connect(sGain); sGain.connect(this._masterGain);
            sSrc.start(now);
            nodes.push({ stop: () => { try{sSrc.stop();}catch(e){} }, gain: sGain });
            
            // Distant creak — occasional
            const creakInterval = setInterval(() => {
                if (!this._ambient || this._ambient.id !== id) return;
                if (Math.random() > 0.3) return;
                const t = ctx.currentTime;
                const o = ctx.createOscillator();
                const g = ctx.createGain();
                o.type = 'sawtooth';
                o.frequency.setValueAtTime(80 + Math.random() * 40, t);
                o.frequency.linearRampToValueAtTime(60 + Math.random() * 30, t + 0.3);
                g.gain.setValueAtTime(vol * 0.04, t);
                g.gain.exponentialRampToValueAtTime(0.001, t + 0.4);
                o.connect(g); g.connect(this._masterGain);
                o.start(t); o.stop(t + 0.45);
            }, 7000 + Math.random() * 5000);
            timers.push(creakInterval);
            
        } else if (biomeType === 'apocalyptic') {
            // === ANOMALOUS: Low electronic hum, static crackle, crystal resonance ===
            
            // Deep hum — two detuned sines for beating
            const humFreqs = [48, 48.5];
            for (const freq of humFreqs) {
                const o = ctx.createOscillator();
                const g = ctx.createGain();
                const f = ctx.createBiquadFilter();
                o.type = 'sine'; o.frequency.setValueAtTime(freq, now);
                f.type = 'lowpass'; f.frequency.setValueAtTime(120, now);
                g.gain.setValueAtTime(0, now);
                g.gain.linearRampToValueAtTime(vol * 0.25, now + 3);
                o.connect(f); f.connect(g); g.connect(this._masterGain);
                o.start(now);
                nodes.push({ stop: () => { try{o.stop();}catch(e){} }, gain: g });
            }
            
            // Static crackle — irregular noise bursts
            const staticInterval = setInterval(() => {
                if (!this._ambient || this._ambient.id !== id) return;
                const t = ctx.currentTime;
                const dur = 0.02 + Math.random() * 0.06;
                const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
                const data = buf.getChannelData(0);
                for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1);
                const src = ctx.createBufferSource();
                src.buffer = buf;
                const g = ctx.createGain();
                g.gain.setValueAtTime(vol * (0.03 + Math.random() * 0.05), t);
                g.gain.exponentialRampToValueAtTime(0.001, t + dur);
                src.connect(g); g.connect(this._masterGain);
                src.start(t);
            }, 800 + Math.random() * 1500);
            timers.push(staticInterval);
            
            // Crystal resonance — high pure tone, distant
            const crystalInterval = setInterval(() => {
                if (!this._ambient || this._ambient.id !== id) return;
                if (Math.random() > 0.5) return;
                const t = ctx.currentTime;
                const freq = 1200 + Math.random() * 800;
                const o = ctx.createOscillator();
                const g = ctx.createGain();
                o.type = 'sine'; o.frequency.setValueAtTime(freq, t);
                g.gain.setValueAtTime(0, t);
                g.gain.linearRampToValueAtTime(vol * 0.04, t + 0.3);
                g.gain.linearRampToValueAtTime(0, t + 1.5);
                o.connect(g); g.connect(this._masterGain);
                o.start(t); o.stop(t + 1.6);
            }, 4000 + Math.random() * 6000);
            timers.push(crystalInterval);
            
            // Slow pitch drift on the hum
            const driftInterval = setInterval(() => {
                if (!this._ambient || this._ambient.id !== id) return;
                const t = ctx.currentTime;
                const drift = 44 + Math.random() * 8;
                for (const n of nodes) {
                    if (n.stop) {
                        try {
                            // Can't easily access osc, but the hum already sounds otherworldly
                        } catch(e) {}
                    }
                }
            }, 10000);
            timers.push(driftInterval);
        }
    }
};
