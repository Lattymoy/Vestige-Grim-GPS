// Vestige GPS — _initCustom
// Extracted from monolith L77642-77653

import { SaveManager } from '../core/saveManager.js';
import { SurvivorGenerator } from '../core/survivorGenerator.js';


export let _initCustom = null;
try {
    const _initSave = SaveManager.load();
    if (_initSave && _initSave.survivors) {
        const _deployed = _initSave.survivors.find(s => s.deployed && s.alive) || _initSave.survivors.find(s => s.alive);
        if (_deployed) _initCustom = SurvivorGenerator.toCustomization(_deployed);
    }
    if (!_initCustom) {
        const _savedCustom = SaveManager.getCustomization();
        if (Object.keys(_savedCustom).length > 0) _initCustom = _savedCustom;
    }
} catch(e) {}

