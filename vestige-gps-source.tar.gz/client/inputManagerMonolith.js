// Vestige GPS — InputManager
// Extracted from monolith L28261-28358

import { Haptics } from '../core/haptics.js';
import { CONFIG } from '../data/config.js';
import { AudioManager } from './audioManager.js';
import { InteractHighlight } from './interactHighlight.js';


export const InputManager = {
    setup(scene, opts = {}) {
        const enableDodge = opts.dodge !== false;
        const enableTapTarget = opts.tapTarget !== false;
        const onDodge = opts.onDodge || null;
        const onTapTarget = opts.onTapTarget || null;
        
        // Ensure audio context is ready
        scene.input.once('pointerdown', () => AudioManager.resume());
        
        scene.moveDir = { x: 0, y: 0 };
        scene.movePointer = null;
        scene.moveAnchor = { x: 0, y: 0 };
        scene._inputSwipes = {};
        
        scene.input.on('pointerdown', (p) => {
            if (scene.state && scene.state.dead) return;
            if (scene.isDead) return;
            if (scene.popupActive || scene.inventoryUI || scene.vehicleMenu || scene.lootMenuOpen) return;
            
            // Check tap-to-interact on highlighted world objects
            if (InteractHighlight.getTarget(scene)) {
                const cam = scene.cameras.main;
                const wx = p.x + (cam.scrollX || 0);
                const wy = p.y + (cam.scrollY || 0);
                if (InteractHighlight.checkTap(scene, wx, wy, 55)) {
                    if (scene.nearestStation && scene.nearestStation.config && scene.nearestStation.config.action && !scene._interactDebounce) {
                        scene._interactDebounce = true;
                        scene.time.delayedCall(300, () => { scene._interactDebounce = false; });
                        AudioManager.uiClick();
                        Haptics.light();
                        scene.nearestStation.config.action();
                    } else if (scene.handleInteract) {
                        AudioManager.uiClick();
                        Haptics.light();
                        scene.handleInteract();
                    }
                    return;
                }
            }
            
            scene._inputSwipes[p.id] = { x: p.x, y: p.y, t: Date.now() };
            if (!scene.movePointer) {
                scene.movePointer = p;
                scene.moveAnchor = { x: p.x, y: p.y };
            }
        });
        
        scene.input.on('pointermove', (p) => {
            if (scene.movePointer && p.id === scene.movePointer.id) {
                const dx = p.x - scene.moveAnchor.x;
                const dy = p.y - scene.moveAnchor.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist > 3) {
                    const f = Math.min(dist / 40, 1);
                    scene.moveDir = { x: (dx / dist) * f, y: (dy / dist) * f };
                    if (dist > 60) {
                        scene.moveAnchor.x = p.x - (dx / dist) * 40;
                        scene.moveAnchor.y = p.y - (dy / dist) * 40;
                    }
                } else {
                    scene.moveDir = { x: 0, y: 0 };
                }
            }
        });
        
        scene.input.on('pointerup', (p) => {
            const sw = scene._inputSwipes[p.id];
            if (sw) {
                const dx = p.x - sw.x;
                const dy = p.y - sw.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const elapsed = Date.now() - sw.t;
                
                if (enableDodge && dist >= (CONFIG.swipeThreshold || 40) && elapsed <= (CONFIG.swipeTime || 300)) {
                    if (onDodge) onDodge.call(scene, dx, dy);
                    else if (scene.performDodge) scene.performDodge(dx, dy);
                } else if (enableTapTarget && dist < 25 && elapsed < 300) {
                    if (onTapTarget) onTapTarget.call(scene, p.x, p.y);
                    else if (scene.tapTarget) scene.tapTarget(p.x, p.y);
                }
                delete scene._inputSwipes[p.id];
            }
            if (scene.movePointer && p.id === scene.movePointer.id) {
                scene.movePointer = null;
                scene.moveDir = { x: 0, y: 0 };
            }
        });
    },
    
    getVelocity(scene, speed) {
        let vx = scene.moveDir.x;
        let vy = scene.moveDir.y;
        const len = Math.sqrt(vx * vx + vy * vy);
        if (len > 1) { vx /= len; vy /= len; }
        return { vx: vx * speed, vy: vy * speed, rawX: vx, rawY: vy, moving: len > 0.05 };
    }
};

