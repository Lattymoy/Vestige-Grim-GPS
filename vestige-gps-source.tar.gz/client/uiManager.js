// Vestige GPS — UIManager
// Extracted from monolith lines 33782-34352
// TODO: convert internal global refs to imports

import { Haptics } from '../core/haptics.js';
import { uiPx } from '../core/utils.js';
import { CONFIG } from '../data/config.js';
import { GrimFont } from '../data/grimFont.js';
import { AudioManager } from './audioManager.js';
import { UIAtlas } from './uiAtlas.js';


export const UIManager = {

    // Room accent colors (used for panel tinting)
    ACCENTS: {
        default:   0x4466aa,
        confirm:   0x33aa44,
        medical:   0x4466aa,
        barter:    0xaa7733,
        faction:   0x44aa66,
        stash:     0x8866aa,
        portal:    0x9944cc,
        danger:    0xaa3333,
        bounty:    0x33aa66,
    },

    // Ensure atlas is built before any UI creation
    _ensure(scene) {
        UIAtlas.build(scene);
    },

    // ════════════════════════════════════════
    // PANEL — Nine-slice frame + clean interior
    // Returns a container. Caller adds content to container.
    // ════════════════════════════════════════
    createPanel(scene, x, y, w, h, opts = {}) {
        this._ensure(scene);
        const {
            variant = 'ui_panel',  // 'ui_panel', 'ui_panel_sm', 'ui_panel_danger'
            accent = 'default',    // key from ACCENTS or a 0xRRGGBB value
            title = null,          // string for panel title
            titleFont = 'grim',   // 'grim' or 'system'
            closable = true,
            onClose = null,
            scrollFactor = null,   // null = world space at camera, 0 = fixed to camera
            depth = 500,
            modal = true,          // dark backdrop
        } = opts;

        const F = UIAtlas.FRAME;
        // Position panel relative to camera so it appears centered on screen
        // We use world coordinates offset by camera scroll (not scrollFactor which breaks interactivity)
        const cam = scene.cameras.main;
        const worldX = (cam.scrollX || 0) + x;
        const worldY = (cam.scrollY || 0) + y;
        const container = scene.add.container(worldX, worldY).setDepth(depth);

        // Modal backdrop — tap outside panel to dismiss
        if (modal) {
            const backdrop = scene.add.rectangle(0, 0, CONFIG.width + 40, CONFIG.height + 40, 0x000000, 0.75);
            backdrop.setInteractive(); // block clicks through
            if (closable) {
                backdrop.on('pointerdown', () => {
                    AudioManager.uiClose();
                    Haptics.light();
                    if (onClose) onClose();
                    container.destroy();
                });
            }
            container.add(backdrop);
        }

        // Nine-slice panel
        const panel = scene.add.nineslice(0, 0, variant, null, w, h, F, F, F, F);
        panel.setInteractive(); // absorb taps so backdrop dismiss doesn't fire through panel
        container.add(panel);
        AudioManager.uiOpen();
        Haptics.light();

        // Accent color overlay on frame edges (tint the panel to match room)
        const accentColor = typeof accent === 'number' ? accent : (this.ACCENTS[accent] || this.ACCENTS.default);
        // Draw accent bars as thin rectangles over the nine-slice
        // Accent lines — subtle inner-frame colored highlights
        const accentAlpha = 0.25;
        const aTop = scene.add.rectangle(0, -h / 2 + F, w - F * 2, 1, accentColor, accentAlpha);
        const aBot = scene.add.rectangle(0, h / 2 - F, w - F * 2, 1, accentColor, accentAlpha);
        const aLeft = scene.add.rectangle(-w / 2 + F, 0, 1, h - F * 2, accentColor, accentAlpha);
        const aRight = scene.add.rectangle(w / 2 - F, 0, 1, h - F * 2, accentColor, accentAlpha);
        container.add([aTop, aBot, aLeft, aRight]);

        // Title
        if (title) {
            const titleY = -h / 2 + F + 8;
            if (titleFont === 'grim' && GrimFont.built) {
                const gt = GrimFont.drawText(scene, 0, titleY, title, { scale: 0.35, rust: false, depth: depth + 1, center: true });
                container.add(gt);
            } else {
                const tt = scene.add.text(0, titleY, title, {
                    fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#' + accentColor.toString(16).padStart(6, '0'),
                    fontStyle: 'bold'
                }).setOrigin(0.5);
                container.add(tt);
            }
        }

        // Content area bounds (for caller to know where to place content)
        container._contentBounds = {
            x: -w / 2 + F + 4,
            y: -h / 2 + F + (title ? 22 : 4),
            w: w - F * 2 - 8,
            h: h - F * 2 - (title ? 26 : 8) - (closable ? 0 : 0)
        };
        container._panelW = w;
        container._panelH = h;
        container._frame = F;
        container._accent = accentColor;

        return container;
    },

    // ════════════════════════════════════════
    // BUTTON — Textured with press state
    // ════════════════════════════════════════
    createButton(scene, x, y, label, opts = {}) {
        this._ensure(scene);
        const {
            width = 90,
            height = 24,
            style = 'normal',  // 'normal', 'danger', 'confirm', 'disabled'
            fontSize = uiPx(9),
            onClick = null,
            depth = 0,
        } = opts;

        const texKey = style === 'danger' ? 'ui_btn_danger' :
                       style === 'confirm' ? 'ui_btn_confirm' :
                       style === 'disabled' ? 'ui_btn_disabled' : 'ui_btn';
        const pressKey = 'ui_btn_press';

        const container = scene.add.container(x, y).setDepth(depth);

        const bg = scene.add.nineslice(0, 0, texKey, null, width, height, 6, 6, 4, 4);
        container.add(bg);

        const textColor = style === 'danger' ? '#aa6666' :
                         style === 'confirm' ? '#66aa66' :
                         style === 'disabled' ? '#555555' : '#8888bb';

        const txt = scene.add.text(0, 0, label, {
            fontFamily: 'Share Tech Mono, monospace', fontSize: fontSize, fill: textColor
        }).setOrigin(0.5);
        container.add(txt);

        if (style !== 'disabled' && onClick) {
            bg.setInteractive({ useHandCursor: true });

            bg.on('pointerdown', () => {
                bg.setTexture(pressKey);
                txt.y = 1;
                AudioManager.uiClick();
                Haptics.light();
                if (onClick) onClick();
            });
            bg.on('pointerup', () => {
                bg.setTexture(texKey);
                txt.y = 0;
            });
            bg.on('pointerout', () => {
                bg.setTexture(texKey);
                txt.y = 0;
            });
        }

        container._bg = bg;
        container._label = txt;
        return container;
    },

    // ════════════════════════════════════════
    // TAB BAR — Horizontal tab strip
    // ════════════════════════════════════════
    createTabs(scene, x, y, labels, activeIdx, onChange, opts = {}) {
        this._ensure(scene);
        const { tabWidth = 70, tabHeight = 20, depth = 0, fontSize = uiPx(8) } = opts;
        const container = scene.add.container(x, y).setDepth(depth);
        const totalW = labels.length * tabWidth;
        const startX = -totalW / 2 + tabWidth / 2;

        labels.forEach((label, i) => {
            const tx = startX + i * tabWidth;
            const isActive = i === activeIdx;
            const texKey = isActive ? 'ui_tab_active' : 'ui_tab_inactive';

            const tab = scene.add.nineslice(tx, 0, texKey, null, tabWidth - 2, tabHeight, 4, 4, 4, 4);
            container.add(tab);

            const ttxt = scene.add.text(tx, 0, label, {
                fontFamily: 'Share Tech Mono, monospace', fontSize: fontSize,
                fill: isActive ? '#aabbdd' : '#556677'
            }).setOrigin(0.5);
            container.add(ttxt);

            if (!isActive) {
                tab.setInteractive({ useHandCursor: true });
                tab.on('pointerdown', () => {
                    if (onChange) onChange(i);
                });
            }
        });

        return container;
    },

    // ════════════════════════════════════════
    // ITEM SLOT — Rarity-framed inventory cell
    // ════════════════════════════════════════
    createItemSlot(scene, x, y, item, opts = {}) {
        this._ensure(scene);
        const { size = 36, depth = 0, onClick = null, showTooltip = false } = opts;
        const container = scene.add.container(x, y).setDepth(depth);

        // Determine rarity
        let rarityKey = 'empty';
        if (item) {
            const rarity = item.rarity || (item.tier ? CONFIG.tiers[item.tier]?.label?.toLowerCase() : null) || 'common';
            rarityKey = rarity;
        }

        const slotBg = scene.add.image(0, 0, `ui_slot_${rarityKey}`).setDisplaySize(size, size);
        container.add(slotBg);

        if (item) {
            // Item icon (emoji fallback or future sprite)
            const def = CONFIG.items?.[item.id] || {};
            const icon = def.icon || item.icon || '?';
            const iconText = scene.add.text(0, -2, icon, {
                fontSize: uiPx(Math.floor(size * 0.5))
            }).setOrigin(0.5);
            container.add(iconText);

            // Stack count
            if (item.count && item.count > 1) {
                const countText = scene.add.text(size / 2 - 4, size / 2 - 4, `${item.count}`, {
                    fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(7), fill: '#ccc',
                    stroke: '#000', strokeThickness: 2
                }).setOrigin(1, 1);
                container.add(countText);
            }
        }

        if (onClick) {
            slotBg.setInteractive({ useHandCursor: true });
            slotBg.on('pointerdown', () => onClick(item));
        }

        container._slotBg = slotBg;
        return container;
    },

    // ════════════════════════════════════════
    // HEALTH BAR — Type-specific with update method
    // Types: 'player', 'boss', 'enemy', 'friendly', 'nameplate', 'party'
    // ════════════════════════════════════════
    createHealthBar(scene, type, opts = {}) {
        this._ensure(scene);
        const configs = {
            player:    { texKey: 'ui_hp_player', w: 140, h: 18, fillColor: 0x44aa44, fillInset: 3, showText: true },
            boss:      { texKey: 'ui_hp_boss', w: 240, h: 22, fillColor: 0x9944cc, fillInset: 4, showText: true, showName: true },
            enemy:     { texKey: 'ui_hp_enemy', w: 40, h: 6, fillColor: 0xcc4444, fillInset: 1, showText: false },
            friendly:  { texKey: 'ui_hp_friendly', w: 40, h: 6, fillColor: 0x4488cc, fillInset: 1, showText: false },
            nameplate: { texKey: 'ui_hp_nameplate', w: 56, h: 8, fillColor: 0x4488cc, fillInset: 1, showText: false, showNameBelow: true },
            party:     { texKey: 'ui_hp_party', w: 100, h: 14, fillColor: 0x4488cc, fillInset: 2, showText: true, showNameLeft: true },
        };
        const cfg = configs[type] || configs.player;
        const w = opts.width || cfg.w;
        const h = opts.height || cfg.h;
        const { x = 0, y = 0, depth = 100, name = '', scrollFactor } = opts;

        const container = scene.add.container(x, y).setDepth(depth);
        if (scrollFactor !== undefined) container.setScrollFactor(scrollFactor);

        // Frame image
        const frame = scene.add.image(0, 0, cfg.texKey).setDisplaySize(w, h);
        container.add(frame);

        // Fill bar (inside frame)
        const ins = cfg.fillInset;
        const fillW = w - ins * 2 - (cfg.texKey.includes('boss') ? 6 : 2); // extra inset for accent pip
        const fillX = -fillW / 2 + (cfg.texKey.includes('boss') ? 1 : 0);
        const fill = scene.add.rectangle(fillX, 0, fillW, h - ins * 2, cfg.fillColor).setOrigin(0, 0.5);
        container.add(fill);

        // Text overlay
        let hpText = null;
        if (cfg.showText) {
            hpText = scene.add.text(0, 0, '', {
                fontFamily: 'Share Tech Mono, monospace',
                fontSize: type === 'player' ? uiPx(9) : type === 'boss' ? uiPx(9) : uiPx(7),
                fill: '#ffffff', stroke: '#000000', strokeThickness: 1
            }).setOrigin(0.5);
            container.add(hpText);
        }

        // Boss name (GrimFont above bar)
        let nameText = null;
        if (cfg.showName && name) {
            if (GrimFont.built) {
                nameText = GrimFont.drawText(scene, 0, -h / 2 - 10, name, {
                    scale: 0.3, rust: true, depth: depth + 1, center: true
                });
                container.add(nameText);
            } else {
                nameText = scene.add.text(0, -h / 2 - 8, name, {
                    fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#cc88ff', fontStyle: 'bold'
                }).setOrigin(0.5);
                container.add(nameText);
            }
        }

        // Nameplate name (below bar)
        if (cfg.showNameBelow && name) {
            const nt = scene.add.text(0, h / 2 + 4, name, {
                fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(6), fill: '#8899bb'
            }).setOrigin(0.5);
            container.add(nt);
        }

        // Party name (left of bar)
        if (cfg.showNameLeft && name) {
            const nt = scene.add.text(-w / 2 - 4, 0, name, {
                fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(7), fill: '#8899bb'
            }).setOrigin(1, 0.5);
            container.add(nt);
        }

        // Update method
        container.updateHP = (current, max) => {
            const pct = Math.max(0, Math.min(1, current / max));
            fill.displayWidth = fillW * pct;

            // Color shift (green → yellow → red for player)
            if (type === 'player') {
                if (pct > 0.6) fill.setFillStyle(0x44aa44);
                else if (pct > 0.3) fill.setFillStyle(0xaaaa33);
                else fill.setFillStyle(0xcc4444);
            }

            if (hpText) hpText.setText(`${Math.ceil(current)}/${max}`);
        };

        // Boss-specific: set name later
        container.setName = (n) => {
            if (nameText && nameText.setText) nameText.setText(n);
        };

        container._fill = fill;
        container._frame = frame;
        container._fillW = fillW;
        return container;
    },

    // ════════════════════════════════════════
    // RESOURCE BAR — Bits/Fuel/Ammo/Materials
    // ════════════════════════════════════════
    createResourceBar(scene, x, y, data, opts = {}) {
        this._ensure(scene);
        const { depth = 100, scrollFactor, compact = false } = opts;
        const container = scene.add.container(x, y).setDepth(depth);
        if (scrollFactor !== undefined) container.setScrollFactor(scrollFactor);

        const resources = [
            { key: 'bits', icon: 'ui_icon_bits', color: '#ccaa44' },
            { key: 'fuel', icon: 'ui_icon_fuel', color: '#66aa66' },
            { key: 'mag', icon: 'ui_icon_ammo', color: '#aaaacc' },
            { key: 'materials', icon: 'ui_icon_materials', color: '#aa9977' },
        ];

        const gap = compact ? 50 : 65;
        const startX = -((resources.length - 1) * gap) / 2;
        const texts = {};

        resources.forEach((res, i) => {
            const rx = startX + i * gap;
            const icon = scene.add.image(rx - 10, 0, res.icon).setScale(1);
            container.add(icon);

            const val = data[res.key] !== undefined ? data[res.key] : 0;
            const t = scene.add.text(rx + 2, 0, `${val}`, {
                fontFamily: 'Share Tech Mono, monospace',
                fontSize: compact ? uiPx(8) : uiPx(9),
                fill: res.color
            }).setOrigin(0, 0.5);
            container.add(t);
            texts[res.key] = t;
        });

        container.updateResource = (key, value) => {
            if (texts[key]) texts[key].setText(`${value}`);
        };

        container._texts = texts;
        return container;
    },

    // ════════════════════════════════════════
    // AMMO HUD — Bottom-right magazine display
    // Shows: MAG/∞ (regular) or MAG/COUNT (power)
    // Tap to toggle power ammo mode
    // ════════════════════════════════════════
    createAmmoHud(scene, x, y, opts = {}) {
        this._ensure(scene);
        const { depth = 100, scrollFactor = 0 } = opts;
        const container = scene.add.container(x, y).setDepth(depth).setScrollFactor(scrollFactor);
        
        // Background pill
        const bg = scene.add.rectangle(0, 0, 68, 28, 0x0a0a16, 0.85)
            .setStrokeStyle(1, 0x2a2a4a, 0.6);
        container.add(bg);
        
        // Bullet icon (left side) — small drawn rectangle
        const bulletIcon = scene.add.rectangle(-24, 0, 3, 8, 0xaaaacc)
            .setAngle(0);
        container.add(bulletIcon);
        
        // Ammo text (right of icon)
        const ammoText = scene.add.text(2, 0, '12/∞', {
            fontFamily: 'Share Tech Mono, monospace',
            fontSize: uiPx(10), fill: '#ccccdd'
        }).setOrigin(0.5).setScrollFactor(scrollFactor);
        container.add(ammoText);
        
        // Reload spinner (hidden by default) — rotating dashes
        const spinner = scene.add.text(0, 0, '↻', {
            fontFamily: 'Share Tech Mono, monospace',
            fontSize: uiPx(14), fill: '#ffcc44'
        }).setOrigin(0.5).setScrollFactor(scrollFactor).setVisible(false);
        container.add(spinner);
        
        // State
        let isReloading = false;
        let spinAngle = 0;
        let isPowerActive = false;
        
        // Tap handler
        bg.setInteractive({ useHandCursor: true });
        bg.on('pointerdown', () => {
            if (isReloading) return;
            if (!scene._togglePowerAmmo) return;
            scene._togglePowerAmmo();
        });
        
        // Public API
        container.update = (mag, powerActive, powerCount) => {
            if (isReloading) return;
            isPowerActive = powerActive;
            if (powerActive) {
                ammoText.setText(`${mag}/${powerCount || 0}`);
                ammoText.setColor('#cc88ff');
                bulletIcon.setFillStyle(0xcc88ff);
                bg.setStrokeStyle(1, 0x8844cc, 0.6);
            } else {
                ammoText.setText(`${mag}/∞`);
                ammoText.setColor('#ccccdd');
                bulletIcon.setFillStyle(0xaaaacc);
                bg.setStrokeStyle(1, 0x2a2a4a, 0.6);
            }
        };
        
        container.setReloading = (val) => {
            isReloading = val;
            ammoText.setVisible(!val);
            spinner.setVisible(val);
            if (val) {
                spinAngle = 0;
                if (container._spinTween) container._spinTween.remove();
                container._spinTween = scene.tweens.add({
                    targets: spinner, angle: 360,
                    duration: 800, repeat: -1, ease: 'Linear'
                });
            } else {
                if (container._spinTween) { container._spinTween.remove(); container._spinTween = null; }
                spinner.setAngle(0);
            }
        };
        
        return container;
    },

    // ════════════════════════════════════════
    // DIVIDER — Horizontal line with dots
    // ════════════════════════════════════════
    createDivider(scene, x, y, width, opts = {}) {
        const { depth = 0, color = 0x16162a } = opts;
        const line = scene.add.rectangle(x, y, width, 1, color);
        line.setDepth(depth);
        return line;
    },

    // ════════════════════════════════════════
    // STATUS LED — Tiny indicator light

    // ════════════════════════════════════════
    // ITEM ROW — Full shop-style item display
    // ════════════════════════════════════════
    createItemRow(scene, x, y, w, item, opts = {}) {
        this._ensure(scene);
        const { depth = 0, onBuy = null, cost = null, stock = null, revealed = true } = opts;
        const h = 40;
        const container = scene.add.container(x, y).setDepth(depth);

        // Row background
        const bg = scene.add.rectangle(0, 0, w, h, 0x0a0a14, 0.8);
        container.add(bg);
        bg.setStrokeStyle(1, 0x1a1a2a);

        if (!revealed) {
            // Encrypted/unknown item
            const enc = scene.add.text(0, -4, '[ ENCRYPTED ]', {
                fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(9), fill: '#554422'
            }).setOrigin(0.5);
            container.add(enc);

            if (cost) {
                const dec = scene.add.text(0, 10, `${cost} DECRYPT`, {
                    fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(7), fill: '#887744'
                }).setOrigin(0.5);
                container.add(dec);
            }
        } else if (item) {
            const def = CONFIG.items?.[item.id] || item;
            const rarity = item.rarity || (item.tier ? CONFIG.tiers[item.tier]?.label?.toLowerCase() : 'common');
            const rarityColor = CONFIG.tiers?.[item.tier || 1]?.color || 0x888888;

            // Rarity strip
            const strip = scene.add.rectangle(-w / 2 + 1.5, 0, 3, h, rarityColor, 0.8);
            container.add(strip);

            // Icon + Name
            const icon = def.icon || '?';
            const name = def.name || item.id || '???';
            const nameText = scene.add.text(-w / 2 + 10, -6, `${icon} ${name}`, {
                fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(9), fill: '#aab0cc'
            }).setOrigin(0, 0.5);
            container.add(nameText);

            // Tier pips
            const tier = item.tier || 1;
            for (let t = 0; t < tier; t++) {
                const pip = scene.add.rectangle(-w / 2 + 12 + t * 6, 8, 4, 4, rarityColor, 0.5);
                container.add(pip);
            }

            // Cost
            if (cost !== null) {
                const costText = scene.add.text(w / 2 - 8, -6, `${cost}`, {
                    fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(9), fill: '#ccaa44'
                }).setOrigin(1, 0.5);
                const bitsIcon = scene.add.image(w / 2 - 6, -6, 'ui_icon_bits').setScale(0.7);
                container.add([costText, bitsIcon]);
            }

            // Stock
            if (stock !== null) {
                const stockText = scene.add.text(w / 2 - 8, 8, `x${stock}`, {
                    fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(8), fill: '#444466'
                }).setOrigin(1, 0.5);
                container.add(stockText);
            }
        }

        // Interactive
        if (onBuy) {
            bg.setInteractive({ useHandCursor: true });
            bg.on('pointerdown', () => onBuy(item));
            bg.on('pointerover', () => bg.setFillStyle(0x12121e));
            bg.on('pointerout', () => bg.setFillStyle(0x0a0a14));
        }

        container._bg = bg;
        return container;
    }
};
