// Vestige GPS — MapScene
// Extracted from monolith lines 48723-55120
// Imports will be wired in integration pass

import { ItemManager } from '../../core/itemManager.js';
import { RouteGenerator } from '../../core/routeGenerator.js';
import { SaveManager } from '../../core/saveManager.js';
import { Utils, uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { AudioManager } from '../audioManager.js';
import { SafehouseExterior } from '../rendering/safehouseExterior.js';
import { SpriteManager } from '../spriteManager.js';
import { GameHUD } from '../ui/gameHUD.js';
import { UIAtlas } from '../uiAtlas.js';
import { UIManager } from '../uiManager.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { GameScene } from './GameScene.js';
import { HavenScene } from './HavenScene.js';
import { SafehouseScene } from './SafehouseScene.js';
import { TraversalScene } from './TraversalScene.js';


export class MapScene extends Phaser.Scene {
    constructor() {
        super({ key: 'MapScene' });
    }
    
    init(data) {
        // Stop any biome ambient audio
        try { AudioManager.stopAmbient(500); } catch(e) {}
        // Player state persists across the run
        this.playerState = data.playerState || {
            health: CONFIG.player.health,
            powerAmmo: CONFIG.player.powerAmmo,
            kills: 0,
            bits: 0,
            fuel: 100,
            materials: 0,
            backpack: ItemManager.createInventory(CONFIG.inventory.backpackSlots),
            vehicle: ItemManager.createInventory(CONFIG.inventory.vehicleSlots)
        };
        
        // Current node ID (where player is now)
        this.currentNodeId = data.currentNodeId || 'safehouse';
        
        // Track completed nodes (persists across map regeneration)
        this.completedNodes = data.completedNodes || [];
        
        // Track traveled routes (from -> to pairs)
        this.traveledRoutes = data.traveledRoutes || [];
        
        // If we arrived at a new node, mark the previous one as completed (except safehouse)
        if (data.previousNodeId && data.previousNodeId !== 'safehouse' && !this.completedNodes.includes(data.previousNodeId)) {
            this.completedNodes.push(data.previousNodeId);
        }
        
        // Well Rested buff — apply 15% bonus to currency earned during this node
        if (data.previousNodeId && this.playerState._preNodeBits !== undefined) {
            const sd = SaveManager.load();
            if (sd && sd.wellRested && sd.wellRested.active && sd.wellRested.runsRemaining > 0) {
                const bitsDelta = (this.playerState.bits || 0) - (this.playerState._preNodeBits || 0);
                const matsDelta = (this.playerState.materials || 0) - (this.playerState._preNodeMats || 0);
                if (bitsDelta > 0) this.playerState.bits += Math.ceil(bitsDelta * 0.15);
                if (matsDelta > 0) this.playerState.materials += Math.ceil(matsDelta * 0.15);
                sd.wellRested.runsRemaining--;
                if (sd.wellRested.runsRemaining <= 0) sd.wellRested = null;
                SaveManager.save(sd);
            }
            delete this.playerState._preNodeBits;
            delete this.playerState._preNodeMats;
        }
        
        // Track the route we just traveled
        if (data.previousNodeId && data.currentNodeId) {
            const routeKey = `${data.previousNodeId}->${data.currentNodeId}`;
            if (!this.traveledRoutes.includes(routeKey)) {
                this.traveledRoutes.push(routeKey);
            }
        }
        
        // Map generation seed for consistency
        this.mapSeed = data.mapSeed || Date.now();
        this.cloudTransition = data.cloudTransition || null;
        
        // Active route from CRT terminal (locked route mode)
        this.activeRoute = data.activeRoute || null;
        this.deployedSurvivor = data.deployedSurvivor || null;
    }
    
    create() {
        // Attach seeded RNG utilities
        Utils.attachRNG(this, this.mapSeed);
        
        // SIDE-SCROLLING: scrollX instead of scrollY, progress left to right
        this.scrollX = 0;
        this.targetScrollX = 0;
        this.nodeSpacing = 180; // Horizontal spacing between columns
        
        // Time of day for current reach
        this.timeOfDay = CONFIG.timeOfDay || 'midday';
        
        // Generate map: locked route mode or free exploration
        this.nodes = {};
        this.connections = [];
        if (this.activeRoute) {
            this.generateRouteMap();
        } else {
            this.generateMap();
        }
        
        // Mark completed nodes from our tracking
        this.completedNodes.forEach(nodeId => {
            if (this.nodes[nodeId]) {
                this.nodes[nodeId].completed = true;
            }
        });
        
        // Start blacked out to prevent flash
        this.cameras.main.setAlpha(0);
        
        // Create visual layers FIRST (before parallax uses them)
        this.bgLayer = this.add.container(0, 0).setDepth(1);
        this.farSceneryLayer = this.add.container(0, 0).setDepth(2);
        this.midSceneryLayer = this.add.container(0, 0).setDepth(3);
        this.nearSceneryLayer = this.add.container(0, 0).setDepth(3.5);
        this.connectionLayer = this.add.container(0, 0).setDepth(4);
        this.nodeLayer = this.add.container(0, 0).setDepth(5);
        this.uiLayer = this.add.container(0, 0).setDepth(100);
        
        // Create parallax background (uses farSceneryLayer)
        this.createParallaxBackground();
        
        // Draw scenery with parallax
        this.createScenery();
        
        // Draw map
        this.drawConnections();
        this.drawNodes();
        
        // Center on current node BEFORE rendering
        this.scrollToCurrentNode();
        this.updateNodePositions();
        
        // Create UI
        this.createUI();
        
        // Input
        this.setupInput();
        
        // Selected node for confirmation
        this.selectedNode = null;
        this.confirmPopup = null;
        
        // Now reveal the map
        this.cameras.main.setAlpha(1);
        if (this.cloudTransition) {
            this._playCloudReveal();
        } else {
            this.cameras.main.fadeIn(400);
        }
        
        // Route mode: create vehicle and start auto-drive after reveal
        if (this.activeRoute) {
            this.time.delayedCall(this.cloudTransition ? 1200 : 600, () => {
                this._routeStartDrive();
            });
        }
    }
    
    _playCloudReveal() {
        const cW = CONFIG.width, cH = CONFIG.height;
        const edgeTargets = [
            { x: cW / 2, y: -cH * 0.5 },
            { x: cW / 2, y: cH * 1.5 },
            { x: -cW * 0.5, y: cH / 2 },
            { x: cW * 1.5, y: cH / 2 },
        ];
        
        const buildCloud = (scene, w, h) => {
            const c = scene.add.container(0, 0);
            c.add(scene.add.ellipse(0, 0, w * 1.3, h * 1.5, 0xd0d0d0, 0.15));
            [{ x: -w*0.15, y: -h*0.05, sw: 0.7, sh: 0.8 },
             { x: w*0.1, y: 0, sw: 0.8, sh: 0.7 },
             { x: -w*0.05, y: h*0.05, sw: 0.9, sh: 0.65 },
             { x: w*0.2, y: -h*0.08, sw: 0.5, sh: 0.6 }
            ].forEach(o => c.add(scene.add.ellipse(o.x, o.y, w*o.sw, h*o.sh, 0xcccccc, 0.45)));
            c.add(scene.add.ellipse(0, -h*0.05, w*0.5, h*0.4, 0xdddddd, 0.5));
            c.add(scene.add.ellipse(-w*0.1, -h*0.2, w*0.4, h*0.2, 0xe8e8e8, 0.35));
            c.add(scene.add.ellipse(w*0.15, -h*0.18, w*0.3, h*0.15, 0xeeeeee, 0.3));
            c.add(scene.add.ellipse(0, h*0.15, w*0.7, h*0.25, 0x999999, 0.2));
            return c;
        };
        
        // White-out + fog
        const whiteout = this.add.rectangle(cW/2, cH/2, cW+200, cH+200, 0xcccccc, 1)
            .setScrollFactor(0).setDepth(499);
        const fogLayer = this.add.container(0, 0).setScrollFactor(0).setDepth(498);
        for (let f = 0; f < 8; f++) {
            fogLayer.add(this.add.rectangle(
                cW/2 + (Math.random()-0.5)*cW*0.4,
                cH/2 + (Math.random()-0.5)*cH*0.4,
                cW*0.8, cH*0.5, 0xcccccc, 0.06 + Math.random()*0.05
            ));
        }
        
        // Build covering clouds at center positions
        const cloudLayer = this.add.container(0, 0).setScrollFactor(0).setDepth(500);
        const allClouds = [];
        for (let bi = 0; bi < 4; bi++) {
            for (let i = 0; i < 3; i++) {
                const spread = (i - 1) * (bi < 2 ? cW * 0.35 : cH * 0.3);
                const cx = cW/2 + (bi < 2 ? spread * 0.4 : 0);
                const cy = cH/2 + (bi >= 2 ? spread * 0.4 : 0);
                const cloud = buildCloud(this, 250 + Math.random()*150, 120 + Math.random()*80);
                cloud.setPosition(cx, cy);
                cloudLayer.add(cloud);
                allClouds.push({ el: cloud, bank: bi });
            }
        }
        
        // Whiteout fades
        this.tweens.add({
            targets: whiteout, alpha: 0, duration: 1000, delay: 300,
            ease: 'Sine.easeOut', onComplete: () => whiteout.destroy()
        });
        // Fog fades
        this.tweens.add({
            targets: fogLayer, alpha: 0, duration: 1800, delay: 400,
            ease: 'Sine.easeOut', onComplete: () => fogLayer.destroy()
        });
        // Clouds disperse to edges
        allClouds.forEach((c, idx) => {
            const edge = edgeTargets[c.bank];
            const spread = (idx % 3 - 1) * (c.bank < 2 ? cW * 0.35 : cH * 0.3);
            this.tweens.add({
                targets: c.el,
                x: edge.x + (c.bank < 2 ? spread : 0),
                y: edge.y + (c.bank >= 2 ? spread : 0),
                alpha: 0,
                duration: 1400 + Math.random() * 500,
                delay: 500 + c.bank * 120 + (idx % 3) * 80,
                ease: 'Sine.easeIn',
                onComplete: () => c.el.destroy()
            });
        });
        this.time.delayedCall(2800, () => { if (cloudLayer.active) cloudLayer.destroy(); });
    }
    
    createParallaxBackground() {
        const W = CONFIG.width, H = CONFIG.height;
        const tod = this.timeOfDay;
        
        const skyPalette = {
            dawn: [0xffaa77, 0xff8855, 0x887766, 0x665566, 0x554455],
            midday: [0x7aaad8, 0x6699cc, 0x5588bb, 0x4477aa, 0x336699],
            dusk: [0xff7755, 0xdd6644, 0xaa5544, 0x553344, 0x2a2244],
            night: [0x1a1a2e, 0x171728, 0x141422, 0x10101c, 0x0a0a16]
        };
        const sc = skyPalette[tod] || skyPalette.midday;
        
        const horizonY = 340;
        this._horizonY = horizonY;
        
        // Sky gradient bands
        const bandH = horizonY / sc.length;
        for (let i = 0; i < sc.length; i++) {
            this.add.rectangle(W/2, i * bandH + bandH/2, W, bandH + 2, sc[i]).setScrollFactor(0).setDepth(0);
        }
        
        // Sun/Moon — single clean disc
        if (tod === 'night') {
            const mx = W - 50, my = 45;
            this.add.circle(mx, my, 12, 0xddddcc).setScrollFactor(0).setDepth(0.1);
            this.add.circle(mx + 4, my - 2, 11, sc[0]).setScrollFactor(0).setDepth(0.11);
            for (let i = 0; i < 20; i++) {
                this.add.circle(
                    Phaser.Math.Between(10, W - 10),
                    Phaser.Math.Between(5, horizonY * 0.6),
                    Math.random() > 0.8 ? 1.5 : 0.8,
                    0xffffff, Math.random() * 0.5 + 0.15
                ).setScrollFactor(0).setDepth(0.05);
            }
        } else if (tod === 'dawn') {
            this.add.circle(W - 50, horizonY - 30, 14, 0xffdd88).setScrollFactor(0).setDepth(0.1);
        } else if (tod === 'dusk') {
            this.add.circle(50, horizonY - 30, 14, 0xff9966).setScrollFactor(0).setDepth(0.1);
        } else {
            this.add.circle(W / 2 + 40, 55, 13, 0xffffdd).setScrollFactor(0).setDepth(0.1);
        }
        
        // Clouds
        this._clouds = [];
        const cAlpha = tod === 'night' ? 0.02 : tod === 'dawn' || tod === 'dusk' ? 0.03 : 0.05;
        for (let i = 0; i < 5; i++) {
            const cloud = this.add.ellipse(
                Phaser.Math.Between(-20, W + 20),
                Phaser.Math.Between(40, horizonY * 0.5),
                Phaser.Math.Between(60, 120),
                Phaser.Math.Between(15, 30),
                0xffffff, cAlpha
            ).setScrollFactor(0).setDepth(0.15);
            this._clouds.push({ obj: cloud, speed: 1.5 + Math.random() * 2.5 });
        }
        
        // === GROUND — depth gradient (darker near horizon, lighter near camera) ===
        const groundH = H - horizonY;
        const gSteps = 4;
        const gStepH = groundH / gSteps;
        const gBase = {
            grassy: [0x2e3e2a, 0x33432e, 0x384832, 0x3d4d37],
            barren: [0x3e3830, 0x434035, 0x484538, 0x4d4a3d],
            apocalyptic: [0x222020, 0x262424, 0x2a2828, 0x2e2c2c]
        };
        // Static ground gradient fallback
        for (let g = 0; g < gSteps; g++) {
            const gy = horizonY + g * gStepH + gStepH / 2;
            this.add.rectangle(W/2, gy, W, gStepH + 2, gBase.barren[g]).setScrollFactor(0).setDepth(0.3);
        }
        // Horizon bridge — covers seam between sky and ground layers
        this.add.rectangle(W/2, horizonY, W, 30, gBase.barren[0]).setScrollFactor(0).setDepth(0.25);
        
        // === SCROLLING GROUND BANDS — biome-colored with depth gradient ===
        this._groundBands = [];
        const bandWidth = 250;
        const mapW = this.mapWidth || 5000;
        
        for (let bx = -400; bx < mapW + 400; bx += bandWidth) {
            const biome = this.getBiomeAtX(bx);
            const colors = gBase[biome] || gBase.barren;
            for (let g = 0; g < gSteps; g++) {
                const gy = horizonY + g * gStepH + gStepH / 2;
                const band = this.add.rectangle(bx + bandWidth/2, gy, bandWidth + 30, gStepH + 2, colors[g]);
                band.baseX = bx + bandWidth/2;
                this.bgLayer.add(band);
                this._groundBands.push(band);
            }
        }
        
        // === GROUND TEXTURE — subtle lines and color variation to break flatness ===
        this._groundTexture = [];
        const texColors = { grassy: [0x344a30, 0x3a5035], barren: [0x4a4235, 0x50483a], apocalyptic: [0x2a2626, 0x302c2c] };
        for (let tx = -200; tx < mapW + 200; tx += 30 + Math.floor(this.random() * 40)) {
            const biome = this.getBiomeAtX(tx);
            const tc = texColors[biome] || texColors.barren;
            const roll = this.random();
            if (roll < 0.4) {
                const lw = 20 + this.random() * 50;
                const ly = horizonY + 30 + this.random() * (groundH - 40);
                const line = this.add.rectangle(tx, ly, lw, 1, tc[0], 0.25);
                line.baseX = tx;
                this.bgLayer.add(line);
                this._groundTexture.push(line);
            } else if (roll < 0.7) {
                const pw = 8 + this.random() * 15;
                const ph = 4 + this.random() * 8;
                const py = horizonY + 20 + this.random() * (groundH - 30);
                const patch = this.add.ellipse(tx, py, pw, ph, tc[1], 0.15);
                patch.baseX = tx;
                this.bgLayer.add(patch);
                this._groundTexture.push(patch);
            } else {
                for (let sp = 0; sp < 3; sp++) {
                    const sx = tx + (this.random() - 0.5) * 20;
                    const sy = horizonY + 25 + this.random() * (groundH - 35);
                    const dot = this.add.rectangle(sx, sy, 1 + this.random() * 2, 1, tc[0], 0.2);
                    dot.baseX = sx;
                    this.bgLayer.add(dot);
                    this._groundTexture.push(dot);
                }
            }
        }
        
        // === CONTINUOUS HORIZON LINE — clean ground-meets-sky transition ===
        this._horizonRidge = [];
        const gRidgeColors = { grassy: 0x2e3e2a, barren: 0x3e3830, apocalyptic: 0x222020 };
        // Simple continuous ridge strip covering full parallax range
        const ridgeExtent = mapW + 400;
        for (let hx = -200; hx < ridgeExtent; hx += 80) {
            const biome = this.getBiomeAtX(hx);
            const ridgeCol = gRidgeColors[biome] || gRidgeColors.barren;
            const ridge = this.add.ellipse(hx + 40, horizonY + 4, 120, 14 + this.random() * 4, ridgeCol);
            ridge.baseX = hx + 40;
            this.bgLayer.add(ridge);
            this._horizonRidge.push(ridge);
        }
        
        // === BACKGROUND SILHOUETTES (0.1x parallax) — mountains, cityscapes, cube crash ===
        // These sit ON the horizon line, rising upward. Very slow parallax = distant feel.
        this._bgSilhouettes = [];
        
        // At 0.1x parallax, need ~10x map width coverage but CAP to prevent lag
        const silExtent = mapW * 10 + 2000;
        const silSpacing = 200; // wider spacing for big silhouettes
        const silCount = Math.min(30, Math.ceil(silExtent / silSpacing));
        
        // Biome silhouette builders — each creates shapes anchored at y=0 (horizon line)
        const silBuilders = {
            grassy: [
                // Connected rolling ridge (raised terrain, not triangles)
                (c, s) => {
                    const rw = 80 + s.random() * 60;
                    const rh = 15 + s.random() * 25;
                    const rh2 = 10 + s.random() * 18;
                    const col = 0x253525;
                    // Continuous ridge using polygon — no disconnected peaks
                    c.add(s.add.polygon(0, 0, [
                        -rw/2, 0, -rw*0.4, -rh*0.4, -rw*0.2, -rh, 0, -rh*0.6,
                        rw*0.15, -rh2, rw*0.35, -rh2*0.5, rw/2, 0
                    ], col, 0.7));
                    // Lighter ridge face
                    c.add(s.add.polygon(0, 0, [
                        -rw*0.35, 0, -rw*0.15, -rh*0.85, 0, -rh*0.5, rw*0.2, -rh2*0.8, rw*0.4, 0
                    ], col + 0x111111, 0.4));
                },
                // Low treeline ridge — connected canopy mass
                (c, s) => {
                    const tw = 70 + s.random() * 40;
                    const th = 8 + s.random() * 10;
                    c.add(s.add.ellipse(0, -th/2, tw, th * 1.3, 0x1a3018, 0.5));
                    c.add(s.add.ellipse(-tw*0.2, -th/2-2, tw*0.5, th*0.8, 0x1a3018, 0.3));
                    c.add(s.add.ellipse(tw*0.15, -th/2+1, tw*0.4, th*0.7, 0x1a3018, 0.25));
                }
            ],
            barren: [
                // Mesa / butte range (connected)
                (c, s) => {
                    const mw = 50 + s.random() * 40, mh = 20 + s.random() * 30;
                    c.add(s.add.polygon(0, 0, [-mw/2, 0, -mw*0.4, -mh, mw*0.3, -mh, mw/2, 0], 0x2a2520, 0.7));
                    c.add(s.add.rectangle(0, -mh, mw * 0.6, 3, 0x3a3530, 0.6));
                    c.add(s.add.rectangle(-mw*0.15, -mh*0.5, 1, mh*0.4, 0x1a1510, 0.15));
                    c.add(s.add.rectangle(mw*0.1, -mh*0.6, 1, mh*0.3, 0x1a1510, 0.15));
                },
                // Distant sand dunes (connected)
                (c, s) => {
                    const dw = 70 + s.random() * 40, dh = 10 + s.random() * 15;
                    c.add(s.add.ellipse(0, -dh*0.3, dw, dh, 0x3a3328, 0.5));
                    c.add(s.add.ellipse(30, -dh*0.2, dw*0.6, dh*0.7, 0x2a2520, 0.4));
                }
            ],
            apocalyptic: [
                // Ruined cityscape skyline (ONLY in this far back layer)
                (c, s) => {
                    const bCount = 5 + Math.floor(s.random() * 4);
                    for (let b = 0; b < bCount; b++) {
                        const bx = (b - bCount/2) * 12 + s.random() * 6;
                        const bh = 15 + s.random() * 40;
                        const bw = 6 + s.random() * 8;
                        c.add(s.add.rectangle(bx, -bh/2, bw, bh, 0x121018, 0.7));
                        if (s.random() > 0.5) {
                            c.add(s.add.polygon(bx, 0, [-bw/2, -bh, -bw*0.2, -bh-4, bw/2, -bh+2], 0x121018, 0.7));
                        }
                        if (s.random() > 0.7) {
                            c.add(s.add.rectangle(bx, -bh * 0.4, 2, 2, 0xaa7733, 0.25));
                        }
                    }
                },
                // Industrial ruin
                (c, s) => {
                    c.add(s.add.rectangle(0, -12, 30, 24, 0x141218, 0.6));
                    c.add(s.add.rectangle(-12, -28, 4, 16, 0x1a1820, 0.7));
                    c.add(s.add.rectangle(8, -32, 3, 20, 0x1a1820, 0.7));
                    c.add(s.add.ellipse(8, -42, 8, 4, 0x332828, 0.3));
                    c.add(s.add.ellipse(18, -6, 14, 12, 0x161420, 0.5));
                }
            ]
        };
        
        // Special landmark: THE CUBE CRASH — appears once in apocalyptic zones
        let cubePlaced = false;
        
        for (let i = 0; i < silCount; i++) {
            const hx = i * silSpacing - 1000;
            // Get biome at world-space position (inverse of 0.1x parallax)
            const worldX = hx / 10;
            let biome = 'barren';
            let minDist = Infinity;
            for (const n of Object.values(this.nodes)) {
                if (!n.biome) continue;
                const d = Math.abs(n.x - worldX);
                if (d < minDist) { minDist = d; biome = n.biome; }
            }
            
            const container = this.add.container(hx, horizonY);
            container.baseX = hx;
            
            // Place cube crash site in apocalyptic zone (once)
            if (!cubePlaced && biome === 'apocalyptic' && this.random() < 0.15) {
                cubePlaced = true;
                // The Cube — massive tilted monolith embedded in the ground
                const cubeSize = 30 + this.random() * 15;
                const tilt = (this.random() - 0.5) * 15;
                // Impact crater glow
                container.add(this.add.ellipse(0, 4, cubeSize * 2.5, cubeSize * 0.6, 0x4a2266, 0.15));
                container.add(this.add.ellipse(0, 2, cubeSize * 1.5, cubeSize * 0.35, 0x6633aa, 0.1));
                // Cube body — dark with purple edge glow
                const cubeBody = this.add.rectangle(0, -cubeSize * 0.6, cubeSize, cubeSize, 0x0a0812, 0.85);
                cubeBody.setAngle(tilt);
                container.add(cubeBody);
                // Cube edge highlights
                const cubeEdge = this.add.rectangle(0, -cubeSize * 0.6, cubeSize + 2, cubeSize + 2, 0x6633aa, 0.2);
                cubeEdge.setAngle(tilt);
                container.add(cubeEdge);
                // Debris ring
                for (let d = 0; d < 5; d++) {
                    const dx = (this.random() - 0.5) * cubeSize * 2;
                    container.add(this.add.rectangle(dx, 2 + this.random() * 4, 3 + this.random() * 4, 2, 0x1a1220, 0.4));
                }
            } else {
                // Normal biome silhouette
                const builders = silBuilders[biome] || silBuilders.barren;
                const builder = builders[Math.floor(this.random() * builders.length)];
                builder(container, this);
            }
            
            this.farSceneryLayer.add(container);
            this._bgSilhouettes.push(container);
        }
        
        // === MID-FAR SCENERY (0.3x parallax) — GROUPED COMPOSITIONS ===
        this._midFarScenery = [];
        
        // At 0.3x parallax, need ~3.3x map width coverage but CAP to prevent lag
        const midFarExtent = mapW * 3.5 + 1000;
        const midFarCount = Math.min(25, Math.ceil(midFarExtent / 320));
        
        // Composition templates per biome — detailed structures (NOT shadows)
        // Cities/skylines only appear in the far back layer (0.1x), not here
        const midFarCompositions = {
            grassy: [
                // Farmstead cluster: barn + silo + fence (solid colors)
                (c, s) => {
                    const bh = 8+s.random()*5, bw = 12+s.random()*4;
                    c.add(s.add.rectangle(-8, -bh/2, bw, bh, 0x6a4a3a)); // barn body
                    c.add(s.add.rectangle(-8, -bh-1, bw+2, 3, 0x7a5a45)); // roof
                    c.add(s.add.rectangle(-8, -bh-2, bw-2, 1, 0x8a6a55)); // roof ridge
                    c.add(s.add.rectangle(-8, 0, 4, 3, 0x3a2a1a)); // door
                    c.add(s.add.rectangle(10, -14, 5, 16, 0x6a6a62)); // silo
                    c.add(s.add.ellipse(10, -22, 6, 4, 0x7a7a72)); // silo cap
                    c.add(s.add.rectangle(10, -6, 4, 2, 0x555550)); // silo band
                    c.add(s.add.rectangle(0, 3, 44, 1, 0x5a5040)); // fence line
                    for (let f = -18; f <= 18; f += 8) c.add(s.add.rectangle(f, 1, 1, 5, 0x5a5040)); // fence posts
                },
                // Tree line: natural cluster with detail
                (c, s) => {
                    for (let t = 0; t < 3+Math.floor(s.random()*2); t++) {
                        const tx = (t-1.5)*14 + s.random()*6;
                        const th = 10+s.random()*10;
                        c.add(s.add.rectangle(tx, 2, 3, 6, 0x5a3a1a)); // trunk
                        c.add(s.add.ellipse(tx, -th/2, 10+s.random()*5, th, 0x3a6a32)); // canopy
                        c.add(s.add.ellipse(tx-2, -th/2-2, 6, th*0.6, 0x4a7a42, 0.4)); // highlight
                    }
                },
                // Cottage: house + garden
                (c, s) => {
                    c.add(s.add.rectangle(0, -5, 16, 10, 0x7a7568)); // walls
                    c.add(s.add.rectangle(0, -5, 14, 8, 0x8a8578)); // front face
                    c.add(s.add.rectangle(0, -11, 18, 3, 0x7a5a4a)); // roof
                    c.add(s.add.rectangle(0, -12, 16, 1, 0x8a6a5a)); // ridge
                    c.add(s.add.rectangle(0, -4, 3, 5, 0x4a3a2a)); // door
                    c.add(s.add.rectangle(-4, -6, 2, 2, 0x5a7a8a, 0.5)); // window
                    c.add(s.add.rectangle(4, -6, 2, 2, 0x5a7a8a, 0.5)); // window
                    c.add(s.add.ellipse(-12, 0, 8, 5, 0x3a5a32)); // bush
                    c.add(s.add.ellipse(12, 0, 6, 4, 0x3a5a32)); // bush
                }
            ],
            barren: [
                // Abandoned outpost: shack + pole
                (c, s) => {
                    c.add(s.add.rectangle(0, -5, 12, 10, 0x6a6055)); // shack
                    c.add(s.add.rectangle(0, -5, 10, 8, 0x7a7065)); // front
                    c.add(s.add.rectangle(0, -11, 14, 3, 0x7a6a5a)); // roof
                    c.add(s.add.rectangle(16, -12, 2, 22, 0x6a6a62)); // pole
                    c.add(s.add.rectangle(16, -24, 8, 4, 0x7a7a72)); // sign
                    c.add(s.add.rectangle(16, -24, 6, 2, 0x5a5a52)); // text
                    c.add(s.add.rectangle(-12, 2, 5, 3, 0x6a5a4a)); // debris
                },
                // Rock formation: mesa + scattered stones
                (c, s) => {
                    const mw = 25+s.random()*15, mh = 12+s.random()*10;
                    c.add(s.add.polygon(0, 0, [-mw/2, 0, -mw*0.35, -mh, mw*0.35, -mh, mw/2, 0], 0x5a5045));
                    c.add(s.add.rectangle(0, -mh, mw*0.6, 2, 0x6a6055)); // flat top
                    c.add(s.add.rectangle(0, -mh*0.5, 1, mh*0.3, 0x4a4035, 0.3)); // crack
                    for (let r = 0; r < 2; r++) {
                        const rx = (s.random()-0.5)*mw*0.8;
                        c.add(s.add.ellipse(rx, 3, 5+s.random()*4, 3, 0x5a5548));
                    }
                },
                // Crater + wreckage
                (c, s) => {
                    const cw = 22+s.random()*12;
                    c.add(s.add.ellipse(0, 2, cw+4, cw*0.25, 0x5a5a50)); // rim
                    c.add(s.add.ellipse(0, 2, cw*0.7, cw*0.15, 0x2a2a28)); // hole
                    c.add(s.add.rectangle(cw/2+4, -3, 3, 7, 0x5a5540)); // pole
                }
            ],
            apocalyptic: [
                // Wrecked outpost (NOT a city — detailed ground-level ruin)
                (c, s) => {
                    c.add(s.add.rectangle(0, -4, 22, 8, 0x3a3535)); // rubble base
                    c.add(s.add.rectangle(-6, -10, 10, 10, 0x4a4242)); // standing wall
                    c.add(s.add.rectangle(-6, -10, 8, 8, 0x504848)); // wall face
                    c.add(s.add.rectangle(-6, -6, 2, 2, 0x332828)); // window hole
                    c.add(s.add.rectangle(8, -2, 8, 4, 0x3a3232).setAngle(12)); // fallen beam
                    c.add(s.add.rectangle(-14, 0, 4, 3, 0x3a3535)); // debris
                },
                // Communication tower + shed
                (c, s) => {
                    c.add(s.add.rectangle(0, -6, 18, 12, 0x4a4a5a)); // building
                    c.add(s.add.rectangle(0, -6, 16, 10, 0x5a5a6a)); // front face
                    c.add(s.add.rectangle(0, -13, 20, 3, 0x5a5a6a)); // roof
                    c.add(s.add.rectangle(12, -20, 2, 20, 0x6a6a7a)); // tower
                    c.add(s.add.circle(12, -22, 1, s.random()>0.5 ? 0x44ff44 : 0xff4444, 0.7)); // light
                    c.add(s.add.rectangle(-10, -2, 8, 6, 0x3a3a42)); // annex
                },
                // Barricade + sandbags
                (c, s) => {
                    for (let b = -10; b <= 10; b += 6) {
                        c.add(s.add.rectangle(b, 0, 5, 4, 0x5a5a48));
                        c.add(s.add.rectangle(b, -1, 4, 2, 0x6a6a58));
                    }
                    c.add(s.add.rectangle(0, -5, 2, 8, 0x5a5a5a)); // post
                    c.add(s.add.rectangle(0, -8, 10, 2, 0x5a5a5a)); // crossbar
                }
            ]
        };
        
        for (let i = 0; i < midFarCount; i++) {
            const hx = i * 320 - 500;
            // Use nearest node's biome at the world-space position this parallax prop appears at
            const worldX = hx / 3.3; // inverse of 0.3x parallax scroll
            let biome = 'barren';
            let minDist = Infinity;
            for (const n of Object.values(this.nodes)) {
                if (!n.biome) continue;
                const d = Math.abs(n.x - worldX);
                if (d < minDist) { minDist = d; biome = n.biome; }
            }
            const container = this.add.container(hx, horizonY + 12);
            container.baseX = hx;
            
            const compositions = midFarCompositions[biome] || midFarCompositions.barren;
            const comp = compositions[Math.floor(this.random() * compositions.length)];
            comp(container, this);
            
            this.midSceneryLayer.add(container);
            this._midFarScenery.push(container);
        }
    }
    getBiomeAtX(x) {
        const nearbyNodes = Object.values(this.nodes).filter(n => Math.abs(n.x - x) < this.nodeSpacing * 2);
        const counts = { grassy: 0, barren: 0, apocalyptic: 0 };
        nearbyNodes.forEach(n => { if (n.biome) counts[n.biome]++; });
        if (counts.apocalyptic >= counts.barren && counts.apocalyptic >= counts.grassy) return 'apocalyptic';
        if (counts.barren >= counts.grassy) return 'barren';
        return 'grassy';
    }
    
    generateRouteMap() {
        // Build linear map from locked CRT route
        const ar = this.activeRoute;
        const reachData = RouteGenerator.generateReach(ar.seed, ar.reach, ar.biome);
        
        const nodeTypes = {
            safehouse: { icon: '🏠', name: 'Safehouse', color: 0x44aa44 },
            haven: { icon: '🏕', name: 'Safe Haven', color: 0x4488cc },
            defense: { icon: '🛡', name: 'Defense', color: 0xcc8844 },
            boss: { icon: '💀', name: 'Boss Gate', color: 0xcc2244 }
        };
        
        const roadY = CONFIG.height - 180;
        const startX = 100;
        
        // Place route nodes linearly
        let cumX = startX;
        ar.nodes.forEach((nId, i) => {
            const srcNode = reachData.nodes[nId];
            if (!srcNode) return;
            
            const nt = nodeTypes[srcNode.type] || nodeTypes.defense;
            const yJitter = (i > 0 && i < ar.nodes.length - 1) ? (Math.sin(i * 2.7) * 40) : 0;
            
            this.nodes[nId] = {
                id: nId,
                type: srcNode.type,
                icon: nt.icon,
                name: srcNode.name,
                color: nt.color,
                x: cumX,
                y: roadY + yJitter,
                col: i,
                reach: ar.reach,
                biome: srcNode.biome || ar.biome,
                fuel: (i > 0 && ar.edges[i - 1]) ? ar.edges[i - 1].fuel : 0,
                difficulty: srcNode.difficulty || 'normal',
                timeOfDay: srcNode.timeOfDay || 'midday',
                discovered: true,
                completed: i < ar.currentStep || this.completedNodes.includes(nId),
                locationType: srcNode.locationType || null,
                hasStoryEvent: srcNode.hasStoryEvent || false,
                bossEntityType: srcNode.bossEntityType || null,
                isBossGate: srcNode.type === 'boss',
                routeIndex: i,
                encounters: (i > 0 && ar.edges[i - 1]) ? ar.edges[i - 1].encounters : []
            };
            
            // Connect to previous
            if (i > 0) {
                this.connections.push({ from: ar.nodes[i - 1], to: nId });
            }
            
            // Spacing based on fuel cost of next edge
            if (i < ar.edges.length) {
                cumX += 80 + ar.edges[i].fuel * 12;
            } else {
                cumX += this.nodeSpacing;
            }
        });
        
        // Set current node to route step
        this.currentNodeId = ar.nodes[ar.currentStep] || ar.nodes[0];
        
        // Store reach bounds for scenery
        this.reachBounds = {};
        this.reachBounds[ar.reach] = {
            minX: startX,
            maxX: cumX
        };
    }
    
    generateMap() {
        // Node types with their properties
        const nodeTypes = {
            safehouse: { icon: '🏠', name: 'Safehouse', color: 0x44aa44 },
            haven: { icon: '🏕', name: 'Safe Haven', color: 0x4488cc },
            defense: { icon: '🛡', name: 'Defense', color: 0xcc8844 },
            boss: { icon: '💀', name: 'Boss Gate', color: 0xcc2244 }
        };
        
        // Biome per reach — player's chosen biome with occasional bleed from other biomes
        const playerBiome = this.saveData?.biome || 'grassy';
        const otherBiomes = ['grassy', 'barren', 'apocalyptic'].filter(b => b !== playerBiome);
        const getBiomeForReach = (reach) => {
            // 80% player's chosen biome, 20% random bleed for world variety
            if (this.random() < 0.8) return playerBiome;
            return otherBiomes[Math.floor(this.random() * otherBiomes.length)];
        };
        
        // Difficulty scaling by reach
        const getDifficultyForReach = (reach, posInReach) => {
            const base = reach - 1;
            const diffs = ['Normal', 'Hard', 'Extreme', 'Deadly'];
            let idx = Math.min(3, base + (posInReach > 0.7 ? 1 : 0));
            if (this.random() < 0.3 && idx > 0) idx--;
            if (this.random() < 0.15 && idx < 3) idx++;
            return diffs[idx];
        };
        
        // Node type pools
        const reachNodePool = {
            early: [{ type: 'defense', weight: 100 }],
            mid: [{ type: 'defense', weight: 100 }],
            late: [{ type: 'defense', weight: 100 }]
        };
        
        const pickNodeType = (pool) => {
            const total = pool.reduce((s, e) => s + e.weight, 0);
            let roll = this.random() * total;
            for (const entry of pool) {
                roll -= entry.weight;
                if (roll <= 0) return entry.type;
            }
            return 'scavenge';
        };
        
        // Pick a location type based on biome weights
        const pickLocationType = (biome) => {
            const locs = CONFIG.locations;
            const entries = Object.entries(locs).filter(([k, v]) => v.category === 'scavenge' && v.biomeWeight[biome] > 0);
            const total = entries.reduce((s, [k, v]) => s + (v.biomeWeight[biome] || 0), 0);
            let roll = this.random() * total;
            for (const [key, loc] of entries) {
                roll -= (loc.biomeWeight[biome] || 0);
                if (roll <= 0) return key;
            }
            return 'house';
        };
        
        // Generate a unique name for a location
        const generateLocationName = (locationType) => {
            const loc = CONFIG.locations[locationType];
            if (!loc || !loc.names) return locationType;
            const prefix = loc.names.prefixes[this.randomInt(0, loc.names.prefixes.length - 1)];
            const suffix = loc.names.suffixes[this.randomInt(0, loc.names.suffixes.length - 1)];
            return `${prefix} ${suffix}`;
        };
        
        const timesOfDay = ['dawn', 'midday', 'dusk', 'night'];
        const startTimeIndex = this.randomInt(0, 3);
        CONFIG.timeOfDay = timesOfDay[startTimeIndex];
        this.timeOfDay = CONFIG.timeOfDay;
        
        const totalReaches = 2; // Start with 2, generate more on demand
        
        // Road Y position (center of play area, below sky)
        const roadY = CONFIG.height - 180;
        const laneSpread = 70; // Vertical spread for node lanes
        
        // SIDE-SCROLLING: Safehouse on the LEFT, progress to the RIGHT
        const startX = 100;
        
        this._genState = { globalCol: 0, nodeId: 0, startX, roadY, nodeSpacing: this.nodeSpacing, startTimeIndex, laneSpread, timesOfDay, nodeTypes, pickNodeType, pickLocationType, generateLocationName, getDifficultyForReach, nextReach: 3 };
        
        this.nodes['safehouse'] = {
            id: 'safehouse',
            type: 'safehouse',
            ...nodeTypes.safehouse,
            x: startX,
            y: roadY,
            col: 0,
            reach: 0,
            biome: 'grassy',
            timeOfDay: timesOfDay[startTimeIndex],
            fuel: 0,
            discovered: true,
            completed: true
        };
        
        let nodeId = 1;
        let globalCol = 0;
        
        for (let reach = 1; reach <= totalReaches; reach++) {
            const colsInReach = 6;
            const reachBiome = getBiomeForReach(reach);
            
            // Haven column (first column of each reach after reach 1)
            if (reach > 1) {
                globalCol++;
                const havenId = `haven_reach${reach}`;
                this.nodes[havenId] = {
                    id: havenId,
                    type: 'haven',
                    ...nodeTypes.haven,
                    x: startX + globalCol * this.nodeSpacing,
                    y: roadY,
                    col: globalCol,
                    reach: reach,
                    biome: reachBiome,
                    timeOfDay: timesOfDay[(startTimeIndex + globalCol) % 4],
                    fuel: this.randomInt(3, 8),
                    difficulty: 'None',
                    discovered: false,
                    completed: false,
                    isHaven: true
                };
                
                // Connect from previous column
                const prevColNodes = Object.values(this.nodes).filter(n => n.col === globalCol - 1).map(n => n.id);
                prevColNodes.forEach(prevId => {
                    this.connections.push({ from: prevId, to: havenId });
                });
            }
            
            // Regular columns
            for (let c = 0; c < colsInReach; c++) {
                globalCol++;
                const posInReach = c / colsInReach;
                const pool = posInReach < 0.33 ? reachNodePool.early :
                             posInReach < 0.66 ? reachNodePool.mid : reachNodePool.late;
                
                const nodesInCol = this.randomInt(2, 3);
                const colNodes = [];
                
                // Distribute nodes vertically (different lanes)
                for (let i = 0; i < nodesInCol; i++) {
                    const laneOffset = (i - (nodesInCol - 1) / 2) * (laneSpread / Math.max(1, nodesInCol - 1));
                    const x = startX + globalCol * this.nodeSpacing + this.randomInt(-10, 10);
                    const y = roadY + laneOffset + this.randomInt(-8, 8);
                    
                    const type = pickNodeType(pool);
                    const difficulty = getDifficultyForReach(reach, posInReach);
                    
                    const id = `node_${nodeId++}`;
                    // 15% chance for a cross-biome node
                    const biomes = ['grassy', 'barren', 'apocalyptic'];
                    const nodeBiome = this.random() < 0.15 ? biomes[this.randomInt(0, 2)] : reachBiome;
                    
                    // Assign location type and name for scavenge nodes
                    let locationType = null, locationName = null, hasStoryEvent = false;
                    if (type === 'defense') {
                        locationType = pickLocationType(nodeBiome);
                        locationName = generateLocationName(locationType);
                        const loc = CONFIG.locations[locationType];
                        if (loc && this.random() < (loc.storyChance || 0)) {
                            hasStoryEvent = true;
                        }
                    }
                    
                    this.nodes[id] = {
                        id: id,
                        type: type,
                        ...nodeTypes[type],
                        name: locationName || nodeTypes[type].name,
                        locationType: locationType,
                        hasStoryEvent: hasStoryEvent,
                        x: x,
                        y: y,
                        col: globalCol,
                        reach: reach,
                        biome: nodeBiome,
                        fuel: this.randomInt(5, 15) + reach * 2,
                        difficulty: difficulty,
                        timeOfDay: timesOfDay[(startTimeIndex + globalCol) % 4],
                        discovered: false,
                        completed: false
                    };
                    colNodes.push(id);
                }
                
                // Connections — every node in prev column connects to all in this column
                const prevColNodes = Object.values(this.nodes).filter(n => n.col === globalCol - 1).map(n => n.id);
                
                if (prevColNodes.length && colNodes.length) {
                    prevColNodes.forEach(prevId => {
                        colNodes.forEach(nextId => {
                            this.connections.push({ from: prevId, to: nextId });
                        });
                    });
                }
            }
            
            // Boss gate column — single forced node
            globalCol++;
            const bossType = 'boss';
            const bossId = `boss_reach${reach}`;
            const bossNames = ['The Hollow', 'The Swarm Mother', 'Cube Phantom', 'Iron Revenant', 'Void Tesseract'];
            const bossEntityTypes = ['warden', 'swarmQueen', 'phantom', 'ironclad', 'cubeAnomaly'];
            const bossEntityType = bossEntityTypes[(reach - 1) % 5];
            this.nodes[bossId] = {
                id: bossId,
                type: bossType,
                ...nodeTypes[bossType],
                name: bossNames[(reach - 1) % 5] || 'Boss Gate',
                bossEntityType: bossEntityType,
                x: startX + globalCol * this.nodeSpacing,
                y: roadY,
                col: globalCol,
                reach: reach,
                biome: reachBiome,
                fuel: 0,
                difficulty: getDifficultyForReach(reach, 1.0),
                timeOfDay: timesOfDay[(startTimeIndex + globalCol) % 4],
                discovered: false,
                completed: false,
                isBossGate: true
            };
            
            // All nodes in previous column connect to boss
            const prevColNodes = Object.values(this.nodes).filter(n => n.col === globalCol - 1).map(n => n.id);
            prevColNodes.forEach(prevId => {
                this.connections.push({ from: prevId, to: bossId });
            });
        }
        
        // Save generation state for infinite extension
        this._genState.globalCol = globalCol;
        this._genState.nodeId = nodeId;
        
        // === FUEL-BASED SPACING — adjust X positions so fuel cost maps to visual distance ===
        // Group connections and shift target nodes based on their fuel cost
        const fuelScale = 8; // pixels per fuel unit
        const baseSpacing = this.nodeSpacing;
        let cumulativeX = startX;
        const processedCols = new Set();
        
        // Sort all nodes by column
        const nodesByCol = {};
        Object.values(this.nodes).forEach(n => {
            if (!nodesByCol[n.col]) nodesByCol[n.col] = [];
            nodesByCol[n.col].push(n);
        });
        
        const maxCol = Math.max(...Object.keys(nodesByCol).map(Number));
        for (let col = 0; col <= maxCol; col++) {
            const nodesInCol = nodesByCol[col];
            if (!nodesInCol) continue;
            
            // Find max fuel cost among nodes in this column
            const maxFuel = Math.max(...nodesInCol.map(n => n.fuel || 0));
            const spacing = Math.max(baseSpacing * 0.6, baseSpacing * 0.5 + maxFuel * fuelScale);
            
            if (col > 0) cumulativeX += spacing;
            
            nodesInCol.forEach(n => {
                n.x = cumulativeX + this.randomInt(-8, 8);
            });
        }
        
        // Store total width and per-reach boundaries for scroll clamping
        this.mapWidth = cumulativeX + baseSpacing * 2;
        this.reachBounds = {};
        Object.values(this.nodes).forEach(n => {
            const r = n.reach || 1;
            if (!this.reachBounds[r]) this.reachBounds[r] = { minX: Infinity, maxX: -Infinity };
            this.reachBounds[r].minX = Math.min(this.reachBounds[r].minX, n.x);
            this.reachBounds[r].maxX = Math.max(this.reachBounds[r].maxX, n.x);
        });
        
        // Mark nodes connected to current as discovered
        this.updateDiscovery();
    }
    
    updateDiscovery() {
        // Get connected nodes from current position
        const currentNode = this.nodes[this.currentNodeId];
        
        // Mark immediate connections as fully discovered
        this.connections.forEach(conn => {
            if (conn.from === this.currentNodeId) {
                this.nodes[conn.to].discovered = true;
            }
        });
        
        // Mark nodes 2 steps away as partially visible
        const immediateNodes = this.connections
            .filter(c => c.from === this.currentNodeId)
            .map(c => c.to);
        
        immediateNodes.forEach(nodeId => {
            this.connections.forEach(conn => {
                if (conn.from === nodeId && this.nodes[conn.to]) {
                    this.nodes[conn.to].partiallyVisible = true;
                }
            });
        });
    }
    
    generateNextReach() {
        // Dynamically generate the next reach and append to the map
        const gs = this._genState;
        if (!gs) return;
        
        const reach = gs.nextReach;
        gs.nextReach++;
        
        let globalCol = gs.globalCol;
        let nodeId = gs.nodeId;
        const { startX, roadY, nodeSpacing, startTimeIndex, laneSpread, timesOfDay, nodeTypes, pickNodeType, pickLocationType, generateLocationName, getDifficultyForReach } = gs;
        
        const biomes = ['grassy', 'barren', 'apocalyptic'];
        const reachBiome = biomes[(reach - 1) % biomes.length];
        const colsInReach = 6;
        
        const reachNodePool = {
            early: [{ type: 'defense', weight: 100 }],
            mid: [{ type: 'defense', weight: 100 }],
            late: [{ type: 'defense', weight: 100 }]
        };
        
        // Haven
        globalCol++;
        const havenId = `haven_reach${reach}`;
        this.nodes[havenId] = {
            id: havenId, type: 'haven', ...nodeTypes.haven,
            x: 0, y: roadY, col: globalCol, reach, biome: reachBiome,
            timeOfDay: timesOfDay[(startTimeIndex + globalCol) % 4],
            fuel: this.randomInt(3, 8), difficulty: 'None', discovered: false, completed: false, isHaven: true
        };
        const prevBossNodes = Object.values(this.nodes).filter(n => n.col === globalCol - 1).map(n => n.id);
        prevBossNodes.forEach(prevId => this.connections.push({ from: prevId, to: havenId }));
        
        // Regular columns
        for (let c = 0; c < colsInReach; c++) {
            globalCol++;
            const posInReach = c / colsInReach;
            const pool = posInReach < 0.33 ? reachNodePool.early : posInReach < 0.66 ? reachNodePool.mid : reachNodePool.late;
            const nodesInCol = this.randomInt(2, 3);
            const colNodes = [];
            
            for (let i = 0; i < nodesInCol; i++) {
                const laneOffset = (i - (nodesInCol - 1) / 2) * (laneSpread / Math.max(1, nodesInCol - 1));
                const x = 0; // will be set by fuel spacing
                const y = roadY + laneOffset + this.randomInt(-8, 8);
                const type = pickNodeType(pool);
                const difficulty = getDifficultyForReach(reach, posInReach);
                const id = `node_${nodeId++}`;
                const nodeBiome = this.random() < 0.15 ? biomes[this.randomInt(0, 2)] : reachBiome;
                
                let locationType = null, locationName = null, hasStoryEvent = false;
                if (type === 'defense') {
                    locationType = pickLocationType(nodeBiome);
                    locationName = generateLocationName(locationType);
                    const loc = CONFIG.locations[locationType];
                    if (loc && this.random() < (loc.storyChance || 0)) hasStoryEvent = true;
                }
                
                this.nodes[id] = {
                    id, type, ...nodeTypes[type],
                    name: locationName || nodeTypes[type].name,
                    locationType, hasStoryEvent,
                    x, y, col: globalCol, reach, biome: nodeBiome,
                    fuel: this.randomInt(5, 15) + reach * 2, difficulty,
                    timeOfDay: timesOfDay[(startTimeIndex + globalCol) % 4],
                    discovered: false, completed: false
                };
                colNodes.push(id);
            }
            
            const prevColNodes = Object.values(this.nodes).filter(n => n.col === globalCol - 1).map(n => n.id);
            if (prevColNodes.length && colNodes.length) {
                prevColNodes.forEach(prevId => colNodes.forEach(nextId => this.connections.push({ from: prevId, to: nextId })));
            }
        }
        
        // Boss gate
        globalCol++;
        const bossType = 'boss';
        const bossId = `boss_reach${reach}`;
        const bossNames = ['The Hollow', 'The Swarm Mother', 'Cube Phantom', 'Iron Revenant', 'Void Tesseract'];
        const bossEntityTypes = ['warden', 'swarmQueen', 'phantom', 'ironclad', 'cubeAnomaly'];
        const bossEntityType = bossEntityTypes[(reach - 1) % 5];
        this.nodes[bossId] = {
            id: bossId, type: bossType, ...nodeTypes[bossType],
            name: bossNames[(reach - 1) % 5] || 'Boss Gate',
            bossEntityType, x: 0, y: roadY, col: globalCol, reach, biome: reachBiome,
            fuel: 0, difficulty: getDifficultyForReach(reach, 1.0),
            timeOfDay: timesOfDay[(startTimeIndex + globalCol) % 4],
            discovered: false, completed: false, isBossGate: true
        };
        const bpn = Object.values(this.nodes).filter(n => n.col === globalCol - 1).map(n => n.id);
        bpn.forEach(prevId => this.connections.push({ from: prevId, to: bossId }));
        
        // Update gen state
        gs.globalCol = globalCol;
        gs.nodeId = nodeId;
        
        // Recompute fuel-based spacing for ALL nodes
        const fuelScale = 8;
        const baseSpacing = this.nodeSpacing;
        let cumulativeX = 0;
        const nodesByCol = {};
        Object.values(this.nodes).forEach(n => {
            if (!nodesByCol[n.col]) nodesByCol[n.col] = [];
            nodesByCol[n.col].push(n);
        });
        const maxCol = Math.max(...Object.keys(nodesByCol).map(Number));
        for (let col = 0; col <= maxCol; col++) {
            const nc = nodesByCol[col];
            if (!nc) continue;
            const maxFuel = Math.max(...nc.map(n => n.fuel || 0));
            const spacing = Math.max(baseSpacing * 0.6, baseSpacing * 0.5 + maxFuel * fuelScale);
            if (col > 0) cumulativeX += spacing;
            nc.forEach(n => { n.x = cumulativeX + this.randomInt(-8, 8); });
        }
        
        this.mapWidth = cumulativeX + baseSpacing * 2;
        this.reachBounds = {};
        Object.values(this.nodes).forEach(n => {
            const r = n.reach || 1;
            if (!this.reachBounds[r]) this.reachBounds[r] = { minX: Infinity, maxX: -Infinity };
            this.reachBounds[r].minX = Math.min(this.reachBounds[r].minX, n.x);
            this.reachBounds[r].maxX = Math.max(this.reachBounds[r].maxX, n.x);
        });
        
        // Rebuild visuals for new nodes
        Object.values(this.nodes).forEach(node => {
            if (!this.nodeVisuals[node.id]) {
                this.createNodeVisual(node);
            }
        });
        
        this.updateDiscovery();
        this.redrawConnections();
    }
    
    createScenery() {
        const roadY = CONFIG.height - 180;
        
        // === BUILD PATH EXCLUSION ZONES ===
        // Sample points along every connection curve so scenery doesn't block roads
        this._pathPoints = [];
        this.connections.forEach(conn => {
            const fromNode = this.nodes[conn.from];
            const toNode = this.nodes[conn.to];
            if (!fromNode || !toNode) return;
            const fromX = fromNode.x, fromY = fromNode.y;
            const toX = toNode.x, toY = toNode.y;
            const dx = toX - fromX, dy = toY - fromY;
            const seed = (fromNode.col * 73 + (fromNode.y|0) * 37 + toNode.col * 17) % 100;
            const curveAmt = ((seed / 100) - 0.5) * 40;
            // Sample 20 points along the curve for fine-grained exclusion
            for (let i = 0; i <= 20; i++) {
                const t = i / 20;
                this._pathPoints.push({
                    x: fromX + dx * t + curveAmt * Math.sin(t * Math.PI),
                    y: fromY + dy * t + curveAmt * Math.sin(t * Math.PI) * 0.5
                });
            }
        });
        
        // === GOAL 1: BIOME-SPECIFIC TERRAIN AROUND EACH NODE ===
        // If a node's biome differs from surrounding nodes, surround it with its own biome props
        this._midGround = [];
        this._nearScenery = [];
        this._nodeBiomeIslands = [];
        this._groundDetails = [];
        
        Object.values(this.nodes).forEach(node => {
            if (!node.biome || node.type === 'safehouse') return;
            const biome = node.biome;
            const nx = node.x;
            const ny = node.y;
            
            // Check if this node's biome differs from the local area
            const localBiome = this.getBiomeAtX(nx);
            const isIslandBiome = (biome !== localBiome);
            
            // If it's an island biome, draw a biome transition zone around the node
            if (isIslandBiome) {
                this._createBiomeIsland(nx, ny, biome, roadY);
            }
            
            // Place trees/structures per node — density decreases with distance from safehouse
            const safehouseX = this.nodes['safehouse'] ? this.nodes['safehouse'].x : 0;
            const distFromStart = Math.abs(nx - safehouseX);
            const densityFactor = Math.max(0.4, 1.0 - distFromStart / 3000); // 100% at start → 40% at far end
            const baseTreeCount = 3 + Math.floor(this.random() * 4); // 3-6 base
            const treeCount = Math.max(2, Math.round(baseTreeCount * densityFactor));
            for (let i = 0; i < treeCount; i++) {
                // Distribute evenly around the node — alternate sides, stagger depth
                const angle = (i / treeCount) * Math.PI * 2 + this.random() * 0.5;
                const dist = 45 + this.random() * 35;
                const x = nx + Math.cos(angle) * dist;
                const y = ny + Math.sin(angle) * dist * 0.4; // Compress Y for ¾ perspective
                
                // Clamp to reasonable screen area
                if (y < roadY - 80 || y > roadY + 60) continue;
                
                // Skip if too close to a connection path
                let onPath = false;
                for (const pp of this._pathPoints) {
                    const pdx = pp.x - x, pdy = pp.y - y;
                    if (pdx * pdx + pdy * pdy < 1600) { onPath = true; break; } // 40px radius
                }
                if (onPath) continue;
                
                const container = this.add.container(x, y);
                container.baseX = x;
                
                if (biome === 'grassy') {
                    const roll = this.random();
                    if (roll < 0.4) this.createIsoTree(container);
                    else if (roll < 0.6) this.createIsoBush(container);
                    else if (roll < 0.8) this.createIsoFencePost(container);
                    else this.createIsoBush(container);
                } else if (biome === 'barren') {
                    const roll = this.random();
                    if (roll < 0.3) this.createIsoDeadTree(container);
                    else if (roll < 0.55) this.createIsoRock(container);
                    else if (roll < 0.75) this.createIsoCactus(container);
                    else this._createIsoSandDrift(container);
                } else {
                    const roll = this.random();
                    if (roll < 0.3) this.createIsoRuin(container);
                    else if (roll < 0.5) this.createIsoPole(container);
                    else if (roll < 0.7) this.createIsoRubble(container);
                    else if (roll < 0.85) this._createIsoBarricade(container);
                    else this._createIsoBrokenWall(container);
                }
                
                this.midSceneryLayer.add(container);
                this._midGround.push(container);
            }
        });
        
        // === GOAL 2: EVENLY PLACED GROUND DETAILS ===
        // Density decreases with distance from safehouse
        const detailSpacing = 45; // Tighter spacing for more detail
        const mapW = this.mapWidth || 5000;
        const safehouseXForDetails = this.nodes['safehouse'] ? this.nodes['safehouse'].x : 0;
        
        for (let gx = -100; gx < mapW + 100; gx += detailSpacing) {
            // Distance-based density: more props near start, fewer further out
            const distFactor = Math.max(0.3, 1.0 - Math.abs(gx - safehouseXForDetails) / 3500);
            const baseCount = 2 + Math.floor(this.random() * 3); // 2-4 base
            const detailCount = Math.max(1, Math.round(baseCount * distFactor));
            for (let d = 0; d < detailCount; d++) {
                const x = gx + (this.random() - 0.5) * detailSpacing * 0.7;
                const ySlot = d / detailCount;
                const y = roadY - 30 + ySlot * 60 + (this.random() - 0.5) * 15;
                
                // Skip if too close to a node (don't clutter node area)
                let tooCloseToNode = false;
                for (const n of Object.values(this.nodes)) {
                    const dx = n.x - x, dy = n.y - y;
                    if (dx * dx + dy * dy < 2500) { tooCloseToNode = true; break; }
                }
                if (tooCloseToNode) continue;
                
                // Skip if on a connection path
                let onPath = false;
                for (const pp of this._pathPoints) {
                    const pdx = pp.x - x, pdy = pp.y - y;
                    if (pdx * pdx + pdy * pdy < 1200) { onPath = true; break; }
                }
                if (onPath) continue;
                
                const biome = this.getBiomeAtX(x);
                const container = this.add.container(x, y);
                container.baseX = x;
                
                // Rich variety of small biome-appropriate details
                if (biome === 'grassy') {
                    const roll = this.random();
                    if (roll < 0.25) this.createGrassTuft(container);
                    else if (roll < 0.4) this.createGrassTuft(container);
                    else if (roll < 0.55) this.createMushroomPatch(container);
                    else if (roll < 0.7) this.createFallenLog(container);
                    else if (roll < 0.82) this.createSmallAnimal(container, 'rabbit');
                    else if (roll < 0.92) this.createSmallAnimal(container, 'bird');
                    else this._createSmallPuddle(container);
                } else if (biome === 'barren') {
                    const roll = this.random();
                    if (roll < 0.2) this.createSmallRock(container);
                    else if (roll < 0.35) this.createDeadBush(container);
                    else if (roll < 0.5) this.createTumbleweed(container);
                    else if (roll < 0.65) this.createBleachedBones(container);
                    else if (roll < 0.75) this.createDirtPatch(container);
                    else if (roll < 0.85) this.createSnake(container);
                    else this._createDryCracks(container);
                } else {
                    const roll = this.random();
                    if (roll < 0.18) this.createDebrisPile(container);
                    else if (roll < 0.32) this.createScrapMetal(container);
                    else if (roll < 0.45) this.createBrokenGlass(container);
                    else if (roll < 0.55) this.createOilStain(container);
                    else if (roll < 0.65) this.createSkull(container);
                    else if (roll < 0.75) this.createCrow(container);
                    else if (roll < 0.85) this.createRadiationSign(container);
                    else if (roll < 0.93) this.createSmallAnimal(container, 'rat');
                    else this._createRebar(container);
                }
                
                this.bgLayer.add(container);
                this._groundDetails.push(container);
            }
        }
        
        // === NEAR-ROAD SCENERY (foreground, 1x) ===
        // Roadside objects that pass in front at ground level
        for (let rx = 0; rx < mapW; rx += 140 + this.random() * 80) {
            const biome = this.getBiomeAtX(rx);
            const side = this.random() > 0.5 ? 1 : -1;
            const x = rx + (this.random() - 0.5) * 40;
            const y = roadY + side * (55 + this.random() * 25);
            
            // Skip if near node
            let nearNode = false;
            for (const n of Object.values(this.nodes)) {
                if (Math.abs(n.x - x) < 70 && Math.abs(n.y - y) < 45) { nearNode = true; break; }
            }
            if (nearNode) continue;
            
            // Skip if on a connection path
            let onPath = false;
            for (const pp of this._pathPoints) {
                const pdx = pp.x - x, pdy = pp.y - y;
                if (pdx * pdx + pdy * pdy < 1200) { onPath = true; break; } // ~35px radius
            }
            if (onPath) continue;
            
            const container = this.add.container(x, y);
            container.baseX = x;
            
            const roll = this.random();
            if (biome === 'grassy') {
                if (roll < 0.35) this.createIsoTree(container);
                else if (roll < 0.55) this.createIsoBush(container);
                else this.createWornSign(container);
            } else if (biome === 'barren') {
                if (roll < 0.3) this.createIsoCactus(container);
                else if (roll < 0.55) this.createIsoRock(container, 1.2);
                else this.createWornVehicle(container);
            } else {
                if (roll < 0.3) this.createIsoRuin(container);
                else if (roll < 0.5) this.createIsoPole(container);
                else if (roll < 0.7) this.createWornVehicle(container);
                else this._createIsoBarricade(container);
            }
            
            this.nearSceneryLayer.add(container);
            this._nearScenery.push(container);
        }
    }
    
    // === BIOME ISLAND: surround an off-biome node with its own terrain ===
    _createBiomeIsland(nx, ny, biome, roadY) {
        const islandRadius = 65;
        
        // Solid ground color patch (oval under the node)
        const groundColors = {
            grassy: 0x3a4a35,
            barren: 0x4a4538,
            apocalyptic: 0x2a2828
        };
        const patch = this.add.ellipse(nx, ny + 5, islandRadius * 2, islandRadius * 0.8, groundColors[biome]);
        patch.baseX = nx;
        this.bgLayer.add(patch);
        this._groundBands.push(patch);
        
        // Place 4-6 biome-specific border props around the perimeter
        const borderCount = 4 + Math.floor(this.random() * 3);
        for (let i = 0; i < borderCount; i++) {
            const angle = (i / borderCount) * Math.PI * 2 + this.random() * 0.4;
            const dist = islandRadius * (0.7 + this.random() * 0.3);
            const px = nx + Math.cos(angle) * dist;
            const py = ny + Math.sin(angle) * dist * 0.35;
            
            // Skip if on a connection path
            let onPath = false;
            if (this._pathPoints) {
                for (const pp of this._pathPoints) {
                    const pdx = pp.x - px, pdy = pp.y - py;
                    if (pdx * pdx + pdy * pdy < 1200) { onPath = true; break; }
                }
            }
            if (onPath) continue;
            
            const c = this.add.container(px, py);
            c.baseX = px;
            
            if (biome === 'grassy') {
                this.random() < 0.5 ? this.createGrassTuft(c) : this.createIsoBush(c);
            } else if (biome === 'barren') {
                this.random() < 0.5 ? this.createSmallRock(c) : this.createDeadBush(c);
            } else {
                this.random() < 0.5 ? this.createDebrisPile(c) : this.createScrapMetal(c);
            }
            
            this.bgLayer.add(c);
            this._groundDetails.push(c);
        }
    }
    
    // === NEW SMALL DETAIL PROPS ===
    
    _createSmallPuddle(c) {
        c.add(this.add.ellipse(0, 0, 8 + this.random() * 6, 4 + this.random() * 3, 0x3a4a5a, 0.35));
        c.add(this.add.ellipse(1, -1, 3, 1.5, 0x4a5a6a, 0.2)); // reflection
    }
    
    _createDryCracks(c) {
        const g = this.add.graphics();
        g.lineStyle(1, 0x4a4538, 0.4);
        g.beginPath();
        g.moveTo(0, 0);
        g.lineTo(4 + this.random() * 4, this.random() * 3);
        g.lineTo(3, 5 + this.random() * 3);
        g.strokePath();
        g.beginPath();
        g.moveTo(0, 0);
        g.lineTo(-3 - this.random() * 3, 2 + this.random() * 2);
        g.strokePath();
        c.add(g);
    }
    
    _createRebar(c) {
        const angle = (this.random() - 0.5) * 60;
        c.add(this.add.rectangle(0, 0, 8 + this.random() * 6, 1, 0x5a4a3a, 0.6).setAngle(angle));
        if (this.random() > 0.5) {
            c.add(this.add.rectangle(2, -1, 5, 1, 0x6a3a2a, 0.5).setAngle(angle + 30));
        }
    }
    

    
    _createIsoSandDrift(c) {
        const s = 0.6 + this.random() * 0.4;
        // Low sand ridge — ¾ iso: ellipse wider than tall
        c.add(this.add.ellipse(0, 2*s, 18*s, 5*s, 0x5a5040, 0.5));
        c.add(this.add.ellipse(0, 0, 14*s, 3*s, 0x6a6050, 0.3));
        // Wind-blown particles
        c.add(this.add.rectangle(6*s, -1*s, 3, 1, 0x5a5040, 0.25).setAngle(-10));
    }
    
    _createIsoBarricade(c) {
        const s = 0.7 + this.random() * 0.3;
        // Makeshift barricade — front face dominant (north wall: wide)
        // Jersey barrier style: 20w × 8h front face, 4w side sliver
        c.add(this.add.ellipse(0, 8*s, 22*s, 5*s, 0x000000, 0.15)); // shadow
        c.add(this.add.rectangle(0, 2*s, 20*s, 8*s, 0x4a4a4a, 0.8)); // front face
        c.add(this.add.rectangle(0, -2*s, 18*s, 2*s, 0x5a5a5a, 0.6)); // top strip (foreshortened)
        c.add(this.add.rectangle(10*s, 2*s, 3*s, 7*s, 0x3a3a3a, 0.7)); // side depth
        // Paint stripe
        c.add(this.add.rectangle(0, 2*s, 16*s, 1, 0xcc8822, 0.4));
    }
    
    _createIsoBrokenWall(c) {
        const s = 0.6 + this.random() * 0.4;
        // Partial wall remnant — ¾ iso
        // Front face (north wall): 16w × 14h — brick/concrete visible
        c.add(this.add.ellipse(0, 10*s, 20*s, 5*s, 0x000000, 0.15));
        c.add(this.add.rectangle(0, 2*s, 16*s, 14*s, 0x3a3535, 0.7));
        // Broken top edge (jagged)
        c.add(this.add.rectangle(-4*s, -6*s, 4*s, 3*s, 0x3a3535, 0.7));
        c.add(this.add.rectangle(5*s, -5*s, 3*s, 2*s, 0x3a3535, 0.6));
        // Side depth (east wall: narrow 4w sliver)
        c.add(this.add.rectangle(8*s, 3*s, 4*s, 12*s, 0x2a2525, 0.6));
        // Exposed rebar
        c.add(this.add.rectangle(-2*s, -7*s, 1, 4*s, 0x6a4a3a, 0.5));
        // Brick lines on front
        for (let row = 0; row < 3; row++) {
            c.add(this.add.rectangle(0, -2*s + row * 4*s, 14*s, 0.5, 0x2a2020, 0.3));
        }
    }
    
    // === SMALL DETAIL PROPS ===
    createGrassTuft(c) {
        const count = 3 + Math.floor(this.random() * 4);
        for (let i = 0; i < count; i++) {
            const gx = (this.random() - 0.5) * 8;
            const gh = 3 + this.random() * 5;
            const blade = this.add.rectangle(gx, -gh/2, 1, gh, 0x4a6a3a);
            blade.setAngle((this.random() - 0.5) * 30);
            c.add(blade);
        }
    }
    
    createSmallRock(c) {
        const col = this.random() < 0.5 ? 0x5a5550 : 0x4a4540;
        c.add(this.add.ellipse(0, 0, 4 + this.random() * 4, 2 + this.random() * 2, col));
    }
    

    
    createDeadBush(c) {
        c.add(this.add.rectangle(0, 2, 1, 4, 0x4a3a2a));
        c.add(this.add.rectangle(-2, 0, 4, 1, 0x4a3a2a).setAngle(-20));
        c.add(this.add.rectangle(2, 1, 3, 1, 0x4a3a2a).setAngle(25));
    }
    
    createDirtPatch(c) {
        c.add(this.add.ellipse(0, 0, 8 + this.random() * 10, 4 + this.random() * 4, 0x3a3530, 0.4));
    }
    
    createSkull(c) {
        c.add(this.add.ellipse(0, 0, 5, 4, 0xddddcc, 0.7));
        c.add(this.add.circle(-1, -1, 1, 0x222222, 0.8));
        c.add(this.add.circle(1, -1, 1, 0x222222, 0.8));
    }
    
    createDebrisPile(c) {
        for (let i = 0; i < 3; i++) {
            const dx = (this.random() - 0.5) * 8;
            const dy = (this.random() - 0.5) * 4;
            c.add(this.add.rectangle(dx, dy, 2 + this.random() * 4, 1 + this.random() * 2, 0x3a3535).setAngle(this.random() * 360));
        }
    }
    
    createScrapMetal(c) {
        const col = this.random() < 0.5 ? 0x5a5a5a : 0x6a5a4a;
        c.add(this.add.rectangle(0, 0, 6 + this.random() * 6, 2 + this.random() * 2, col).setAngle(this.random() * 40 - 20));
        if (this.random() > 0.5) {
            c.add(this.add.rectangle(2, -1, 3, 1, 0x4a4a4a).setAngle(this.random() * 60));
        }
    }
    
    createBrokenGlass(c) {
        for (let i = 0; i < 2 + Math.floor(this.random() * 3); i++) {
            const gx = (this.random() - 0.5) * 6;
            const gy = (this.random() - 0.5) * 3;
            c.add(this.add.rectangle(gx, gy, 2, 1, 0x88aacc, 0.4).setAngle(this.random() * 360));
        }
    }
    
    createSmallAnimal(c, type) {
        if (type === 'rabbit') {
            c.add(this.add.ellipse(0, 0, 5, 3, 0x8a7a6a));
            c.add(this.add.ellipse(-2, -2, 1, 3, 0x8a7a6a));
            c.add(this.add.ellipse(0, -2, 1, 3, 0x8a7a6a));
        } else if (type === 'bird') {
            c.add(this.add.ellipse(0, 0, 4, 2, 0x4a4a5a));
            c.add(this.add.triangle(2, 0, 0, 0, 3, -1, 3, 1, 0x6a5a3a));
        } else if (type === 'lizard') {
            c.add(this.add.ellipse(0, 0, 5, 2, 0x5a6a4a));
            c.add(this.add.rectangle(3, 0, 4, 1, 0x5a6a4a));
        } else if (type === 'rat') {
            c.add(this.add.ellipse(0, 0, 4, 2, 0x4a4040));
            c.add(this.add.rectangle(3, 0, 4, 0.5, 0x4a4040));
            c.add(this.add.circle(-1.5, -1, 0.5, 0x2a2020));
        }
        c.setAlpha(0.7 + this.random() * 0.3);
    }
    
    createWornSign(c) {
        c.add(this.add.rectangle(0, 4, 2, 10, 0x5a4a3a));
        c.add(this.add.rectangle(0, -2, 10, 6, 0x6a5a4a));
        c.add(this.add.rectangle(0, -2, 8, 4, 0x5a4a3a, 0.5));
    }
    
    createWornVehicle(c) {
        // Rusted car shell
        const rust = 0x6a4a3a;
        c.add(this.add.ellipse(0, 4, 24, 6, 0x000000, 0.3)); // shadow
        c.add(this.add.rectangle(0, 0, 20, 8, rust)); // body
        c.add(this.add.rectangle(0, -5, 14, 5, rust)); // cabin
        c.add(this.add.rectangle(-6, -4, 4, 3, 0x3a4a5a, 0.4)); // window
        c.add(this.add.rectangle(4, -4, 4, 3, 0x3a4a5a, 0.4)); // window
        c.add(this.add.circle(-6, 4, 3, 0x2a2a2a)); // wheel
        c.add(this.add.circle(6, 4, 3, 0x2a2a2a)); // wheel
        // Rust patches
        c.add(this.add.ellipse(3, 1, 4, 2, 0x4a3020, 0.5));
        c.add(this.add.ellipse(-5, 2, 3, 2, 0x4a3020, 0.5));
        c.setScale(0.8 + this.random() * 0.4);
        c.setAngle((this.random() - 0.5) * 20);
    }
    
    // === ADDITIONAL BIOME DETAIL PROPS ===
    
    // Grassy biome
    createMushroomPatch(c) {
        for (let i = 0; i < 2 + Math.floor(this.random() * 3); i++) {
            const mx = (this.random() - 0.5) * 8;
            const my = (this.random() - 0.5) * 4;
            c.add(this.add.rectangle(mx, my + 2, 1, 3, 0x8a7a6a));
            c.add(this.add.ellipse(mx, my, 3 + this.random() * 2, 2, 0xaa6644));
        }
    }
    
    createFallenLog(c) {
        c.add(this.add.ellipse(0, 2, 16, 4, 0x000000, 0.2)); // shadow
        c.add(this.add.rectangle(0, 0, 14, 4, 0x4a3a2a));
        c.add(this.add.ellipse(-7, 0, 4, 4, 0x3a2a1a)); // end
        c.add(this.add.ellipse(7, 0, 4, 4, 0x3a2a1a)); // end
        // Moss
        c.add(this.add.ellipse(2, -1, 5, 2, 0x3a5a3a, 0.5));
    }
    
    // Barren biome
    createTumbleweed(c) {
        const size = 4 + this.random() * 4;
        c.add(this.add.circle(0, 0, size, 0x6a5a4a, 0.6));
        // Twiggy texture
        for (let i = 0; i < 6; i++) {
            const angle = (i / 6) * Math.PI * 2;
            c.add(this.add.rectangle(
                Math.cos(angle) * size * 0.7,
                Math.sin(angle) * size * 0.7,
                size * 0.6, 1, 0x5a4a3a
            ).setAngle(angle * 180 / Math.PI));
        }
    }
    
    createBleachedBones(c) {
        // Scattered bone fragments
        c.add(this.add.rectangle(-3, 0, 8, 2, 0xddddcc, 0.8).setAngle(15));
        c.add(this.add.rectangle(4, 2, 6, 1.5, 0xccccbb, 0.7).setAngle(-25));
        c.add(this.add.ellipse(-1, 3, 4, 3, 0xddddcc, 0.6)); // pelvis?
        if (this.random() > 0.5) {
            c.add(this.add.rectangle(5, -2, 4, 1, 0xccccbb, 0.6).setAngle(45));
        }
    }
    
    // Apocalyptic biome
    createRadiationSign(c) {
        c.add(this.add.rectangle(0, 5, 2, 12, 0x5a5a5a));
        c.add(this.add.triangle(0, -3, -6, 6, 0, -6, 6, 6, 0xffcc00, 0.8));
        c.add(this.add.circle(0, -2, 2, 0x1a1a1a, 0.9));
        // Trefoil hint
        for (let i = 0; i < 3; i++) {
            const a = (i / 3) * Math.PI * 2 - Math.PI / 2;
            c.add(this.add.circle(Math.cos(a) * 2, -2 + Math.sin(a) * 2, 1, 0x1a1a1a, 0.8));
        }
    }
    
    createOilStain(c) {
        c.add(this.add.ellipse(0, 0, 12 + this.random() * 10, 6 + this.random() * 4, 0x1a1a1a, 0.4));
        c.add(this.add.ellipse(2, -1, 8 + this.random() * 5, 4 + this.random() * 2, 0x2a2525, 0.3));
        // Rainbow sheen
        c.add(this.add.ellipse(-2, 1, 4, 2, 0x4a3a5a, 0.15));
    }
    
    // Snake for barren
    createSnake(c) {
        // S-curve body
        c.add(this.add.ellipse(-4, 0, 3, 2, 0x5a6a4a));
        c.add(this.add.ellipse(0, 1, 3, 2, 0x5a6a4a));
        c.add(this.add.ellipse(4, 0, 3, 2, 0x5a6a4a));
        c.add(this.add.triangle(6, 0, 0, -1, 3, 0, 0, 1, 0x5a6a4a)); // head
        c.setAlpha(0.7);
    }
    
    // Crow for apocalyptic
    createCrow(c) {
        c.add(this.add.ellipse(0, 0, 5, 3, 0x1a1a1a));
        c.add(this.add.circle(-2, -1, 1.5, 0x1a1a1a)); // head
        c.add(this.add.triangle(3, 0, 0, -1, 4, 0, 0, 1, 0x1a1a1a)); // tail
        c.add(this.add.triangle(-3, -1, 0, 0, 2, -1, 2, 1, 0x3a3a3a)); // beak
        c.setAlpha(0.8);
    }
    
    // === ISOMETRIC SCENERY PROPS — all anchored to Y=0 ground ===
    createIsoTree(c) {
        const s = 0.8 + this.random() * 0.4;
        c.add(this.add.ellipse(2*s, 1*s, 18*s, 7*s, 0x000000, 0.2));
        c.add(this.add.rectangle(0, -6*s, 5*s, 14*s, 0x4a3a2a));
        c.add(this.add.rectangle(2*s, -6*s, 1.5*s, 13*s, 0x3a2a1a));
        c.add(this.add.rectangle(-1*s, -6*s, 1.5*s, 12*s, 0x5a4a3a));
        c.add(this.add.ellipse(0, -16*s, 18*s, 14*s, 0x2a5a2a));
        c.add(this.add.ellipse(2*s, -19*s, 16*s, 12*s, 0x3a6a3a));
        c.add(this.add.ellipse(-1*s, -21*s, 12*s, 8*s, 0x4a7a4a));
    }
    
    createIsoDeadTree(c) {
        const s = 0.7 + this.random() * 0.3;
        c.add(this.add.ellipse(1*s, 1*s, 12*s, 4*s, 0x000000, 0.15));
        c.add(this.add.rectangle(0, -7*s, 4*s, 16*s, 0x3a2a1a));
        c.add(this.add.rectangle(1*s, -7*s, 1.5*s, 15*s, 0x2a1a0a));
        c.add(this.add.rectangle(-6*s, -14*s, 8*s, 2*s, 0x3a2a1a).setAngle(-20));
        c.add(this.add.rectangle(5*s, -17*s, 7*s, 1.5*s, 0x3a2a1a).setAngle(18));
        c.add(this.add.rectangle(-3*s, -20*s, 5*s, 1.5*s, 0x3a2a1a).setAngle(-35));
    }
    
    createIsoRock(c, scale = 1) {
        const s = scale * (0.6 + this.random() * 0.4);
        c.add(this.add.ellipse(1*s, 1*s, 16*s, 5*s, 0x000000, 0.15));
        c.add(this.add.ellipse(0, -2*s, 14*s, 9*s, 0x5a5550));
        c.add(this.add.ellipse(0, -4*s, 12*s, 6*s, 0x6a6560));
        c.add(this.add.ellipse(-2*s, -5*s, 5*s, 3*s, 0x7a7570));
    }
    
    createIsoRuin(c) {
        const s = 0.8 + this.random() * 0.4;
        c.add(this.add.ellipse(2*s, 1*s, 24*s, 8*s, 0x000000, 0.2));
        c.add(this.add.rectangle(0, -6*s, 18*s, 14*s, 0x3a3535));
        c.add(this.add.rectangle(9*s, -5*s, 4*s, 12*s, 0x2a2828));
        c.add(this.add.rectangle(-3*s, -14*s, 6*s, 4*s, 0x3a3535));
        c.add(this.add.rectangle(5*s, -12*s, 4*s, 3*s, 0x3a3535));
        c.add(this.add.rectangle(-5*s, 0, 4*s, 2*s, 0x2a2525).setAngle(12));
        c.add(this.add.rectangle(3*s, 1*s, 3*s, 2*s, 0x353030).setAngle(-8));
    }
    
    createIsoBush(c) {
        const s = 0.5 + this.random() * 0.3;
        c.add(this.add.ellipse(0, 1*s, 10*s, 3.5*s, 0x000000, 0.12));
        c.add(this.add.ellipse(0, -3*s, 10*s, 7*s, 0x2a4a2a));
        c.add(this.add.ellipse(1*s, -4*s, 7*s, 5*s, 0x3a5a3a));
    }
    
    createIsoFencePost(c) {
        c.add(this.add.rectangle(0, -5, 3, 14, 0x5a4a3a));
        c.add(this.add.rectangle(1, -5, 1, 13, 0x4a3a2a));
        c.add(this.add.rectangle(0, -10, 7, 2, 0x5a4a3a));
        c.add(this.add.rectangle(0, -4, 7, 1.5, 0x5a4a3a));
    }
    
    createIsoCactus(c) {
        const s = 0.6 + this.random() * 0.3;
        c.add(this.add.ellipse(0, 1*s, 7*s, 2.5*s, 0x000000, 0.12));
        c.add(this.add.rectangle(0, -7*s, 5*s, 16*s, 0x3a5a3a));
        c.add(this.add.rectangle(1*s, -7*s, 1.5*s, 14*s, 0x2a4a2a));
        c.add(this.add.rectangle(-4*s, -10*s, 3*s, 8*s, 0x3a5a3a));
        c.add(this.add.rectangle(-4*s, -14*s, 3*s, 1.5*s, 0x3a5a3a));
        c.add(this.add.rectangle(4*s, -8*s, 3*s, 6*s, 0x3a5a3a));
    }
    
    createIsoRubble(c) {
        const s = 0.5 + this.random() * 0.3;
        c.add(this.add.ellipse(0, 0, 14*s, 5*s, 0x000000, 0.12));
        const cols = [0x3a3535, 0x2a2525, 0x454040, 0x353030];
        for (let i = 0; i < 5; i++) {
            const rx = (this.random() - 0.5) * 10 * s;
            const ry = (this.random() - 0.5) * 4 * s - 1;
            c.add(this.add.rectangle(rx, ry, 2+this.random()*4, 1.5+this.random()*2.5, cols[Math.floor(this.random()*cols.length)]).setAngle(this.random()*360));
        }
    }
    
    createIsoPole(c) {
        const lean = 3 + this.random() * 8;
        c.add(this.add.ellipse(1, 1, 5, 2, 0x000000, 0.1));
        c.add(this.add.rectangle(0, -10, 2, 22, 0x4a4a3a).setAngle(lean));
        c.add(this.add.rectangle(0, -18, 12, 1.5, 0x3a3a30).setAngle(lean * 0.3));
        c.add(this.add.rectangle(5, -16, 1, 4, 0x3a3a30, 0.5).setAngle(lean + 10));
    }
    
    drawConnections() {
        this.connectionGraphics = this.add.graphics();
        this.connectionLayer.add(this.connectionGraphics);
        this.redrawConnections();
    }
    
    redrawConnections() {
        this.connectionGraphics.clear();
        
        // Draw reach dividers
        const bossNodes = Object.values(this.nodes).filter(n => n.isBossGate);
        bossNodes.forEach(bn => {
            const divX = bn.x + this.scrollX + this.nodeSpacing * 0.5;
            this.connectionGraphics.lineStyle(1, 0x442222, 0.3);
            this.connectionGraphics.beginPath();
            this.connectionGraphics.moveTo(divX, CONFIG.height - 280);
            this.connectionGraphics.lineTo(divX, CONFIG.height - 80);
            this.connectionGraphics.strokePath();
        });
        
        this.connections.forEach(conn => {
            const fromNode = this.nodes[conn.from];
            const toNode = this.nodes[conn.to];
            if (!fromNode || !toNode) return;
            
            const isCurrentConnection = fromNode.id === this.currentNodeId;
            const routeKey = `${fromNode.id}->${toNode.id}`;
            const isTraveledRoute = this.traveledRoutes.includes(routeKey);
            const toBossGate = toNode.isBossGate && (fromNode.discovered || fromNode.completed);
            if (!isCurrentConnection && !isTraveledRoute && !toBossGate) {
                // Future route preview: show faded paths from accessible nodes (one step ahead)
                const isFromAccessible = this.connections.some(c => c.from === this.currentNodeId && c.to === fromNode.id);
                const isOneAhead = isFromAccessible && !toNode.discovered && !toNode.completed;
                if (!isOneAhead) return;
                
                // Draw as faded dotted path
                const fFromX = fromNode.x + this.scrollX;
                const fToX = toNode.x + this.scrollX;
                const fFromY = fromNode.y;
                const fToY = toNode.y;
                const fdx = fToX - fFromX;
                const fdy = fToY - fFromY;
                const fSeed = (fromNode.col * 73 + (fromNode.y|0) * 37 + toNode.col * 17) % 100;
                const fCurve = ((fSeed / 100) - 0.5) * 40;
                
                this.connectionGraphics.lineStyle(1, 0x555555, 0.2);
                const dotSegs = 12;
                for (let i = 0; i < dotSegs; i += 2) {
                    const t1 = i / dotSegs, t2 = (i + 1) / dotSegs;
                    const x1 = fFromX + fdx * t1 + fCurve * Math.sin(t1 * Math.PI);
                    const y1 = fFromY + fdy * t1 + fCurve * Math.sin(t1 * Math.PI) * 0.5;
                    const x2 = fFromX + fdx * t2 + fCurve * Math.sin(t2 * Math.PI);
                    const y2 = fFromY + fdy * t2 + fCurve * Math.sin(t2 * Math.PI) * 0.5;
                    this.connectionGraphics.beginPath();
                    this.connectionGraphics.moveTo(x1, y1);
                    this.connectionGraphics.lineTo(x2, y2);
                    this.connectionGraphics.strokePath();
                }
                return;
            }
            
            const fromX = fromNode.x + this.scrollX;
            const toX = toNode.x + this.scrollX;
            const fromY = fromNode.y;
            const toY = toNode.y;
            
            const isBossRoad = toBossGate && !isCurrentConnection && !isTraveledRoute;
            const roadAlpha = isBossRoad ? 0.4 : 1;
            
            // Road surface type from destination node's biome (matches what traversal will show)
            const roadBiome = toNode.biome || this.getBiomeAtX((fromNode.x + toNode.x) / 2);
            
            let roadBase, roadSurface, roadEdge, roadDetail, roadWidth;
            if (roadBiome === 'grassy') {
                // Dirt road — matches traversal isDirt=true: 0x4a3a28 surface, 0x5a4a38 edge
                roadBase = 0x3a2a18; roadSurface = 0x4a3a28; roadEdge = 0x5a4a38; roadDetail = 0x5a4830;
                roadWidth = isCurrentConnection ? 5 : isBossRoad ? 2 : 3;
            } else if (roadBiome === 'barren') {
                // Worn asphalt — matches traversal isDirt=false: 0x2a2a2a surface, 0x5a5a4a edge
                roadBase = 0x222222; roadSurface = 0x2a2a2a; roadEdge = 0x5a5a4a; roadDetail = 0x1a1a1a;
                roadWidth = isCurrentConnection ? 5 : isBossRoad ? 2 : 4;
            } else {
                // Cracked asphalt — darker, damaged version of asphalt
                roadBase = 0x1a1a1a; roadSurface = 0x2a2a2a; roadEdge = 0x5a5a4a; roadDetail = 0x111111;
                roadWidth = isCurrentConnection ? 5 : isBossRoad ? 2 : 4;
            }
            
            // Generate a seeded curve offset for this connection
            const seed = (fromNode.col * 73 + (fromNode.y|0) * 37 + toNode.col * 17) % 100;
            const curveAmt = ((seed / 100) - 0.5) * 40;
            
            const dx = toX - fromX;
            const dy = toY - fromY;
            
            const drawCurve = (lw, lc, la) => {
                this.connectionGraphics.lineStyle(lw, lc, la);
                const segs = 16;
                for (let i = 0; i < segs; i++) {
                    const t1 = i / segs, t2 = (i + 1) / segs;
                    const x1 = fromX + dx * t1 + curveAmt * Math.sin(t1 * Math.PI);
                    const y1 = fromY + dy * t1 + curveAmt * Math.sin(t1 * Math.PI) * 0.5;
                    const x2 = fromX + dx * t2 + curveAmt * Math.sin(t2 * Math.PI);
                    const y2 = fromY + dy * t2 + curveAmt * Math.sin(t2 * Math.PI) * 0.5;
                    this.connectionGraphics.beginPath();
                    this.connectionGraphics.moveTo(x1, y1);
                    this.connectionGraphics.lineTo(x2, y2);
                    this.connectionGraphics.strokePath();
                }
            };
            
            // 3-layer road: edge → base → surface
            drawCurve(roadWidth + 2, roadEdge, roadAlpha * 0.7);
            drawCurve(roadWidth + 1, roadBase, roadAlpha * 0.9);
            drawCurve(roadWidth, roadSurface, roadAlpha);
            
            // Biome-specific road details
            for (let i = 0; i < 10; i++) {
                const t = (i + 0.5) / 10;
                const tx = fromX + dx * t + curveAmt * Math.sin(t * Math.PI);
                const ty = fromY + dy * t + curveAmt * Math.sin(t * Math.PI) * 0.5;
                if (roadBiome === 'grassy' && (seed + i * 7) % 3 === 0) {
                    this.connectionGraphics.fillStyle(roadDetail, roadAlpha * 0.3);
                    this.connectionGraphics.fillCircle(tx + ((seed+i)%5-2), ty + ((seed+i)%3-1), 1);
                } else if (roadBiome === 'barren' && (seed + i * 11) % 4 === 0) {
                    this.connectionGraphics.lineStyle(1, roadDetail, roadAlpha * 0.3);
                    this.connectionGraphics.beginPath();
                    this.connectionGraphics.moveTo(tx - 2, ty - 3);
                    this.connectionGraphics.lineTo(tx + 2, ty + 3);
                    this.connectionGraphics.strokePath();
                } else if (roadBiome === 'apocalyptic' && (seed + i * 13) % 5 === 0) {
                    this.connectionGraphics.fillStyle(roadDetail, roadAlpha * 0.4);
                    this.connectionGraphics.fillEllipse(tx, ty, 3, 2);
                }
            }
            
            // Traveled routes get tire track marks
            if (isTraveledRoute) {
                this.connectionGraphics.lineStyle(1, 0x1a1a15, 0.3);
                for (let i = 0; i < 8; i++) {
                    const t = (i + 0.5) / 8;
                    const tx = fromX + (toX - fromX) * t + curveAmt * Math.sin(t * Math.PI) * 0.6;
                    const ty = fromY + (toY - fromY) * t + curveAmt * Math.sin(t * Math.PI);
                    this.connectionGraphics.beginPath();
                    this.connectionGraphics.moveTo(tx - 2, ty - 1);
                    this.connectionGraphics.lineTo(tx + 2, ty + 1);
                    this.connectionGraphics.strokePath();
                }
            }
        });
    }
    
    drawNodes() {
        this.nodeVisuals = {};
        
        Object.values(this.nodes).forEach(node => {
            this.createNodeVisual(node);
        });
    }
    
    createNodeVisual(node) {
        // SIDE-SCROLLING: use scrollX for horizontal positioning
        const container = this.add.container(node.x + this.scrollX, node.y);
        
        // Determine visibility
        const isCurrentNode = node.id === this.currentNodeId;
        const isAccessible = this.connections.some(c => c.from === this.currentNodeId && c.to === node.id);
        const isDiscovered = node.discovered;
        const isPartial = node.partiallyVisible && !isDiscovered;
        const isFog = !isDiscovered && !isPartial && !isCurrentNode;
        const isCompleted = node.completed && !isCurrentNode && node.id !== 'safehouse';
        
        const isBossGate = node.isBossGate;
        const isHaven = node.isHaven;
        const scale = isCurrentNode ? 1.15 : isBossGate ? 1.2 : isHaven ? 1.0 : 0.9;
        
        // Create isometric building based on node type
        if (!isFog) {
            const building = this.createIsoNodeBuilding(node, scale, isCompleted, isPartial);
            container.add(building);
        } else {
            // Fog: just a shadowy shape
            const fogShape = this.add.ellipse(0, 5, 30 * scale, 15 * scale, 0x222222, 0.4);
            container.add(fogShape);
            const fogIcon = this.add.text(0, 0, '?', {
                fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#444'
            }).setOrigin(0.5);
            container.add(fogIcon);
        }
        
        
        // Current node indicator (pulsing glow)
        if (isCurrentNode) {
            const pulse = this.add.ellipse(0, 8, 50, 25, 0x44ff44, 0);
            pulse.setStrokeStyle(2, 0x44ff44, 0.5);
            container.add(pulse);
            container.sendToBack(pulse);
            
            this.tweens.add({
                targets: pulse,
                scaleX: 1.3,
                scaleY: 1.3,
                alpha: 0,
                duration: 1000,
                repeat: -1
            });
            
            // Player vehicle parked at current node (skip in route mode — vehicle drives separately)
            if (!this.activeRoute) {
                const veh = SpriteManager.createVehicle(this, 0, 18, 'iso');
                veh.setScale(0.8);
                container.add(veh);
            }
        }
        
        // Boss gate pulsing red glow
        if (isBossGate && !isCompleted && !isFog) {
            const bossGlow = this.add.ellipse(0, 8, 55, 28, 0xcc2244, 0);
            bossGlow.setStrokeStyle(2, 0xcc2244, 0.5);
            container.add(bossGlow);
            container.sendToBack(bossGlow);
            this.tweens.add({
                targets: bossGlow, scaleX: 1.4, scaleY: 1.4, alpha: 0, duration: 1500, repeat: -1
            });
        }
        
        // Accessible node highlight (subtle, no red circle)
        if (isAccessible && !isCompleted && !isFog) {
            const highlight = this.add.ellipse(0, 8, 45, 22, 0x88ff88, 0.15);
            container.add(highlight);
            container.sendToBack(highlight);
        }
        
        // Node info - only for accessible nodes
        if (isAccessible && !isCurrentNode && !isFog) {
            let infoY = 28;
            
            // Shift label down if another node is close below to prevent overlap
            const nodeArr = Object.values(this.nodes);
            for (const other of nodeArr) {
                if (other.id === node.id) continue;
                if (Math.abs(other.x - node.x) < 100 && other.y > node.y && other.y - node.y < 55) {
                    infoY = -32; // Move label above node instead
                    break;
                }
            }
            
            const biomeName = node.biome ? CONFIG.biomes[node.biome]?.name || node.name : node.name;
            let displayName = node.locationType ? node.name : (node.type === 'defense' ? biomeName : node.name);
            // Truncate long names to prevent overlap
            if (displayName.length > 14) displayName = displayName.substring(0, 12) + '…';
            const nameColor = isBossGate ? '#ff4466' : isHaven ? '#66aadd' : '#888';
            const name = this.add.text(0, infoY, displayName, {
                fontFamily: CONFIG.font, fontSize: isBossGate ? uiPx(8) : uiPx(7), fill: nameColor,
                fontStyle: isBossGate ? 'bold' : 'normal'
            }).setOrigin(0.5);
            container.add(name);
            
            // Reach label for boss gates
            if (isBossGate && node.reach) {
                const reachLabel = this.add.text(0, -35, `REACH ${node.reach}`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#cc4466', fontStyle: 'bold'
                }).setOrigin(0.5);
                container.add(reachLabel);
            }
            
            // Fuel cost
            if (node.fuel > 0) {
                // Fuel icon (atlas) + cost
                if (this.textures.exists('ui_icon_fuel')) {
                    container.add(this.add.image(-8, infoY + 10, 'ui_icon_fuel').setScale(0.6));
                    container.add(this.add.text(0, infoY + 9, `${node.fuel}`, {
                        fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#a84'
                    }).setOrigin(0, 0.5));
                } else {
                    container.add(this.add.text(0, infoY + 9, `FUEL ${node.fuel}`, {
                        fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#a84'
                    }).setOrigin(0.5));
                }
            }
        }
        
        // Make accessible nodes interactive
        if (isAccessible && !node.completed) {
            container.setSize(60, 50);
            container.setInteractive();
            container.on('pointerdown', () => this.selectNode(node));
            
            container.on('pointerover', () => {
                container.setScale(1.1);
            });
            container.on('pointerout', () => {
                container.setScale(1);
            });
        }
        
        this.nodeLayer.add(container);
        this.nodeVisuals[node.id] = container;
        
        // Bobbing exclamation point for story event nodes
        if (node.hasStoryEvent && !node.storyEventDone && !isCompleted) {
            const exclY = -40 * scale;
            const exclBg = this.add.circle(0, exclY, 7, 0xffcc44, 0.9);
            container.add(exclBg);
            const excl = this.add.text(0, exclY, '!', {
                fontFamily: CONFIG.font, fontSize: uiPx(Math.max(10, 12 * scale)),
                fill: '#221100', fontStyle: 'bold'
            }).setOrigin(0.5);
            container.add(excl);
            this.tweens.add({
                targets: [excl, exclBg], y: exclY - 3, duration: 800,
                yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
            });
        }
    }
    
    // Create isometric building sprite for a node (like SafehouseExterior)
    createIsoNodeBuilding(node, scale, isCompleted, isPartial) {
        const c = this.add.container(0, 0);
        const s = scale;
        const a = (obj) => { c.add(obj); return obj; };
        const alpha = isCompleted ? 0.45 : isPartial ? 0.55 : 1;
        const biome = node.biome || 'barren';
        
        // Ground anchor — everything draws UP from gy (ground level)
        const gy = 8;
        
        // === RAISED TERRAIN BASE — grounds the node visually ===
        // Iso diamond mound with biome coloring, layered for depth
        const baseColors = {
            grassy: [0x2a3a22, 0x334428, 0x3c4e30],
            barren: [0x3a3228, 0x443c30, 0x4e4638],
            apocalyptic: [0x1e1c1c, 0x242222, 0x2a2828]
        };
        const bc2 = baseColors[biome] || baseColors.barren;
        const bw = 38 * s, bh = 14 * s;
        // Dirt mound base (back layer)
        a(this.add.ellipse(0, gy + 4*s, bw + 6, bh + 2, bc2[0], 0.7 * alpha));
        // Middle terrain layer
        a(this.add.ellipse(0, gy + 3*s, bw, bh - 2, bc2[1], 0.8 * alpha));
        // Top surface
        a(this.add.ellipse(0, gy + 2*s, bw - 6, bh - 5, bc2[2], 0.6 * alpha));
        // Front edge — shows the "cliff" of the raised terrain
        a(this.add.ellipse(0, gy + 6*s, bw - 4, 4*s, bc2[0], 0.4 * alpha));
        // Tiny texture: pebbles / grass tufts on edges
        if (!isPartial) {
            const texCol = biome === 'grassy' ? 0x2a4a20 : biome === 'apocalyptic' ? 0x181616 : 0x352e24;
            for (let p = 0; p < 3; p++) {
                const px = (this.random() - 0.5) * bw * 0.7;
                const py = gy + 3*s + this.random() * 3*s;
                a(this.add.rectangle(px, py, 2, 1, texCol, 0.3 * alpha));
            }
        }
        
        // Shadow flat on ground (on top of terrain base)
        a(this.add.ellipse(2*s, gy + 2*s, 36*s, 10*s, 0x000000, 0.25 * alpha));
        
        if (node.type === 'boss') {
            // === BOSS — show actual boss entity sprite ===
            const bet = node.bossEntityType || 'warden';
            const bossColors = {
                warden: { main: 0x884422, light: 0xaa6644, dark: 0x663311, eye: 0xff2222 },
                swarmQueen: { main: 0x448844, light: 0x66aa66, dark: 0x224422, eye: 0xaaff44 },
                phantom: { main: 0x664488, light: 0x8866aa, dark: 0x442266, eye: 0xcc88ff },
                ironclad: { main: 0x666677, light: 0x888899, dark: 0x444455, eye: 0xff4422 },
                cubeAnomaly: { main: 0x8844aa, light: 0xaa66cc, dark: 0x662288, eye: 0xff00ff }
            };
            const bc = bossColors[bet] || bossColors.warden;
            
            // Dark arena platform
            a(this.add.polygon(0, gy, [0, 0, 20*s, 10*s, 0, 20*s, -20*s, 10*s], 0x1a1010, alpha).setOrigin(0));
            
            // Ominous glow under boss
            a(this.add.ellipse(0, gy + 4*s, 28*s, 10*s, bc.eye, 0.08 * alpha));
            
            if (bet === 'warden') {
                // Hulking brute — front-facing ¾ iso
                // Legs
                a(this.add.rectangle(-5*s, gy - 4*s, 6*s, 10*s, bc.dark, alpha));
                a(this.add.rectangle(5*s, gy - 4*s, 6*s, 10*s, bc.dark, alpha));
                a(this.add.rectangle(-5*s, gy - 6*s, 7*s, 3*s, 0x555544, alpha)); // knee guard
                a(this.add.rectangle(5*s, gy - 6*s, 7*s, 3*s, 0x555544, alpha));
                // Torso — wide and armored
                a(this.add.rectangle(0, gy - 14*s, 20*s, 14*s, bc.main, alpha));
                a(this.add.rectangle(0, gy - 16*s, 18*s, 4*s, 0x555544, alpha)); // chest plate
                a(this.add.rectangle(0, gy - 14*s, 16*s, 1*s, 0x444433, alpha));
                // Arms
                a(this.add.rectangle(-12*s, gy - 12*s, 5*s, 12*s, bc.dark, alpha));
                a(this.add.rectangle(12*s, gy - 12*s, 5*s, 12*s, bc.dark, alpha));
                a(this.add.rectangle(-12*s, gy - 16*s, 6*s, 3*s, 0x666655, alpha)); // shoulder
                a(this.add.rectangle(12*s, gy - 16*s, 6*s, 3*s, 0x666655, alpha));
                // Head
                a(this.add.rectangle(0, gy - 24*s, 10*s, 8*s, bc.light, alpha));
                a(this.add.rectangle(-3*s, gy - 25*s, 3*s, 3*s, bc.eye, alpha)); // eye
                a(this.add.rectangle(3*s, gy - 25*s, 3*s, 3*s, bc.eye, alpha));
                a(this.add.rectangle(0, gy - 22*s, 5*s, 1.5*s, 0xaa0000, alpha)); // mouth
                // Chains
                a(this.add.rectangle(-8*s, gy - 10*s, 1*s, 4*s, 0x888877, alpha));
                a(this.add.rectangle(-6*s, gy - 9*s, 1*s, 3*s, 0x888877, alpha));
                
            } else if (bet === 'swarmQueen') {
                // Insectoid queen — wide with legs
                // Legs (6 total, 3 per side)
                for (let i = 0; i < 3; i++) {
                    const lx = -10*s + i * 4*s, rx = 4*s + i * 4*s;
                    a(this.add.rectangle(lx, gy - 1*s, 2*s, 6*s, bc.dark, alpha));
                    a(this.add.rectangle(rx, gy - 1*s, 2*s, 6*s, bc.dark, alpha));
                }
                // Abdomen
                a(this.add.ellipse(0, gy - 4*s, 20*s, 12*s, bc.dark, alpha));
                a(this.add.ellipse(0, gy - 5*s, 16*s, 9*s, bc.main, alpha));
                // Egg sacs
                a(this.add.ellipse(-5*s, gy - 2*s, 5*s, 4*s, 0x88aa44, alpha));
                a(this.add.ellipse(5*s, gy - 2*s, 5*s, 4*s, 0x88aa44, alpha));
                // Thorax
                a(this.add.ellipse(0, gy - 12*s, 16*s, 10*s, bc.dark, alpha));
                a(this.add.ellipse(0, gy - 13*s, 12*s, 7*s, bc.main, alpha));
                // Head
                a(this.add.ellipse(0, gy - 20*s, 10*s, 8*s, bc.dark, alpha));
                a(this.add.ellipse(0, gy - 20*s, 7*s, 6*s, bc.main, alpha));
                // Compound eyes
                a(this.add.ellipse(-3*s, gy - 21*s, 3*s, 2.5*s, bc.eye, alpha));
                a(this.add.ellipse(3*s, gy - 21*s, 3*s, 2.5*s, bc.eye, alpha));
                // Mandibles
                a(this.add.rectangle(-4*s, gy - 17*s, 2*s, 3*s, 0x886633, alpha));
                a(this.add.rectangle(4*s, gy - 17*s, 2*s, 3*s, 0x886633, alpha));
                
            } else if (bet === 'phantom') {
                // Ethereal wraith — floating, translucent
                // Cloak trail
                a(this.add.triangle(0, gy, 0, -4*s, -12*s, 10*s, 12*s, 10*s, bc.dark, alpha * 0.4));
                // Body
                a(this.add.ellipse(0, gy - 10*s, 16*s, 22*s, bc.main, alpha * 0.5));
                a(this.add.ellipse(0, gy - 12*s, 12*s, 16*s, bc.light, alpha * 0.35));
                // Inner void
                a(this.add.ellipse(0, gy - 10*s, 8*s, 12*s, 0x110022, alpha * 0.5));
                // Head
                a(this.add.ellipse(0, gy - 22*s, 9*s, 7*s, bc.main, alpha * 0.7));
                a(this.add.ellipse(0, gy - 22*s, 6*s, 5*s, bc.light, alpha * 0.5));
                // Eyes
                a(this.add.rectangle(-3*s, gy - 23*s, 3*s, 3*s, bc.eye, alpha));
                a(this.add.rectangle(3*s, gy - 23*s, 3*s, 3*s, bc.eye, alpha));
                // Horns
                a(this.add.rectangle(-5*s, gy - 27*s, 2*s, 5*s, 0x886aaa, alpha));
                a(this.add.rectangle(5*s, gy - 27*s, 2*s, 5*s, 0x886aaa, alpha));
                // Wisps
                a(this.add.ellipse(-10*s, gy - 8*s, 3*s, 8*s, bc.dark, alpha * 0.2));
                a(this.add.ellipse(10*s, gy - 8*s, 3*s, 8*s, bc.dark, alpha * 0.2));
                
            } else if (bet === 'ironclad') {
                // Mechanical tank — boxy, armored
                // Treads
                a(this.add.rectangle(-8*s, gy - 1*s, 8*s, 5*s, 0x333333, alpha));
                a(this.add.rectangle(8*s, gy - 1*s, 8*s, 5*s, 0x333333, alpha));
                // Piston legs
                a(this.add.rectangle(-7*s, gy - 7*s, 6*s, 10*s, 0x555566, alpha));
                a(this.add.rectangle(7*s, gy - 7*s, 6*s, 10*s, 0x555566, alpha));
                a(this.add.rectangle(-7*s, gy - 5*s, 5*s, 2*s, 0x777788, alpha)); // piston
                a(this.add.rectangle(7*s, gy - 5*s, 5*s, 2*s, 0x777788, alpha));
                // Core body
                a(this.add.rectangle(0, gy - 16*s, 24*s, 16*s, bc.main, alpha));
                a(this.add.rectangle(0, gy - 20*s, 22*s, 4*s, bc.light, alpha)); // upper plate
                // Rivets
                for (let r = -8; r <= 8; r += 4) {
                    a(this.add.circle(r*s, gy - 20*s, 1*s, 0x999999, alpha));
                }
                // Visor
                a(this.add.rectangle(0, gy - 25*s, 18*s, 6*s, 0x222233, alpha));
                a(this.add.rectangle(0, gy - 25*s, 14*s, 3*s, bc.eye, alpha)); // eye slit
                // Shoulder turret
                a(this.add.rectangle(13*s, gy - 24*s, 5*s, 4*s, 0x555555, alpha));
                a(this.add.rectangle(17*s, gy - 24*s, 5*s, 2*s, 0x777777, alpha)); // barrel
                // Arms
                a(this.add.rectangle(-14*s, gy - 14*s, 4*s, 10*s, 0x555566, alpha));
                a(this.add.rectangle(14*s, gy - 14*s, 4*s, 10*s, 0x555566, alpha));
                
            } else {
                // Cube anomaly — geometric alien
                const csz = 16*s;
                // Outer shell
                a(this.add.rectangle(0, gy - 14*s, csz, csz, 0x220044, alpha));
                a(this.add.rectangle(0, gy - 14*s, csz - 3*s, csz - 3*s, bc.main, alpha));
                // Grid
                for (let g = -5; g <= 5; g += 3) {
                    a(this.add.rectangle(g*s, gy - 14*s, 0.5*s, csz - 4*s, 0x6622aa, alpha * 0.3));
                    a(this.add.rectangle(0, gy - 14*s + g*s, csz - 4*s, 0.5*s, 0x6622aa, alpha * 0.3));
                }
                // Core
                a(this.add.rectangle(0, gy - 14*s, 5*s, 5*s, 0xdd44ff, alpha));
                a(this.add.rectangle(0, gy - 14*s, 3*s, 3*s, 0xff88ff, alpha));
                // Corner crystals
                a(this.add.rectangle(-5*s, gy - 19*s, 4*s, 4*s, 0xaa44dd, alpha));
                a(this.add.rectangle(5*s, gy - 19*s, 4*s, 4*s, 0xaa44dd, alpha));
                a(this.add.rectangle(-5*s, gy - 9*s, 4*s, 4*s, 0xaa44dd, alpha));
                a(this.add.rectangle(5*s, gy - 9*s, 4*s, 4*s, 0xaa44dd, alpha));
                // Eyes
                a(this.add.rectangle(-3*s, gy - 18*s, 3*s, 2*s, bc.eye, alpha));
                a(this.add.rectangle(3*s, gy - 18*s, 3*s, 2*s, bc.eye, alpha));
            }
            
            // Spikes flanking
            a(this.add.triangle(-18*s, gy, 0, -8*s, -2*s, 2*s, 2*s, 2*s, 0x2a1515, alpha));
            a(this.add.triangle(18*s, gy, 0, -8*s, -2*s, 2*s, 2*s, 2*s, 0x2a1515, alpha));
            
        } else if (node.type === 'defense') {
            // === DEFENSE — convoy truck ===
            // Truck body
            a(this.add.rectangle(-4*s, gy - 6*s, 22*s, 10*s, 0x4a5040, alpha));
            a(this.add.rectangle(-4*s, gy - 11*s, 20*s, 2*s, 0x5a6050, alpha));
            a(this.add.rectangle(8*s, gy - 6*s, 4*s, 9*s, 0x3a4030, alpha));
            // Cab
            a(this.add.rectangle(-16*s, gy - 7*s, 8*s, 8*s, 0x3a4a3a, alpha));
            a(this.add.rectangle(-16*s, gy - 9*s, 6*s, 3*s, 0x2a3a4a, alpha));
            // Wheels
            a(this.add.ellipse(-10*s, gy + 1*s, 5*s, 3*s, 0x1a1a1a, alpha));
            a(this.add.ellipse(4*s, gy + 1*s, 5*s, 3*s, 0x1a1a1a, alpha));
            // Sandbags + crate on bed
            a(this.add.ellipse(-2*s, gy - 12*s, 5*s, 3*s, 0x6a6a5a, alpha));
            a(this.add.ellipse(3*s, gy - 12*s, 4*s, 2.5*s, 0x6a6a5a, alpha));
            a(this.add.rectangle(6*s, gy - 14*s, 5*s, 4*s, 0x5a4a3a, alpha));
            // Mounted gun
            a(this.add.rectangle(0, gy - 16*s, 2*s, 6*s, 0x3a3a3a, alpha));
            a(this.add.rectangle(3*s, gy - 18*s, 8*s, 2*s, 0x3a3a3a, alpha));
            
        } else if (node.type === 'safehouse') {
            // === SAFEHOUSE — fortified base ===
            a(this.add.polygon(0, gy, [0, 0, 16*s, 8*s, 16*s, -16*s, 0, -24*s], 0x3a3a38, alpha).setOrigin(0));
            a(this.add.polygon(0, gy, [0, 0, -16*s, 8*s, -16*s, -16*s, 0, -24*s], 0x4a4a48, alpha).setOrigin(0));
            a(this.add.polygon(0, gy - 24*s, [0, 0, 16*s, 8*s, 0, 16*s, -16*s, 8*s], 0x555553, alpha).setOrigin(0));
            a(this.add.rectangle(-8*s, gy - 8*s, 8*s, 10*s, 0x1a1a1a, alpha));
            a(this.add.rectangle(-8*s, gy - 3*s, 7*s, 1.5*s, 0x8a8a22, alpha));
            a(this.add.rectangle(-8*s, gy - 16*s, 5*s, 3.5*s, 0x2a3a4a, alpha));
            a(this.add.rectangle(-4*s, gy - 30*s, 1*s, 8*s, 0x555555, alpha));
            a(this.add.circle(-4*s, gy - 34*s, 1*s, 0xaa0000, alpha * 0.7));
            
        } else if (node.type === 'haven') {
            // === HAVEN — trading camp ===
            a(this.add.triangle(0, gy - 4*s, 0, -16*s, -14*s, 6*s, 14*s, 6*s, 0x4a6070, alpha));
            a(this.add.triangle(0, gy - 4*s, 0, -16*s, 0, 6*s, 14*s, 6*s, 0x5a7080, alpha * 0.6));
            a(this.add.rectangle(0, gy - 2*s, 5*s, 8*s, 0x253035, alpha));
            a(this.add.rectangle(-16*s, gy - 4*s, 1.5*s, 12*s, 0x5a4a3a, alpha));
            a(this.add.rectangle(-16*s, gy - 10*s, 8*s, 4*s, 0x4a3a2a, alpha));
            a(this.add.ellipse(14*s, gy + 1*s, 6*s, 3*s, 0x2a1a0a, alpha));
            a(this.add.circle(14*s, gy - 1*s, 2*s, 0xff8844, 0.35 * alpha));
            a(this.add.circle(14*s, gy - 1*s, 1*s, 0xffcc66, 0.5 * alpha));
            
        }
        
        if (node.type === 'defense') {
            // === LOCATION-SPECIFIC BUILDINGS ===
            const loc = node.locationType || 'house';
            const tint = biome === 'grassy' ? 0x080808 : biome === 'barren' ? 0x040400 : 0x000004;
            // Biome tint offsets for wall colors
            const bw = biome === 'grassy' ? 0x050a05 : biome === 'barren' ? 0x0a0800 : 0x000005;
            
            if (loc === 'gas_station') {
                // Canopy on posts over pump area, small attached store
                // Store body — front face (wide, dominant) 
                a(this.add.polygon(6*s, gy, [0, 0, 10*s, 5*s, 10*s, -10*s, 0, -15*s], 0x4a4540 + bw, alpha).setOrigin(0));
                a(this.add.polygon(6*s, gy, [0, 0, -10*s, 5*s, -10*s, -10*s, 0, -15*s], 0x5a5550 + bw, alpha).setOrigin(0));
                // Store roof (thin top)
                a(this.add.polygon(6*s, gy - 15*s, [0, 0, 10*s, 5*s, 0, 10*s, -10*s, 5*s], 0x3a3530 + bw, alpha).setOrigin(0));
                // Store window
                a(this.add.rectangle(0, gy - 8*s, 6*s, 5*s, 0x2a3a4a, alpha));
                // Canopy — flat cover over pump area
                a(this.add.polygon(-10*s, gy - 14*s, [0, 0, 14*s, 7*s, 0, 14*s, -14*s, 7*s], 0x555555, alpha).setOrigin(0));
                // Canopy posts (front two visible)
                a(this.add.rectangle(-16*s, gy - 4*s, 1.5*s, 12*s, 0x4a4a4a, alpha));
                a(this.add.rectangle(-4*s, gy - 4*s, 1.5*s, 12*s, 0x4a4a4a, alpha));
                // Fuel pumps under canopy
                a(this.add.rectangle(-12*s, gy - 3*s, 3*s, 6*s, 0xcc4444, alpha));
                a(this.add.rectangle(-8*s, gy - 3*s, 3*s, 6*s, 0xcc4444, alpha));
                // Pump hoses
                a(this.add.rectangle(-13*s, gy - 5*s, 1*s, 3*s, 0x1a1a1a, alpha));
                a(this.add.rectangle(-7*s, gy - 5*s, 1*s, 3*s, 0x1a1a1a, alpha));
                // Sign on store
                a(this.add.rectangle(6*s, gy - 16*s, 8*s, 2*s, 0x884422, alpha));
                
            } else if (loc === 'pharmacy') {
                // Small storefront with cross sign
                a(this.add.polygon(0, gy, [0, 0, 14*s, 7*s, 14*s, -12*s, 0, -19*s], 0x405045 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -14*s, 7*s, -14*s, -12*s, 0, -19*s], 0x506055 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 19*s, [0, 0, 14*s, 7*s, 0, 14*s, -14*s, 7*s], 0x405040 + bw, alpha).setOrigin(0));
                // Large front window
                a(this.add.rectangle(-7*s, gy - 6*s, 8*s, 8*s, 0x2a3a3a, alpha));
                a(this.add.rectangle(-7*s, gy - 6*s, 7*s, 7*s, 0x354545, alpha * 0.5));
                // Medical cross on side wall
                a(this.add.rectangle(10*s, gy - 12*s, 2*s, 6*s, 0x44aa44, alpha));
                a(this.add.rectangle(10*s, gy - 12*s, 6*s, 2*s, 0x44aa44, alpha));
                // Door
                a(this.add.rectangle(-3*s, gy + 1*s, 4*s, 6*s, 0x1a2a1a, alpha));
                
            } else if (loc === 'hardware_store') {
                // Wide storefront with tool signage
                a(this.add.polygon(0, gy, [0, 0, 16*s, 8*s, 16*s, -12*s, 0, -20*s], 0x4a4035 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -16*s, 8*s, -16*s, -12*s, 0, -20*s], 0x5a5045 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 20*s, [0, 0, 16*s, 8*s, 0, 16*s, -16*s, 8*s], 0x4a4540 + bw, alpha).setOrigin(0));
                // Storefront windows
                a(this.add.rectangle(-9*s, gy - 6*s, 6*s, 7*s, 0x2a3540, alpha));
                a(this.add.rectangle(-2*s, gy - 6*s, 5*s, 7*s, 0x2a3540, alpha));
                // Sign board
                a(this.add.rectangle(0, gy - 21*s, 12*s, 3*s, 0x884422, alpha));
                // Outdoor display rack
                a(this.add.rectangle(-18*s, gy - 2*s, 4*s, 6*s, 0x5a5040, alpha));
                a(this.add.rectangle(-18*s, gy - 5*s, 3*s, 1*s, 0x666055, alpha));
                
            } else if (loc === 'grocery') {
                // Wide store with cart + awning
                a(this.add.polygon(0, gy, [0, 0, 16*s, 8*s, 16*s, -11*s, 0, -19*s], 0x454540 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -16*s, 8*s, -16*s, -11*s, 0, -19*s], 0x555550 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 19*s, [0, 0, 16*s, 8*s, 0, 16*s, -16*s, 8*s], 0x454540 + bw, alpha).setOrigin(0));
                // Awning over entrance
                a(this.add.polygon(-8*s, gy - 14*s, [0, 0, 10*s, 3*s, 0, 6*s, -10*s, 3*s], 0x448844, alpha).setOrigin(0));
                // Windows
                a(this.add.rectangle(-10*s, gy - 6*s, 5*s, 6*s, 0x2a3a40, alpha));
                a(this.add.rectangle(-3*s, gy - 6*s, 5*s, 6*s, 0x2a3a40, alpha));
                // Shopping cart
                a(this.add.rectangle(-18*s, gy - 1*s, 4*s, 3*s, 0x888888, alpha));
                a(this.add.rectangle(-18*s, gy + 1*s, 4*s, 1*s, 0x666666, alpha));
                // Sign
                a(this.add.rectangle(0, gy - 21*s, 10*s, 2.5*s, 0x448844, alpha));
                
            } else if (loc === 'apartment') {
                // Tall narrow building, multiple window rows
                a(this.add.polygon(0, gy, [0, 0, 12*s, 6*s, 12*s, -20*s, 0, -26*s], 0x3a3540 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -12*s, 6*s, -12*s, -20*s, 0, -26*s], 0x4a4550 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 26*s, [0, 0, 12*s, 6*s, 0, 12*s, -12*s, 6*s], 0x555560 + bw, alpha).setOrigin(0));
                // Window grid — 3 floors × 2 windows 
                for (let fy = 0; fy < 3; fy++) {
                    const wy = gy - 8*s - fy * 6*s;
                    a(this.add.rectangle(-6*s, wy, 3*s, 3*s, 0x2a3a4a, alpha));
                    a(this.add.rectangle(-1*s, wy, 3*s, 3*s, 0x2a3a4a, alpha));
                }
                // Door
                a(this.add.rectangle(-4*s, gy + 1*s, 4*s, 5*s, 0x1a1a1a, alpha));
                // Fire escape (side)
                a(this.add.rectangle(10*s, gy - 10*s, 3*s, 1*s, 0x4a4a4a, alpha));
                a(this.add.rectangle(10*s, gy - 16*s, 3*s, 1*s, 0x4a4a4a, alpha));
                a(this.add.rectangle(11*s, gy - 13*s, 1*s, 8*s, 0x3a3a3a, alpha));
                
            } else if (loc === 'warehouse') {
                // Big boxy with loading dock door
                a(this.add.polygon(0, gy, [0, 0, 18*s, 9*s, 18*s, -12*s, 0, -21*s], 0x3a3a3a + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -18*s, 9*s, -18*s, -12*s, 0, -21*s], 0x4a4a4a + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 21*s, [0, 0, 18*s, 9*s, 0, 18*s, -18*s, 9*s], 0x555555 + bw, alpha).setOrigin(0));
                // Loading dock door (front)
                a(this.add.rectangle(-8*s, gy - 4*s, 10*s, 10*s, 0x2a2a2a, alpha));
                a(this.add.rectangle(-8*s, gy - 9*s, 10*s, 1*s, 0x5a5a5a, alpha));
                // Horizontal grooves on door
                for (let r = 0; r < 3; r++) a(this.add.rectangle(-8*s, gy - 2*s - r * 3*s, 9*s, 0.5*s, 0x3a3a3a, alpha));
                // Small side door
                a(this.add.rectangle(-2*s, gy + 1*s, 3*s, 5*s, 0x1a1a1a, alpha));
                // Loading dock platform
                a(this.add.rectangle(-8*s, gy + 2*s, 12*s, 2*s, 0x4a4a4a, alpha));
                
            } else if (loc === 'auto_shop') {
                // Garage bay doors visible from front
                a(this.add.polygon(0, gy, [0, 0, 14*s, 7*s, 14*s, -10*s, 0, -17*s], 0x3a3a38 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -14*s, 7*s, -14*s, -10*s, 0, -17*s], 0x4a4a48 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 17*s, [0, 0, 14*s, 7*s, 0, 14*s, -14*s, 7*s], 0x4a4a45 + bw, alpha).setOrigin(0));
                // Two garage bay doors 
                a(this.add.rectangle(-9*s, gy - 3*s, 6*s, 8*s, 0x2a2a2a, alpha));
                a(this.add.rectangle(-2*s, gy - 3*s, 6*s, 8*s, 0x2a2a2a, alpha));
                // Door grooves
                for (let d = 0; d < 2; d++) {
                    const dx = -9*s + d * 7*s;
                    for (let r = 0; r < 3; r++) a(this.add.rectangle(dx, gy - 1*s - r * 2.5*s, 5*s, 0.5*s, 0x3a3a3a, alpha));
                }
                // Tire stack outside
                a(this.add.ellipse(-18*s, gy, 4*s, 2*s, 0x1a1a1a, alpha));
                a(this.add.ellipse(-18*s, gy - 2*s, 4*s, 2*s, 0x1a1a1a, alpha));
                a(this.add.ellipse(-18*s, gy - 4*s, 4*s, 2*s, 0x1a1a1a, alpha));
                // Sign
                a(this.add.rectangle(0, gy - 18*s, 10*s, 2*s, 0x4488aa, alpha));
                
            } else if (loc === 'motel') {
                // Long low building, numbered doors along front
                a(this.add.polygon(0, gy, [0, 0, 20*s, 10*s, 20*s, -8*s, 0, -18*s], 0x45403a + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -20*s, 10*s, -20*s, -8*s, 0, -18*s], 0x55504a + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 18*s, [0, 0, 20*s, 10*s, 0, 20*s, -20*s, 10*s], 0x4a4540 + bw, alpha).setOrigin(0));
                // Row of doors (front face — wide and visible)
                for (let d = 0; d < 4; d++) {
                    const dx = -14*s + d * 5*s;
                    a(this.add.rectangle(dx, gy - 2*s, 3*s, 6*s, 0x3a2a20, alpha));
                    a(this.add.rectangle(dx, gy - 6*s, 2.5*s, 2*s, 0x2a3a4a, alpha));
                }
                // Walkway overhang
                a(this.add.rectangle(-7*s, gy - 12*s, 20*s, 1.5*s, 0x5a5040, alpha));
                // Motel sign on pole
                a(this.add.rectangle(18*s, gy - 8*s, 1.5*s, 14*s, 0x4a4a4a, alpha));
                a(this.add.rectangle(18*s, gy - 14*s, 6*s, 4*s, 0xaa4444, alpha));
                a(this.add.circle(18*s, gy - 16*s, 1*s, 0xff6644, alpha * 0.6));
                
            } else if (loc === 'diner') {
                // Low building, counter visible through window
                a(this.add.polygon(0, gy, [0, 0, 14*s, 7*s, 14*s, -10*s, 0, -17*s], 0x504540 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -14*s, 7*s, -14*s, -10*s, 0, -17*s], 0x605550 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 17*s, [0, 0, 14*s, 7*s, 0, 14*s, -14*s, 7*s], 0x555045 + bw, alpha).setOrigin(0));
                // Large window showing interior
                a(this.add.rectangle(-7*s, gy - 6*s, 9*s, 6*s, 0x2a3540, alpha));
                a(this.add.rectangle(-7*s, gy - 6*s, 8*s, 5*s, 0x354a55, alpha * 0.4));
                // Counter visible through window
                a(this.add.rectangle(-7*s, gy - 4*s, 7*s, 1*s, 0x5a5040, alpha * 0.5));
                // Door
                a(this.add.rectangle(-1*s, gy + 1*s, 3*s, 5*s, 0x3a2a20, alpha));
                // Chimney/vent
                a(this.add.rectangle(10*s, gy - 19*s, 2*s, 4*s, 0x4a4a4a, alpha));
                // Sign
                a(this.add.rectangle(0, gy - 18*s, 8*s, 2*s, 0xaa6644, alpha));
                
            } else if (loc === 'police_station') {
                // Institutional building, barred windows
                a(this.add.polygon(0, gy, [0, 0, 16*s, 8*s, 16*s, -14*s, 0, -22*s], 0x3a3a45 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -16*s, 8*s, -16*s, -14*s, 0, -22*s], 0x4a4a55 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 22*s, [0, 0, 16*s, 8*s, 0, 16*s, -16*s, 8*s], 0x555565 + bw, alpha).setOrigin(0));
                // Barred windows
                a(this.add.rectangle(-8*s, gy - 10*s, 5*s, 4*s, 0x2a2a3a, alpha));
                a(this.add.rectangle(-8*s, gy - 10*s, 0.5*s, 4*s, 0x5a5a5a, alpha));
                a(this.add.rectangle(-2*s, gy - 10*s, 4*s, 4*s, 0x2a2a3a, alpha));
                a(this.add.rectangle(-2*s, gy - 10*s, 0.5*s, 4*s, 0x5a5a5a, alpha));
                // Double door entrance
                a(this.add.rectangle(-5*s, gy + 1*s, 6*s, 6*s, 0x2a2a3a, alpha));
                a(this.add.rectangle(-5*s, gy - 2*s, 0.5*s, 6*s, 0x4a4a5a, alpha));
                // Badge emblem
                a(this.add.circle(-5*s, gy - 16*s, 2.5*s, 0x4488aa, alpha));
                a(this.add.circle(-5*s, gy - 16*s, 1.5*s, 0x5599bb, alpha * 0.6));
                
            } else if (loc === 'church') {
                // Steeple/cross on peaked roof
                a(this.add.polygon(0, gy, [0, 0, 14*s, 7*s, 14*s, -14*s, 0, -21*s], 0x4a4540 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -14*s, 7*s, -14*s, -14*s, 0, -21*s], 0x5a5550 + bw, alpha).setOrigin(0));
                // Peaked roof
                a(this.add.polygon(0, gy - 21*s, [0, -5*s, 16*s, 7*s, 0, 14*s, -16*s, 7*s], 0x6a5a4a + bw, alpha).setOrigin(0));
                // Arched door 
                a(this.add.rectangle(-5*s, gy - 2*s, 5*s, 8*s, 0x3a2a20, alpha));
                a(this.add.ellipse(-5*s, gy - 6*s, 5*s, 3*s, 0x3a2a20, alpha));
                // Stained glass window
                a(this.add.rectangle(-5*s, gy - 14*s, 3*s, 4*s, 0x4a3a6a, alpha));
                a(this.add.ellipse(-5*s, gy - 16*s, 3*s, 2*s, 0x6a4a8a, alpha));
                // Cross on steeple
                a(this.add.rectangle(0, gy - 30*s, 1.5*s, 8*s, 0x8a8a80, alpha));
                a(this.add.rectangle(0, gy - 31*s, 5*s, 1.5*s, 0x8a8a80, alpha));
                
            } else if (loc === 'school') {
                // Longer building, multiple windows, flag
                a(this.add.polygon(0, gy, [0, 0, 18*s, 9*s, 18*s, -10*s, 0, -19*s], 0x4a4540 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -18*s, 9*s, -18*s, -10*s, 0, -19*s], 0x5a5550 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 19*s, [0, 0, 18*s, 9*s, 0, 18*s, -18*s, 9*s], 0x555550 + bw, alpha).setOrigin(0));
                // Row of windows
                for (let w = 0; w < 4; w++) {
                    a(this.add.rectangle(-13*s + w * 5*s, gy - 10*s, 3*s, 3.5*s, 0x2a3a4a, alpha));
                }
                // Double doors
                a(this.add.rectangle(-3*s, gy + 1*s, 5*s, 6*s, 0x3a2a20, alpha));
                a(this.add.rectangle(-3*s, gy - 2*s, 0.5*s, 6*s, 0x4a3a30, alpha));
                // Flag pole
                a(this.add.rectangle(-20*s, gy - 6*s, 1*s, 16*s, 0x5a5a5a, alpha));
                a(this.add.rectangle(-18*s, gy - 20*s, 4*s, 3*s, 0x4488aa, alpha));
                
            } else if (loc === 'research_lab') {
                // Industrial/sterile, foundry logo, antenna
                a(this.add.polygon(0, gy, [0, 0, 16*s, 8*s, 16*s, -14*s, 0, -22*s], 0x404550 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -16*s, 8*s, -16*s, -14*s, 0, -22*s], 0x505560 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 22*s, [0, 0, 16*s, 8*s, 0, 16*s, -16*s, 8*s], 0x606570 + bw, alpha).setOrigin(0));
                // Reinforced door
                a(this.add.rectangle(-5*s, gy + 1*s, 5*s, 6*s, 0x3a3a4a, alpha));
                a(this.add.rectangle(-5*s, gy - 2*s, 4*s, 0.5*s, 0x5a5a6a, alpha));
                // Hazard stripe
                a(this.add.rectangle(-5*s, gy + 3*s, 14*s, 1*s, 0xaa8822, alpha));
                // Small reinforced windows
                a(this.add.rectangle(-8*s, gy - 12*s, 3*s, 2*s, 0x2a3a5a, alpha));
                a(this.add.rectangle(-2*s, gy - 12*s, 3*s, 2*s, 0x2a3a5a, alpha));
                // Foundry logo (glowing circle)
                a(this.add.circle(8*s, gy - 12*s, 3*s, 0x2a2a3a, alpha));
                a(this.add.circle(8*s, gy - 12*s, 2*s, 0x8844aa, alpha * 0.5));
                // Antenna/dish on roof
                a(this.add.rectangle(4*s, gy - 26*s, 1*s, 6*s, 0x5a5a5a, alpha));
                a(this.add.ellipse(5*s, gy - 28*s, 4*s, 3*s, 0x6a6a6a, alpha));
                
            } else if (loc === 'bunker') {
                // Mostly underground — hatch visible, minimal above-ground
                // Ground mound
                a(this.add.ellipse(0, gy + 2*s, 24*s, 8*s, biome === 'grassy' ? 0x3a4a3a : biome === 'barren' ? 0x4a4030 : 0x3a3535, alpha));
                // Concrete frame around hatch
                a(this.add.rectangle(0, gy - 2*s, 12*s, 6*s, 0x4a4a4a, alpha));
                a(this.add.rectangle(0, gy - 2*s, 10*s, 5*s, 0x2a2a2a, alpha));
                // Hatch door (slightly ajar)
                a(this.add.rectangle(0, gy - 5*s, 8*s, 1.5*s, 0x5a5a5a, alpha));
                a(this.add.rectangle(-2*s, gy - 6*s, 5*s, 2*s, 0x5a5a5a, alpha).setAngle(-15));
                // Vent pipe
                a(this.add.rectangle(10*s, gy - 6*s, 2*s, 8*s, 0x4a4a4a, alpha));
                a(this.add.rectangle(10*s, gy - 10*s, 4*s, 1*s, 0x5a5a5a, alpha));
                // Warning sign
                a(this.add.rectangle(-10*s, gy - 4*s, 1*s, 8*s, 0x4a4a4a, alpha));
                a(this.add.rectangle(-10*s, gy - 7*s, 4*s, 3*s, 0xaa8822, alpha));
                
            } else {
                // Default: HOUSE — peaked roof suburban home
                a(this.add.polygon(0, gy, [0, 0, 16*s, 8*s, 16*s, -10*s, 0, -18*s], 0x4a4a40 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy, [0, 0, -16*s, 8*s, -16*s, -10*s, 0, -18*s], 0x5a5a50 + bw, alpha).setOrigin(0));
                a(this.add.polygon(0, gy - 18*s, [0, -6*s, 18*s, 8*s, 0, 16*s, -18*s, 8*s], 0x6a5a4a + bw, alpha).setOrigin(0));
                a(this.add.rectangle(-7*s, gy - 2*s, 5*s, 8*s, 0x3a2a20, alpha));
                a(this.add.rectangle(-7*s, gy - 10*s, 5*s, 3.5*s, 0x2a3a4a, alpha));
                a(this.add.rectangle(7*s, gy - 10*s, 4*s, 3*s, 0x2a3a4a, alpha));
                // Mailbox
                a(this.add.rectangle(-18*s, gy - 2*s, 2*s, 6*s, 0x3a3a3a, alpha));
                a(this.add.rectangle(-18*s, gy - 5*s, 4*s, 3*s, 0x4444aa, alpha));
            }
        }
        
        return c;
    }
    
    createUI() {
        const uiDepth = 100;
        
        // === TIME OF DAY PILLAR (left side) ===
        this.createTimePillar();
        
        // ── Shared top HUD (floating panel) ──
        const currentNode2 = this.nodes[this.currentNodeId];
        const currentReach2 = currentNode2?.reach || 1;
        this.hud = GameHUD.create(this, {
            title: 'ROUTE MAP',
            subtitle: 'REACH ' + currentReach2,
            resources: {
                fuel: this.playerState.fuel,
                health: this.playerState.health,
                mag: (ItemManager.getEquipmentStats(this.playerState.equipment || {}).mag || 10), bits: this.playerState.bits
            },
            survivor: this.deployedSurvivor || null
        });
        
        // Wire legacy text refs
        this.fuelText = this.hud._texts.fuel;
        this.healthText = this.hud._texts.health;
        this.magText = this.hud._texts.mag;
        this.bitsText = this.hud._texts.bits;
        
        // Bottom hint
        const hint = this.add.text(CONFIG.width/2, CONFIG.height - 20, 'Select a destination', {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#666'
        }).setOrigin(0.5);
        this.uiLayer.add(hint);
        
        // DEBUG: Skip node button (small, left side)
        const skipBtn = this.add.rectangle(25, CONFIG.height - 50, 30, 30, 0x553333, 0.8);
        skipBtn.setStrokeStyle(1, 0x884444);
        skipBtn.setInteractive();
        this.uiLayer.add(skipBtn);
        const skipText = this.add.text(25, CONFIG.height - 50, '⏩', {
            fontFamily: CONFIG.font, fontSize: uiPx(12)
        }).setOrigin(0.5);
        this.uiLayer.add(skipText);
        skipBtn.on('pointerdown', () => this.debugSkipNode());
        
        // Set UI to not scroll
        this.uiLayer.setScrollFactor(0);
        this.uiLayer.setDepth(uiDepth);
    }
    
    debugSkipNode() {
        // Find first accessible node
        const accessible = this.connections
            .filter(c => c.from === this.currentNodeId)
            .map(c => this.nodes[c.to])
            .filter(n => n && !n.completed);
        
        if (accessible.length === 0) return;
        
        const target = accessible[0];
        
        // Mark current as completed
        if (this.currentNodeId !== 'safehouse' && !this.completedNodes.includes(this.currentNodeId)) {
            this.completedNodes.push(this.currentNodeId);
            this.nodes[this.currentNodeId].completed = true;
        }
        
        // Track route
        const routeKey = `${this.currentNodeId}->${target.id}`;
        if (!this.traveledRoutes.includes(routeKey)) {
            this.traveledRoutes.push(routeKey);
        }
        
        // Move to target
        this.currentNodeId = target.id;
        
        // Update global config to match destination
        if (target.biome) {
            CONFIG.currentBiome.type = target.biome;
            CONFIG.currentBiome.seed = Date.now();
        }
        if (target.timeOfDay) {
            CONFIG.timeOfDay = target.timeOfDay;
        }
        
        // Update discovery
        this.updateDiscovery();
        
        // If we just completed a boss gate, generate the next reach
        const completedNode = this.nodes[this.completedNodes[this.completedNodes.length - 1]];
        if (completedNode && completedNode.isBossGate && this._genState) {
            this.generateNextReach();
        }
        
        // Scroll to new position
        this.scrollToCurrentNode();
        
        // Redraw everything including time indicator
        this.clearAndRedraw();
    }
    
    clearAndRedraw() {
        // Clear existing visuals
        Object.values(this.nodeVisuals).forEach(v => v.destroy());
        if (this.connectionGraphics) this.connectionGraphics.destroy();
        
        // Rebuild UI (time indicator updates)
        this.uiLayer.removeAll(true);
        this.createUI();
        
        // Redraw
        this.drawConnections();
        this.drawNodes();
        this.updateNodePositions();
    }
    
    createTimePillar() {
        const timeOfDay = CONFIG.timeOfDay || 'midday';
        const x = CONFIG.width - 30;
        const y = CONFIG.height - 50;
        
        // Simple background circle
        const bg = this.add.circle(x, y, 18, 0x000000, 0.5);
        this.uiLayer.add(bg);
        
        if (timeOfDay === 'night') {
            // Moon crescent
            const moon = this.add.circle(x, y, 10, 0xddddcc);
            const shadow = this.add.circle(x + 4, y - 3, 9, 0x000000, 0.9);
            this.uiLayer.add(moon);
            this.uiLayer.add(shadow);
        } else if (timeOfDay === 'dawn') {
            // Rising sun - half circle with horizon
            const glow = this.add.circle(x, y, 12, 0xffaa55, 0.3);
            const sun = this.add.circle(x, y + 4, 9, 0xffcc66);
            const horizon = this.add.rectangle(x, y + 9, 30, 12, 0x000000, 0.9);
            this.uiLayer.add(glow);
            this.uiLayer.add(horizon);
            this.uiLayer.add(sun);
        } else if (timeOfDay === 'dusk') {
            // Setting sun - half circle, orange
            const glow = this.add.circle(x, y, 12, 0xff6633, 0.3);
            const sun = this.add.circle(x, y + 4, 9, 0xff8855);
            const horizon = this.add.rectangle(x, y + 9, 30, 12, 0x000000, 0.9);
            this.uiLayer.add(glow);
            this.uiLayer.add(horizon);
            this.uiLayer.add(sun);
        } else {
            // Midday - full sun
            const glow = this.add.circle(x, y, 14, 0xffffaa, 0.3);
            const sun = this.add.circle(x, y, 10, 0xffee66);
            this.uiLayer.add(glow);
            this.uiLayer.add(sun);
        }
    }
    
    setupInput() {
        this.isDragging = false;
        this.dragStartX = 0;
        this.scrollStartX = 0;
        
        this.input.on('pointerdown', (p) => {
            if (this.confirmPopup) return;
            
            this.isDragging = true;
            this.dragStartX = p.x;
            this.scrollStartX = this.scrollX;
        });
        
        this.input.on('pointermove', (p) => {
            if (!this.isDragging || this.confirmPopup) return;
            
            const deltaX = p.x - this.dragStartX;
            this.targetScrollX = this.scrollStartX + deltaX;
            
            // LEFT BOUND: first node in map (safehouse in normal, route start in route mode)
            const firstNode = this.activeRoute
                ? this.nodes[this.activeRoute.nodes[0]]
                : this.nodes['safehouse'];
            const safehouseScroll = firstNode ? -firstNode.x + 120 : 120;
            
            // RIGHT BOUND: two node sets ahead of current position
            // Find accessible nodes (one step ahead) and THEIR connections (two steps ahead)
            const curNode = this.nodes[this.currentNodeId];
            let maxViewX = curNode ? curNode.x : 0;
            
            // First set: directly connected from current
            const firstSet = [];
            if (this.connections) {
                this.connections
                    .filter(c => c.from === this.currentNodeId)
                    .forEach(c => {
                        const targetNode = this.nodes[c.to];
                        if (targetNode) {
                            maxViewX = Math.max(maxViewX, targetNode.x);
                            firstSet.push(targetNode.id);
                        }
                    });
                
                // Second set: connected from each first-set node
                firstSet.forEach(nid => {
                    this.connections
                        .filter(c => c.from === nid)
                        .forEach(c => {
                            const targetNode = this.nodes[c.to];
                            if (targetNode) maxViewX = Math.max(maxViewX, targetNode.x);
                        });
                });
            }
            
            // Also include all completed/visited nodes (backtracking always allowed)
            if (this.completedNodes) {
                this.completedNodes.forEach(nid => {
                    const n = this.nodes[nid];
                    if (n) maxViewX = Math.max(maxViewX, n.x);
                });
            }
            
            // Small padding past the farthest visible node
            maxViewX += 100;
            
            const maxScroll = -maxViewX + CONFIG.width - 80;
            this.targetScrollX = Math.min(this.targetScrollX, safehouseScroll);
            this.targetScrollX = Math.max(this.targetScrollX, maxScroll);
        });
        
        this.input.on('pointerup', () => {
            this.isDragging = false;
        });
    }
    
    // ═══════════════════════════════════════════
    // ROUTE DRIVE — auto-drive vehicle along locked route
    // ═══════════════════════════════════════════
    
    _routeStartDrive() {
        const ar = this.activeRoute;
        if (!ar) return;
        
        // Current step in the route
        this._routeStep = ar.currentStep || 0;
        this._routeDriving = false;
        this._routePaused = false;
        
        // Create vehicle sprite at current node position
        const startNode = this.nodes[ar.nodes[this._routeStep]];
        if (!startNode) return;
        
        const vehX = startNode.x + this.scrollX;
        const vehY = startNode.y + 2;
        this._routeVehicle = SpriteManager.createVehicle(this, vehX, vehY, 'side');
        this._routeVehicle.setScale(1.2).setDepth(50);
        this._routeVehicleBaseX = startNode.x;
        this._routeVehicleBaseY = vehY;
        
        // Dust trail container
        this._routeDust = this.add.container(0, 0).setDepth(49);
        
        // Check if current node is already completed (returning from gameplay)
        const currentNode = this.nodes[ar.nodes[this._routeStep]];
        const isReturning = currentNode && currentNode.completed;
        
        if (isReturning) {
            // Already explored this node — continue driving after brief pause
            this.time.delayedCall(400, () => {
                this._routeAdvance();
            });
        } else if (this._routeStep === 0) {
            // First node (safehouse) — start driving
            this.time.delayedCall(800, () => {
                this._routeAdvance();
            });
        } else {
            // Mid-route re-entry — show enter prompt for current node
            this._routeArriveAtNode(currentNode);
        }
    }
    
    _routeAdvance() {
        const ar = this.activeRoute;
        if (!ar || this._routePaused) return;
        
        const nextStep = this._routeStep + 1;
        
        // Route complete?
        if (nextStep >= ar.nodes.length) {
            this._routeComplete();
            return;
        }
        
        const nextNodeId = ar.nodes[nextStep];
        const nextNode = this.nodes[nextNodeId];
        const edge = ar.edges[this._routeStep]; // edge FROM current TO next
        if (!nextNode) return;
        
        // Check for encounters on this edge — roll each against its chance
        // NOTE: Encounters disabled — TraversalScene decoupled from main loop (separate mode planned)
        const rawEnc = (edge && edge.encounters) ? edge.encounters : [];
        const encounters = rawEnc.filter(e => Math.random() < (e.chance || 0));
        
        // Always clean drive to next node (encounters reserved for standalone traversal mode)
        this._routeDriveToNode(nextNode, nextStep, edge);
    }
    
    _routeDriveToNode(targetNode, stepIndex, edge) {
        this._routeDriving = true;
        const veh = this._routeVehicle;
        if (!veh || !veh.active) return;
        
        const fromX = this._routeVehicleBaseX;
        const toX = targetNode.x;
        const toY = targetNode.y + 2;
        const dist = Math.abs(toX - fromX);
        const duration = Math.max(1500, Math.min(4000, dist * 8)); // 8ms per pixel
        
        // Scroll camera to track vehicle
        this._routeScrollTo(toX, duration);
        
        // Start dust particles
        this._routeStartDust();
        
        // Drive tween
        this.tweens.add({
            targets: { progress: 0 },
            progress: 1,
            duration,
            ease: 'Sine.easeInOut',
            onUpdate: (tween) => {
                const p = tween.getValue();
                this._routeVehicleBaseX = fromX + (toX - fromX) * p;
                this._routeVehicleBaseY = targetNode.y + 2;
                // Slight Y bob for terrain feel
                const bob = Math.sin(p * Math.PI * 6) * 1.5;
                veh.x = this._routeVehicleBaseX + this.scrollX;
                veh.y = this._routeVehicleBaseY + bob;
            },
            onComplete: () => {
                this._routeStopDust();
                this._routeDriving = false;
                this._routeStep = stepIndex;
                
                // Deduct fuel for this edge (modified by survivor marks)
                const _fcm0 = this.playerState.survivorMods?.fuelCostMultiplier || 1;
                if (edge) this.playerState.fuel -= Math.round((edge.fuel || 0) * _fcm0);
                
                // Update activeRoute progress
                this.activeRoute.currentStep = stepIndex;
                const sd = SaveManager.load();
                if (sd && sd.activeRoute) {
                    sd.activeRoute.currentStep = stepIndex;
                    SaveManager.save(sd);
                }
                
                // Arrive at node
                this._routeArriveAtNode(targetNode);
            }
        });
    }
    
    _routeDriveToEncounter(targetNode, edge, encounters) {
        this._routeDriving = true;
        const veh = this._routeVehicle;
        if (!veh || !veh.active) return;
        
        const fromX = this._routeVehicleBaseX;
        const toX = targetNode.x;
        // Stop midway for encounter
        const midX = fromX + (toX - fromX) * (0.3 + Math.random() * 0.3);
        const midY = targetNode.y + 2;
        const dist = Math.abs(midX - fromX);
        const duration = Math.max(800, dist * 8);
        
        this._routeScrollTo(midX, duration);
        this._routeStartDust();
        
        this.tweens.add({
            targets: { progress: 0 },
            progress: 1,
            duration,
            ease: 'Sine.easeInOut',
            onUpdate: (tween) => {
                const p = tween.getValue();
                this._routeVehicleBaseX = fromX + (midX - fromX) * p;
                const bob = Math.sin(p * Math.PI * 4) * 1.5;
                veh.x = this._routeVehicleBaseX + this.scrollX;
                veh.y = midY + bob;
            },
            onComplete: () => {
                this._routeStopDust();
                this._routeDriving = false;
                this._routePaused = true;
                
                // Flash warning then launch TraversalScene
                this._routeShowEncounterAlert(targetNode, edge, encounters);
            }
        });
    }
    
    _routeShowEncounterAlert(targetNode, edge, encounters) {
        const enc = encounters[0]; // Primary encounter
        const alertColors = {
            scavenge: '#aa44aa', defense: '#cc8844',
            rescue: '#44cc66', anomaly: '#44aaaa'
        };
        const alertNames = {
            scavenge: 'SCAVENGE SITE', defense: 'DEFENSE STAND',
            rescue: 'SURVIVOR SIGNAL', anomaly: 'ANOMALY DETECTED'
        };
        
        const alertText = this.add.text(CONFIG.width / 2, CONFIG.height / 2 - 40,
            `-- ${alertNames[enc.type] || 'ENCOUNTER'} --`, {
            fontFamily: CONFIG.font, fontSize: uiPx(16), fill: alertColors[enc.type] || '#ff6644',
            fontStyle: 'bold', backgroundColor: '#000000', padding: { x: 12, y: 6 }
        }).setOrigin(0.5).setDepth(200).setAlpha(0);
        
        this.tweens.add({
            targets: alertText,
            alpha: 1,
            duration: 300,
            yoyo: true,
            hold: 1200,
            onComplete: () => {
                alertText.destroy();
                this._routeLaunchTraversal(targetNode, edge, encounters);
            }
        });
    }
    
    _routeLaunchTraversal(targetNode, edge, encounters) {
        const biomeName = targetNode.biome ? CONFIG.biomes[targetNode.biome]?.name || targetNode.name : targetNode.name;
        
        if (targetNode.biome) {
            CONFIG.currentBiome.type = targetNode.biome;
            CONFIG.currentBiome.seed = Date.now();
            CONFIG.timeOfDay = targetNode.timeOfDay;
        }
        
        // Advance step BEFORE transition — encounter resolves arrival at next node
        const nextStep = this._routeStep + 1;
        this.activeRoute.currentStep = nextStep;
        const sd = SaveManager.load();
        if (sd && sd.activeRoute) {
            sd.activeRoute.currentStep = nextStep;
            SaveManager.save(sd);
        }
        
        // Deduct fuel for this edge (modified by survivor marks)
        const _fcm1 = this.playerState.survivorMods?.fuelCostMultiplier || 1;
        this.playerState.fuel -= Math.round((edge.fuel || 0) * _fcm1);
        
        const travelData = {
            routeType: targetNode.biome === 'grassy' ? 'dirt' : 'road',
            destination: targetNode.locationType ? targetNode.name : biomeName,
            destinationNode: targetNode,
            locationType: targetNode.locationType,
            hasStoryEvent: false,
            distance: 400 + (edge.fuel || 5) * 20,
            playerState: this.playerState,
            mapSeed: this.mapSeed,
            currentNodeId: targetNode.id,
            previousNodeId: this.activeRoute.nodes[this._routeStep],
            completedNodes: this.completedNodes,
            traveledRoutes: this.traveledRoutes,
            activeRoute: this.activeRoute,
            deployedSurvivor: this.deployedSurvivor || null,
            encounters: encounters,
            routeEncounterMode: true,
            rescueMode: encounters.some(e => e.type === 'rescue')
        };
        
        SceneTransition.fadeTo(this, 'TraversalScene', travelData);
    }
    
    _routeArriveAtNode(node) {
        // Vehicle stops at node — show enter prompt overlay
        this._routePaused = true;
        
        const type = node.type;
        const isBoss = type === 'boss';
        const isHaven = type === 'haven';
        const label = isBoss ? 'ENGAGE' : isHaven ? 'ENTER HAVEN' : 'EXPLORE';
        const color = isBoss ? '#cc4444' : isHaven ? '#4488cc' : '#44cc44';
        
        // Position prompt above vehicle
        const veh = this._routeVehicle;
        if (!veh || !veh.active) return;
        
        const promptC = this.add.container(veh.x, veh.y - 40).setDepth(200);
        this._routeNodePrompt = promptC;
        
        // Background pill
        const bg = this.add.rectangle(0, 0, 120, 36, 0x000000, 0.8).setStrokeStyle(1, Phaser.Display.Color.HexStringToColor(color).color, 0.8);
        promptC.add(bg);
        
        // Location name
        promptC.add(this.add.text(0, -18, node.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#aaa'
        }).setOrigin(0.5));
        
        // Enter button
        const btn = this.add.text(0, 2, `[ ${label} ]`, {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: color, fontStyle: 'bold'
        }).setOrigin(0.5);
        promptC.add(btn);
        
        bg.setSize(Math.max(120, btn.width + 24), 44);
        bg.setInteractive({ useHandCursor: true });
        bg.on('pointerover', () => btn.setColor('#ffffff'));
        bg.on('pointerout', () => btn.setColor(color));
        bg.on('pointerdown', () => {
            promptC.destroy();
            this._routeNodePrompt = null;
            if (isBoss) this._routeLaunchBoss(node);
            else if (isHaven) this._routeLaunchHaven(node);
            else this._routeLaunchExploration(node);
        });
        
        // Gentle bounce
        this.tweens.add({
            targets: promptC,
            y: promptC.y - 3,
            duration: 800,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
    }
    
    _routeLaunchExploration(node) {
        if (node.biome) {
            CONFIG.currentBiome.type = node.biome;
            CONFIG.currentBiome.seed = Date.now();
            CONFIG.timeOfDay = node.timeOfDay;
        }
        
        // Snapshot currency for Well Rested bonus calc on return
        this.playerState._preNodeBits = this.playerState.bits || 0;
        this.playerState._preNodeMats = this.playerState.materials || 0;
        
        // Always route to GameScene — interior entry happens via doors in GameScene
        const sceneKey = 'GameScene';
        const launchData = {
            destinationNode: node,
            locationType: node.locationType,
            hasStoryEvent: node.hasStoryEvent,
            mapSeed: this.mapSeed,
            currentNodeId: node.id,
            previousNodeId: this.activeRoute.nodes[Math.max(0, this._routeStep - 1)],
            completedNodes: this.completedNodes,
            traveledRoutes: this.traveledRoutes,
            activeRoute: this.activeRoute,
            deployedSurvivor: this.deployedSurvivor || null,
            playerState: this.playerState
        };
        
        SceneTransition.fadeTo(this, sceneKey, launchData);
    }
    
    _routeLaunchBoss(node) {
        if (node.biome) {
            CONFIG.currentBiome.type = node.biome;
            CONFIG.currentBiome.seed = Date.now();
            CONFIG.timeOfDay = node.timeOfDay;
        }
        
        // Snapshot currency for Well Rested bonus calc on return
        this.playerState._preNodeBits = this.playerState.bits || 0;
        this.playerState._preNodeMats = this.playerState.materials || 0;
        
        const launchData = {
            destinationNode: node,
            mapSeed: this.mapSeed,
            currentNodeId: node.id,
            previousNodeId: this.activeRoute.nodes[Math.max(0, this._routeStep - 1)],
            completedNodes: this.completedNodes,
            traveledRoutes: this.traveledRoutes,
            activeRoute: this.activeRoute,
            deployedSurvivor: this.deployedSurvivor || null,
            playerState: this.playerState,
            bossType: node.bossEntityType,
            bossName: node.name
        };
        
        SceneTransition.fadeTo(this, 'GameScene', launchData);
    }
    
    _routeLaunchHaven(node) {
        // Snapshot currency for Well Rested bonus calc on return
        this.playerState._preNodeBits = this.playerState.bits || 0;
        this.playerState._preNodeMats = this.playerState.materials || 0;
        
        const launchData = {
            destinationNode: node,
            mapSeed: this.mapSeed,
            currentNodeId: node.id,
            previousNodeId: this.activeRoute.nodes[Math.max(0, this._routeStep - 1)],
            completedNodes: this.completedNodes,
            traveledRoutes: this.traveledRoutes,
            activeRoute: this.activeRoute,
            deployedSurvivor: this.deployedSurvivor || null,
            playerState: this.playerState
        };
        
        SceneTransition.fadeTo(this, 'HavenScene', launchData);
    }
    
    _routeComplete() {
        // All nodes visited — reach complete
        const sd = SaveManager.load();
        if (sd) {
            sd.currentReach = (sd.currentReach || 1) + 1;
            sd.activeRoute = null;
            sd.routeSeed = Date.now();
            SaveManager.save(sd);
        }
        
        // Show completion message then return to safehouse
        const msg = this.add.text(CONFIG.width / 2, CONFIG.height / 2 - 20,
            `REACH ${(sd?.currentReach || 2) - 1} COMPLETE`, {
            fontFamily: CONFIG.font, fontSize: uiPx(16), fill: '#44cc44', fontStyle: 'bold',
            backgroundColor: '#000000', padding: { x: 16, y: 8 }
        }).setOrigin(0.5).setDepth(200).setAlpha(0);
        
        this.tweens.add({
            targets: msg, alpha: 1, duration: 500,
            hold: 2000,
            onComplete: () => {
                msg.destroy();
                this.scene.start('SafehouseScene', {
                    returnedLoot: {
                        bits: this.playerState.bits || 0,
                        powerAmmo: this.playerState.powerAmmo || 0,
                        fuel: this.playerState.fuel || 0, cubeBonus: 0
                    },
                    returnedBackpack: this.playerState.backpack,
                    returnedEquipment: this.playerState.equipment,
                    returnedVehicle: this.playerState.vehicle,
                    deployedSurvivor: this.deployedSurvivor
                });
            }
        });
    }
    
    // ── Route drive helpers ──
    
    _routeScrollTo(targetWorldX, duration) {
        const targetScroll = -targetWorldX + CONFIG.width * 0.35;
        this.tweens.add({
            targets: this,
            targetScrollX: targetScroll,
            duration: duration * 0.8,
            ease: 'Sine.easeInOut'
        });
    }
    
    _routeStartDust() {
        if (this._routeDustTimer) return;
        this._routeDustTimer = this.time.addEvent({
            delay: 120,
            loop: true,
            callback: () => {
                if (!this._routeVehicle || !this._routeVehicle.active) return;
                const veh = this._routeVehicle;
                const puff = this.add.circle(veh.x - 20, veh.y + 8, 3 + Math.random() * 3,
                    0x887766, 0.3 + Math.random() * 0.2);
                puff.setDepth(48);
                this.tweens.add({
                    targets: puff,
                    x: puff.x - 15 - Math.random() * 10,
                    y: puff.y - 5 - Math.random() * 8,
                    alpha: 0,
                    scaleX: 2,
                    scaleY: 1.5,
                    duration: 500 + Math.random() * 300,
                    onComplete: () => puff.destroy()
                });
            }
        });
    }
    
    _routeStopDust() {
        if (this._routeDustTimer) {
            this._routeDustTimer.destroy();
            this._routeDustTimer = null;
        }
    }
    
    selectNode(node) {
        // Route mode: no manual selection, vehicle drives automatically
        if (this.activeRoute) return;
        if (this.confirmPopup || this.selectedNode) return;
        if (this.playerState.fuel < node.fuel) {
            this.showMessage('Not enough fuel!');
            return;
        }
        
        this.selectedNode = node;
        this.showConfirmPopup(node);
    }
    
    showConfirmPopup(node) {
        const popupContainer = this.add.container(CONFIG.width/2, CONFIG.height/2).setDepth(7.5);
        const popupBackdrop = this.add.rectangle(0, 0, CONFIG.width, CONFIG.height, 0x000000, 0.7).setInteractive();
        popupBackdrop.on('pointerdown', () => this.closeConfirmPopup());
        popupContainer.add(popupBackdrop);
        const typeDescs = {
            defense: 'Defend a point against hostile waves.',
            haven: 'Rest, trade, and resupply.',
            boss: 'A powerful foe blocks the road.'
        };
        const isBossGate = node.isBossGate, isHaven = node.isHaven;
        const boxH = isBossGate ? 230 : 200;
        UIAtlas.build(this);
        const inner = this.add.nineslice(0, 0, 'ui_panel', null, 260, boxH, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME, UIAtlas.FRAME);
        inner.setInteractive(); // absorb taps so backdrop dismiss doesn't fire through
        popupContainer.add(inner);
        const accentColor = isBossGate ? 0xcc4466 : isHaven ? 0x4488aa : (node.color || 0x4466aa);
        popupContainer.add(this.add.rectangle(0, -boxH/2 + UIAtlas.FRAME - 1, 260 - UIAtlas.FRAME*2, 1, accentColor, 0.5));
        const locConfig = node.locationType ? CONFIG.locations[node.locationType] : null;
        let curY = -boxH/2 + 30;
        // Type indicator circle with text label
        const typeLabels = { defense: 'D', boss: 'X', haven: 'H', safehouse: 'SH' };
        const typeLbl = typeLabels[node.type] || '?';
        popupContainer.add(this.add.circle(0, curY, 16, accentColor, 0.3));
        popupContainer.add(this.add.circle(0, curY, 16, 0x000000, 0).setStrokeStyle(1, accentColor, 0.6));
        popupContainer.add(this.add.text(0, curY, typeLbl, { fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#fff', fontStyle: 'bold' }).setOrigin(0.5));
        curY += 24;
        const popupBiomeName = node.biome ? CONFIG.biomes[node.biome]?.name || node.name : node.name;
        const displayName = node.locationType ? node.name : (node.type === 'defense' ? popupBiomeName : node.name);
        const titleColor = isBossGate ? '#ff4466' : isHaven ? '#66aadd' : '#fff';
        popupContainer.add(this.add.text(0, curY, displayName, { fontFamily: CONFIG.font, fontSize: uiPx(14), fill: titleColor, fontStyle: 'bold' }).setOrigin(0.5));
        curY += 18;
        const desc = typeDescs[node.type] || '';
        if (desc) { popupContainer.add(this.add.text(0, curY, desc, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#777', fontStyle: 'italic' }).setOrigin(0.5)); curY += 14; }
        if (isBossGate && node.reach) { curY += 4; popupContainer.add(this.add.text(0, curY, `-- REACH ${node.reach} GATE --`, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#cc4466', fontStyle: 'bold' }).setOrigin(0.5)); curY += 16; }
        if (node.hasStoryEvent && !node.storyEventDone) { curY += 2; popupContainer.add(this.add.text(0, curY, '[ Story Event ]', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#ffcc44', fontStyle: 'bold' }).setOrigin(0.5)); curY += 14; }
        curY += 8;
        const stats = [];
        if (node.fuel > 0) stats.push({ label: `Fuel Cost: ${node.fuel}`, color: '#aa8844' });
        if (node.difficulty && node.difficulty !== 'None') stats.push({ label: `Difficulty: ${node.difficulty}`, color: '#aaa' });
        if (node.timeOfDay) stats.push({ label: this.getTimeName(node.timeOfDay), color: '#aaa' });
        stats.forEach((stat, i) => { popupContainer.add(this.add.text(0, curY + i * 18, stat.label, { fontFamily: CONFIG.font, fontSize: uiPx(11), fill: stat.color }).setOrigin(0.5)); });
        const btnY = boxH/2 - 30;
        const travelLabel = isBossGate ? 'ENGAGE' : isHaven ? 'ENTER' : 'TRAVEL';
        const travelBtn = UIManager.createButton(this, -60, btnY, travelLabel, {
            width: 100, height: 36, style: isBossGate ? 'danger' : 'confirm', fontSize: uiPx(12), depth: 1,
            onClick: () => this.travelToNode(node)
        });
        popupContainer.add(travelBtn);
        const cancelBtn = UIManager.createButton(this, 60, btnY, 'CANCEL', {
            width: 100, height: 36, style: 'normal', fontSize: uiPx(12), depth: 1,
            onClick: () => this.closeConfirmPopup()
        });
        popupContainer.add(cancelBtn);
        this.confirmPopup = popupContainer;
    }

    getTimeName(time) {
        const names = { dawn: 'Dawn', midday: 'Midday', dusk: 'Dusk', night: 'Night' };
        return names[time] || 'Midday';
    }
    
    closeConfirmPopup() {
        if (this.confirmPopup) {
            this.confirmPopup.destroy();
            this.confirmPopup = null;
            this.selectedNode = null;
        }
    }
    travelToNode(node) {
        // Deduct gas (modified by survivor marks)
        const _fcm2 = this.playerState.survivorMods?.fuelCostMultiplier || 1;
        this.playerState.fuel -= Math.round(node.fuel * _fcm2);
        
        // Snapshot currency for Well Rested bonus calc on return
        this.playerState._preNodeBits = this.playerState.bits || 0;
        this.playerState._preNodeMats = this.playerState.materials || 0;
        
        // Get biome name for destination display
        const biomeName = node.biome ? CONFIG.biomes[node.biome]?.name || node.name : node.name;
        
        // Update activeRoute progress if in route mode
        if (this.activeRoute) {
            const nodeIdx = this.activeRoute.nodes.indexOf(node.id);
            if (nodeIdx >= 0) {
                this.activeRoute.currentStep = nodeIdx;
                // Persist to saveData
                const sd = SaveManager.load();
                if (sd && sd.activeRoute) {
                    sd.activeRoute.currentStep = nodeIdx;
                    SaveManager.save(sd);
                }
            }
        }
        
        // Store destination data
        const travelData = {
            routeType: node.biome === 'grassy' ? 'dirt' : 'road',
            destination: node.locationType ? node.name : (node.type === 'defense' ? biomeName : node.name),
            destinationNode: node,
            locationType: node.locationType,
            hasStoryEvent: node.hasStoryEvent,
            distance: 400 + node.fuel * 20, // Distance based on gas cost
            playerState: this.playerState,
            mapSeed: this.mapSeed,
            currentNodeId: node.id, // Will become current after arrival
            previousNodeId: this.currentNodeId, // Track where we came from
            completedNodes: this.completedNodes, // Pass completed nodes list
            traveledRoutes: this.traveledRoutes, // Pass traveled routes
            activeRoute: this.activeRoute || null, // Pass route context
            encounters: node.encounters || [] // Edge encounters for this leg
        };
        
        // Set biome config for exploration
        if (node.biome) {
            CONFIG.currentBiome.type = node.biome;
            CONFIG.currentBiome.seed = Date.now();
            CONFIG.timeOfDay = node.timeOfDay;
        }
        
        this.closeConfirmPopup();
        
        // Go directly to destination scene (TraversalScene decoupled — separate mode planned)
        const type = node.type;
        const targetScene = type === 'haven' ? 'HavenScene' : 'GameScene';
        SceneTransition.fadeTo(this, targetScene, travelData);
    }
    
    showMessage(msg) {
        const msgText = this.add.text(CONFIG.width/2, CONFIG.height/2, msg, {
            fontFamily: CONFIG.font, fontSize: uiPx(18), fill: '#ff6644', fontStyle: 'bold',
            backgroundColor: '#000000',
            padding: { x: 15, y: 8 }
        }).setOrigin(0.5).setDepth(150);
        
        this.tweens.add({
            targets: msgText,
            y: CONFIG.height/2 - 30,
            alpha: 0,
            duration: 1000,
            onComplete: () => msgText.destroy()
        });
    }
    
    scrollToCurrentNode() {
        const currentNode = this.nodes[this.currentNodeId];
        if (!currentNode) return;
        // SIDE-SCROLLING: center current node horizontally, slight offset to show what's ahead
        this.targetScrollX = -currentNode.x + 120;
        this.scrollX = this.targetScrollX;
    }
    
    update(time, delta) {
        const dt = delta / 1000;
        
        // Smooth horizontal scroll
        if (Math.abs(this.scrollX - this.targetScrollX) > 1) {
            this.scrollX += (this.targetScrollX - this.scrollX) * 0.12;
            this.updateNodePositions();
        }
        
        // Route mode: sync vehicle and prompt with scroll
        if (this._routeVehicle && this._routeVehicle.active && !this._routeDriving) {
            this._routeVehicle.x = this._routeVehicleBaseX + this.scrollX;
        }
        if (this._routeNodePrompt && this._routeVehicle) {
            this._routeNodePrompt.x = this._routeVehicle.x;
        }
        
        // Animate clouds
        if (this._clouds) {
            this._clouds.forEach(c => {
                c.obj.x -= c.speed * dt;
                if (c.obj.x < -60) c.obj.x = CONFIG.width + 60;
            });
        }
    }
    
    updateNodePositions() {
        // Update node visual positions based on horizontal scroll
        // Nodes move 1:1 with scroll - they ARE the ground reference
        Object.keys(this.nodeVisuals).forEach(id => {
            const node = this.nodes[id];
            const visual = this.nodeVisuals[id];
            visual.x = node.x + this.scrollX;
        });
        
        // Far horizon removed — no floating objects
        
        // Background silhouettes - SLOW parallax (0.1x) - mountains, cityscapes, cube
        if (this._bgSilhouettes) {
            const viewL = -400, viewR = CONFIG.width + 400;
            this._bgSilhouettes.forEach(item => {
                const nx = item.baseX + this.scrollX * 0.1;
                item.x = nx;
                item.setVisible(nx > viewL && nx < viewR);
            });
        }
        
        // Mid-far scenery - MEDIUM parallax (0.3x) - towns, craters, installations
        if (this._midFarScenery) {
            const viewL = -400, viewR = CONFIG.width + 400;
            this._midFarScenery.forEach(item => {
                const nx = item.baseX + this.scrollX * 0.3;
                item.x = nx;
                item.setVisible(nx > viewL && nx < viewR);
            });
        }
        
        // Ground bands - move WITH nodes (1x) so nodes look planted on ground
        if (this._groundBands) {
            const viewL = -200, viewR = CONFIG.width + 200;
            this._groundBands.forEach(item => {
                const nx = item.baseX + this.scrollX;
                item.x = nx;
                item.setVisible(nx > viewL && nx < viewR);
            });
        }
        
        // Ground texture lines - move WITH nodes (1x)
        if (this._groundTexture) {
            const viewL = -100, viewR = CONFIG.width + 100;
            this._groundTexture.forEach(item => {
                const nx = item.baseX + this.scrollX;
                item.x = nx;
                item.setVisible(nx > viewL && nx < viewR);
            });
        }
        
        // Horizon ridge - move WITH ground (1x) — in bgLayer now
        if (this._horizonRidge) {
            this._horizonRidge.forEach(item => {
                item.x = item.baseX + this.scrollX;
            });
        }
        
        // Ground details - move WITH nodes (1x)
        if (this._groundDetails) {
            const viewL = -100, viewR = CONFIG.width + 100;
            this._groundDetails.forEach(item => {
                const nx = item.baseX + this.scrollX;
                item.x = nx;
                item.setVisible(nx > viewL && nx < viewR);
            });
        }
        
        // Mid-ground scenery - move WITH nodes (1x) - trees near road
        if (this._midGround) {
            const viewL = -200, viewR = CONFIG.width + 200;
            this._midGround.forEach(item => {
                const nx = item.baseX + this.scrollX;
                item.x = nx;
                item.setVisible(nx > viewL && nx < viewR);
            });
        }
        
        // Near scenery - move WITH nodes (1x) - roadside objects
        if (this._nearScenery) {
            const viewL = -200, viewR = CONFIG.width + 200;
            this._nearScenery.forEach(item => {
                const nx = item.baseX + this.scrollX;
                item.x = nx;
                item.setVisible(nx > viewL && nx < viewR);
            });
        }
        
        // Redraw connections
        this.redrawConnections();
    }
}
