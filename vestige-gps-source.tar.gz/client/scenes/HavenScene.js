// Vestige GPS — HavenScene
// Extracted from monolith lines 71812-75110
// Imports will be wired in integration pass

import { HavenShopManager } from '../../core/havenShopManager.js';
import { ItemManager } from '../../core/itemManager.js';
import { NPCManager } from '../../core/npcManager.js';
import { SaveManager } from '../../core/saveManager.js';
import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { AudioManager } from '../audioManager.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { InteractHighlight } from '../interactHighlight.js';
import { SpriteManager } from '../spriteManager.js';
import { InventoryUI } from '../ui/inventoryUI.js';
import { UIAtlas } from '../uiAtlas.js';
import { UIManager } from '../uiManager.js';
import { VehicleFleet } from '../vehicleFleet.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { InputManager } from '../rendering/inputManager.js';
import { GameScene } from './GameScene.js';
import { MapScene } from './MapScene.js';
import { PortalDungeonScene } from './PortalDungeonScene.js';
import { SafehouseScene } from './SafehouseScene.js';


export class HavenScene extends Phaser.Scene {
    constructor() { super({ key: 'HavenScene' }); }

    init(data) {
        this.playerState = data.playerState || { health: 100, powerAmmo: 0, fuel: 100, scrap: 0, backpack: 'backpack_basic' };
        this.saveData = data.saveData || (typeof SaveManager !== 'undefined' ? SaveManager.load() : {});
        this.mapSeed = data.mapSeed;
        this.currentNodeId = data.currentNodeId;
        this.previousNodeId = data.previousNodeId;
        this.activeRoute = data.activeRoute || null;
        this.deployedSurvivor = data.deployedSurvivor || null;
        this.completedNodes = data.completedNodes || [];
        this.traveledRoutes = data.traveledRoutes || [];
    }

    /* ════════════════════════════════════════════════════
       LAYOUT CONSTANTS — all geometry lives here
       ════════════════════════════════════════════════════ */
    _layout() {
        const L = {};

        // World — generous space
        L.worldW = 2400;
        L.worldH = 2200;

        // ── ROAD ──
        L.roadY = 1900;          // centerline Y (near bottom)
        L.roadH = 52;            // road thickness
        L.roadLeft = 0;
        L.roadRight = L.worldW;

        // ── SOUTH SQUARE (garage area) ──
        L.southSquare = {
            cx: 1200,
            w: 500,
            h: 420,
            wallThick: 16
        };
        L.southSquare.bot = L.roadY + L.roadH / 2;
        L.southSquare.top = L.southSquare.bot - L.southSquare.h;
        L.southSquare.cy = (L.southSquare.top + L.southSquare.bot) / 2;
        L.southSquare.left = L.southSquare.cx - L.southSquare.w / 2;
        L.southSquare.right = L.southSquare.cx + L.southSquare.w / 2;

        // ── ENTRANCE TUNNEL (west) — runs from world left edge to south square ──
        L.entranceTunnel = {
            x: 0, y: L.roadY,
            w: L.southSquare.left,
            h: L.roadH,
            wallThick: 32
        };

        // ── EXIT TUNNEL (east) — runs from south square to world right edge ──
        L.exitTunnel = {
            x: L.southSquare.right, y: L.roadY,
            w: L.worldW - L.southSquare.right,
            h: L.roadH,
            wallThick: 32
        };

        // ── PARKWAY (directly off the road, same level, angled edges blend into road) ──
        // The parkway is a widened area directly north of the road.
        // Its left and right edges angle smoothly into the road surface.
        L.parkway = {
            cx: L.southSquare.cx,
            w: 380,
            h: 120,
            spots: 8,
            spotW: 38,
            spotH: 55,
            angleInset: 60
        };
        // Parkway sits directly above the road's north edge
        L.parkway.bot = L.roadY - L.roadH / 2;                     // flush with road top
        L.parkway.top = L.parkway.bot - L.parkway.h;
        L.parkway.cy = (L.parkway.top + L.parkway.bot) / 2;
        L.parkway.left = L.parkway.cx - L.parkway.w / 2;
        L.parkway.right = L.parkway.cx + L.parkway.w / 2;

        // ── CONNECTOR TUNNEL (south square → north square) ──
        L.connector = {
            cx: L.southSquare.cx,
            w: 80,
            h: 320,
            wallThick: 16
        };
        L.connector.bot = L.southSquare.top;
        L.connector.top = L.connector.bot - L.connector.h;
        L.connector.cy = (L.connector.top + L.connector.bot) / 2;

        // ── NORTH SQUARE (main hub) ──
        L.northSquare = {
            cx: L.southSquare.cx,
            w: 700,
            h: 580,
            wallThick: 16
        };
        L.northSquare.bot = L.connector.top;
        L.northSquare.top = L.northSquare.bot - L.northSquare.h;
        L.northSquare.cy = (L.northSquare.top + L.northSquare.bot) / 2;
        L.northSquare.left = L.northSquare.cx - L.northSquare.w / 2;
        L.northSquare.right = L.northSquare.cx + L.northSquare.w / 2;

        // ── BRANCH TUNNELS (4 total: 2 left, 2 right) ──
        const branchLen = 200;
        const branchW = 70;
        const ns = L.northSquare;
        // Evenly spaced — room centers need ~200px vertical gap to avoid overlap
        const branchY1 = ns.top + ns.h * 0.3;    // upper pair
        const branchY2 = ns.top + ns.h * 0.7;    // lower pair

        L.branches = {
            leftTop:  { cx: ns.left - branchLen / 2, cy: branchY1, w: branchLen, h: branchW, side: 'left' },
            leftBot:  { cx: ns.left - branchLen / 2, cy: branchY2, w: branchLen, h: branchW, side: 'left' },
            rightTop: { cx: ns.right + branchLen / 2, cy: branchY1, w: branchLen, h: branchW, side: 'right' },
            rightBot: { cx: ns.right + branchLen / 2, cy: branchY2, w: branchLen, h: branchW, side: 'right' },
        };

        // ── ROOMS (varied sizes, at end of each branch) ──
        // Room edge aligns with branch end — no gap
        const bLeftEnd = ns.left - branchLen;   // left branch ends here
        const bRightEnd = ns.right + branchLen; // right branch ends here
        L.rooms = {
            factionHQ: {
                cx: bLeftEnd - 95,
                cy: branchY1,
                w: 190, h: 160,
                label: 'FACTION HQ',
                color: 0x2a3a2a
            },
            medBay: {
                cx: bLeftEnd - 80,
                cy: branchY2,
                w: 160, h: 130,
                label: 'MED BAY',
                color: 0x2a2a3a
            },
            vendor: {
                cx: bRightEnd + 95,
                cy: branchY1,
                w: 190, h: 160,
                label: 'VENDOR',
                color: 0x3a2a1a
            },
            stash: {
                cx: bRightEnd + 75,
                cy: branchY2,
                w: 150, h: 120,
                label: 'STASH',
                color: 0x2a2a2a
            },
        };

        // ── PORTAL (slotted into north wall of north square) ──
        L.portal = {
            cx: ns.cx,
            cy: ns.top,
            w: 140,
            h: 80
        };

        // ── PATHWAYS ──
        L.pathRing = {
            cx: ns.cx,
            cy: ns.cy,
            w: ns.w - 160,
            h: ns.h - 140,
            thickness: 50
        };

        return L;
    }

    /* ════════════════════════════════════════════════════
       CREATE — pure layout, no decoration
       ════════════════════════════════════════════════════ */
    create() {
        NPCManager.destroyAll(this); // Clean registry from any previous Haven session

        this.state = this.playerState;
        if (this.state.vehicleHealth === undefined) this.state.vehicleHealth = 100;

        const L = this._layout();
        this.L = L;

        // State
        this.stations = [];
        this.popupActive = false;
        this.popupElements = [];
        this.parkingSpots = [];
        this._phase = 'driving';
        this._playerParked = false;

        // World & physics bounds
        this.physics.world.setBounds(0, 0, L.worldW, L.worldH);
        this.cameras.main.setBounds(0, 0, L.worldW, L.worldH);
        this.cameras.main.setBackgroundColor('#080806');

        // Collision group
        this.walls = this.physics.add.staticGroup();

        // ── BUILD ZONES ──
        this._buildBackground(L);
        this._buildRoad(L);
        this._buildEntranceTunnel(L);
        this._buildExitTunnel(L);
        this._buildSouthSquare(L);
        this._buildParkway(L);
        this._buildConnector(L);
        this._buildNorthSquare(L);
        this._buildBranches(L);
        this._buildRooms(L);
        this._buildPortal(L);
        this._buildPathways(L);
        this._buildEnvironmentDetails(L);
        this._buildGates(L);
        this._buildExitZone(L);

        // Refresh all static bodies so physics tree is correct
        this.walls.refresh();

        this._buildPatrolNPCs(L);
        this._buildUI();

        // ── START DRIVE-IN ──
        this._startDriveIn(L);
        SceneTransition.fadeIn(this, 600);

    }

    /* ═══════════════════════════════════════════════════════════════
       CAVERN BACKGROUND — deep underground cave environment
       Replaces flat black with mottled rock, formations, stalactites,
       mineral veins, puddles, rubble, and edge fog.
       All at depth 0–0.25 (below structure floors at 0.3).
       ═══════════════════════════════════════════════════════════════ */
    _buildBackground(L) {
        // Seeded PRNG for deterministic cave generation
        const seed = 7919;
        let _s = seed;
        const rng = () => { _s = (_s * 16807 + 0) % 2147483647; return (_s & 0x7fffffff) / 0x7fffffff; };
        const rngRange = (min, max) => min + rng() * (max - min);
        const rngInt = (min, max) => Math.floor(rngRange(min, max + 1));
        const rngPick = (arr) => arr[Math.floor(rng() * arr.length)];

        // ── Structure exclusion zones (padded) ──
        const pad = 20;
        const ns = L.northSquare, ss = L.southSquare, cn = L.connector;
        const exclusions = [
            // Road corridor full width
            { l: -pad, r: L.worldW + pad, t: L.roadY - L.roadH/2 - pad, b: L.roadY + L.roadH/2 + pad },
            // South square
            { l: ss.left - pad, r: ss.right + pad, t: ss.top - pad, b: ss.bot + pad },
            // Connector
            { l: cn.cx - cn.w/2 - pad, r: cn.cx + cn.w/2 + pad, t: cn.top - pad, b: cn.bot + pad },
            // North square
            { l: ns.left - pad, r: ns.right + pad, t: ns.top - pad, b: ns.bot + pad },
        ];
        // Branches + rooms
        Object.values(L.branches).forEach(b => {
            exclusions.push({ l: b.cx - b.w/2 - pad, r: b.cx + b.w/2 + pad, t: b.cy - b.h/2 - pad, b: b.cy + b.h/2 + pad });
        });
        Object.values(L.rooms).forEach(r => {
            exclusions.push({ l: r.cx - r.w/2 - pad, r: r.cx + r.w/2 + pad, t: r.cy - r.h/2 - pad, b: r.cy + r.h/2 + pad });
        });

        const isExcluded = (x, y) => exclusions.some(e => x >= e.l && x <= e.r && y >= e.t && y <= e.b);

        // ── COLOR PALETTES ──
        const rockDark = [0x0a0a08, 0x0c0b09, 0x0e0d0a, 0x09080a, 0x0b0a07];
        const rockMid  = [0x141210, 0x161412, 0x121014, 0x151311, 0x131110];
        const rockLight = [0x1c1a16, 0x1e1c18, 0x1a1820, 0x201e1a, 0x1d1b17];
        const mineralColors = [0x2a3a4a, 0x3a2a3a, 0x2a3a2a, 0x4a3a2a, 0x3a4a4a];

        // ═══ LAYER 1: Base ground — mottled rock floor ═══
        const gFloor = this.add.graphics().setDepth(0);
        // Base fill
        gFloor.fillStyle(0x080806, 1);
        gFloor.fillRect(0, 0, L.worldW, L.worldH);

        // Mottled patches — large overlapping blobs
        for (let i = 0; i < 300; i++) {
            const px = rngRange(-50, L.worldW + 50);
            const py = rngRange(-50, L.worldH + 50);
            const pw = rngRange(40, 180);
            const ph = rngRange(30, 140);
            const col = rngPick(rockDark);
            const alpha = rngRange(0.15, 0.5);
            gFloor.fillStyle(col, alpha);
            gFloor.fillRect(px - pw/2, py - ph/2, pw, ph);
        }

        // Finer grain texture
        for (let i = 0; i < 500; i++) {
            const px = rngRange(0, L.worldW);
            const py = rngRange(0, L.worldH);
            const pw = rngRange(8, 40);
            const ph = rngRange(6, 30);
            const col = rng() > 0.5 ? rngPick(rockDark) : rngPick(rockMid);
            gFloor.fillStyle(col, rngRange(0.1, 0.35));
            gFloor.fillRect(px - pw/2, py - ph/2, pw, ph);
        }

        // ═══ LAYER 2: Mineral veins — thin colored streaks ═══
        const gVeins = this.add.graphics().setDepth(0.06);
        for (let i = 0; i < 40; i++) {
            const sx = rngRange(0, L.worldW);
            const sy = rngRange(0, L.worldH);
            if (isExcluded(sx, sy)) continue;
            const col = rngPick(mineralColors);
            gVeins.lineStyle(rngRange(1, 2.5), col, rngRange(0.08, 0.2));
            gVeins.beginPath();
            gVeins.moveTo(sx, sy);
            let cx = sx, cy = sy;
            const segs = rngInt(3, 8);
            for (let s = 0; s < segs; s++) {
                cx += rngRange(-60, 60);
                cy += rngRange(-40, 40);
                gVeins.lineTo(cx, cy);
            }
            gVeins.strokePath();
        }

        // ═══ LAYER 3: Puddles — dark reflective patches ═══
        const gPuddles = this.add.graphics().setDepth(0.07);
        for (let i = 0; i < 25; i++) {
            const px = rngRange(100, L.worldW - 100);
            const py = rngRange(100, L.worldH - 100);
            if (isExcluded(px, py)) continue;
            const pw = rngRange(15, 50);
            const ph = rngRange(10, 30);
            // Dark water base
            gPuddles.fillStyle(0x060810, rngRange(0.3, 0.6));
            gPuddles.fillEllipse(px, py, pw, ph);
            // Subtle highlight edge (reflection)
            gPuddles.lineStyle(1, 0x1a2030, rngRange(0.15, 0.3));
            gPuddles.strokeEllipse(px, py, pw + 2, ph + 1);
        }

        // ═══ LAYER 4: Rock formations — ¾ iso boulders/masses ═══
        // These go in the empty zones: world edges, corners, spaces between structures.
        const gRock = this.add.graphics().setDepth(0.15);

        // Helper: draw a ¾ iso rock formation (front face + top strip)
        const drawRock = (x, y, w, h, topH) => {
            const col = rngPick(rockMid);
            const colDark = rngPick(rockDark);
            const colLight = rngPick(rockLight);
            // Front face
            gRock.fillStyle(col, rngRange(0.6, 0.9));
            gRock.fillRect(x - w/2, y - h, w, h);
            // Top strip
            gRock.fillStyle(colLight, rngRange(0.4, 0.7));
            gRock.fillRect(x - w/2, y - h - topH, w, topH);
            // Bottom edge
            gRock.fillStyle(colDark, 0.5);
            gRock.fillRect(x - w/2, y - 1, w, 2);
            // Cracks
            if (w > 20) {
                gRock.lineStyle(1, colDark, rngRange(0.2, 0.4));
                const crackX = x + rngRange(-w/4, w/4);
                gRock.lineBetween(crackX, y - h, crackX + rngRange(-5, 5), y);
            }
        };

        // Scatter rock formations — avoid exclusion zones
        const rockZones = [
            // Top of world — dense
            { l: 0, r: L.worldW, t: 0, b: ns.top - 80, density: 60 },
            // Bottom of world (below road)
            { l: 0, r: L.worldW, t: L.roadY + L.roadH/2 + 40, b: L.worldH, density: 30 },
            // Left side
            { l: 0, r: ns.left - 250, t: ns.top, b: ss.bot, density: 25 },
            // Right side
            { l: ns.right + 250, r: L.worldW, t: ns.top, b: ss.bot, density: 25 },
        ];

        rockZones.forEach(zone => {
            for (let i = 0; i < zone.density; i++) {
                const rx = rngRange(zone.l + 20, zone.r - 20);
                const ry = rngRange(zone.t + 20, zone.b - 20);
                if (isExcluded(rx, ry)) continue;
                const rw = rngRange(12, 60);
                const rh = rngRange(8, 35);
                const rt = rngRange(2, 6);
                drawRock(rx, ry, rw, rh, rt);
            }
        });

        // ═══ LAYER 5: Stalactites — hanging from cave ceiling ═══
        // In ¾ iso, ceiling formations appear near the top of the world.
        // They point downward: wide base at top, narrowing to a tip.
        const gStal = this.add.graphics().setDepth(0.18);

        const drawStalactite = (x, baseY, w, h) => {
            const col = rngPick(rockMid);
            const colDark = rngPick(rockDark);
            const tipY = baseY + h;
            // Main body — trapezoid narrowing downward
            gStal.fillStyle(col, rngRange(0.5, 0.8));
            gStal.beginPath();
            gStal.moveTo(x - w/2, baseY);
            gStal.lineTo(x + w/2, baseY);
            gStal.lineTo(x + w/6, tipY);
            gStal.lineTo(x - w/6, tipY);
            gStal.closePath();
            gStal.fillPath();
            // Highlight left edge
            gStal.lineStyle(1, rngPick(rockLight), rngRange(0.15, 0.3));
            gStal.lineBetween(x - w/2, baseY, x - w/6, tipY);
            // Dark right edge
            gStal.lineStyle(1, colDark, rngRange(0.2, 0.4));
            gStal.lineBetween(x + w/2, baseY, x + w/6, tipY);
            // Drip at tip
            if (rng() > 0.6) {
                gStal.fillStyle(0x0a1020, rngRange(0.2, 0.4));
                gStal.fillCircle(x, tipY + 2, rngRange(1, 2.5));
            }
        };

        // Stalactites along top edge
        for (let i = 0; i < 50; i++) {
            const sx = rngRange(30, L.worldW - 30);
            const baseY = rngRange(-5, 60);
            const sw = rngRange(8, 30);
            const sh = rngRange(20, 80);
            drawStalactite(sx, baseY, sw, sh);
        }
        // Some deeper stalactites in the upper cavern void
        for (let i = 0; i < 20; i++) {
            const sx = rngRange(30, L.worldW - 30);
            const baseY = rngRange(60, 200);
            if (isExcluded(sx, baseY + 40)) continue;
            const sw = rngRange(6, 20);
            const sh = rngRange(15, 50);
            drawStalactite(sx, baseY, sw, sh);
        }

        // ═══ LAYER 6: Stalagmites — rising from cave floor ═══
        // ¾ iso: front face visible, thin top. Base at ground, point upward.
        const drawStalagmite = (x, groundY, w, h) => {
            const col = rngPick(rockMid);
            const colLight = rngPick(rockLight);
            const topY = groundY - h;
            // Main body — trapezoid narrowing upward
            gStal.fillStyle(col, rngRange(0.5, 0.8));
            gStal.beginPath();
            gStal.moveTo(x - w/2, groundY);
            gStal.lineTo(x + w/2, groundY);
            gStal.lineTo(x + w/6, topY);
            gStal.lineTo(x - w/6, topY);
            gStal.closePath();
            gStal.fillPath();
            // Top cap — foreshortened
            gStal.fillStyle(colLight, rngRange(0.3, 0.5));
            gStal.fillRect(x - w/6, topY - 2, w/3, 2);
            // Base shadow
            gStal.fillStyle(0x040404, 0.3);
            gStal.fillEllipse(x, groundY + 2, w + 4, 4);
        };

        // Scatter in empty zones
        const stalagZones = [
            { l: 0, r: L.worldW, t: 80, b: ns.top - 60, density: 30 },
            { l: 0, r: L.worldW, t: L.roadY + L.roadH/2 + 30, b: L.worldH - 20, density: 15 },
            { l: 0, r: ns.left - 260, t: ns.top, b: ss.bot, density: 12 },
            { l: ns.right + 260, r: L.worldW, t: ns.top, b: ss.bot, density: 12 },
        ];
        stalagZones.forEach(zone => {
            for (let i = 0; i < zone.density; i++) {
                const sx = rngRange(zone.l + 15, zone.r - 15);
                const sy = rngRange(zone.t, zone.b);
                if (isExcluded(sx, sy)) continue;
                const sw = rngRange(6, 22);
                const sh = rngRange(10, 40);
                drawStalagmite(sx, sy, sw, sh);
            }
        });

        // ═══ LAYER 7: Rubble — small rock debris near structure edges ═══
        const gRubble = this.add.graphics().setDepth(0.12);
        // Scatter near each exclusion zone edge
        exclusions.forEach(e => {
            const edgePad = 30;
            for (let i = 0; i < 8; i++) {
                // Pick a random edge of this exclusion zone
                const side = rngInt(0, 3);
                let rx, ry;
                if (side === 0) { rx = rngRange(e.l, e.r); ry = e.t - rngRange(5, edgePad); }
                else if (side === 1) { rx = rngRange(e.l, e.r); ry = e.b + rngRange(5, edgePad); }
                else if (side === 2) { rx = e.l - rngRange(5, edgePad); ry = rngRange(e.t, e.b); }
                else { rx = e.r + rngRange(5, edgePad); ry = rngRange(e.t, e.b); }
                if (rx < 5 || rx > L.worldW - 5 || ry < 5 || ry > L.worldH - 5) continue;
                if (isExcluded(rx, ry)) continue;
                // Small irregular rock chunk
                const rw = rngRange(3, 10);
                const rh = rngRange(2, 7);
                gRubble.fillStyle(rngPick(rockMid), rngRange(0.3, 0.6));
                gRubble.fillRect(rx - rw/2, ry - rh/2, rw, rh);
            }
        });

        // ═══ LAYER 8: Edge fog — darkness vignette at world borders ═══
        const gFog = this.add.graphics().setDepth(0.22);
        const fogW = 200;  // fog band width

        // Top fog — dense (ceiling)
        for (let i = 0; i < 12; i++) {
            const t = i / 12;
            gFog.fillStyle(0x020202, (1 - t) * 0.7);
            gFog.fillRect(0, t * fogW, L.worldW, fogW / 12 + 4);
        }
        // Bottom fog
        for (let i = 0; i < 8; i++) {
            const t = i / 8;
            gFog.fillStyle(0x020202, (1 - t) * 0.5);
            gFog.fillRect(0, L.worldH - fogW + t * fogW, L.worldW, fogW / 8 + 4);
        }
        // Left fog
        for (let i = 0; i < 10; i++) {
            const t = i / 10;
            gFog.fillStyle(0x020202, (1 - t) * 0.6);
            gFog.fillRect(t * fogW, 0, fogW / 10 + 4, L.worldH);
        }
        // Right fog
        for (let i = 0; i < 10; i++) {
            const t = i / 10;
            gFog.fillStyle(0x020202, (1 - t) * 0.6);
            gFog.fillRect(L.worldW - fogW + t * fogW, 0, fogW / 10 + 4, L.worldH);
        }

        // ═══ LAYER 9: Ceiling shadow near structures ═══
        // A subtle dark gradient above the north square to suggest low ceiling
        const gCeiling = this.add.graphics().setDepth(0.2);
        const ceilTop = ns.top - 120;
        const ceilBot = ns.top - 30;
        for (let i = 0; i < 6; i++) {
            const t = i / 6;
            const y = ceilTop + t * (ceilBot - ceilTop);
            gCeiling.fillStyle(0x040404, (1 - t) * 0.35);
            gCeiling.fillRect(ns.left - 100, y, ns.w + 200, (ceilBot - ceilTop) / 6 + 2);
        }
    }

    /* ═══════════════════════════════════════════════════════
       ROAD — runs along bottom, entrance left to exit right
       ═══════════════════════════════════════════════════════ */
    _buildRoad(L) {
        const g = this.add.graphics().setDepth(0.5);
        const ry = L.roadY, hR = L.roadH / 2;
        const rTop = ry - hR, rBot = ry + hR;

        // ── Base surface ──
        g.fillStyle(0x1a1814, 1);
        g.fillRect(0, rTop, L.worldW, L.roadH);

        // ── Asphalt wear — mottled patches ──
        const seed = 4219;
        let _s = seed;
        const rng = () => { _s = (_s * 16807) % 2147483647; return (_s & 0x7fffffff) / 0x7fffffff; };
        const rngR = (a, b) => a + rng() * (b - a);

        for (let i = 0; i < 80; i++) {
            const px = rngR(0, L.worldW);
            const py = rngR(rTop + 3, rBot - 3);
            const pw = rngR(20, 100);
            const ph = rngR(4, 14);
            g.fillStyle(rng() > 0.5 ? 0x1e1c16 : 0x161410, rngR(0.15, 0.4));
            g.fillRect(px - pw/2, py - ph/2, pw, ph);
        }

        // ── Edge lines — worn yellow paint ──
        for (let x = 0; x < L.worldW; x += rngR(3, 8)) {
            const w = rngR(2, 5);
            const a = rngR(0.15, 0.4);
            g.fillStyle(0x44402a, a);
            g.fillRect(x, rTop, w, 2);
            g.fillRect(x, rBot - 2, w, 2);
        }

        // ── Center dashes ──
        for (let x = 0; x < L.worldW; x += 40) {
            const dashW = rngR(16, 24);
            const a = rngR(0.2, 0.45);
            g.fillStyle(0x2a2820, a);
            g.fillRect(x, ry - 1, dashW, 2);
        }

        // ── Tire tracks — faint parallel lines ──
        const trackOffsets = [-10, -8, 8, 10];
        trackOffsets.forEach(off => {
            g.lineStyle(1, 0x0e0c08, rngR(0.1, 0.25));
            g.beginPath();
            let cx = 0;
            g.moveTo(0, ry + off);
            while (cx < L.worldW) {
                cx += rngR(20, 60);
                g.lineTo(cx, ry + off + rngR(-1, 1));
            }
            g.strokePath();
        });

        // ── Drain grates — periodic metal inserts ──
        for (let x = 200; x < L.worldW; x += rngR(250, 400)) {
            const gx = x, gy = rBot - 6;
            g.fillStyle(0x222018, 0.7);
            g.fillRect(gx - 8, gy - 3, 16, 6);
            g.lineStyle(1, 0x0a0a08, 0.5);
            for (let s = -6; s <= 6; s += 3) {
                g.lineBetween(gx + s, gy - 2, gx + s, gy + 2);
            }
        }

        // ── Oil stains — dark splotches ──
        for (let i = 0; i < 12; i++) {
            const ox = rngR(100, L.worldW - 100);
            const oy = rngR(rTop + 6, rBot - 6);
            g.fillStyle(0x0a0808, rngR(0.15, 0.35));
            g.fillEllipse(ox, oy, rngR(8, 25), rngR(4, 12));
        }

        // ── Crack lines ──
        for (let i = 0; i < 15; i++) {
            const sx = rngR(50, L.worldW - 50);
            const sy = rngR(rTop + 4, rBot - 4);
            g.lineStyle(1, 0x0e0c08, rngR(0.15, 0.3));
            g.beginPath();
            g.moveTo(sx, sy);
            let cx2 = sx, cy2 = sy;
            for (let s = 0; s < rngR(2, 5); s++) {
                cx2 += rngR(-15, 15);
                cy2 += rngR(-6, 6);
                cy2 = Math.max(rTop + 2, Math.min(rBot - 2, cy2));
                g.lineTo(cx2, cy2);
            }
            g.strokePath();
        }

        // ── Tunnel lighting strips — amber dots along road inside tunnels ──
        const gLights = this.add.graphics().setDepth(0.55);
        [L.entranceTunnel, L.exitTunnel].forEach(tun => {
            const tLeft = tun.x || 0;
            const tRight = tLeft + tun.w;
            for (let x = tLeft + 30; x < tRight; x += 60) {
                // Top strip light
                gLights.fillStyle(0x665522, 0.5);
                gLights.fillCircle(x, rTop + 4, 2);
                gLights.fillStyle(0x886633, 0.15);
                gLights.fillCircle(x, rTop + 4, 6);
                // Bottom strip light
                gLights.fillStyle(0x665522, 0.5);
                gLights.fillCircle(x, rBot - 4, 2);
                gLights.fillStyle(0x886633, 0.15);
                gLights.fillCircle(x, rBot - 4, 6);
            }
        });

        // ── Ramp transition — road meets parkway ──
        // Visual ramp area where road widens into parkway pull-off
        const p = L.parkway;
        const rampG = this.add.graphics().setDepth(0.48);
        // Angled ramp fill connecting road surface to parkway bottom
        rampG.fillStyle(0x181610, 0.8);
        rampG.beginPath();
        rampG.moveTo(p.left - p.angleInset - 20, rTop);
        rampG.lineTo(p.right + p.angleInset + 20, rTop);
        rampG.lineTo(p.right + p.angleInset, rTop);
        rampG.lineTo(p.left - p.angleInset, rTop);
        rampG.closePath();
        rampG.fillPath();
        // Chevron arrows pointing up from road into parkway
        const chevG = this.add.graphics().setDepth(0.52);
        for (let i = 0; i < 3; i++) {
            const cy = rTop - 4 - i * 12;
            const cx = p.cx;
            chevG.lineStyle(1.5, 0x2a2820, 0.3 - i * 0.08);
            chevG.beginPath();
            chevG.moveTo(cx - 10, cy + 5);
            chevG.lineTo(cx, cy);
            chevG.lineTo(cx + 10, cy + 5);
            chevG.strokePath();
        }
    }

    /* ════════════════════════════════════════════════════
       ENTRANCE TUNNEL (west side)
       ════════════════════════════════════════════════════ */
    _buildEntranceTunnel(L) {
        const t = L.entranceTunnel;
        const halfRoad = L.roadH / 2;
        const wt = L.southSquare.wallThick;  // match south square wall thickness

        // Tunnel floor
        this.add.rectangle(t.w / 2, t.y, t.w, t.h + 6, 0x141210).setDepth(0.4);

        // North wall — runs from x=0 to south square left edge
        this._addIsoWall(t.w / 2, t.y - halfRoad, t.w, 'north');

        // South wall
        this._addIsoWall(t.w / 2, t.y + halfRoad, t.w, 'south');
    }

    /* ════════════════════════════════════════════════════
       EXIT TUNNEL (east side)
       ════════════════════════════════════════════════════ */
    _buildExitTunnel(L) {
        const t = L.exitTunnel;
        const halfRoad = L.roadH / 2;
        const wt = L.southSquare.wallThick;  // match south square wall thickness
        const tunnelLeft = t.x;
        const tunnelRight = t.x + t.w;
        const tunnelCX = (tunnelLeft + tunnelRight) / 2;

        // Tunnel floor
        this.add.rectangle(tunnelCX, t.y, t.w, t.h + 6, 0x141210).setDepth(0.4);

        // North wall
        this._addIsoWall(tunnelCX, t.y - halfRoad, t.w, 'north');

        // South wall
        this._addIsoWall(tunnelCX, t.y + halfRoad, t.w, 'south');
    }

    /* ════════════════════════════════════════════════════
       SOUTH SQUARE (garage area)
       ════════════════════════════════════════════════════ */
    _buildSouthSquare(L) {
        const s = L.southSquare;

        // Floor
        this.add.rectangle(s.cx, s.cy, s.w, s.h, 0x14120e).setDepth(0.3);

        // Wall module — north has connector gap, E/W have road gaps
        this._buildWallModule(
            { left: s.left, right: s.right, top: s.top, bot: s.bot },
            [
                { wall: 'north', center: s.cx, size: L.connector.w },
                { wall: 'east', center: L.roadY, size: L.roadH },
                { wall: 'west', center: L.roadY, size: L.roadH }
            ]
        );

        // ── ELECTRONIC BOUNTY BOARD (north wall, right side) ──
        const connHalf = L.connector.w / 2;
        const bbX = (s.cx + connHalf + s.right) / 2;
        const bbY = s.top - this.WALL.frontH / 2;
        const bbG = this.add.graphics().setDepth(2.5);
        // Mounting bracket
        bbG.fillStyle(0x2a2622, 0.9);
        bbG.fillRect(bbX - 32, bbY - 14, 64, 28);
        // Screen bezel
        bbG.fillStyle(0x1a1818, 1);
        bbG.fillRect(bbX - 28, bbY - 11, 56, 22);
        // Screen surface
        bbG.fillStyle(0x0a1a18, 1);
        bbG.fillRect(bbX - 26, bbY - 9, 52, 18);
        // Scanlines
        for (let sy = bbY - 8; sy < bbY + 8; sy += 2) {
            bbG.fillStyle(0x0a2a24, 0.15);
            bbG.fillRect(bbX - 25, sy, 50, 1);
        }
        // Data rows
        bbG.fillStyle(0x33aa66, 0.6);
        bbG.fillRect(bbX - 22, bbY - 6, 36, 2);
        bbG.fillStyle(0x33aa66, 0.4);
        bbG.fillRect(bbX - 22, bbY - 2, 28, 2);
        bbG.fillRect(bbX - 22, bbY + 2, 32, 2);
        bbG.fillStyle(0xaa6633, 0.5);
        bbG.fillRect(bbX + 18, bbY - 6, 6, 2);
        bbG.fillRect(bbX + 14, bbY - 2, 10, 2);
        // Status LED + cable
        bbG.fillStyle(0x33cc44, 0.8);
        bbG.fillCircle(bbX + 26, bbY - 10, 1.5);
        bbG.lineStyle(1, 0x2a2622, 0.6);
        bbG.lineBetween(bbX + 30, bbY, bbX + 34, bbY + 8);
        this.add.text(bbX, bbY + 14, 'BOUNTY NET', { fontFamily: CONFIG.font, fontSize: '5px', fill: '#33aa66' }).setOrigin(0.5).setDepth(2.6);
        this._bountyBoardPos = { x: bbX, y: bbY + 20 };
        this._stashPos = { x: L.rooms.stash.cx, y: L.rooms.stash.cy };
        const screenGlow = this.add.rectangle(bbX, bbY, 52, 18, 0x33aa66, 0.03).setDepth(2.55);
        this.tweens.add({ targets: screenGlow, alpha: { from: 0.01, to: 0.06 }, duration: 800, yoyo: true, repeat: -1 });

        // ── WALL DETAILS — pipes, conduits, grime ──
        const wdG = this.add.graphics().setDepth(2.2);
        const pipeY = s.top - this.WALL.frontH * 0.7;
        wdG.fillStyle(0x3a3630, 0.6);
        wdG.fillRect(s.left + 12, pipeY, s.cx - connHalf - s.left - 20, 3);
        wdG.fillStyle(0x4a4640, 0.3);
        wdG.fillRect(s.left + 12, pipeY - 1, s.cx - connHalf - s.left - 20, 1);
        for (let px = s.left + 32; px < s.cx - connHalf - 8; px += 40) {
            wdG.fillStyle(0x2a2622, 0.7);
            wdG.fillRect(px, pipeY - 2, 4, 7);
        }
        wdG.fillStyle(0x2a2828, 0.5);
        wdG.fillRect(s.right - 20, s.bot - this.WALL.frontH, 2, this.WALL.frontH - 4);
        wdG.fillStyle(0x0a0a08, 0.15);
        wdG.fillEllipse(s.left + 40, s.top - 8, 30, 6);
        wdG.fillEllipse(s.right - 50, s.top - 10, 25, 5);
        const ventX = s.left + 30, ventY = s.bot - this.WALL.frontH / 2;
        wdG.fillStyle(0x222018, 0.7);
        wdG.fillRect(ventX - 8, ventY - 5, 16, 10);
        wdG.lineStyle(1, 0x0a0a08, 0.5);
        for (let vs = ventX - 6; vs <= ventX + 6; vs += 3) wdG.lineBetween(vs, ventY - 4, vs, ventY + 4);
    }

    /* ═══════════════════════════════════════════════════════
       PARKWAY (8-spot vehicle parking, inside south square)
       ═══════════════════════════════════════════════════════ */
    _buildParkway(L) {
        const p = L.parkway;
        const ai = p.angleInset;
        const seed = 5531;
        let _s = seed;
        const rng = () => { _s = (_s * 16807) % 2147483647; return (_s & 0x7fffffff) / 0x7fffffff; };
        const rngR = (a, b) => a + rng() * (b - a);

        const g = this.add.graphics().setDepth(0.34);
        // Base surface
        g.fillStyle(0x1a1610, 1);
        g.beginPath();
        g.moveTo(p.left, p.top); g.lineTo(p.right, p.top);
        g.lineTo(p.right + ai, p.bot); g.lineTo(p.left - ai, p.bot);
        g.closePath(); g.fillPath();
        // Surface texture
        for (let i = 0; i < 40; i++) {
            const px = rngR(p.left - ai/2, p.right + ai/2);
            const py = rngR(p.top + 2, p.bot - 2);
            const t = (py - p.top) / (p.bot - p.top);
            const edgeL = p.left - ai * t, edgeR = p.right + ai * t;
            if (px < edgeL || px > edgeR) continue;
            g.fillStyle(rng() > 0.5 ? 0x1e1c14 : 0x141210, rngR(0.15, 0.4));
            g.fillRect(px - rngR(5, 20), py - rngR(2, 6), rngR(10, 40), rngR(4, 12));
        }
        // Curb
        const curbG = this.add.graphics().setDepth(0.296);
        curbG.fillStyle(0x2a2822, 0.8);
        curbG.fillRect(p.left + 2, p.top - 2, p.right - p.left - 4, 3);
        curbG.lineStyle(2.5, 0x2a2822, 0.7);
        curbG.lineBetween(p.left, p.top, p.left - ai, p.bot);
        curbG.lineBetween(p.right, p.top, p.right + ai, p.bot);

        // Parking spot data only
        const spotsPerRow = 4;
        const rowStartX = p.cx - p.w / 2 + p.spotW / 2 + 15;
        const gap = (p.w - 30) / spotsPerRow;
        const topY = p.cy - p.h / 4, botY = p.cy + p.h / 4;
        [topY, botY].forEach((rowY, rowIdx) => {
            for (let i = 0; i < spotsPerRow; i++) {
                this.parkingSpots.push({ x: rowStartX + i * gap, y: rowY, occupied: false, idx: rowIdx * spotsPerRow + i });
            }
        });

        // Blend strip
        const blendG = this.add.graphics().setDepth(0.42);
        for (let i = 0; i < 6; i++) {
            const t = i / 6, by = p.bot - 4 + t * 8;
            blendG.fillStyle(0x181610, (1 - t) * 0.3);
            blendG.fillRect(p.cx - ((p.right+ai)-(p.left-ai))/2, by, (p.right+ai)-(p.left-ai), 2);
        }

        // ── RAILING — metal railing along the pathway from parkway to connector ──
        const pathW = 50;
        const sCX = L.southSquare.cx;
        const railG = this.add.graphics().setDepth(3.0);
        const railTop = p.top;
        const railBot = L.southSquare.top; // path goes up to north wall
        const railH = railBot - railTop;

        // Left railing
        const rlx = sCX - pathW/2 - 3;
        railG.fillStyle(0x3a3830, 0.7);
        railG.fillRect(rlx, railTop, 2, railH);
        railG.fillStyle(0x4a4840, 0.35);
        railG.fillRect(rlx - 1, railTop, 1, railH);
        // Posts
        for (let ry = railTop; ry < railBot; ry += 30) {
            railG.fillStyle(0x3a3830, 0.8);
            railG.fillRect(rlx - 1, ry, 4, 6);
            railG.fillStyle(0x4a4840, 0.4);
            railG.fillRect(rlx - 1, ry - 1, 4, 1);
        }

        // Right railing
        const rrx = sCX + pathW/2 + 1;
        railG.fillStyle(0x3a3830, 0.7);
        railG.fillRect(rrx, railTop, 2, railH);
        railG.fillStyle(0x4a4840, 0.35);
        railG.fillRect(rrx + 2, railTop, 1, railH);
        for (let ry = railTop; ry < railBot; ry += 30) {
            railG.fillStyle(0x3a3830, 0.8);
            railG.fillRect(rrx - 1, ry, 4, 6);
            railG.fillStyle(0x4a4840, 0.4);
            railG.fillRect(rrx - 1, ry - 1, 4, 1);
        }
    }

    /* ════════════════════════════════════════════════════
       CONNECTOR TUNNEL (south square → north square)
       ════════════════════════════════════════════════════ */
    _buildConnector(L) {
        const c = L.connector;
        const W = this.WALL;

        // Floor
        this.add.rectangle(c.cx, c.cy, c.w, c.h, 0x12100c).setDepth(0.3);

        // Side walls span between the two squares with overlap
        const sideTop = L.southSquare.top - W.frontH - W.topH;
        const sideBot = L.northSquare.bot;
        this._addSideWall(c.cx - c.w / 2, sideTop, sideBot, 'west');
        this._addSideWall(c.cx + c.w / 2, sideTop, sideBot, 'east');
    }

    /* ════════════════════════════════════════════════════
       NORTH SQUARE (main hub area)
       ════════════════════════════════════════════════════ */
    _buildNorthSquare(L) {
        const n = L.northSquare;
        const branchW = L.branches.leftTop.h;
        const portalW = L.portal.w + 8;
        this.add.rectangle(n.cx, n.cy, n.w, n.h, 0x16140e).setDepth(0.3);
        this._buildWallModule(
            { left: n.left, right: n.right, top: n.top, bot: n.bot },
            [
                { wall: 'north', center: n.cx, size: portalW },
                { wall: 'south', center: n.cx, size: L.connector.w },
                { wall: 'west', center: L.branches.leftTop.cy, size: branchW },
                { wall: 'west', center: L.branches.leftBot.cy, size: branchW },
                { wall: 'east', center: L.branches.rightTop.cy, size: branchW },
                { wall: 'east', center: L.branches.rightBot.cy, size: branchW }
            ]
        );

        // ═══ MASSIVE CRYSTAL FORMATION — center of north square ═══
        const seed = 8831;
        let _s = seed;
        const rng = () => { _s = (_s * 16807) % 2147483647; return (_s & 0x7fffffff) / 0x7fffffff; };
        const rngR = (a, b) => a + rng() * (b - a);
        const ccx = n.cx, ccy = n.cy;

        const colors = {
            purple: { face: 0x6a3a8a, light: 0x8a5aaa, dark: 0x4a2a6a, glow: 0x9966cc },
            blue:   { face: 0x3a5a8a, light: 0x5a7aaa, dark: 0x2a3a6a, glow: 0x6699cc },
            teal:   { face: 0x3a7a6a, light: 0x5a9a8a, dark: 0x2a5a4a, glow: 0x66ccaa },
        };
        const hues = ['purple', 'blue', 'teal'];

        // Helper: draw a single ¾ iso crystal shard
        const drawCrystal = (g, x, groundY, w, h, hue) => {
            const tipY = groundY - h;
            const midY = groundY - h * 0.6;
            const c = colors[hue] || colors.purple;
            // Base shadow
            g.fillStyle(0x0a0a0a, 0.35);
            g.fillEllipse(x, groundY + 2, w + 6, 4);
            // Left facet
            g.fillStyle(c.dark, 0.9);
            g.beginPath();
            g.moveTo(x - w/2, groundY); g.lineTo(x - w/4, midY);
            g.lineTo(x, tipY); g.lineTo(x - 1, groundY);
            g.closePath(); g.fillPath();
            // Right facet
            g.fillStyle(c.face, 0.9);
            g.beginPath();
            g.moveTo(x + w/2, groundY); g.lineTo(x + w/4, midY);
            g.lineTo(x, tipY); g.lineTo(x + 1, groundY);
            g.closePath(); g.fillPath();
            // Center highlight
            g.fillStyle(c.light, 0.35);
            g.beginPath();
            g.moveTo(x - w/6, groundY - h*0.15); g.lineTo(x, tipY + h*0.1);
            g.lineTo(x + w/6, groundY - h*0.15);
            g.closePath(); g.fillPath();
            // Edges
            g.lineStyle(1, c.light, 0.4);
            g.lineBetween(x - w/2, groundY, x, tipY);
            g.lineBetween(x + w/2, groundY, x, tipY);
        };

        // ── Rock base platform ──
        const baseG = this.add.graphics().setDepth(2.8);
        // Large irregular rock base
        baseG.fillStyle(0x1a181a, 0.85);
        baseG.beginPath();
        baseG.moveTo(ccx - 50, ccy + 22); baseG.lineTo(ccx - 38, ccy - 12);
        baseG.lineTo(ccx - 10, ccy - 20); baseG.lineTo(ccx + 15, ccy - 18);
        baseG.lineTo(ccx + 45, ccy - 8); baseG.lineTo(ccx + 55, ccy + 20);
        baseG.lineTo(ccx + 40, ccy + 26); baseG.lineTo(ccx - 42, ccy + 26);
        baseG.closePath(); baseG.fillPath();
        // Rock top surface
        baseG.fillStyle(0x222024, 0.55);
        baseG.fillRect(ccx - 48, ccy + 22, 96, 5);
        // Rock cracks
        baseG.lineStyle(1, 0x0e0e10, 0.3);
        baseG.lineBetween(ccx - 20, ccy + 24, ccx - 15, ccy - 10);
        baseG.lineBetween(ccx + 10, ccy + 25, ccx + 18, ccy - 5);

        // ── Main crystal cluster — 8 large shards ──
        const gMain = this.add.graphics().setDepth(3.2);
        drawCrystal(gMain, ccx, ccy + 10, 28, 90, 'purple');
        drawCrystal(gMain, ccx - 18, ccy + 14, 22, 70, 'blue');
        drawCrystal(gMain, ccx + 16, ccy + 12, 20, 78, 'teal');
        drawCrystal(gMain, ccx - 8, ccy + 8, 16, 95, 'purple');
        drawCrystal(gMain, ccx + 24, ccy + 16, 18, 55, 'blue');
        drawCrystal(gMain, ccx - 28, ccy + 18, 14, 52, 'teal');
        drawCrystal(gMain, ccx + 8, ccy + 6, 12, 85, 'purple');
        drawCrystal(gMain, ccx - 12, ccy + 20, 20, 45, 'blue');

        // Collision for central cluster
        this._addWall(ccx, ccy + 10, 70, 40);

        // ── Ambient glow layers ──
        const glowG = this.add.graphics().setDepth(2.7);
        glowG.fillStyle(0x6633aa, 0.07);
        glowG.fillCircle(ccx, ccy, 80);
        glowG.fillStyle(0x6633aa, 0.04);
        glowG.fillCircle(ccx, ccy, 130);
        glowG.fillStyle(0x4422aa, 0.02);
        glowG.fillCircle(ccx, ccy, 180);
        this.tweens.add({ targets: glowG, alpha: { from: 0.5, to: 1 }, duration: 2500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut' });

        // ── Medium crystal formations — ring of clusters around center ──
        const gMed = this.add.graphics().setDepth(3.0);
        const medCrystals = [
            { x: -65, y: -40, shards: [{w:10,h:30},{w:8,h:22},{w:6,h:26}] },
            { x: 70, y: -30, shards: [{w:12,h:28},{w:8,h:20},{w:7,h:24}] },
            { x: -75, y: 30, shards: [{w:9,h:25},{w:7,h:18},{w:6,h:22}] },
            { x: 60, y: 45, shards: [{w:11,h:26},{w:7,h:20}] },
            { x: 25, y: -55, shards: [{w:8,h:24},{w:6,h:18},{w:5,h:20}] },
            { x: -40, y: 55, shards: [{w:10,h:22},{w:7,h:16}] },
            { x: -30, y: -60, shards: [{w:9,h:26},{w:6,h:19}] },
            { x: 50, y: -50, shards: [{w:8,h:22},{w:6,h:17}] },
        ];
        medCrystals.forEach(mc => {
            const mx = ccx + mc.x, my = ccy + mc.y;
            // Small rock base
            gMed.fillStyle(0x1a181a, 0.6);
            gMed.fillEllipse(mx, my + 3, mc.shards.length * 8 + 6, 5);
            mc.shards.forEach((sh, si) => {
                const sx = mx + (si - mc.shards.length/2) * 6;
                drawCrystal(gMed, sx, my + 2, sh.w, sh.h, hues[(si + mc.x) % 3 === 0 ? 0 : (si + mc.x) % 3 === 1 ? 1 : 2]);
            });
        });

        // ── Dozens of tiny scattered crystals filling the middle ──
        const gTiny = this.add.graphics().setDepth(2.9);
        const pr = L.pathRing;
        const innerL = pr.cx - pr.w/2 + pr.thickness + 10;
        const innerR = pr.cx + pr.w/2 - pr.thickness - 10;
        const innerT = pr.cy - pr.h/2 + pr.thickness + 10;
        const innerB = pr.cy + pr.h/2 - pr.thickness - 10;

        for (let i = 0; i < 60; i++) {
            const tx = rngR(innerL, innerR);
            const ty = rngR(innerT, innerB);
            // Skip if too close to center cluster
            if (Math.abs(tx - ccx) < 50 && Math.abs(ty - ccy) < 35) continue;
            // Skip if overlapping medium clusters
            let skip = false;
            medCrystals.forEach(mc => { if (Math.abs(tx - (ccx+mc.x)) < 20 && Math.abs(ty - (ccy+mc.y)) < 15) skip = true; });
            if (skip) continue;
            const tw = rngR(3, 7), th = rngR(8, 18);
            const hue = hues[Math.floor(rng() * 3)];
            const c = colors[hue];
            // Simplified 2-facet tiny crystal
            gTiny.fillStyle(c.dark, 0.6);
            gTiny.beginPath();
            gTiny.moveTo(tx - tw/2, ty); gTiny.lineTo(tx, ty - th); gTiny.lineTo(tx, ty);
            gTiny.closePath(); gTiny.fillPath();
            gTiny.fillStyle(c.face, 0.6);
            gTiny.beginPath();
            gTiny.moveTo(tx + tw/2, ty); gTiny.lineTo(tx, ty - th); gTiny.lineTo(tx, ty);
            gTiny.closePath(); gTiny.fillPath();
            // Dot glow
            if (rng() > 0.6) {
                gTiny.fillStyle(c.glow, 0.04);
                gTiny.fillCircle(tx, ty - th/2, 6);
            }
        }

        // ── Floor radiance — colored light wash from crystal on floor ──
        const floorGlow = this.add.graphics().setDepth(0.295);
        floorGlow.fillStyle(0x3a1a5a, 0.04);
        floorGlow.fillCircle(ccx, ccy, 160);
        floorGlow.fillStyle(0x2a1a4a, 0.03);
        floorGlow.fillCircle(ccx, ccy, 220);
    }

    /* ════════════════════════════════════════════════════
       BRANCH TUNNELS (4 connectors to rooms)
       ════════════════════════════════════════════════════ */
    _buildBranches(L) {
        Object.entries(L.branches).forEach(([key, b]) => {
            this.add.rectangle(b.cx, b.cy, b.w, b.h, 0x12100c).setDepth(0.3);
            const roomKey = key === 'leftTop' ? 'factionHQ' : key === 'leftBot' ? 'medBay' : key === 'rightTop' ? 'vendor' : 'stash';
            const room = L.rooms[roomKey];
            const isLeft = b.side === 'left';
            const roomEdge = isLeft ? room.cx + room.w / 2 : room.cx - room.w / 2;
            const hubEdge = isLeft ? b.cx + b.w / 2 : b.cx - b.w / 2;
            const wallStart = isLeft ? roomEdge : hubEdge;
            const wallEnd = isLeft ? hubEdge : roomEdge;
            const wallW = wallEnd - wallStart;
            const wallCX = wallStart + wallW / 2;
            this._addIsoWall(wallCX, b.cy - b.h / 2, wallW, 'north');
            this._addIsoWall(wallCX, b.cy + b.h / 2, wallW, 'south');
        });

        // ── BRANCH ZONE TRIGGERS — show room name when entering corridor ──
        this._branchZones = [];
        const zoneLabels = { leftTop: 'FACTION HUB', leftBot: 'MEDICAL BAY', rightTop: 'BARTER', rightBot: 'STORAGE' };
        const zoneSubs = { leftTop: 'Pledge & Reputation', leftBot: 'Medical Supplies', rightTop: 'Trade & Rebuild', rightBot: 'Personal Stash' };
        Object.entries(L.branches).forEach(([key, b]) => {
            this._branchZones.push({
                x: b.cx, y: b.cy,
                hw: b.w / 2, hh: b.h / 2,
                label: zoneLabels[key] || '', subtitle: zoneSubs[key] || '',
                triggered: false
            });
        });
    }

    /* ═══════════════════════════════════════════════════════
       ROOMS (4 varied-size rooms with props, NPCs, posters)
       ═══════════════════════════════════════════════════════ */
    _buildRooms(L) {
        const W = this.WALL;
        this._roomNPCs = [];

        // ── ¾ ISO PROP HELPERS ──
        const drawBox = (g, x, groundY, w, h, dp, faceC, topC, sideC) => {
            g.fillStyle(faceC, 0.9); g.fillRect(x-w/2, groundY-h, w, h);
            g.fillStyle(topC, 0.7); g.fillRect(x-w/2, groundY-h-3, w, 3);
            g.fillStyle(sideC, 0.8); g.fillRect(x+w/2, groundY-h, dp, h);
            g.fillStyle(topC, 0.5); g.fillRect(x+w/2, groundY-h-3, dp, 3);
            g.fillStyle(0x0a0a08, 0.25); g.fillRect(x-w/2, groundY, w+dp, 2);
        };
        const drawWallItem = (g, x, wallY, w, h, faceC) => {
            g.fillStyle(faceC, 0.85); g.fillRect(x-w/2, wallY-h/2, w, h);
            g.fillStyle(0x3a3830, 0.5); g.fillRect(x-w/2, wallY-h/2-2, w, 2);
            g.lineStyle(1, 0x1a1816, 0.4); g.strokeRect(x-w/2, wallY-h/2, w, h);
        };
        const drawSideShelf = (g, wx, y, dp, h, shelves, isE, fc) => {
            g.fillStyle(fc||0x2a2420, 0.85); g.fillRect(wx-(isE?dp:0), y-h, dp, h);
            g.fillStyle(0x3a3228, 0.5); g.fillRect(isE?wx-dp-3:wx+dp, y-h, 3, h);
            g.fillStyle(0x4a4238, 0.5); g.fillRect(wx-(isE?dp+3:0), y-h-2, dp+3, 2);
            for (let i=1;i<=shelves;i++){const sy=y-h+(h/(shelves+1))*i;
                g.fillStyle(0x3a3228,0.6);g.fillRect(wx-(isE?dp:0),sy,dp,2);
                for(let j=0;j<2;j++){const ix=wx-(isE?dp-2-j*(dp/2-1):-2-j*(dp/2-1));
                    g.fillStyle([0x4a3a2a,0x3a4a3a,0x4a4a3a][j%3],0.55);g.fillRect(ix,sy-7,dp/2-2,7);}}
        };
        const drawChair = (g, x, gy) => {
            g.fillStyle(0x3a3228,0.8);g.fillRect(x-5,gy-6,10,6);g.fillStyle(0x4a4238,0.5);g.fillRect(x-5,gy-8,10,2);
            g.fillStyle(0x2a2420,0.8);g.fillRect(x-5,gy-16,10,8);g.fillStyle(0x3a3228,0.4);g.fillRect(x-5,gy-18,10,2);
            g.fillStyle(0x1a1816,0.6);g.fillRect(x-4,gy,1,3);g.fillRect(x+3,gy,1,3);
        };
        const drawCarpet = (g, cx, cy, cw, ch, color, border) => {
            g.fillStyle(border,0.5);g.fillRect(cx-cw/2-2,cy-ch/2-2,cw+4,ch+4);
            g.fillStyle(color,0.45);g.fillRect(cx-cw/2,cy-ch/2,cw,ch);
            g.lineStyle(1,border,0.2);
            for(let dx=cx-cw/2+15;dx<cx+cw/2;dx+=20)g.lineBetween(dx,cy-ch/2,dx,cy+ch/2);
            for(let dy=cy-ch/2+15;dy<cy+ch/2;dy+=20)g.lineBetween(cx-cw/2,dy,cx+cw/2,dy);
        };

        Object.entries(L.rooms).forEach(([key, r]) => {
            this.add.rectangle(r.cx, r.cy, r.w, r.h, 0x16140e).setDepth(0.3);
            const branch = L.branches[key==='factionHQ'?'leftTop':key==='medBay'?'leftBot':key==='vendor'?'rightTop':'rightBot'];
            const isLeft = branch.side === 'left';
            const rL = r.cx-r.w/2, rR = r.cx+r.w/2, rT = r.cy-r.h/2, rB = r.cy+r.h/2;
            this._buildWallModule(
                { left: rL, right: rR, top: rT, bot: rB },
                [{ wall: isLeft?'east':'west', center: r.cy, size: branch.h }],
                { doorFrames: true }
            );
            const g = this.add.graphics().setDepth(3.5);
            const carpetG = this.add.graphics().setDepth(0.295);
            const nwY = rT - W.frontH/2; // north wall center-Y

            if (key === 'factionHQ') {
                drawCarpet(carpetG, r.cx, r.cy, r.w-30, r.h-30, 0x2a3a2a, 0x1a2a1a);
                // Command desk
                const dX = rL+50, dY = r.cy+8;
                drawBox(g, dX, dY, 56, 16, 5, 0x3a3228, 0x4a4238, 0x2a2420);
                // Papers + radio on desk
                g.fillStyle(0x6a6a58,0.4);g.fillRect(dX-20,dY-18,14,10);
                g.fillStyle(0x7a7a68,0.3);g.fillRect(dX-18,dY-17,10,8);
                g.fillStyle(0x2a2a30,0.8);g.fillRect(dX+10,dY-22,12,8);
                g.fillStyle(0x3a3a40,0.5);g.fillRect(dX+10,dY-24,12,2);
                g.fillStyle(0x33cc44,0.5);g.fillCircle(dX+16,dY-18,1);
                g.lineStyle(1,0x5a5a5a,0.5);g.lineBetween(dX+20,dY-22,dX+24,dY-30);
                drawChair(g, dX, dY-26);
                // NPC
                const fNPC = SpriteManager.createNPCSprite(this, dX, dY-22, 'settler_d');
                fNPC.setDepth(10+(dY-22)*0.01); SpriteManager.stopNPC(fNPC); fNPC.setFrame(6);
                this._roomNPCs.push(fNPC);
                // War map on north wall
                drawWallItem(g, r.cx+15, nwY, 44, 22, 0x1a2a1a);
                g.lineStyle(1,0x6a5a40,0.5);
                g.lineBetween(r.cx+2,nwY-6,r.cx+18,nwY+2);
                g.lineBetween(r.cx+10,nwY-8,r.cx+4,nwY+6);
                g.fillStyle(0xcc3333,0.5);g.fillCircle(r.cx+8,nwY-2,2);g.fillCircle(r.cx+20,nwY+4,2);
                g.fillStyle(0x33cc44,0.4);g.fillCircle(r.cx+14,nwY-5,1.5);
                // Star poster
                drawWallItem(g, r.cx-25, nwY, 22, 16, 0x5a2020);
                g.fillStyle(0xcc9933,0.7);g.beginPath();
                for(let i=0;i<5;i++){const a=-Math.PI/2+i*Math.PI*2/5,sr=i%2===0?5:2;g[i===0?'moveTo':'lineTo'](r.cx-25+Math.cos(a)*sr,nwY+Math.sin(a)*sr);}
                g.closePath();g.fillPath();
                // Filing cabinet (west wall, below banner)
                drawSideShelf(g, rL+8, rB-8, 12, 34, 3, false, 0x2a2a30);
                // Faction banner (west wall, upper area — no overlap with cabinet)
                g.fillStyle(0x4a1a1a,0.6);g.fillRect(rL+6,r.cy-40,3,40);
                g.fillStyle(0x6a2020,0.55);g.fillRect(rL+9,r.cy-36,16,32);
                g.fillStyle(0xcc9933,0.4);g.fillCircle(rL+17,r.cy-20,5);
                g.fillStyle(0xcc9933,0.3);g.fillRect(rL+13,r.cy-4,2,4);g.fillRect(rL+19,r.cy-4,2,4);
                // Ammo crate (right of center, away from bookshelf)
                drawBox(g, r.cx+40, rB-10, 20, 12, 3, 0x3a3020, 0x4a3a28, 0x2a2418);
                g.lineStyle(1,0x5a4a30,0.4);g.strokeRect(r.cx+31,rB-21,18,10);
                // Bookshelf south wall (left of center)
                drawBox(g, r.cx-20, rB-8, 36, 22, 4, 0x2e2620, 0x3a3228, 0x1e1c18);
                for(let bi=0;bi<5;bi++){g.fillStyle([0x4a3a2a,0x3a2a4a,0x2a4a3a,0x4a4a2a,0x3a3a4a][bi],0.5);
                    g.fillRect(r.cx-34+bi*7,rB-28,5,18);}
                // Overhead light
                g.fillStyle(0x5a5a50,0.3);g.fillRect(dX-4,dY-40,8,2);
                g.fillStyle(0xaaaa66,0.06);g.fillCircle(dX,dY-20,25);

            } else if (key === 'medBay') {
                drawCarpet(carpetG, r.cx, r.cy, r.w-24, r.h-24, 0x2a2a3a, 0x1a1a2a);
                // Treatment counter (clear of medicine cabinet)
                const cX = rL+44, cY = r.cy+4;
                drawBox(g, cX, cY, 44, 14, 4, 0x3a3a40, 0x4a4a50, 0x2a2a30);
                g.fillStyle(0x5a5a5a,0.5);g.fillRect(cX-16,cY-18,8,6);
                g.fillStyle(0x4a4a5a,0.4);g.fillRect(cX-15,cY-20,6,2);
                g.fillStyle(0x3a5a3a,0.5);g.fillRect(cX+4,cY-17,10,5);
                g.fillStyle(0xcc3333,0.6);g.fillRect(cX+7,cY-16,4,1);g.fillRect(cX+8,cY-17,2,3);
                // Medic NPC
                const mNPC = SpriteManager.createNPCSprite(this, cX+5, cY-18, 'settler_c');
                mNPC.setDepth(10+(cY-18)*0.01); SpriteManager.stopNPC(mNPC); mNPC.setFrame(6);
                this._roomNPCs.push(mNPC);
                g.fillStyle(0xcc3333,0.65);g.fillRect(cX+3,cY-38,8,2);g.fillRect(cX+6,cY-41,2,8);
                // Gurney
                const bX=r.cx+10,bY=rB-12;
                drawBox(g, bX, bY, 44, 10, 4, 0x3a3a3a, 0x5a5a5a, 0x2a2a2a);
                g.fillStyle(0x4a5a5a,0.4);g.fillRect(bX-20,bY-12,38,2);
                g.fillStyle(0x5a6a6a,0.4);g.fillRect(bX-18,bY-14,10,4);
                g.fillStyle(0x3a3a3a,0.6);g.fillRect(bX-20,bY,2,6);g.fillRect(bX+20,bY,2,6);
                // IV drip
                g.fillStyle(0x5a5a5a,0.6);g.fillRect(bX+28,bY-34,2,30);g.fillRect(bX+26,bY-36,6,2);
                g.fillStyle(0x4a6a7a,0.4);g.fillRect(bX+29,bY-34,5,8);
                g.lineStyle(1,0x4a6a7a,0.3);g.lineBetween(bX+31,bY-26,bX+24,bY-14);
                // Medicine cabinet
                drawSideShelf(g, rL+6, r.cy-10, 12, 34, 3, false, 0x3a3a40);
                // Heartbeat poster
                drawWallItem(g, r.cx+25, nwY, 22, 16, 0x203040);
                g.lineStyle(1.5,0x33cc66,0.6);g.beginPath();
                g.moveTo(r.cx+17,nwY);g.lineTo(r.cx+21,nwY);g.lineTo(r.cx+23,nwY-4);
                g.lineTo(r.cx+27,nwY+4);g.lineTo(r.cx+29,nwY);g.lineTo(r.cx+33,nwY);g.strokePath();
                // Anatomy chart
                drawWallItem(g, r.cx-15, nwY, 18, 20, 0x1a2a2a);
                g.fillStyle(0x4a6a5a,0.3);g.fillRect(r.cx-20,nwY-6,8,14);
                // Biohazard bin
                drawBox(g, rR-18, rB-10, 12, 14, 3, 0x5a3a20, 0x6a4a30, 0x4a2a18);
                g.fillStyle(0xccaa33,0.5);g.fillCircle(rR-18,rB-18,3);
                // Sink
                g.fillStyle(0x4a4a50,0.7);g.fillRect(rL+14,rB-16,16,8);
                g.fillStyle(0x5a5a60,0.4);g.fillRect(rL+14,rB-18,16,2);
                g.fillStyle(0x3a4a5a,0.3);g.fillRect(rL+18,rB-15,8,5);
                g.fillStyle(0x5a5a5a,0.5);g.fillRect(rL+21,rB-20,2,4);
                // Overhead light
                g.fillStyle(0x5a5a60,0.25);g.fillRect(cX-6,cY-42,12,2);
                g.fillStyle(0xaaaacc,0.06);g.fillCircle(cX,cY-20,28);

            } else if (key === 'vendor') {
                drawCarpet(carpetG, r.cx, r.cy, r.w-30, r.h-30, 0x3a2a1a, 0x2a1a0a);
                // Trade counter (east side, clear of display shelf)
                const cX = rR-48, cY = r.cy+8;
                drawBox(g, cX, cY, 48, 16, 5, 0x3a3228, 0x4a4238, 0x2a2420);
                // Scale on counter
                g.fillStyle(0x5a5a50,0.6);g.fillRect(cX-8,cY-22,2,6);
                g.lineStyle(1,0x6a6a60,0.5);g.lineBetween(cX-14,cY-22,cX-2,cY-22);
                g.fillStyle(0x5a5a50,0.4);g.fillRect(cX-14,cY-21,5,3);g.fillRect(cX-6,cY-21,5,3);
                g.fillStyle(0xccaa44,0.4);g.fillCircle(cX+14,cY-18,2);g.fillCircle(cX+18,cY-17,1.5);
                g.fillStyle(0x4a2a1a,0.5);g.fillRect(cX+6,cY-19,8,6);
                // Vendor NPC
                const vNPC = SpriteManager.createNPCSprite(this, cX+4, cY-22, 'vendor_b');
                vNPC.setDepth(10+(cY-22)*0.01); SpriteManager.stopNPC(vNPC); vNPC.setFrame(18);
                this._roomNPCs.push(vNPC);
                // Weapon rack on north wall
                drawWallItem(g, r.cx-10, nwY, 56, 18, 0x2e2620);
                g.lineStyle(2,0x5a5a5a,0.65);
                [-24,-14,-4,6,16,24].forEach(ox=>g.lineBetween(r.cx-10+ox,nwY-6,r.cx-10+ox,nwY+6));
                g.fillStyle(0x4a4a4a,0.3);
                g.fillRect(r.cx-32,nwY-2,18,2);g.fillRect(r.cx-4,nwY-3,12,3);g.fillRect(r.cx+12,nwY-1,8,2);
                // Price board
                drawWallItem(g, rR-30, nwY, 20, 16, 0x1a1a18);
                g.fillStyle(0xccaa44,0.4);g.fillRect(rR-38,nwY-5,14,2);g.fillRect(rR-36,nwY-1,10,2);g.fillRect(rR-38,nwY+3,12,2);
                // Display shelf east wall
                drawSideShelf(g, rR-6, r.cy+20, 12, 44, 4, true, 0x2a2420);
                // Armor mannequin
                const mx=r.cx-30,my=rB-14;
                g.fillStyle(0x3a3a30,0.6);g.fillRect(mx-4,my-30,8,22);g.fillRect(mx-6,my-32,12,3);
                g.fillStyle(0x4a4a40,0.4);g.fillRect(mx-4,my-33,8,2);g.fillRect(mx-2,my-8,4,6);
                g.fillStyle(0x2a2a28,0.5);g.fillCircle(mx,my-2,6);
                // Crate stack
                drawBox(g,r.cx-60,rB-8,22,14,3,0x3a3020,0x4a3a28,0x2a2418);
                drawBox(g,r.cx-56,rB-22,16,10,3,0x3a3020,0x4a3a28,0x2a2418);
                g.lineStyle(1,0x5a4a30,0.3);g.strokeRect(r.cx-70,rB-21,20,12);
                // Scrap on floor
                g.fillStyle(0x4a4a40,0.25);g.fillRect(r.cx+20,r.cy+30,6,3);
                g.fillStyle(0x5a4a3a,0.2);g.fillRect(r.cx+10,r.cy+34,4,2);
                // Lantern
                g.fillStyle(0x5a5a40,0.3);g.fillRect(cX-3,cY-44,6,2);
                g.lineStyle(1,0x4a4a30,0.4);g.lineBetween(cX,cY-42,cX,cY-36);
                g.fillStyle(0xaaaa66,0.08);g.fillCircle(cX,cY-22,22);

            } else if (key === 'stash') {
                drawCarpet(carpetG, r.cx, r.cy, r.w-20, r.h-20, 0x2a2a2a, 0x1a1a1a);
                // Lockers east wall
                const lx=rR-6;
                drawSideShelf(g, lx, r.cy+25, 12, 50, 0, true, 0x2a2a30);
                for(let li=0;li<3;li++){const ly=r.cy-22+li*18;
                    g.lineStyle(1,0x1a1a20,0.5);g.strokeRect(lx-12,ly,11,16);
                    g.fillStyle(0x4a4a50,0.45);g.fillRect(lx-5,ly+6,2,4);}
                g.fillStyle(0xccaa44,0.5);g.fillCircle(lx-4,r.cy+2,1.5);
                // Workbench south wall
                const wX=r.cx-8,wY=rB-10;
                drawBox(g, wX, wY, 50, 14, 4, 0x3a3228, 0x4a4238, 0x2a2420);
                g.fillStyle(0x4a4a4a,0.7);g.fillRect(wX-18,wY-20,6,8);
                g.fillStyle(0x5a5a5a,0.5);g.fillRect(wX-20,wY-18,10,2);
                g.fillStyle(0x5a5a5a,0.5);g.fillRect(wX+2,wY-22,3,10);
                g.fillStyle(0x5a5a50,0.4);g.fillRect(wX+10,wY-24,2,12);
                g.fillStyle(0xaa5533,0.4);g.fillRect(wX+9,wY-26,4,4);
                g.fillStyle(0x3a3020,0.5);g.fillRect(wX+16,wY-19,8,5);
                // Tool pegboard
                drawWallItem(g, r.cx, nwY, 40, 18, 0x2e2820);
                g.fillStyle(0x5a5a5a,0.5);
                g.fillRect(r.cx-14,nwY-4,2,10);g.fillRect(r.cx-16,nwY-5,6,3);
                g.fillRect(r.cx-2,nwY-6,2,12);g.fillRect(r.cx+8,nwY-3,10,2);
                g.fillStyle(0xaa5533,0.3);g.fillRect(r.cx-14,nwY+4,4,3);
                // Locked crate
                drawBox(g, r.cx-2, r.cy+2, 26, 16, 4, 0x2a2620, 0x3a3228, 0x1e1c18);
                g.fillStyle(0x4a4a40,0.5);g.fillRect(r.cx-14,r.cy-12,24,2);g.fillRect(r.cx-14,r.cy-4,24,2);
                g.fillStyle(0x6a5a40,0.7);g.fillRect(r.cx-4,r.cy-7,6,5);
                g.lineStyle(1,0x7a6a50,0.5);g.beginPath();g.arc(r.cx-1,r.cy-9,3,Math.PI,0);g.strokePath();
                // Ammo boxes
                drawBox(g,rL+18,r.cy+10,14,8,3,0x3a3a2a,0x4a4a38,0x2a2a20);
                drawBox(g,rL+22,r.cy+2,12,8,3,0x3a3a2a,0x4a4a38,0x2a2a20);
                // Floor lamp
                g.fillStyle(0x3a3a30,0.6);g.fillRect(wX+26,wY-36,2,30);
                g.fillStyle(0x5a5a40,0.4);g.fillRect(wX+23,wY-38,8,3);
                g.fillStyle(0xaaaa66,0.06);g.fillCircle(wX+27,wY-20,16);
            }
        });
    }

    /* ═══════════════════════════════════════════════════════
       PORTAL (north wall of north square)
       ═══════════════════════════════════════════════════════ */
    _buildPortal(L) {
        const p = L.portal;
        const W = this.WALL;

        // Portal sits in the gap of the north wall. The wall gap is already
        // created by _buildNorthSquare. We build a rocky arch frame that
        // overlaps the wall edges, with the portal swirl inside.

        const gFrame = this.add.graphics().setDepth(2.5);
        const wallTop = p.cy - W.frontH - W.topH;  // visual top of north wall
        const wallBot = p.cy;  // groundY of north wall

        // ── Rocky archway frame ──
        // Irregular rock formation around the portal opening
        const rockColor = 0x2a2628;
        const rockLight = 0x3a3438;
        const rockDark = 0x1a181c;

        // Left pillar — rough hewn rock
        gFrame.fillStyle(rockColor, 0.95);
        gFrame.beginPath();
        gFrame.moveTo(p.cx - p.w/2 - 8, wallBot + 4);
        gFrame.lineTo(p.cx - p.w/2 - 12, wallTop - 10);
        gFrame.lineTo(p.cx - p.w/2 - 6, wallTop - 18);
        gFrame.lineTo(p.cx - p.w/2 + 4, wallTop - 14);
        gFrame.lineTo(p.cx - p.w/2 + 6, wallBot + 4);
        gFrame.closePath();
        gFrame.fillPath();
        // Pillar highlight
        gFrame.lineStyle(1, rockLight, 0.3);
        gFrame.lineBetween(p.cx - p.w/2 - 10, wallTop - 8, p.cx - p.w/2 - 6, wallBot + 2);

        // Right pillar
        gFrame.fillStyle(rockColor, 0.95);
        gFrame.beginPath();
        gFrame.moveTo(p.cx + p.w/2 + 8, wallBot + 4);
        gFrame.lineTo(p.cx + p.w/2 + 12, wallTop - 10);
        gFrame.lineTo(p.cx + p.w/2 + 6, wallTop - 18);
        gFrame.lineTo(p.cx + p.w/2 - 4, wallTop - 14);
        gFrame.lineTo(p.cx + p.w/2 - 6, wallBot + 4);
        gFrame.closePath();
        gFrame.fillPath();
        gFrame.lineStyle(1, rockDark, 0.3);
        gFrame.lineBetween(p.cx + p.w/2 + 10, wallTop - 8, p.cx + p.w/2 + 6, wallBot + 2);

        // Arch top — rough stone lintel connecting pillars
        gFrame.fillStyle(rockColor, 0.95);
        gFrame.beginPath();
        gFrame.moveTo(p.cx - p.w/2 - 6, wallTop - 14);
        gFrame.lineTo(p.cx - p.w/4, wallTop - 24);
        gFrame.lineTo(p.cx, wallTop - 28);
        gFrame.lineTo(p.cx + p.w/4, wallTop - 24);
        gFrame.lineTo(p.cx + p.w/2 + 6, wallTop - 14);
        gFrame.lineTo(p.cx + p.w/2 - 2, wallTop - 8);
        gFrame.lineTo(p.cx + p.w/4 - 4, wallTop - 16);
        gFrame.lineTo(p.cx, wallTop - 20);
        gFrame.lineTo(p.cx - p.w/4 + 4, wallTop - 16);
        gFrame.lineTo(p.cx - p.w/2 + 2, wallTop - 8);
        gFrame.closePath();
        gFrame.fillPath();
        // Arch keystone
        gFrame.fillStyle(rockLight, 0.5);
        gFrame.fillRect(p.cx - 6, wallTop - 27, 12, 8);

        // Rock debris at base
        gFrame.fillStyle(rockDark, 0.6);
        gFrame.fillRect(p.cx - p.w/2 - 4, wallBot + 2, 12, 4);
        gFrame.fillRect(p.cx + p.w/2 - 8, wallBot + 2, 14, 3);
        gFrame.fillStyle(rockColor, 0.4);
        gFrame.fillRect(p.cx - p.w/2 + 10, wallBot + 3, 6, 3);
        gFrame.fillRect(p.cx + p.w/2 - 18, wallBot + 4, 8, 2);

        // Small rock chunks scattered around frame
        for (let i = 0; i < 8; i++) {
            const rx = p.cx + (i - 4) * 18 + (i % 2 ? 5 : -3);
            const ry = wallBot + 3 + (i % 3);
            gFrame.fillStyle(rockDark, 0.3 + (i % 3) * 0.1);
            gFrame.fillRect(rx, ry, 3 + i % 4, 2 + i % 2);
        }

        // ── Rune markings on pillars ──
        const runeColor = 0x7744aa;
        gFrame.lineStyle(1, runeColor, 0.4);
        // Left pillar runes
        const lp = p.cx - p.w/2 - 4;
        gFrame.lineBetween(lp, wallBot - 8, lp - 2, wallBot - 14);
        gFrame.lineBetween(lp - 2, wallBot - 14, lp + 2, wallBot - 20);
        gFrame.lineBetween(lp, wallBot - 24, lp - 3, wallBot - 30);
        // Right pillar runes
        const rp = p.cx + p.w/2 + 4;
        gFrame.lineBetween(rp, wallBot - 8, rp + 2, wallBot - 14);
        gFrame.lineBetween(rp + 2, wallBot - 14, rp - 2, wallBot - 20);
        gFrame.lineBetween(rp, wallBot - 24, rp + 3, wallBot - 30);

        // ── Portal void — the dark opening ──
        const portalW = p.w - 16, portalH = W.frontH + 8;
        const portalTop = wallBot - portalH;
        const gVoid = this.add.graphics().setDepth(2.0);
        gVoid.fillStyle(0x0a0010, 1);
        gVoid.fillRect(p.cx - portalW/2, portalTop, portalW, portalH);

        // ── Animated portal swirl layers ──
        // Multiple concentric swirl rings that rotate at different speeds
        const swirlLayers = [];
        const colors = [0x4422aa, 0x6633bb, 0x8844cc, 0x5533aa, 0x7744bb];
        const swirlCX = p.cx, swirlCY = portalTop + portalH / 2;

        for (let layer = 0; layer < 5; layer++) {
            const sg = this.add.graphics().setDepth(2.1 + layer * 0.02);
            swirlLayers.push({ g: sg, layer });
        }

        // Draw initial swirl state
        this._portalSwirl = { layers: swirlLayers, cx: swirlCX, cy: swirlCY, portalW, portalH, colors, time: 0 };
        this._portalPos = { x: swirlCX, y: swirlCY + portalH / 2 + 10 };

        // ── Energy particles inside portal — subtle dots ──
        const particleG = this.add.graphics().setDepth(2.3);
        for (let i = 0; i < 20; i++) {
            const angle = (i / 20) * Math.PI * 2;
            const r = 8 + (i % 5) * 6;
            const px = swirlCX + Math.cos(angle) * r * 0.8;
            const py = swirlCY + Math.sin(angle) * r * 0.4;
            particleG.fillStyle(colors[i % 5], 0.4 - i * 0.015);
            particleG.fillCircle(px, py, 1 + (i % 3) * 0.5);
        }
        this.tweens.add({
            targets: particleG,
            alpha: { from: 0.5, to: 1 },
            duration: 1500,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });

        // ── Ambient glow ──
        const portalGlow = this.add.graphics().setDepth(1.9);
        portalGlow.fillStyle(0x5522aa, 0.08);
        portalGlow.fillCircle(swirlCX, swirlCY, portalW);
        portalGlow.fillStyle(0x5522aa, 0.04);
        portalGlow.fillCircle(swirlCX, swirlCY, portalW * 1.5);
        this.tweens.add({
            targets: portalGlow,
            alpha: { from: 0.6, to: 1 },
            duration: 3000,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });

        // Timer-based swirl animation
        this.time.addEvent({
            delay: 80,
            loop: true,
            callback: () => {
                if (!this._portalSwirl) return;
                const ps = this._portalSwirl;
                ps.time += 0.08;
                ps.layers.forEach(({ g, layer }) => {
                    g.clear();
                    const speed = 0.3 + layer * 0.15;
                    const t = ps.time * speed;
                    const col = ps.colors[layer];
                    // Draw elliptical arc segments
                    for (let seg = 0; seg < 3; seg++) {
                        const startAngle = t + seg * Math.PI * 2 / 3;
                        const arcLen = 0.5 + layer * 0.12;
                        g.lineStyle(2 - layer * 0.2, col, 0.25 - layer * 0.03);
                        g.beginPath();
                        for (let a = 0; a < arcLen; a += 0.1) {
                            const angle = startAngle + a;
                            const r = ps.portalW * (0.15 + layer * 0.08);
                            const x = ps.cx + Math.cos(angle) * r;
                            const y = ps.cy + Math.sin(angle) * r * 0.55;
                            // Clip to portal bounds
                            if (x < ps.cx - ps.portalW/2 + 4 || x > ps.cx + ps.portalW/2 - 4) continue;
                            if (y < ps.cy - ps.portalH/2 + 4 || y > ps.cy + ps.portalH/2 - 4) continue;
                            if (a === 0) g.moveTo(x, y);
                            else g.lineTo(x, y);
                        }
                        g.strokePath();
                    }
                });
            }
        });
    }

    /* ═══════════════════════════════════════════════════════
       PATHWAYS — stone walkways connecting areas
       ═══════════════════════════════════════════════════════ */
    _buildPathways(L) {
        const pathW = 50;
        const pathBase = 0x1e1c14;
        const pathLight = 0x26241a;
        const pathDark = 0x141210;
        const edgeColor = 0x2a2820;
        const stoneColor = 0x222018;
        const seed = 6673;
        let _s = seed;
        const rng = () => { _s = (_s * 16807) % 2147483647; return (_s & 0x7fffffff) / 0x7fffffff; };
        const rngR = (a, b) => a + rng() * (b - a);

        const drawPath = (cx, cy, w, h, dir) => {
            const gp = this.add.graphics().setDepth(0.32);
            const x0 = cx - w/2, y0 = cy - h/2;
            gp.fillStyle(pathBase, 0.6);
            gp.fillRect(x0, y0, w, h);
            if (dir === 'h') {
                const stoneH = 8;
                for (let sy = y0+2; sy < y0+h-2; sy += stoneH+1) {
                    const offset = (Math.floor((sy-y0)/(stoneH+1))%2)*12;
                    for (let sx = x0+2+offset; sx < x0+w-2; sx += rngR(18,28)) {
                        const sw = rngR(14,24);
                        if (sx+sw > x0+w-2) continue;
                        gp.fillStyle(rng()>0.3 ? stoneColor : pathLight, rngR(0.15,0.35));
                        gp.fillRect(sx, sy, sw, stoneH);
                        gp.fillStyle(pathDark, rngR(0.15,0.3));
                        gp.fillRect(sx+sw, sy, 1, stoneH);
                    }
                    gp.fillStyle(pathDark, rngR(0.1,0.2));
                    gp.fillRect(x0+3, sy+stoneH, w-6, 1);
                }
            } else {
                const stoneW = 8;
                for (let sx = x0+2; sx < x0+w-2; sx += stoneW+1) {
                    const offset = (Math.floor((sx-x0)/(stoneW+1))%2)*12;
                    for (let sy = y0+2+offset; sy < y0+h-2; sy += rngR(18,28)) {
                        const sh = rngR(14,24);
                        if (sy+sh > y0+h-2) continue;
                        gp.fillStyle(rng()>0.3 ? stoneColor : pathLight, rngR(0.15,0.35));
                        gp.fillRect(sx, sy, stoneW, sh);
                        gp.fillStyle(pathDark, rngR(0.15,0.3));
                        gp.fillRect(sx, sy+sh, stoneW, 1);
                    }
                    gp.fillStyle(pathDark, rngR(0.1,0.2));
                    gp.fillRect(sx+stoneW, y0+3, 1, h-6);
                }
            }
            const ge = this.add.graphics().setDepth(0.33);
            ge.fillStyle(edgeColor, 0.45);
            if (dir === 'h') {
                ge.fillRect(x0, y0, w, 2); ge.fillRect(x0, y0+h-2, w, 2);
                ge.fillStyle(pathDark, 0.3);
                ge.fillRect(x0, y0+2, w, 1); ge.fillRect(x0, y0+h-3, w, 1);
            } else {
                ge.fillRect(x0, y0, 2, h); ge.fillRect(x0+w-2, y0, 2, h);
                ge.fillStyle(pathDark, 0.3);
                ge.fillRect(x0+2, y0, 1, h); ge.fillRect(x0+w-3, y0, 1, h);
            }
            for (let i = 0; i < Math.max(1, (w*h)/4000); i++) {
                gp.fillStyle(pathDark, rngR(0.1,0.25));
                gp.fillEllipse(rngR(x0+4,x0+w-4), rngR(y0+4,y0+h-4), rngR(4,12), rngR(2,6));
            }
        };

        const ns = L.northSquare;
        const pr = L.pathRing;

        // Parkway top → connector bottom
        const parkToConnY0 = L.parkway.top, parkToConnY1 = L.connector.bot;
        drawPath(L.southSquare.cx, (parkToConnY0+parkToConnY1)/2, pathW, parkToConnY1-parkToConnY0+pathW, 'v');
        // Connector full length
        drawPath(L.connector.cx, L.connector.cy, pathW, L.connector.h+pathW, 'v');
        // Connector top → ring bottom
        const ringBot = pr.cy + pr.h/2;
        drawPath(ns.cx, L.connector.top + (ringBot-L.connector.top)/2, pathW, ringBot-L.connector.top+pathW, 'v');
        // Path ring — overlapping corners
        drawPath(pr.cx, pr.cy-pr.h/2, pr.w+pr.thickness, pr.thickness, 'h');
        drawPath(pr.cx, pr.cy+pr.h/2, pr.w+pr.thickness, pr.thickness, 'h');
        drawPath(pr.cx-pr.w/2, pr.cy, pr.thickness, pr.h+pr.thickness, 'v');
        drawPath(pr.cx+pr.w/2, pr.cy, pr.thickness, pr.h+pr.thickness, 'v');

        // Spurs through branches into rooms
        Object.entries(L.branches).forEach(([bKey, b]) => {
            const isLeft = b.side === 'left';
            const ringEdge = isLeft ? pr.cx-pr.w/2 : pr.cx+pr.w/2;
            const roomKey = bKey==='leftTop'?'factionHQ':bKey==='leftBot'?'medBay':bKey==='rightTop'?'vendor':'stash';
            const room = L.rooms[roomKey];
            const spurLeft = isLeft ? room.cx : ringEdge-pr.thickness/2;
            const spurRight = isLeft ? ringEdge+pr.thickness/2 : room.cx;
            drawPath(spurLeft+(spurRight-spurLeft)/2, b.cy, spurRight-spurLeft, pathW, 'h');
        });
        // Portal spur
        const portalSpurBot = pr.cy-pr.h/2+pr.thickness/2;
        drawPath(L.portal.cx, (L.portal.cy+portalSpurBot)/2, pathW, portalSpurBot-L.portal.cy+pathW, 'v');
    }

    /* ═══════════════════════════════════════════════════════
       ENVIRONMENT DETAILS — props throughout Haven
       ═══════════════════════════════════════════════════════ */
    _buildEnvironmentDetails(L) {
        const W = this.WALL;
        const seed = 9173;
        let _s = seed;
        const rng = () => { _s = (_s * 16807) % 2147483647; return (_s & 0x7fffffff) / 0x7fffffff; };
        const rngR = (a, b) => a + rng() * (b - a);

        // ── SOUTH SQUARE — industrial utility area ──
        const ss = L.southSquare;
        const ssG = this.add.graphics().setDepth(3.0);

        // Utility crates along south wall (left of road gaps)
        const crateBaseY = ss.bot - 14;
        ssG.fillStyle(0x3a3020, 0.8);
        ssG.fillRect(ss.left + 16, crateBaseY - 12, 20, 12);
        ssG.fillStyle(0x4a3a28, 0.5);
        ssG.fillRect(ss.left + 16, crateBaseY - 14, 20, 2);
        ssG.fillStyle(0x3a3020, 0.7);
        ssG.fillRect(ss.left + 20, crateBaseY - 22, 14, 10);
        ssG.fillStyle(0x4a3a28, 0.4);
        ssG.fillRect(ss.left + 20, crateBaseY - 24, 14, 2);
        // Supply barrel
        ssG.fillStyle(0x3a3a30, 0.7);
        ssG.fillRect(ss.right - 40, crateBaseY - 16, 14, 16);
        ssG.fillStyle(0x4a4a40, 0.4);
        ssG.fillRect(ss.right - 40, crateBaseY - 18, 14, 2);
        ssG.fillStyle(0x2a2a28, 0.5);
        ssG.fillRect(ss.right - 39, crateBaseY - 13, 12, 2);
        ssG.fillRect(ss.right - 39, crateBaseY - 5, 12, 2);

        // Wall-mounted lights on south square (north wall, flanking connector)
        const connHalf = L.connector.w / 2;
        [ss.cx - connHalf - 50, ss.cx + connHalf + 50].forEach(lx => {
            ssG.fillStyle(0x3a3830, 0.6);
            ssG.fillRect(lx - 3, ss.top - W.frontH * 0.8, 6, 4);
            ssG.fillStyle(0xaaaa66, 0.06);
            ssG.fillCircle(lx, ss.top - W.frontH * 0.5, 18);
        });

        // Floor drain grates in south square
        [ss.cx - 80, ss.cx + 80].forEach(dx => {
            ssG.fillStyle(0x0e0e0c, 0.5);
            ssG.fillRect(dx - 6, ss.cy + 40, 12, 8);
            ssG.lineStyle(1, 0x1a1a18, 0.4);
            for (let sl = dx - 4; sl <= dx + 4; sl += 3) ssG.lineBetween(sl, ss.cy + 41, sl, ss.cy + 47);
        });

        // ── CONNECTOR TUNNEL — industrial corridor ──
        const cn = L.connector;
        const cnG = this.add.graphics().setDepth(2.3);

        // Pipe runs along both side walls
        const pipeY1 = cn.top + 40, pipeY2 = cn.bot - 40;
        [cn.cx - cn.w/2 + 4, cn.cx + cn.w/2 - 4].forEach(px => {
            cnG.fillStyle(0x3a3630, 0.5);
            cnG.fillRect(px - 1, cn.top + 10, 2, cn.h - 20);
            cnG.fillStyle(0x4a4640, 0.25);
            cnG.fillRect(px - 2, cn.top + 10, 1, cn.h - 20);
            // Pipe brackets
            for (let by = cn.top + 30; by < cn.bot - 20; by += 50) {
                cnG.fillStyle(0x2a2622, 0.6);
                cnG.fillRect(px - 3, by, 6, 4);
            }
        });

        // Overhead glow patches (ceiling lights)
        const ceilG = this.add.graphics().setDepth(0.32);
        for (let ly = cn.top + 40; ly < cn.bot - 20; ly += 70) {
            ceilG.fillStyle(0xaaaa66, 0.04);
            ceilG.fillCircle(cn.cx, ly, 20);
            // Light fixture
            cnG.fillStyle(0x4a4a40, 0.4);
            cnG.fillRect(cn.cx - 6, ly - 3, 12, 2);
        }

        // Junction box on east wall
        cnG.fillStyle(0x2a2a30, 0.6);
        cnG.fillRect(cn.cx + cn.w/2 - 8, cn.cy - 8, 8, 14);
        cnG.fillStyle(0x3a3a40, 0.3);
        cnG.fillRect(cn.cx + cn.w/2 - 7, cn.cy - 6, 6, 10);
        cnG.fillStyle(0x33cc44, 0.4);
        cnG.fillCircle(cn.cx + cn.w/2 - 4, cn.cy - 4, 1);

        // Floor scuff marks
        cnG.fillStyle(0x0e0e0c, 0.12);
        cnG.fillEllipse(cn.cx - 8, cn.cy - 30, 18, 6);
        cnG.fillEllipse(cn.cx + 5, cn.cy + 50, 14, 5);

        // ── NORTH SQUARE — main hub details ──
        const ns = L.northSquare;
        const pr = L.pathRing;
        const nsG = this.add.graphics().setDepth(3.1);

        // Benches — set back from path ring in the central area
        const ringL = pr.cx - pr.w/2, ringR = pr.cx + pr.w/2;
        const ringT = pr.cy - pr.h/2, ringB = pr.cy + pr.h/2;
        const innerL = pr.cx - pr.w/2 + pr.thickness + 20;
        const innerR = pr.cx + pr.w/2 - pr.thickness - 20;
        const innerT = pr.cy - pr.h/2 + pr.thickness + 20;
        const innerB = pr.cy + pr.h/2 - pr.thickness - 20;
        const drawBench = (bx, by) => {
            nsG.fillStyle(0x3a3228, 0.75);
            nsG.fillRect(bx - 14, by - 6, 28, 6);
            nsG.fillStyle(0x4a4238, 0.5);
            nsG.fillRect(bx - 14, by - 8, 28, 2);
            nsG.fillStyle(0x2a2420, 0.6);
            nsG.fillRect(bx - 12, by, 2, 4);
            nsG.fillRect(bx + 10, by, 2, 4);
        };
        drawBench(innerL + 10, pr.cy - 15);
        drawBench(innerR - 10, pr.cy + 20);

        // Barrels/containers against walls (away from walkways)
        const drawBarrel = (bx, by) => {
            nsG.fillStyle(0x3a3a30, 0.65);
            nsG.fillRect(bx - 6, by - 14, 12, 14);
            nsG.fillStyle(0x4a4a40, 0.4);
            nsG.fillRect(bx - 6, by - 16, 12, 2);
            nsG.fillStyle(0x2a2a28, 0.4);
            nsG.fillRect(bx - 5, by - 10, 10, 2);
        };
        drawBarrel(ns.left + 16, ns.top + 50);
        drawBarrel(ns.right - 18, ns.top + 55);

        // Rubble piles at room-side edges (against walls, not on paths)
        nsG.fillStyle(0x1a181a, 0.4);
        nsG.fillEllipse(ns.left + 12, ns.cy - 50, 16, 6);
        nsG.fillStyle(0x181618, 0.35);
        nsG.fillEllipse(ns.right - 14, ns.cy + 40, 14, 5);
        [ns.left+8, ns.left+18, ns.right-10, ns.right-20].forEach((rx, i) => {
            nsG.fillStyle(0x1e1c1a, 0.3);
            nsG.fillRect(rx - 2, ns.cy + (i < 2 ? -48 : 38) - 2, 4 + i, 3 + i % 2);
        });

        // Wall-mounted sconces on north square walls
        [ns.left + 60, ns.left + 180, ns.right - 60, ns.right - 180].forEach(lx => {
            nsG.fillStyle(0x3a3830, 0.5);
            nsG.fillRect(lx - 3, ns.top - W.frontH * 0.75, 6, 4);
            nsG.fillStyle(0xaaaa66, 0.05);
            nsG.fillCircle(lx, ns.top - W.frontH * 0.5, 16);
        });
        // Sconces on south wall of north square
        [ns.cx - 100, ns.cx + 100].forEach(lx => {
            nsG.fillStyle(0x3a3830, 0.5);
            nsG.fillRect(lx - 3, ns.bot - W.frontH * 0.75, 6, 4);
            nsG.fillStyle(0xaaaa66, 0.04);
            nsG.fillCircle(lx, ns.bot - W.frontH * 0.5, 14);
        });

        // Floor cracks and debris in north square
        nsG.lineStyle(1, 0x0e0e0c, 0.15);
        nsG.lineBetween(ns.cx - 120, ns.cy + 80, ns.cx - 100, ns.cy + 95);
        nsG.lineBetween(ns.cx - 100, ns.cy + 95, ns.cx - 90, ns.cy + 88);
        nsG.lineBetween(ns.cx + 80, ns.cy - 60, ns.cx + 95, ns.cy - 50);

        // ── PARKWAY — subtle ground wear only ──
        const pk = L.parkway;
        const pkG = this.add.graphics().setDepth(0.38);
        // Faint tire marks near road transition (logical — vehicles drive here)
        pkG.fillStyle(0x0e0e0c, 0.07);
        pkG.fillRect(pk.cx - 30, pk.bot - 6, 60, 2);
        pkG.fillRect(pk.cx - 28, pk.bot - 10, 56, 2);
    }

    /* ════════════════════════════════════════════════════
       GATES — at every doorway/transition point
       ════════════════════════════════════════════════════
       N/S gates: iso front-face, spans horizontal opening.
       E/W gates: rotated iso — front face turned 90deg so it
         fills the vertical opening. Same iso detail (face + top
         strip + grooves) but oriented vertically. Descends into
         ground. Top strip appears as door lowers.
       Metal palette distinguishes gates from stone walls.
       Floor rail permanent at every gate position.
       ════════════════════════════════════════════════════ */
    _buildGates(L) {
        this._gates = {};
        const W = this.WALL;
        const G = {
            face: 0x3a3640, faceDark: 0x2c2832, top: 0x4a4650,
            groove: 0x24222c, grooveA: 0.5, edge: 0x1e1c26,
            rivet: 0x5a5660, strip: 0x1a1820, highlight: 0x5a5660
        };

        // ── N/S GATE — iso front face, horizontal strip ──
        const makeNSGate = (id, cx, groundY, gapW) => {
            const d = 2.05; // in front of side walls (2.0)
            const bY = groundY, fT = bY - W.frontH;
            // Floor rail
            this.add.rectangle(cx, bY + 2, gapW + 2, 3, G.strip).setDepth(0.296);
            this.add.rectangle(cx, bY + 2, gapW - 2, 1, G.groove, 0.4).setDepth(0.37);
            // Front face + top strip (standard iso)
            const face = this.add.rectangle(cx, bY - W.frontH/2, gapW, W.frontH, G.face).setDepth(d);
            const topStrip = this.add.rectangle(cx, fT - W.topH/2, gapW, W.topH, G.top).setDepth(d+0.03);
            const topHL = this.add.rectangle(cx, fT - W.topH+1, gapW, 1, G.highlight, 0.3).setDepth(d+0.04);
            const grooves = [];
            for (let i = 1; i <= 4; i++) grooves.push(this.add.rectangle(cx, bY - W.frontH*(i/5), gapW-4, 1, G.groove, G.grooveA).setDepth(d+0.01));
            const edge = this.add.rectangle(cx, bY-1, gapW, 2, G.edge).setDepth(d+0.02);
            const rivets = [];
            const rx = gapW/2-3, ry = W.frontH/2-3;
            [[cx-rx,bY-W.frontH/2-ry],[cx+rx,bY-W.frontH/2-ry],
             [cx-rx,bY-W.frontH/2+ry],[cx+rx,bY-W.frontH/2+ry]].forEach(([px,py]) => {
                rivets.push(this.add.circle(px, py, 1.2, G.rivet, 0.6).setDepth(d+0.05));
            });
            const emblem = this.add.rectangle(cx, bY-W.frontH/2, gapW-8, 2, G.highlight, 0.35).setDepth(d+0.05);
            const collBody = this.add.rectangle(cx, bY, gapW, W.collisionH, 0x000000, 0).setDepth(0);
            this.walls.add(collBody);
            const doorParts = [face, topStrip, topHL, ...grooves, edge, ...rivets, emblem];
            this._gates[id] = {
                id, x: cx, y: bY, open: false, orient: 'ns',
                face, topStrip, topHL, grooves, edge, rivets, emblem, collBody,
                doorParts, groundY: bY, fullH: W.frontH, w: gapW, cx
            };
        };

        // Place N/S gates only (E/W openings have no gates)
        makeNSGate('southToConn', L.southSquare.cx, L.southSquare.top, L.connector.w);
        makeNSGate('connToNorth', L.northSquare.cx, L.northSquare.bot, L.connector.w);

        // ── SECURITY STATIONS — flanking both gates ──
        const secG = this.add.graphics().setDepth(3.2);
        const drawBooth = (bx, by) => {
            // Front face
            secG.fillStyle(0x3a3830, 0.9);
            secG.fillRect(bx - 12, by - 22, 24, 18);
            // Top strip
            secG.fillStyle(0x4a4840, 0.7);
            secG.fillRect(bx - 13, by - 24, 26, 3);
            // Side face
            secG.fillStyle(0x2a2820, 0.8);
            secG.fillRect(bx + 12, by - 22, 4, 18);
            // Window slit + highlight
            secG.fillStyle(0x1a2a2a, 0.7);
            secG.fillRect(bx - 8, by - 18, 16, 6);
            secG.fillStyle(0x3a5a5a, 0.3);
            secG.fillRect(bx - 6, by - 17, 6, 4);
            // Base
            secG.fillStyle(0x2a2622, 0.9);
            secG.fillRect(bx - 14, by - 4, 28, 6);
            // Antenna + LED
            secG.lineStyle(1, 0x4a4840, 0.6);
            secG.lineBetween(bx + 8, by - 24, bx + 10, by - 32);
            secG.fillStyle(0x33cc44, 0.7);
            secG.fillCircle(bx - 8, by - 23, 1.5);
            this._addWall(bx, by - 10, 28, 22);
        };
        // Booths flanking south gate (southToConn) only
        const gateW = L.connector.w;
        const sg1x = L.southSquare.cx - gateW/2 - 24;
        const sg1y = L.southSquare.top + 6;
        drawBooth(sg1x, sg1y);
        drawBooth(L.southSquare.cx + gateW/2 + 24, sg1y);

        // Guard NPCs at south gate
        this._securityNPCs = [];
        const guardNPC1 = SpriteManager.createNPCSprite(this, sg1x, sg1y + 14, 'guard_a');
        guardNPC1.setDepth(10 + (sg1y + 14) * 0.01);
        SpriteManager.stopNPC(guardNPC1); guardNPC1.setFrame(0);
        this._securityNPCs.push(guardNPC1);
        DynamicShadows.add(this, guardNPC1, { offsetY: 8, scale: 0.5, alpha: 0.12, interior: true });
        const guardNPC2 = SpriteManager.createNPCSprite(this, L.southSquare.cx + gateW/2 + 24, sg1y + 14, 'guard_b');
        guardNPC2.setDepth(10 + (sg1y + 14) * 0.01);
        SpriteManager.stopNPC(guardNPC2); guardNPC2.setFrame(0);
        this._securityNPCs.push(guardNPC2);
        DynamicShadows.add(this, guardNPC2, { offsetY: 8, scale: 0.5, alpha: 0.12, interior: true });
    }

    // t: 0=closed, 1=open
    _setGateOpenness(gate, t) {
        const W = this.WALL;
        // N/S gate: iso front face shrinks from top, bottom at groundY
        const visH = Math.max(0, gate.fullH * (1 - t));
        const botY = gate.groundY, newTopY = botY - visH;
        gate.face.setSize(gate.w, Math.max(1, visH));
        gate.face.y = botY - visH/2;
        gate.topStrip.y = newTopY - W.topH/2;
        gate.topHL.y = newTopY - W.topH + 1;
        const gc = gate.grooves.length;
        gate.grooves.forEach((g, i) => {
            const ny = botY - gate.fullH*((i+1)/(gc+1));
            g.setVisible(ny >= newTopY && ny <= botY);
        });
        gate.edge.y = botY - 1; gate.edge.setVisible(visH > 2);
        if (gate.rivets.length === 4) {
            const rx = gate.w/2-3, ry = visH/2-3, cy = botY-visH/2;
            if (visH > 8) {
                gate.rivets[0].setPosition(gate.cx-rx,cy-ry).setVisible(true);
                gate.rivets[1].setPosition(gate.cx+rx,cy-ry).setVisible(true);
                gate.rivets[2].setPosition(gate.cx-rx,cy+ry).setVisible(true);
                gate.rivets[3].setPosition(gate.cx+rx,cy+ry).setVisible(true);
            } else gate.rivets.forEach(r => r.setVisible(false));
        }
        if (gate.emblem) { gate.emblem.y = botY-visH/2; gate.emblem.setVisible(visH > 6); }
        // Collision
        if (visH <= 1) { gate.collBody.body && (gate.collBody.body.enable = false); }
        else {
            gate.collBody.body && (gate.collBody.body.enable = true);
            gate.collBody.setSize(gate.w, W.collisionH); gate.collBody.y = botY;
            gate.collBody.body && gate.collBody.body.setSize(gate.w, W.collisionH);
            gate.collBody.body && gate.collBody.body.reset(gate.cx, botY);
        }
        if (visH <= 0) gate.doorParts.forEach(p => p.setVisible(false));
    }

    _openGate(id, duration) {
        const g = this._gates[id]; if (!g || g.open) return; g.open = true;
        const dur = duration !== undefined ? duration : 400;
        if (dur === 0) { this._setGateOpenness(g, 1); return; }
        this.tweens.add({ targets: { val: 0 }, val: 1, duration: dur, ease: 'Power2',
            onUpdate: (tw) => this._setGateOpenness(g, tw.getValue()) });
    }

    _closeGate(id, duration) {
        const g = this._gates[id]; if (!g || !g.open) return; g.open = false;
        const dur = duration !== undefined ? duration : 400;
        g.doorParts.forEach(p => p.setVisible(true));
        g.collBody.body && (g.collBody.body.enable = true);
        if (dur === 0) { this._setGateOpenness(g, 0); return; }
        this.tweens.add({ targets: { val: 1 }, val: 0, duration: dur, ease: 'Power2',
            onUpdate: (tw) => this._setGateOpenness(g, tw.getValue()) });
    }

    /* ════════════════════════════════════════════════════
       EXIT ZONE — trigger near entrance to leave
       ════════════════════════════════════════════════════ */
    _buildExitZone(L) {
        // Interactive exit zone at the east end of the exit tunnel
        const t = L.exitTunnel;
        const zoneX = t.x + t.w - 40;
        const zoneY = t.y;
        const zoneW = 60;
        const zoneH = t.h + 20;

        // Visual arrow indicator
        const arrowG = this.add.graphics().setDepth(5);
        arrowG.fillStyle(0x44aa88, 0.35);
        arrowG.fillTriangle(zoneX + 10, zoneY - 8, zoneX + 30, zoneY, zoneX + 10, zoneY + 8);
        this.tweens.add({ targets: arrowG, alpha: 0.15, duration: 800, yoyo: true, repeat: -1 });

        // "EXIT" label
        const exitLabel = this.add.text(zoneX + 15, zoneY - 20, 'EXIT', {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#44aa88', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(5).setAlpha(0);

        // Proximity zone
        const exitZone = this.add.zone(zoneX + zoneW / 2, zoneY, zoneW, zoneH);
        this.physics.add.existing(exitZone, true);

        this._exitOverlap = this.physics.add.overlap(this.player, exitZone, () => {
            if (this._exiting) return;
            this._exiting = true;

            try { AudioManager.doorOpen(); } catch(e) {}
            exitLabel.setAlpha(1);

            // Brief pause then depart
            this.time.delayedCall(600, () => {
                SceneTransition.fadeTo(this, 'SafehouseScene', {
                    fromHaven: true,
                    playerState: this.playerState,
                    deployedSurvivor: this.deployedSurvivor || null,
                });
            });
        });

        // Show label on approach
        if (this.player) {
            this.events.on('update', () => {
                if (this._exiting) return;
                const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, zoneX, zoneY);
                exitLabel.setAlpha(dist < 80 ? Math.min(1, (80 - dist) / 40) : 0);
            });
        }
    }

    /* ════════════════════════════════════════════════════
       UI — minimal resource bar
       ════════════════════════════════════════════════════ */
    _buildUI() {
        this.resourceText = this.add.text(10, 10, '', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aaaaaa', stroke: '#000000', strokeThickness: 2 }).setScrollFactor(0).setDepth(100);
        this._updateResourceText();
    }

    _updateResourceText() {
        const s = this.state;
        this.resourceText.setText('HP:' + (s.health || 100) + '  Fuel:' + (s.fuel || 100) + '  Scrap:' + (s.scrap || 0));
    }

    // ═══════════════════════════════════════════════════════════════════
    // ═══ LOCKED — WALL MODULE SYSTEM                                ═══
    // ═══ Theme-aware 3/4 iso walls with door frames, anchors, refs. ═══
    // ═══                                                            ═══
    // ═══ Depth rules:                                               ═══
    // ═══   N/S iso walls  = 1.9  (front/back face)                  ═══
    // ═══   E/W side walls = 2.0  (overlap iso at corners)           ═══
    // ═══   Overlap caps   = 2.05 (visual-only, covers gap edges)    ═══
    // ═══   Door frames    = 2.1  (on top of all wall faces)         ═══
    // ═══                                                            ═══
    // ═══ API:                                                       ═══
    // ═══   _buildWallModule(bounds, gaps, opts?) -> ModuleRef       ═══
    // ═══   opts: { theme, doorFrames:bool, anchors:bool }           ═══
    // ═══                                                            ═══
    // ═══ ModuleRef: { bounds, theme, walls{n,s,e,w}, gaps{n,s,e,w},═══
    // ═══            anchors[], allParts[], collisionBodies[] }      ═══
    // ═══                                                            ═══
    // ═══ LOCKED METHODS:                                            ═══
    // ═══   get WALL()                                               ═══
    // ═══   _resolveTheme(theme)                                     ═══
    // ═══   _addWall(x,y,w,h)                                       ═══
    // ═══   _addIsoWall(cx,groundY,w,facing,depth,theme)             ═══
    // ═══   _addIsoWallVisualOnly(cx,groundY,w,facing,depth,theme)   ═══
    // ═══   _addSideWall(cx,topY,botY,side,depth,theme)              ═══
    // ═══   _addSideWallVisualOnly(cx,topY,botY,side,depth,theme)    ═══
    // ═══   _buildSideWallWithGaps(cx,topY,botY,gaps,side,d,theme)   ═══
    // ═══   _buildIsoWallWithGaps(groundY,start,end,gaps,f,d,theme)  ═══
    // ═══   _addNSDoorFrame(gap,groundY,depth,theme)                 ═══
    // ═══   _addEWDoorFrame(gap,cx,depth,theme)                      ═══
    // ═══   _generateAnchors(wallRefs)                               ═══
    // ═══   _buildWallModule(bounds,gaps,opts)                       ═══
    // ═══════════════════════════════════════════════════════════════════

    // --- Default theme constants ---
    get WALL() {
        return {
            frontH: 24, topH: 4, sideW: 8, sideSliver: 3,
            collisionH: 20,
            baseColor: 0x2e2a24, darkColor: 0x22201a,
            lightColor: 0x3a3630, edgeColor: 0x1a1816,
            highlightColor: 0x4a4640,
            // Door frame palette
            frameColor: 0x4a4238, frameDark: 0x2a2622,
            frameHighlight: 0x5a5248
        };
    }

    // --- Merge partial theme over defaults ---
    _resolveTheme(theme) {
        if (!theme) return this.WALL;
        return { ...this.WALL, ...theme };
    }

    // --- Collision-only body (invisible). Returns body ref. ---
    _addWall(x, y, w, h) {
        const wall = this.add.rectangle(x, y, w, h, 0x000000, 0).setDepth(0);
        this.walls.add(wall);
        return wall;
    }

    // --- N/S iso wall: front face + top strip + grooves. ---
    // Returns { parts[], collision, cx, groundY, w, facing, visualTop, visualBot }
    _addIsoWall(cx, groundY, w, facing, depth, theme) {
        const W = this._resolveTheme(theme);
        const d = depth || 1.9;
        // South walls use Y-based depth so player renders BEHIND them
        const effectiveD = (facing === 'south') ? (10 + groundY * 0.01) : d;
        const bY = groundY, fT = bY - W.frontH, tT = fT - W.topH;
        const parts = [];
        if (facing === 'north') {
            parts.push(this.add.rectangle(cx, bY - W.frontH / 2, w, W.frontH, W.baseColor).setDepth(effectiveD));
            for (let i = 1; i <= 3; i++) parts.push(this.add.rectangle(cx, bY - W.frontH * (i/4), w, 1, W.darkColor, 0.3).setDepth(effectiveD+0.01));
            parts.push(this.add.rectangle(cx, bY - 1, w, 2, W.edgeColor).setDepth(effectiveD+0.02));
            parts.push(this.add.rectangle(cx, fT - W.topH/2, w, W.topH, W.lightColor).setDepth(effectiveD+0.03));
            parts.push(this.add.rectangle(cx, tT + 1, w, 1, W.highlightColor, 0.4).setDepth(effectiveD+0.04));
        } else {
            parts.push(this.add.rectangle(cx, bY - W.frontH / 2, w, W.frontH, W.darkColor).setDepth(effectiveD));
            for (let i = 1; i <= 3; i++) parts.push(this.add.rectangle(cx, bY - W.frontH * (i/4), w, 1, W.edgeColor, 0.2).setDepth(effectiveD+0.01));
            parts.push(this.add.rectangle(cx, fT - W.topH/2, w, W.topH, W.baseColor).setDepth(effectiveD+0.03));
            parts.push(this.add.rectangle(cx, tT + 1, w, 1, W.lightColor, 0.3).setDepth(effectiveD+0.04));
        }
        const collision = this._addWall(cx, groundY, w, W.collisionH);

        if (!this._occlusionWalls) this._occlusionWalls = [];
        this._occlusionWalls.push({
            parts, facing, cx, groundY, w,
            left: cx - w/2, right: cx + w/2,
            visualTop: tT, visualBot: bY
        });
        return { parts, collision, cx, groundY, w, facing, visualTop: tT, visualBot: bY };
    }

    // --- Visual-only iso wall. No collision, no occlusion. ---
    // Returns { parts[] }
    _addIsoWallVisualOnly(cx, groundY, w, facing, depth, theme) {
        const W = this._resolveTheme(theme);
        const d = depth || 1.8;
        const effectiveD = (facing === 'south') ? (10 + groundY * 0.01) : d;
        const bY = groundY, fT = bY - W.frontH, tT = fT - W.topH;
        const parts = [];
        if (facing === 'north') {
            parts.push(this.add.rectangle(cx, bY - W.frontH / 2, w, W.frontH, W.baseColor).setDepth(effectiveD));
            for (let i = 1; i <= 3; i++) parts.push(this.add.rectangle(cx, bY - W.frontH * (i/4), w, 1, W.darkColor, 0.3).setDepth(effectiveD+0.01));
            parts.push(this.add.rectangle(cx, bY - 1, w, 2, W.edgeColor).setDepth(effectiveD+0.02));
            parts.push(this.add.rectangle(cx, fT - W.topH/2, w, W.topH, W.lightColor).setDepth(effectiveD+0.03));
            parts.push(this.add.rectangle(cx, tT + 1, w, 1, W.highlightColor, 0.4).setDepth(effectiveD+0.04));
        } else {
            parts.push(this.add.rectangle(cx, bY - W.frontH / 2, w, W.frontH, W.darkColor).setDepth(effectiveD));
            for (let i = 1; i <= 3; i++) parts.push(this.add.rectangle(cx, bY - W.frontH * (i/4), w, 1, W.edgeColor, 0.2).setDepth(effectiveD+0.01));
            parts.push(this.add.rectangle(cx, fT - W.topH/2, w, W.topH, W.baseColor).setDepth(effectiveD+0.03));
            parts.push(this.add.rectangle(cx, tT + 1, w, 1, W.lightColor, 0.3).setDepth(effectiveD+0.04));
        }
        return { parts };
    }

    // --- E/W side wall: depth face + sliver + grooves. ---
    // Returns { parts[], collision, cx, topY, botY, side }
    _addSideWall(cx, topY, botY, side, depth, theme) {
        const W = this._resolveTheme(theme);
        const d = depth || 2.0;
        const h = botY - topY, cy = topY + h / 2;
        const parts = [];
        parts.push(this.add.rectangle(cx, cy, W.sideW, h, W.darkColor).setDepth(d));
        if (side === 'east') {
            parts.push(this.add.rectangle(cx - W.sideW/2 + W.sideSliver/2, cy, W.sideSliver, h, W.baseColor, 0.5).setDepth(d+0.01));
            parts.push(this.add.rectangle(cx + W.sideW/2 - 1, cy, 1, h, W.edgeColor, 0.5).setDepth(d+0.01));
        } else {
            parts.push(this.add.rectangle(cx + W.sideW/2 - W.sideSliver/2, cy, W.sideSliver, h, W.baseColor, 0.5).setDepth(d+0.01));
            parts.push(this.add.rectangle(cx - W.sideW/2 + 1, cy, 1, h, W.edgeColor, 0.5).setDepth(d+0.01));
        }
        for (let i = 1; i <= 3; i++) parts.push(this.add.rectangle(cx, topY + h*(i/4), W.sideW, 1, W.edgeColor, 0.15).setDepth(d+0.02));
        const collision = this._addWall(cx, cy, W.sideW, h);
        return { parts, collision, cx, topY, botY, side };
    }

    // --- Visual-only side wall. No collision. For overlap caps at gap edges. ---
    // Returns { parts[] }
    _addSideWallVisualOnly(cx, topY, botY, side, depth, theme) {
        const W = this._resolveTheme(theme);
        const d = depth || 2.0;
        const h = botY - topY, cy = topY + h / 2;
        if (h <= 0) return { parts: [] };
        const parts = [];
        parts.push(this.add.rectangle(cx, cy, W.sideW, h, W.darkColor).setDepth(d));
        if (side === 'east') {
            parts.push(this.add.rectangle(cx - W.sideW/2 + W.sideSliver/2, cy, W.sideSliver, h, W.baseColor, 0.5).setDepth(d+0.01));
            parts.push(this.add.rectangle(cx + W.sideW/2 - 1, cy, 1, h, W.edgeColor, 0.5).setDepth(d+0.01));
        } else {
            parts.push(this.add.rectangle(cx + W.sideW/2 - W.sideSliver/2, cy, W.sideSliver, h, W.baseColor, 0.5).setDepth(d+0.01));
            parts.push(this.add.rectangle(cx - W.sideW/2 + 1, cy, 1, h, W.edgeColor, 0.5).setDepth(d+0.01));
        }
        for (let i = 1; i <= 3; i++) parts.push(this.add.rectangle(cx, topY + h*(i/4), W.sideW, 1, W.edgeColor, 0.15).setDepth(d+0.02));
        return { parts };
    }

    // --- Side wall with gaps + overlap caps. ---
    // Returns { segments[], overlapCaps[] }
    _buildSideWallWithGaps(cx, topY, botY, gaps, side, depth, theme) {
        const W = this._resolveTheme(theme);
        const sorted = [...gaps].sort((a,b) => a.center - b.center);
        const segments = [], overlapCaps = [];
        let cursor = topY;
        sorted.forEach(gap => {
            const gs = gap.center - gap.size/2, ge = gap.center + gap.size/2;
            if (gs > cursor) segments.push(this._addSideWall(cx, cursor, gs, side, depth, theme));
            cursor = ge;
            // Visual-only overlap: cap the iso wall face that extends upward from ge.
            const overlapTop = ge - W.frontH - W.topH;
            if (overlapTop < ge) {
                overlapCaps.push(this._addSideWallVisualOnly(cx, overlapTop, ge, side, (depth || 2.0) + 0.05, theme));
            }
        });
        if (cursor < botY) segments.push(this._addSideWall(cx, cursor, botY, side, depth, theme));
        return { segments, overlapCaps };
    }

    // --- Iso wall with gaps. ---
    // Returns { segments[] }
    _buildIsoWallWithGaps(groundY, start, end, gaps, facing, depth, theme) {
        const sorted = [...gaps].sort((a,b) => a.center - b.center);
        const segments = [];
        let cursor = start;
        sorted.forEach(gap => {
            const gs = gap.center - gap.size/2, ge = gap.center + gap.size/2;
            if (gs > cursor) segments.push(this._addIsoWall(cursor + (gs-cursor)/2, groundY, gs-cursor, facing, depth, theme));
            cursor = ge;
        });
        if (cursor < end) segments.push(this._addIsoWall(cursor + (end-cursor)/2, groundY, end-cursor, facing, depth, theme));
        return { segments };
    }

    // --- Door frame at a N/S wall gap ---
    // Jambs on left/right edges + lintel across top. 3/4 iso perspective.
    // Returns { parts[] }
    _addNSDoorFrame(gap, groundY, depth, theme) {
        const W = this._resolveTheme(theme);
        const d = (depth || 1.9) + 0.2;  // 2.1 -- above all wall faces
        const gL = gap.center - gap.size / 2;
        const gR = gap.center + gap.size / 2;
        const jW = 3;   // jamb width
        const lH = 3;   // lintel height
        const faceTop = groundY - W.frontH;
        const parts = [];
        // Left jamb -- full front-face height
        parts.push(this.add.rectangle(gL + jW/2, groundY - W.frontH/2, jW, W.frontH, W.frameColor).setDepth(d));
        parts.push(this.add.rectangle(gL + 1, groundY - W.frontH/2, 1, W.frontH, W.frameDark, 0.4).setDepth(d+0.01));
        // Right jamb
        parts.push(this.add.rectangle(gR - jW/2, groundY - W.frontH/2, jW, W.frontH, W.frameColor).setDepth(d));
        parts.push(this.add.rectangle(gR - 1, groundY - W.frontH/2, 1, W.frontH, W.frameDark, 0.4).setDepth(d+0.01));
        // Lintel -- spans gap at top of front face
        parts.push(this.add.rectangle(gap.center, faceTop - lH/2, gap.size, lH, W.frameColor).setDepth(d));
        parts.push(this.add.rectangle(gap.center, faceTop - lH, gap.size, 1, W.frameHighlight, 0.5).setDepth(d+0.01));
        // Bottom sill
        parts.push(this.add.rectangle(gap.center, groundY + 1, gap.size, 2, W.frameDark).setDepth(d));
        return { parts };
    }

    // --- Door frame at an E/W wall gap ---
    // Horizontal header + footer bars across the side wall face.
    // Returns { parts[] }
    _addEWDoorFrame(gap, cx, depth, theme) {
        const W = this._resolveTheme(theme);
        const d = (depth || 2.0) + 0.1;  // 2.1
        const gT = gap.center - gap.size / 2;
        const gB = gap.center + gap.size / 2;
        const barH = 3;
        const parts = [];
        // Header bar at top of gap
        parts.push(this.add.rectangle(cx, gT + barH/2, W.sideW + 2, barH, W.frameColor).setDepth(d));
        parts.push(this.add.rectangle(cx, gT, W.sideW + 2, 1, W.frameHighlight, 0.5).setDepth(d+0.01));
        // Footer bar at bottom of gap
        parts.push(this.add.rectangle(cx, gB - barH/2, W.sideW + 2, barH, W.frameColor).setDepth(d));
        parts.push(this.add.rectangle(cx, gB, W.sideW + 2, 1, W.frameDark, 0.4).setDepth(d+0.01));
        return { parts };
    }

    // --- Generate prop anchors from wall segment refs ---
    // Each segment center -> one anchor. Long segments (>100px) get thirds.
    // Returns anchor[] where each = { id, x, y, wall, groundY|topY }
    _generateAnchors(wallRefs) {
        const anchors = [];
        const idx = { north: 0, south: 0, east: 0, west: 0 };
        wallRefs.forEach(ref => {
            if (!ref) return;
            const dir = ref.facing || ref.side;
            if (!dir) return;
            const n = idx[dir]++;
            if (ref.facing) {
                // N/S iso wall -- anchor at center of front face
                const W = this.WALL;
                anchors.push({ id: `${dir}_${n}`, x: ref.cx, y: ref.groundY - W.frontH / 2, wall: dir, groundY: ref.groundY, segW: ref.w });
                // Thirds for wide segments
                if (ref.w > 100) {
                    anchors.push({ id: `${dir}_${n}_L`, x: ref.cx - ref.w / 3, y: ref.groundY - W.frontH / 2, wall: dir, groundY: ref.groundY, segW: ref.w });
                    anchors.push({ id: `${dir}_${n}_R`, x: ref.cx + ref.w / 3, y: ref.groundY - W.frontH / 2, wall: dir, groundY: ref.groundY, segW: ref.w });
                }
            } else {
                // E/W side wall -- anchor at center
                const cy = (ref.topY + ref.botY) / 2;
                const segH = ref.botY - ref.topY;
                anchors.push({ id: `${dir}_${n}`, x: ref.cx, y: cy, wall: dir, topY: ref.topY, botY: ref.botY, segH });
                if (segH > 100) {
                    anchors.push({ id: `${dir}_${n}_T`, x: ref.cx, y: ref.topY + segH / 3, wall: dir, topY: ref.topY, botY: ref.botY, segH });
                    anchors.push({ id: `${dir}_${n}_B`, x: ref.cx, y: ref.botY - segH / 3, wall: dir, topY: ref.topY, botY: ref.botY, segH });
                }
            }
        });
        return anchors;
    }

    // ═══════════════════════════════════════════════════════════════
    // ═══ _buildWallModule -- complete rectangular room walls     ═══
    // ═══                                                        ═══
    // ═══ bounds: { left, right, top, bot }                      ═══
    // ═══ gaps:   [{ wall:'north'|'south'|'east'|'west',         ═══
    // ═══           center:Number, size:Number }]                ═══
    // ═══ opts:   { theme?, doorFrames:bool, anchors:bool }      ═══
    // ═══                                                        ═══
    // ═══ Returns ModuleRef:                                     ═══
    // ═══   { bounds, theme, walls{n,s,e,w}, gaps{n,s,e,w},     ═══
    // ═══     anchors[], allParts[], collisionBodies[] }         ═══
    // ═══════════════════════════════════════════════════════════════
    _buildWallModule(bounds, gaps, opts) {
        const o = opts || {};
        const W = this._resolveTheme(o.theme);
        const useDoorFrames = o.doorFrames !== undefined ? o.doorFrames : false;
        const useAnchors = o.anchors !== undefined ? o.anchors : false;
        const { left, right, top, bot } = bounds;

        // Side walls overlap iso walls at corners -- extend iso under side walls
        const sideTop = top - W.frontH - W.topH;
        const sideBot = bot;
        const ext = W.sideW / 2;

        // Categorize gaps
        const ng = gaps.filter(g => g.wall==='north');
        const sg = gaps.filter(g => g.wall==='south');
        const eg = gaps.filter(g => g.wall==='east');
        const wg = gaps.filter(g => g.wall==='west');

        // Build each wall, collecting refs
        const wallRefs = { north: [], south: [], east: [], west: [] };
        const allParts = [], collisionBodies = [];

        const collect = (result, dir) => {
            if (!result) return;
            // Single segment ref
            if (result.parts) {
                wallRefs[dir].push(result);
                allParts.push(...result.parts);
                if (result.collision) collisionBodies.push(result.collision);
            }
            // Multi-segment result from withGaps
            if (result.segments) {
                result.segments.forEach(s => {
                    wallRefs[dir].push(s);
                    allParts.push(...s.parts);
                    if (s.collision) collisionBodies.push(s.collision);
                });
            }
            if (result.overlapCaps) {
                result.overlapCaps.forEach(c => { if (c && c.parts) allParts.push(...c.parts); });
            }
        };

        // N/S iso walls (d=1.9)
        if (ng.length) collect(this._buildIsoWallWithGaps(top, left - ext, right + ext, ng, 'north', undefined, o.theme), 'north');
        else collect(this._addIsoWall((left+right)/2, top, right - left + W.sideW, 'north', undefined, o.theme), 'north');

        // South wall — visible with occlusion fade (handled by _addIsoWall + update loop)
        if (sg.length) {
            collect(this._buildIsoWallWithGaps(bot, left - ext, right + ext, sg, 'south', undefined, o.theme), 'south');
        } else {
            collect(this._addIsoWall((left+right)/2, bot, right - left + W.sideW, 'south', undefined, o.theme), 'south');
        }

        // E/W side walls (d=2.0)
        if (eg.length) collect(this._buildSideWallWithGaps(right, sideTop, sideBot, eg, 'east', undefined, o.theme), 'east');
        else collect(this._addSideWall(right, sideTop, sideBot, 'east', undefined, o.theme), 'east');

        if (wg.length) collect(this._buildSideWallWithGaps(left, sideTop, sideBot, wg, 'west', undefined, o.theme), 'west');
        else collect(this._addSideWall(left, sideTop, sideBot, 'west', undefined, o.theme), 'west');

        // Door frames at gap openings
        const gapRefs = { north: [], south: [], east: [], west: [] };
        if (useDoorFrames) {
            ng.forEach(g => { const f = this._addNSDoorFrame(g, top, 1.9, o.theme); gapRefs.north.push({ ...g, frameParts: f.parts }); allParts.push(...f.parts); });
            sg.forEach(g => { const f = this._addNSDoorFrame(g, bot, 1.9, o.theme); gapRefs.south.push({ ...g, frameParts: f.parts }); allParts.push(...f.parts); });
            eg.forEach(g => { const f = this._addEWDoorFrame(g, right, 2.0, o.theme); gapRefs.east.push({ ...g, frameParts: f.parts }); allParts.push(...f.parts); });
            wg.forEach(g => { const f = this._addEWDoorFrame(g, left, 2.0, o.theme); gapRefs.west.push({ ...g, frameParts: f.parts }); allParts.push(...f.parts); });
        } else {
            ng.forEach(g => gapRefs.north.push({ ...g, frameParts: [] }));
            sg.forEach(g => gapRefs.south.push({ ...g, frameParts: [] }));
            eg.forEach(g => gapRefs.east.push({ ...g, frameParts: [] }));
            wg.forEach(g => gapRefs.west.push({ ...g, frameParts: [] }));
        }

        // Prop anchor points
        const allSegments = [...wallRefs.north, ...wallRefs.south, ...wallRefs.east, ...wallRefs.west];
        const anchors = useAnchors ? this._generateAnchors(allSegments) : [];

        return {
            bounds: { left, right, top, bot },
            theme: W,
            walls: wallRefs,
            gaps: gapRefs,
            anchors,
            allParts,
            collisionBodies
        };
    }
    // ═══ END LOCKED: Wall Module System ═══
    _buildPatrolNPCs(L) {
        this._patrolNPCs = []; // Keep array ref for gate proximity checks
        const pr = L.pathRing;
        const ns = L.northSquare;
        const speed = 30;

        // Define waypoints along the path ring (clockwise)
        const ringL = pr.cx - pr.w/2, ringR = pr.cx + pr.w/2;
        const ringT = pr.cy - pr.h/2, ringB = pr.cy + pr.h/2;
        const ringWaypoints = [
            { x: ringL, y: ringB, dir: 'up' },
            { x: ringL, y: ringT, dir: 'right' },
            { x: ringR, y: ringT, dir: 'down' },
            { x: ringR, y: ringB, dir: 'left' },
        ];

        // Connector path waypoints
        const connTop = L.connector.top;
        const connBot = L.connector.bot;
        const connWaypoints = [
            { x: ns.cx, y: connBot + 20, dir: 'up' },
            { x: ns.cx, y: connTop - 20, dir: 'down' },
        ];

        const presets = ['settler_a','settler_b','settler_c','settler_d','settler_e','settler_f'];

        // 2 NPCs walking the ring — via NPCManager
        for (let i = 0; i < 2; i++) {
            const wpIdx = i * 2;
            const wp = ringWaypoints[wpIdx];
            const handle = NPCManager.spawn(this, {
                x: wp.x, y: wp.y, preset: presets[i],
                role: 'patrol', behavior: 'waypoint_patrol',
                behaviorOpts: { waypoints: ringWaypoints, speed: speed + (i * 8), pauseChance: 0.3, pauseMin: 1500, pauseMax: 3000 },
                interior: true
            });
            handle._waypointIdx = wpIdx;
            this._patrolNPCs.push(handle);
        }

        // 1 NPC on connector path
        {
            const wp = connWaypoints[0];
            const handle = NPCManager.spawn(this, {
                x: wp.x, y: wp.y, preset: presets[2],
                role: 'patrol', behavior: 'waypoint_patrol',
                behaviorOpts: { waypoints: connWaypoints, speed: speed - 5, pauseChance: 0.3, pauseMin: 1500, pauseMax: 3000 },
                interior: true
            });
            this._patrolNPCs.push(handle);
        }

        // 2 NPCs chatting (stationary pair near ring bottom-right)
        const chatX = ringR - 30, chatY = ringB - 10;
        const chat1Handle = NPCManager.spawn(this, {
            x: chatX - 12, y: chatY, preset: 'settler_a',
            role: 'conversation', behavior: 'conversation',
            behaviorOpts: { partner: { x: chatX + 12, y: chatY } },
            interior: true
        });
        SpriteManager.stopNPC(chat1Handle.sprite);
        chat1Handle.sprite.setFrame(6); // facing right
        
        const chat2Handle = NPCManager.spawn(this, {
            x: chatX + 12, y: chatY, preset: 'settler_e',
            role: 'conversation', behavior: 'conversation',
            behaviorOpts: { partner: { x: chatX - 12, y: chatY } },
            interior: true
        });
        SpriteManager.stopNPC(chat2Handle.sprite);
        chat2Handle.sprite.setFrame(18); // facing left
    }

    /* ════════════════════════════════════════════════════
       VEHICLE DRIVE-IN
       ════════════════════════════════════════════════════ */
    _startDriveIn(L) {
        const ry = L.roadY;
        const avail = this.parkingSpots.filter(s => !s.occupied);
        const spot = avail[Math.floor(Math.random() * avail.length)] || this.parkingSpots[0];
        if (!spot) { console.error('NO PARKING SPOTS'); return; }
        spot.occupied = true;
        this._parkedSpot = spot;

        // Spawn vehicle off-screen left, facing right
        this.vehicle = SpriteManager.createVehicle(this, -60, ry, 'iso');
        this.vehicle.setDepth(20);
        DynamicShadows.add(this, this.vehicle, { offsetY: 14, scale: 1.2, alpha: 0.15, interior: true });
        this._setVehicleFacing('right');
        this.cameras.main.startFollow(this.vehicle, true, 0.1, 0.1);

        // Drive straight through entrance tunnel to align with parking spot
        this.tweens.add({
            targets: this.vehicle,
            x: spot.x,
            duration: 3500,
            ease: 'Sine.easeInOut',
            onComplete: () => {
                // Turn up, drive into parkway spot
                this._setVehicleFacing('up');
                this.tweens.add({
                    targets: this.vehicle,
                    y: spot.y,
                    duration: 800,
                    ease: 'Sine.easeOut',
                    onComplete: () => {
                        this._setVehicleFacing('right');
                        this._finishParking(spot);
                    }
                });
            }
        });
    }

    _setVehicleFacing(dir) {
        if (!this.vehicle || !this.vehicle._fleetSprite) return;
        try { this.vehicle._fleetSprite.setFrame(VehicleFleet.getFrame(this.vehicle._fleetType || 'pickup', dir, false)); } catch (e) { }
        this.vehicle._facing = dir;
    }

    _finishParking(spot) {
        this._phase = 'exiting';
        this._playerParked = true;
        // Vehicle parks below wall depth so walls properly occlude it
        this.vehicle.setDepth(1.5);
        this.time.delayedCall(400, () => this._exitVehicle(spot));
    }

    _exitVehicle(spot) {
        this.player = SpriteManager.createPlayerSprite(this, spot.x, spot.y + 30, this.state.backpack, this.deployedSurvivor ? this.deployedSurvivor.equippedAura : null);
        this.player.setDepth(20);
        DynamicShadows.add(this, this.player, { offsetY: 10, scale: 0.6, alpha: 0.15, interior: true });
        this.physics.add.existing(this.player);
        this.player.body.setCollideWorldBounds(true);
        this.player.body.setSize(14, 10);
        this.player.body.setOffset(17, 28);
        this.cameras.main.startFollow(this.player, true, 0.08, 0.08);
        InputManager.setup(this, { dodge: false, tapTarget: false });

        // Collide player with walls
        this.physics.add.collider(this.player, this.walls);

        // Vehicle interaction uses same pattern as GameScene
        this.nearVehicle = false;
        this.vehicleMenu = null;

        this._phase = 'walking';
        this.showAnnouncement('UNDERGROUND HAVEN', 'You are safe here.');
    }

    /* ════════════════════════════════════════════════════
       VEHICLE INTERACTION (ported from GameScene)
       ════════════════════════════════════════════════════ */
    _checkVehicleProximity() {
        if (!this.player || !this.vehicle) return;
        this.nearVehicle = false;
        this._nearInteract = null;
        const px = this.player.x, py = this.player.y;
        const vd = Phaser.Math.Distance.Between(px, py, this.vehicle.x, this.vehicle.y);
        if (vd < 55) this.nearVehicle = true;

        // Check room NPC proximity
        if (this._roomNPCs && !this.nearVehicle) {
            const roomKeys = ['factionHQ', 'medBay', 'vendor'];
            this._roomNPCs.forEach((npc, idx) => {
                const d = Phaser.Math.Distance.Between(px, py, npc.x, npc.y);
                if (d < 40) this._nearInteract = { type: roomKeys[idx] || 'npc', npc };
            });
        }
        // Check bounty board proximity
        if (!this.nearVehicle && !this._nearInteract && this._bountyBoardPos) {
            const bd = Phaser.Math.Distance.Between(px, py, this._bountyBoardPos.x, this._bountyBoardPos.y);
            if (bd < 50) this._nearInteract = { type: 'bountyBoard', pos: this._bountyBoardPos };
        }
        // Check portal proximity
        if (!this.nearVehicle && !this._nearInteract && this._portalPos) {
            const pd = Phaser.Math.Distance.Between(px, py, this._portalPos.x, this._portalPos.y);
            if (pd < 55) this._nearInteract = { type: 'portal', pos: this._portalPos };
        }
        // Stash room
        if (!this.nearVehicle && !this._nearInteract && this._stashPos) {
            const sd = Phaser.Math.Distance.Between(px, py, this._stashPos.x, this._stashPos.y);
            if (sd < 45) this._nearInteract = { type: 'stash', pos: this._stashPos };
        }

        if (this.nearVehicle) {
            InteractHighlight.show(this, this.vehicle, 'VEHICLE', { padding: 6 });
        } else if (this._nearInteract) {
            const labels = { factionHQ:'FACTION', medBay:'MEDICAL', vendor:'BARTER', stash:'STORAGE', bountyBoard:'BOUNTY', portal:'PORTAL' };
            const target = this._nearInteract.npc || this._nearInteract.pos || this.player;
            InteractHighlight.show(this, target, labels[this._nearInteract.type] || 'USE', { padding: 5 });
        } else if (!this.vehicleMenu) {
            InteractHighlight.hide(this);
        }
    }

    handleInteract() {
        if (this.popupActive) return;
        if (this.nearVehicle) {
            this.showVehicleMenu();
        } else if (this._nearInteract) {
            const t = this._nearInteract.type;
            if (t === 'medBay') this.showMedicalShop();
            else if (t === 'vendor') this.showBarterShop();
            else if (t === 'factionHQ') this.showFactionMenu();
            else if (t === 'stash') this.showStoragePanel();
            else if (t === 'bountyBoard') this.showBountyBoard();
            else if (t === 'portal') this.showPortalEntry();
        }
    }

    showVehicleMenu() {
        if (this.popupActive) return;
        if (this.vehicleMenu || this.inventoryUI) return;
        const W = CONFIG.width, H = CONFIG.height;
        this.vehicleMenu = [];
        UIAtlas.build(this);
        const panel = UIManager.createPanel(this, W/2, H/2, 180, 200, {
            title: 'VEHICLE', accent: 0x446655, closable: true,
            onClose: () => this.closeVehicleMenu(), depth: 491, modal: true
        });
        panel.setScrollFactor(0);
        this.vehicleMenu.push(panel);
        const cb = panel._contentBounds;
        const invBtn = UIManager.createButton(this, 0, cb.y + 18, 'INVENTORY', {
            width: 140, height: 28, style: 'normal', fontSize: uiPx(10), depth: 492,
            onClick: () => { this.closeVehicleMenu(); this.openInventory(); }
        });
        panel.add(invBtn);
        const mapBtn = UIManager.createButton(this, 0, cb.y + 52, 'MAP', {
            width: 140, height: 28, style: 'normal', fontSize: uiPx(10), depth: 492,
            onClick: () => { this.closeVehicleMenu(); this._leaveHaven('map'); }
        });
        panel.add(mapBtn);
        const extractFuel = this.getExtractFuelCost();
        const canExtract = this.state.fuel >= extractFuel;
        const extBtn = UIManager.createButton(this, 0, cb.y + 86, `EXTRACT (${extractFuel})`, {
            width: 140, height: 28, style: canExtract ? 'confirm' : 'danger', fontSize: uiPx(10), depth: 492,
            onClick: canExtract ? () => { this.closeVehicleMenu(); this._leaveHaven('extract', extractFuel); } : null
        });
        panel.add(extBtn);
    }

    closeVehicleMenu() {
        if (this.vehicleMenu) {
            this.vehicleMenu.forEach(e => { if (e && e.destroy) e.destroy(); });
            this.vehicleMenu = null;
        }
    }

    openInventory() {
        if (this.inventoryUI) return;
        this.inventoryUI = new InventoryUI(
            this,
            this.state.backpack,
            this.state.equipment,
            () => {
                this.inventoryUI = null;
                if (this.player && this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
            }
        );
    }

    /* ════════════════════════════════════════════════════
       UPDATE
       ════════════════════════════════════════════════════ */
    update(time, delta) {
        if (this._phase === 'driving' || this._phase === 'leaving') return;
        if (this._phase !== 'walking' || !this.player || !this.player.body) return;

        const speed = 110;
        let vx = (this.moveDir?.x || 0) * speed;
        let vy = (this.moveDir?.y || 0) * speed;
        this.player.body.setVelocity(vx, vy);
        SpriteManager.updatePlayerAnimation(this.player, vx, vy, this);
        this.player.setDepth(10 + this.player.y * 0.01);

        // ── PROXIMITY GATE CHECK ──
        const px = this.player.x, py = this.player.y;
        const openDist = 60;   // distance to open
        const closeDist = 100; // distance to close
        if (this._gates) {
            Object.values(this._gates).forEach(g => {
                // Check player
                let closest = Math.sqrt((px-g.x)**2 + (py-g.y)**2);
                // Check patrol NPCs
                if (this._patrolNPCs) {
                    this._patrolNPCs.forEach(pn => {
                        const nd = Math.sqrt((pn.sprite.x-g.x)**2 + (pn.sprite.y-g.y)**2);
                        if (nd < closest) closest = nd;
                    });
                }
                if (closest < openDist && !g.open) {
                    this._openGate(g.id, 300);
                } else if (closest > closeDist && g.open) {
                    this._closeGate(g.id, 300);
                }
            });
        }

        // ── VEHICLE PROXIMITY ──
        this._checkVehicleProximity();

        // ── BRANCH ZONE ANNOUNCEMENTS ──
        if (this._branchZones) {
            this._branchZones.forEach(z => {
                const inside = Math.abs(px - z.x) < z.hw && Math.abs(py - z.y) < z.hh;
                if (inside && !z.triggered) {
                    z.triggered = true;
                    this.showAnnouncement(z.label, z.subtitle);
                } else if (!inside && z.triggered) {
                    z.triggered = false;
                }
            });
        }

        // ── NPC BEHAVIOR UPDATE (via NPCManager) ──
        NPCManager.updateAll(this, delta / 1000);

        // ── DYNAMIC SHADOWS ──
        DynamicShadows.update(this);

        // ── WALL OCCLUSION — fade walls when player walks behind them ──
        // Detection: player obscured when behind a wall relative to ¾ camera.
        // Camera is above+south, so N-facing walls block view of anything above them,
        // and S-facing walls block view when player is between wall and camera.
        // Uses gradient alpha based on proximity for smooth reveal.
        if (this._occlusionWalls && this.player) {
            const py = this.player.y;
            const px = this.player.x;
            this._occlusionWalls.forEach(ow => {
                const inX = px > ow.left - 10 && px < ow.right + 10;
                let behindness = 0;  // 0 = not behind, 1 = fully behind

                if (ow.facing === 'south') {
                    // South walls hidden for ¾ camera — skip occlusion
                    return;
                } else {
                    // North wall: only fade when player is just above visual top
                    if (inX && py < ow.visualTop + 6 && py > ow.visualTop - 20) {
                        const dist = ow.visualTop + 6 - py;
                        behindness = Math.min(1, dist / 20);
                    }
                }

                const targetAlpha = behindness > 0.15 ? Math.max(0.2, 1 - behindness * 0.7) : 1.0;
                ow.parts.forEach(p => {
                    p.alpha += (targetAlpha - p.alpha) * 0.18;
                });
            });
        }
    }

    /* ════════════════════════════════════════════════════
       LEAVE HAVEN
       ════════════════════════════════════════════════════ */
    _leaveHaven(destination, extractFuel) {
        if (this._phase === 'leaving') return;
        this._phase = 'leaving';
        InteractHighlight.hide(this);

        // Player enters vehicle — destroy player AND backpack/wings
        if (this.player) {
            if (this.player.backpack) { this.player.backpack.destroy(); }
            if (this.player._crownSprite) { this.player._crownSprite.destroy(); }
            this.player.destroy();
            this.player = null;
        }
        this.cameras.main.startFollow(this.vehicle, true, 0.1, 0.1);

        const L = this.L;

        // Determine what scene to go to after drive-out
        const onExit = () => {
            if (destination === 'extract') {
                this.state.fuel -= extractFuel;
                
                
                SceneTransition.fadeTo(this, 'SafehouseScene', SceneTransition.safehouseReturnData(this));
            } else {
                SceneTransition.fadeTo(this, 'MapScene', SceneTransition.mapReturnData(this));
            }
        };

        this.time.delayedCall(300, () => {
            // Phase 1: Turn down, drive to road
            this._setVehicleFacing('down');
            this.tweens.add({
                targets: this.vehicle,
                y: L.roadY,
                duration: 800,
                ease: 'Sine.easeOut',
                onComplete: () => {
                    // Phase 2: Turn right, drive straight out off-screen
                    this._setVehicleFacing('right');
                    this.tweens.add({
                        targets: this.vehicle,
                        x: L.worldW + 80,
                        duration: 3500,
                        ease: 'Sine.easeIn',
                        onComplete: onExit
                    });
                }
            });
        });
    }

    getExtractFuelCost() {
        const row = this.currentRow || 1;
        return Math.max(5, Math.floor(row * 3));
    }

    _driveWaypoints(waypoints, idx, onComplete) {
        if (idx >= waypoints.length) { onComplete(); return; }
        const wp = waypoints[idx];
        const curX = this.vehicle.x, curY = this.vehicle.y;
        const dx = Math.abs((wp.x !== undefined ? wp.x : curX) - curX);
        const dy = Math.abs((wp.y !== undefined ? wp.y : curY) - curY);
        const dist = Math.sqrt(dx * dx + dy * dy);
        this._setVehicleFacing(wp.dir);
        this.tweens.add({
            targets: this.vehicle,
            x: wp.x !== undefined ? wp.x : curX,
            y: wp.y !== undefined ? wp.y : curY,
            duration: Math.max(350, dist * 5),
            ease: 'Sine.easeInOut',
            onComplete: () => this._driveWaypoints(waypoints, idx + 1, onComplete)
        });
    }

    /* ════════════════════════════════════════════════════
       ANNOUNCEMENTS & PANELS (minimal stubs)
       ════════════════════════════════════════════════════ */
    showAnnouncement(title, subtitle) {
        const container = this.add.container(CONFIG.width / 2, 50).setDepth(200).setAlpha(0).setScrollFactor(0);
        container.add(this.add.rectangle(0, 0, 240, 50, 0x000000, 0.75));
        container.add(this.add.text(0, -8, title, { fontFamily: CONFIG.font, fontSize: uiPx(13), fill: '#fff', fontStyle: 'bold' }).setOrigin(0.5));
        container.add(this.add.text(0, 12, subtitle, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#998877' }).setOrigin(0.5));
        this.tweens.add({ targets: container, alpha: 1, y: 55, duration: 300 });
        this.tweens.add({ targets: container, alpha: 0, y: 45, delay: 2200, duration: 400, onComplete: () => container.destroy() });
    }

    // ═════════════════════════════════════════════════════
    // MEDICAL BAY — buy medical supplies, pay to reveal
    // ═════════════════════════════════════════════════════
    _updateChallenge(sd, stat, amount) {
        if (!sd.haven || !sd.haven.challenges) return;
        ['daily','weekly','monthly'].forEach(t => {
            (sd.haven.challenges[t]||[]).forEach(c => {
                if (c.stat === stat) c.progress = (c.progress || 0) + amount;
            });
        });
    }

    showMedicalShop() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const cx = this.cameras.main.scrollX + W/2, cy = this.cameras.main.scrollY + H/2;
        const panel = UIManager.createPanel(this, cx, cy, W - 20, H - 40, {
            title: 'MEDICAL BAY', accent: 'medical', closable: true,
            onClose: () => this.closePanel(), depth: 500
        });
        this.popupElements = [panel];
        const bits = this.state.bits || (this.saveData ? this.saveData.stash.bits : 0);
        const cb = panel._contentBounds;
        panel.add(this.add.text(0, cb.y, ` ${bits} bits  |  Refreshes: ${HavenShopManager.formatTime(HavenShopManager.timeUntilRotation())}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#556677' }).setOrigin(0.5));
        const shop = HavenShopManager.getMedicalShop(this.state.reach || 1);
        const startY = cb.y + 18;
        shop.forEach((item, i) => {
            const iy = startY + i * 38;
            const def = CONFIG.items[item.id];
            if (item.revealed && def) {
                const row = UIManager.createItemRow(this, 0, iy, cb.w, item, {
                    depth: 501, cost: item.cost, stock: item.stock, revealed: true,
                    onBuy: () => {
                        const sd = this.saveData || SaveManager.load();
                        if (sd.stash.bits >= item.cost && item.stock > 0) {
                            const bought = ItemManager.createItem(item.id);
                            if (bought && ItemManager.addItem(sd.stash.inventory, bought)) {
                                sd.stash.bits -= item.cost; item.stock--;
                                this._updateChallenge(sd, 'shopBuy', 1);
                                SaveManager.save(sd);
                                this.closePanel(); this.showMedicalShop();
                            }
                        }
                    }
                });
                panel.add(row);
            } else {
                const row = UIManager.createItemRow(this, 0, iy, cb.w, null, {
                    depth: 501, cost: 25, revealed: false,
                    onBuy: () => {
                        const sd = this.saveData || SaveManager.load();
                        if (sd.stash.bits >= 25) { sd.stash.bits -= 25; item.revealed = true; SaveManager.save(sd); this.closePanel(); this.showMedicalShop(); }
                    }
                });
                panel.add(row);
            }
        });
    }

    // BARTER — buy/sell equippable items, rebuild gear
    // ═════════════════════════════════════════════════════
    showBarterShop() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const cx = this.cameras.main.scrollX + W/2, cy = this.cameras.main.scrollY + H/2;
        const panel = UIManager.createPanel(this, cx, cy, W - 20, H - 40, {
            title: 'BARTER', accent: 'barter', closable: true,
            onClose: () => this.closePanel(), depth: 500
        });
        this.popupElements = [panel];
        const sd = this.saveData || SaveManager.load();
        const cb = panel._contentBounds;
        if (!this._barterTab) this._barterTab = 'buy';
        panel.add(this.add.text(0, cb.y, ` ${sd.stash.bits} bits  |  Refreshes: ${HavenShopManager.formatTime(HavenShopManager.timeUntilRotation())}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#556677' }).setOrigin(0.5));

        const tabs = UIManager.createTabs(this, 0, cb.y + 18, ['BUY','SELL','REBUILD'],
            ['buy','sell','rebuild'].indexOf(this._barterTab),
            (idx) => { this._barterTab = ['buy','sell','rebuild'][idx]; this.closePanel(); this.showBarterShop(); },
            { tabWidth: 80, depth: 501 }
        );
        panel.add(tabs);

        const startY = cb.y + 42;
        if (this._barterTab === 'buy') {
            if (!this._barterShopCache || this._barterShopCacheRot !== HavenShopManager.getRotationId()) {
                this._barterShopCache = HavenShopManager.getBarterShop(this.state.reach || 1);
                this._barterShopCacheRot = HavenShopManager.getRotationId();
            }
            this._barterShopCache.forEach((item, i) => {
                if (i > 7) return;
                const row = UIManager.createItemRow(this, 0, startY + i * 36, cb.w, item, {
                    depth: 501, cost: item._shopCost, revealed: true,
                    onBuy: () => {
                        if (sd.stash.bits >= item._shopCost) {
                            if (ItemManager.addItem(sd.stash.inventory, item)) {
                                sd.stash.bits -= item._shopCost;
                                this._updateChallenge(sd, 'shopBuy', 1);
                                this._barterShopCache.splice(i, 1);
                                SaveManager.save(sd);
                                this.closePanel(); this.showBarterShop();
                            }
                        }
                    }
                });
                panel.add(row);
            });
        } else if (this._barterTab === 'sell') {
            const inv = sd.stash.inventory;
            let count = 0;
            inv.forEach((item, i) => {
                if (!item || count > 8) return;
                const price = HavenShopManager.getSellPrice(item);
                if (price <= 0) return;
                const iy = startY + count * 32;
                count++;
                const color = item.tierColor ? '#' + item.tierColor.toString(16).padStart(6,'0') : '#aaa';
                const row = this.add.container(0, iy).setDepth(501);
                const bg = this.add.rectangle(0, 0, cb.w, 28, 0x0c0c18, 0.8);
                row.add(bg);
                row.add(this.add.rectangle(-cb.w/2 + 1.5, 0, 3, 28, item.tierColor || 0x888888, 0.8));
                row.add(this.add.text(-cb.w/2 + 10, 0, `${item.icon} ${item.name}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:color, wordWrap:{width:150} }).setOrigin(0, 0.5));
                row.add(this.add.text(cb.w/2 - 8, 0, `+${price}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#44cc44' }).setOrigin(1, 0.5));
                bg.setInteractive({ useHandCursor: true });
                bg.on('pointerdown', () => {
                    sd.stash.bits += price; inv[i] = null; this._updateChallenge(sd, 'shopSell', 1);
                    SaveManager.save(sd);
                    this.closePanel(); this.showBarterShop();
                });
                bg.on('pointerover', () => bg.setFillStyle(0x14141e));
                bg.on('pointerout', () => bg.setFillStyle(0x0c0c18));
                panel.add(row);
            });
            if (count === 0) panel.add(this.add.text(0, startY + 20, 'No sellable items in stash', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#555' }).setOrigin(0.5));
        } else if (this._barterTab === 'rebuild') {
            const ts = sd.haven ? sd.haven.shopTimestamps : {};
            const canRebuild = !ts.lastRebuild || (Date.now() - ts.lastRebuild > 12 * 3600000);
            panel.add(this.add.text(0, startY, 'Rebuild a piece of gear to re-roll its mods.\nOne rebuild every 12 hours.', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#888', wordWrap:{width:W-60}, align:'center' }).setOrigin(0.5));
            if (!canRebuild) {
                const remaining = (12*3600000) - (Date.now() - (ts.lastRebuild||0));
                panel.add(this.add.text(0, startY + 40, `Next rebuild: ${HavenShopManager.formatTime(remaining)}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#aa6644' }).setOrigin(0.5));
            } else {
                let count = 0;
                sd.stash.inventory.forEach((item, i) => {
                    if (!item || !item.procedural || count > 6) return;
                    const iy = startY + 35 + count * 32;
                    count++;
                    const color = item.tierColor ? '#' + item.tierColor.toString(16).padStart(6,'0') : '#aaa';
                    const row = this.add.container(0, iy).setDepth(501);
                    const bg = this.add.rectangle(0, 0, cb.w, 28, 0x0c0c1e, 0.8);
                    row.add(bg);
                    row.add(this.add.rectangle(-cb.w/2 + 1.5, 0, 3, 28, item.tierColor || 0x888888, 0.8));
                    row.add(this.add.text(-cb.w/2 + 10, 0, `${item.icon} ${item.name}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:color, wordWrap:{width:180} }).setOrigin(0, 0.5));
                    row.add(this.add.text(cb.w/2 - 8, 0, 'REBUILD', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#44aacc' }).setOrigin(1, 0.5));
                    bg.setInteractive({ useHandCursor: true });
                    bg.on('pointerdown', () => {
                        const rebuilt = ItemManager.generateItem(item.category, item.tier, 0, this.state.reach || 1);
                        if (rebuilt) {
                            sd.stash.inventory[i] = rebuilt;
                            if (!sd.haven) sd.haven = {};
                            if (!sd.haven.shopTimestamps) sd.haven.shopTimestamps = {};
                            sd.haven.shopTimestamps.lastRebuild = Date.now();
                            SaveManager.save(sd);
                            this.closePanel(); this.showBarterShop();
                        }
                    });
                    bg.on('pointerover', () => bg.setFillStyle(0x14142e));
                    bg.on('pointerout', () => bg.setFillStyle(0x0c0c1e));
                    panel.add(row);
                });
                if (count === 0) panel.add(this.add.text(0, startY + 50, 'No procedural gear in stash to rebuild', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#555' }).setOrigin(0.5));
            }
        }
    }

    // FACTION HUB — pledge, reputation, faction store
    // ═════════════════════════════════════════════════════
    showFactionMenu() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const cx = this.cameras.main.scrollX + W/2, cy = this.cameras.main.scrollY + H/2;
        const panel = UIManager.createPanel(this, cx, cy, W - 20, H - 40, {
            title: 'FACTION HUB', accent: 'faction', closable: true,
            onClose: () => this.closePanel(), depth: 500
        });
        this.popupElements = [panel];
        const sd = this.saveData || SaveManager.load();
        const cb = panel._contentBounds;
        if (!sd.haven) sd.haven = {};
        if (!sd.haven.faction) sd.haven.faction = { pledged: null, reputation: {}, lastChange: 0 };
        const fData = sd.haven.faction;
        const pledged = fData.pledged;
        if (!this._factionTab) this._factionTab = pledged ? 'status' : 'pledge';

        const tabLabels = pledged ? ['STATUS','STORE','CHANGE'] : ['PLEDGE'];
        const tabKeys = pledged ? ['status','store','change'] : ['pledge'];
        const tabs = UIManager.createTabs(this, 0, cb.y + 4, tabLabels,
            tabKeys.indexOf(this._factionTab),
            (idx) => { this._factionTab = tabKeys[idx]; this.closePanel(); this.showFactionMenu(); },
            { tabWidth: 90, depth: 501 }
        );
        panel.add(tabs);

        const startY = cb.y + 28;
        if (this._factionTab === 'pledge' || (this._factionTab === 'change' && pledged)) {
            const factions = HavenShopManager.factions;
            const canChange = !fData.lastChange || (Date.now() - fData.lastChange > 24 * 3600000);
            if (!canChange && this._factionTab === 'change') {
                const remaining = (24*3600000) - (Date.now() - (fData.lastChange||0));
                panel.add(this.add.text(0, startY + 20, `Faction change available in:\n${HavenShopManager.formatTime(remaining)}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#aa6644', align:'center' }).setOrigin(0.5));
            } else {
                Object.entries(factions).forEach(([fid, f], i) => {
                    const iy = startY + i * 42;
                    const isPledged = pledged === fid;
                    const row = this.add.container(0, iy).setDepth(501);
                    const bg = this.add.rectangle(0, 0, cb.w, 36, isPledged ? 0x0e1a0e : 0x0c0c18, 0.8);
                    row.add(bg);
                    if (isPledged) row.add(this.add.rectangle(-cb.w/2 + 1.5, 0, 3, 36, 0x44aa44, 0.8));
                    row.add(this.add.text(-cb.w/2 + 10, -6, `${f.icon} ${f.name}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(10), fill:f.color, fontStyle:'bold' }).setOrigin(0, 0.5));
                    row.add(this.add.text(-cb.w/2 + 10, 8, f.motto, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#556655' }).setOrigin(0, 0.5));
                    if (isPledged) {
                        row.add(this.add.text(cb.w/2 - 8, 0, 'PLEDGED', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#44cc44' }).setOrigin(1, 0.5));
                    } else {
                        bg.setInteractive({ useHandCursor: true });
                        bg.on('pointerdown', () => {
                            fData.pledged = fid;
                            if (!fData.reputation[fid]) fData.reputation[fid] = 0;
                            fData.lastChange = Date.now();
                            SaveManager.save(sd);
                            this._factionTab = 'status';
                            this.closePanel(); this.showFactionMenu();
                        });
                        bg.on('pointerover', () => bg.setFillStyle(0x14141e));
                        bg.on('pointerout', () => bg.setFillStyle(0x0c0c18));
                    }
                    panel.add(row);
                });
            }
        } else if (this._factionTab === 'status' && pledged) {
            const f = HavenShopManager.factions[pledged];
            const rep = fData.reputation[pledged] || 0;
            const rank = HavenShopManager.getRank(rep);
            panel.add(this.add.text(0, startY, `${f.icon} ${f.name}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(14), fill:f.color, fontStyle:'bold' }).setOrigin(0.5));
            panel.add(this.add.text(0, startY + 22, f.motto, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#888' }).setOrigin(0.5));
            panel.add(this.add.text(0, startY + 48, `Rank: ${rank.name}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(11), fill:'#ccaa44' }).setOrigin(0.5));
            panel.add(this.add.text(0, startY + 65, `Reputation: ${rep}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#888' }).setOrigin(0.5));
            const nextRank = HavenShopManager.ranks.find(r => r.rep > rep);
            if (nextRank) {
                const prevRep = rank.rep;
                const progress = (rep - prevRep) / (nextRank.rep - prevRep);
                const barFrame = UIManager.createHealthBar(this, 'party', { x: 0, y: startY + 82, depth: 501, width: 200, height: 10 });
                barFrame.updateHP(rep - prevRep, nextRank.rep - prevRep);
                panel.add(barFrame);
                panel.add(this.add.text(0, startY + 96, `Next: ${nextRank.name} (${nextRank.rep} rep)`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#666' }).setOrigin(0.5));
            }
            panel.add(this.add.text(0, startY + 120, 'Earn reputation by completing Portal runs\nand clearing challenges.', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#555', align:'center' }).setOrigin(0.5));
        } else if (this._factionTab === 'store' && pledged) {
            const rep = fData.reputation[pledged] || 0;
            const shop = HavenShopManager.getFactionShop(pledged, this.state.reach || 1);
            panel.add(this.add.text(0, startY - 5, `${HavenShopManager.factions[pledged].name} Armory  |  Refreshes: ${HavenShopManager.formatTime(HavenShopManager.timeUntilRotation())}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#556677' }).setOrigin(0.5));
            shop.forEach((item, i) => {
                const iy = startY + 15 + i * 38;
                const locked = (item._repRequired || 0) > rep;
                const row = UIManager.createItemRow(this, 0, iy, cb.w, locked ? null : item, {
                    depth: 501, cost: item._shopCost, revealed: !locked,
                    onBuy: locked ? null : () => {
                        if (sd.stash.bits >= item._shopCost && ItemManager.addItem(sd.stash.inventory, item)) {
                            sd.stash.bits -= item._shopCost; this._updateChallenge(sd, 'shopBuy', 1);
                            SaveManager.save(sd);
                            this.closePanel(); this.showFactionMenu();
                        }
                    }
                });
                if (locked) {
                    row.add(this.add.text(0, -4, 'LCK Locked', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#444' }).setOrigin(0.5));
                    row.add(this.add.text(cb.w/2 - 8, 8, `Req: ${item._repRequired} rep`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#aa4444' }).setOrigin(1, 0.5));
                }
                panel.add(row);
            });
        }
    }

    // STORAGE — access safehouse stash
    // ═════════════════════════════════════════════════════
    showStoragePanel() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const cx = this.cameras.main.scrollX + W/2, cy = this.cameras.main.scrollY + H/2;
        const panel = UIManager.createPanel(this, cx, cy, W - 20, H - 40, {
            title: 'STORAGE', accent: 'stash', closable: true,
            onClose: () => this.closePanel(), depth: 500
        });
        this.popupElements = [panel];
        const sd = this.saveData || SaveManager.load();
        const cb = panel._contentBounds;
        const inv = sd.stash.inventory;
        const filled = inv.filter(i => i !== null).length;
        panel.add(this.add.text(0, cb.y, `${filled} / ${inv.length} slots`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#666' }).setOrigin(0.5));

        const cols = 4, cellSize = 52, gridW = cols * cellSize;
        const gridStartX = -gridW/2, gridStartY = cb.y + 14;
        inv.forEach((item, i) => {
            const col = i % cols, row = Math.floor(i / cols);
            const slotX = gridStartX + col * cellSize + cellSize/2;
            const slotY = gridStartY + row * cellSize + cellSize/2;
            const slot = UIManager.createItemSlot(this, slotX, slotY, item ? { id: item.id, rarity: (CONFIG.tiers[item.tier]?.label?.toLowerCase()) || 'common', icon: item.icon, tier: item.tier } : null, { depth: 501 });
            panel.add(slot);
        });
        const resY = gridStartY + Math.ceil(inv.length / cols) * cellSize + 15;
        const resBar = UIManager.createResourceBar(this, 0, resY, {
            bits: sd.stash.bits, fuel: sd.stash.fuel, mag: (ItemManager.getEquipmentStats(sd.equipment || {}).mag || 10), materials: sd.stash.materials || 0
        }, { depth: 501 });
        panel.add(resBar);
    }

    showBountyBoard() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const cx = this.cameras.main.scrollX + W/2, cy = this.cameras.main.scrollY + H/2;
        const panel = UIManager.createPanel(this, cx, cy, W - 20, H - 40, {
            title: 'BOUNTY NET', accent: 'bounty', closable: true,
            onClose: () => this.closePanel(), depth: 500
        });
        this.popupElements = [panel];
        const sd = this.saveData || SaveManager.load();
        const cb = panel._contentBounds;
        if (!sd.haven) sd.haven = {};
        if (!sd.haven.challenges) sd.haven.challenges = { daily:[], weekly:[], monthly:[], lastDailyReset:0, lastWeeklyReset:0, lastMonthlyReset:0 };
        if (!sd.haven.portal) sd.haven.portal = { highestFloor:0, leaderboard:[] };
        if (!this._bountyTab) this._bountyTab = 'challenges';

        const tabs = UIManager.createTabs(this, 0, cb.y + 4, ['CHALLENGES','LEADERBOARD'],
            this._bountyTab === 'challenges' ? 0 : 1,
            (idx) => { this._bountyTab = idx === 0 ? 'challenges' : 'leaderboard'; this.closePanel(); this.showBountyBoard(); },
            { tabWidth: 100, depth: 501 }
        );
        panel.add(tabs);

        const startY = cb.y + 28;
        if (this._bountyTab === 'challenges') {
            const ch = sd.haven.challenges;
            if (ch.lastDailyReset < HavenShopManager.getDailyId()) { ch.daily = HavenShopManager.getChallenges('daily'); ch.lastDailyReset = HavenShopManager.getDailyId(); }
            if (ch.lastWeeklyReset < HavenShopManager.getWeeklyId()) { ch.weekly = HavenShopManager.getChallenges('weekly'); ch.lastWeeklyReset = HavenShopManager.getWeeklyId(); }
            if (ch.lastMonthlyReset < HavenShopManager.getMonthlyId()) { ch.monthly = HavenShopManager.getChallenges('monthly'); ch.lastMonthlyReset = HavenShopManager.getMonthlyId(); }
            SaveManager.save(sd);

            let y = startY;
            const renderSection = (label, challenges) => {
                panel.add(this.add.text(-cb.w/2 + 4, y, label, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#ccaa44', fontStyle:'bold' }).setOrigin(0));
                y += 16;
                if (!challenges || challenges.length === 0) { panel.add(this.add.text(0, y, 'No challenges', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#555' }).setOrigin(0.5)); y += 18; return; }
                challenges.forEach(c => {
                    const done = c.progress >= c.target;
                    const row = this.add.container(0, y).setDepth(501);
                    const bg = this.add.rectangle(0, 0, cb.w, 28, done ? 0x0e1a0e : 0x0c0c18, 0.8);
                    row.add(bg);
                    if (done) row.add(this.add.rectangle(-cb.w/2 + 1.5, 0, 3, 28, 0x44aa44, 0.8));
                    row.add(this.add.text(-cb.w/2 + 8, 0, `${c.icon} ${c.desc}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill: done ? '#44cc44' : '#aaa', wordWrap:{width:180} }).setOrigin(0, 0.5));
                    row.add(this.add.text(cb.w/2 - 8, -5, `${Math.min(c.progress,c.target)}/${c.target}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#888' }).setOrigin(1, 0.5));
                    if (done && !c.claimed) {
                        row.add(this.add.text(cb.w/2 - 8, 6, `+${c.reward}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#ccaa44' }).setOrigin(1, 0.5));
                        bg.setInteractive({ useHandCursor: true });
                        bg.on('pointerdown', () => { c.claimed = true; sd.stash.bits += c.reward; SaveManager.save(sd); this.closePanel(); this.showBountyBoard(); });
                    } else if (done) {
                        row.add(this.add.text(cb.w/2 - 8, 6, 'CLAIMED', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#555' }).setOrigin(1, 0.5));
                    } else {
                        row.add(this.add.text(cb.w/2 - 8, 6, `${c.reward} bits`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#666' }).setOrigin(1, 0.5));
                    }
                    panel.add(row);
                    y += 32;
                });
            };
            renderSection('DAILY', ch.daily);
            renderSection('WEEKLY', ch.weekly);
            renderSection('MONTHLY', ch.monthly);
        } else {
            panel.add(this.add.text(0, startY, 'PORTAL DEPTH LEADERBOARD', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(10), fill:'#ccaa44', fontStyle:'bold' }).setOrigin(0.5));
            panel.add(this.add.text(0, startY + 18, `Your best: Floor ${sd.haven.portal.highestFloor}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#44cc44' }).setOrigin(0.5));
            const lb = sd.haven.portal.leaderboard || [];
            if (lb.length === 0) {
                panel.add(this.add.text(0, startY + 50, 'No runs recorded yet.\nEnter the Portal to begin.', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#555', align:'center' }).setOrigin(0.5));
            }
            lb.sort((a,b) => b.floor - a.floor);
            lb.slice(0, 10).forEach((entry, i) => {
                const iy = startY + 40 + i * 22;
                const medal = i === 0 ? '1ST' : i === 1 ? '2ND' : i === 2 ? '3RD' : `${i+1}.`;
                panel.add(this.add.text(-cb.w/2 + 4, iy, `${medal} Floor ${entry.floor}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill: i < 3 ? '#ccaa44' : '#888' }).setOrigin(0, 0.5));
                panel.add(this.add.text(cb.w/2 - 8, iy, entry.date || '', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#555' }).setOrigin(1, 0.5));
            });
        }
    }

    // PORTAL ENTRY — solo or matchmaking
    // ═════════════════════════════════════════════════════
    showPortalEntry() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const cx = this.cameras.main.scrollX + W/2, cy = this.cameras.main.scrollY + H/2;
        const panel = UIManager.createPanel(this, cx, cy, W - 20, 260, {
            title: 'THE PORTAL', accent: 'portal', closable: true,
            onClose: () => this.closePanel(), depth: 500
        });
        this.popupElements = [panel];
        const sd = this.saveData || SaveManager.load();
        const best = sd.haven && sd.haven.portal ? sd.haven.portal.highestFloor : 0;
        const cb = panel._contentBounds;

        panel.add(this.add.text(0, cb.y + 10, 'Infinite dungeon with scaling difficulty.\nEvery 5 floors: a boss with unique modifiers.\nDying returns you to Haven. No losses.', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#888', align:'center', wordWrap:{width:W-60} }).setOrigin(0.5));
        panel.add(this.add.text(0, cb.y + 45, `Personal best: Floor ${best}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#ccaa44' }).setOrigin(0.5));

        const soloBtn = UIManager.createButton(this, 0, cb.y + 75, 'ENTER SOLO', {
            width: 180, height: 36, style: 'confirm', fontSize: uiPx(11), depth: 501,
            onClick: () => { this.closePanel(); this._enterPortal('solo'); }
        });
        panel.add(soloBtn);

        const matchBtn = UIManager.createButton(this, 0, cb.y + 115, 'MATCHMAKER', {
            width: 180, height: 36, style: 'disabled', fontSize: uiPx(11), depth: 501
        });
        panel.add(matchBtn);
        panel.add(this.add.text(0, cb.y + 137, 'Coming soon', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(7), fill:'#555' }).setOrigin(0.5));
    }

    _enterPortal(mode) {
        const sd = this.saveData || SaveManager.load();
        SceneTransition.fadeTo(this, 'PortalDungeonScene', {
            playerState: this.state,
            equipment: sd.equipment,
            backpack: sd.stash.inventory,
            saveData: sd,
            mode: mode
        }, { duration: 600 });
    }

    closePanel() {
        this.popupActive = false;
        this.popupElements.forEach(el => el.destroy());
        this.popupElements = [];
    }
}

// ==================== PORTAL DUNGEON SCENE ====================
// Infinite scaling dungeon accessed from Haven portal.
// Every 5 floors = boss. Roguelike abilities every 5 floors (max 5).
// Death returns to Haven with no losses. All enemies drop loot.

