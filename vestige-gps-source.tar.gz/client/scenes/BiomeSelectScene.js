// Vestige GPS — BiomeSelectScene
// Extracted from monolith lines 35179-35383
// Imports will be wired in integration pass

import { SaveManager } from '../../core/saveManager.js';
import { uiPx } from '../../core/utils.js';
import { BIOMES } from '../../data/biomesLookup.js';
import { CONFIG } from '../../data/config.js';
import { GrimFont } from '../../data/grimFont.js';
import { AudioManager } from '../audioManager.js';
import { ParallaxBG } from '../rendering/parallaxBG.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { SurvivorSelectScene } from './SurvivorSelectScene.js';


export class BiomeSelectScene extends Phaser.Scene {
    constructor() { super('BiomeSelectScene'); }
    
    create() {
        const W = CONFIG.width, H = CONFIG.height;
        const biomeList = Object.values(BIOMES);
        
        // ── Animated parallax landscape backdrop ──
        this._bgLayers = ParallaxBG.createForMenu(this, 'grassy', 'dusk', 0, H);
        // Dark overlay so text is readable
        this.add.rectangle(W/2, H/2, W, H, 0x08080e, 0.7).setDepth(1);
        
        // Title
        GrimFont.build(this);
        const titleC = GrimFont.drawText(this, W/2, 36, 'CHOOSE YOUR REGION', {
            scale: 0.45, rust: true, depth: 5, center: true
        });
        titleC.setAlpha(0);
        this.tweens.add({ targets: titleC, alpha: 0.9, duration: 800, ease: 'Sine.easeIn' });
        
        this.add.text(W/2, 58, 'This determines your safehouse surroundings', {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#667788'
        }).setOrigin(0.5).setDepth(5).setAlpha(0);
        this.tweens.add({
            targets: this.children.list[this.children.list.length-1],
            alpha: 0.6, duration: 600, delay: 300
        });
        
        // Biome cards
        const cardH = 110, cardW = W - 24, startY = 90, gap = 8;
        this._selected = null;
        this._cards = [];
        
        biomeList.forEach((b, i) => {
            const cy = startY + i * (cardH + gap) + cardH/2;
            const card = this.add.container(W/2, cy).setDepth(2);
            card.setAlpha(0);
            this.tweens.add({ targets: card, alpha: 1, duration: 500, delay: 200 + i*150 });
            
            // Card background
            const bg = this.add.rectangle(0, 0, cardW, cardH, 0x12121a, 0.9);
            card.add(bg);
            
            // Border (starts dim)
            const border = this.add.graphics();
            border.lineStyle(1.5, b.accent, 0.2);
            border.strokeRoundedRect(-cardW/2, -cardH/2, cardW, cardH, 4);
            card.add(border);
            
            // Landscape preview (left side) — biome-specific silhouettes
            const prevW = 100, prevH = cardH - 16;
            const prevX = -cardW/2 + 8 + prevW/2;
            const prevY = 0;
            const pg = this.add.graphics();
            // Sky gradient
            const skyPal = (ParallaxBG._skyPalettes[b.id] || ParallaxBG._skyPalettes.grassy).dusk;
            for (let py = 0; py < prevH; py++) {
                const t = py / prevH;
                const col = ParallaxBG._lerpColor(skyPal.top, skyPal.low, t);
                pg.fillStyle(col, 0.9);
                pg.fillRect(prevX - prevW/2, prevY - prevH/2 + py, prevW, 1);
            }
            // Mountains — biome-specific shape
            pg.fillStyle(b.mountain, 0.9);
            pg.beginPath();
            pg.moveTo(prevX - prevW/2, prevY + 8);
            ParallaxBG._drawSilhouetteScaled(pg, b.id, 'far_front', prevW, prevH * 0.3, prevY - prevH * 0.15, prevX - prevW/2);
            pg.lineTo(prevX + prevW/2, prevY + 8);
            pg.closePath(); pg.fill();
            // Ground
            pg.fillStyle(b.ground, 1);
            pg.fillRect(prevX - prevW/2, prevY + 8, prevW, prevH/2 - 4);
            // Patches
            pg.fillStyle(b.patchCol, 0.5);
            for (let p = 0; p < 6; p++) {
                pg.fillEllipse(
                    prevX - prevW/2 + 10 + Math.random()*80,
                    prevY + 14 + Math.random()*24,
                    4 + Math.random()*8, 3 + Math.random()*5
                );
            }
            // Border
            pg.lineStyle(1, b.accent, 0.3);
            pg.strokeRoundedRect(prevX - prevW/2, prevY - prevH/2, prevW, prevH, 3);
            card.add(pg);
            
            // Name
            const nameX = prevX + prevW/2 + 14;
            const nameText = this.add.text(nameX, -cardH/2 + 14, b.name.toUpperCase(), {
                fontFamily: CONFIG.font, fontSize: uiPx(14), fontStyle: 'bold',
                fill: '#' + b.accent.toString(16).padStart(6, '0')
            }).setOrigin(0, 0.5);
            card.add(nameText);
            
            // Subtitle tag (Plentiful / Scarce / Swarming)
            if (b.subtitle) {
                const tagX = nameText.x + nameText.width + 8;
                const subtitleText = this.add.text(tagX, -cardH/2 + 14, b.subtitle.toUpperCase(), {
                    fontFamily: CONFIG.font, fontSize: uiPx(8),
                    fill: '#' + b.accent.toString(16).padStart(6, '0')
                }).setOrigin(0, 0.5).setAlpha(0.5);
                card.add(subtitleText);
            }
            
            // Description
            card.add(this.add.text(nameX, -cardH/2 + 32, b.desc, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#778899',
                wordWrap: { width: cardW - prevW - 40 }
            }).setOrigin(0, 0));
            
            // Make interactive
            bg.setInteractive({ useHandCursor: true });
            bg.on('pointerover', () => {
                if (this._selected !== b.id) {
                    bg.setFillStyle(0x1a1a24, 0.95);
                    border.clear();
                    border.lineStyle(1.5, b.accent, 0.5);
                    border.strokeRoundedRect(-cardW/2, -cardH/2, cardW, cardH, 4);
                }
            });
            bg.on('pointerout', () => {
                if (this._selected !== b.id) {
                    bg.setFillStyle(0x12121a, 0.9);
                    border.clear();
                    border.lineStyle(1.5, b.accent, 0.2);
                    border.strokeRoundedRect(-cardW/2, -cardH/2, cardW, cardH, 4);
                }
            });
            bg.on('pointerdown', () => {
                this._selectBiome(b.id);
            });
            
            this._cards.push({ id: b.id, bg, border, card, accent: b.accent, cardW, cardH });
        });
        
        // Confirm button (hidden until selection)
        const btnY = startY + biomeList.length * (cardH + gap) + 24;
        this._confirmContainer = this.add.container(W/2, btnY).setDepth(5).setAlpha(0);
        
        const cbg = this.add.rectangle(0, 0, 140, 36, 0x1a3a2a, 0.9);
        cbg.setInteractive({ useHandCursor: true });
        this._confirmContainer.add(cbg);
        this._confirmContainer.add(this.add.rectangle(0, 0, 138, 34, 0x0e0e14, 1));
        this._confirmText = this.add.text(0, 0, 'DEPLOY', {
            fontFamily: CONFIG.font, fontSize: uiPx(14), fontStyle: 'bold', fill: '#44aa66'
        }).setOrigin(0.5);
        this._confirmContainer.add(this._confirmText);
        
        cbg.on('pointerover', () => cbg.setFillStyle(0x2a4a3a, 1));
        cbg.on('pointerout', () => cbg.setFillStyle(0x1a3a2a, 0.9));
        cbg.on('pointerdown', () => {
            if (!this._selected) return;
            this._deploy();
        });
        
        SceneTransition.fadeIn(this, 600);
    }
    
    _selectBiome(id) {
        this._selected = id;
        const biome = BIOMES[id];
        
        // Swap background parallax to selected biome
        if (this._bgLayers) {
            ParallaxBG.destroy(this._bgLayers);
        }
        this._bgLayers = ParallaxBG.createForMenu(this, id, 'dusk', 0, CONFIG.height);
        
        // Update card visuals
        this._cards.forEach(c => {
            const sel = c.id === id;
            c.bg.setFillStyle(sel ? 0x1a2a1a : 0x12121a, sel ? 1 : 0.9);
            c.border.clear();
            c.border.lineStyle(sel ? 2.5 : 1.5, c.accent, sel ? 0.9 : 0.2);
            c.border.strokeRoundedRect(-c.cardW/2, -c.cardH/2, c.cardW, c.cardH, 4);
            
            // Scale pulse on selected
            if (sel) {
                this.tweens.add({
                    targets: c.card, scaleX: 1.02, scaleY: 1.02, duration: 150, yoyo: true,
                    ease: 'Sine.easeOut'
                });
            }
        });
        
        // Show confirm
        this.tweens.add({ targets: this._confirmContainer, alpha: 1, duration: 300 });
    }
    
    _deploy() {
        // Save biome choice
        const saveData = SaveManager.load();
        saveData.biome = this._selected;
        SaveManager.save(saveData);
        
        // Go to survivor selection
        AudioManager.stopMusic(800);
        this.cameras.main.fadeOut(800, 0, 0, 0);
        this.time.delayedCall(800, () => this.scene.start('SurvivorSelectScene'));
    }
}

// ============================================
// SURVIVOR SELECT SCENE — Pick 3 starting survivors
// ============================================

