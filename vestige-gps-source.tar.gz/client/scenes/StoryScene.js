// Vestige GPS — StoryScene
// Extracted from monolith lines 75657-76557
// Imports will be wired in integration pass

import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { GameScene } from './GameScene.js';
import { MapScene } from './MapScene.js';


export class StoryScene extends Phaser.Scene {
    constructor() { super({ key: 'StoryScene' }); }
    
    init(data) {
        this.playerState = data.playerState || {};
        this.destinationNode = data.destinationNode || {};
        this.mapSeed = data.mapSeed;
        this.currentNodeId = data.currentNodeId;
        this.activeRoute = data.activeRoute || null;
        this.deployedSurvivor = data.deployedSurvivor || null;
        this.previousNodeId = data.previousNodeId;
        this.completedNodes = data.completedNodes || [];
        this.traveledRoutes = data.traveledRoutes || [];
    }
    
    create() {
        this.reach = this.destinationNode?.reach || 1;
        this.elements = [];
        
        // Dark background
        this.bg = this.add.rectangle(CONFIG.width/2, CONFIG.height/2, CONFIG.width, CONFIG.height, 0x0a0a0a);
        
        // Ambient dust
        for (let i = 0; i < 12; i++) {
            const p = this.add.circle(
                Phaser.Math.Between(0, CONFIG.width), Phaser.Math.Between(0, CONFIG.height),
                Phaser.Math.Between(1, 2), 0xffffff, 0.04
            );
            this.tweens.add({
                targets: p, y: p.y - Phaser.Math.Between(30, 80), alpha: 0,
                duration: Phaser.Math.Between(4000, 7000), repeat: -1, delay: Phaser.Math.Between(0, 4000)
            });
        }
        
        // Pick a story tree and show the root node
        const trees = this.getStoryTrees();
        this.storyTree = trees[Math.floor(Math.random() * trees.length)];
        
        this.cameras.main.fadeIn(400);
        this.showNode(this.storyTree.root);
    }
    
    clearPage() {
        this.elements.forEach(el => {
            if (el && el.destroy) el.destroy();
        });
        this.elements = [];
    }
    
    showNode(nodeId) {
        this.clearPage();
        
        const node = this.storyTree.nodes[nodeId];
        if (!node) { this.exitToMap(); return; }
        
        // Apply any effects from this node
        if (node.effect) this.applyEffect(node.effect);
        
        const W = CONFIG.width;
        const H = CONFIG.height;
        const addEl = (el) => { this.elements.push(el); return el; };
        
        // === TOP: Icon + Title ===
        if (node.icon) {
            addEl(this.add.text(W/2, 50, node.icon, { fontSize: uiPx(32) }).setOrigin(0.5).setAlpha(0));
        }
        
        // Scene title (small, subdued)
        if (node.title) {
            addEl(this.add.text(W/2, 85, node.title, {
                fontFamily: CONFIG.font, fontSize: uiPx(13), fill: '#aa77cc', fontStyle: 'bold',
                letterSpacing: 2
            }).setOrigin(0.5).setAlpha(0));
        }
        
        // Divider line
        const divG = addEl(this.add.graphics());
        divG.lineStyle(1, 0x443355, 0.4);
        divG.lineBetween(W/2 - 80, 105, W/2 + 80, 105);
        divG.setAlpha(0);
        
        // === MIDDLE: Story text ===
        const textEl = addEl(this.add.text(W/2, 170, node.text, {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#ccc', align: 'center',
            wordWrap: { width: 280 }, lineSpacing: 7
        }).setOrigin(0.5).setAlpha(0));
        
        // === Flavor text (optional, smaller, italic feel) ===
        let flavorY = 170;
        if (textEl.height) flavorY = 170 + textEl.height / 2 + 15;
        if (node.flavor) {
            addEl(this.add.text(W/2, flavorY, node.flavor, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#776688', align: 'center',
                wordWrap: { width: 260 }, lineSpacing: 4, fontStyle: 'italic'
            }).setOrigin(0.5).setAlpha(0));
        }
        
        // === BOTTOM: Choices ===
        if (node.choices && node.choices.length > 0) {
            const choiceH = 50;
            const totalH = node.choices.length * choiceH + (node.choices.length - 1) * 6;
            const startY = H - 30 - totalH;
            
            node.choices.forEach((choice, i) => {
                const btnY = startY + i * (choiceH + 6);
                
                const btn = addEl(this.add.rectangle(W/2, btnY, 290, choiceH, 0x13131a));
                btn.setStrokeStyle(1, 0x333344);
                btn.setAlpha(0);
                
                // Choice text
                const label = addEl(this.add.text(W/2 - 130, btnY - 8, choice.label, {
                    fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#ddd', fontStyle: 'bold'
                }).setOrigin(0, 0.5).setAlpha(0));
                
                // Description
                if (choice.desc) {
                    addEl(this.add.text(W/2 - 130, btnY + 10, choice.desc, {
                        fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#666'
                    }).setOrigin(0, 0.5).setAlpha(0));
                }
                
                // Risk tag
                const riskColors = { safe: '#4a7', risky: '#aa7', dangerous: '#a55' };
                if (choice.risk) {
                    addEl(this.add.text(W/2 + 132, btnY, choice.risk.toUpperCase(), {
                        fontFamily: CONFIG.font, fontSize: uiPx(7), fill: riskColors[choice.risk] || '#555'
                    }).setOrigin(1, 0.5).setAlpha(0));
                }
                
                // Interactivity
                btn.setInteractive();
                btn.on('pointerover', () => {
                    btn.setFillStyle(0x1e1e2a);
                    btn.setStrokeStyle(1, 0x7755aa);
                    label.setColor('#fff');
                });
                btn.on('pointerout', () => {
                    btn.setFillStyle(0x13131a);
                    btn.setStrokeStyle(1, 0x333344);
                    label.setColor('#ddd');
                });
                btn.on('pointerdown', () => {
                    // Disable input during transition
                    this.elements.forEach(el => { if (el.removeInteractive) el.removeInteractive(); });
                    this.transitionTo(choice.next, choice.effect);
                });
            });
        }
        
        // Animate elements in with stagger
        this.elements.forEach((el, i) => {
            if (el.setAlpha) {
                this.tweens.add({
                    targets: el, alpha: 1, y: (el.y || 0),
                    duration: 350, delay: i * 40, ease: 'Power2'
                });
            }
        });
    }
    
    transitionTo(nextId, effect) {
        if (effect) this.applyEffect(effect);
        
        // Fade out current elements
        this.elements.forEach((el, i) => {
            if (el.setAlpha) {
                this.tweens.add({
                    targets: el, alpha: 0,
                    duration: 250, delay: i * 15
                });
            }
        });
        
        this.time.delayedCall(400, () => {
            if (nextId === '_combat') {
                this.exitToCombat();
            } else if (nextId === '_map' || !nextId) {
                this.exitToMap();
            } else {
                this.showNode(nextId);
            }
        });
    }
    
    applyEffect(effect) {
        if (!effect) return;
        if (effect.bits) this.playerState.bits = (this.playerState.bits || 0) + effect.bits;
        if (effect.fuel) this.playerState.fuel = Math.min(100, (this.playerState.fuel || 0) + effect.fuel);
        if (effect.hp) this.playerState.health = Math.min(CONFIG.player.health, (this.playerState.health || 100) + effect.hp);
        if (effect.powerAmmo) this.playerState.powerAmmo = (this.playerState.powerAmmo || 0) + effect.powerAmmo;
        if (effect.damage) this.playerState.health = Math.max(1, (this.playerState.health || 100) - effect.damage);
        
        // Show effect toast
        const parts = [];
        if (effect.bits > 0) parts.push('+' + effect.bits + ' bits');
        if (effect.bits < 0) parts.push(effect.bits + ' bits');
        if (effect.fuel > 0) parts.push('+' + effect.fuel + ' fuel');
        if (effect.fuel < 0) parts.push(effect.fuel + ' fuel');
        if (effect.hp) parts.push('+' + effect.hp + ' HP');
        if (effect.powerAmmo > 0) parts.push('+' + effect.powerAmmo + ' pwr ammo');
        if (effect.powerAmmo < 0) parts.push(effect.powerAmmo + ' pwr ammo');
        if (effect.damage) parts.push('-' + effect.damage + ' HP');
        
        if (parts.length > 0) {
            const toast = this.add.text(CONFIG.width / 2, CONFIG.height - 15, parts.join('  '), {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#88ddaa', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(50);
            this.tweens.add({
                targets: toast, y: toast.y - 25, alpha: 0,
                duration: 1500, delay: 800, onComplete: () => toast.destroy()
            });
        }
    }
    
    exitToMap() {
        SceneTransition.fadeTo(this, 'MapScene', {
            playerState: this.playerState,
            currentNodeId: this.currentNodeId,
            previousNodeId: this.previousNodeId,
            completedNodes: this.completedNodes,
            traveledRoutes: this.traveledRoutes,
            mapSeed: this.mapSeed
        });
    }
    
    exitToCombat() {
        this.destinationNode.type = 'encounter';
        SceneTransition.fadeTo(this, 'GameScene', {
            playerState: this.playerState,
            destinationNode: this.destinationNode,
            mapSeed: this.mapSeed,
            currentNodeId: this.currentNodeId,
            previousNodeId: this.previousNodeId,
            completedNodes: this.completedNodes,
            traveledRoutes: this.traveledRoutes
        });
    }
    
    getStoryTrees() {
        const reach = this.reach;
        const bitReward = 25 + reach * 10;
        const bigReward = 50 + reach * 15;
        
        return [
            // === THE WANDERER ===
            {
                root: 'intro',
                nodes: {
                    intro: {
                        icon: '\u{1F9D1}', title: 'The Wanderer',
                        text: 'A figure emerges from the haze.\nHands raised. No weapons visible.\n\nThey stop ten paces away.',
                        flavor: '"Don\'t shoot. I just want to talk."',
                        choices: [
                            { label: 'Lower your weapon', desc: 'Hear them out', next: 'talk', risk: 'safe' },
                            { label: 'Keep your distance', desc: 'Stay alert', next: 'cautious', risk: 'safe' },
                            { label: 'Aim at them', desc: 'Show dominance', next: 'threaten', risk: 'risky' }
                        ]
                    },
                    talk: {
                        icon: '\u{1F4AC}', title: 'An Offer',
                        text: 'They relax slightly.\n\n"My camp is overrun. Crawlers, maybe worse.\nI have supplies — medicine, ammo.\nHelp me clear it and they\'re yours."',
                        choices: [
                            { label: 'Accept the job', desc: 'Fight alongside them', next: 'accept' },
                            { label: 'Ask for payment upfront', desc: 'Trust is earned', next: 'negotiate' },
                            { label: 'Decline', desc: 'Wish them luck', next: 'decline_kind' }
                        ]
                    },
                    cautious: {
                        icon: '\u{1F441}', title: 'Standoff',
                        text: 'You keep your hand near your weapon.\nThey notice. Their smile fades.\n\n"Look, I get it. Nobody trusts anyone anymore.\nBut I need help. My camp is two clicks north."',
                        choices: [
                            { label: 'What\'s in it for me?', desc: 'Negotiate terms', next: 'negotiate' },
                            { label: 'Lead the way', desc: 'Actions speak louder', next: 'accept' },
                            { label: 'Walk away', desc: 'Not your problem', next: 'leave' }
                        ]
                    },
                    threaten: {
                        icon: '⚠', title: 'Fear',
                        text: 'They freeze. Eyes wide.\n\n"Okay — okay! Take this. Just let me go."\n\nThey toss a small pouch at your feet\nand back away slowly.',
                        effect: { bits: Math.floor(bitReward * 0.6) },
                        choices: [
                            { label: 'Take it and let them go', desc: 'You got what you need', next: 'leave_cold' },
                            { label: 'Wait — what else?', desc: 'Push your luck', next: 'push_luck' }
                        ]
                    },
                    negotiate: {
                        icon: '\u{1F91D}', title: 'Terms',
                        text: 'They think for a moment, then nod.\n\n"Half now, half after. Fair?"\n\nThey hand you a clip of ammunition\nand a handful of bits.',
                        effect: { bits: Math.floor(bitReward * 0.5), powerAmmo: 5 },
                        choices: [
                            { label: 'Deal. Let\'s move.', desc: 'Time to fight', next: 'fight_together' },
                            { label: 'I want it all upfront', desc: 'All or nothing', next: 'all_upfront' }
                        ]
                    },
                    accept: {
                        icon: '\u{1F91D}', title: 'Alliance',
                        text: 'They look relieved.\n\n"Thank you. Seriously.\nStay close — the crawlers come in waves."',
                        flavor: 'You follow them north through the rubble.',
                        choices: [
                            { label: 'Continue', next: 'fight_together' }
                        ]
                    },
                    fight_together: {
                        icon: '⚔', title: 'The Camp',
                        text: 'The camp is worse than described.\nOverturned barricades. Claw marks everywhere.\n\nA low chittering rises from the shadows.',
                        flavor: '"Here they come. Ready?"',
                        effect: { bits: bitReward },
                        choices: [
                            { label: 'Fight!', desc: 'Clear the camp', next: '_combat', risk: 'dangerous' }
                        ]
                    },
                    all_upfront: {
                        icon: '\u{1F624}', title: 'Tension',
                        text: '"Are you serious right now?"\n\nThey stare at you. Long pause.\n\n"...Fine. Take it all.\nBut you better not bail on me."',
                        effect: { bits: bitReward, powerAmmo: 8 },
                        choices: [
                            { label: 'A deal\'s a deal', desc: 'Head to the camp', next: 'fight_together' },
                            { label: 'Actually, I\'m leaving', desc: 'Take the money and run', next: 'betrayal' }
                        ]
                    },
                    betrayal: {
                        icon: '\u{1F494}', title: 'Betrayal',
                        text: '"You — you\'re just going to—"\n\nTheir voice breaks. They don\'t follow.\n\nYou walk away with everything they had.',
                        flavor: 'The screaming starts twenty minutes later.',
                        choices: [
                            { label: '...', desc: 'Keep walking', next: '_map' }
                        ]
                    },
                    push_luck: {
                        icon: '\u{1F4A5}', title: 'Bad Call',
                        text: 'Their fear turns to desperation.\nA hidden blade flashes.\n\nYou stumble back — cut across the arm.',
                        flavor: 'They vanish into the ruins before you can react.',
                        effect: { damage: 15 },
                        choices: [
                            { label: 'Damn.', next: '_map' }
                        ]
                    },
                    decline_kind: {
                        icon: '\u{1F44B}', title: 'Parting',
                        text: '"I understand. Be safe out there."\n\nThey hesitate, then press something into your hand.\n\n"Take this anyway. You might need it."',
                        effect: { bits: Math.floor(bitReward * 0.3), powerAmmo: 3 },
                        choices: [
                            { label: 'Thank them', next: '_map' }
                        ]
                    },
                    leave: {
                        title: 'Moving On',
                        text: 'You turn and keep walking.\nTheir voice fades behind you.',
                        flavor: 'Some roads are walked alone.',
                        choices: [
                            { label: 'Continue', next: '_map' }
                        ]
                    },
                    leave_cold: {
                        title: 'Cold Comfort',
                        text: 'They disappear into the haze.\nYou pocket the bits and keep moving.',
                        choices: [
                            { label: 'Continue', next: '_map' }
                        ]
                    }
                }
            },
            
            // === THE SIGNAL ===
            {
                root: 'intro',
                nodes: {
                    intro: {
                        icon: '\u{1F4FB}', title: 'The Signal',
                        text: 'Your radio crackles.\nStatic, then fragments of a voice.\n\n"...anyone... coordinates... medicine..."',
                        flavor: 'The signal is weak. Coming from the east.',
                        choices: [
                            { label: 'Respond', desc: 'Open communications', next: 'respond', risk: 'risky' },
                            { label: 'Trace the signal', desc: 'Find them silently', next: 'trace', risk: 'risky' },
                            { label: 'Radio silence', desc: 'Could be a trap', next: 'silence', risk: 'safe' }
                        ]
                    },
                    respond: {
                        icon: '\u{1F4E1}', title: 'Contact',
                        text: '"Oh thank god. You\'re real."\n\nThe voice steadies. A woman.\n\n"We\'re holed up in the old water tower.\nThree of us. We have supplies to trade\nbut something is circling outside."',
                        choices: [
                            { label: 'I\'m on my way', desc: 'Head to the water tower', next: 'approach_tower' },
                            { label: 'What do you have?', desc: 'Negotiate first', next: 'negotiate_radio' },
                            { label: 'Describe what\'s out there', desc: 'Intel first', next: 'intel' }
                        ]
                    },
                    trace: {
                        icon: '\u{1F50D}', title: 'Following the Signal',
                        text: 'You track the signal through collapsed streets.\nThe source grows stronger.\n\nA water tower, barricaded at the base.\nMovement in the shadows below.',
                        choices: [
                            { label: 'Scout the perimeter', desc: 'Count the threats', next: 'scout' },
                            { label: 'Announce yourself', desc: 'Call out to them', next: 'approach_tower' },
                            { label: 'Watch and wait', desc: 'Let the situation develop', next: 'wait' }
                        ]
                    },
                    silence: {
                        title: 'Static',
                        text: 'You switch off the radio.\n\nThe signal fades to nothing.\nYou\'ll never know who was out there.',
                        flavor: 'Sometimes the safest choice is no choice at all.',
                        choices: [
                            { label: 'Move on', next: '_map' }
                        ]
                    },
                    negotiate_radio: {
                        icon: '\u{1F4AC}', title: 'Haggling',
                        text: '"We have antibiotics. Fuel cans.\nA working pistol with six rounds.\n\nJust... please. There\'s a child up here."',
                        flavor: 'Her voice cracks on the last word.',
                        choices: [
                            { label: 'Coming. No payment needed.', next: 'approach_tower_kind', effect: { hp: 10 } },
                            { label: 'I\'ll clear them. Fuel is mine.', next: 'approach_tower' },
                            { label: 'I can\'t risk it. Sorry.', next: 'refuse' }
                        ]
                    },
                    intel: {
                        icon: '\u{1F50A}', title: 'Intelligence',
                        text: '"Four... no, five of them. Big ones.\nThey came at dusk. Haven\'t left.\n\nThey\'re not like normal crawlers.\nThey\'re... coordinated."',
                        flavor: 'Stalkers. Has to be.',
                        choices: [
                            { label: 'I know what those are. Coming.', next: 'approach_tower' },
                            { label: 'That\'s too many. Sorry.', next: 'refuse' }
                        ]
                    },
                    scout: {
                        icon: '\u{1F441}', title: 'Perimeter',
                        text: 'You count five hostiles.\nStalkers — lean, fast, flanking in pairs.\n\nOne guards a drainage entrance.\nThe others circle the tower base.',
                        flavor: 'The drain could be your way in.',
                        choices: [
                            { label: 'Use the drainage tunnel', desc: 'Risky flank', next: 'tunnel', risk: 'dangerous' },
                            { label: 'Attack head-on', desc: 'No surprises', next: 'fight_direct', risk: 'dangerous' },
                            { label: 'Create a distraction', desc: 'Draw them away', next: 'distraction' }
                        ]
                    },
                    wait: {
                        icon: '⌛', title: 'Patience',
                        text: 'You wait. An hour passes.\n\nThe stalkers grow restless. Two leave.\nThen a third. Only two remain.',
                        flavor: 'Better odds now.',
                        effect: { bits: 10 },
                        choices: [
                            { label: 'Strike now', desc: 'Only two left', next: 'fight_easy' },
                            { label: 'Wait longer', desc: 'Maybe they\'ll all leave', next: 'wait_more' }
                        ]
                    },
                    wait_more: {
                        icon: '⌛', title: 'Too Long',
                        text: 'The remaining stalkers don\'t leave.\nReinforcements arrive instead.\n\nSeven now. Too many.',
                        flavor: 'From above, a faint cry. The signal goes dead.',
                        choices: [
                            { label: 'It\'s too late', next: '_map' }
                        ]
                    },
                    approach_tower: {
                        icon: '\u{1F5FC}', title: 'The Tower',
                        text: 'You approach the water tower.\nThe creatures turn toward you.\n\nFrom above: "LOOK OUT!"',
                        effect: { fuel: 8, powerAmmo: 6 },
                        choices: [
                            { label: 'Fight!', desc: 'Clear them out', next: '_combat', risk: 'dangerous' }
                        ]
                    },
                    approach_tower_kind: {
                        icon: '\u{1F5FC}', title: 'The Tower',
                        text: 'You sprint toward the tower.\nNo negotiation. No hesitation.\n\nThe creatures notice you.',
                        effect: { fuel: 12, powerAmmo: 8, bits: bitReward },
                        choices: [
                            { label: 'Fight!', desc: 'Protect them', next: '_combat', risk: 'dangerous' }
                        ]
                    },
                    tunnel: {
                        icon: '\u{1F573}', title: 'The Tunnel',
                        text: 'You crawl through the drainage pipe.\nDark. Tight. Something skitters ahead.\n\nYou emerge inside the barricade.\nThe stalker at the entrance didn\'t see you.',
                        flavor: 'Now you\'re inside. But so is one of them.',
                        effect: { damage: 10 },
                        choices: [
                            { label: 'Ambush it', desc: 'Element of surprise', next: 'fight_easy' }
                        ]
                    },
                    distraction: {
                        icon: '\u{1F4A5}', title: 'Diversion',
                        text: 'You throw a fuel can into the rubble\nand ignite it. The explosion draws three.\n\nTwo remain, confused.',
                        effect: { fuel: -5 },
                        choices: [
                            { label: 'Strike while they\'re split', next: 'fight_easy' }
                        ]
                    },
                    fight_direct: {
                        icon: '⚔', title: 'Head On',
                        text: 'No tricks. No stealth.\nYou walk straight at them.\n\nAll five turn to face you.',
                        choices: [
                            { label: 'Bring it on', next: '_combat', risk: 'dangerous' }
                        ]
                    },
                    fight_easy: {
                        icon: '⚔', title: 'Advantage',
                        text: 'The odds are in your favor.\nThe survivors cheer from above.',
                        effect: { bits: bigReward, fuel: 10 },
                        choices: [
                            { label: 'Finish it', next: '_combat' }
                        ]
                    },
                    refuse: {
                        title: 'Silence',
                        text: 'You switch off the radio.\n\nThe static dies. Then the screaming starts.\nThen that dies too.',
                        choices: [
                            { label: '...', next: '_map' }
                        ]
                    }
                }
            },
            
            // === THE CACHE ===
            {
                root: 'intro',
                nodes: {
                    intro: {
                        icon: '\u{1F537}', title: 'Cube Markings',
                        text: 'Spray-painted on the concrete.\nThe symbol of the Cube — unmistakable.\n\nArrows lead down a narrow alley\ntoward a half-buried door.',
                        choices: [
                            { label: 'Follow the arrows', desc: 'The Cube provides', next: 'door', risk: 'safe' },
                            { label: 'Check for traps first', desc: 'Careful approach', next: 'check_traps' },
                            { label: 'Ignore it', desc: 'Trust nothing', next: 'ignore', risk: 'safe' }
                        ]
                    },
                    door: {
                        icon: '\u{1F6AA}', title: 'The Door',
                        text: 'The door is heavy. Rusted.\nBut the lock has been oiled recently.\n\nIt swings open to reveal stairs\nleading down into darkness.',
                        choices: [
                            { label: 'Descend', desc: 'Into the dark', next: 'basement', risk: 'risky' },
                            { label: 'Call out first', desc: '"Hello?"', next: 'call_out' }
                        ]
                    },
                    check_traps: {
                        icon: '\u{1F50D}', title: 'Careful',
                        text: 'You scan the entrance.\nNo tripwires. No pressure plates.\n\nBut there are footprints —\nrecent, heading in. None coming out.',
                        choices: [
                            { label: 'Go in anyway', next: 'door' },
                            { label: 'Those prints worry me', next: 'ignore' }
                        ]
                    },
                    call_out: {
                        icon: '\u{1F50A}', title: 'Echo',
                        text: 'Your voice bounces off the walls.\n\nSilence. Then —\na faint hum. Mechanical.\n\nSomething activates below.',
                        choices: [
                            { label: 'Investigate the hum', next: 'basement' },
                            { label: 'Nope. Leaving.', next: 'ignore', effect: { bits: 5 } }
                        ]
                    },
                    basement: {
                        icon: '✨', title: 'The Shrine',
                        text: 'The stairs open into a chamber.\nCandles — still lit. Someone was here.\n\nIn the center, a Cube fragment\npulses with violet light.\n\nShelves line the walls. Supplies.',
                        choices: [
                            { label: 'Take the Cube fragment', desc: 'Raw power', next: 'take_cube', risk: 'risky' },
                            { label: 'Loot the shelves', desc: 'Practical supplies', next: 'loot_shelves', risk: 'safe' },
                            { label: 'Take everything', desc: 'Why choose?', next: 'take_all', risk: 'dangerous' }
                        ]
                    },
                    take_cube: {
                        icon: '\u{1F52E}', title: 'Resonance',
                        text: 'The fragment hums in your palm.\nYour vision blurs. Colors shift.\n\nFor a moment, you see the world\nas the Cube sees it — geometry everywhere.\n\nThen it fades. Power remains.',
                        effect: { bits: bigReward },
                        choices: [
                            { label: 'Leave the shrine', next: 'exit_clean' },
                            { label: 'Also grab the shelves', next: 'greedy', risk: 'risky' }
                        ]
                    },
                    loot_shelves: {
                        icon: '\u{1F4E6}', title: 'Supplies',
                        text: 'Ammunition. Bandages. Fuel canisters.\nWhoever stocked this was serious.\n\nThe Cube fragment watches from its pedestal,\npulsing steadily.',
                        effect: { powerAmmo: 0, fuel: 8, hp: 15 },
                        choices: [
                            { label: 'Leave the fragment alone', next: 'exit_clean' },
                            { label: 'Take the fragment too', next: 'greedy', risk: 'risky' }
                        ]
                    },
                    take_all: {
                        icon: '\u{1F49C}', title: 'Greed',
                        text: 'You grab everything. Shelves, fragment, all of it.\n\nThe candles flicker. The hum deepens.\nThe floor trembles.',
                        effect: { bits: bigReward, powerAmmo: 0, fuel: 8 },
                        choices: [
                            { label: 'RUN', next: 'collapse', risk: 'dangerous' }
                        ]
                    },
                    greedy: {
                        icon: '⚠', title: 'Tremor',
                        text: 'As you reach for more, the room shudders.\nDust falls from the ceiling.\n\nThe Cube fragment flares — bright, angry.\nThe stairs begin to crumble.',
                        choices: [
                            { label: 'Sprint for the exit!', next: 'collapse', risk: 'dangerous' }
                        ]
                    },
                    collapse: {
                        icon: '\u{1F4A5}', title: 'Collapse',
                        text: 'You scramble up the stairs\nas the ceiling comes down behind you.\n\nDaylight. Dust. Coughing.\n\nYou made it. Barely.',
                        effect: { damage: 15 },
                        choices: [
                            { label: 'Dust yourself off', next: '_map' }
                        ]
                    },
                    exit_clean: {
                        title: 'Clean Exit',
                        text: 'You climb the stairs calmly.\nThe door shuts behind you.\n\nWhen you glance back,\nthe Cube markings have faded.',
                        choices: [
                            { label: 'Continue', next: '_map' }
                        ]
                    },
                    ignore: {
                        title: 'Passed By',
                        text: 'You walk past the markings.\n\nNot everything needs to be explored.\nNot every mystery needs solving.',
                        choices: [
                            { label: 'Keep moving', next: '_map' }
                        ]
                    }
                }
            },
            
            // === THE TRADER ===
            {
                root: 'intro',
                nodes: {
                    intro: {
                        icon: '\u{1F3AA}', title: 'The Trader',
                        text: 'A makeshift stall blocks the road.\nTarps, ropes, crates stacked high.\n\nA figure in a heavy coat waves you over.\nGold tooth glinting.',
                        flavor: '"Welcome, welcome! Looking to trade?"',
                        choices: [
                            { label: 'Browse the goods', desc: 'See what they have', next: 'browse' },
                            { label: 'Ask about the road', desc: 'Information first', next: 'road_info' },
                            { label: 'Keep walking', desc: 'No time for this', next: 'leave' }
                        ]
                    },
                    browse: {
                        icon: '\u{1F4E6}', title: 'Wares',
                        text: 'They spread their goods on the tarp.\n\nAmmunition, salvaged meds,\na fuel canister, and something\nwrapped in cloth at the back.',
                        choices: [
                            { label: 'Buy ammo (20 bits)', desc: '+12 rounds', next: 'buy_ammo', risk: 'safe' },
                            { label: 'Buy meds (25 bits)', desc: '+30 HP', next: 'buy_meds', risk: 'safe' },
                            { label: 'Buy fuel (30 bits)', desc: '+15 fuel', next: 'buy_fuel', risk: 'safe' },
                            { label: 'What\'s in the cloth?', desc: 'The mystery item', next: 'mystery_item', risk: 'risky' }
                        ]
                    },
                    buy_ammo: {
                        title: 'Armed Up',
                        text: '"Good choice. Can\'t have too many rounds\nin this wasteland."',
                        effect: { bits: -20, powerAmmo: 12 },
                        choices: [
                            { label: 'Browse more', next: 'browse_again' },
                            { label: 'Thanks. Moving on.', next: 'leave_friendly' }
                        ]
                    },
                    buy_meds: {
                        title: 'Patched Up',
                        text: '"Genuine pre-war antibiotics.\nWell... mostly genuine."',
                        effect: { bits: -25, hp: 30 },
                        choices: [
                            { label: 'Browse more', next: 'browse_again' },
                            { label: 'Thanks. Moving on.', next: 'leave_friendly' }
                        ]
                    },
                    buy_fuel: {
                        title: 'Fueled Up',
                        text: '"Liquid gold, that is.\nTreat her gentle."',
                        effect: { bits: -30, fuel: 15 },
                        choices: [
                            { label: 'Browse more', next: 'browse_again' },
                            { label: 'Thanks. Moving on.', next: 'leave_friendly' }
                        ]
                    },
                    mystery_item: {
                        icon: '❓', title: 'The Cloth Bundle',
                        text: 'They unwrap it carefully.\n\nA Cube shard — small but unmistakable.\nIt pulses faintly in the dim light.\n\n"Sixty bits. Non-negotiable."',
                        choices: [
                            { label: 'Pay 60 bits', desc: 'Worth every bit', next: 'buy_shard' },
                            { label: 'Try to haggle', desc: '"That\'s steep..."', next: 'haggle' },
                            { label: 'No thanks', next: 'browse_again' }
                        ]
                    },
                    buy_shard: {
                        icon: '\u{1F52E}', title: 'Acquired',
                        text: '"Pleasure doing business."\n\nThe shard thrums in your pack.\nYou feel... stronger.',
                        effect: { bits: -60, hp: 20, powerAmmo: 5 },
                        choices: [
                            { label: 'Move on', next: 'leave_friendly' }
                        ]
                    },
                    haggle: {
                        icon: '\u{1F624}', title: 'Haggling',
                        text: 'They cross their arms.\n\n"Fifty. Final offer.\nAnd only because I like your face."',
                        choices: [
                            { label: 'Pay 50 bits', next: 'buy_shard_discount' },
                            { label: 'Still too much', next: 'browse_again' }
                        ]
                    },
                    buy_shard_discount: {
                        icon: '\u{1F52E}', title: 'Bargain',
                        text: '"You drive a hard bargain.\nGet out of here before I change my mind."',
                        flavor: 'The shard hums contentedly in your pack.',
                        effect: { bits: -50, hp: 20, powerAmmo: 5 },
                        choices: [
                            { label: 'Leave', next: 'leave_friendly' }
                        ]
                    },
                    browse_again: {
                        title: 'Still Browsing',
                        text: '"Take your time. Not like the world\'s ending.\n\nOh wait."',
                        choices: [
                            { label: 'Buy ammo (20 bits)', desc: '+12 rounds', next: 'buy_ammo' },
                            { label: 'Buy meds (25 bits)', desc: '+30 HP', next: 'buy_meds' },
                            { label: 'Buy fuel (30 bits)', desc: '+15 fuel', next: 'buy_fuel' },
                            { label: 'Done shopping', next: 'leave_friendly' }
                        ]
                    },
                    road_info: {
                        icon: '\u{1F5FA}', title: 'Intel',
                        text: 'They lean in close.\n\n"Road north? Bad. Real bad.\nBig nest — brutes and hosts.\nBut there\'s a cache behind the old school\nif you can get past them."',
                        flavor: '"Free tip. Next one costs you."',
                        choices: [
                            { label: 'Good to know. Let me browse.', next: 'browse' },
                            { label: 'Thanks. I\'ll be careful.', next: 'leave_friendly' }
                        ]
                    },
                    leave: {
                        title: 'Passing Through',
                        text: '"Your loss, friend!\nI\'ll be here if you change your mind!"',
                        choices: [
                            { label: 'Continue', next: '_map' }
                        ]
                    },
                    leave_friendly: {
                        title: 'Farewell',
                        text: '"Safe travels, friend.\nMay the Cube guide your path."\n\nThey wave as you disappear\nback into the wasteland.',
                        effect: { bits: 5 },
                        choices: [
                            { label: 'Continue', next: '_map' }
                        ]
                    }
                }
            },
            
            // === DISTANT SCREAMS ===
            {
                root: 'intro',
                nodes: {
                    intro: {
                        icon: '\u{1F50A}', title: 'Distant Screams',
                        text: 'The sound carries on the wind.\nHuman. Terrified.\n\nIt\'s coming from deeper in —\npast the collapsed overpass.',
                        flavor: 'The screams are getting weaker.',
                        choices: [
                            { label: 'Rush toward them', desc: 'There might still be time', next: 'rush', risk: 'dangerous' },
                            { label: 'Approach carefully', desc: 'Could be bait', next: 'careful', risk: 'risky' },
                            { label: 'Keep moving', desc: 'You can\'t save everyone', next: 'ignore', risk: 'safe' }
                        ]
                    },
                    rush: {
                        icon: '\u{1F3C3}', title: 'Running',
                        text: 'You sprint through the rubble.\nRounding the corner, you see them —\n\nThree survivors backed against a wall.\nSix crawlers closing in.',
                        choices: [
                            { label: 'Open fire!', desc: 'No time to think', next: 'save_them', effect: { powerAmmo: -5 } },
                            { label: 'Draw them to you', desc: 'Use yourself as bait', next: 'bait' }
                        ]
                    },
                    careful: {
                        icon: '\u{1F441}', title: 'Watching',
                        text: 'You creep along the overpass.\nBelow: survivors surrounded by crawlers.\n\nBut something else watches too.\nA brute, lurking in the building across.',
                        flavor: 'It hasn\'t seen you. Yet.',
                        choices: [
                            { label: 'Take out the brute first', desc: 'Eliminate the big threat', next: 'snipe_brute' },
                            { label: 'Save survivors now', next: 'save_them', risk: 'dangerous' },
                            { label: 'This is too dangerous', next: 'retreat' }
                        ]
                    },
                    save_them: {
                        icon: '⚔', title: 'Rescue',
                        text: 'You engage the crawlers.\nThe survivors scramble behind you.\n\n"Thank you! Thank you!"\n\nBut more are coming.',
                        effect: { bits: bigReward },
                        choices: [
                            { label: 'Hold the line!', next: '_combat', risk: 'dangerous' }
                        ]
                    },
                    bait: {
                        icon: '\u{1F3AF}', title: 'Bait',
                        text: 'You make noise. Throw rocks.\nThe crawlers turn toward you.\n\nThe survivors run.\nNow it\'s just you and six angry crawlers.',
                        flavor: '"GO! I\'ll handle this!"',
                        effect: { bits: bigReward, hp: 10 },
                        choices: [
                            { label: 'Fight them off', next: '_combat', risk: 'dangerous' }
                        ]
                    },
                    snipe_brute: {
                        icon: '\u{1F3AF}', title: 'Clean Shot',
                        text: 'One shot. The brute staggers.\nTwo shots. It falls.\n\nThe crawlers scatter in confusion.\nYou drop down to finish them.',
                        effect: { bits: bigReward, powerAmmo: -3 },
                        choices: [
                            { label: 'Clear the rest', next: 'rescued' }
                        ]
                    },
                    rescued: {
                        icon: '\u{1F91D}', title: 'Rescued',
                        text: 'The survivors emerge, shaking.\nA family — mother, father, child.\n\n"We were heading north. Got ambushed.\nPlease, take these. You saved our lives."',
                        effect: { powerAmmo: 8, fuel: 5, hp: 10 },
                        choices: [
                            { label: 'Be safe out there', next: '_map' }
                        ]
                    },
                    retreat: {
                        title: 'Retreat',
                        text: 'You back away slowly.\nThe screaming stops a minute later.\n\nYou tell yourself there was\nnothing you could have done.',
                        choices: [
                            { label: '...', next: '_map' }
                        ]
                    },
                    ignore: {
                        title: 'Walked Away',
                        text: 'The screams fade behind you.\nSilence returns.\n\nThe wasteland doesn\'t judge.\nBut your hands are shaking.',
                        choices: [
                            { label: 'Keep going', next: '_map' }
                        ]
                    }
                }
            }
        ];
    }
}
