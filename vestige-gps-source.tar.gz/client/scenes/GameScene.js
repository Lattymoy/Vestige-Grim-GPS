// Vestige GPS — GameScene
// Extracted from monolith lines 55122-66368
// Imports will be wired in integration pass

import { Blurbs } from '../../core/blurbs.js';
import { BossAI } from '../../core/bossAI.js';
import { CombatSystem } from '../../core/combatSystem.js';
import { ConsumableSystem } from '../../core/consumableSystem.js';
import { DOTManager } from '../../core/dotManager.js';
import { DOTSystem } from '../../core/dotSystem.js';
import { EnemyAI } from '../../core/enemyAI.js';
import { EnemyManager } from '../../core/enemyManager.js';
import { EventBus } from '../../core/eventBus.js';
import { Haptics } from '../../core/haptics.js';
import { ItemManager } from '../../core/itemManager.js';
import { NPCManager } from '../../core/npcManager.js';
import { SaveManager } from '../../core/saveManager.js';
import { SignatureEffects } from '../../core/signatureEffects.js';
import { StatTracker } from '../../core/statTracker.js';
import { SurvivorGenerator } from '../../core/survivorGenerator.js';
import { Utils, _restoreTint, uiPx } from '../../core/utils.js';
import { BUILDING_STATE } from '../../data/buildingState.js';
import { CONFIG } from '../../data/config.js';
import { DEFENSE_DATA } from '../../data/defense.js';
import { GrimFont } from '../../data/grimFont.js';
import { ISO_DEFS } from '../../data/isoDefs.js';
import { AudioManager } from '../audioManager.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { InteractHighlight } from '../interactHighlight.js';
import { IsoRenderer } from '../isoRenderer.js';
import { CrownAura } from '../rendering/crownAura.js';
import { PropRenderer } from '../rendering/propRenderer.js';
import { TelegraphSystem } from '../rendering/telegraphSystem.js';
import { SpriteManager } from '../spriteManager.js';
import { TerrainGenerator } from '../../core/terrainGenerator.js';
import { GameHUD } from '../ui/gameHUD.js';
import { InventoryUI } from '../ui/inventoryUI.js';
import { PlayerStatusIcons } from '../ui/playerStatusIcons.js';
import { UIAtlas } from '../uiAtlas.js';
import { UIManager } from '../uiManager.js';
import { VehicleFleet } from '../vehicleFleet.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { OverheadZone } from '../rendering/overheadZone.js';
import { InteriorScene } from './InteriorScene.js';
import { MapScene } from './MapScene.js';
import { SafehouseScene } from './SafehouseScene.js';


export class GameScene extends Phaser.Scene {
    constructor() {
        super({ key: 'GameScene' });
    }
    
    init(data) {
        // Map integration data
        this.incomingPlayerState = data.playerState || null;
        this.destinationNode = data.destinationNode || null;
        this.mapSeed = data.mapSeed || null;
        this.currentNodeId = data.currentNodeId || null;
        this.previousNodeId = data.previousNodeId || null;
        this.completedNodes = data.completedNodes || [];
        this.traveledRoutes = data.traveledRoutes || [];
        this.activeRoute = data.activeRoute || null;
        this.deployedSurvivor = data.deployedSurvivor || null;
        this.fromMap = !!data.destinationNode;
        this.currentRow = (data.destinationNode && data.destinationNode.row) || data.currentRow || 1;
        
        // Persistent state for building enter/exit
        this.savedPlayerPos = data.savedPlayerPos || null;
        this.savedRouteSeed = data.savedRouteSeed || null;
        
        // Breakdown mode data (merged from BreakdownScene)
        // breakdownMode removed - deprecated
        this.breakdownDistanceRemaining = data.distanceRemaining || 200;
        this.breakdownDestination = data.destination || 'Unknown';
        
        // scavengeMode removed - deprecated
        this.scavengeDistanceRemaining = data.distanceRemaining || 200;
        this.scavengeDestination = data.destination || 'Unknown';
        
        // Rescue encounter (edge encounter from route)
        this.rescueMode = data.rescueMode || false;
        this._rescueTriggered = false;
        this._rescueComplete = false;
        
        // Location system data
        this.locationType = data.locationType || (this.destinationNode?.locationType) || null;
        this.lootMultiplier = data.lootMultiplier || 1.0;
        this.lootCategory = data.lootCategory || null;
        this.ambushEnemies = data.ambushEnemies || 0;
        this.reducedEnemies = data.reducedEnemies || false;
        this.alarmTriggered = data.alarmTriggered || false;
        this.guaranteedAugment = data.guaranteedAugment || false;
        this.loreRevealed = data.loreRevealed || false;
    }

    create() {
        // Clean up consumable zones/channels from previous scene
        ConsumableSystem.cleanupAll();
        
        // Build GrimFont for announcements
        GrimFont.build(this);
        
        // State - use incoming state if from map, otherwise default
        if (this.incomingPlayerState) {
            this.state = {
                health: this.incomingPlayerState.health,
                powerAmmo: this.incomingPlayerState.powerAmmo || 0,
                _powerAmmoActive: this.incomingPlayerState._powerAmmoActive || false,
                kills: this.incomingPlayerState.kills || 0,
                bits: this.incomingPlayerState.bits || 0,
                fuel: this.incomingPlayerState.fuel || 100,
                materials: this.incomingPlayerState.materials || 0,
                dead: false,
                backpack: this.incomingPlayerState.backpack || ItemManager.createInventory(CONFIG.inventory.backpackSlots),
                vehicle: this.incomingPlayerState.vehicle || ItemManager.createInventory(CONFIG.inventory.vehicleSlots),
                equipment: this.incomingPlayerState.equipment || { weapon: null, melee: null, gear: null, consumable: null },
                foundNotes: [...new Set([...(this.incomingPlayerState.foundNotes || []), ...(typeof SaveManager !== 'undefined' ? StatTracker.getFoundNotes() : [])])]
            };
        } else {
            // Fresh run — apply base health + gym buff bonus
            let startHealth = CONFIG.player.health;
            try {
                const sd = SaveManager.load();
                if (sd && sd.gymBuff && sd.gymBuff.remainingMs > 0 && sd.gymBuff.buffs.maxHealth) {
                    startHealth += sd.gymBuff.buffs.maxHealth;
                }
            } catch(e) {}
            this.state = {
                health: startHealth,
                powerAmmo: CONFIG.player.powerAmmo,
                _powerAmmoActive: false,
                kills: 0,
                bits: 0,
                fuel: 100,
                materials: 0,
                dead: false,
                backpack: ItemManager.createInventory(CONFIG.inventory.backpackSlots),
                vehicle: ItemManager.createInventory(CONFIG.inventory.vehicleSlots),
                equipment: { weapon: null, melee: null, gear: null, consumable: null },
                foundNotes: typeof SaveManager !== 'undefined' ? StatTracker.getFoundNotes() : []
            };
        }
        
        this.canDodge = true;
        this.canMelee = true;
        this.canShoot = true;
        this.isDodging = false;
        this.isInvincible = false;
        this._reloading = false;
        
        // Magazine state
        const eqStats = ItemManager.getEquippedStats(this.state);
        this._magazineMax = eqStats.mag || 10;
        this._magazine = (this.state._magazine !== undefined && this.state._magazine !== null) ? this.state._magazine : this._magazineMax;
        // Reload stat (1-100): 1=slow(3s), 50=medium(1.5s), 100=fast(0.5s) + survivor mark modifier
        const _baseReloadG = Math.max(500, 3000 - (eqStats.reload || 50) * 25);
        const _reloadModG = this.state.survivorMods?.reloadSpeed || 0;
        this._reloadTime = Math.max(300, Math.round(_baseReloadG * (1 - _reloadModG)));
        this.moveDir = { x: 0, y: 0 };
        this.aimAngle = 0;
        this.target = null;
        this.lockedTarget = null;
        this.itemDrops = []; // Tangible item drops (Phase 2B)
        this.inventoryUI = null; // Phase 2C inventory panel
        this.nearVehicle = false;
        
        // Run stats — tracked per run, flushed to SaveManager on completion/death
        this._runStats = {
            kills: 0, meleeKills: 0, rangedKills: 0, bossesKilled: 0,
            bossTypesKilled: [],
            damageDealt: 0, damageTaken: 0, itemsLooted: 0,
            containersOpened: 0, buildingsExplored: 0,
            distanceTraveled: 0, flairWeaponsFound: 0, baneWeaponsFound: 0,
            cubesCollected: 0, bitsEarned: 0, runTime: 0, survived: false,
            reach: 0, loreChipsFound: [],
            timesHealed: 0, materialsEarned: 0, rareFinds: 0
        };
        this._runStartTime = Date.now();
        this._lastPlayerPos = null;
        
        // Game mode based on node type
        this.gameMode = this.destinationNode?.type || 'defense'; // 'defense', 'boss'
        this.modeState = {}; // Mode-specific state

        // Resolve map size from game mode
        const sizeName = CONFIG.modeSizeMap[this.gameMode] || 'medium';
        const mapSize = CONFIG.mapSizes[sizeName];
        CONFIG.world.width = mapSize.width;
        CONFIG.world.height = mapSize.height;
        CONFIG.activeMapSize = mapSize;

        // World bounds
        this.physics.world.setBounds(0, 0, CONFIG.world.width, CONFIG.world.height);
        
        // Create arena
        this.createArena();
        
        // Camera
        this.cameras.main.setBounds(0, 0, CONFIG.world.width, CONFIG.world.height);

        // Player - using animated spritesheet with backpack
        // Restore position if returning from building, otherwise spawn based on mode
        let spawnX, spawnY;
        if (this.savedPlayerPos) {
            spawnX = this.savedPlayerPos.x;
            spawnY = this.savedPlayerPos.y;
        } else if (this.gameMode === 'boss') {
            // Spawn at south of arena, boss spawns at north
            spawnX = CONFIG.world.width / 2;
            spawnY = CONFIG.world.height - 100;
        } else if (this.gameMode === 'defense') {
            // Spawn near the camp but offset
            spawnX = CONFIG.world.width / 2 - 40;
            spawnY = CONFIG.world.height / 2 + 40;
        } else {
            spawnX = CONFIG.world.width / 2;
            spawnY = CONFIG.world.height / 2;
        }
        this.player = SpriteManager.createPlayerSprite(this, spawnX, spawnY, this.state.backpack, this.deployedSurvivor ? this.deployedSurvivor.equippedAura : null);
        this.player.setCollideWorldBounds(true).setDepth(20);
        this.player.setVisible(false); // Hidden until vehicle arrival animation completes
        if (this.player.backpack) this.player.backpack.setVisible(false);
        if (this.player._crownSprite) this.player._crownSprite.setVisible(false);
        DynamicShadows.add(this, this.player, { offsetY: 10, scale: 0.6, alpha: 0.15 });
        // Apply time-of-day ambient tint to player sprite
        if (this._ambientTint && this._ambientTint !== 0xffffff) this.player.setTint(this._ambientTint);
        // Apply gear outfit if equipment has gear
        if (this.state.equipment && this.state.equipment.gear) {
            const gearItem = this.state.equipment.gear;
            if (gearItem.outfit) {
                const custom = Object.assign({}, SpriteManager.playerCustomization);
                custom.shirt = gearItem.outfit.shirt;
                custom.pants = gearItem.outfit.pants;
                custom.gearType = gearItem.gearClass || gearItem.baseId;
                SpriteManager.rebuildPlayerSheet(this, custom);
                this.player.setTexture('player_sheet', 0);
                this.player.setDisplaySize(40, 40);
            }
        }
        
        // Weapon sprite — gun graphic that shows when locked on, colored by foundry
        if (this.state.equipment && this.state.equipment.weapon) {
            const baseId = this.state.equipment.weapon.baseId || 'pistol';
            this.player.weaponType = SpriteManager.getWeaponSpriteType(baseId);
            this.player.weaponFoundry = this.state.equipment.weapon.foundry || null;
            this.player.weaponFlair = this.state.equipment.weapon.flair || null;
            // Rebuild armed sheet with weapon art
            {
                const wt = this.player.weaponType;
                const fid = this.player.weaponFoundry;
                SpriteManager.armedSheets[wt] = SpriteManager.generatePlayerSheet(SpriteManager.playerCustomization, true, wt, fid, this.state.equipment.weapon);
                const sheetKey = 'player_sheet_armed_' + wt;
                if (this.textures.exists(sheetKey)) this.textures.remove(sheetKey);
                this.textures.addSpriteSheet(sheetKey, SpriteManager.armedSheets[wt], { frameWidth: 48, frameHeight: 48 });
                // Recreate animations — old ones reference stale frames from removed texture
                const dirs = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
                dirs.forEach((dir, i) => {
                    const animKey = `player_armed_${wt}_${dir}`;
                    if (this.anims.exists(animKey)) this.anims.remove(animKey);
                    this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 8, repeat: -1 });
                });
                const idleKey = `player_armed_${wt}_idle`;
                if (this.anims.exists(idleKey)) this.anims.remove(idleKey);
                this.anims.create({ key: idleKey, frames: [{ key: sheetKey, frame: 0 }], frameRate: 1 });
            }
        }
        // Track melee flair too
        if (this.state.equipment && this.state.equipment.melee) {
            this.player.meleeFlair = this.state.equipment.melee.flair || null;
            // Rebuild melee sheet with actual weapon art
            const meleeItem = this.state.equipment.melee;
            const mt = (meleeItem.baseId === 'blunt') ? 'blunt' : (meleeItem.baseId === 'heavy') ? 'heavy' : 'blade';
            {
                SpriteManager.meleeSheets[mt] = SpriteManager.generateMeleeSheet(SpriteManager.playerCustomization, mt, meleeItem);
                const sheetKey = 'player_sheet_melee_' + mt;
                if (this.textures.exists(sheetKey)) this.textures.remove(sheetKey);
                this.textures.addSpriteSheet(sheetKey, SpriteManager.meleeSheets[mt], { frameWidth: 48, frameHeight: 48 });
                const dirs = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
                dirs.forEach((dir, i) => {
                    const animKey = `player_melee_${mt}_${dir}`;
                    if (this.anims.exists(animKey)) this.anims.remove(animKey);
                    this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 10, repeat: 0 });
                });
            }
        }
        this.player.isArmed = false;
        
        // Returning from building — ensure player is visible, alpha reset, phantom cleared
        if (this.savedPlayerPos && this.player) {
            this.player.setVisible(true);
            this.player.setAlpha(1);
            this._phantomActive = false;
            this._phantomInvis = false;
            // Reset animation state to prevent skating
            this.player.isMoving = false;
            this.player.body.setVelocity(0, 0);
            this.player.setFrame(0); // idle down
            this.player.anims.stop();
            if (this.player.backpack) {
                this.player.backpack.setVisible(true);
                this.player.backpack.setAlpha(1);
            }
            if (this.player._crownSprite) {
                this.player._crownSprite.setVisible(true);
                this.player._crownSprite.setAlpha(CrownAura.ALPHA);
            }
            
            // Sheltered augment chip: -20% damage for 15s after exiting interior
            const shAug = [this.state.equipment?.weapon?.augment, this.state.equipment?.melee?.augment]
                .find(a => a && a.relicAbility === 'sheltered');
            if (shAug && SignatureEffects.isReady(this, 'sheltered', shAug.relicCooldown || 10000)) {
                SignatureEffects.trigger(this, 'sheltered', shAug.relicCooldown || 10000);
                this._shelteredActive = true;
                const dur = 15000;
                const st = this.add.text(this.player.x, this.player.y - 30, 'SHELTERED', {
                    fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#44aaff', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(35);
                this.tweens.add({ targets: st, y: st.y - 20, alpha: 0, duration: 600, onComplete: () => st.destroy() });
                this.time.delayedCall(dur, () => { this._shelteredActive = false; });
            }
        }
        
        // Camera follows player — deferred if vehicle arrival animation is active
        if (!this._arrivalActive) {
            this.cameras.main.startFollow(this.player, true, 1, 1);
        }
        this.cameras.main.setRoundPixels(true);

        // Crosshair — drawn as live graphics for clean transparency
        this.reticle = this.add.graphics().setVisible(false).setDepth(25).setAlpha(0.8);
        this.reticle._drawCrosshair = function(tintColor) {
            this.clear();
            const s = 12;
            const c = tintColor || 0xccbbaa;
            // Corner brackets
            this.lineStyle(1.5, c, 0.9);
            // Top-left
            this.beginPath(); this.moveTo(-s, -s); this.lineTo(-s, -s + 5); this.strokePath();
            this.beginPath(); this.moveTo(-s, -s); this.lineTo(-s + 5, -s); this.strokePath();
            // Top-right
            this.beginPath(); this.moveTo(s, -s); this.lineTo(s, -s + 5); this.strokePath();
            this.beginPath(); this.moveTo(s, -s); this.lineTo(s - 5, -s); this.strokePath();
            // Bottom-left
            this.beginPath(); this.moveTo(-s, s); this.lineTo(-s, s - 5); this.strokePath();
            this.beginPath(); this.moveTo(-s, s); this.lineTo(-s + 5, s); this.strokePath();
            // Bottom-right
            this.beginPath(); this.moveTo(s, s); this.lineTo(s, s - 5); this.strokePath();
            this.beginPath(); this.moveTo(s, s); this.lineTo(s - 5, s); this.strokePath();
            // Center dot
            this.fillStyle(c, 0.5);
            this.fillCircle(0, 0, 1.5);
        };
        this.reticle._drawCrosshair();

        // Groups
        this.bullets = this.physics.add.group();
        this.enemies = this.physics.add.group();
        this.acidPuddles = this.physics.add.group();

        // Acid puddle DOT — stepping in acid applies toxic DOT
        this.physics.add.overlap(this.player, this.acidPuddles, (p, puddle) => {
            if (this.isInvincible || this.state.dead || this._godMode) return;
            if (!puddle._acidActive) return;
            // Apply/refresh toxic DOT — the DOT system handles ticking
            DOTSystem.applyToPlayer(this, 'toxic', { damage: puddle._acidDmg || 2 });
        });

        // Collisions
        this.physics.add.collider(this.player, this.walls);
        this.physics.add.collider(this.enemies, this.walls);
        this.physics.add.collider(this.player, this.propWalls);
        this.physics.add.collider(this.enemies, this.propWalls);
        this.physics.add.collider(this.bullets, this.propWalls, (b, w) => { this._bulletHitProp(b, w); });
        this.physics.add.collider(this.enemies, this.enemies, (a, b) => {
            // Husk stumble/trip physics
            const aIsCrawler = a._isCrawler || a.enemyType === 'crawler' || a.enemyType === 'husk_crawl';
            const bIsCrawler = b._isCrawler || b.enemyType === 'crawler' || b.enemyType === 'husk_crawl';
            const aSpd = a.body ? Math.sqrt(a.body.velocity.x**2 + a.body.velocity.y**2) : 0;
            const bSpd = b.body ? Math.sqrt(b.body.velocity.x**2 + b.body.velocity.y**2) : 0;
            // Trip: non-crawler moving fast hits a crawler
            if (aIsCrawler && !bIsCrawler && bSpd > 30 && !b._stumbling) {
                EnemyAI._stumbleEnemy(this, b);
            } else if (bIsCrawler && !aIsCrawler && aSpd > 30 && !a._stumbling) {
                EnemyAI._stumbleEnemy(this, a);
            }
            // Speed stumble: only frenzy-speed husks (>100) rear-end slow/stopped husks
            else if (aSpd > 100 && bSpd < 15 && !b._stumbling && !aIsCrawler && !bIsCrawler) {
                EnemyAI._stumbleEnemy(this, b);
            } else if (bSpd > 100 && aSpd < 15 && !a._stumbling && !bIsCrawler && !aIsCrawler) {
                EnemyAI._stumbleEnemy(this, a);
            }
        });
        this.physics.add.collider(this.bullets, this.walls, (b) => { this.spark(b.x, b.y, b.rotation, b.fx); b.destroy(); });
        this.physics.add.overlap(this.bullets, this.enemies, (b, e) => {
            if (!b.active || !e.active) return;
            this.spark(b.x, b.y, b.rotation, b.fx);
            const dmg = b.damage || CONFIG.player.gunDamage;
            const wasCrit = b.isCrit || false;
            
            // Pierce: probability-based punch-through
            const doPierce = b.pierceLeft > 0 || (b.pierceChance && Math.random() < b.pierceChance);
            if (doPierce) {
                if (!b._hitEnemies) b._hitEnemies = new Set();
                if (b._hitEnemies.has(e)) return;
                b._hitEnemies.add(e);
                if (b.pierceLeft > 0) b.pierceLeft--;
            } else {
                b.destroy();
            }
            
            this.damageEnemy(e, dmg, 'bullet', b);
            
            // Limb loss — husks can become crawlers when shot
            if (e.active && !e._dying) EnemyAI._limbLossToCrawler(this, e, b.x, b.y);
            // Blade loss — flickers lose arms, become acid-trailing maimed variant
            if (e.active && !e._dying) EnemyAI._flickerMaimCheck(this, e);
            
            // === T5/T6 BULLET-HIT SIGNATURE EFFECTS ===
            const bSigs = b._sigs || [];
            
            // Ricochet: bounce to 2nd target at 50% damage
            const ricochet = bSigs.find(s => s.effect === 'ricochet');
            if (ricochet && !b._ricochetDone) {
                b._ricochetDone = true;
                SignatureEffects.doRicochet(this, b, e, dmg, ricochet);
            }
            
            // Firepower: apply Burn DOT (augment chip ability)
            if (b._isFirepower && e.active) {
                DOTManager.apply(this, e, 'burn', 15, 5000, 'firepower');
            }
            
            // Parasitic Rounds: +1 dmg + heal 2HP + apply Poison
            if (b._isParasitic && e.active) {
                SignatureEffects.consumeParasiticRound(this, this.state, e);
            }
        });
        this.physics.add.overlap(this.player, this.enemies, (p, e) => this.enemyHitPlayer(e));

        // Spawn points from generated route (set in createArena)
        if (!this.savedPlayerPos) {
            // Fresh zone entry — full mode setup
            this.setupGameMode();
        } else {
            // Returning from building — resume without restarting entire event
            if (this.gameMode === 'defense') {
                // Re-run setupGameMode to recreate convoy/soldiers/quest-giver
                // (scene was destroyed + rebuilt, so all Phaser objects need recreating)
                // This resets to discovery phase — player re-approaches the NPC
                this.setupGameMode();
            } else if (this.gameMode === 'boss') {
                // Boss shouldn't have buildings; if triggered, minimal state
                this.modeState = this.modeState || { phase: 'active' };
            } else {
                // freeRoam / exploration — delayed ambient spawns
                this.time.delayedCall(3000, () => {
                    this.time.addEvent({ delay: 8000, callback: () => this.spawnWave(1), loop: true });
                });
            }
        }

        // UI
        this.createUI();
        this.updateConsumableButton();

        // Input
        this.setupInput();

        // Keyboard
        this.keys = this.input.keyboard.addKeys({ w:'W', s:'S', a:'A', d:'D', h:'H', e:'E', i:'I' });
        
        // === DEBUG PANEL (mobile-friendly) ===
        // Triple-tap top-right corner to toggle debug buttons
        this._debugTapCount = 0;
        this._debugPanel = null;
        const debugZone = this.add.rectangle(CONFIG.width - 25, 12, 50, 24, 0x000000, 0)
            .setScrollFactor(0).setDepth(999).setInteractive();
        debugZone.on('pointerdown', () => {
            this._debugTapCount++;
            if (this._debugTapCount >= 3) {
                this._debugTapCount = 0;
                this.toggleDebugPanel();
            }
            this.time.delayedCall(800, () => { this._debugTapCount = Math.max(0, this._debugTapCount - 1); });
        });
    }
    
    toggleDebugPanel() {
        if (this._debugPanel) {
            this._debugPanel.forEach(el => el.destroy());
            this._debugPanel = null;
            return;
        }
        this._debugPanel = [];
        const d = 998;
        const bx = CONFIG.width - 50;
        let by = 36;
        const bw = 88, bh = 22, gap = 25;
        const self = this;
        
        // State trackers
        if (!this._debugRelicIdx) this._debugRelicIdx = 0;
        if (!this._debugWeaponTier) this._debugWeaponTier = 4;
        
        const makeBtn = (label, color, fn) => {
            const bg = this.add.rectangle(bx, by, bw, bh, color, 0.9)
                .setStrokeStyle(1, 0x888888, 0.5).setScrollFactor(0).setDepth(d)
                .setInteractive({ useHandCursor: true });
            const txt = this.add.text(bx, by, label, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#dddddd', fontStyle: 'bold'
            }).setOrigin(0.5).setScrollFactor(0).setDepth(d + 1);
            bg.on('pointerdown', () => fn(txt));
            this._debugPanel.push(bg, txt);
            by += gap;
            return txt;
        };
        
        // --- COMBAT ---
        makeBtn('KILL ALL', 0x663333, () => {
            this.enemies.getChildren().forEach(e => { if (e.active) { e.hp = 0; this.killEnemy(e); } });
        });
        
        makeBtn('GOD MODE', 0x665522, (txt) => {
            this._godMode = !this._godMode;
            if (this._godMode) {
                this.state.health = 999;
                this.state.powerAmmo = 99;
                if (this.modeState && this.modeState.caravanHp) this.modeState.caravanHp = this.modeState.caravanMaxHp;
            }
            txt.setText(this._godMode ? 'GOD: ON' : 'GOD MODE');
        });
        
        // --- WAVE SKIPS ---
        makeBtn('SKIP WAVE', 0x336633, () => {
            this.enemies.getChildren().forEach(e => { if (e.active) { e.hp = 0; this.killEnemy(e); } });
        });
        
        makeBtn('SKIP → 10', 0x333366, () => {
            if (this.gameMode === 'defense' && this.modeState) this.modeState.wavesCurrent = 9;
            this.enemies.getChildren().forEach(e => { if (e.active) { e.hp = 0; this.killEnemy(e); } });
        });
        
        makeBtn('SKIP → 15', 0x553333, () => {
            if (this.gameMode === 'defense' && this.modeState) this.modeState.wavesCurrent = 14;
            this.enemies.getChildren().forEach(e => { if (e.active) { e.hp = 0; this.killEnemy(e); } });
        });
        
        // --- ITEMS ---
        makeBtn('DROP LOOT', 0x224466, () => {
            const reach = this.destinationNode?.reach || 5;
            for (let i = 0; i < 5; i++) {
                this.time.delayedCall(i * 100, () => {
                    this.spawnItemDrop(
                        this.player.x + Phaser.Math.Between(-40, 40),
                        this.player.y + Phaser.Math.Between(-20, 40),
                        'boss_high', reach
                    );
                });
            }
        });
        
        makeBtn('AUG', 0x662244, (txt) => {
            const augKeys = Object.keys(CONFIG.baseItems).filter(k => CONFIG.baseItems[k].category === 'augment');
            const key = augKeys[this._debugRelicIdx % augKeys.length];
            this._debugRelicIdx++;
            const aug = ItemManager.generateItem('augment');
            const base = CONFIG.baseItems[key];
            aug.baseId = key;
            aug.name = base.name;
            aug.icon = base.icon;
            aug.description = base.desc;
            aug.category = 'augment';
            aug.relicType = base.relicType;
            aug.relicAbility = base.relicAbility;
            aug.relicCooldown = base.relicCooldown || 0;
            ItemManager.addItem(this.state.backpack, aug);
            txt.setText(key.substring(0, 12));
            const t = this.add.text(this.player.x, this.player.y - 30, `${aug.name}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#ff4466', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: t, y: t.y - 25, alpha: 0, duration: 1200, onComplete: () => t.destroy() });
        });
        
        makeBtn('WEAPON T4', 0x445566, (txt) => {
            const wpn = ItemManager.generateItem('weapon', 4);
            if (wpn) {
                // Random foundry
                const fKeys = Object.keys(CONFIG.foundries);
                const fId = fKeys[Math.floor(Math.random() * fKeys.length)];
                if (CONFIG.foundries[fId] && CONFIG.foundries[fId].palette) {
                    wpn.foundry = fId;
                    wpn.foundryName = CONFIG.foundries[fId].name;
                    wpn.foundryTag = CONFIG.foundries[fId].tag;
                    wpn.foundryPalette = CONFIG.foundries[fId].palette;
                }
                wpn._holsterWC = null;
                this.state.equipment.weapon = wpn;
                SpriteManager.createHolsterSprites(this, this.player, this.player.backpack, this.state.equipment);
                SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                txt.setText(wpn.baseId.substring(0, 10));
                const t = this.add.text(this.player.x, this.player.y - 30, wpn.name, {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#44ccff', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(7.5);
                this.tweens.add({ targets: t, y: t.y - 25, alpha: 0, duration: 1200, onComplete: () => t.destroy() });
            }
        });
        
        makeBtn('MELEE T4', 0x564522, (txt) => {
            const mel = ItemManager.generateItem('melee', 4);
            if (mel) {
                const fKeys = Object.keys(CONFIG.foundries);
                const fId = fKeys[Math.floor(Math.random() * fKeys.length)];
                if (CONFIG.foundries[fId] && CONFIG.foundries[fId].palette) {
                    mel.foundry = fId;
                    mel.foundryName = CONFIG.foundries[fId].name;
                    mel.foundryTag = CONFIG.foundries[fId].tag;
                    mel.foundryPalette = CONFIG.foundries[fId].palette;
                }
                mel._holsterWC = null;
                this.state.equipment.melee = mel;
                SpriteManager.createHolsterSprites(this, this.player, this.player.backpack, this.state.equipment);
                SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                txt.setText(mel.baseId.substring(0, 10));
                const t = this.add.text(this.player.x, this.player.y - 30, mel.name, {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#ff8844', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(7.5);
                this.tweens.add({ targets: t, y: t.y - 25, alpha: 0, duration: 1200, onComplete: () => t.destroy() });
            }
        });
        
        makeBtn('+3 LOCKPICK', 0x445533, () => {
            for (let i = 0; i < 3; i++) {
                const lp = ItemManager.createItem('lockpick');
                if (lp) ItemManager.addItem(this.state.backpack, lp);
            }
            const t = this.add.text(this.player.x, this.player.y - 30, '+3 Lockpicks', {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#ccaa44', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: t, y: t.y - 25, alpha: 0, duration: 800, onComplete: () => t.destroy() });
        });
        
        makeBtn('+50 BITS', 0x336644, () => {
            this.state.bits = (this.state.bits || 0) + 50;
            const t = this.add.text(this.player.x, this.player.y - 30, '+50 Bits', {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#44ff88', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: t, y: t.y - 25, alpha: 0, duration: 800, onComplete: () => t.destroy() });
        });
        
        makeBtn('HEAL FULL', 0x336644, () => {
            this.state.health = CONFIG.player.health;
        });
    }

    createArena() {
        const w = CONFIG.world.width;
        const h = CONFIG.world.height;
        
        // Get lighting settings
        this.lighting = CONFIG.lighting[CONFIG.timeOfDay];
        this._ambientTint = this.lighting.ambient || 0xffffff; // Cached for sprite tinting
        
        this.walls = this.physics.add.staticGroup();
        this.propWalls = this.physics.add.staticGroup();
        this.destructibles = new Map();
        this.wallRects = [];
        this.buildingDoors = [];
        
        // Generate map procedurally using biome - use saved seed if returning from building
        const biomeType = CONFIG.currentBiome.type;
        this.biome = CONFIG.biomes[biomeType] || CONFIG.biomes.grassy;
        CONFIG._activeBiomeLootQualityBonus = this.biome.lootQualityBonus || 0;
        
        // Start biome ambient audio
        try { AudioManager.playBiomeAmbient(biomeType); } catch(e) {}
        const routeSeed = this.savedRouteSeed || CONFIG.currentBiome.seed;
        this.currentRouteSeed = routeSeed; // Store for passing to interior
        
        // Clear building state cache when entering a new zone (not returning from interior)
        if (!this.savedRouteSeed) {
            for (const key in BUILDING_STATE) delete BUILDING_STATE[key];
        }
        
        // Boss arenas: dedicated open-field layouts
        if (this.gameMode === 'boss') {
            const biomeConfig = CONFIG.biomes[biomeType];
            const gc = biomeConfig.groundColor;
            
            // Ground base
            this.add.rectangle(w/2, h/2, w, h, gc).setDepth(0);
            
            // Biome ground texture — dirt patches, cracks, grass tufts
            for (let i = 0; i < 40; i++) {
                const gx = Phaser.Math.Between(15, w - 15);
                const gy = Phaser.Math.Between(15, h - 15);
                const gtype = Math.random();
                if (gtype < 0.3) {
                    // Dirt patch
                    this.add.ellipse(gx, gy, Phaser.Math.Between(8, 20), Phaser.Math.Between(6, 14), gc - 0x111111, 0.3).setDepth(0.5);
                } else if (gtype < 0.6) {
                    // Crack line
                    const g = this.add.graphics().setDepth(0.6);
                    g.lineStyle(1, gc - 0x222222, 0.25);
                    const len = Phaser.Math.Between(10, 30);
                    const ang = Math.random() * Math.PI;
                    g.lineBetween(gx, gy, gx + Math.cos(ang) * len, gy + Math.sin(ang) * len);
                } else {
                    // Small stone / pebble
                    this.add.circle(gx, gy, Phaser.Math.Between(1, 3), gc - 0x0a0a0a, 0.35).setDepth(0.5);
                }
            }
            
            // Road through center (all arenas have road context)
            const roadY = h / 2;
            this.add.rectangle(w/2, roadY, w, 70, 0x2a2a2a).setDepth(1);
            // Road edge lines
            this.add.rectangle(w/2, roadY - 33, w, 3, 0x4a4a3a).setDepth(2);
            this.add.rectangle(w/2, roadY + 33, w, 3, 0x4a4a3a).setDepth(2);
            // Dashed center line
            for (let i = 0; i < Math.ceil(w / 35); i++) {
                this.add.rectangle(i * 35, roadY, 18, 2, 0x5a5a4a).setDepth(2);
            }
            // Road cracks
            for (let i = 0; i < 6; i++) {
                const rx = Phaser.Math.Between(30, w - 30);
                const ry = roadY + Phaser.Math.Between(-28, 28);
                const rg = this.add.graphics().setDepth(2.1);
                rg.lineStyle(1, 0x1a1a1a, 0.4);
                const rl = Phaser.Math.Between(8, 22);
                const ra = Math.random() * Math.PI;
                rg.lineBetween(rx, ry, rx + Math.cos(ra) * rl, ry + Math.sin(ra) * rl);
            }
            
            // === BOSS ARENA THEMING — unique environment per boss type ===
            if (this.gameMode === 'boss' && this.modeState && this.modeState.bossType) {
                const bType = this.modeState.bossType;
                const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
                
                if (bType === 'warden') {
                    // WARDEN — ruined courtyard, cracked pillars, chains on walls
                    // Stone floor overlay
                    for (let tx = 40; tx < w - 40; tx += 30) {
                        for (let ty = 40; ty < h - 40; ty += 30) {
                            if (Math.abs(ty - h/2) < 38) continue; // skip road
                            if (Math.random() < 0.4) {
                                this.add.rectangle(tx + Phaser.Math.Between(-5,5), ty + Phaser.Math.Between(-5,5), Phaser.Math.Between(20,28), Phaser.Math.Between(18,26), tc(0x3a3a38), 0.3).setDepth(0.8);
                            }
                        }
                    }
                    // Cracked pillars
                    const pillarPositions = [
                        { x: w*0.2, y: h*0.2 }, { x: w*0.8, y: h*0.2 },
                        { x: w*0.2, y: h*0.8 }, { x: w*0.8, y: h*0.8 },
                        { x: w*0.5, y: h*0.15 }, { x: w*0.5, y: h*0.85 }
                    ];
                    for (const p of pillarPositions) {
                        const pd = 3 + p.y * 0.01;
                        IsoRenderer.cube(this, p.x, p.y, 12, 12, 28, tc(0x5a5a55), { depth: pd });
                        this.add.rectangle(p.x, p.y - 30, 16, 4, tc(0x6a6a65)).setDepth(pd + 0.01);
                        // Cracks
                        const g = this.add.graphics().setDepth(pd + 0.02);
                        g.lineStyle(1, 0x2a2a28, 0.5);
                        g.lineBetween(p.x - 2, p.y - 10, p.x + 3, p.y + 5);
                        this.addWall(p.x, p.y, 14, 14, 0, false);
                    }
                    // Chains on ground
                    for (let i = 0; i < 6; i++) {
                        const cx = Phaser.Math.Between(60, w-60), cy = Phaser.Math.Between(40, h-40);
                        if (Math.abs(cy - h/2) < 38) continue;
                        for (let j = 0; j < 5; j++) {
                            this.add.circle(cx + j*4, cy + Math.sin(j)*2, 2, tc(0x666655), 0.3).setDepth(1.5);
                        }
                    }
                    // Blood stains
                    for (let i = 0; i < 5; i++) {
                        this.add.ellipse(Phaser.Math.Between(80, w-80), Phaser.Math.Between(60, h-60), Phaser.Math.Between(8, 18), Phaser.Math.Between(6, 12), 0x441111, 0.15).setDepth(1.2);
                    }
                    
                } else if (bType === 'swarmQueen') {
                    // SWARM QUEEN — organic nest, slime patches, egg clusters, hive walls
                    // Slime/organic ground
                    for (let i = 0; i < 20; i++) {
                        const sx = Phaser.Math.Between(30, w-30), sy = Phaser.Math.Between(30, h-30);
                        this.add.ellipse(sx, sy, Phaser.Math.Between(12, 30), Phaser.Math.Between(8, 20), 0x224422, 0.2).setDepth(0.7);
                        if (Math.random() < 0.3) this.add.ellipse(sx, sy, Phaser.Math.Between(4, 10), Phaser.Math.Between(3, 7), 0x44aa44, 0.12).setDepth(0.8);
                    }
                    // Egg clusters (collidable hazards)
                    const eggPositions = [
                        { x: w*0.15, y: h*0.25 }, { x: w*0.85, y: h*0.25 },
                        { x: w*0.15, y: h*0.75 }, { x: w*0.85, y: h*0.75 },
                        { x: w*0.35, y: h*0.15 }, { x: w*0.65, y: h*0.15 }
                    ];
                    for (const e of eggPositions) {
                        const pd = 3 + e.y * 0.01;
                        for (let j = 0; j < 4; j++) {
                            const ex = e.x + Phaser.Math.Between(-8, 8), ey = e.y + Phaser.Math.Between(-6, 6);
                            this.add.ellipse(ex, ey, 8, 11, tc(0x668844), 0.6).setDepth(pd);
                            this.add.ellipse(ex, ey - 2, 5, 6, tc(0x88aa66), 0.3).setDepth(pd + 0.01);
                        }
                        this.add.ellipse(e.x, e.y + 6, 24, 6, 0x224422, 0.3).setDepth(pd - 0.01);
                        this.addWall(e.x, e.y, 22, 18, 0, false);
                    }
                    // Tendril vines on edges
                    for (let i = 0; i < 10; i++) {
                        const vx = Math.random() < 0.5 ? Phaser.Math.Between(10, 40) : Phaser.Math.Between(w-40, w-10);
                        const vy = Phaser.Math.Between(30, h-30);
                        const vg = this.add.graphics().setDepth(2);
                        vg.lineStyle(2, 0x336633, 0.4);
                        vg.lineBetween(vx, vy, vx + Phaser.Math.Between(-15, 15), vy + Phaser.Math.Between(-20, 20));
                    }
                    
                } else if (bType === 'phantom') {
                    // PHANTOM — misty graveyard, spectral fog, tombstones, dead trees
                    // Fog layer
                    for (let i = 0; i < 8; i++) {
                        const fx = Phaser.Math.Between(20, w-20), fy = Phaser.Math.Between(20, h-20);
                        const fog = this.add.ellipse(fx, fy, Phaser.Math.Between(50, 100), Phaser.Math.Between(30, 60), 0x664488, 0.06).setDepth(0.6);
                        this.tweens.add({ targets: fog, x: fog.x + Phaser.Math.Between(-20, 20), alpha: { from: 0.04, to: 0.08 }, duration: 3000 + Math.random() * 2000, yoyo: true, repeat: -1 });
                    }
                    // Tombstones
                    const tombPositions = [
                        { x: w*0.15, y: h*0.3 }, { x: w*0.3, y: h*0.2 }, { x: w*0.7, y: h*0.2 },
                        { x: w*0.85, y: h*0.3 }, { x: w*0.2, y: h*0.7 }, { x: w*0.4, y: h*0.85 },
                        { x: w*0.6, y: h*0.85 }, { x: w*0.8, y: h*0.7 }
                    ];
                    for (const t of tombPositions) {
                        const pd = 3 + t.y * 0.01;
                        IsoRenderer.cube(this, t.x, t.y, 8, 4, 14, tc(0x4a4a4a), { depth: pd });
                        this.add.rectangle(t.x, t.y - 16, 10, 3, tc(0x555555)).setDepth(pd + 0.01);
                        this.add.rectangle(t.x, t.y + 4, 12, 3, tc(0x3a3a3a)).setDepth(pd - 0.01); // base
                        this.addWall(t.x, t.y, 10, 6, 0, false);
                    }
                    // Dead trees
                    for (let i = 0; i < 4; i++) {
                        const tx = Phaser.Math.Between(30, w-30), ty = Phaser.Math.Between(30, h-30);
                        if (Math.abs(ty - h/2) < 45 && Math.abs(tx - w/2) < 80) continue;
                        PropRenderer.createTree(this, tx, ty, 'dead');
                    }
                    // Spectral wisps (animated)
                    for (let i = 0; i < 4; i++) {
                        const wx = Phaser.Math.Between(60, w-60), wy = Phaser.Math.Between(60, h-60);
                        const wisp = this.add.circle(wx, wy, 4, 0xaa88ff, 0.2).setDepth(22);
                        this.tweens.add({ targets: wisp, x: wx + Phaser.Math.Between(-60, 60), y: wy + Phaser.Math.Between(-60, 60), alpha: { from: 0.1, to: 0.25 }, duration: 4000 + Math.random() * 3000, yoyo: true, repeat: -1 });
                    }
                    
                } else if (bType === 'ironclad') {
                    // IRONCLAD — industrial arena, scrap piles, sparking wires, oil puddles
                    // Metal floor tiles
                    for (let tx = 30; tx < w - 30; tx += 40) {
                        for (let ty = 30; ty < h - 30; ty += 40) {
                            if (Math.abs(ty - h/2) < 38) continue;
                            this.add.rectangle(tx, ty, 35, 35, tc(0x333340), 0.25).setDepth(0.7);
                            this.add.rectangle(tx, ty, 33, 33, tc(0x3a3a44), 0.15).setDepth(0.75);
                        }
                    }
                    // Scrap piles (cover)
                    const scrapPositions = [
                        { x: w*0.2, y: h*0.25 }, { x: w*0.8, y: h*0.25 },
                        { x: w*0.2, y: h*0.75 }, { x: w*0.8, y: h*0.75 },
                        { x: w*0.35, y: h*0.15 }, { x: w*0.65, y: h*0.85 }
                    ];
                    for (const s of scrapPositions) {
                        const pd = 3 + s.y * 0.01;
                        IsoRenderer.cube(this, s.x, s.y, 20, 14, 8, tc(0x555560), { depth: pd });
                        this.add.rectangle(s.x + 5, s.y - 6, 8, 3, tc(0x666670)).setAngle(15).setDepth(pd + 0.01);
                        this.add.rectangle(s.x - 6, s.y - 4, 4, 10, tc(0x444450)).setAngle(-10).setDepth(pd + 0.01);
                        this.addWall(s.x, s.y, 22, 16, 0, false);
                    }
                    // Oil puddles
                    for (let i = 0; i < 5; i++) {
                        this.add.ellipse(Phaser.Math.Between(50, w-50), Phaser.Math.Between(50, h-50), Phaser.Math.Between(15, 30), Phaser.Math.Between(10, 20), 0x111122, 0.25).setDepth(1.1);
                    }
                    // Sparking wires (animated)
                    for (let i = 0; i < 3; i++) {
                        const sx = Phaser.Math.Between(50, w-50), sy = Phaser.Math.Between(30, h-30);
                        const wire = this.add.graphics().setDepth(2);
                        wire.lineStyle(1, 0x666666, 0.4);
                        wire.lineBetween(sx, sy, sx + Phaser.Math.Between(15, 30), sy + Phaser.Math.Between(-10, 10));
                        // Spark
                        this.time.addEvent({ delay: 2000 + Math.random() * 3000, loop: true, callback: () => {
                            const spark = this.add.circle(sx, sy, 2, 0xffcc44, 0.8).setDepth(25);
                            this.tweens.add({ targets: spark, x: spark.x + Phaser.Math.Between(-8, 8), y: spark.y - Phaser.Math.Between(3, 8), alpha: 0, duration: 200, onComplete: () => spark.destroy() });
                        }});
                    }
                    
                } else if (bType === 'cubeAnomaly') {
                    // CUBE ANOMALY — void rift arena, floating fragments, corrupted ground
                    // Corrupted ground overlay
                    for (let i = 0; i < 15; i++) {
                        const cx2 = Phaser.Math.Between(40, w-40), cy2 = Phaser.Math.Between(40, h-40);
                        this.add.rectangle(cx2, cy2, Phaser.Math.Between(15, 35), Phaser.Math.Between(12, 30), 0x220044, 0.15).setAngle(Phaser.Math.Between(0, 45)).setDepth(0.7);
                    }
                    // Void cracks
                    for (let i = 0; i < 8; i++) {
                        const vg = this.add.graphics().setDepth(0.9);
                        vg.lineStyle(2, 0x8800ff, 0.2);
                        const vx1 = Phaser.Math.Between(30, w-30), vy1 = Phaser.Math.Between(30, h-30);
                        const vx2 = vx1 + Phaser.Math.Between(-40, 40), vy2 = vy1 + Phaser.Math.Between(-40, 40);
                        vg.lineBetween(vx1, vy1, vx2, vy2);
                        this.tweens.add({ targets: vg, alpha: { from: 0.1, to: 0.3 }, duration: 2000, yoyo: true, repeat: -1 });
                    }
                    // Floating cube fragments
                    const fragPositions = [
                        { x: w*0.2, y: h*0.2 }, { x: w*0.8, y: h*0.2 },
                        { x: w*0.2, y: h*0.8 }, { x: w*0.8, y: h*0.8 },
                        { x: w*0.5, y: h*0.12 }, { x: w*0.5, y: h*0.88 }
                    ];
                    for (const f of fragPositions) {
                        const pd = 3 + f.y * 0.01;
                        const frag = this.add.container(f.x, f.y).setDepth(pd);
                        frag.add(this.add.rectangle(0, 0, 14, 14, 0x220044));
                        frag.add(this.add.rectangle(0, 0, 10, 10, 0x440088));
                        frag.add(this.add.rectangle(0, 0, 6, 6, 0x8844cc, 0.5));
                        frag.add(this.add.circle(0, 0, 2, 0xcc44ff, 0.4));
                        this.tweens.add({ targets: frag, y: f.y - 4, angle: { from: -5, to: 5 }, duration: 2500, yoyo: true, repeat: -1 });
                        this.addWall(f.x, f.y, 16, 16, 0, false);
                    }
                    // Void energy ring at center
                    const ring = this.add.circle(w/2, h/2 - 60, 40, 0x8800ff, 0.05).setDepth(3);
                    this.tweens.add({ targets: ring, scaleX: { from: 0.8, to: 1.2 }, scaleY: { from: 0.8, to: 1.2 }, alpha: { from: 0.03, to: 0.08 }, duration: 2000, yoyo: true, repeat: -1 });
                }
                
                // Boss arena spawn points — edges + corners
                this.generatedRoute = { spawnPoints: [
                    { x: 25, y: 25 }, { x: w - 25, y: 25 },
                    { x: 25, y: h - 25 }, { x: w - 25, y: h - 25 },
                    { x: w/2, y: 20 }, { x: w/2, y: h - 20 },
                    { x: 20, y: h/2 }, { x: w - 20, y: h/2 }
                ], buildingDoors: [] };
                this.routeName = this.modeState.bossType ? 
                    { warden: 'The Courtyard', swarmQueen: 'The Nest', phantom: 'The Graveyard', ironclad: 'The Foundry', cubeAnomaly: 'The Rift' }[this.modeState.bossType] || 'Boss Arena'
                    : 'Boss Arena';
            } else {
                // === BOSS ARENA — imposing open ground ===
                const cx = w/2, cy = h/2;
                
                // Center arena marking — cracked concrete pad
                this.add.rectangle(cx, cy, w * 0.65, h * 0.5, 0x2a2a28, 0.3).setDepth(0.8);
                this.add.rectangle(cx, cy, w * 0.63, h * 0.48, 0x252525, 0.15).setDepth(0.85);
                // Cracks in the pad
                for (let i = 0; i < 8; i++) {
                    const crg = this.add.graphics().setDepth(0.9);
                    crg.lineStyle(1, 0x1a1a18, 0.3);
                    const crx = cx + Phaser.Math.Between(-100, 100);
                    const cry = cy + Phaser.Math.Between(-60, 60);
                    const crl = Phaser.Math.Between(15, 40);
                    const cra = Math.random() * Math.PI;
                    crg.lineBetween(crx, cry, crx + Math.cos(cra) * crl, cry + Math.sin(cra) * crl);
                }
                
                // Four pillars / ruins at cardinal points
                const pillars = [
                    { x: cx - 110, y: cy - 60 }, { x: cx + 110, y: cy - 60 },
                    { x: cx - 110, y: cy + 60 }, { x: cx + 110, y: cy + 60 }
                ];
                for (const p of pillars) {
                    const pd = 3 + p.y * 0.01;
                    // Pillar base
                    IsoRenderer.cube(this, p.x, p.y, 16, 16, 20, 0x555550, { depth: pd });
                    this.addWall(p.x, p.y, 16, 16, 0x000000, false);
                    // Crumbled top
                    this.add.rectangle(p.x - 3, p.y - 12, 8, 4, 0x444440).setAngle(Phaser.Math.Between(-10, 10)).setDepth(pd + 1);
                    // Rubble at base
                    for (let r = 0; r < 3; r++) {
                        this.add.rectangle(
                            p.x + Phaser.Math.Between(-12, 12), p.y + Phaser.Math.Between(6, 14),
                            Phaser.Math.Between(3, 7), Phaser.Math.Between(2, 5), 0x444440, 0.5
                        ).setDepth(pd + 0.5);
                    }
                }
                
                // Inner cover — low walls for dodging
                const lowWalls = [
                    { x: cx - 50, y: cy - 25, w: 24, h: 8 },
                    { x: cx + 50, y: cy + 25, w: 24, h: 8 },
                    { x: cx, y: cy - 50, w: 20, h: 10 },
                    { x: cx, y: cy + 55, w: 20, h: 10 }
                ];
                for (const lw of lowWalls) {
                    const pd = 3 + lw.y * 0.01;
                    IsoRenderer.cube(this, lw.x, lw.y, lw.w, lw.h, 4, 0x4a4a42, { depth: pd });
                    this.addWall(lw.x, lw.y, lw.w, lw.h, 0x000000, false);
                }
                
                // Ominous ground markings — ritual circle / scorch marks
                const circleG = this.add.graphics().setDepth(1.0);
                circleG.lineStyle(2, 0x332211, 0.2);
                circleG.strokeCircle(cx, cy, 55);
                circleG.lineStyle(1, 0x331111, 0.15);
                circleG.strokeCircle(cx, cy, 45);
                // Cross marks
                circleG.lineStyle(1, 0x331111, 0.15);
                circleG.lineBetween(cx - 50, cy, cx + 50, cy);
                circleG.lineBetween(cx, cy - 35, cx, cy + 35);
                
                // Scattered bones / remains
                for (let i = 0; i < 8; i++) {
                    const bx = cx + Phaser.Math.Between(-80, 80);
                    const by = cy + Phaser.Math.Between(-50, 50);
                    this.add.rectangle(bx, by, Phaser.Math.Between(4, 8), 2, 0x8a8a7a, 0.3).setAngle(Phaser.Math.Between(0, 180)).setDepth(1.5);
                }
                
                // Ambient smoke wisps at edges
                const smokeSpots = [
                    { x: 40, y: h - 60 }, { x: w - 40, y: 60 },
                    { x: 60, y: 80 }, { x: w - 70, y: h - 80 }
                ];
                for (const ss of smokeSpots) {
                    this.time.addEvent({ delay: 800 + Math.random() * 400, loop: true, callback: () => {
                        const smoke = this.add.circle(
                            ss.x + Phaser.Math.Between(-5, 5), ss.y,
                            Phaser.Math.Between(3, 6), 0x444444, 0.2
                        ).setDepth(11);
                        this.tweens.add({ targets: smoke, alpha: 0, y: smoke.y - 20, scaleX: 2, duration: 1500, onComplete: () => smoke.destroy() });
                    }});
                }
                
                this.generatedRoute = { spawnPoints: [
                    { x: 60, y: 60 }, { x: w-60, y: 60 },
                    { x: 60, y: h-60 }, { x: w-60, y: h-60 },
                    { x: w/2, y: 40 }, { x: w/2, y: h-40 }
                ], buildingDoors: [] };
                this.routeName = biomeConfig.name;
                // Vehicle far south — not accessible until boss is dead
                const bossVX = 80, bossVY = h - 55;
                const bossVeh = SpriteManager.createVehicle(this, -60, bossVY, 'side').setScale(1.2).setDepth(10 + bossVY * 0.01);
                this.add.ellipse(bossVX + 8, bossVY + 18, 70, 16, 0x000000, 0.3).setDepth(3);
                this.addWall(bossVX, bossVY, 60, 24, 0x000000, false);
                this.parkedVehicle = { x: bossVX, y: bossVY };
                this.parkedVehicleSprite = bossVeh;
                if (this.savedPlayerPos) {
                    bossVeh.setPosition(bossVX, bossVY);
                    if (this.player) {
                        this.player.setVisible(true);
                        if (this.player.backpack) this.player.backpack.setVisible(true);
                        if (this.player._crownSprite) this.player._crownSprite.setVisible(true);
                    }
                    this.cameras.main.startFollow(this.player, true, 1, 1);
                } else {
                    if (this.player) this.player.setVisible(false);
                    this.playVehicleArrival(bossVeh, bossVX, bossVY);
                }
            }
        } else {
            const generator = new TerrainGenerator(this, biomeType, routeSeed, this.locationType);
            this.generatedRoute = generator.generate();
            this.routeName = this.locationType ? (this.destinationNode?.name || CONFIG.biomes[biomeType].name) : CONFIG.biomes[biomeType].name;
            this.renderRoute(this.generatedRoute);
        }
        
        // Border walls
        this.addWall(w/2, 8, w, 16, 0x2a3a2a, false);
        this.addWall(w/2, h-8, w, 16, 0x2a3a2a, false);
        this.addWall(8, h/2, 16, h, 0x2a3a2a, false);
        this.addWall(w-8, h/2, 16, h, 0x2a3a2a, false);
        
        this.walls.refresh();
        
        // Ambient light overlay
        if (this.lighting.intensity < 1) {
            this.ambientOverlay = this.add.rectangle(CONFIG.width/2, CONFIG.height/2, CONFIG.width, CONFIG.height, this.lighting.ambient, 1 - this.lighting.intensity);
            this.ambientOverlay.setBlendMode(Phaser.BlendModes.MULTIPLY);
            this.ambientOverlay.setScrollFactor(0).setDepth(98);
        }
        
        // Use generated spawn points
        this.spawnPoints = this.generatedRoute.spawnPoints;
        // buildingDoors are populated during renderRoute() → createBuilding()
        // which creates actual door objects with doorSide, archetype, etc.
        // Do NOT overwrite with generatedRoute.buildingDoors (data-only, no doorSide)
    }
    
    renderRoute(route) {
        const w = CONFIG.world.width;
        const h = CONFIG.world.height;
        
        // Ground color from route type
        const groundColor = this.tintColor(route.groundColor, this.lighting.ambient, this.lighting.intensity);
        this.add.rectangle(w/2, h/2, w, h, groundColor).setDepth(0);
        
        // Add parked player vehicle — always present in zone
        this.parkedVehicle = null;
        if (route.road && route.road.segments.length > 0) {
            const roadSeg = route.road.segments[0];
            const vehicleX = 80;
            const vehicleY = roadSeg.y + 15;
            const parkedVehicle = SpriteManager.createVehicle(this, -60, vehicleY, 'side');
            parkedVehicle.setScale(1.2).setDepth(10 + vehicleY * 0.01);
            this.add.ellipse(vehicleX + 8, vehicleY + 18, 70, 16, 0x000000, 0.3).setDepth(3);
            this.addWall(vehicleX, vehicleY, 60, 24, 0x000000, false);
            this.parkedVehicle = { x: vehicleX, y: vehicleY };
            this.parkedVehicleSprite = parkedVehicle;
            
            if (this.savedPlayerPos) {
                // Returning from building — skip arrival, place vehicle at parked position
                parkedVehicle.setPosition(vehicleX, vehicleY);
                if (this.player) {
                    this.player.setVisible(true);
                    if (this.player.backpack) this.player.backpack.setVisible(true);
                    if (this.player._crownSprite) this.player._crownSprite.setVisible(true);
                }
                this.cameras.main.startFollow(this.player, true, 1, 1);
            } else {
                // Hide player during arrival
                if (this.player) this.player.setVisible(false);
                
                // Arrival animation — drive in from left with exhaust
                this.playVehicleArrival(parkedVehicle, vehicleX, vehicleY);
            }
        }
        
        // Biome-specific ground details
        const biomeType = route.biomeType || CONFIG.currentBiome.type;
        const gds = (CONFIG.activeMapSize || CONFIG.mapSizes.medium).groundDetailScale || 1;
        
        if (biomeType === 'grassy') {
            // Grass tufts
            for (let i = 0; i < Math.round(60 * gds); i++) {
                const gx = Phaser.Math.Between(20, w - 20);
                const gy = Phaser.Math.Between(20, h - 20);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(gy - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const tuftColor = this.tintColor(0x3a4a3a, this.lighting.ambient, this.lighting.intensity);
                const tuft = this.add.rectangle(gx, gy, Phaser.Math.Between(4, 8), Phaser.Math.Between(3, 6), tuftColor);
                tuft.setAngle(Phaser.Math.Between(-15, 15)).setDepth(1);
            }
            // Moss patches — organic blobs on ground, nature reclaiming concrete
            for (let i = 0; i < Math.round(10 * gds); i++) {
                const mx = Phaser.Math.Between(30, w - 30);
                const my = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(my - seg.y) < seg.height/2 + 15) onRoad = true;
                }
                if (onRoad) continue;
                const mossColor = this.tintColor(0x2a4a1a, this.lighting.ambient, this.lighting.intensity);
                const mossLight = this.tintColor(0x3a5a2a, this.lighting.ambient, this.lighting.intensity);
                const mw = Phaser.Math.Between(14, 35);
                const mh = Phaser.Math.Between(10, 22);
                this.add.ellipse(mx, my, mw, mh, mossColor, 0.25).setDepth(1);
                // Lighter inner patch for depth
                this.add.ellipse(mx - 2, my - 1, mw * 0.5, mh * 0.4, mossLight, 0.15).setDepth(1.05);
            }
            // Wildflower clusters — tiny colored dots in groups of 3-6
            for (let i = 0; i < Math.round(6 * gds); i++) {
                const fx = Phaser.Math.Between(30, w - 30);
                const fy = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(fy - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const flowerColors = [0x8a5a8a, 0x8a8a3a, 0xaa7a4a, 0x7a7aaa]; // purple, yellow, orange, blue
                const fc = this.tintColor(flowerColors[Math.floor(Math.random() * flowerColors.length)], this.lighting.ambient, this.lighting.intensity);
                const count = 3 + Math.floor(Math.random() * 4);
                for (let f = 0; f < count; f++) {
                    const fdx = fx + Phaser.Math.Between(-6, 6);
                    const fdy = fy + Phaser.Math.Between(-4, 4);
                    this.add.circle(fdx, fdy, 1, fc, 0.4 + Math.random() * 0.2).setDepth(1.2);
                }
                // Tiny stem/leaf beneath each cluster
                const stemColor = this.tintColor(0x3a5a2a, this.lighting.ambient, this.lighting.intensity);
                this.add.rectangle(fx, fy + 2, 2, 3, stemColor, 0.2).setDepth(1.15);
            }
            // Vine tendrils — snaking across the ground
            for (let i = 0; i < Math.round(5 * gds); i++) {
                let vx = Phaser.Math.Between(40, w - 40);
                let vy = Phaser.Math.Between(40, h - 40);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(vy - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const vineColor = this.tintColor(0x2a4a1a, this.lighting.ambient, this.lighting.intensity);
                // 4-6 connected organic segments with gentle curves
                const segments = 4 + Math.floor(Math.random() * 3);
                for (let s = 0; s < segments; s++) {
                    const angle = Phaser.Math.Between(-40, 40) + (s * 15); // gentle wandering
                    const len = Phaser.Math.Between(8, 18);
                    const rad = angle * Math.PI / 180;
                    const ex = vx + Math.cos(rad) * len;
                    const ey = vy + Math.sin(rad) * len * 0.5;
                    const midX = (vx + ex) / 2;
                    const midY = (vy + ey) / 2;
                    const dist = Math.sqrt((ex - vx) ** 2 + (ey - vy) ** 2);
                    const drawAngle = Math.atan2(ey - vy, ex - vx) * 180 / Math.PI;
                    this.add.rectangle(midX, midY, dist, 1, vineColor, 0.2 + Math.random() * 0.1)
                        .setAngle(drawAngle).setDepth(1.1);
                    // Occasional leaf node at joint
                    if (Math.random() < 0.4) {
                        this.add.ellipse(vx, vy, 3, 2, vineColor, 0.25).setDepth(1.15);
                    }
                    vx = ex; vy = ey;
                }
            }
        } else if (biomeType === 'barren') {
            // Cracked earth patches and dirt spots
            for (let i = 0; i < Math.round(30 * gds); i++) {
                const gx = Phaser.Math.Between(20, w - 20);
                const gy = Phaser.Math.Between(20, h - 20);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(gy - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const crackColor = this.tintColor(0x2a2520, this.lighting.ambient, this.lighting.intensity);
                const crack = this.add.rectangle(gx, gy, Phaser.Math.Between(12, 30), Phaser.Math.Between(1, 3), crackColor);
                crack.setAngle(Phaser.Math.Between(-40, 40)).setDepth(1);
            }
            // Dusty spots
            for (let i = 0; i < Math.round(15 * gds); i++) {
                const dx = Phaser.Math.Between(30, w - 30);
                const dy = Phaser.Math.Between(30, h - 30);
                const dustColor = this.tintColor(0x3a3025, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(dx, dy, Phaser.Math.Between(20, 50), Phaser.Math.Between(15, 35), dustColor, 0.25).setDepth(1);
            }
            // Sand drifts — directional wind-blown accumulation patches
            for (let i = 0; i < Math.round(6 * gds); i++) {
                const sx = Phaser.Math.Between(40, w - 40);
                const sy = Phaser.Math.Between(40, h - 40);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(sy - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const sandColor = this.tintColor(0x4a4235, this.lighting.ambient, this.lighting.intensity);
                const sandLight = this.tintColor(0x5a5040, this.lighting.ambient, this.lighting.intensity);
                const dw = Phaser.Math.Between(25, 55);
                const dh = Phaser.Math.Between(8, 18);
                // Elongated wind-shaped ellipse — angled consistently (prevailing wind)
                this.add.ellipse(sx, sy, dw, dh, sandColor, 0.2).setAngle(Phaser.Math.Between(10, 25)).setDepth(1);
                // Windward crest — lighter strip on the leading edge
                this.add.ellipse(sx - dw * 0.2, sy - 1, dw * 0.4, dh * 0.4, sandLight, 0.15).setAngle(Phaser.Math.Between(10, 25)).setDepth(1.05);
            }
            // Bleached sun-scorched patches — lighter ground from UV exposure
            for (let i = 0; i < Math.round(5 * gds); i++) {
                const bx = Phaser.Math.Between(30, w - 30);
                const by = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(by - seg.y) < seg.height/2 + 15) onRoad = true;
                }
                if (onRoad) continue;
                const bleachColor = this.tintColor(0x4a4538, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(bx, by, Phaser.Math.Between(18, 40), Phaser.Math.Between(12, 28), bleachColor, 0.15).setDepth(0.95);
            }
            // Tire ruts — old vehicle tracks, paired parallel lines
            for (let i = 0; i < Math.round(3 * gds); i++) {
                const rx = Phaser.Math.Between(60, w - 60);
                const ry = Phaser.Math.Between(40, h - 40);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(ry - seg.y) < seg.height/2 + 25) onRoad = true;
                }
                if (onRoad) continue;
                const rutColor = this.tintColor(0x252018, this.lighting.ambient, this.lighting.intensity);
                const rutAngle = Phaser.Math.Between(-20, 20);
                const rutLen = Phaser.Math.Between(30, 60);
                const spacing = 6; // axle width
                // Two parallel tracks
                this.add.rectangle(rx, ry - spacing/2, rutLen, 2, rutColor, 0.15)
                    .setAngle(rutAngle).setDepth(1);
                this.add.rectangle(rx, ry + spacing/2, rutLen, 2, rutColor, 0.15)
                    .setAngle(rutAngle).setDepth(1);
            }
            // Gravel scatter — small angular stones in loose clusters
            for (let i = 0; i < Math.round(8 * gds); i++) {
                const gx = Phaser.Math.Between(20, w - 20);
                const gy = Phaser.Math.Between(20, h - 20);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(gy - seg.y) < seg.height/2 + 15) onRoad = true;
                }
                if (onRoad) continue;
                const gravelColor = this.tintColor(0x3a352a, this.lighting.ambient, this.lighting.intensity);
                const count = 3 + Math.floor(Math.random() * 4);
                for (let g = 0; g < count; g++) {
                    const gdx = gx + Phaser.Math.Between(-5, 5);
                    const gdy = gy + Phaser.Math.Between(-3, 3);
                    this.add.rectangle(gdx, gdy, Phaser.Math.Between(2, 4), Phaser.Math.Between(1, 3), gravelColor, 0.3)
                        .setAngle(Phaser.Math.Between(-45, 45)).setDepth(1.1);
                }
            }
        } else if (biomeType === 'apocalyptic') {
            // Rubble patches
            for (let i = 0; i < Math.round(18 * gds); i++) {
                const rx = Phaser.Math.Between(20, w - 20);
                const ry = Phaser.Math.Between(20, h - 20);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(ry - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const rubbleColor = this.tintColor(0x1a1a18, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(rx, ry, Phaser.Math.Between(8, 20), Phaser.Math.Between(6, 14), rubbleColor, 0.4).setDepth(1);
            }
            // Corrupted ground patches — violet-black Cube saturation
            for (let i = 0; i < Math.round(8 * gds); i++) {
                const cx = Phaser.Math.Between(30, w - 30);
                const cy = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(cy - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const corruptColor = this.tintColor(0x1a1020, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(cx, cy, Phaser.Math.Between(20, 50), Phaser.Math.Between(15, 35), corruptColor, 0.35).setDepth(1);
            }
            // Geometric ground veins — faint cyan traces following angular paths
            for (let i = 0; i < Math.round(6 * gds); i++) {
                let vx = Phaser.Math.Between(40, w - 40);
                let vy = Phaser.Math.Between(40, h - 40);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(vy - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const veinColor = this.tintColor(0x4a6a7a, this.lighting.ambient, this.lighting.intensity);
                // Draw 3-5 connected angular segments
                const segments = 3 + Math.floor(Math.random() * 3);
                for (let s = 0; s < segments; s++) {
                    const angle = Math.floor(Math.random() * 6) * 60; // snap to 60-degree increments
                    const len = Phaser.Math.Between(12, 28);
                    const rad = angle * Math.PI / 180;
                    const ex = vx + Math.cos(rad) * len;
                    const ey = vy + Math.sin(rad) * len * 0.5; // foreshorten for ¾ view
                    const midX = (vx + ex) / 2;
                    const midY = (vy + ey) / 2;
                    const dist = Math.sqrt((ex - vx) ** 2 + (ey - vy) ** 2);
                    const drawAngle = Math.atan2(ey - vy, ex - vx) * 180 / Math.PI;
                    this.add.rectangle(midX, midY, dist, 1, veinColor, 0.15 + Math.random() * 0.1)
                        .setAngle(drawAngle).setDepth(1.1);
                    vx = ex; vy = ey;
                }
            }
            // Scorch marks (fewer than before — the corruption is the new dominant detail)
            for (let i = 0; i < Math.round(5 * gds); i++) {
                const sx = Phaser.Math.Between(40, w - 40);
                const sy = Phaser.Math.Between(40, h - 40);
                const scorchColor = this.tintColor(0x151210, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(sx, sy, Phaser.Math.Between(25, 50), Phaser.Math.Between(20, 40), scorchColor, 0.25).setDepth(1);
            }
        }
        
        // ===== BIOME-SPECIFIC ENVIRONMENTAL OBJECTS =====
        if (biomeType === 'grassy') {
            // Grass tuft clusters (subtle ground variation)
            for (let i = 0; i < Math.round(8 * gds); i++) {
                const fx = Phaser.Math.Between(30, w - 30);
                const fy = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(fy - seg.y) < seg.height/2 + 30) onRoad = true;
                }
                if (onRoad) continue;
                const gc = this.tintColor(0x3a5a2a, this.lighting.ambient, this.lighting.intensity);
                // 2-3 grass blades per tuft
                for (let b = 0; b < 2 + Math.floor(Math.random() * 2); b++) {
                    const bx = fx + Phaser.Math.Between(-3, 3);
                    const bh = Phaser.Math.Between(3, 6);
                    this.add.rectangle(bx, fy - bh/2, 1, bh, gc, 0.4).setDepth(1.5)
                        .setAngle(Phaser.Math.Between(-20, 20));
                }
            }
            // Puddles (after rain feel)
            for (let i = 0; i < Math.round(3 * gds); i++) {
                const px = Phaser.Math.Between(50, w - 50);
                const py = Phaser.Math.Between(50, h - 50);
                const puddleColor = this.tintColor(0x2a3540, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(px, py, Phaser.Math.Between(15, 35), Phaser.Math.Between(10, 20), puddleColor, 0.2).setDepth(1);
                // Slight reflection highlight
                this.add.ellipse(px - 3, py - 2, Phaser.Math.Between(6, 12), Phaser.Math.Between(4, 8), 0x4a5a6a, 0.1).setDepth(1.1);
            }
            // Fallen leaf litter patches — clustered brown/orange dots
            for (let i = 0; i < Math.round(7 * gds); i++) {
                const lx = Phaser.Math.Between(30, w - 30);
                const ly = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(ly - seg.y) < seg.height/2 + 15) onRoad = true;
                }
                if (onRoad) continue;
                const leafColors = [0x5a4a2a, 0x6a5a3a, 0x4a3a1a, 0x5a3a2a];
                const count = 4 + Math.floor(Math.random() * 5);
                for (let l = 0; l < count; l++) {
                    const ldx = lx + Phaser.Math.Between(-8, 8);
                    const ldy = ly + Phaser.Math.Between(-5, 5);
                    const lc = this.tintColor(leafColors[Math.floor(Math.random() * leafColors.length)], this.lighting.ambient, this.lighting.intensity);
                    this.add.ellipse(ldx, ldy, Phaser.Math.Between(2, 4), Phaser.Math.Between(1, 3), lc, 0.25 + Math.random() * 0.15)
                        .setAngle(Phaser.Math.Between(-60, 60)).setDepth(1.2);
                }
            }
            // Crack-through-asphalt grass strips — nature pushing through pavement
            for (let i = 0; i < Math.round(4 * gds); i++) {
                const cx = Phaser.Math.Between(40, w - 40);
                const cy = Phaser.Math.Between(40, h - 40);
                // These intentionally appear near roads — on the edges
                const grassCrackColor = this.tintColor(0x3a5a2a, this.lighting.ambient, this.lighting.intensity);
                const crackDark = this.tintColor(0x2a2520, this.lighting.ambient, this.lighting.intensity);
                const stripAngle = Phaser.Math.Between(-15, 15);
                const stripLen = Phaser.Math.Between(12, 30);
                // Dark crack line in ground
                this.add.rectangle(cx, cy, stripLen, 2, crackDark, 0.2).setAngle(stripAngle).setDepth(1);
                // Grass blades emerging from crack
                const bladeCount = 3 + Math.floor(Math.random() * 3);
                for (let b = 0; b < bladeCount; b++) {
                    const offset = (b / bladeCount - 0.5) * stripLen * 0.8;
                    const rad = stripAngle * Math.PI / 180;
                    const bx = cx + Math.cos(rad) * offset;
                    const by = cy + Math.sin(rad) * offset;
                    const bh = Phaser.Math.Between(3, 7);
                    this.add.rectangle(bx, by - bh/2, 1, bh, grassCrackColor, 0.35)
                        .setAngle(Phaser.Math.Between(-25, 25)).setDepth(1.5);
                }
            }
            // Algae puddles — stagnant water with green film
            for (let i = 0; i < Math.round(2 * gds); i++) {
                const ax = Phaser.Math.Between(50, w - 50);
                const ay = Phaser.Math.Between(50, h - 50);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(ay - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const waterDark = this.tintColor(0x1a2a20, this.lighting.ambient, this.lighting.intensity);
                const algaeColor = this.tintColor(0x2a4a1a, this.lighting.ambient, this.lighting.intensity);
                const pw = Phaser.Math.Between(18, 35);
                const ph = Phaser.Math.Between(10, 20);
                this.add.ellipse(ax, ay, pw, ph, waterDark, 0.25).setDepth(1);
                // Green film on surface
                this.add.ellipse(ax + 2, ay + 1, pw * 0.6, ph * 0.5, algaeColor, 0.15).setDepth(1.1);
                // Edge moisture ring
                this.add.ellipse(ax, ay, pw + 4, ph + 3, waterDark, 0.08).setDepth(0.95);
            }
        } else if (biomeType === 'barren') {
            // Rock formations
            for (let i = 0; i < Math.round(6 * gds); i++) {
                const rx = Phaser.Math.Between(40, w - 40);
                const ry = Phaser.Math.Between(40, h - 40);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(ry - seg.y) < seg.height/2 + 30) onRoad = true;
                }
                if (onRoad) continue;
                const rockColor = this.tintColor(0x3a3530, this.lighting.ambient, this.lighting.intensity);
                const rockDark = this.tintColor(0x2a2520, this.lighting.ambient, this.lighting.intensity);
                const rw = Phaser.Math.Between(8, 18);
                const rh = Phaser.Math.Between(6, 12);
                // Shadow
                this.add.ellipse(rx + 2, ry + rh/2 + 2, rw + 4, 5, 0x000000, 0.15).setDepth(1);
                // Rock body
                this.add.ellipse(rx, ry, rw, rh, rockColor).setDepth(1.5);
                this.add.ellipse(rx - 1, ry - 1, rw * 0.7, rh * 0.6, rockDark, 0.3).setDepth(1.6);
            }
            // Dead bush skeletons
            for (let i = 0; i < Math.round(4 * gds); i++) {
                const bx = Phaser.Math.Between(30, w - 30);
                const by = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(by - seg.y) < seg.height/2 + 25) onRoad = true;
                }
                if (onRoad) continue;
                const bushColor = this.tintColor(0x4a4030, this.lighting.ambient, this.lighting.intensity);
                // Scraggly branches
                for (let b = 0; b < 4; b++) {
                    const angle = Phaser.Math.Between(-60, 60);
                    const len = Phaser.Math.Between(6, 14);
                    this.add.rectangle(bx, by - 2, len, 1.5, bushColor, 0.5).setDepth(1.5).setAngle(angle);
                }
                this.add.rectangle(bx, by + 3, 2, 6, bushColor, 0.4).setDepth(1.4);
            }
            // Tumbleweed silhouettes — scraggly dry ball shapes
            for (let i = 0; i < Math.round(3 * gds); i++) {
                const tx = Phaser.Math.Between(30, w - 30);
                const ty = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(ty - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const twigColor = this.tintColor(0x4a3a28, this.lighting.ambient, this.lighting.intensity);
                const twigDark = this.tintColor(0x3a2a18, this.lighting.ambient, this.lighting.intensity);
                const ts = Phaser.Math.Between(6, 12);
                // Shadow
                this.add.ellipse(tx + 1, ty + ts/2 + 1, ts + 2, 3, 0x000000, 0.1).setDepth(1);
                // Tangled ball shape — outer ring
                this.add.ellipse(tx, ty, ts, ts * 0.8, twigColor, 0.3).setDepth(1.5);
                // Inner tangle lines
                for (let t = 0; t < 5; t++) {
                    const ta = Phaser.Math.Between(0, 180);
                    this.add.rectangle(tx, ty, ts * 0.7, 1, twigDark, 0.25).setAngle(ta).setDepth(1.6);
                }
            }
            // Erosion channels — shallow grooves where water once ran
            for (let i = 0; i < Math.round(3 * gds); i++) {
                let ex = Phaser.Math.Between(40, w - 40);
                let ey = Phaser.Math.Between(40, h - 40);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(ey - seg.y) < seg.height/2 + 25) onRoad = true;
                }
                if (onRoad) continue;
                const channelColor = this.tintColor(0x252018, this.lighting.ambient, this.lighting.intensity);
                // Meandering downhill path (3-5 segments)
                const segments = 3 + Math.floor(Math.random() * 3);
                for (let s = 0; s < segments; s++) {
                    const angle = 70 + Phaser.Math.Between(-20, 20); // mostly downward
                    const len = Phaser.Math.Between(10, 22);
                    const rad = angle * Math.PI / 180;
                    const nx = ex + Math.cos(rad) * len;
                    const ny = ey + Math.sin(rad) * len * 0.5;
                    const midX = (ex + nx) / 2;
                    const midY = (ey + ny) / 2;
                    const dist = Math.sqrt((nx - ex) ** 2 + (ny - ey) ** 2);
                    const drawAngle = Math.atan2(ny - ey, nx - ex) * 180 / Math.PI;
                    // Channel groove
                    this.add.rectangle(midX, midY, dist, 2, channelColor, 0.12)
                        .setAngle(drawAngle).setDepth(1);
                    // Slightly wider shadow beneath
                    this.add.rectangle(midX, midY + 1, dist, 3, channelColor, 0.06)
                        .setAngle(drawAngle).setDepth(0.95);
                    ex = nx; ey = ny;
                }
            }
            // Heat shimmer patches — very faint light distortion zones
            for (let i = 0; i < Math.round(2 * gds); i++) {
                const hx = Phaser.Math.Between(60, w - 60);
                const hy = Phaser.Math.Between(60, h - 60);
                const shimmerColor = this.tintColor(0x5a5040, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(hx, hy, Phaser.Math.Between(30, 60), Phaser.Math.Between(18, 35), shimmerColor, 0.06).setDepth(0.9);
            }
        } else if (biomeType === 'apocalyptic') {
            // Debris piles (kept but reduced — urban ruins still exist under the corruption)
            for (let i = 0; i < Math.round(3 * gds); i++) {
                const dx = Phaser.Math.Between(50, w - 50);
                const dy = Phaser.Math.Between(50, h - 50);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(dy - seg.y) < seg.height/2 + 30) onRoad = true;
                }
                if (onRoad) continue;
                const pileColor = this.tintColor(0x2a2520, this.lighting.ambient, this.lighting.intensity);
                const pileDark = this.tintColor(0x1a1815, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(dx, dy, Phaser.Math.Between(20, 40), Phaser.Math.Between(12, 22), pileColor, 0.5).setDepth(1.5);
                for (let j = 0; j < 4; j++) {
                    const cx = dx + Phaser.Math.Between(-10, 10);
                    const cy = dy + Phaser.Math.Between(-6, 6);
                    this.add.rectangle(cx, cy, Phaser.Math.Between(4, 10), Phaser.Math.Between(3, 7), pileDark, 0.5).setDepth(1.6).setAngle(Phaser.Math.Between(-30, 30));
                }
            }
            // Crystal emergence points — small hexagonal spires pushing up from ground
            for (let i = 0; i < Math.round(4 * gds); i++) {
                const cx = Phaser.Math.Between(40, w - 40);
                const cy = Phaser.Math.Between(40, h - 40);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(cy - seg.y) < seg.height/2 + 25) onRoad = true;
                }
                if (onRoad) continue;
                const crystalColor = this.tintColor(0x5a6a7a, this.lighting.ambient, this.lighting.intensity);
                const crystalGlow = this.tintColor(0x8aaacc, this.lighting.ambient, this.lighting.intensity);
                // Base crack in ground
                this.add.ellipse(cx, cy + 3, Phaser.Math.Between(8, 14), Phaser.Math.Between(4, 7), 0x1a1020, 0.4).setDepth(1.4);
                // Crystal body — front face dominant (north-facing)
                const ch = Phaser.Math.Between(8, 16);
                const cw = Phaser.Math.Between(3, 6);
                this.add.rectangle(cx, cy - ch/2 + 2, cw, ch, crystalColor, 0.7).setDepth(1.7);
                // Highlight edge
                this.add.rectangle(cx - 1, cy - ch/2 + 1, 1, ch - 2, crystalGlow, 0.3).setDepth(1.8);
                // Top facet (thin strip for ¾ view)
                this.add.rectangle(cx, cy - ch + 3, cw + 1, 2, crystalGlow, 0.25).setDepth(1.9);
                // Faint glow on ground
                this.add.ellipse(cx, cy + 4, cw + 8, 4, crystalGlow, 0.08).setDepth(1.3);
            }
            // Pulsing fungal clusters — low bioluminescent ground growths
            for (let i = 0; i < Math.round(3 * gds); i++) {
                const fx = Phaser.Math.Between(30, w - 30);
                const fy = Phaser.Math.Between(30, h - 30);
                let onRoad = false;
                for (const seg of route.road.segments) {
                    if (Math.abs(fy - seg.y) < seg.height/2 + 20) onRoad = true;
                }
                if (onRoad) continue;
                const fungalColor = this.tintColor(0x6a8a8a, this.lighting.ambient, this.lighting.intensity);
                const fungalGlow = this.tintColor(0x8ababa, this.lighting.ambient, this.lighting.intensity);
                // Cluster of 3-5 small caps
                const count = 3 + Math.floor(Math.random() * 3);
                for (let f = 0; f < count; f++) {
                    const fdx = fx + Phaser.Math.Between(-6, 6);
                    const fdy = fy + Phaser.Math.Between(-3, 3);
                    const fs = Phaser.Math.Between(2, 4);
                    // Hexagonal cap (approximated as wide rect at this scale)
                    this.add.rectangle(fdx, fdy, fs + 1, fs, fungalColor, 0.5).setDepth(1.6);
                    this.add.rectangle(fdx, fdy, fs - 1, fs - 1, fungalGlow, 0.2).setDepth(1.7);
                }
                // Ground glow beneath cluster
                this.add.ellipse(fx, fy + 2, 14, 6, fungalGlow, 0.06).setDepth(1.2);
            }
            // Corrupted puddles — dark iridescent standing liquid
            for (let i = 0; i < Math.round(2 * gds); i++) {
                const px = Phaser.Math.Between(50, w - 50);
                const py = Phaser.Math.Between(50, h - 50);
                const puddleColor = this.tintColor(0x101018, this.lighting.ambient, this.lighting.intensity);
                const sheenColor = this.tintColor(0x4a3a6a, this.lighting.ambient, this.lighting.intensity);
                this.add.ellipse(px, py, Phaser.Math.Between(14, 30), Phaser.Math.Between(8, 18), puddleColor, 0.35).setDepth(1);
                // Iridescent surface sheen
                this.add.ellipse(px - 2, py - 1, Phaser.Math.Between(8, 16), Phaser.Math.Between(4, 10), sheenColor, 0.1).setDepth(1.1);
            }
        }
        
        // Render road
        this.renderRoad(route.road);
        
        // Render trees first (behind buildings) — route through createProp for destructible tracking
        if (!this.searchableProps) this.searchableProps = [];
        for (const tree of route.trees) {
            const treeTypeMap = { leafy: 'tree', pine: 'tree_pine', dead: 'dead_tree', converted: 'converted_tree' };
            try {
                this.createProp({ x: tree.x, y: tree.y, type: treeTypeMap[tree.type] || 'tree' });
            } catch(e) { console.warn('Tree prop error:', tree.type, e); }
        }
        
        // Render buildings
        for (const building of route.buildings) {
            this.createBuilding(building.x, building.y, building.width, building.height, 
                               building.name, building.archetype, building.subtype, building.color, 
                               building.type, building.shape, building.wing, building.damaged, building.buildingId, building.interiorScale);
        }
        
        // Render shell buildings (open ruins — walk-through, no scene transition)
        if (route.shellBuildings) {
            for (const shell of route.shellBuildings) {
                this.createShellBuilding(shell);
            }
        }
        
        // Render environmental storytelling scenes
        if (route.storyScenes) {
            for (const scene of route.storyScenes) {
                this.createStoryScene(scene);
            }
        }
        
        // Render props
        this.searchableProps = [];
        for (const prop of route.props) {
            try {
                this.createProp(prop);
            } catch(e) { console.warn('Prop error:', prop.type, e); }
        }
        
        // Render roadside vehicle wrecks (siphon-able)
        this.siphonVehicles = [];
        if (route.vehicles) {
            for (const veh of route.vehicles) {
                this.createSiphonVehicle(veh.x, veh.y, veh.type);
            }
        }
        
        // === HIDDEN CHESTS — rare discoverable loot (scavenge, encounter, scavenge_event only) ===
        if (!this.hiddenChests) this.hiddenChests = [];
        if (false /* deprecated modes removed */) {
            const chestChance = 0.10; // 10% per zone
            if (Math.random() < chestChance) {
                this.spawnHiddenChest(route);
            }
        }
        
        // === WORLD NOTES — diegetic lore objects ===
        this.worldNoteProps = [];
        if (false /* deprecated modes removed */) {
            this.spawnWorldNotes(route);
        }
    }
    
    renderRoad(road) {
        const biomeType = CONFIG.currentBiome ? CONFIG.currentBiome.type : 'grassy';
        const roadColor = this.tintColor(this.lighting.roadColor, this.lighting.ambient, this.lighting.intensity);
        const lineColor = this.tintColor(0x4a4a3a, this.lighting.ambient, this.lighting.intensity);
        const edgeColor = this.tintColor(0x3a3a3a, this.lighting.ambient, this.lighting.intensity);
        const sidewalkColor = this.tintColor(0x4a4a42, this.lighting.ambient, this.lighting.intensity);
        const pathColor = this.tintColor(0x5a5a50, this.lighting.ambient, this.lighting.intensity);
        
        for (const seg of road.segments) {
            if (seg.isParkingLot) {
                // Parking lot - large asphalt area with lines
                this.add.rectangle(seg.x, seg.y, seg.width, seg.height, roadColor).setDepth(2);
                
                // Parking lines
                const lineSpacing = 40;
                for (let x = seg.x - seg.width/2 + 30; x < seg.x + seg.width/2 - 30; x += lineSpacing) {
                    this.add.rectangle(x, seg.y - seg.height/4, 3, seg.height/3, lineColor).setDepth(2);
                    this.add.rectangle(x, seg.y + seg.height/4, 3, seg.height/3, lineColor).setDepth(2);
                }
            } else if (seg.isPath) {
                // Walking path (for parks/cemeteries)
                this.add.rectangle(seg.x, seg.y, seg.width, seg.height, pathColor).setDepth(2);
                // Path edge detail
                const darker = this.tintColor(0x4a4a40, this.lighting.ambient, this.lighting.intensity);
                if (seg.isVertical) {
                    this.add.rectangle(seg.x - seg.width/2 + 2, seg.y, 3, seg.height, darker).setDepth(2);
                    this.add.rectangle(seg.x + seg.width/2 - 2, seg.y, 3, seg.height, darker).setDepth(2);
                } else {
                    this.add.rectangle(seg.x, seg.y - seg.height/2 + 2, seg.width, 3, darker).setDepth(2);
                    this.add.rectangle(seg.x, seg.y + seg.height/2 - 2, seg.width, 3, darker).setDepth(2);
                }
            } else if (seg.isVertical) {
                // Vertical road (for intersections)
                this.add.rectangle(seg.x, seg.y, seg.width, seg.height, roadColor).setDepth(2);
                
                // Center line (vertical)
                for (let y = 30; y < seg.height - 30; y += 50) {
                    this.add.rectangle(seg.x, seg.y - seg.height/2 + y, 4, 25, lineColor).setDepth(2);
                }
                
                // Edge lines
                this.add.rectangle(seg.x - seg.width/2 + 2, seg.y, 4, seg.height, edgeColor).setDepth(2);
                this.add.rectangle(seg.x + seg.width/2 - 2, seg.y, 4, seg.height, edgeColor).setDepth(2);
                
                // Sidewalks (vertical)
                this.add.rectangle(seg.x - seg.width/2 - 14, seg.y, 24, seg.height, sidewalkColor).setDepth(2);
                this.add.rectangle(seg.x + seg.width/2 + 14, seg.y, 24, seg.height, sidewalkColor).setDepth(2);
            } else {
                // Regular horizontal road
                this.add.rectangle(seg.x, seg.y, seg.width, seg.height, roadColor).setDepth(2);
                
                // Biome-specific road treatment
                if (biomeType === 'barren') {
                    // Faded lines — skip some dashes
                    for (let x = 30; x < seg.width - 30; x += 50) {
                        if (Math.random() < 0.6) { // 40% chance line is faded/missing
                            const fadeAlpha = 0.3 + Math.random() * 0.4;
                            this.add.rectangle(seg.x - seg.width/2 + x, seg.y, 25, 4, lineColor, fadeAlpha).setDepth(2);
                        }
                    }
                    // Sand/dirt drifts across road
                    const driftColor = this.tintColor(0x4a4030, this.lighting.ambient, this.lighting.intensity);
                    for (let i = 0; i < 5; i++) {
                        const dx = seg.x + Phaser.Math.Between(-seg.width/3, seg.width/3);
                        const dy = seg.y + Phaser.Math.Between(-20, 20);
                        this.add.ellipse(dx, dy, Phaser.Math.Between(30, 70), Phaser.Math.Between(8, 18), driftColor, 0.25).setDepth(2.1);
                    }
                    // Dirt shoulders instead of sidewalks
                    const shoulderColor = this.tintColor(0x3a3525, this.lighting.ambient, this.lighting.intensity);
                    this.add.rectangle(seg.x, seg.y - seg.height/2 - 10, seg.width, 18, shoulderColor, 0.5).setDepth(2);
                    this.add.rectangle(seg.x, seg.y + seg.height/2 + 10, seg.width, 18, shoulderColor, 0.5).setDepth(2);
                } else if (biomeType === 'apocalyptic') {
                    // Center line (damaged)
                    for (let x = 30; x < seg.width - 30; x += 50) {
                        this.add.rectangle(seg.x - seg.width/2 + x, seg.y, 25, 4, lineColor).setDepth(2);
                    }
                    // Road cracks
                    const crackColor = this.tintColor(0x1a1a18, this.lighting.ambient, this.lighting.intensity);
                    for (let i = 0; i < 8; i++) {
                        const cx = seg.x + Phaser.Math.Between(-seg.width/3, seg.width/3);
                        const cy = seg.y + Phaser.Math.Between(-25, 25);
                        const len = Phaser.Math.Between(12, 35);
                        const angle = Phaser.Math.Between(-60, 60);
                        this.add.rectangle(cx, cy, len, 2, crackColor, 0.5).setDepth(2.1).setAngle(angle);
                    }
                    // Potholes
                    for (let i = 0; i < 3; i++) {
                        const px = seg.x + Phaser.Math.Between(-seg.width/4, seg.width/4);
                        const py = seg.y + Phaser.Math.Between(-15, 15);
                        this.add.ellipse(px, py, Phaser.Math.Between(8, 16), Phaser.Math.Between(5, 10), crackColor, 0.4).setDepth(2.1);
                    }
                    // Broken sidewalks
                    this.add.rectangle(seg.x, seg.y - seg.height/2 - 14, seg.width, 24, sidewalkColor).setDepth(2);
                    this.add.rectangle(seg.x, seg.y + seg.height/2 + 14, seg.width, 24, sidewalkColor).setDepth(2);
                    // Sidewalk cracks
                    for (let i = 0; i < 4; i++) {
                        const sx = seg.x + Phaser.Math.Between(-seg.width/3, seg.width/3);
                        const topOrBot = Math.random() < 0.5 ? seg.y - seg.height/2 - 14 : seg.y + seg.height/2 + 14;
                        this.add.rectangle(sx, topOrBot, Phaser.Math.Between(6, 15), 2, crackColor, 0.4).setDepth(2.1).setAngle(Phaser.Math.Between(-30, 30));
                    }
                } else {
                    // Grassy — clean road
                    // Center line
                    for (let x = 30; x < seg.width - 30; x += 50) {
                        this.add.rectangle(seg.x - seg.width/2 + x, seg.y, 25, 4, lineColor).setDepth(2);
                    }
                    // Edge lines
                    this.add.rectangle(seg.x, seg.y - seg.height/2 + 2, seg.width, 4, edgeColor).setDepth(2);
                    this.add.rectangle(seg.x, seg.y + seg.height/2 - 2, seg.width, 4, edgeColor).setDepth(2);
                    // Sidewalks
                    this.add.rectangle(seg.x, seg.y - seg.height/2 - 14, seg.width, 24, sidewalkColor).setDepth(2);
                    this.add.rectangle(seg.x, seg.y + seg.height/2 + 14, seg.width, 24, sidewalkColor).setDepth(2);
                    // Grass tufts along sidewalk edges
                    const grassColor = this.tintColor(0x3a5a3a, this.lighting.ambient, this.lighting.intensity);
                    for (let i = 0; i < 8; i++) {
                        const gx = seg.x + Phaser.Math.Between(-seg.width/3, seg.width/3);
                        const topOrBot = Math.random() < 0.5 ? seg.y - seg.height/2 - 28 : seg.y + seg.height/2 + 28;
                        this.add.rectangle(gx, topOrBot, Phaser.Math.Between(3, 7), Phaser.Math.Between(4, 8), grassColor, 0.35).setDepth(2.1);
                    }
                }
            }
        }
    }
    
    createProp(prop) {
        const x = prop.x;
        const y = prop.y;
        
        // Searchable prop loot config
        const searchableLoot = {
            mailbox: { chance: 0.50, loot: ['Scrap', 'Cloth', 'Wire'], icon: '📬', hitW: 14, hitH: 18 },
            trash_can: { chance: 0.55, loot: ['Scrap', 'Cloth'], icon: '🗑', hitW: 14, hitH: 14 },
            dumpster: { chance: 0.70, loot: ['Scrap', 'Wire', 'Cloth', 'Meds'], icon: '🗑', hitW: 40, hitH: 20 },
            oil_barrel: { chance: 0.45, loot: ['Scrap', 'Wire'], icon: '🛢', hitW: 18, hitH: 18 },
            crate_stack: { chance: 0.65, loot: ['Scrap', 'Wire', 'Parts'], icon: '📦', hitW: 24, hitH: 20 },
            shipping_container: { chance: 0.75, loot: ['Scrap', 'Parts', 'Wire', 'Meds'], icon: '📦', hitW: 50, hitH: 24 },
            newspaper_box: { chance: 0.35, loot: ['Scrap', 'Cloth'], icon: '📰', hitW: 14, hitH: 16 },
            shopping_cart: { chance: 0.60, loot: ['Scrap', 'Cloth', 'Meds'], icon: '🛒', hitW: 20, hitH: 18 },
            bench: { chance: 0.25, loot: ['Cloth', 'Scrap'], icon: '🪑', hitW: 32, hitH: 14 },
            barrier: { chance: 0.15, loot: ['Scrap'], icon: '🚧', hitW: 44, hitH: 12 },
            car_wreck: { chance: 0.55, loot: ['Scrap', 'Parts', 'Wire'], icon: '🚗', hitW: 56, hitH: 30 },
            truck_wreck: { chance: 0.50, loot: ['Scrap', 'Parts', 'Wire'], icon: '🚛', hitW: 76, hitH: 30 },
            fire_hydrant: { chance: 0.10, loot: ['Scrap'], icon: '🔧', hitW: 10, hitH: 14 },
            cephalon_shrine: { chance: 0.80, loot: ['Scrap', 'Parts', 'Wire'], icon: '📦', hitW: 22, hitH: 14 },
            cube_node: { chance: 0.40, loot: ['Parts', 'Wire'], icon: '📦', hitW: 12, hitH: 12 },
            abandoned_tent: { chance: 0.60, loot: ['Cloth', 'Scrap', 'Meds'], icon: '📦', hitW: 18, hitH: 10 },
            dried_wellhead: { chance: 0.30, loot: ['Scrap', 'Parts'], icon: '🔧', hitW: 10, hitH: 12 },
            collapsed_billboard: { chance: 0.25, loot: ['Scrap'], icon: '🚧', hitW: 30, hitH: 10 },
            collapsed_fence: { chance: 0.20, loot: ['Scrap', 'Cloth'], icon: '🚧', hitW: 26, hitH: 10 },
            rusted_swing_set: { chance: 0.15, loot: ['Scrap'], icon: '🔧', hitW: 22, hitH: 10 },
            ivy_wall: { chance: 0.30, loot: ['Cloth', 'Scrap', 'Meds'], icon: '📦', hitW: 22, hitH: 14 },
            doghouse: { chance: 0.35, loot: ['Cloth', 'Scrap'], icon: '📦', hitW: 12, hitH: 10 },
            gutted_fridge: { chance: 0.55, loot: ['Scrap', 'Meds', 'Parts'], icon: '📦', hitW: 12, hitH: 16 },
            tire_stack: { chance: 0.20, loot: ['Scrap'], icon: '🔧', hitW: 12, hitH: 12 },
            cracked_cistern: { chance: 0.35, loot: ['Scrap', 'Parts'], icon: '🔧', hitW: 14, hitH: 10 },
            dust_generator: { chance: 0.45, loot: ['Parts', 'Wire', 'Scrap'], icon: '🔧', hitW: 12, hitH: 10 },
            tipped_portapotty: { chance: 0.30, loot: ['Cloth', 'Scrap'], icon: '📦', hitW: 10, hitH: 12 },
            concrete_barrier_wl: { chance: 0.10, loot: ['Scrap'], icon: '🚧', hitW: 18, hitH: 8 },
            shattered_cube: { chance: 0.50, loot: ['Parts', 'Wire'], icon: '📦', hitW: 16, hitH: 10 },
            converted_dumpster: { chance: 0.60, loot: ['Scrap', 'Wire', 'Parts'], icon: '📦', hitW: 14, hitH: 10 }
        };
        
        // Dispatch to PropRenderer
        const propMap = {
            car_wreck: 'createCarWreck', truck_wreck: 'createTruckWreck',
            dumpster: 'createDumpster', oil_barrel: 'createOilBarrel',
            crate_stack: 'createCrateStack', shipping_container: 'createShippingContainer',
            mailbox: 'createMailbox', trash_can: 'createTrashCan',
            bench: 'createBench', fence_h: 'createFence',
            lamp_post: 'createLampPost', sign_post: 'createSignPost',
            barrier: 'createBarrier', shopping_cart: 'createShoppingCart',
            newspaper_box: 'createNewspaperBox', fire_hydrant: 'createFireHydrant',
            crystal_spire: 'createCrystalSpire', cube_node: 'createCubeNode',
            organ_pillar: 'createOrganPillar', corrupted_lamp: 'createCorruptedLamp',
            fungal_cluster: 'createFungalCluster', cephalon_shrine: 'createCephalonShrine',
            bleached_skeleton: 'createBleachedSkeleton', rock_cairn: 'createRockCairn',
            abandoned_tent: 'createAbandonedTent', dried_wellhead: 'createDriedWellhead',
            barbed_wire: 'createBarbedWire', collapsed_billboard: 'createCollapsedBillboard',
            collapsed_fence: 'createCollapsedFence', rusted_swing_set: 'createRustedSwingSet',
            bird_bath: 'createBirdBath', child_bicycle: 'createChildBicycle',
            clothesline_post: 'createClotheslinePost', ivy_wall: 'createIvyWall',
            doghouse: 'createDoghouse', gutted_fridge: 'createGuttedFridge',
            playground_slide: 'createPlaygroundSlide', lawn_chair: 'createLawnChair',
            tire_stack: 'createTireStack', porch_steps: 'createPorchSteps',
            cracked_cistern: 'createCrackedCistern', dust_generator: 'createDustGenerator',
            tipped_portapotty: 'createTippedPortapotty', exposed_foundation: 'createExposedFoundation',
            buried_road_sign: 'createBuriedRoadSign', concrete_barrier_wl: 'createConcreteBarrierWl',
            metallic_vine: 'createMetallicVine', shattered_cube: 'createShatteredCube',
            bone_arch: 'createBoneArch', spore_tower: 'createSporeTower',
            geometric_crater: 'createGeometricCrater', converted_dumpster: 'createConvertedDumpster'
        };
        const treeMap = { tree: 'leafy', tree_pine: 'pine', dead_tree: 'dead', converted_tree: 'converted' };
        
        // ── Destructible category + HP config ──
        const destructCfg = {
            oil_barrel: { cat: 'explode', hp: 3 }, car_wreck: { cat: 'explode', hp: 5 },
            truck_wreck: { cat: 'explode', hp: 5 }, dust_generator: { cat: 'explode', hp: 3 },
            crate_stack: { cat: 'shatter', hp: 2 }, trash_can: { cat: 'shatter', hp: 2 },
            mailbox: { cat: 'shatter', hp: 2 }, newspaper_box: { cat: 'shatter', hp: 2 },
            shopping_cart: { cat: 'shatter', hp: 2 }, fire_hydrant: { cat: 'shatter', hp: 3 },
            shipping_container: { cat: 'shatter', hp: 3 }, cube_node: { cat: 'shatter', hp: 2 },
            shattered_cube: { cat: 'shatter', hp: 2 }, converted_dumpster: { cat: 'shatter', hp: 3 },
            gutted_fridge: { cat: 'shatter', hp: 2 }, cracked_cistern: { cat: 'shatter', hp: 2 },
            tipped_portapotty: { cat: 'shatter', hp: 2 },
            lamp_post: { cat: 'topple', hp: 3 }, sign_post: { cat: 'topple', hp: 2 },
            fence_h: { cat: 'topple', hp: 2 }, barrier: { cat: 'topple', hp: 4 },
            barbed_wire: { cat: 'topple', hp: 2 }, clothesline_post: { cat: 'topple', hp: 2 },
            collapsed_billboard: { cat: 'topple', hp: 3 }, buried_road_sign: { cat: 'topple', hp: 2 },
            concrete_barrier_wl: { cat: 'topple', hp: 4 },
            tree: { cat: 'splinter', hp: 5 }, tree_pine: { cat: 'splinter', hp: 5 },
            dead_tree: { cat: 'splinter', hp: 4 }, converted_tree: { cat: 'splinter', hp: 4 },
            collapsed_fence: { cat: 'splinter', hp: 3 }, rusted_swing_set: { cat: 'splinter', hp: 3 },
            porch_steps: { cat: 'splinter', hp: 3 }, playground_slide: { cat: 'splinter', hp: 3 },
            dumpster: { cat: 'collapse', hp: 4 }, bench: { cat: 'collapse', hp: 2 },
            abandoned_tent: { cat: 'collapse', hp: 2 }, dried_wellhead: { cat: 'collapse', hp: 3 },
            ivy_wall: { cat: 'collapse', hp: 3 }, doghouse: { cat: 'collapse', hp: 2 },
            tire_stack: { cat: 'collapse', hp: 2 }, exposed_foundation: { cat: 'collapse', hp: 3 },
            crystal_spire: { cat: 'collapse', hp: 3 }, organ_pillar: { cat: 'collapse', hp: 3 },
            corrupted_lamp: { cat: 'collapse', hp: 2 }, fungal_cluster: { cat: 'collapse', hp: 2 },
            cephalon_shrine: { cat: 'collapse', hp: 3 }, bone_arch: { cat: 'collapse', hp: 3 },
            spore_tower: { cat: 'collapse', hp: 3 }, geometric_crater: { cat: 'collapse', hp: 2 },
            metallic_vine: { cat: 'collapse', hp: 2 }, rock_cairn: { cat: 'collapse', hp: 3 },
            bleached_skeleton: { cat: 'collapse', hp: 2 }, bird_bath: { cat: 'collapse', hp: 2 },
            child_bicycle: { cat: 'collapse', hp: 2 }, lawn_chair: { cat: 'collapse', hp: 2 }
        };
        
        const isDestructible = propMap[prop.type] || treeMap[prop.type];
        const dCfg = destructCfg[prop.type];
        
        // ── Visual capture: intercept scene.add calls to track created objects ──
        const capturedVisuals = [];
        if (isDestructible && dCfg) {
            this._capturingProp = true;
            this._lastPropWall = null;
            this._lastPropWallRect = null;
            this._capturedPropWalls = [];
            
            const origRect = this.add.rectangle.bind(this.add);
            const origEllipse = this.add.ellipse.bind(this.add);
            const origCircle = this.add.circle.bind(this.add);
            const origSprite = this.add.sprite.bind(this.add);
            const self = this;
            
            this.add.rectangle = (...args) => { const o = origRect(...args); if (!self._addingPropWall) capturedVisuals.push(o); return o; };
            this.add.ellipse = (...args) => { const o = origEllipse(...args); capturedVisuals.push(o); return o; };
            this.add.circle = (...args) => { const o = origCircle(...args); capturedVisuals.push(o); return o; };
            this.add.sprite = (...args) => { const o = origSprite(...args); capturedVisuals.push(o); return o; };
            
            try {
                // Call PropRenderer
                if (propMap[prop.type]) {
                    PropRenderer[propMap[prop.type]](this, x, y);
                } else if (treeMap[prop.type]) {
                    PropRenderer.createTree(this, x, y, treeMap[prop.type]);
                }
            } finally {
                // ALWAYS restore originals — even if PropRenderer throws
                this.add.rectangle = origRect;
                this.add.ellipse = origEllipse;
                this.add.circle = origCircle;
                this.add.sprite = origSprite;
                this._capturingProp = false;
            }
            
            // Register destructible
            const wallBody = this._lastPropWall;
            const wallRect = this._lastPropWallRect;
            if (wallBody) {
                const entry = {
                    x, y, type: prop.type,
                    hp: dCfg.hp, maxHp: dCfg.hp,
                    category: dCfg.cat,
                    visuals: capturedVisuals,
                    wallBody, wallRect,
                    allPropWalls: this._capturedPropWalls || [],
                    searchHitbox: null
                };
                // Register primary wall
                this.destructibles.set(wallBody, entry);
                // Also register any secondary walls (multi-wall props) pointing to same entry
                if (this._capturedPropWalls) {
                    this._capturedPropWalls.forEach(pw => {
                        if (pw.wall && pw.wall !== wallBody) {
                            this.destructibles.set(pw.wall, entry);
                        }
                    });
                }
            }
            this._capturedPropWalls = null;
        } else {
            // Non-destructible prop — render normally
            if (propMap[prop.type]) {
                PropRenderer[propMap[prop.type]](this, x, y);
            } else if (treeMap[prop.type]) {
                PropRenderer.createTree(this, x, y, treeMap[prop.type]);
            }
        }
        
        // Attach searchable loot hitbox
        const cfg = searchableLoot[prop.type];
        const searchMult = this.biome?.searchableMult || 1.0;
        if (cfg && Math.random() < cfg.chance * searchMult) {
            const lootPool = cfg.loot;
            const itemCount = 1 + Math.floor(Math.random() * 2);
            const items = [];
            for (let i = 0; i < itemCount; i++) {
                items.push(lootPool[Math.floor(Math.random() * lootPool.length)]);
            }
            const hitbox = this.add.rectangle(x, y, cfg.hitW, cfg.hitH, 0x000000, 0).setDepth(15);
            hitbox.searchItems = items;
            hitbox.searched = false;
            hitbox.propType = prop.type;
            hitbox.propIcon = cfg.icon;
            this.searchableProps.push(hitbox);
            
            // Link to destructible if exists
            if (dCfg && this._lastPropWall && this.destructibles.has(this._lastPropWall)) {
                this.destructibles.get(this._lastPropWall).searchHitbox = hitbox;
            }
        }
    }
    
    tintColor(baseColor, tintColor, intensity) {
        const base = Phaser.Display.Color.ValueToColor(baseColor);
        const tint = Phaser.Display.Color.ValueToColor(tintColor);
        const r = Math.floor(base.red * intensity * (tint.red / 255 + intensity) / (1 + intensity));
        const g = Math.floor(base.green * intensity * (tint.green / 255 + intensity) / (1 + intensity));
        const b = Math.floor(base.blue * intensity * (tint.blue / 255 + intensity) / (1 + intensity));
        return Phaser.Display.Color.GetColor(Phaser.Math.Clamp(r, 0, 255), Phaser.Math.Clamp(g, 0, 255), Phaser.Math.Clamp(b, 0, 255));
    }
    
    // ── DESTRUCTIBLE PROPS — bullet damage + destruction effects ──
    _bulletHitProp(bullet, wall) {
        if (!bullet.active) return;
        if (!this.destructibles || !this.destructibles.has(wall)) {
            // Not a tracked destructible — treat like a regular wall
            this.spark(bullet.x, bullet.y, bullet.rotation, bullet.fx);
            bullet.destroy();
            return;
        }
        const entry = this.destructibles.get(wall);
        entry.hp -= 1;
        
        // Hit spark
        this.spark(bullet.x, bullet.y, bullet.rotation, bullet.fx);
        
        // Visual hit flash — briefly tint all visuals
        entry.visuals.forEach(v => {
            if (v && v.active) {
                v.setAlpha(Math.max(0.3, (v.alpha || 1) * 0.6));
                this.time.delayedCall(80, () => { if (v.active) v.setAlpha(v._origAlpha || 1); });
                if (!v._origAlpha) v._origAlpha = v.alpha;
            }
        });
        
        bullet.destroy();
        
        if (entry.hp <= 0) {
            this._destroyProp(entry);
        }
    }
    
    _destroyProp(entry) {
        if (entry._destroyed) return; // prevent double-destroy from chain detonation
        entry._destroyed = true;
        const { x, y, category, visuals, wallBody, wallRect, searchHitbox, allPropWalls } = entry;
        
        // Remove primary wall body from propWalls
        if (wallBody && wallBody.active !== false) {
            this.propWalls.remove(wallBody, true, true);
        }
        
        // Remove ALL propWalls created for this prop (multi-wall props like trucks)
        if (allPropWalls && allPropWalls.length > 0) {
            allPropWalls.forEach(pw => {
                if (pw.wall && pw.wall !== wallBody && pw.wall.active !== false) {
                    this.propWalls.remove(pw.wall, true, true);
                }
                if (pw.rect) {
                    const ri = this.wallRects.indexOf(pw.rect);
                    if (ri >= 0) this.wallRects.splice(ri, 1);
                }
            });
        }
        
        // Remove primary wallRect from wallRects (line-of-sight)
        if (wallRect) {
            const idx = this.wallRects.indexOf(wallRect);
            if (idx >= 0) this.wallRects.splice(idx, 1);
        }
        
        // Remove from destructibles map (primary + all secondary keys)
        this.destructibles.delete(wallBody);
        if (allPropWalls && allPropWalls.length > 0) {
            allPropWalls.forEach(pw => {
                if (pw.wall) this.destructibles.delete(pw.wall);
            });
        }
        
        // Drop loot
        this._dropPropLoot(entry);
        
        // Remove searchable hitbox
        if (searchHitbox && this.searchableProps) {
            const si = this.searchableProps.indexOf(searchHitbox);
            if (si >= 0) this.searchableProps.splice(si, 1);
            if (searchHitbox.active !== false) searchHitbox.destroy();
        }
        
        // ── Per-category destruction effects ──
        if (category === 'explode') {
            // Fireball particles
            for (let i = 0; i < 10; i++) {
                const col = Math.random() < 0.5 ? 0xff8833 : 0xffcc44;
                const p = this.add.rectangle(x + Phaser.Math.Between(-8, 8), y + Phaser.Math.Between(-8, 8),
                    Phaser.Math.Between(3, 7), Phaser.Math.Between(3, 7), col, 0.9).setDepth(50);
                this.tweens.add({
                    targets: p,
                    x: p.x + Phaser.Math.Between(-40, 40), y: p.y + Phaser.Math.Between(-40, 40),
                    alpha: 0, duration: 400, onComplete: () => p.destroy()
                });
            }
            // Flash
            const flash = this.add.circle(x, y, 30, 0xffaa44, 0.6).setDepth(51);
            this.tweens.add({ targets: flash, alpha: 0, scaleX: 2, scaleY: 2, duration: 200, onComplete: () => flash.destroy() });
            
            // Damage nearby enemies
            this.enemies.getChildren().forEach(e => {
                if (!e.active || e._dying) return;
                if (Phaser.Math.Distance.Between(x, y, e.x, e.y) < 60) {
                    e.hp -= 15;
                    if (e.hp <= 0) { e.hp = 0; EnemyManager.killEnemy(this, e); }
                }
            });
            // Damage player
            if (this.player && !this.state.dead && Phaser.Math.Distance.Between(x, y, this.player.x, this.player.y) < 40) {
                this.state.health -= 10;
                if (this.state.health <= 0) { this.state.health = 0; this.playerDeath(); }
            }
            
            // Chain detonation
            this.destructibles.forEach((other) => {
                if (other.category === 'explode' && other.hp > 0) {
                    if (Phaser.Math.Distance.Between(x, y, other.x, other.y) < 80) {
                        this.time.delayedCall(150, () => {
                            if (other.hp > 0) { other.hp = 0; this._destroyProp(other); }
                        });
                    }
                }
            });
            
            try { AudioManager.hit(); } catch(e) {}
            this.cameras.main.shake(80, 0.008);
            
            // Destroy visuals
            visuals.forEach(v => { if (v && v.active !== false) v.destroy(); });
            
        } else if (category === 'shatter') {
            // Debris scatter
            const baseCol = 0x666666;
            for (let i = 0; i < 8; i++) {
                const p = this.add.rectangle(x, y, Phaser.Math.Between(2, 5), Phaser.Math.Between(2, 4),
                    Phaser.Math.Between(0, 1) ? baseCol : 0x888888, 0.8).setDepth(50);
                this.tweens.add({
                    targets: p,
                    x: x + Phaser.Math.Between(-30, 30), y: y + Phaser.Math.Between(-25, 25),
                    alpha: 0, angle: Phaser.Math.Between(-180, 180),
                    duration: 300, onComplete: () => p.destroy()
                });
            }
            // Dust puff
            for (let i = 0; i < 3; i++) {
                const d = this.add.circle(x + Phaser.Math.Between(-5, 5), y + Phaser.Math.Between(-3, 3),
                    Phaser.Math.Between(4, 8), 0x999999, 0.3).setDepth(49);
                this.tweens.add({ targets: d, scaleX: 2.5, scaleY: 2.5, alpha: 0, duration: 400, onComplete: () => d.destroy() });
            }
            try { AudioManager.lootCrate(); } catch(e) {}
            this.cameras.main.shake(50, 0.003);
            visuals.forEach(v => { if (v && v.active !== false) v.destroy(); });
            
        } else if (category === 'topple') {
            // Don't destroy visuals — tween them flat
            const dir = (this.player ? (this.player.x > x ? 1 : -1) : 1);
            visuals.forEach(v => {
                if (v && v.active !== false) {
                    this.tweens.add({
                        targets: v,
                        angle: dir * 90, alpha: 0.5,
                        x: v.x + dir * 8, y: v.y + 4,
                        duration: 300, ease: 'Bounce.easeOut',
                        onComplete: () => { v.setDepth(1); }
                    });
                }
            });
            try { AudioManager.doorOpen(); } catch(e) {}
            this.cameras.main.shake(50, 0.003);
            
        } else if (category === 'splinter') {
            // Wood/leaf debris
            for (let i = 0; i < 10; i++) {
                const isLeaf = Math.random() < 0.4;
                const col = isLeaf ? 0x447733 : 0x6a5033;
                const p = this.add.rectangle(x + Phaser.Math.Between(-6, 6), y + Phaser.Math.Between(-10, 0),
                    Phaser.Math.Between(2, isLeaf ? 4 : 6), Phaser.Math.Between(2, 4), col, 0.8).setDepth(50);
                this.tweens.add({
                    targets: p,
                    x: p.x + Phaser.Math.Between(-35, 35),
                    y: p.y + Phaser.Math.Between(10, 40) + (isLeaf ? 20 : 0),
                    alpha: 0, angle: Phaser.Math.Between(-180, 180),
                    duration: isLeaf ? 600 : 350, onComplete: () => p.destroy()
                });
            }
            // Stump remains
            this.add.rectangle(x, y + 5, 6, 4, 0x3a2a1a, 0.6).setDepth(1);
            try { AudioManager.melee(); } catch(e) {}
            this.cameras.main.shake(50, 0.003);
            visuals.forEach(v => { if (v && v.active !== false) v.destroy(); });
            
        } else if (category === 'collapse') {
            // Debris falls inward
            for (let i = 0; i < 7; i++) {
                const ox = Phaser.Math.Between(-15, 15);
                const oy = Phaser.Math.Between(-12, 12);
                const p = this.add.rectangle(x + ox * 2, y + oy * 2,
                    Phaser.Math.Between(3, 7), Phaser.Math.Between(3, 6), 0x555555, 0.7).setDepth(50);
                this.tweens.add({
                    targets: p,
                    x: x + ox * 0.3, y: y + oy * 0.3 + 3,
                    alpha: 0.3, duration: 350, onComplete: () => { p.setDepth(1); }
                });
            }
            // Dust cloud
            for (let i = 0; i < 4; i++) {
                const d = this.add.ellipse(x + Phaser.Math.Between(-4, 4), y + Phaser.Math.Between(-3, 3),
                    Phaser.Math.Between(6, 12), Phaser.Math.Between(4, 8), 0x999999, 0.25).setDepth(49);
                this.tweens.add({
                    targets: d,
                    scaleX: 3, scaleY: 2.5, alpha: 0,
                    x: d.x + Phaser.Math.Between(-15, 15), y: d.y + Phaser.Math.Between(-10, 10),
                    duration: 500, onComplete: () => d.destroy()
                });
            }
            // Rubble pile
            for (let i = 0; i < 3; i++) {
                this.add.rectangle(x + Phaser.Math.Between(-8, 8), y + Phaser.Math.Between(-4, 4),
                    Phaser.Math.Between(4, 8), Phaser.Math.Between(3, 5), 0x444444, 0.4).setDepth(1);
            }
            try { AudioManager.hit(); } catch(e) {}
            this.cameras.main.shake(50, 0.003);
            visuals.forEach(v => { if (v && v.active !== false) v.destroy(); });
        }
    }
    
    _dropPropLoot(entry) {
        const { x, y, searchHitbox } = entry;
        
        if (searchHitbox && searchHitbox.searchItems && !searchHitbox.searched) {
            // Drop the pre-rolled search items as physical loot
            searchHitbox.searchItems.forEach(itemName => {
                const ox = Phaser.Math.Between(-20, 20);
                const oy = Phaser.Math.Between(-15, 15);
                const matColors = { Scrap: 0x888888, Cloth: 0xaa8866, Wire: 0x66aa66, Parts: 0x6688aa, Meds: 0xcc4444 };
                const col = matColors[itemName] || 0xaaaaaa;
                
                const drop = this.add.rectangle(x + ox, y + oy, 6, 6, col, 0.9).setDepth(15);
                this.physics.add.existing(drop, true);
                drop._matName = itemName;
                drop._matDrop = true;
                
                // Auto-pickup on player overlap
                this.physics.add.overlap(this.player, drop, () => {
                    if (!drop.active) return;
                    this.state.materials = this.state.materials || {};
                    this.state.materials[itemName] = (this.state.materials[itemName] || 0) + 1;
                    Blurbs.show(this, this.player, `+1 ${itemName}`, { color: '#cccccc', fontSize: 9, duration: 600 });
                    try { AudioManager.pickup(); } catch(e) {}
                    drop.destroy();
                });
                
                // Scatter animation
                this.tweens.add({
                    targets: drop,
                    x: drop.x + Phaser.Math.Between(-8, 8), y: drop.y + Phaser.Math.Between(-6, 6),
                    duration: 200, ease: 'Quad.easeOut'
                });
            });
        } else if (!searchHitbox && Math.random() < 0.15) {
            // No search hitbox — 15% chance of bonus scrap
            const drop = this.add.rectangle(x + Phaser.Math.Between(-10, 10), y + Phaser.Math.Between(-8, 8),
                5, 5, 0x888888, 0.8).setDepth(15);
            this.physics.add.existing(drop, true);
            drop._matName = 'Scrap';
            drop._matDrop = true;
            this.physics.add.overlap(this.player, drop, () => {
                if (!drop.active) return;
                this.state.materials = this.state.materials || {};
                this.state.materials.Scrap = (this.state.materials.Scrap || 0) + 1;
                Blurbs.show(this, this.player, '+1 Scrap', { color: '#999999', fontSize: 9, duration: 600 });
                try { AudioManager.pickup(); } catch(e) {}
                drop.destroy();
            });
        }
    }
    
    createShellBuilding(shell) {
        const { x, y, w, h, wallColor, floorColor, style, missingWalls, interiorProps, name } = shell;
        const biomeType = CONFIG.currentBiome?.type || 'grassy';
        const d = 10 + y * 0.01;
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        
        const wallDk = IsoRenderer.darken(wallColor, 0.15);
        const wallLt = IsoRenderer.lighten(wallColor, 0.1);
        const wallEdge = IsoRenderer.darken(wallColor, 0.25);
        const wallH = 20; // front face height
        const topH = 4;   // foreshortened top strip
        const sideW = 6;  // side wall thickness
        
        // === FLOOR — visible ground inside the ruin ===
        this.add.rectangle(x, y, w - sideW * 2, h - wallH, tc(floorColor), 0.5).setDepth(1.5);
        
        // Floor details per biome
        if (biomeType === 'barren') {
            // Sand drift across floor
            this.add.ellipse(x + Phaser.Math.Between(-w/4, w/4), y + h/4, w * 0.5, 12, tc(0x4a4235), 0.15).setDepth(1.6);
            // Cracks
            for (let c = 0; c < 3; c++) {
                this.add.rectangle(x + Phaser.Math.Between(-w/3, w/3), y + Phaser.Math.Between(-h/4, h/4),
                    Phaser.Math.Between(8, 20), 1, tc(0x1a1a15), 0.12).setAngle(Phaser.Math.Between(-30, 30)).setDepth(1.6);
            }
        } else if (biomeType === 'apocalyptic') {
            // Cube vein on floor
            this.add.rectangle(x, y, Phaser.Math.Between(12, 25), 1, tc(0x4a6a7a), 0.1).setAngle(60).setDepth(1.6);
            this.add.rectangle(x + 5, y + 3, Phaser.Math.Between(8, 16), 1, tc(0x4a6a7a), 0.08).setAngle(0).setDepth(1.6);
            // Dark corruption patch
            this.add.ellipse(x, y, 14, 10, tc(0x0a0810), 0.1).setDepth(1.55);
        } else {
            // Overgrown — moss on floor
            this.add.ellipse(x - w/4, y, 16, 10, tc(0x2a4a1a), 0.1).setDepth(1.6);
            this.add.ellipse(x + w/5, y + h/6, 12, 8, tc(0x2a4a1a), 0.08).setDepth(1.6);
        }
        
        // === NORTH WALL (back wall — always present) ===
        const nWallY = y - h/2;
        // Front face
        this.add.rectangle(x, nWallY + wallH/2 + topH, w, wallH, tc(wallColor)).setDepth(d - 0.5);
        // Top strip
        this.add.rectangle(x, nWallY + topH/2, w, topH, tc(wallLt)).setDepth(d - 0.49);
        // Horizontal mortar/damage lines
        this.add.rectangle(x, nWallY + topH + wallH * 0.3, w, 1, tc(wallDk), 0.3).setDepth(d - 0.48);
        this.add.rectangle(x, nWallY + topH + wallH * 0.7, w, 1, tc(wallDk), 0.2).setDepth(d - 0.48);
        // Ragged top edge — missing chunks
        const chunkW = Phaser.Math.Between(8, 16);
        const chunkX = x + Phaser.Math.Between(-w/3, w/3);
        this.add.rectangle(chunkX, nWallY + 2, chunkW, topH + 4, tc(floorColor), 0.5).setDepth(d - 0.47);
        // Collision
        this.addWall(x, nWallY + wallH/2, w, wallH + topH, wallColor, false);
        
        // === WEST WALL (left) ===
        if (!missingWalls.includes('west')) {
            const wX = x - w/2 + sideW/2;
            this.add.rectangle(wX, y, sideW, h, tc(wallDk)).setDepth(d + 0.1);
            // Front sliver
            this.add.rectangle(wX + sideW/2 + 1, y, 2, h, tc(wallColor), 0.4).setDepth(d + 0.11);
            this.addWall(wX, y, sideW, h, wallColor, false);
        }
        
        // === EAST WALL (right) ===
        if (!missingWalls.includes('east')) {
            const eX = x + w/2 - sideW/2;
            this.add.rectangle(eX, y, sideW, h, tc(wallDk)).setDepth(d + 0.1);
            this.add.rectangle(eX - sideW/2 - 1, y, 2, h, tc(wallColor), 0.4).setDepth(d + 0.11);
            this.addWall(eX, y, sideW, h, wallColor, false);
        }
        
        // === SOUTH WALL — visual removed for ¾ camera, invisible collision kept ===
        if (!missingWalls.includes('south')) {
            const gapW = w * 0.4;
            const segW = (w - gapW) / 2;
            const sWallY = y + h/2;
            // Invisible collision only — no visual wall
            this.addWall(x - w/2 + segW/2, sWallY - wallH/2, segW, wallH + topH, wallColor, false);
            this.addWall(x + w/2 - segW/2, sWallY - wallH/2, segW, wallH + topH, wallColor, false);
        } else {
            // South wall completely missing — rubble line
            const rubbleY = y + h/2;
            for (let r = 0; r < 5; r++) {
                const rx = x + Phaser.Math.Between(-w/2 + 5, w/2 - 5);
                this.add.rectangle(rx, rubbleY, Phaser.Math.Between(4, 10), Phaser.Math.Between(3, 6),
                    tc(wallDk), 0.3).setAngle(Phaser.Math.Between(-30, 30)).setDepth(d + 0.05);
            }
        }
        
        // === BIOME-SPECIFIC WALL DECORATION ===
        if (biomeType === 'barren') {
            // Peeling plaster on north wall
            this.add.rectangle(x + Phaser.Math.Between(-w/4, w/4), nWallY + topH + 6,
                Phaser.Math.Between(8, 16), Phaser.Math.Between(4, 10), tc(0x2a2520), 0.12).setDepth(d - 0.46);
        } else if (biomeType === 'apocalyptic') {
            // Cube growth on north wall
            const cgx = x + Phaser.Math.Between(-w/4, w/4);
            this.add.rectangle(cgx, nWallY + topH + 8, 10, 8, tc(0x1a1020), 0.2).setDepth(d - 0.46);
            this.add.rectangle(cgx, nWallY + topH + 4, 10, 1, tc(0x4a6a7a), 0.1).setDepth(d - 0.45);
        } else {
            // Vines on north wall
            for (let v = 0; v < 2; v++) {
                const vx = x + Phaser.Math.Between(-w/3, w/3);
                this.add.rectangle(vx, nWallY + topH + Phaser.Math.Between(2, wallH), 1, Phaser.Math.Between(6, 14),
                    tc(0x2a5a1a), 0.2).setDepth(d - 0.46);
            }
        }
        
        // === SHADOW ===
        this.add.ellipse(x, y + h/2 + 4, w + 10, 8, 0x000000, 0.1).setDepth(0.5);
        
        // === NAME LABEL (subtle, like building names) ===
        // Not added — these are anonymous ruins
        
        // === INTERIOR SEARCHABLE PROPS ===
        if (interiorProps && interiorProps.length > 0) {
            for (const ip of interiorProps) {
                // Small crate/container visual
                const pd = 10 + ip.y * 0.01;
                this.add.rectangle(ip.x, ip.y, 8, 6, tc(0x4a4a3a), 0.5).setDepth(pd + 0.01);
                this.add.rectangle(ip.x, ip.y - 3, 8, 2, tc(0x5a5a4a), 0.3).setDepth(pd + 0.02);
                
                // Searchable hitbox
                const hitbox = this.add.rectangle(ip.x, ip.y, 14, 12, 0x000000, 0).setDepth(15);
                hitbox.searchItems = [...ip.loot];
                hitbox.searched = false;
                hitbox.propType = 'shell_crate';
                hitbox.propIcon = 'LOOT';
                if (!this.searchableProps) this.searchableProps = [];
                this.searchableProps.push(hitbox);
            }
        }
    }
    
    // ════════════════════════════════════════
    // ENVIRONMENTAL STORYTELLING SCENES
    // Multi-prop compositions — ¾ isometric, camera south
    // ════════════════════════════════════════
    createStoryScene(scene) {
        const renderers = {
            // Overgrown
            lastBarbecue: '_renderScene_lastBarbecue',
            memorialWall: '_renderScene_memorialWall',
            theQueue: '_renderScene_theQueue',
            gardenOvergrown: '_renderScene_gardenOvergrown',
            // Wasteland
            thePyre: '_renderScene_thePyre',
            waterWasHere: '_renderScene_waterWasHere',
            theDig: '_renderScene_theDig',
            lastGasStation: '_renderScene_lastGasStation',
            // Anomalous
            fallenPatrol: '_renderScene_fallenPatrol',
            cephalonCamp: '_renderScene_cephalonCamp',
            theOffering: '_renderScene_theOffering',
            barricadeInward: '_renderScene_barricadeInward'
        };
        const method = renderers[scene.id];
        if (method && this[method]) {
            this[method](scene.x, scene.y, scene.w, scene.h);
        }
    }
    
    // --- OVERGROWN: The Last Barbecue ---
    // Grill, two lawn chairs, table with bottles, tipped cooler. Knee-high grass. Interrupted moment.
    _renderScene_lastBarbecue(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // Ground: taller grass circle around the scene
        g.fillStyle(tc(0x3a5a2a), 0.3);
        g.fillEllipse(cx, cy, w + 10, h + 6);
        
        // === Charcoal grill (north-center) — front face wide, lid open ===
        // ¾ view: we see the front bowl face (10w × 6h) + thin top rim + lid angled back
        const gx = cx - 2, gy = cy - 12;
        // Legs (4 thin lines)
        g.lineStyle(1, tc(0x2a2a2a), 0.8);
        g.lineBetween(gx - 4, gy + 3, gx - 5, gy + 9);
        g.lineBetween(gx + 4, gy + 3, gx + 5, gy + 9);
        // Bowl — front face
        g.fillStyle(tc(0x1a1a1a), 1);
        g.fillRoundedRect(gx - 5, gy - 2, 10, 6, 1);
        // Ash inside (top strip visible)
        g.fillStyle(tc(0x4a4a4a), 0.6);
        g.fillRect(gx - 4, gy - 3, 8, 2);
        // Lid — angled back (north), thin arc behind grill
        g.lineStyle(1, tc(0x222222), 0.7);
        g.beginPath(); g.arc(gx, gy - 5, 6, Math.PI * 1.1, Math.PI * 1.9); g.strokePath();
        
        // === Two lawn chairs (east and west of grill, facing each other) ===
        // West chair — ¾ side view: seat is 8w × 4h, back rises 6h
        const lc1x = cx - 18, lc1y = cy - 4;
        g.fillStyle(tc(0x2a6a2a), 0.8);
        g.fillRect(lc1x, lc1y, 8, 4); // seat
        g.fillRect(lc1x + 6, lc1y - 6, 2, 6); // back (east side, facing grill)
        // Legs
        g.lineStyle(1, tc(0x555555), 0.6);
        g.lineBetween(lc1x, lc1y + 4, lc1x - 1, lc1y + 7);
        g.lineBetween(lc1x + 7, lc1y + 4, lc1x + 8, lc1y + 7);
        
        // East chair — mirror
        const lc2x = cx + 10, lc2y = cy - 4;
        g.fillStyle(tc(0x2a6a2a), 0.8);
        g.fillRect(lc2x, lc2y, 8, 4);
        g.fillRect(lc2x, lc2y - 6, 2, 6); // back (west side, facing grill)
        g.lineStyle(1, tc(0x555555), 0.6);
        g.lineBetween(lc2x, lc2y + 4, lc2x - 1, lc2y + 7);
        g.lineBetween(lc2x + 7, lc2y + 4, lc2x + 8, lc2y + 7);
        
        // === Folding table (south of grill) with 3 beer bottles ===
        const tx = cx, ty = cy + 4;
        // Table top — ¾ view: 14w × 4h surface, thin legs
        g.fillStyle(tc(0x5a5a52), 0.8);
        g.fillRect(tx - 7, ty, 14, 3);
        g.lineStyle(1, tc(0x444444), 0.5);
        g.lineBetween(tx - 6, ty + 3, tx - 6, ty + 6);
        g.lineBetween(tx + 6, ty + 3, tx + 6, ty + 6);
        // 3 bottles (standing upright — small rectangles 1w × 3h)
        for (let b = -3; b <= 3; b += 3) {
            g.fillStyle(tc(0x2a4a2a), 0.9);
            g.fillRect(tx + b, ty - 3, 2, 3);
            g.fillStyle(tc(0x3a6a3a), 0.5);
            g.fillRect(tx + b, ty - 4, 2, 1); // neck
        }
        
        // === Cooler (tipped on side, west) ===
        const cox = cx - 22, coy = cy + 6;
        g.fillStyle(tc(0x3a5a8a), 0.8);
        g.fillRect(cox, coy, 8, 5); // body on side
        g.fillStyle(tc(0xcccccc), 0.5);
        g.fillRect(cox, coy, 8, 1); // lid edge
        
        // === Paper plate circles (faded, between chairs) ===
        g.fillStyle(tc(0x8a8a7a), 0.15);
        g.fillCircle(cx - 6, cy + 2, 3);
        g.fillCircle(cx + 8, cy + 1, 2);
        
        g.setDepth(depth);
    }
    
    // --- OVERGROWN: The Memorial Wall ---
    // Brick wall section with photos, flowers, candles. Community loss.
    _renderScene_memorialWall(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Brick wall — north-facing, front face dominant (36w × 20h) ===
        const wx = cx, wy = cy - 6;
        // Front face
        g.fillStyle(tc(0x6a4a3a), 1);
        g.fillRect(wx - 18, wy - 8, 36, 20);
        // Top strip (foreshortened)
        g.fillStyle(tc(0x7a5a4a), 0.8);
        g.fillRect(wx - 18, wy - 10, 36, 2);
        // Brick lines
        g.lineStyle(1, tc(0x5a3a2a), 0.3);
        for (let row = 0; row < 4; row++) {
            const ry = wy - 6 + row * 5;
            g.lineBetween(wx - 17, ry, wx + 17, ry);
            // Vertical joints (staggered)
            for (let col = -2; col <= 2; col++) {
                const jx = wx + col * 8 + (row % 2 === 0 ? 0 : 4);
                g.lineBetween(jx, ry, jx, ry + 5);
            }
        }
        
        // === Photographs (faded rectangles on wall) ===
        const photos = [
            { x: wx - 12, y: wy - 4, w: 5, h: 4 },
            { x: wx - 4, y: wy - 6, w: 4, h: 5 },
            { x: wx + 4, y: wy - 3, w: 6, h: 4 },
            { x: wx + 12, y: wy - 5, w: 4, h: 4 }
        ];
        for (const p of photos) {
            g.fillStyle(tc(0x8a8a7a), 0.4);
            g.fillRect(p.x, p.y, p.w, p.h);
            g.lineStyle(1, tc(0x6a6a5a), 0.3);
            g.strokeRect(p.x, p.y, p.w, p.h);
        }
        
        // === Child's drawing (lower on wall — child height) ===
        g.fillStyle(tc(0x8a5a5a), 0.35);
        g.fillRect(wx - 2, wy + 4, 6, 5);
        // Crayon color spots
        g.fillStyle(tc(0xaa3333), 0.3); g.fillCircle(wx, wy + 6, 1);
        g.fillStyle(tc(0x33aa33), 0.3); g.fillCircle(wx + 3, wy + 7, 1);
        
        // === Dried flowers (brown clusters at base) ===
        g.fillStyle(tc(0x5a4a3a), 0.5);
        g.fillEllipse(wx - 10, wy + 13, 6, 3);
        g.fillEllipse(wx + 6, wy + 14, 5, 3);
        // Stems
        g.lineStyle(1, tc(0x4a3a2a), 0.4);
        g.lineBetween(wx - 10, wy + 12, wx - 10, wy + 8);
        g.lineBetween(wx + 6, wy + 12, wx + 7, wy + 8);
        
        // === Candle stubs (tiny, at base) ===
        for (let c = -14; c <= 14; c += 7) {
            g.fillStyle(tc(0xccbb99), 0.6);
            g.fillRect(wx + c, wy + 11, 2, 3);
            // Wax drip
            g.fillStyle(tc(0xaa9977), 0.3);
            g.fillCircle(wx + c + 1, wy + 14, 1);
        }
        
        // === Handwritten notes (white rectangles pinned to wall) ===
        g.fillStyle(tc(0xccccbb), 0.35);
        g.fillRect(wx - 15, wy + 1, 4, 3);
        g.fillRect(wx + 9, wy + 0, 3, 4);
        
        g.setDepth(depth);
    }
    
    // --- OVERGROWN: The Queue ---
    // Shopping carts lined up outside barricaded entrance. Order maintained.
    _renderScene_theQueue(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Barricaded entrance (north side) — planks across doorway ===
        const dx = cx + 20, dy = cy - 10;
        // Door frame — ¾ front face
        g.fillStyle(tc(0x4a4a42), 0.9);
        g.fillRect(dx - 8, dy - 10, 16, 18);
        // Planks (horizontal boards across)
        g.fillStyle(tc(0x6a5a42), 0.8);
        g.fillRect(dx - 10, dy - 6, 20, 2);
        g.fillRect(dx - 9, dy - 1, 18, 2);
        g.fillRect(dx - 10, dy + 4, 20, 2);
        // Wall flanks
        g.fillStyle(tc(0x5a5a52), 0.7);
        g.fillRect(dx - 18, dy - 10, 10, 18);
        g.fillRect(dx + 8, dy - 10, 10, 18);
        
        // === Shopping carts (3, queued heading east toward door) ===
        // ¾ view from south: cart shows front basket face (8w × 6h body), handle extends south
        for (let i = 0; i < 3; i++) {
            const cartX = cx - 20 + i * 14, cartY = cy + 2;
            // Wheels
            g.fillStyle(tc(0x333333), 0.6);
            g.fillCircle(cartX - 3, cartY + 5, 1);
            g.fillCircle(cartX + 3, cartY + 5, 1);
            // Basket body — wire mesh (open top)
            g.lineStyle(1, tc(0x888888), 0.7);
            g.strokeRect(cartX - 4, cartY - 2, 8, 6);
            // Cross wire
            g.lineBetween(cartX - 4, cartY + 1, cartX + 4, cartY + 1);
            // Handle extending south
            g.lineStyle(1, tc(0x666666), 0.6);
            g.lineBetween(cartX - 3, cartY + 4, cartX - 2, cartY + 8);
            g.lineBetween(cartX + 3, cartY + 4, cartX + 2, cartY + 8);
            g.lineBetween(cartX - 2, cartY + 8, cartX + 2, cartY + 8);
            
            // First cart: tarp + pillow inside
            if (i === 0) {
                g.fillStyle(tc(0x5a6a5a), 0.5);
                g.fillRect(cartX - 3, cartY - 1, 6, 3); // tarp fold
                g.fillStyle(tc(0xaaaaaa), 0.4);
                g.fillEllipse(cartX, cartY - 1, 4, 2); // pillow
            }
        }
        
        g.setDepth(depth);
    }
    
    // --- OVERGROWN: The Garden That Kept Going ---
    // Raised bed exploding with growth. Vine thicket. Giant zucchini. Gardening gloves.
    _renderScene_gardenOvergrown(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Raised garden bed — ¾ view: front face (24w × 6h), top soil visible (24w × 4h) ===
        const bx = cx, by = cy;
        // Front face (wooden frame)
        g.fillStyle(tc(0x6a5030), 1);
        g.fillRect(bx - 12, by, 24, 6);
        // Top surface (soil + plant mass)
        g.fillStyle(tc(0x3a2a1a), 0.9);
        g.fillRect(bx - 12, by - 4, 24, 4);
        // Side depth (east edge)
        g.fillStyle(tc(0x5a4025), 0.8);
        g.fillRect(bx + 12, by - 4, 3, 10);
        
        // === Explosive vine growth — shooting up and outward ===
        g.lineStyle(2, tc(0x2a5a1a), 0.8);
        // Main vine up from center
        g.beginPath(); g.moveTo(bx, by - 4); g.lineTo(bx - 3, by - 16); g.lineTo(bx - 8, by - 24); g.strokePath();
        g.beginPath(); g.moveTo(bx + 4, by - 4); g.lineTo(bx + 8, by - 18); g.lineTo(bx + 12, by - 28); g.strokePath();
        // Side vines sprawling
        g.lineStyle(1, tc(0x3a6a2a), 0.6);
        g.beginPath(); g.moveTo(bx - 8, by - 24); g.lineTo(bx - 18, by - 20); g.lineTo(bx - 24, by - 14); g.strokePath();
        g.beginPath(); g.moveTo(bx + 12, by - 28); g.lineTo(bx + 20, by - 22); g.strokePath();
        
        // Leaf clusters on vines
        const leaves = [
            { x: bx - 8, y: by - 24 }, { x: bx - 18, y: by - 20 }, { x: bx + 8, y: by - 18 },
            { x: bx + 12, y: by - 28 }, { x: bx - 3, y: by - 16 }, { x: bx + 20, y: by - 22 }
        ];
        g.fillStyle(tc(0x3a7a2a), 0.7);
        for (const lf of leaves) {
            g.fillEllipse(lf.x, lf.y, 4, 3);
        }
        
        // === Giant zucchini on ground (absurdly large oblong shapes) ===
        g.fillStyle(tc(0x2a5a2a), 0.7);
        g.fillEllipse(bx - 16, by + 8, 10, 4);  // one sprawled west
        g.fillEllipse(bx + 10, by + 10, 8, 3);  // one east
        // Highlight stripe
        g.fillStyle(tc(0x4a8a4a), 0.3);
        g.fillEllipse(bx - 16, by + 7, 8, 1);
        
        // === Gardening gloves (pair, on bed edge) ===
        g.fillStyle(tc(0x8a7a5a), 0.6);
        g.fillRect(bx + 8, by - 1, 3, 4);
        g.fillRect(bx + 5, by - 1, 3, 4);
        
        // === Watering can (rusted, nearby) ===
        g.fillStyle(tc(0x6a4a3a), 0.7);
        g.fillRect(bx + 18, by + 4, 5, 4); // body
        g.lineStyle(1, tc(0x5a3a2a), 0.5);
        g.lineBetween(bx + 23, by + 4, bx + 26, by + 2); // spout
        
        g.setDepth(depth);
    }
    
    // --- WASTELAND: The Pyre ---
    // Scorched circle, charred debris, perimeter poles with fabric. Burning.
    _renderScene_thePyre(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Scorched earth circle ===
        g.fillStyle(tc(0x1a1510), 0.7);
        g.fillEllipse(cx, cy, 40, 28);
        // Char gradient ring
        g.fillStyle(tc(0x2a2018), 0.4);
        g.fillEllipse(cx, cy, 46, 32);
        // Inner scorched (darker)
        g.fillStyle(tc(0x0a0808), 0.6);
        g.fillEllipse(cx, cy, 24, 16);
        
        // === Charred debris in center — wood, furniture fragments ===
        g.fillStyle(tc(0x1a1410), 0.8);
        g.fillRect(cx - 6, cy - 3, 12, 3); // beam
        g.fillRect(cx - 2, cy - 5, 3, 8); // cross beam
        // Ash texture
        g.fillStyle(tc(0x3a3530), 0.3);
        for (let i = 0; i < 5; i++) {
            g.fillCircle(cx + (i - 2) * 4, cy + 1, 2);
        }
        
        // === Perimeter poles (fence posts) with fabric scraps ===
        const poleAngles = [0, Math.PI * 0.4, Math.PI * 0.8, Math.PI * 1.2, Math.PI * 1.6];
        for (let i = 0; i < poleAngles.length; i++) {
            const a = poleAngles[i];
            const px = cx + Math.cos(a) * 20;
            const py = cy + Math.sin(a) * 14;
            // Pole — vertical stick (1w × 8h)
            g.fillStyle(tc(0x4a4035), 0.8);
            g.fillRect(px, py - 8, 2, 8);
            // Fabric scrap tied near top
            if (i % 2 === 0) {
                g.fillStyle(tc(0x6a5a4a), 0.4);
                g.fillRect(px + 1, py - 7, 4, 2);
            }
        }
        
        // === Stone ring at boundary ===
        g.fillStyle(tc(0x5a5550), 0.4);
        for (let a = 0; a < Math.PI * 2; a += 0.5) {
            const sx = cx + Math.cos(a) * 22 + (Math.random() - 0.5) * 2;
            const sy = cy + Math.sin(a) * 15 + (Math.random() - 0.5) * 2;
            g.fillEllipse(sx, sy, 3, 2);
        }
        
        g.setDepth(depth);
    }
    
    // --- WASTELAND: Water Was Here ---
    // Dry riverbed, sandbag dam, empty jugs, measurement sign.
    _renderScene_waterWasHere(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Dry riverbed (east-west depression) ===
        g.fillStyle(tc(0x4a4535), 0.5);
        g.fillEllipse(cx, cy, w, 20);
        // Cracked bed inside
        g.fillStyle(tc(0x3a3525), 0.6);
        g.fillEllipse(cx, cy, w - 10, 14);
        // Crack lines
        g.lineStyle(1, tc(0x2a2520), 0.4);
        g.lineBetween(cx - 12, cy - 3, cx - 4, cy + 2);
        g.lineBetween(cx - 4, cy + 2, cx + 8, cy - 1);
        g.lineBetween(cx + 4, cy + 1, cx + 14, cy + 3);
        
        // === Sandbag dam (crude barrier, crossing the bed) ===
        const dx = cx + 8, dy = cy;
        g.fillStyle(tc(0x6a6252), 0.8);
        // Stacked bags — ¾ front: 3 bottom, 2 top
        for (let r = 0; r < 3; r++) {
            g.fillRoundedRect(dx - 2 + r * 5, dy - 2, 5, 3, 1);
        }
        g.fillRoundedRect(dx + 1, dy - 5, 5, 3, 1);
        g.fillRoundedRect(dx + 6, dy - 5, 5, 3, 1);
        
        // === Plastic tub in deepest part (empty, cracked) ===
        g.fillStyle(tc(0x5a6a7a), 0.5);
        g.fillRect(cx - 8, cy - 2, 8, 4);
        g.lineStyle(1, tc(0x3a4a5a), 0.4);
        g.strokeRect(cx - 8, cy - 2, 8, 4);
        // Crack
        g.lineBetween(cx - 6, cy - 2, cx - 4, cy + 2);
        
        // === Empty water jugs on bank (3, lined up) ===
        for (let j = 0; j < 3; j++) {
            const jx = cx - 20 + j * 6, jy = cy - 10;
            g.fillStyle(tc(0x7a8a9a), 0.4);
            g.fillRect(jx, jy, 3, 5);
            g.fillStyle(tc(0x6a7a8a), 0.3);
            g.fillRect(jx, jy - 1, 3, 1); // cap
        }
        
        // === Water level sign ===
        const sx = cx + 22, sy = cy - 8;
        // Post
        g.fillStyle(tc(0x5a5040), 0.7);
        g.fillRect(sx, sy - 6, 2, 14);
        // Sign board — front face
        g.fillStyle(tc(0x6a6050), 0.8);
        g.fillRect(sx - 4, sy - 6, 10, 7);
        // Hash marks (descending)
        g.lineStyle(1, tc(0x2a2a2a), 0.5);
        for (let m = 0; m < 4; m++) {
            g.lineBetween(sx - 2, sy - 4 + m * 1.5, sx + 3, sy - 4 + m * 1.5);
        }
        
        g.setDepth(depth);
    }
    
    // --- WASTELAND: The Dig ---
    // Deep hole, branch ladder, excavated dirt piles, tools. Desperate search for water.
    _renderScene_theDig(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Dirt piles (excavated earth around hole) ===
        g.fillStyle(tc(0x5a5040), 0.6);
        g.fillEllipse(cx - 14, cy - 8, 12, 6);
        g.fillEllipse(cx + 12, cy - 4, 10, 7);
        g.fillEllipse(cx - 8, cy + 12, 14, 5);
        // Darker base on mounds
        g.fillStyle(tc(0x4a4030), 0.4);
        g.fillEllipse(cx - 14, cy - 6, 10, 3);
        g.fillEllipse(cx + 12, cy - 2, 8, 3);
        
        // === The hole — dark rectangle with angled sides ===
        // ¾ view: near side (south) is wider, far side (north) narrower
        g.fillStyle(tc(0x1a1510), 0.9);
        g.fillRect(cx - 6, cy - 5, 12, 10);
        // Side walls visible (lighter)
        g.fillStyle(tc(0x3a3025), 0.7);
        g.fillRect(cx - 7, cy - 5, 1, 10); // west wall
        g.fillRect(cx + 6, cy - 5, 1, 10); // east wall
        // Far wall (north, bottom of visible opening)
        g.fillStyle(tc(0x2a2520), 0.6);
        g.fillRect(cx - 6, cy - 5, 12, 2);
        
        // === Branch ladder leaning against west wall ===
        g.lineStyle(1, tc(0x5a4a30), 0.8);
        // Two rails
        g.lineBetween(cx - 5, cy + 5, cx - 7, cy - 8);
        g.lineBetween(cx - 3, cy + 5, cx - 5, cy - 8);
        // Rungs
        g.lineBetween(cx - 5, cy + 2, cx - 3, cy + 2);
        g.lineBetween(cx - 5, cy - 1, cx - 4, cy - 1);
        g.lineBetween(cx - 6, cy - 4, cx - 4, cy - 4);
        
        // === Exposed pipe at bottom (cut open) ===
        g.fillStyle(tc(0x5a5a5a), 0.6);
        g.fillRect(cx - 3, cy + 1, 8, 2);
        // Cut mark
        g.lineStyle(1, tc(0x8a8a8a), 0.4);
        g.lineBetween(cx + 2, cy + 1, cx + 2, cy + 3);
        
        // === Tools at edge — pickaxe + shovel ===
        // Pickaxe (east of hole)
        g.fillStyle(tc(0x5a5040), 0.7);
        g.fillRect(cx + 10, cy + 4, 1, 10); // handle
        g.fillStyle(tc(0x4a4a4a), 0.8);
        g.fillRect(cx + 8, cy + 3, 5, 2); // head
        
        // Shovel (south-east)
        g.fillStyle(tc(0x5a5040), 0.7);
        g.fillRect(cx + 16, cy + 6, 1, 10); // handle
        g.fillStyle(tc(0x5a5a5a), 0.7);
        g.fillRect(cx + 14, cy + 5, 4, 3); // blade
        
        g.setDepth(depth);
    }
    
    // --- WASTELAND: The Last Gas Station ---
    // Pumps with spray-paint X marks. Fuel container queue. Orderly until the end.
    _renderScene_lastGasStation(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Collapsed awning (partial, one side down) ===
        g.fillStyle(tc(0x4a4a45), 0.5);
        g.fillRect(cx - 25, cy - 16, 50, 3); // awning panel
        // Support posts
        g.fillStyle(tc(0x5a5a55), 0.7);
        g.fillRect(cx - 24, cy - 16, 2, 14);
        g.fillRect(cx + 22, cy - 16, 2, 20); // this one tilted/longer (collapsed side)
        
        // === 4 pumps in a row (¾ front face: 4w × 8h each) ===
        for (let p = 0; p < 4; p++) {
            const px = cx - 16 + p * 11, py = cy - 6;
            // Pump body — front face
            g.fillStyle(tc(0x4a4a45), 0.9);
            g.fillRect(px, py, 4, 8);
            // Screen (dark rectangle)
            g.fillStyle(tc(0x1a1a1a), 0.6);
            g.fillRect(px + 0.5, py + 1, 3, 2);
            // Nozzle hook (small)
            g.fillStyle(tc(0x3a3a3a), 0.5);
            g.fillRect(px + 3, py + 4, 2, 1);
            
            // Spray paint X on first 3 pumps
            if (p < 3) {
                g.lineStyle(2, tc(0xaa3333), 0.6);
                g.lineBetween(px, py, px + 4, py + 8);
                g.lineBetween(px + 4, py, px, py + 8);
            }
        }
        
        // === Fuel container queue at unmarked pump ===
        // Line of containers leading to the 4th pump
        const qx = cx + 16, qy = cy + 6;
        const containers = [
            { w: 3, h: 4, c: 0x5a6a4a },  // jerry can
            { w: 4, h: 3, c: 0x7a7a8a },  // plastic jug
            { w: 2, h: 4, c: 0x5a8a6a },  // bottle
            { w: 3, h: 4, c: 0x5a6a4a },  // jerry can
            { w: 3, h: 3, c: 0x6a6a7a },  // plastic jug
        ];
        for (let i = 0; i < containers.length; i++) {
            const c = containers[i];
            g.fillStyle(tc(c.c), 0.5);
            g.fillRect(qx - i * 5, qy, c.w, c.h);
        }
        
        g.setDepth(depth);
    }
    
    // --- ANOMALOUS: The Patrol That Didn't Report ---
    // Three Terracorp bodies in formation. Organic growth veins. Weapons untouched.
    _renderScene_fallenPatrol(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Three bodies in triangle formation ===
        const bodies = [
            { x: cx, y: cy - 14, rot: 0, pose: 'facedown' },     // point man, north
            { x: cx - 12, y: cy + 2, rot: 0, pose: 'back' },     // on back, arms up
            { x: cx + 14, y: cy + 6, rot: 0, pose: 'slumped' }   // slumped against wall
        ];
        
        for (const b of bodies) {
            // Body — ¾ top-down view: torso (6w × 10h) + head circle
            if (b.pose === 'facedown') {
                // Face down — dark tactical gear visible
                g.fillStyle(tc(0x2a2a28), 0.8);
                g.fillRect(b.x - 3, b.y - 4, 6, 10); // torso
                g.fillStyle(tc(0x3a3530), 0.7);
                g.fillCircle(b.x, b.y - 6, 2); // head (helmet)
                // Weapon beside (rifle shape)
                g.fillStyle(tc(0x3a3a3a), 0.6);
                g.fillRect(b.x + 5, b.y - 2, 2, 8);
            } else if (b.pose === 'back') {
                // On back — arms reaching up
                g.fillStyle(tc(0x2a2a28), 0.8);
                g.fillRect(b.x - 3, b.y - 4, 6, 10);
                g.fillStyle(tc(0x3a3530), 0.7);
                g.fillCircle(b.x, b.y + 7, 2); // head south (face up)
                // Arms extended north
                g.lineStyle(1, tc(0x2a2a28), 0.7);
                g.lineBetween(b.x - 3, b.y - 2, b.x - 6, b.y - 8);
                g.lineBetween(b.x + 3, b.y - 2, b.x + 5, b.y - 7);
            } else {
                // Slumped sitting — shorter torso, legs out
                g.fillStyle(tc(0x2a2a28), 0.8);
                g.fillRect(b.x - 3, b.y - 2, 6, 6); // torso
                g.fillStyle(tc(0x3a3530), 0.7);
                g.fillCircle(b.x, b.y - 4, 2); // head drooped
                // Legs extended south
                g.fillStyle(tc(0x2a2a25), 0.6);
                g.fillRect(b.x - 4, b.y + 4, 3, 6);
                g.fillRect(b.x + 1, b.y + 4, 3, 6);
            }
            
            // Terracorp marking (small orange rectangle on shoulder)
            g.fillStyle(tc(0xaa6a2a), 0.4);
            g.fillRect(b.x + 2, b.y - 3, 2, 2);
            
            // === Organic growth veins extending from body into ground ===
            g.lineStyle(1, tc(0x4a2a4a), 0.5);
            const veinCount = 2 + Math.floor(Math.random() * 2);
            for (let v = 0; v < veinCount; v++) {
                const angle = Math.random() * Math.PI * 2;
                const len = 8 + Math.random() * 10;
                g.lineBetween(b.x, b.y + 2, b.x + Math.cos(angle) * len, b.y + 2 + Math.sin(angle) * len * 0.7);
            }
        }
        
        // === Radio near slumped body ===
        g.fillStyle(tc(0x3a3a3a), 0.7);
        g.fillRect(cx + 18, cy + 10, 3, 4);
        g.lineStyle(1, tc(0x2a2a2a), 0.5);
        g.lineBetween(cx + 19, cy + 10, cx + 20, cy + 6); // antenna
        
        g.setDepth(depth);
    }
    
    // --- ANOMALOUS: Cephalon Camp ---
    // Tent circle around cube node. Kneeling impressions. Well-maintained but empty.
    _renderScene_cephalonCamp(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Central cube node (hovering, cyan edges) ===
        const nx = cx, ny = cy;
        g.fillStyle(tc(0x1a1a2a), 0.8);
        g.fillRect(nx - 5, ny - 5, 10, 10);
        g.lineStyle(1, tc(0x4adfdf), 0.6);
        g.strokeRect(nx - 5, ny - 5, 10, 10);
        // Glow underneath
        g.fillStyle(tc(0x4adfdf), 0.08);
        g.fillEllipse(nx, ny + 8, 14, 6);
        
        // === Tents in circle (5 tents, human-made) ===
        // ¾ view: tent = triangular wedge (8w × 6h front face + 4h depth top)
        const tentAngles = [0.3, 1.0, 1.9, 3.0, 4.2];
        const tentRadius = 22;
        for (let i = 0; i < tentAngles.length; i++) {
            const a = tentAngles[i];
            const tx = cx + Math.cos(a) * tentRadius;
            const ty = cy + Math.sin(a) * tentRadius * 0.65;
            
            // Tent body — triangle front face
            g.fillStyle(tc(0x5a6a5a), 0.7);
            g.beginPath();
            g.moveTo(tx - 4, ty + 3);
            g.lineTo(tx + 4, ty + 3);
            g.lineTo(tx, ty - 4);
            g.closePath();
            g.fillPath();
            // Ridge line
            g.lineStyle(1, tc(0x4a5a4a), 0.5);
            g.lineBetween(tx, ty - 4, tx + 2, ty - 5);
        }
        
        // === Organized supplies near one tent ===
        const sx = cx + Math.cos(tentAngles[0]) * (tentRadius + 8);
        const sy = cy + Math.sin(tentAngles[0]) * (tentRadius + 8) * 0.65;
        // Canned food stack
        g.fillStyle(tc(0x6a6a5a), 0.5);
        g.fillRect(sx, sy, 4, 3);
        g.fillRect(sx, sy - 2, 4, 2);
        // Water container
        g.fillStyle(tc(0x5a7a8a), 0.4);
        g.fillRect(sx + 6, sy, 3, 4);
        
        // === Fire pit with recent ash ===
        g.fillStyle(tc(0x2a2520), 0.5);
        g.fillEllipse(cx + 10, cy + 10, 8, 5);
        g.fillStyle(tc(0x3a3530), 0.3);
        g.fillEllipse(cx + 10, cy + 10, 5, 3);
        
        // === Kneeling impressions (5 paired depressions facing the node) ===
        g.fillStyle(tc(0x2a2025), 0.25);
        for (let k = 0; k < 5; k++) {
            const kx = cx - 12 + k * 6;
            const ky = cy + 16;
            g.fillEllipse(kx, ky, 2, 1.5); // left knee
            g.fillEllipse(kx + 2, ky, 2, 1.5); // right knee
        }
        
        g.setDepth(depth);
    }
    
    // --- ANOMALOUS: The Offering ---
    // Human objects arranged at monolith base. Sacrifice? Gift? Test? Unacknowledged.
    _renderScene_theOffering(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        // === Cube monolith — tall slab (8w × 24h front face, ¾ north-facing) ===
        const mx = cx, my = cy - 8;
        // Shadow
        g.fillStyle(tc(0x0a0a10), 0.25);
        g.fillEllipse(mx, my + 14, 18, 6);
        // Front face
        g.fillStyle(tc(0x1a1520), 0.9);
        g.fillRect(mx - 4, my - 12, 8, 24);
        // Top strip
        g.fillStyle(tc(0x2a2030), 0.7);
        g.fillRect(mx - 4, my - 13, 8, 2);
        // Side edge (east)
        g.fillStyle(tc(0x151018), 0.8);
        g.fillRect(mx + 4, my - 12, 2, 24);
        // Faint cyan edge lines
        g.lineStyle(1, tc(0x4adfdf), 0.2);
        g.strokeRect(mx - 4, my - 12, 8, 24);
        // Geometric pattern on face
        g.lineStyle(1, tc(0x4adfdf), 0.15);
        g.lineBetween(mx - 2, my - 8, mx + 2, my - 4);
        g.lineBetween(mx + 2, my - 4, mx - 2, my);
        g.lineBetween(mx - 2, my, mx + 2, my + 4);
        
        // === Arranged objects at base (facing the monolith) ===
        const baseY = my + 14;
        
        // Clothing pile
        g.fillStyle(tc(0x5a5a6a), 0.4);
        g.fillEllipse(mx - 10, baseY, 6, 3);
        
        // Jewelry (tiny glint)
        g.fillStyle(tc(0x8a8a4a), 0.5);
        g.fillCircle(mx - 5, baseY + 1, 1);
        
        // Photographs (small rectangles)
        g.fillStyle(tc(0x7a7a6a), 0.4);
        g.fillRect(mx - 2, baseY - 1, 4, 3);
        g.fillRect(mx + 1, baseY, 3, 2);
        
        // Child's toy (small colored shape)
        g.fillStyle(tc(0xaa4a4a), 0.5);
        g.fillCircle(mx + 6, baseY + 1, 2);
        
        // Weapons (laid down)
        g.fillStyle(tc(0x4a4a4a), 0.5);
        g.fillRect(mx + 8, baseY - 1, 2, 6);
        g.fillRect(mx + 12, baseY, 2, 5);
        
        // Food cans
        g.fillStyle(tc(0x5a6a5a), 0.4);
        g.fillRect(mx - 14, baseY + 2, 3, 3);
        g.fillRect(mx - 12, baseY + 3, 3, 3);
        
        g.setDepth(depth);
    }
    
    // --- ANOMALOUS: The Barricade That Faced Inward ---
    // Circular barrier facing center. Scorch marks. Breach from inside. Containment failed.
    _renderScene_barricadeInward(cx, cy, w, h) {
        const g = this.add.graphics();
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const depth = 10 + (cy + h / 2) * 0.01;
        
        const radius = 22;
        
        // === Ground scar at center (geometric burn pattern) ===
        g.fillStyle(tc(0x1a1520), 0.6);
        g.fillEllipse(cx, cy, 16, 11);
        // Scorch marks — radiating lines
        g.lineStyle(1, tc(0x2a2025), 0.4);
        for (let a = 0; a < Math.PI * 2; a += 0.7) {
            g.lineBetween(cx, cy, cx + Math.cos(a) * 8, cy + Math.sin(a) * 5);
        }
        
        // === Circular barricade (concrete barriers + furniture) ===
        // Draw arc segments with a breach (gap) on east side
        const breachStart = -0.4;
        const breachEnd = 0.5;
        
        for (let a = 0; a < Math.PI * 2; a += 0.45) {
            // Skip breach area
            if (a > breachStart + Math.PI * 2 - 0.5 || a < breachEnd) continue;
            
            const bx = cx + Math.cos(a) * radius;
            const by = cy + Math.sin(a) * radius * 0.7;
            
            // Alternate between concrete barriers and furniture
            if (Math.floor(a * 3) % 2 === 0) {
                // Concrete barrier — ¾ front face (6w × 4h)
                g.fillStyle(tc(0x5a5a55), 0.8);
                g.fillRect(bx - 3, by - 2, 6, 4);
                g.fillStyle(tc(0x6a6a65), 0.5);
                g.fillRect(bx - 3, by - 3, 6, 1); // top strip
            } else {
                // Furniture/debris — irregular shapes
                g.fillStyle(tc(0x4a4035), 0.7);
                g.fillRect(bx - 2, by - 3, 5, 5);
            }
        }
        
        // === Breach — barriers shoved outward ===
        // Displaced barrier pieces outside the ring
        g.fillStyle(tc(0x5a5a55), 0.6);
        g.fillRect(cx + radius + 4, cy - 4, 6, 4); // pushed east
        g.fillStyle(tc(0x4a4a40), 0.5);
        g.fillRect(cx + radius + 2, cy + 4, 5, 3); // another piece
        // Drag marks from breach
        g.lineStyle(1, tc(0x3a3530), 0.3);
        g.lineBetween(cx + radius - 2, cy - 2, cx + radius + 4, cy - 3);
        g.lineBetween(cx + radius - 1, cy + 2, cx + radius + 3, cy + 4);
        
        // === Shell casings scattered inside ===
        g.fillStyle(tc(0x8a7a3a), 0.3);
        for (let c = 0; c < 8; c++) {
            const sx = cx + (Math.random() - 0.5) * 20;
            const sy = cy + (Math.random() - 0.5) * 12;
            g.fillRect(sx, sy, 1, 1);
        }
        
        g.setDepth(depth);
    }
    
    createBuilding(x, y, width, height, name, archetype, subtype, baseColor, buildingType = '', shape = 'rect', wing = null, damaged = false, buildingId = null, interiorScale = null) {
        const color = this.tintColor(baseColor, this.lighting.ambient, this.lighting.intensity);
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        
        // Y-based depth for proper sorting
        const buildingDepth = 10 + (y + height/2) * 0.01;
        
        // Dynamic shadow
        const shadowOffsetX = Math.cos(this.lighting.shadowAngle) * height * 0.5 * this.lighting.shadowLength;
        const shadowOffsetY = Math.sin(this.lighting.shadowAngle) * height * 0.25 * this.lighting.shadowLength;
        const shadowAlpha = CONFIG.timeOfDay === 'night' ? 0.35 : 0.55;
        
        // Ground shadow
        this.add.rectangle(
            x + shadowOffsetX * 0.6, 
            y + height/2 + 5 + Math.abs(shadowOffsetY) * 0.5, 
            width + Math.abs(shadowOffsetX) * 0.4, 
            height * 0.25 + Math.abs(shadowOffsetY), 
            0x000000, shadowAlpha
        ).setDepth(3);
        
        // Render main body (pass door X so windows avoid it)
        this.renderBuildingBody(x, y, width, height, baseColor, buildingDepth, archetype, damaged, 'main', x);
        
        // Render wing for L-shapes
        if (wing && (shape === 'L_right' || shape === 'L_left')) {
            const wx = x + wing.dx;
            const wy = y + wing.dy;
            const wingDepth = 10 + (wy + wing.h/2) * 0.01;
            
            this.add.rectangle(
                wx + shadowOffsetX * 0.4, wy + wing.h/2 + 5 + Math.abs(shadowOffsetY) * 0.3,
                wing.w + Math.abs(shadowOffsetX) * 0.3, wing.h * 0.2 + Math.abs(shadowOffsetY),
                0x000000, shadowAlpha * 0.8
            ).setDepth(3);
            
            this.renderBuildingBody(wx, wy, wing.w, wing.h, baseColor, wingDepth, archetype, damaged, 'wing', wx);
            
            // Seam cover
            const seamX = x + (wing.side > 0 ? width/2 - 4 : -width/2 + 4);
            const seamH = wy + wing.h/2 - (y - height/2);
            this.add.rectangle(seamX, y - height/2 + seamH/2, 10, seamH, this.tintColor(baseColor, this.lighting.ambient, this.lighting.intensity)).setDepth(buildingDepth + 0.002);
            
            this.addWall(wx, wy, wing.w, wing.h, color, false);
        }
        
        // Damage effects
        if (damaged) {
            this.renderBuildingDamage(x, y, width, height, buildingDepth, wing, shape);
        }
        
        // === DOOR AREA ===
        // For buildings below road, door faces NORTH (toward road)
        // For buildings above road, door faces SOUTH (toward road) — default
        const roadCenterY = CONFIG.world.height / 2;
        const buildingBelowRoad = y > roadCenterY;
        const elevation = Math.min(height * 0.35, 30);
        const doorFrameColor = tc(damaged ? 0x1a1a18 : 0x151510);
        const doorColor = tc(damaged ? 0x1a1a18 : 0x252520);
        
        let doorActualY;
        if (buildingBelowRoad) {
            // Door on NORTH side — NOT visible from ¾ perspective (facing away from camera)
            // Only render: invisible interaction zone + walkway hint leading to building edge
            doorActualY = y - height/2 - 8;
            
            // Invisible interaction door (player walks up to building edge)
            const door = this.add.rectangle(x, doorActualY, 36, 12, 0x000000, 0).setDepth(buildingDepth + 0.009);
            door.buildingName = name;
            door.archetype = archetype;
            door.subtype = subtype;
            door.buildingType = buildingType;
            door.buildingWidth = width;
            door.buildingHeight = height;
            door.doorSide = 'north';
            door.buildingId = buildingId;
            door.interiorScale = interiorScale;
            
            // Locked building chance (15% at reach 3+, increases with reach)
            const lockReach = this.destinationNode?.reach || 1;
            const lockChance = lockReach >= 3 ? 0.10 + (lockReach - 3) * 0.05 : 0;
            door.isLocked = Math.random() < lockChance;
            
            // Walkway / path leading to the hidden north entrance
            this.add.rectangle(x, doorActualY - 4, 36, 8, tc(0x353530)).setDepth(buildingDepth - 0.001);
            this.add.rectangle(x, doorActualY - 10, 32, 6, tc(0x353530)).setDepth(2);
            
            // Subtle door mat indicator at building edge
            this.add.rectangle(x, y - height/2 + 2, 28, 4, tc(0x2a2a25)).setDepth(buildingDepth + 0.001);
            
            // Small "entrance" arrow/indicator on ground
            this.add.rectangle(x, doorActualY - 16, 4, 8, tc(0x4a4a40), 0.4).setDepth(3);
            this.add.rectangle(x - 4, doorActualY - 12, 4, 4, tc(0x4a4a40), 0.3).setDepth(3);
            this.add.rectangle(x + 4, doorActualY - 12, 4, 4, tc(0x4a4a40), 0.3).setDepth(3);
            
            this.buildingDoors.push(door);
        } else {
            // Door on SOUTH side (front face) — recessed doorway IN the front wall
            const doorY = y + height/2 - 4;
            doorActualY = doorY + elevation/2 + 10;
            
            // Dark recess BEHIND the front face (the doorway opening)
            this.add.rectangle(x, doorActualY - 2, 36, elevation + 12, tc(0x0a0a08)).setDepth(buildingDepth + 0.0015);
            
            // Door frame sides (jambs) — sit flush with front face
            this.add.rectangle(x - 16, doorActualY - 2, 5, elevation + 10, tc(0x2a2a25)).setDepth(buildingDepth + 0.003);
            this.add.rectangle(x + 16, doorActualY - 2, 5, elevation + 10, tc(0x2a2a25)).setDepth(buildingDepth + 0.003);
            // Lintel above
            this.add.rectangle(x, doorActualY - elevation/2 - 4, 38, 5, tc(0x2a2a25)).setDepth(buildingDepth + 0.003);
            
            // Door panel INSIDE the recess (slightly recessed from face)
            const door = this.add.rectangle(x, doorActualY, 28, elevation + 4, doorColor).setDepth(buildingDepth + 0.002);
            door.buildingName = name;
            door.archetype = archetype;
            door.subtype = subtype;
            door.buildingType = buildingType;
            door.buildingWidth = width;
            door.buildingHeight = height;
            door.doorSide = 'south';
            door.buildingId = buildingId;
            door.interiorScale = interiorScale;
            
            // Locked building chance (same as north door)
            const lockReachS = this.destinationNode?.reach || 1;
            const lockChanceS = lockReachS >= 3 ? 0.10 + (lockReachS - 3) * 0.05 : 0;
            door.isLocked = Math.random() < lockChanceS;
            
            if (damaged) {
                // Damaged door — ajar, showing dark gap
                this.add.rectangle(x - 3, doorActualY, 20, elevation + 2, tc(0x1a1815)).setDepth(buildingDepth + 0.0025);
                this.add.rectangle(x + 9, doorActualY + 4, 3, 5, tc(0x5a5a4a)).setDepth(buildingDepth + 0.0025);
            } else {
                // Panel detail + handle — recessed inside frame
                this.add.rectangle(x, doorActualY - 4, 22, 6, tc(0x1a1a18)).setDepth(buildingDepth + 0.0025);
                this.add.rectangle(x, doorActualY + 4, 22, 6, tc(0x1a1a18)).setDepth(buildingDepth + 0.0025);
                this.add.circle(x + 9, doorActualY + 2, 2.5, tc(0x6a6a5a)).setDepth(buildingDepth + 0.0025);
            }
            
            // Step / threshold at door base
            this.add.rectangle(x, doorY + elevation + 16, 40, 6, tc(0x353530)).setDepth(buildingDepth + 0.001);
            
            this.buildingDoors.push(door);
        }
        
        this.addWall(x, y, width, height, color, false);
        
        // === PATHWAY from door to road ===
        const pathColor = tc(0x4a4a40);
        const pathW = 18;
        
        if (!buildingBelowRoad) {
            const doorBottomY = y + height/2 + elevation + 12;
            const sidewalkY = roadCenterY - 49;
            if (sidewalkY > doorBottomY) {
                const pathH = sidewalkY - doorBottomY;
                this.add.rectangle(x, doorBottomY + pathH/2, pathW, pathH, pathColor).setDepth(2);
                this.add.rectangle(x - pathW/2, doorBottomY + pathH/2, 2, pathH, tc(0x3a3a35), 0.4).setDepth(2.05);
                this.add.rectangle(x + pathW/2, doorBottomY + pathH/2, 2, pathH, tc(0x3a3a35), 0.4).setDepth(2.05);
            }
        } else {
            const doorTopY = doorActualY - elevation/2 - 9;
            const sidewalkY = roadCenterY + 49;
            if (doorTopY > sidewalkY) {
                const pathH = doorTopY - sidewalkY;
                this.add.rectangle(x, sidewalkY + pathH/2, pathW, pathH, pathColor).setDepth(2);
                this.add.rectangle(x - pathW/2, sidewalkY + pathH/2, 2, pathH, tc(0x3a3a35), 0.4).setDepth(2.05);
                this.add.rectangle(x + pathW/2, sidewalkY + pathH/2, 2, pathH, tc(0x3a3a35), 0.4).setDepth(2.05);
            }
        }
        
        // === BUILDING EXTRAS by archetype ===
        this.createBuildingExtras(x, y, width, height, archetype, subtype, damaged, buildingDepth, wing, shape, buildingId);
    }
    
    // Render a building body section (main or wing)
    renderBuildingBody(x, y, width, height, color, depth, archetype, damaged, section, doorX) {
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const roofColor = tc(0x1a1815);
        const roofHighlight = tc(0x252520);
        const trimColor = tc(0x2a2825);
        const foundationColor = tc(0x252520);
        const bodyColor = damaged ? tc(IsoRenderer.darken(color, 0.1)) : tc(color);
        
        // === ISOMETRIC BUILDING — 3D cube with top, front, side ===
        const elevation = Math.min(height * 0.35, 30); // visible front face height
        const sideW = Math.max(4, Math.min(elevation * 0.5, width * 0.12));
        
        const topColor = tc(IsoRenderer.lighten(color, 0.15));
        const frontColor = damaged ? tc(IsoRenderer.darken(color, 0.05)) : tc(color);
        const sideColor = tc(IsoRenderer.darken(color, 0.25));
        
        // Foundation (slightly wider, at base)
        this.add.rectangle(x, y + height/2 + 2, width + 6, 8, foundationColor).setDepth(depth);
        this.add.rectangle(x + sideW/2, y + height/2 + 2, sideW + 2, 8, tc(IsoRenderer.darken(0x252520, 0.2))).setDepth(depth);
        
        // Side face (right edge — shows depth)
        this.add.rectangle(
            x + width/2 - sideW/2, y - elevation/2,
            sideW, height + elevation, sideColor
        ).setDepth(depth + 0.001);
        
        // Front face (bottom — visible wall)
        this.add.rectangle(
            x - sideW/2, y + height/2 + elevation/2,
            width - sideW, elevation, frontColor
        ).setDepth(depth + 0.002);
        
        // Front face trim/base
        this.add.rectangle(
            x - sideW/2, y + height/2 + elevation - 3,
            width - sideW, 4, trimColor
        ).setDepth(depth + 0.0025);
        
        // Top surface (roof area)
        const roofW = width - sideW;
        this.add.rectangle(
            x - sideW/2, y - elevation/2,
            roofW, height, topColor
        ).setDepth(depth + 0.003);
        
        // === ROOF DETAILS ===
        if (!damaged || section === 'main') {
            // Roof edge overhang
            const overhang = section === 'wing' ? 4 : 8;
            this.add.rectangle(x - sideW/2, y - height/2 - elevation/2 - 2, roofW + overhang, 6, roofColor).setDepth(depth + 0.004);
            this.add.rectangle(x - sideW/2, y - height/2 - elevation/2 - 5, roofW + overhang - 4, 3, roofHighlight).setDepth(depth + 0.005);
            
            // Rooftop details by archetype
            if (archetype === 'industrial') {
                // Vents / AC units on roof
                const ventColor = tc(0x3a3a3a);
                this.add.rectangle(x - width/4, y - height/4, 12, 8, ventColor).setDepth(depth + 0.006);
                this.add.rectangle(x + width/6, y - height/3, 8, 8, ventColor).setDepth(depth + 0.006);
            } else if (archetype === 'commercial') {
                // Flat commercial roof with slight parapet
                this.add.rectangle(x - sideW/2, y - height/2 - elevation/2 + 1, roofW, 3, tc(0x2a2a28)).setDepth(depth + 0.006);
            }
        } else {
            // Damaged roof — partial/broken
            const partialW = roofW * 0.55;
            this.add.rectangle(x - width/2 + partialW/2, y - height/2 - elevation/2 - 2, partialW + 6, 6, roofColor).setDepth(depth + 0.004);
            // Exposed rafters
            for (let rx = x - width/4; rx < x + width/2 - sideW; rx += 14) {
                this.add.rectangle(rx, y - height/2 - elevation/2, 3, 6, tc(0x3a3025), 0.6).setDepth(depth + 0.004);
            }
        }
        
        // === VERTICAL TRIM / COLUMNS ===
        this.add.rectangle(x - width/2 + 4, y - elevation/2, 5, height + elevation, trimColor).setDepth(depth + 0.0035);
        this.add.rectangle(x + width/2 - sideW - 3, y - elevation/2, 5, height + elevation, trimColor).setDepth(depth + 0.0035);
        
        // === ARCHETYPE FACADE DETAILS ===
        if (archetype === 'industrial' && width > 80) {
            // Corrugated siding on side face
            for (let ry = y - height/2; ry < y + height/2; ry += 10) {
                this.add.rectangle(x + width/2 - sideW/2, ry, sideW - 2, 1, tc(0x1a1815), 0.3).setDepth(depth + 0.0015);
            }
            // Front face corrugation
            for (let ry = y + height/2; ry < y + height/2 + elevation - 4; ry += 6) {
                this.add.rectangle(x - sideW/2, ry, width - sideW - 8, 1, trimColor, 0.3).setDepth(depth + 0.0025);
            }
        } else if (archetype === 'commercial' && section === 'main') {
            // Storefront accent band on front face
            const accentColor = tc(0x2a3535);
            this.add.rectangle(x - sideW/2, y + height/2 + 4, width - sideW - 10, 5, accentColor).setDepth(depth + 0.0028);
        } else if (archetype === 'residential') {
            // Subtle horizontal siding lines on top surface
            for (let ry = y - height/2 + 10; ry < y + height/2 - 5; ry += 16) {
                this.add.rectangle(x - sideW/2, ry, roofW - 8, 1, trimColor, 0.2).setDepth(depth + 0.0035);
            }
        }
        
        // === WINDOWS — placed on FRONT face, avoiding door overlap ===
        const frontFaceY = y + height/2 + elevation * 0.35; // center of front face
        const frontLeft = x - width/2 + 20;
        const frontRight = x + width/2 - sideW - 20;
        const doorCenterX = doorX !== undefined ? doorX : x; // door X position
        const doorHalfW = 25; // door exclusion zone half-width
        
        // Calculate window positions avoiding door
        const windowSpacing = archetype === 'industrial' ? 55 : 42;
        const windowW = archetype === 'industrial' ? 20 : 18;
        const windowH = Math.min(elevation - 8, 18);
        
        if (windowH > 6) {
            for (let wx = frontLeft; wx <= frontRight; wx += windowSpacing) {
                // Skip if overlapping with door zone
                if (Math.abs(wx - doorCenterX) < doorHalfW) continue;
                
                const isLit = (CONFIG.timeOfDay === 'night' || CONFIG.timeOfDay === 'dusk') && Math.random() > 0.35;
                const isSmashed = damaged && Math.random() < 0.45;
                const windowColor = isSmashed ? 0x0a0a0a : (isLit ? 0x665533 : 0x151520);
                
                // Window frame
                this.add.rectangle(wx, frontFaceY, windowW + 4, windowH + 4, tc(0x1a1815)).setDepth(depth + 0.005);
                // Glass
                this.add.rectangle(wx, frontFaceY, windowW, windowH, windowColor).setDepth(depth + 0.006);
                
                if (isSmashed) {
                    const gfx = this.add.graphics().setDepth(depth + 0.007);
                    gfx.fillStyle(0x1a2020, 0.5);
                    gfx.fillTriangle(wx - windowW/2 + 2, frontFaceY - windowH/2, wx + 2, frontFaceY - windowH/2, wx - 2, frontFaceY);
                    gfx.fillTriangle(wx + windowW/2, frontFaceY - windowH/2, wx + windowW/2, frontFaceY + 2, wx + 2, frontFaceY - 3);
                } else {
                    // Panes (cross)
                    const paneColor = tc(0x252525);
                    this.add.rectangle(wx, frontFaceY, windowW, 2, paneColor).setDepth(depth + 0.007);
                    this.add.rectangle(wx, frontFaceY, 2, windowH, paneColor).setDepth(depth + 0.007);
                }
                
                // Window glow cast on ground at night
                if (isLit && !isSmashed) {
                    this.add.rectangle(wx, frontFaceY + windowH + 8, windowW + 4, 6, 0x443322, 0.25).setDepth(3);
                }
            }
        }
        
        // === SECOND-FLOOR WINDOWS (on upper portion of front face for tall buildings) ===
        if (height > 70 && section === 'main' && windowH > 6) {
            // Place on front face, above the first-floor windows
            const upperFrontY = y + height/2 + elevation * 0.08; // upper part of front face
            for (let wx = frontLeft + 5; wx <= frontRight - 5; wx += windowSpacing) {
                if (Math.abs(wx - doorCenterX) < doorHalfW) continue;
                const isLit2 = (CONFIG.timeOfDay === 'night' || CONFIG.timeOfDay === 'dusk') && Math.random() > 0.5;
                const isSmashed2 = damaged && Math.random() < 0.6;
                const wColor2 = isSmashed2 ? 0x0a0a0a : (isLit2 ? 0x554422 : 0x151520);
                this.add.rectangle(wx, upperFrontY, windowW + 2, windowW + 2, tc(0x1a1815)).setDepth(depth + 0.005);
                this.add.rectangle(wx, upperFrontY, windowW - 2, windowW - 2, wColor2).setDepth(depth + 0.006);
                if (!isSmashed2) {
                    this.add.rectangle(wx, upperFrontY, windowW - 2, 1.5, tc(0x252525)).setDepth(depth + 0.007);
                    this.add.rectangle(wx, upperFrontY, 1.5, windowW - 2, tc(0x252525)).setDepth(depth + 0.007);
                }
            }
        }
    }
    
    // Render damage effects on building
    renderBuildingDamage(x, y, width, height, depth, wing, shape) {
        // Pick a wall to be collapsed (left or right, but not the door side which is bottom)
        const side = Math.random() < 0.5 ? -1 : 1; // -1 left, 1 right
        const collapseX = x + side * (width/2 - 5);
        const collapseY = y + Phaser.Math.Between(-height/4, height/4);
        
        // Broken wall edge — irregular blocks
        const rubbleColor = this.tintColor(0x2a2520, this.lighting.ambient, this.lighting.intensity);
        const darkRubble = this.tintColor(0x1a1815, this.lighting.ambient, this.lighting.intensity);
        
        // Gap in wall (dark interior showing through)
        const gapW = Phaser.Math.Between(15, 25);
        const gapH = Phaser.Math.Between(20, 35);
        this.add.rectangle(collapseX, collapseY, gapW, gapH, 0x0a0a0a).setDepth(depth + 0.001);
        
        // Jagged edges around gap
        for (let i = 0; i < 5; i++) {
            const bx = collapseX + Phaser.Math.Between(-gapW/2 - 5, gapW/2 + 5);
            const by = collapseY + Phaser.Math.Between(-gapH/2 - 5, gapH/2 + 5);
            const bw = Phaser.Math.Between(4, 10);
            const bh = Phaser.Math.Between(3, 8);
            this.add.rectangle(bx, by, bw, bh, rubbleColor).setDepth(depth + 0.003).setAngle(Phaser.Math.Between(-15, 15));
        }
        
        // Ground rubble scatter (outside the building)
        const rubbleBaseX = collapseX + side * 15;
        const rubbleBaseY = y + height/2 + 5;
        for (let i = 0; i < 8; i++) {
            const rx = rubbleBaseX + Phaser.Math.Between(-20, 20);
            const ry = rubbleBaseY + Phaser.Math.Between(-8, 12);
            const rw = Phaser.Math.Between(3, 10);
            const rh = Phaser.Math.Between(2, 6);
            const rc = Math.random() < 0.5 ? rubbleColor : darkRubble;
            this.add.rectangle(rx, ry, rw, rh, rc, 0.8).setDepth(4).setAngle(Phaser.Math.Between(-30, 30));
        }
        
        // Dust/debris pile at base of collapse
        this.add.ellipse(rubbleBaseX, rubbleBaseY + 4, 30, 10, rubbleColor, 0.5).setDepth(4);
        
        // Cracks radiating from damage
        const crackColor = this.tintColor(0x151210, this.lighting.ambient, this.lighting.intensity);
        for (let i = 0; i < 3; i++) {
            const cx = collapseX + Phaser.Math.Between(-gapW, gapW);
            const cy = collapseY + Phaser.Math.Between(-gapH, gapH);
            const len = Phaser.Math.Between(8, 20);
            const angle = Phaser.Math.Between(-45, 45);
            const crack = this.add.rectangle(cx, cy, len, 1.5, crackColor, 0.6).setDepth(depth + 0.002);
            crack.setAngle(angle);
        }
    }
    
    addWall(x, y, w, h, color, visible = true) {
        // If we're capturing prop visuals, redirect to propWalls
        if (this._capturingProp) {
            return this.addPropWall(x, y, w, h);
        }
        const wall = this.add.rectangle(x, y, w, h, color);
        if (!visible) wall.setAlpha(0);
        this.physics.add.existing(wall, true);
        this.walls.add(wall);
        this.wallRects.push(new Phaser.Geom.Rectangle(x - w/2, y - h/2, w, h));
    }
    
    addPropWall(x, y, w, h) {
        this._addingPropWall = true;
        const wall = this.add.rectangle(x, y, w, h, 0x000000, 0);
        this._addingPropWall = false;
        this.physics.add.existing(wall, true);
        this.propWalls.add(wall);
        const rect = new Phaser.Geom.Rectangle(x - w/2, y - h/2, w, h);
        this.wallRects.push(rect);
        this._lastPropWall = wall;
        this._lastPropWallRect = rect;
        if (this._capturedPropWalls) this._capturedPropWalls.push({ wall, rect });
        return wall;
    }
    
    // === BUILDING EXTRAS — garages, loading docks, awnings, etc. ===
    createBuildingExtras(x, y, width, height, archetype, subtype, damaged, depth, wing, shape, buildingId = null) {
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const biome = CONFIG.currentBiome ? CONFIG.currentBiome.type : 'grassy';
        
        // Pick a side for the extra (opposite from wing, or random)
        let extraSide;
        if (wing && shape === 'L_right') extraSide = -1; // left
        else if (wing && shape === 'L_left') extraSide = 1; // right
        else extraSide = Math.random() < 0.5 ? -1 : 1;
        
        const extraX = x + extraSide * (width/2 + 18);
        
        if (archetype === 'residential' && !damaged && Math.random() < 0.55) {
            // === GARAGE / CARPORT ===
            const garageW = 38, garageH = 32;
            const gx = extraX;
            const gy = y + height/2 - garageH/2 + 4;
            const gDepth = 10 + (gy + garageH/2) * 0.01;
            
            // Garage body (iso cube)
            IsoRenderer.cube(this, gx, gy, garageW, garageH, 14, 0x3a3832, { depth: gDepth });
            
            // Garage door (front face — roller door lines)
            const gdY = gy + garageH/2 + 4;
            const garageDoor = this.add.rectangle(gx, gdY, garageW - 8, 12, tc(0x2a2a28)).setDepth(gDepth + 0.008);
            for (let ly = gdY - 4; ly <= gdY + 4; ly += 3) {
                this.add.rectangle(gx, ly, garageW - 12, 1, tc(0x1a1a18), 0.5).setDepth(gDepth + 0.009);
            }
            // Handle on garage door
            this.add.rectangle(gx, gdY + 3, 10, 2, tc(0x5a5a5a)).setDepth(gDepth + 0.01);
            
            // Make garage door interactive — enters garage interior
            garageDoor.setInteractive();
            garageDoor.buildingName = 'Garage';
            garageDoor.archetype = 'industrial';
            garageDoor.subtype = 'garage';
            garageDoor.buildingWidth = 80;
            garageDoor.buildingHeight = 65;
            garageDoor.doorSide = y < CONFIG.world.height / 2 ? 'south' : 'north';
            garageDoor.isGarage = true;
            garageDoor.buildingId = (buildingId || `bld_${x}_${y}`) + '_garage';
            garageDoor.interiorScale = 1.6; // garages are small single-room spaces
            this.buildingDoors.push(garageDoor);
            
            // Driveway from garage to road
            const roadCY = CONFIG.world.height / 2;
            const driveColor = tc(0x3a3a35);
            const driveW = garageW - 4;
            if (y < roadCY) {
                const driveTop = gy + garageH/2 + 10;
                const driveBot = roadCY - 49;
                if (driveBot > driveTop) {
                    this.add.rectangle(gx, (driveTop + driveBot)/2, driveW, driveBot - driveTop, driveColor).setDepth(2);
                }
            } else {
                const driveBot = gy - garageH/2;
                const driveTop = roadCY + 49;
                if (driveBot > driveTop) {
                    this.add.rectangle(gx, (driveTop + driveBot)/2, driveW, driveBot - driveTop, driveColor).setDepth(2);
                }
            }
            
            // Vehicle inside garage (40% chance)
            if (Math.random() < 0.4) {
                this.createGarageVehicle(gx, gy + 2, gDepth);
            }
            
            // Collision wall for garage body (player can't walk through)
            this.addWall(gx, gy, garageW, garageH, 0x3a3832, false);
            
            
        } else if (archetype === 'residential' && Math.random() < 0.4) {
            // === PORCH / STEPS ===
            const porchW = width * 0.35;
            const porchH = 10;
            const px = x + (Math.random() < 0.5 ? -1 : 1) * (width/4);
            const py = y + height/2 + porchH + 2;
            this.add.rectangle(px, py, porchW, porchH, tc(0x3a3530)).setDepth(depth - 0.01);
            // Railing posts
            this.add.rectangle(px - porchW/2 + 3, py - 6, 3, 12, tc(0x4a4a3a)).setDepth(depth - 0.005);
            this.add.rectangle(px + porchW/2 - 3, py - 6, 3, 12, tc(0x4a4a3a)).setDepth(depth - 0.005);
        }
        
        if (archetype === 'commercial' && !damaged) {
            // === STOREFRONT AWNING ===
            const awningColor = tc([0x884433, 0x335544, 0x443366, 0x664433][Math.floor(Math.random() * 4)]);
            const awW = Math.min(width * 0.7, 80);
            const awY = y + height/2 + 6;
            this.add.rectangle(x, awY, awW, 10, awningColor).setDepth(depth + 0.011);
            // Awning stripes
            for (let sx = x - awW/2 + 8; sx < x + awW/2; sx += 12) {
                this.add.rectangle(sx, awY, 2, 8, tc(IsoRenderer.darken(awningColor, 0.3)), 0.4).setDepth(depth + 0.012);
            }
            // Sign text area (rectangle as "sign")
            if (Math.random() < 0.5) {
                this.add.rectangle(x, y - height/2 + 10, width * 0.6, 12, tc(0x2a3030)).setDepth(depth + 0.006);
                this.add.rectangle(x, y - height/2 + 10, width * 0.55, 8, tc(0x3a4040)).setDepth(depth + 0.0065);
            }
        }
        
        if (archetype === 'industrial') {
            // === LOADING DOCK ===
            if (width > 70 && Math.random() < 0.5) {
                const dockW = 35, dockH = 14;
                const dockSide = extraSide;
                const dkX = x + dockSide * (width/2 + dockW/2 - 2);
                const dkY = y + height/2 - dockH/2;
                const dkDepth = 10 + (dkY + dockH) * 0.01;
                
                // Dock platform
                IsoRenderer.cube(this, dkX, dkY, dockW, dockH, 6, 0x3a3a35, { depth: dkDepth });
                // Dock bumpers
                this.add.rectangle(dkX - dockW/4, dkY + dockH/2 + 4, 6, 4, tc(0x1a1a1a)).setDepth(dkDepth + 0.005);
                this.add.rectangle(dkX + dockW/4, dkY + dockH/2 + 4, 6, 4, tc(0x1a1a1a)).setDepth(dkDepth + 0.005);
                
                this.addWall(dkX, dkY, dockW, dockH, 0x3a3a35, false);
            }
            
            // Pipes on side wall
            if (Math.random() < 0.4) {
                const pipeX = x + (extraSide * -1) * (width/2 + 3);
                for (let py = y - height/3; py < y + height/4; py += 18) {
                    this.add.rectangle(pipeX, py, 4, 16, tc(0x4a4a4a)).setDepth(depth + 0.002);
                }
                // Elbow joint
                this.add.circle(pipeX, y - height/3, 3, tc(0x555555)).setDepth(depth + 0.003);
            }
        }
        
        if (archetype === 'civic') {
            // === STEPS WITH HANDRAILS ===
            const stepsW = Math.min(width * 0.5, 50);
            const sy = y + height/2 + 14;
            // Three steps
            for (let s = 0; s < 3; s++) {
                const sw = stepsW - s * 6;
                this.add.rectangle(x, sy + s * 4, sw, 4, tc(0x454540 - s * 0x050505)).setDepth(depth + 0.001 + s * 0.0001);
            }
            // Handrails
            this.add.rectangle(x - stepsW/2 + 3, sy - 6, 3, 22, tc(0x4a4a48)).setDepth(depth + 0.01);
            this.add.rectangle(x + stepsW/2 - 3, sy - 6, 3, 22, tc(0x4a4a48)).setDepth(depth + 0.01);
        }
        
        // === PARKING LOT — commercial, civic, and some industrial buildings ===
        const parkingArchetypes = ['commercial', 'civic'];
        const parkingSubtypes = ['gas_station', 'grocery', 'hardware_store', 'police_station', 'motel', 'diner', 'school'];
        const hasParkingLot = parkingArchetypes.includes(archetype) || parkingSubtypes.includes(subtype);
        
        if (hasParkingLot && Math.random() < 0.75) {
            // Seeded RNG for parking lot — deterministic across scene reloads
            const lotSeedBase = Math.floor(x * 1000 + y * 7919);
            const lotRng = (offset) => {
                let s = (lotSeedBase + offset * 2654435761) & 0x7fffffff;
                s = ((s >> 16) ^ s) * 0x45d9f3b; s = ((s >> 16) ^ s) * 0x45d9f3b; s = (s >> 16) ^ s;
                return (s & 0xffff) / 0xffff;
            };
            let lotRngIdx = 0;
            const lotNext = () => lotRng(lotRngIdx++);
            const lotBetween = (min, max) => Math.floor(lotNext() * (max - min + 1)) + min;
            
            // Parking lot goes to the RIGHT of the building, clamped to world bounds
            const lotW = Math.min(width * 1.2, 160);
            const lotH = 80;
            let lotX = x + width / 2 + lotW / 2 + 15; // right of building with gap
            const lotY = y; // aligned vertically with building
            const worldEdge = (CONFIG.world ? CONFIG.world.width : 800) - 10;
            
            // If lot would overflow right edge, try left side instead
            if (lotX + lotW / 2 > worldEdge) {
                lotX = x - width / 2 - lotW / 2 - 15; // left of building
            }
            // Final clamp
            lotX = Math.max(lotW / 2 + 5, Math.min(lotX, worldEdge - lotW / 2));
            
            const lotDepth = 3;
            
            // Pathway from parking lot to building door
            const pathW = 18;
            const pathLeft = Math.min(x + width / 2, lotX - lotW / 2);
            const pathRight = Math.max(x - width / 2, lotX + lotW / 2);
            const pathLen = Math.abs(lotX - x) - width / 2 - lotW / 2 + 20;
            if (pathLen > 5) {
                const pathCX = (x + lotX) / 2;
                this.add.rectangle(pathCX, y, pathLen, pathW, tc(0x3a3a35)).setDepth(lotDepth - 0.01);
                this.add.rectangle(pathCX, y - pathW / 2, pathLen, 1, tc(0x4a4a40), 0.15).setDepth(lotDepth);
                this.add.rectangle(pathCX, y + pathW / 2, pathLen, 1, tc(0x4a4a40), 0.15).setDepth(lotDepth);
            }
            
            // Asphalt pad
            this.add.rectangle(lotX, lotY, lotW, lotH, tc(0x2a2a28)).setDepth(lotDepth);
            this.add.rectangle(lotX, lotY, lotW - 2, lotH - 2, tc(0x2e2e2b)).setDepth(lotDepth + 0.001);
            
            // Parking lines — ¾ iso perspective: horizontal stripes separating spaces
            // Camera is above+south, so we see cars from above-front.
            // Lines run LEFT-RIGHT (horizontal) between parking spaces stacked NORTH-SOUTH.
            // This means lines are perpendicular to the vehicle facing direction.
            const spotH = 28; // height of each parking space
            const numSpots = Math.floor(lotH / spotH);
            for (let s = 0; s <= numSpots; s++) {
                const ly = lotY - lotH / 2 + s * spotH;
                this.add.rectangle(lotX, ly, lotW * 0.85, 1, tc(0x4a4a44), 0.25).setDepth(lotDepth + 0.002);
            }
            
            // Parked vehicles (1-3, seeded, placed within spaces)
            const numCars = 1 + Math.floor(lotNext() * 2);
            const usedSpots = new Set();
            for (let c = 0; c < numCars; c++) {
                let carSpot;
                let attempts = 0;
                do {
                    carSpot = Math.floor(lotNext() * numSpots);
                    attempts++;
                } while (usedSpots.has(carSpot) && attempts < 8);
                usedSpots.add(carSpot);
                
                const carX = lotX + (lotNext() - 0.5) * lotW * 0.3;
                const carY = lotY - lotH / 2 + carSpot * spotH + spotH / 2;
                // Use PropRenderer for proper ¾ iso car rendering
                if (lotNext() < 0.35) {
                    PropRenderer.createTruckWreck(this, carX, carY);
                } else {
                    PropRenderer.createCarWreck(this, carX, carY);
                }
            }
            
            // Light pole at lot edge
            if (lotNext() < 0.6) {
                const poleX = lotX + (lotNext() < 0.5 ? -1 : 1) * (lotW / 2 - 5);
                const poleY = lotY - lotH / 3;
                IsoRenderer.pole(this, poleX, poleY, 3, 30, 0x5a5a5a, { depth: lotDepth + 3 });
                this.add.rectangle(poleX, poleY - 28, 8, 3, tc(0x888888)).setDepth(lotDepth + 3.1);
            }
        }
        
        // === GAS STATION CANOPY — only for gas_station subtype ===
        if (subtype === 'gas_station') {
            const canopySide = (y < CONFIG.world.height / 2) ? 1 : -1;
            const canopyX = x;
            const canopyY = y + canopySide * (height / 2 + 40);
            const canopyW = Math.min(width * 0.9, 80);
            const canopyH = 40;
            
            // Build canopy with overhead zone
            const canopy = OverheadZone.gasStationCanopy(this, canopyX, canopyY, canopyW, canopyH, {
                color: 0x555555, depth: 50
            });
            
            // Fuel pumps under canopy (modular)
            const pumpCount = 2;
            for (let p = 0; p < pumpCount; p++) {
                const pumpX = canopyX + (p - 0.5) * 28;
                const pumpY = canopyY;
                if (ISO_DEFS.fuel_pump) {
                    IsoRenderer.render(ISO_DEFS.fuel_pump, {
                        scene: this, x: pumpX, y: pumpY,
                        scale: 0.7, wall: 'front',
                        depth: 20 + pumpY * 0.01,
                        damage: damaged ? 0.4 : Math.random() * 0.1
                    });
                    this.addWall(pumpX, pumpY, 8, 18, 0x000000, false);
                }
            }
        }
    }
    
    // Render a small vehicle visible inside/near a garage
    createGarageVehicle(x, y, depth) {
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const palettes = [
            { body: 0x445566, dark: 0x2a3540, light: 0x556677 },
            { body: 0x554433, dark: 0x3a2a20, light: 0x665544 },
            { body: 0x664444, dark: 0x4a2a2a, light: 0x775555 },
            { body: 0x555555, dark: 0x353535, light: 0x666666 },
        ];
        const pal = palettes[Math.floor(Math.random() * palettes.length)];
        const d = depth + 0.005;
        
        // ¾ iso compact vehicle peeking through garage door
        // Front face (north) wide, thin foreshortened top, side depth sliver
        const bW = 52, bH = 26;
        
        // Wheels (below body)
        this.add.ellipse(x - 8, y + bH/2 + 1, 6, 3, 0x1a1a1a).setDepth(d - 0.003);
        this.add.ellipse(x + 8, y + bH/2 + 1, 6, 3, 0x1a1a1a).setDepth(d - 0.003);
        this.add.ellipse(x - 8, y + bH/2 + 1, 3, 2, tc(0x2a2a2a)).setDepth(d - 0.002);
        this.add.ellipse(x + 8, y + bH/2 + 1, 3, 2, tc(0x2a2a2a)).setDepth(d - 0.002);
        
        // Body — lower front face (wide, dominant)
        this.add.rectangle(x, y + bH * 0.1, bW, bH * 0.5, tc(pal.dark)).setDepth(d);
        // Body — upper front face
        this.add.rectangle(x, y - bH * 0.1, bW - 2, bH * 0.3, tc(pal.body)).setDepth(d + 0.001);
        
        // Side depth edge (east, narrow 3px sliver)
        this.add.rectangle(x + bW/2 + 1, y, 3, bH * 0.55, tc(IsoRenderer.darken(pal.body, 0.2))).setDepth(d + 0.0005);
        
        // Cabin (raised center section — front face showing depth)
        const cabW = bW * 0.4;
        this.add.rectangle(x - 1, y - bH * 0.22, cabW, bH * 0.22, tc(pal.dark)).setDepth(d + 0.003);
        // Roof top strip (foreshortened)
        this.add.rectangle(x - 1, y - bH * 0.32, cabW - 2, bH * 0.1, tc(pal.body)).setDepth(d + 0.004);
        // Windshield (dark)
        this.add.rectangle(x, y - bH * 0.14, cabW * 0.7, bH * 0.15, tc(0x1a2530)).setDepth(d + 0.0035);
        
        // Hood (right of cabin, lower)
        this.add.rectangle(x + bW/2 - 5, y - bH * 0.02, 7, bH * 0.38, tc(pal.body)).setDepth(d + 0.002);
        // Headlight dot
        this.add.rectangle(x + bW/2 - 4, y + bH * 0.12, 3, 2, tc(0xaaaa66)).setDepth(d + 0.0025);
    }
    
    // Create a siphon-able vehicle wreck (interactive)
    createSiphonVehicle(x, y, vehicleType) {
        const biome = CONFIG.currentBiome ? CONFIG.currentBiome.type : 'grassy';
        
        // Map old vehicleType to fleet types
        const typeMap = { truck: 'cargo', suv: 'suv', compact: 'pickup' };
        const fleetType = typeMap[vehicleType] || VehicleFleet.randomWreckType();
        
        // Pick random facing direction
        const dirs = ['down', 'right', 'up', 'left'];
        const dir = dirs[Phaser.Math.Between(0, 3)];
        
        VehicleFleet.registerTextures(this);
        const frame = VehicleFleet.getFrame(fleetType, dir, true);
        const d = 10 + y * 0.01;
        const sprite = this.add.sprite(x, y, 'fleet_all', frame).setDepth(d);
        
        // Size based on type
        const isLarge = (fleetType === 'cargo' || fleetType === 'humvee');
        const vw = isLarge ? 68 : 56;
        const vh = isLarge ? 30 : 26;
        
        // Ground shadow
        this.add.ellipse(x, y + vh/2 + 4, vw * 0.85, vh * 0.45, 0x000000, 0.3).setDepth(d - 0.01);
        
        // Overgrowth
        if (biome !== 'barren' && biome !== 'apocalyptic') {
            const grassCol = 0x3a5a2a;
            for (let w = 0; w < Phaser.Math.Between(2, 4); w++) {
                const wx = x + Phaser.Math.Between(-vw/2, vw/2);
                const wy = y + vh/2 + Phaser.Math.Between(-2, 6);
                this.add.rectangle(wx, wy - 3, 2, Phaser.Math.Between(5, 9), grassCol, 0.45)
                    .setAngle(Phaser.Math.Between(-15, 15)).setDepth(d + 0.011);
            }
        }
        
        // Collision wall
        this.addWall(x, y, vw * 0.75, vh * 0.75, 0x000000, false);
        
        // Siphon interaction zone
        const zone = this.add.zone(x, y, vw + 20, vh + 20);
        this.physics.add.existing(zone, true);
        
        const hasFuel = biome === 'grassy' ? Math.random() < 0.55 :
                        biome === 'barren' ? Math.random() < 0.35 :
                        Math.random() < 0.2;
        const fuelAmount = hasFuel ? Phaser.Math.Between(2, 8) : 0;
        
        zone._siphon = {
            hasFuel: hasFuel,
            fuelAmount: fuelAmount,
            siphoned: false,
            vehicleType: vehicleType
        };
        
        if (!this.siphonVehicles) this.siphonVehicles = [];
        this.siphonVehicles.push(zone);
    }

    createUI() {
        const uiDepth = 100;
        
        // ── Survivor HUD panel (top-right — name, level, title, HP bar) ──
        // Load save data for stash currencies
        let saveD = null; try { saveD = SaveManager.load(); } catch(e) {}
        const stashRef = saveD ? saveD.stash : {};
        this.hud = GameHUD.create(this, {
            resources: {
                bits: 0,
                mag: this._magazineMax || 12,
                fuel: stashRef.fuel || 0,
                materials: stashRef.materials || 0
            },
            combat: true,
            survivor: this.deployedSurvivor || null
        });
        
        // Wire legacy text refs (populated when dropdown expands)
        this.magText = this.hud._texts.mag || null;
        this.bitsText = this.hud._texts.bits || null;
        
        // Kills counter (top-left, small)
        this.killsText = this.add.text(15, 38, 'KILLS: 0', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#667' }).setScrollFactor(0).setDepth(uiDepth);
        
        // ── Time of day + Location (center, stylized) ──
        const timeNames = { dawn: 'DAWN', midday: 'MIDDAY', dusk: 'DUSK', night: 'NIGHT' };
        const timeColors = { dawn: '#cc9966', midday: '#bbaa88', dusk: '#cc7755', night: '#6677aa' };
        const locColors = { dawn: '#ddbb88', midday: '#ccbb99', dusk: '#dd9977', night: '#8899bb' };
        const tod = CONFIG.timeOfDay || 'midday';
        
        this.timeText = this.add.text(CONFIG.width/2, 14, timeNames[tod] || 'MIDDAY', { 
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: timeColors[tod] || '#888',
            letterSpacing: 6
        }).setOrigin(0.5).setScrollFactor(0).setDepth(uiDepth).setAlpha(0);
        
        const routeName = this.routeName || (CONFIG.biomes[CONFIG.currentBiome.type] ? CONFIG.biomes[CONFIG.currentBiome.type].name : 'Unknown');
        this.routeText = this.add.text(CONFIG.width/2, 28, routeName, { 
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: locColors[tod] || '#aa8866', fontStyle: 'bold'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(uiDepth).setAlpha(0);
        
        // Fade in, hold, fade out
        this.tweens.add({ targets: [this.timeText, this.routeText], alpha: 1, duration: 600, ease: 'Sine.easeIn',
            onComplete: () => {
                this.time.delayedCall(3000, () => {
                    this.tweens.add({ targets: [this.timeText, this.routeText], alpha: 0, duration: 1500, ease: 'Power2' });
                });
            }
        });
        
        // ── Bottom-right action cluster ──
        // Ammo HUD (top of cluster)
        const clusterX = CONFIG.width - 40;
        this._ammoHud = UIManager.createAmmoHud(this, clusterX, CONFIG.height - 60, { depth: uiDepth + 1 });
        this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
        
        // Power ammo toggle handler
        this._togglePowerAmmo = () => {
            const wasActive = this.state._powerAmmoActive;
            if (!wasActive && (this.state.powerAmmo || 0) <= 0) {
                AudioManager.emptyClip();
                Haptics.error();
                return;
            }
            this.state._powerAmmoActive = !wasActive;
            // Immediate visual feedback BEFORE reload spinner
            if (this._ammoHud) this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
            const blurb = wasActive ? 'Loading Regular Ammo' : 'Loading Power Ammo';
            this._startReload(blurb);
        };
        const btnY = CONFIG.height - 26;
        this.consumeBtn = GameHUD.createActionButton(this, clusterX - 20, btnY, {
            iconKey: 'ui_icon_heal', label: 'USE', depth: uiDepth, size: 30
        });
        this.consumeIcon = this.consumeBtn._label;
        this.consumeCount = this.add.text(clusterX - 20, btnY + 18, '', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#44aa44' }).setOrigin(0.5).setScrollFactor(0).setDepth(uiDepth + 1);
        
        this.invBtn = GameHUD.createActionButton(this, clusterX + 18, btnY, {
            iconKey: 'ui_icon_backpack', label: 'INV', depth: uiDepth, size: 30
        });
        this.invBtnIcon = this.invBtn._label;
        
        // Augment ability button (left of USE)
        const rlcX = clusterX - 56, rlcY = btnY;
        this.relicBtnContainer = GameHUD.createActionButton(this, rlcX, rlcY, {
            iconKey: 'ui_icon_cube', label: 'RLC', depth: uiDepth, visible: false, size: 30
        });
        this.relicBtnBg = this.relicBtnContainer;
        this.relicBtn = this.relicBtnContainer;
        this.relicIcon = this.add.text(rlcX, rlcY - 3, '', { fontFamily: CONFIG.font, fontSize: uiPx(12) }).setOrigin(0.5).setScrollFactor(0).setDepth(uiDepth + 1).setVisible(false);
        this.relicCooldownText = this.add.text(rlcX, rlcY, '', { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#ff4466', fontStyle: 'bold', stroke: '#000000', strokeThickness: 3 }).setOrigin(0.5).setScrollFactor(0).setDepth(uiDepth + 3).setVisible(false);
        this.relicActiveText = this.add.text(rlcX, rlcY - 22, '', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#44ffaa', fontStyle: 'bold', stroke: '#000000', strokeThickness: 3 }).setOrigin(0.5).setScrollFactor(0).setDepth(uiDepth + 3).setVisible(false);
        this.relicCooldownOverlay = this.add.rectangle(rlcX, rlcY, 30, 30, 0x000000, 0.55).setScrollFactor(0).setDepth(uiDepth + 0.5).setVisible(false);
        // Relic state
        this._relicCooldownEnd = 0;
        this._relicActiveEnd = 0;
        this._relicStates = {};
        // Store cluster coords for input detection
        this._clusterX = clusterX;
        this._btnY = btnY;
        this._rlcX = rlcX;
        
        
        // Boss health bar (UIManager — hidden until boss spawns)
        this.bossHP = UIManager.createHealthBar(this, 'boss', {
            x: CONFIG.width/2, y: 130, depth: uiDepth, scrollFactor: 0, name: 'THE TESSERACT'
        });
        this.bossHP.setVisible(false);
        
        // Death screen
        this.deathScreen = this.add.container(CONFIG.width/2, CONFIG.height/2).setScrollFactor(0).setVisible(false).setDepth(7.5);
        this.deathScreen.add(this.add.rectangle(0, 0, CONFIG.width, CONFIG.height, 0x000000, 0.85));
        // GrimFont death title
        GrimFont.build(this);
        const deathTitle = GrimFont.drawText(this, 0, -60, 'CUBED', { scale: 1.3, rust: true, depth: 201, center: true });
        this.deathScreen.add(deathTitle);
        this.deathKills = this.add.text(0, -10, 'Kills: 0', { fontFamily: CONFIG.font, fontSize: uiPx(18), fill: '#fff' }).setOrigin(0.5);
        this.deathScreen.add(this.deathKills);
        this.deathLost = this.add.text(0, 20, '', { fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#aa4444', align: 'center' }).setOrigin(0.5);
        this.deathScreen.add(this.deathLost);
        const retBtn = UIManager.createButton(this, 0, 65, '[ TAP TO RETURN ]', { width: 160, height: 30, depth: 201 });
        this.deathScreen.add(retBtn);
    }

    setupInput() {
        this.swipes = {};
        this.movePointer = null;
        this.moveAnchor = { x: 0, y: 0 };

        this.input.on('pointerdown', (p) => {
            if (this.inventoryUI || this.vehicleMenu || this.popupActive) return; // Don't process scene input when any UI open
            if (this.state.dead) { 
                this.scene.start('SafehouseScene', SceneTransition.safehouseReturnData(this, { died: true })); 
                return; 
            }
            
            // Check inventory button (bottom-right cluster)
            const cx = this._clusterX || (CONFIG.width - 40);
            const by = this._btnY || (CONFIG.height - 26);
            const invDist = Phaser.Math.Distance.Between(p.x, p.y, cx + 18, by);
            if (invDist < 20) {
                this.openInventory();
                return;
            }
            
            // Check consumable quick-use button
            const consDist = Phaser.Math.Distance.Between(p.x, p.y, cx - 20, by);
            if (consDist < 20) {
                this.quickUseConsumable();
                return;
            }
            
            // Check active relic button
            if (this.relicBtnBg && this.relicBtnBg.visible) {
                const relicDist = Phaser.Math.Distance.Between(p.x, p.y, this._rlcX || (cx - 56), by);
                if (relicDist < 20) {
                    this.activateRelic();
                    return;
                }
            }
            
            // Tap-to-interact on highlighted world objects
            if (InteractHighlight.getTarget(this)) {
                const cam = this.cameras.main;
                const wx = p.x + cam.scrollX;
                const wy = p.y + cam.scrollY;
                if (InteractHighlight.checkTap(this, wx, wy, 55)) {
                    AudioManager.uiClick();
                    Haptics.light();
                    this.handleInteract();
                    return;
                }
            }
            
            
            this.swipes[p.id] = { x: p.x, y: p.y, t: Date.now() };
            if (!this.movePointer) {
                this.movePointer = p;
                this.moveAnchor = { x: p.x, y: p.y };
            }
        });

        this.input.on('pointermove', (p) => {
            if (this.movePointer && p.id === this.movePointer.id) {
                const dx = p.x - this.moveAnchor.x;
                const dy = p.y - this.moveAnchor.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist > 3) {
                    const f = Math.min(dist / 40, 1);
                    this.moveDir = { x: (dx/dist)*f, y: (dy/dist)*f };
                    if (dist > 60) {
                        this.moveAnchor.x = p.x - (dx/dist)*40;
                        this.moveAnchor.y = p.y - (dy/dist)*40;
                    }
                } else {
                    this.moveDir = { x: 0, y: 0 };
                }
            }
        });

        this.input.on('pointerup', (p) => {
            const sw = this.swipes[p.id];
            if (sw) {
                const dx = p.x - sw.x, dy = p.y - sw.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                const elapsed = Date.now() - sw.t;
                if (dist >= CONFIG.swipeThreshold && elapsed <= CONFIG.swipeTime) {
                    this.dodge(dx, dy);
                } else if (dist < 25 && elapsed < 300) {
                    // Quick tap — switch target or unlock current
                    this.tapSwitchTarget(p.x, p.y);
                }
                delete this.swipes[p.id];
            }
            if (this.movePointer && p.id === this.movePointer.id) {
                this.movePointer = null;
                this.moveDir = { x: 0, y: 0 };
            }
        });
    }
    
    
    
    returnToMap() {
        if (this._departing) return;
        this._departing = true;
        
        // If we have a parked vehicle, animate departure
        if (this.parkedVehicle && this.parkedVehicleSprite) {
            const vx = this.parkedVehicle.x;
            const vy = this.parkedVehicle.y;
            
            // Player walks to vehicle
            this.tweens.add({
                targets: this.player,
                x: vx,
                y: vy,
                duration: 500,
                ease: 'Sine.easeInOut',
                onUpdate: () => {
                    if (this.player.backpack) {
                        this.player.backpack.x = this.player.x;
                        this.player.backpack.y = this.player.y - 4;
                    }
                },
                onComplete: () => {
                    // Player enters vehicle
                    this.player.setVisible(false);
                    if (this.player.backpack) this.player.backpack.setVisible(false);
                    if (this.player._crownSprite) this.player._crownSprite.setVisible(false);
                    
                    this.time.delayedCall(300, () => {
                        // Engine start rumble
                        this.tweens.add({
                            targets: this.parkedVehicleSprite,
                            x: this.parkedVehicleSprite.x + 1,
                            duration: 40, yoyo: true, repeat: 6
                        });
                        
                        // Exhaust puffs
                        for (let p = 0; p < 5; p++) {
                            this.time.delayedCall(p * 100, () => {
                                if (!this.parkedVehicleSprite) return;
                                const puff = this.add.circle(
                                    this.parkedVehicleSprite.x - 30,
                                    vy + 14 + Phaser.Math.Between(-3, 3),
                                    Phaser.Math.Between(2, 5), 0x777777, 0.5
                                ).setDepth(7.5);
                                this.tweens.add({
                                    targets: puff,
                                    x: puff.x - 20, y: puff.y - 5,
                                    alpha: 0, scaleX: 2, scaleY: 1.5,
                                    duration: 500,
                                    onComplete: () => puff.destroy()
                                });
                            });
                        }
                        
                        // Drive off to the right
                        this.time.delayedCall(500, () => {
                            // Acceleration exhaust
                            for (let p = 0; p < 6; p++) {
                                this.time.delayedCall(p * 70, () => {
                                    if (!this.parkedVehicleSprite) return;
                                    const puff = this.add.circle(
                                        this.parkedVehicleSprite.x - 28,
                                        vy + 14 + Phaser.Math.Between(-2, 4),
                                        Phaser.Math.Between(3, 6), 0x666666, 0.5
                                    ).setDepth(7.5);
                                    this.tweens.add({
                                        targets: puff,
                                        x: puff.x - 25, y: puff.y + Phaser.Math.Between(-3, 3),
                                        alpha: 0, scaleX: 2.5, scaleY: 1.5,
                                        duration: 600,
                                        onComplete: () => puff.destroy()
                                    });
                                });
                            }
                            
                            this.tweens.add({
                                targets: this.parkedVehicleSprite,
                                x: this.parkedVehicleSprite.x + CONFIG.world.width + 100,
                                duration: 1000,
                                ease: 'Quad.easeIn'
                            });
                            
                            // Fade to black and transition
                            const overlay = this.add.rectangle(
                                this.cameras.main.scrollX + CONFIG.width / 2,
                                this.cameras.main.scrollY + CONFIG.height / 2,
                                CONFIG.width, CONFIG.height, 0x000000, 0
                            ).setDepth(300).setScrollFactor(0);
                            this.tweens.add({
                                targets: overlay,
                                alpha: 1, duration: 700, delay: 400,
                                onComplete: () => {
                                    this.scene.start('MapScene', SceneTransition.mapReturnData(this));
                                }
                            });
                        });
                    });
                }
            });
        } else {
            // No vehicle — simple fade
            SceneTransition.fadeTo(this, 'MapScene', SceneTransition.mapReturnData(this), { duration: 300 });
        }
    }
    
    // === VEHICLE ARRIVAL/DEPARTURE ANIMATIONS ===
    playVehicleArrival(vehicleSprite, targetX, targetY) {
        // Block gameplay during arrival
        this._arrivalActive = true;
        // Safety timeout — if tween chain breaks, ensure gameplay isn't permanently blocked
        this.time.delayedCall(6000, () => {
            if (this._arrivalActive) {
                this._arrivalActive = false;
                if (this.player) {
                    this.player.setVisible(true);
                    if (this.player.backpack) this.player.backpack.setVisible(true);
                    if (this.player._crownSprite) this.player._crownSprite.setVisible(true);
                }
                this.cameras.main.startFollow(this.player, true, 1, 1);
            }
        });
        
        // Point camera at arrival zone, stop following player during animation
        this.cameras.main.stopFollow();
        this.cameras.main.centerOn(targetX, targetY);
        
        // Exhaust during drive-in
        for (let p = 0; p < 5; p++) {
            this.time.delayedCall(80 + p * 100, () => {
                if (!vehicleSprite || !vehicleSprite.active) return;
                const puff = this.add.circle(
                    vehicleSprite.x - 30,
                    targetY + 14 + Phaser.Math.Between(-2, 2),
                    Phaser.Math.Between(2, 5), 0x777777, 0.4
                ).setDepth(7.5);
                this.tweens.add({
                    targets: puff,
                    x: puff.x - Phaser.Math.Between(15, 30),
                    y: puff.y - Phaser.Math.Between(2, 8),
                    alpha: 0, scaleX: 2, scaleY: 1.5,
                    duration: 500,
                    onComplete: () => puff.destroy()
                });
            });
        }
        
        // Drive to parking spot
        this.tweens.add({
            targets: vehicleSprite,
            x: targetX,
            duration: 800,
            ease: 'Quad.easeOut',
            onComplete: () => {
                // Settle exhaust
                const settle = this.add.circle(targetX - 30, targetY + 14, 4, 0x666666, 0.3).setDepth(9);
                this.tweens.add({
                    targets: settle,
                    x: settle.x - 15, y: settle.y - 5,
                    alpha: 0, scaleX: 2.5, scaleY: 2,
                    duration: 700,
                    onComplete: () => settle.destroy()
                });
                
                // Player exits vehicle after a beat
                this.time.delayedCall(300, () => {
                    if (this.player) {
                        this.player.x = targetX;
                        this.player.y = targetY;
                        this.player.setVisible(true);
                        // Show and sync backpack
                        if (this.player.backpack) {
                            this.player.backpack.setVisible(true);
                            this.player.backpack.x = targetX;
                            this.player.backpack.y = targetY - 4;
                        }
                        // Walk away from vehicle
                        const bpTargets = this.player.backpack ? [this.player, this.player.backpack] : [this.player];
                        this.tweens.add({
                            targets: this.player,
                            x: targetX + 40,
                            y: targetY + 20,
                            duration: 400,
                            ease: 'Sine.easeOut',
                            onUpdate: () => {
                                if (this.player.backpack) {
                                    this.player.backpack.x = this.player.x;
                                    this.player.backpack.y = this.player.y - 4;
                                }
                            },
                            onComplete: () => {
                                // Resume camera following player
                                this.cameras.main.startFollow(this.player, true, 1, 1);
                                this._arrivalActive = false;
                            }
                        });
                    } else {
                        this.cameras.main.startFollow(this.player, true, 1, 1);
                        this._arrivalActive = false;
                    }
                });
            }
        });
    }
    
    setupGameMode() {
        const biomeConfig = CONFIG.biomes[CONFIG.currentBiome.type];
        const reach = this.destinationNode?.reach || 1;
        
        switch (this.gameMode) {
            case 'defense': {
                // === FOUNDRY CONVOY DEFENSE — narrative-driven wave defense ===
                // Player discovers a stranded Foundry convoy in the procedural biome
                // NPC dialogue triggers the event — no auto-combat
                
                // Select random foundry for this event
                const foundryIds = Object.keys(CONFIG.foundries);
                const foundryId = foundryIds[Math.floor(Math.random() * foundryIds.length)];
                const foundry = CONFIG.foundries[foundryId];
                
                // Pick quest-giver name
                const namePool = DEFENSE_DATA.foundryNames[foundryId] || DEFENSE_DATA.foundryNames.terracorp;
                const questGiverName = namePool[Math.floor(Math.random() * namePool.length)];
                // Pick soldier names (unique from quest-giver)
                const soldierNames = namePool.filter(n => n !== questGiverName).sort(() => Math.random() - 0.5).slice(0, 2);
                
                this.modeState = {
                    // Core
                    wavesTotal: 12,
                    wavesCurrent: 0,
                    enemiesInWave: 0,
                    enemiesSpawned: 0,
                    phase: 'discovery', // discovery → dialogue → prepare → spawning → wave → intermission → checkpoint → complete/failed
                    
                    // Foundry
                    foundryId: foundryId,
                    foundry: foundry,
                    questGiverName: questGiverName,
                    soldierNames: soldierNames,
                    
                    // Convoy
                    caravanHp: 80,
                    caravanMaxHp: 80,
                    repairStage: 0, // 0-4
                    
                    // Soldiers
                    soldiers: [],
                    
                    // Upgrades
                    shieldType: null,
                    shieldHp: 0,
                    shieldMaxHp: 0,
                    shieldCooldown: 0,
                    shieldActive: false,
                    turretInstalled: false,
                    turretMounted: false,
                    turretHeat: 0,
                    turretOverheated: false,
                    arsenalUpgraded: false,
                    powerSurge: false,
                    reinforcementsArrived: false,
                    lootQualityBonus: 0,
                    
                    // Tracking
                    totalKills: 0,
                    bitsEarned: 0,
                    wavesCompleted: 0,
                    extractReady: false
                };
                
                // Place Foundry convoy and NPCs in the procedural biome
                this.createFoundryConvoy();
                this.createFoundrySoldiers();
                
                // No announcement, no auto-start — player discovers convoy naturally
                break;
            }
            case 'boss': {
                // Boss fight — phase-based encounter
                const bossIndex = Math.min(4, Math.floor((reach - 1) / 2)); // 0-4 maps to 5 boss types
                const bossTypes = ['warden', 'swarmQueen', 'phantom', 'ironclad', 'cubeAnomaly'];
                const bossType = bossTypes[bossIndex];
                
                this.modeState = { 
                    phase: 'intro', 
                    bossType: bossType,
                    bossEntity: null,
                    bossHp: 0,
                    bossMaxHp: 0,
                    bossPhase: 1,
                    bossAttackTimer: 0,
                    bossSpecialTimer: 0,
                    addsTimer: 0,
                    reach: reach
                };
                
                const bossDisplayNames = {
                    warden: 'THE WARDEN',
                    swarmQueen: 'THE SWARM QUEEN', 
                    phantom: 'THE PHANTOM',
                    ironclad: 'THE IRONCLAD',
                    cubeAnomaly: 'THE CUBE ANOMALY'
                };
                
                const bossSubtitles = {
                    warden: 'The ground trembles.',
                    swarmQueen: 'Something stirs in the nest.',
                    phantom: 'The air grows cold.',
                    ironclad: 'Steel groans in the distance.',
                    cubeAnomaly: 'Reality fractures.'
                };
                
                // === BOSS-SPECIFIC BUILDUP SEQUENCE ===
                // Phase 1: Quiet tension (0-1.5s)
                this.showModeAnnouncement(bossSubtitles[bossType] || 'Something approaches...', '');
                
                // Phase 2: Environmental warnings (1.5-3.5s)
                this.time.delayedCall(1500, () => {
                    const cx = CONFIG.world.width / 2, cy = CONFIG.world.height / 2 - 60;
                    
                    if (bossType === 'warden') {
                        // Distant thuds — screen shakes getting closer
                        for (let i = 0; i < 4; i++) {
                            this.time.delayedCall(i * 500, () => {
                                this.cameras.main.shake(80 + i * 60, 0.003 + i * 0.003);
                                // Dust particles from ground
                                for (let j = 0; j < 3; j++) {
                                    const dp = this.add.circle(cx + Phaser.Math.Between(-80, 80), cy + Phaser.Math.Between(40, 100), 2, 0x887766, 0.4).setDepth(22);
                                    this.tweens.add({ targets: dp, y: dp.y - Phaser.Math.Between(8, 20), alpha: 0, duration: 600, onComplete: () => dp.destroy() });
                                }
                            });
                        }
                    } else if (bossType === 'swarmQueen') {
                        // Chittering sounds — small bugs skitter across the ground
                        for (let i = 0; i < 8; i++) {
                            this.time.delayedCall(i * 200, () => {
                                const bx = Phaser.Math.Between(60, CONFIG.world.width - 60);
                                const by = Phaser.Math.Between(60, CONFIG.world.height - 60);
                                const bug = this.add.circle(bx, by, 2, 0x44aa44, 0.5).setDepth(22);
                                const tx = cx + Phaser.Math.Between(-30, 30), ty = cy + Phaser.Math.Between(-30, 30);
                                this.tweens.add({ targets: bug, x: tx, y: ty, alpha: 0, duration: 800, onComplete: () => bug.destroy() });
                            });
                        }
                        // Egg pulse
                        this.cameras.main.flash(200, 68, 170, 68, true, null, 0.15);
                    } else if (bossType === 'phantom') {
                        // Temperature drop — screen darkens, wisps flicker
                        const dark = this.add.rectangle(CONFIG.width/2, CONFIG.height/2, CONFIG.width, CONFIG.height, 0x000000, 0).setDepth(90).setScrollFactor(0);
                        this.tweens.add({ targets: dark, alpha: 0.25, duration: 2000, yoyo: true, hold: 500 });
                        // Wisps converge
                        for (let i = 0; i < 6; i++) {
                            this.time.delayedCall(i * 300, () => {
                                const wa = Math.random() * Math.PI * 2, wd = 120;
                                const wisp = this.add.circle(cx + Math.cos(wa) * wd, cy + Math.sin(wa) * wd, 3, 0xaa88ff, 0.4).setDepth(22);
                                this.tweens.add({ targets: wisp, x: cx, y: cy, alpha: 0, duration: 1000, onComplete: () => wisp.destroy() });
                            });
                        }
                    } else if (bossType === 'ironclad') {
                        // Mechanical startup — sparks, grinding
                        for (let i = 0; i < 3; i++) {
                            this.time.delayedCall(i * 600, () => {
                                this.cameras.main.shake(60, 0.004);
                                // Sparks shower from above
                                for (let j = 0; j < 5; j++) {
                                    const sx = cx + Phaser.Math.Between(-40, 40);
                                    const sp = this.add.circle(sx, cy - 40, 2, 0xffcc44, 0.7).setDepth(25);
                                    this.tweens.add({ targets: sp, y: cy + Phaser.Math.Between(10, 40), x: sp.x + Phaser.Math.Between(-15, 15), alpha: 0, duration: 400, onComplete: () => sp.destroy() });
                                }
                            });
                        }
                    } else if (bossType === 'cubeAnomaly') {
                        // Reality fracture — screen glitches, purple flashes
                        for (let i = 0; i < 5; i++) {
                            this.time.delayedCall(i * 400, () => {
                                this.cameras.main.flash(80, 136, 0, 255, true, null, 0.2);
                                // Screen offset glitch
                                const ox = Phaser.Math.Between(-3, 3), oy = Phaser.Math.Between(-2, 2);
                                this.cameras.main.setScroll(this.cameras.main.scrollX + ox, this.cameras.main.scrollY + oy);
                                // Void crack
                                const vg = this.add.graphics().setDepth(24);
                                const vx = Phaser.Math.Between(40, CONFIG.world.width - 40), vy = Phaser.Math.Between(40, CONFIG.world.height - 40);
                                vg.lineStyle(2, 0x8800ff, 0.5);
                                vg.lineBetween(vx, vy, vx + Phaser.Math.Between(-30, 30), vy + Phaser.Math.Between(-30, 30));
                                this.tweens.add({ targets: vg, alpha: 0, duration: 1500, onComplete: () => vg.destroy() });
                            });
                        }
                    }
                });
                
                // Phase 3: Name reveal + spawn (3.5s)
                this.time.delayedCall(3500, () => {
                    this.showModeAnnouncement('' + (bossDisplayNames[bossType] || 'BOSS'), '');
                });
                
                // Phase 4: Boss materializes (4.5s)
                this.time.delayedCall(4500, () => BossAI.spawnBossEntity(this));
                break;
            }
            // horde case removed - deprecated
            // story case removed - deprecated
            // breakdown case removed - deprecated
            // encounter case removed - deprecated
            // scavenge_event case removed - deprecated
            default: {
                // Scavenge (default) — pre-placed enemies + escalating reinforcements
                const [minEnemies, maxEnemies] = biomeConfig.enemyCount;
                const scavReach = this.destinationNode?.reach || 1;
                const scavReachMult = 1 + (scavReach - 1) * 0.15;
                let initialCount = Math.round(Phaser.Math.Between(minEnemies, Math.floor((minEnemies + maxEnemies) / 2)) * scavReachMult);
                
                // Location enemy modifier
                const locCfg = this.locationType ? CONFIG.locations[this.locationType] : null;
                if (locCfg?.enemyMod) {
                    initialCount = Math.max(1, Math.round(initialCount * locCfg.enemyMod));
                }
                
                // Story event: reduced enemies (safe_entry outcome)
                if (this.reducedEnemies) {
                    initialCount = Math.max(1, Math.floor(initialCount * 0.5));
                }
                
                // Story event: alarm triggered — extra enemies
                if (this.alarmTriggered) {
                    initialCount = Math.round(initialCount * 1.5);
                }
                
                // Pre-place enemies far from player entry (already patrolling when player arrives)
                this._prePlaceEnemies(initialCount);
                
                // Start escalation timer — reinforcements from edges after initial quiet period
                this._startEscalation(scavReach);
                
                // Story event: ambush — extra enemies after a delay
                if (this.ambushEnemies > 0) {
                    this.time.delayedCall(4000, () => {
                        this.showModeAnnouncement('AMBUSH!', 'Enemies incoming!', true);
                        this.time.delayedCall(1000, () => this.spawnEdgeWave(this.ambushEnemies));
                    });
                }
                
                break;
            }
        }
        
        // === RESCUE ENCOUNTER — trapped survivor NPC ===
        if (this.rescueMode && !this._rescueTriggered) {
            this._rescueTriggered = true;
            const reach = this.destinationNode?.reach || 1;
            const rescueSeed = Date.now() + (this.mapSeed || 0);
            // Rarity scales with reach
            const rarityRoll = Math.random() * 100;
            let rescueRarity = 'common';
            if (reach >= 4 && rarityRoll < 5) rescueRarity = 'legendary';
            else if (reach >= 3 && rarityRoll < 15) rescueRarity = 'rare';
            else if (reach >= 2 && rarityRoll < 35) rescueRarity = 'uncommon';
            this._rescueSurvivor = SurvivorGenerator.generate(rescueSeed, rescueRarity);
            
            // Pick spawn point far from player
            const rpx = this.player?.x || CONFIG.world.width / 2;
            const rpy = this.player?.y || CONFIG.world.height / 2;
            let bestPt = null, bestDist = 0;
            for (const pt of (this.spawnPoints || [])) {
                const d = Phaser.Math.Distance.Between(pt.x, pt.y, rpx, rpy);
                if (d > bestDist) { bestDist = d; bestPt = pt; }
            }
            const rsx = bestPt ? bestPt.x + Phaser.Math.Between(-20, 20) : CONFIG.world.width * 0.75;
            const rsy = bestPt ? bestPt.y + Phaser.Math.Between(-20, 20) : CONFIG.world.height * 0.4;
            
            this.time.delayedCall(2500, () => {
                this._spawnRescueNPC(rsx, rsy);
                this.showModeAnnouncement('SURVIVOR SIGNAL', 'Someone needs help nearby.', true);
            });
        }
    }
    
    showModeAnnouncement(title, subtitle, compact = false) {
        // Compact: small pill at top — for phase transitions, wave clears, loot prompts
        // Full: larger centered banner — for mode intros, boss defeats
        const yPos = compact ? 60 : 55;
        const bgW = compact ? 220 : Math.min(CONFIG.width - 10, 310);
        const bgH = compact ? 38 : 68;
        
        const container = this.add.container(CONFIG.width / 2, yPos).setDepth(200).setScrollFactor(0);
        const bg = this.add.rectangle(0, 0, bgW, bgH, 0x000000, compact ? 0.7 : 0.8);
        bg.setStrokeStyle(1, 0x443322, 0.3);
        container.add(bg);
        
        // Strip emoji for GrimFont (it can't render them), keep for subtitle
        const cleanTitle = title.replace(/[^\x20-\x7E]/g, '').trim();
        
        // Use GrimFont for title
        if (!compact && GrimFont.built) {
            const titleScale = cleanTitle.length > 14 ? 0.6 : cleanTitle.length > 10 ? 0.7 : 0.8;
            const isRust = cleanTitle.includes('BOSS') || cleanTitle.includes('DEFEAT') || cleanTitle.includes('PHASE') || cleanTitle.includes('HORDE');
            const grimText = GrimFont.drawText(this, 0, subtitle ? -10 : 0, cleanTitle, { 
                scale: titleScale, rust: isRust, depth: 201, center: true 
            });
            grimText.setScrollFactor(0);
            container.add(grimText);
        } else {
            const titleSize = compact ? uiPx(14) : uiPx(18);
            const t = this.add.text(0, subtitle ? -10 : 0, title, {
                fontFamily: CONFIG.font, fontSize: titleSize, fill: '#ff6644', fontStyle: 'bold'
            }).setOrigin(0.5);
            container.add(t);
        }
        
        if (subtitle) {
            const subSize = compact ? uiPx(10) : uiPx(12);
            const s = this.add.text(0, compact ? 10 : 14, subtitle, {
                fontFamily: CONFIG.font, fontSize: subSize, fill: '#998877', align: 'center'
            }).setOrigin(0.5);
            container.add(s);
        }
        
        // Slide in from above
        container.y = yPos - 20;
        container.alpha = 0;
        this.tweens.add({
            targets: container, y: yPos, alpha: 1, duration: 300, ease: 'Power2'
        });
        
        this.tweens.add({
            targets: container, alpha: 0, y: yPos - 10,
            delay: compact ? 1500 : 2500, duration: 400,
            onComplete: () => container.destroy()
        });
    }
    
    // === DEFENSE MODE ===
    // ==================== BREAKDOWN MODE ====================
    
    // createBreakdownObjectives removed - deprecated
    
    collectBreakdownSupply(supply) {
        if (supply.collected) return;
        supply.collected = true;
        
        if (supply.isObjective) {
            this.state.vehicleHealth = Math.min(100, (this.state.vehicleHealth || 0) + 50);
            this.showModeAnnouncement('TOOLKIT FOUND', 'Get back to the vehicle!');
            supply.destroy();
            this.modeState.objectiveFound = true;
            this._setupReturnZone();
        } else if (supply.isBonus) {
            this.state.powerAmmo = (this.state.powerAmmo || 0) + 8;
            this.state.bits = (this.state.bits || 0) + 10;
            this.showModeAnnouncement('SUPPLIES', '+8 power ammo, +10 bits', true);
            supply.destroy();
        }
    }
    
    _setupReturnZone() {
        if (this.breakdownObjText) {
            this.breakdownObjText.setText('RETURN TO VEHICLE');
            this.breakdownObjText.setColor('#44ff44');
        }
        const vx = this.brokenVehicle ? this.brokenVehicle.x : 100;
        const vy = this.brokenVehicle ? this.brokenVehicle.y : CONFIG.world.height / 2 + 8;
        this.breakdownReturnZone = this.add.circle(vx, vy, 25, 0x44aa44, 0.15).setDepth(5);
        this.tweens.add({ targets: this.breakdownReturnZone, alpha: 0.3, scaleX: 1.2, scaleY: 1.2, duration: 800, yoyo: true, repeat: -1 });
        this.physics.add.existing(this.breakdownReturnZone);
        this.physics.add.overlap(this.player, this.breakdownReturnZone, () => {
            if (this.modeState.repaired) return;
            this.modeState.repaired = true;
            this.completeBreakdownRepair();
        });
    }
    
    // completeBreakdownRepair removed - deprecated
    
    // updateBreakdownMode removed - deprecated
    
    // === SCAVENGE EVENT MODE (DEPRECATED) — traversal ? encounter areas ===
    
    // createRoadEventExitZone removed - deprecated
    
    // completeRoadEvent removed - deprecated
    
    // updateScavengeEventMode removed - deprecated
    
    // === RESCUE ENCOUNTER — trapped survivor interaction ===
    
    _spawnRescueNPC(x, y) {
        // Clamp to world bounds
        x = Phaser.Math.Clamp(x, 60, CONFIG.world.width - 60);
        y = Phaser.Math.Clamp(y, 60, CONFIG.world.height - 60);
        
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const npc = this.add.container(x, y).setDepth(8);
        
        // Rubble/debris around the survivor (they're trapped)
        for (let i = 0; i < 5; i++) {
            const rx = Phaser.Math.Between(-18, 18);
            const ry = Phaser.Math.Between(-8, 12);
            const rw = Phaser.Math.Between(6, 14);
            const rh = Phaser.Math.Between(4, 8);
            npc.add(this.add.rectangle(rx, ry, rw, rh, tc(0x555544), 0.8).setAngle(Phaser.Math.Between(-20, 20)));
        }
        
        // The survivor figure — 3/4 perspective matching player sprite
        const surv = this._rescueSurvivor;
        const skinColor = tc(surv.appearance?.skinColor || 0xc4956a);
        const clothesColor = tc(surv.appearance?.clothesPrimary || 0x556677);
        const hairColor = tc(surv.appearance?.hairColorHex || 0x443322);
        
        // Crouching figure — body visible from front (north-facing camera perspective)
        // Torso (front face dominant, slightly hunched)
        npc.add(this.add.rectangle(0, -6, 10, 10, clothesColor));
        // Head
        npc.add(this.add.circle(0, -14, 4, skinColor));
        // Hair on top
        npc.add(this.add.rectangle(0, -18, 7, 3, hairColor));
        // Arms reaching out
        npc.add(this.add.rectangle(-7, -4, 4, 3, skinColor));
        npc.add(this.add.rectangle(7, -4, 4, 3, skinColor));
        // Legs (crouching)
        npc.add(this.add.rectangle(-3, 3, 4, 5, clothesColor));
        npc.add(this.add.rectangle(3, 3, 4, 5, clothesColor));
        
        // Ground shadow
        npc.add(this.add.ellipse(0, 8, 20, 8, 0x000000, 0.25));
        
        // Distress indicator — pulsing green ring
        const ring = this.add.circle(x, y, 22, 0x44cc66, 0).setDepth(7);
        ring.setStrokeStyle(2, 0x44cc66, 0.6);
        this.tweens.add({
            targets: ring, scaleX: 1.4, scaleY: 1.4, alpha: 0.3,
            duration: 1000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
        });
        
        // Help text floating above
        const helpText = this.add.text(x, y - 28, 'HELP!', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#44cc66', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(9);
        this.tweens.add({
            targets: helpText, y: y - 33, duration: 800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
        });
        
        // Objective text
        this._rescueObjText = this.add.text(CONFIG.width - 10, 50, 'FIND SURVIVOR', {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#44cc66'
        }).setOrigin(1, 0).setScrollFactor(0).setDepth(101);
        
        // Store references
        this._rescueNPC = npc;
        this._rescueRing = ring;
        this._rescueHelpText = helpText;
        this._rescueX = x;
        this._rescueY = y;
        this._rescueInteractRange = 40;
    }
    
    _updateRescue() {
        if (!this._rescueNPC || this._rescueComplete) return;
        if (!this.player || !this.player.active) return;
        
        const dist = Phaser.Math.Distance.Between(
            this.player.x, this.player.y, this._rescueX, this._rescueY
        );
        
        // Count nearby enemies (within 100px of the survivor)
        const nearbyEnemies = this.enemies.getChildren().filter(e => {
            if (!e.active || e.hp <= 0) return false;
            return Phaser.Math.Distance.Between(e.x, e.y, this._rescueX, this._rescueY) < 120;
        }).length;
        
        // Update objective text
        if (this._rescueObjText && this._rescueObjText.active) {
            if (dist < 80) {
                if (nearbyEnemies > 0) {
                    this._rescueObjText.setText(`CLEAR AREA (${nearbyEnemies} hostiles)`);
                    this._rescueObjText.setFill('#cc6644');
                } else {
                    this._rescueObjText.setText('APPROACH SURVIVOR');
                    this._rescueObjText.setFill('#44cc66');
                }
            }
        }
        
        // Trigger rescue when close enough and area is clear
        if (dist < this._rescueInteractRange && nearbyEnemies === 0) {
            this._rescueComplete = true;
            this._showRescuePanel();
        }
    }
    
    _showRescuePanel() {
        // Clean up NPC visuals
        if (this._rescueRing) { this._rescueRing.destroy(); this._rescueRing = null; }
        if (this._rescueHelpText) { this._rescueHelpText.destroy(); this._rescueHelpText = null; }
        if (this._rescueObjText) { this._rescueObjText.destroy(); this._rescueObjText = null; }
        
        // Pause gameplay
        this._rescuePanelOpen = true;
        if (this.player && this.player.body) this.player.body.moves = false;
        
        const surv = this._rescueSurvivor;
        const rDef = SurvivorGenerator.RARITIES[surv.rarity];
        
        UIAtlas.build(this);
        const panelW = 280, panelH = 260;
        const panel = UIManager.createPanel(this, CONFIG.width / 2, CONFIG.height / 2, panelW, panelH, {
            title: 'SURVIVOR RESCUED', accent: 'confirm', closable: false, depth: 250, modal: true
        });
        panel.setScrollFactor(0);
        const cb = panel._contentBounds;
        
        // Rarity badge
        panel.add(this.add.text(0, cb.y + 8, rDef.label.toUpperCase(), {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: rDef.color
        }).setOrigin(0.5));
        
        // Name
        panel.add(this.add.text(0, cb.y + 24, surv.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(13), fill: rDef.textColor || '#ccddcc', fontStyle: 'bold'
        }).setOrigin(0.5));
        
        // Gender + Personality
        const gLabel = surv.gender === 'unknown'
            ? (surv.unknownType ? surv.unknownType.charAt(0).toUpperCase() + surv.unknownType.slice(1) : 'Unknown')
            : surv.gender.charAt(0).toUpperCase() + surv.gender.slice(1);
        panel.add(this.add.text(0, cb.y + 42, `${gLabel} | ${surv.personality?.label || 'Unknown'}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#667788'
        }).setOrigin(0.5));
        
        // Rank
        const rankInfo = SurvivorGenerator.getRank(surv);
        panel.add(this.add.text(0, cb.y + 56, `Rank: ${rankInfo.label}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#778899'
        }).setOrigin(0.5));
        
        // Marks
        const marks = surv.marks || [];
        let perkY = cb.y + 74;
        if (marks.length === 0) {
            panel.add(this.add.text(0, perkY, 'No marks', {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#445566'
            }).setOrigin(0.5));
            perkY += 14;
        } else {
            marks.forEach(p => {
                const isNeg = p.type === 'negative';
                const isMixed = p.type === 'mixed';
                const col = isNeg ? '#aa5544' : isMixed ? '#aaaa44' : '#66aa66';
                panel.add(this.add.text(0, perkY, `${isNeg ? '-' : '+'} ${p.name}`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: col
                }).setOrigin(0.5));
                perkY += 14;
            });
        }
        
        // Check barracks capacity
        const sd = SaveManager.load();
        const barracksLvl = sd?.upgrades?.barracks || 1;
        const maxSurvivors = CONFIG.barracks.levels[barracksLvl]?.maxSurvivors || 2;
        const aliveSurvivors = (sd?.survivors || []).filter(s => s.alive).length;
        const hasRoom = aliveSurvivors < maxSurvivors;
        
        // Buttons
        const btnY = cb.y + panelH - 75;
        
        if (hasRoom) {
            const recruitBtn = UIManager.createButton(this, 0, btnY, 'RECRUIT', {
                width: 120, height: 34, style: 'confirm', fontSize: uiPx(11), depth: 251,
                onClick: () => {
                    // Add survivor to roster
                    const saveData = SaveManager.load();
                    saveData.survivors.push(surv);
                    SaveManager.save(saveData);
                    
                    panel.destroy();
                    this._rescuePanelOpen = false;
                    if (this.player && this.player.body) this.player.body.moves = true;
                    
                    // NPC walks off (simple fade)
                    if (this._rescueNPC) {
                        this.tweens.add({ targets: this._rescueNPC, alpha: 0, y: this._rescueNPC.y - 20, duration: 800, onComplete: () => this._rescueNPC.destroy() });
                    }
                    
                    this.showModeAnnouncement(`${surv.name} JOINED`, `${rDef.label} survivor recruited!`, true);
                }
            });
            recruitBtn.setScrollFactor(0);
            panel.add(recruitBtn);
        } else {
            panel.add(this.add.text(0, btnY - 10, `BARRACKS FULL (${aliveSurvivors}/${maxSurvivors})`, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#aa5544'
            }).setOrigin(0.5));
        }
        
        const passBtn = UIManager.createButton(this, 0, hasRoom ? btnY + 40 : btnY + 14, 'LEAVE THEM', {
            width: 120, height: 30, style: 'normal', fontSize: uiPx(10), depth: 251,
            onClick: () => {
                panel.destroy();
                this._rescuePanelOpen = false;
                if (this.player && this.player.body) this.player.body.moves = true;
                
                // NPC fades sadly
                if (this._rescueNPC) {
                    this.tweens.add({ targets: this._rescueNPC, alpha: 0, duration: 1200, onComplete: () => this._rescueNPC.destroy() });
                }
                
                this.showModeAnnouncement('SURVIVOR LEFT BEHIND', 'They disappeared into the wastes.', true);
            }
        });
        passBtn.setScrollFactor(0);
        panel.add(passBtn);
    }
    
    // === FOUNDRY CONVOY DEFENSE — Full event system ===
    
    // ── FOUNDRY CONVOY CREATION ──
    // Places the damaged Foundry truck on the road in the procedural biome
    createFoundryConvoy() {
        const w = CONFIG.world.width, h = CONFIG.world.height;
        const road = this.generatedRoute?.road;
        if (!road || !road.segments.length) return;
        
        const roadSeg = road.segments[0];
        // Place convoy ~60% along the road from left edge
        const cx = Math.min(w - 120, w * 0.6);
        const cy = roadSeg.y;
        
        this.modeState.convoyX = cx;
        this.modeState.convoyY = cy;
        
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const p = this.modeState.foundry.palette;
        const d = 10 + cy * 0.01;
        
        // Parse foundry palette hex to int
        const pInt = (hex) => parseInt(hex.replace('#', ''), 16);
        const bodyColor = tc(pInt(p.body));
        const bodyDark = tc(pInt(p.bodyDark));
        const bodyLight = tc(pInt(p.bodyLight));
        const accentColor = tc(pInt(p.accent));
        const metalColor = tc(pInt(p.metal));
        const metalLight = tc(pInt(p.metalLight));
        const canvasColor = tc(pInt(p.bodyLight));
        const canvasDark = tc(pInt(p.body));
        const wheelColor = 0x1a1a1a;
        
        // === SUPPLY CONVOY TRUCK — large military-style, Foundry themed, DAMAGED ===
        this.caravanContainer = this.add.container(cx, cy).setDepth(d).setScale(1.6);
        
        // Ground shadow
        this.caravanContainer.add(this.add.ellipse(0, 22, 90, 20, 0x000000, 0.35));
        
        // === WHEELS ===
        const wOff = 28, wY = 18;
        this.caravanContainer.add(this.add.ellipse(-wOff, wY, 13, 7, wheelColor));
        this.caravanContainer.add(this.add.ellipse(-wOff, wY, 8, 5, tc(0x2a2a2a)));
        this.caravanContainer.add(this.add.ellipse(-wOff, wY, 3, 2, tc(0x3a3a3a)));
        this.caravanContainer.add(this.add.ellipse(-wOff - 4, wY + 1, 11, 6, wheelColor));
        this.caravanContainer.add(this.add.ellipse(wOff, wY, 13, 7, wheelColor));
        this.caravanContainer.add(this.add.ellipse(wOff, wY, 8, 5, tc(0x2a2a2a)));
        this.caravanContainer.add(this.add.ellipse(wOff, wY, 3, 2, tc(0x3a3a3a)));
        
        // Undercarriage
        this.caravanContainer.add(this.add.rectangle(0, 16, 72, 5, tc(0x1a1a1a)));
        
        // === TRUCK BED ===
        this.caravanContainer.add(this.add.rectangle(-8, 0, 50, 28, bodyDark));
        this.caravanContainer.add(this.add.rectangle(-8, 10, 50, 8, bodyColor));
        this.caravanContainer.add(this.add.rectangle(17, 2, 4, 26, tc(pInt(p.bodyDark))));
        this.caravanContainer.add(this.add.rectangle(-8, -5, 50, 2, bodyLight));
        
        // === CANVAS TARP (Foundry colored) ===
        this.caravanContainer.add(this.add.rectangle(-22, -10, 3, 12, metalColor));
        this.caravanContainer.add(this.add.rectangle(-8, -11, 3, 14, metalColor));
        this.caravanContainer.add(this.add.rectangle(6, -10, 3, 12, metalColor));
        this.caravanContainer.add(this.add.rectangle(-8, -14, 48, 10, canvasColor));
        this.caravanContainer.add(this.add.rectangle(-8, -8, 48, 4, canvasDark));
        this.caravanContainer.add(this.add.rectangle(-8, -17, 44, 2, tc(pInt(p.metalLight))));
        // Side ropes
        this.caravanContainer.add(this.add.rectangle(17, -8, 1, 10, canvasDark));
        this.caravanContainer.add(this.add.rectangle(-33, -8, 1, 10, canvasDark));
        // Tarp back
        this.caravanContainer.add(this.add.rectangle(-32, -6, 3, 16, canvasDark));
        this.caravanContainer.add(this.add.rectangle(-31, -2, 2, 8, tc(0x1a1a0a)));
        
        // === CARGO visible inside ===
        this.caravanContainer.add(this.add.rectangle(-18, -4, 10, 8, tc(0x5a4a2a)));
        this.caravanContainer.add(this.add.rectangle(-18, -6, 10, 4, tc(0x6a5a3a)));
        this.caravanContainer.add(this.add.rectangle(-6, -3, 8, 7, bodyDark));
        this.caravanContainer.add(this.add.rectangle(-6, -5, 8, 3, bodyColor));
        
        // === CAB ===
        this.caravanContainer.add(this.add.rectangle(32, 4, 22, 22, bodyDark));
        this.caravanContainer.add(this.add.rectangle(32, 0, 20, 16, bodyColor));
        this.caravanContainer.add(this.add.rectangle(32, -8, 20, 6, bodyDark));
        this.caravanContainer.add(this.add.rectangle(32, -10, 18, 4, bodyLight));
        // Windshield — CRACKED
        this.caravanContainer.add(this.add.rectangle(32, -3, 14, 8, tc(0x1a2530)));
        const windshieldCrack = this.add.graphics();
        windshieldCrack.lineStyle(1, 0x667788, 0.6);
        windshieldCrack.lineBetween(26, -6, 34, 1);
        windshieldCrack.lineBetween(30, -5, 38, -1);
        windshieldCrack.lineBetween(33, -7, 29, 2);
        this.caravanContainer.add(windshieldCrack);
        // Side window
        this.caravanContainer.add(this.add.rectangle(42, -2, 3, 6, tc(0x1a2530)));
        // Headlight
        this.caravanContainer.add(this.add.rectangle(44, 6, 3, 4, tc(0x888844), 0.4));
        // Grille
        this.caravanContainer.add(this.add.rectangle(44, 10, 3, 6, metalColor));
        
        // === FOUNDRY LOGO — accent color stripe on truck side ===
        this.caravanContainer.add(this.add.rectangle(-8, 5, 46, 3, accentColor, 0.7));
        // Foundry tag stencil
        const tagText = this.add.text(-8, 5, this.modeState.foundry.tag, {
            fontFamily: CONFIG.font, fontSize: '5px', fill: '#' + pInt(p.detail).toString(16).padStart(6, '0')
        }).setOrigin(0.5).setAlpha(0.8);
        this.caravanContainer.add(tagText);
        
        // === DAMAGE VISUALS ===
        // Dented panels — offset rectangles suggesting impact damage
        this.caravanContainer.add(this.add.rectangle(-15, 8, 8, 4, tc(0x1a1a1a), 0.25).setAngle(5));
        this.caravanContainer.add(this.add.rectangle(10, 12, 6, 3, tc(0x1a1a1a), 0.2).setAngle(-8));
        this.caravanContainer.add(this.add.rectangle(25, 8, 5, 5, tc(0x1a1a1a), 0.2).setAngle(12));
        // Missing bumper section
        this.caravanContainer.add(this.add.rectangle(43, 14, 5, 3, tc(0x1a1a1a), 0.3));
        // Scratch marks
        const scratchG = this.add.graphics();
        scratchG.lineStyle(1, 0x222222, 0.3);
        scratchG.lineBetween(-20, 6, -10, 8);
        scratchG.lineBetween(5, 9, 15, 11);
        this.caravanContainer.add(scratchG);
        
        // Wheel well arches
        this.caravanContainer.add(this.add.ellipse(-wOff, 11, 16, 8, bodyDark));
        this.caravanContainer.add(this.add.ellipse(wOff, 11, 14, 8, bodyDark));
        
        // === HOOD SMOKE — particle system, rate decreases with repair ===
        this._convoySmoke = { rate: 3, timer: 0 }; // 3 particles/sec initial
        this.time.addEvent({ delay: 100, loop: true, callback: () => {
            if (!this.caravanContainer || !this.caravanContainer.active) return;
            if (this.modeState.phase === 'complete') return;
            this._convoySmoke.timer += 0.1;
            if (this._convoySmoke.timer < 1 / this._convoySmoke.rate) return;
            this._convoySmoke.timer = 0;
            const sx = cx + 50 * 1.6 + Phaser.Math.Between(-4, 4);
            const sy = cy - 8 * 1.6 + Phaser.Math.Between(-3, 3);
            const size = Phaser.Math.Between(3, 7);
            const smoke = this.add.circle(sx, sy, size, 0x333333, 0.4).setDepth(d + 2);
            this.tweens.add({
                targets: smoke, alpha: 0, y: sy - Phaser.Math.Between(15, 30),
                x: sx + Phaser.Math.Between(-8, 8), scale: 1.8,
                duration: Phaser.Math.Between(800, 1400), onComplete: () => smoke.destroy()
            });
        }});
        
        // === CARAVAN HP BAR ===
        this.caravanHpBg = this.add.rectangle(cx, cy + 32, 80, 6, 0x222222, 0.8).setDepth(d + 1).setStrokeStyle(1, 0x444444);
        this.caravanHpBar = this.add.rectangle(cx - 39, cy + 32, 78, 4, 0x44cc44).setDepth(d + 1.01).setOrigin(0, 0.5);
        const accentHex = '#' + pInt(p.accent).toString(16).padStart(6, '0');
        this.caravanHpLabel = this.add.text(cx, cy + 32, `${this.modeState.foundry.tag} TRANSPORT`, {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: accentHex
        }).setOrigin(0.5).setDepth(d + 1.02).setAlpha(0.7);
        
        // Collision body
        this.caravanBody = this.add.zone(cx, cy, 90, 36);
        this.physics.add.existing(this.caravanBody, true);
        this.physics.add.collider(this.player, this.caravanBody);
        
        // Idle animation — slight engine vibration
        this.tweens.add({
            targets: this.caravanContainer,
            y: cy - 0.5, duration: 800, yoyo: true, repeat: -1, ease: 'Sine.inOut'
        });
        
        // === TURRET MOUNT POINT (hidden until wave 9 upgrade) ===
        this._turretMount = this.add.container(cx - 5 * 1.6, cy - 18 * 1.6).setDepth(d + 3).setVisible(false);
        // Will be populated in applyCheckpointUpgrade when turret is selected
        
        // === SHIELD MOUNT POINT (hidden until wave 3 upgrade) ===
        this._shieldVisual = null;
        this._shieldDevice = null;
    }
    
    // ── FOUNDRY SOLDIERS ──
    createFoundrySoldiers() {
        const cx = this.modeState.convoyX;
        const cy = this.modeState.convoyY;
        const d = 10 + cy * 0.01 + 0.5;
        
        const soldiers = [];
        const solCfg = DEFENSE_DATA.soldier;
        
        // Map foundry ID to NPC preset via NPCManager
        const fId = this.modeState.foundry.id;
        
        // Soldier positions: guard (quest-giver), patrol, mechanic
        const positions = [
            { x: cx + 40, y: cy + 34, role: 'guard', name: this.modeState.questGiverName, preset: NPCManager.getFoundryPreset(fId, 'guard') },
            { x: cx - 62, y: cy + 10, role: 'patrol', name: this.modeState.soldierNames[0] || 'Soldier', preset: NPCManager.getFoundryPreset(fId, 'patrol') },
            { x: cx - 30, y: cy + 34, role: 'mechanic', name: this.modeState.soldierNames[1] || 'Soldier', preset: NPCManager.getFoundryPreset(fId, 'mechanic') }
        ];
        
        for (const pos of positions) {
            // Create proper character sprite with foundry gear overlay
            const sol = SpriteManager.createNPCSprite(this, pos.x, pos.y, pos.preset);
            sol.setDepth(d);
            
            const solData = {
                sprite: sol,
                x: pos.x, y: pos.y,
                role: pos.role,
                name: pos.name,
                hp: solCfg.hp,
                maxHp: solCfg.hp,
                downed: false,
                downTimer: 0,
                fireTimer: 0,
                combatActive: false,
                _patrolDir: 1,
                _patrolTimer: 0,
                _homeX: pos.x,
                _homeY: pos.y
            };
            
            // Quest-giver gets exclamation mark
            if (pos.role === 'guard') {
                const exclMark = this.add.text(pos.x, pos.y - 24, '!', {
                    fontFamily: CONFIG.font, fontSize: uiPx(16), fill: '#FFD700',
                    fontStyle: 'bold', stroke: '#000000', strokeThickness: 2
                }).setOrigin(0.5).setDepth(d + 5);
                this.tweens.add({
                    targets: exclMark, scaleX: { from: 0.9, to: 1.1 }, scaleY: { from: 0.9, to: 1.1 },
                    duration: 600, yoyo: true, repeat: -1, ease: 'Sine.inOut'
                });
                solData.exclMark = exclMark;
                solData._guardPaceTimer = 0;
                solData._guardPaceDir = 1;
                this._questGiverSoldier = solData;
            }
            
            // Mechanic — crouching position near hood
            if (pos.role === 'mechanic') {
                sol.setScale(0.9);
                solData._mechState = 'working'; // working, standing, walking_away, walking_back
                solData._mechTimer = 0;
                solData._mechToolX = pos.x + 15; // "tool bench" offset
                // Sparks effect every 3-4 seconds
                this.time.addEvent({ delay: 3500, loop: true, callback: () => {
                    if (!sol.active || this.modeState.repairStage >= 4) return;
                    if (solData._mechState !== 'working') return; // Only spark when crouching
                    for (let i = 0; i < 3; i++) {
                        const sp = this.add.circle(
                            pos.x + Phaser.Math.Between(-5, 5),
                            pos.y + Phaser.Math.Between(-8, -2),
                            1, 0xffcc44, 0.8
                        ).setDepth(d + 3);
                        this.tweens.add({
                            targets: sp, alpha: 0, y: sp.y - 6, x: sp.x + Phaser.Math.Between(-4, 4),
                            duration: 250, onComplete: () => sp.destroy()
                        });
                    }
                }});
            }
            
            // Patrol soldier — waypoint route around convoy perimeter
            if (pos.role === 'patrol') {
                solData._patrolMinX = cx - 80;
                solData._patrolMaxX = cx + 20;
                solData._waypoints = [
                    { x: cx + 78, y: cy + 34 },
                    { x: cx - 62, y: cy + 34 },
                    { x: cx - 62, y: cy - 32 },
                    { x: cx + 78, y: cy - 32 }
                ];
                solData._waypointIdx = 0;
                solData._waypointPause = 0;
            }
            
            soldiers.push(solData);
        }
        
        this.modeState.soldiers = soldiers;
        
        // NPC interaction zone — check proximity in update loop
        this._defenseNpcCheckTimer = 0;
    }
    
    // ── NPC SPEECH BUBBLE ──
    showNPCSpeechBubble(text, duration = 3000) {
        if (!this._questGiverSoldier) return;
        // Remove existing bubble
        if (this._npcBubble) {
            this._npcBubble.forEach(el => { if (el && el.destroy) el.destroy(); });
            this._npcBubble = null;
        }
        
        const sol = this._questGiverSoldier;
        const bx = sol.x;
        const by = sol.y - 34;
        const p = this.modeState.foundry.palette;
        const pInt = (hex) => parseInt(hex.replace('#', ''), 16);
        const accentInt = pInt(p.accent);
        
        const bubbleBg = this.add.rectangle(bx, by, 0, 18, 0x0a0a14, 0.9)
            .setStrokeStyle(1, accentInt, 0.6).setDepth(200);
        const bubbleText = this.add.text(bx, by, text, {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#cccccc',
            wordWrap: { width: 140 }
        }).setOrigin(0.5).setDepth(201).setAlpha(0);
        
        // Size bubble to text
        const tw = Math.min(160, bubbleText.width + 16);
        const th = bubbleText.height + 10;
        bubbleBg.setDisplaySize(tw, th);
        
        // Pointer triangle
        const ptr = this.add.triangle(bx, by + th / 2 + 4, 0, 0, 8, 0, 4, 6, 0x0a0a14, 0.9).setDepth(200);
        
        this._npcBubble = [bubbleBg, bubbleText, ptr];
        
        // Fade in
        this.tweens.add({ targets: [bubbleBg, ptr], alpha: { from: 0, to: 1 }, duration: 200 });
        this.tweens.add({ targets: bubbleText, alpha: { from: 0, to: 1 }, duration: 200 });
        
        // Auto-dismiss
        this.time.delayedCall(duration, () => {
            if (!this._npcBubble) return;
            this._npcBubble.forEach(el => {
                if (el && el.active) this.tweens.add({ targets: el, alpha: 0, duration: 300, onComplete: () => el.destroy() });
            });
            this._npcBubble = null;
        });
    }
    
    // ── DIALOGUE PANEL ──
    showDialoguePanel() {
        if (this._dialoguePanel) return;
        this.popupActive = true;
        
        const W = CONFIG.width, H = CONFIG.height;
        const ms = this.modeState;
        const p = ms.foundry.palette;
        const pInt = (hex) => parseInt(hex.replace('#', ''), 16);
        const accentHex = p.accent;
        const accentInt = pInt(p.accent);
        
        const panelH = 110;
        const panelY = H - panelH / 2 - 4;
        
        this._dialoguePanel = [];
        this._dialogueLine = 0;
        this._dialogueCharIndex = 0;
        this._dialogueTyping = false;
        
        const addEl = (el) => { this._dialoguePanel.push(el); el.setScrollFactor(0); return el; };
        
        // Panel background
        addEl(this.add.rectangle(W / 2, panelY, W - 8, panelH, 0x0a0a14, 0.94).setDepth(210).setStrokeStyle(1, accentInt, 0.5));
        // Accent top border
        addEl(this.add.rectangle(W / 2, panelY - panelH / 2, W - 8, 2, accentInt, 0.7).setDepth(210.1));
        
        // Portrait frame (left side)
        const portX = 38, portY = panelY - 10;
        addEl(this.add.rectangle(portX, portY, 44, 44, 0x111122, 0.9).setDepth(211).setStrokeStyle(1, accentInt, 0.6));
        
        // Pixel art portrait — foundry-themed face
        const portG = this.add.graphics().setDepth(212).setScrollFactor(0);
        const px = portX - 16, py = portY - 16;
        // Face
        portG.fillStyle(0xc4956a); portG.fillRect(px + 10, py + 12, 12, 14);
        // Helmet
        portG.fillStyle(pInt(p.metal)); portG.fillRect(px + 8, py + 6, 16, 10);
        // Visor
        portG.fillStyle(accentInt, 0.9); portG.fillRect(px + 10, py + 12, 12, 4);
        // Eyes behind visor
        portG.fillStyle(0xeeeeee); portG.fillRect(px + 12, py + 13, 2, 2); portG.fillRect(px + 18, py + 13, 2, 2);
        // Collar/armor
        portG.fillStyle(pInt(p.body)); portG.fillRect(px + 8, py + 26, 16, 6);
        // Shoulder accent
        portG.fillStyle(accentInt); portG.fillRect(px + 6, py + 26, 4, 4); portG.fillRect(px + 22, py + 26, 4, 4);
        addEl(portG);
        
        // Speaker name
        addEl(this.add.text(66, panelY - panelH / 2 + 10, `${ms.questGiverName}  [${ms.foundry.tag}]`, {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: accentHex, fontStyle: 'bold'
        }).setOrigin(0, 0).setDepth(212));
        
        // Dialogue text area
        this._dialogueTextObj = addEl(this.add.text(66, panelY - panelH / 2 + 28, '', {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#cccccc',
            wordWrap: { width: W - 90 }, lineSpacing: 3
        }).setOrigin(0, 0).setDepth(212));
        
        // Options container (populated when line has options)
        this._dialogueOptions = [];
        
        // Start dialogue
        this._advanceDialogue();
    }
    
    _advanceDialogue(forceLine) {
        const lines = DEFENSE_DATA.dialogue.intro;
        const lineIdx = forceLine !== undefined ? forceLine : this._dialogueLine;
        if (lineIdx >= lines.length) return;
        
        const line = lines[lineIdx];
        this._dialogueLine = lineIdx;
        
        // Clear options
        this._dialogueOptions.forEach(el => { if (el && el.destroy) el.destroy(); });
        this._dialogueOptions = [];
        
        // Typewriter effect
        this._dialogueCharIndex = 0;
        this._dialogueTyping = true;
        this._dialogueFullText = line.text;
        
        if (this._typewriterTimer) this._typewriterTimer.destroy();
        this._typewriterTimer = this.time.addEvent({
            delay: 35, loop: true, callback: () => {
                if (!this._dialogueTyping) return;
                this._dialogueCharIndex++;
                if (this._dialogueTextObj && this._dialogueTextObj.active) {
                    this._dialogueTextObj.setText(this._dialogueFullText.substring(0, this._dialogueCharIndex));
                }
                if (this._dialogueCharIndex >= this._dialogueFullText.length) {
                    this._dialogueTyping = false;
                    if (this._typewriterTimer) this._typewriterTimer.destroy();
                    // Show options if this line has them
                    if (line.options) this._showDialogueOptions(line.options);
                }
            }
        });
        
        // Tap to skip typewriter / advance to next line
        if (this._dialogueTapHandler) this.input.off('pointerdown', this._dialogueTapHandler);
        this._dialogueTapHandler = () => {
            if (this._dialogueTyping) {
                // Skip typewriter — show full text
                this._dialogueTyping = false;
                if (this._typewriterTimer) this._typewriterTimer.destroy();
                if (this._dialogueTextObj && this._dialogueTextObj.active) {
                    this._dialogueTextObj.setText(this._dialogueFullText);
                }
                if (line.options) this._showDialogueOptions(line.options);
            } else if (!line.options) {
                // Advance to next line
                this._dialogueLine++;
                this._advanceDialogue();
            }
        };
        this.input.on('pointerdown', this._dialogueTapHandler);
    }
    
    _showDialogueOptions(options) {
        const W = CONFIG.width, H = CONFIG.height;
        const panelH = 110;
        const panelY = H - panelH / 2 - 4;
        const p = this.modeState.foundry.palette;
        const pInt = (hex) => parseInt(hex.replace('#', ''), 16);
        const accentInt = pInt(p.accent);
        
        const optY = panelY + 22;
        const optSpacing = Math.min(80, (W - 80) / options.length);
        const startX = W / 2 - (options.length - 1) * optSpacing / 2;
        
        options.forEach((opt, i) => {
            const ox = startX + i * optSpacing;
            const isStart = opt.action === 'start_defense';
            const btnColor = isStart ? 0x2a4a2a : 0x1a1a2a;
            const txtColor = isStart ? '#44cc44' : '#aaaacc';
            
            const btn = this.add.rectangle(ox, optY, optSpacing - 6, 28, btnColor, 0.85)
                .setStrokeStyle(1, isStart ? 0x44cc44 : accentInt, 0.6)
                .setScrollFactor(0).setDepth(213).setInteractive({ useHandCursor: true });
            const txt = this.add.text(ox, optY, opt.label, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: txtColor
            }).setOrigin(0.5).setScrollFactor(0).setDepth(214);
            
            btn.on('pointerover', () => btn.setFillStyle(isStart ? 0x3a5a3a : 0x2a2a3a, 0.95));
            btn.on('pointerout', () => btn.setFillStyle(btnColor, 0.85));
            btn.on('pointerdown', () => this._handleDialogueOption(opt.action));
            
            this._dialogueOptions.push(btn, txt);
            this._dialoguePanel.push(btn, txt);
        });
    }
    
    _handleDialogueOption(action) {
        if (action === 'start_defense') {
            this.closeDialoguePanel();
            this.triggerDefenseEvent();
        } else if (action === 'close') {
            this.closeDialoguePanel();
        } else if (action.startsWith('lore_')) {
            const resp = DEFENSE_DATA.dialogue.loreResponses[action];
            if (resp) {
                // Show lore response, then return to options line
                this._dialogueOptions.forEach(el => { if (el && el.destroy) el.destroy(); });
                this._dialogueOptions = [];
                this._dialogueFullText = resp.text;
                this._dialogueCharIndex = 0;
                this._dialogueTyping = true;
                if (this._typewriterTimer) this._typewriterTimer.destroy();
                this._typewriterTimer = this.time.addEvent({
                    delay: 35, loop: true, callback: () => {
                        if (!this._dialogueTyping) return;
                        this._dialogueCharIndex++;
                        if (this._dialogueTextObj && this._dialogueTextObj.active) {
                            this._dialogueTextObj.setText(this._dialogueFullText.substring(0, this._dialogueCharIndex));
                        }
                        if (this._dialogueCharIndex >= this._dialogueFullText.length) {
                            this._dialogueTyping = false;
                            if (this._typewriterTimer) this._typewriterTimer.destroy();
                            // After reading lore, tap to return to options
                            if (this._dialogueTapHandler) this.input.off('pointerdown', this._dialogueTapHandler);
                            this._dialogueTapHandler = () => {
                                this._advanceDialogue(resp.returnTo);
                            };
                            this.input.on('pointerdown', this._dialogueTapHandler);
                        }
                    }
                });
            }
        }
    }
    
    closeDialoguePanel() {
        this.popupActive = false;
        if (this._dialogueTapHandler) {
            this.input.off('pointerdown', this._dialogueTapHandler);
            this._dialogueTapHandler = null;
        }
        if (this._typewriterTimer) { this._typewriterTimer.destroy(); this._typewriterTimer = null; }
        if (this._dialoguePanel) {
            this._dialoguePanel.forEach(el => { if (el && el.destroy) el.destroy(); });
            this._dialoguePanel = null;
        }
        this._dialogueOptions = [];
        this._dialogueTextObj = null;
    }
    
    // ── DEFENSE EVENT TRIGGER ──
    triggerDefenseEvent() {
        const ms = this.modeState;
        ms.phase = 'prepare';
        
        // Quest-giver loses exclamation mark, soldiers go combat-ready
        if (this._questGiverSoldier && this._questGiverSoldier.exclMark) {
            this.tweens.add({ targets: this._questGiverSoldier.exclMark, alpha: 0, scaleY: 0, duration: 300,
                onComplete: () => { if (this._questGiverSoldier.exclMark) this._questGiverSoldier.exclMark.destroy(); }
            });
        }
        
        // Activate all soldiers for combat — reset idle behavior state
        ms.soldiers.forEach(s => {
            s.combatActive = true;
            if (s.sprite) s.sprite.setScale(1.0); // Reset mechanic crouchScale
            s._mechState = 'working'; // Reset mechanic cycle
            s._mechTimer = 0;
        });
        
        // Announcement
        const foundryName = ms.foundry.name.toUpperCase();
        this.showModeAnnouncement(`CONVOY DEFENSE — ${foundryName}`, 'Protect the convoy while repairs complete');
        
        // === DEFENSE HUD ===
        const hudX = 12, hudY = 36;
        this.defenseHudBg = this.add.rectangle(hudX + 56, hudY + 10, 120, 30, 0x000000, 0.6)
            .setStrokeStyle(1, 0x443322, 0.4).setScrollFactor(0).setDepth(99);
        this.defenseWaveText = this.add.text(hudX + 6, hudY + 2, 'WAVE 0/12', {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#ccaa66', fontStyle: 'bold'
        }).setScrollFactor(0).setDepth(100);
        this.defenseEnemyText = this.add.text(hudX + 6, hudY + 15, '', {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866'
        }).setScrollFactor(0).setDepth(100);
        
        // Supply crate drops every 20s during waves
        this.time.addEvent({ delay: 20000, loop: true, callback: () => {
            if (!this.caravanContainer || !this.caravanContainer.active) return;
            if (ms.phase !== 'wave' && ms.phase !== 'spawning') return;
            this._spawnDefenseSupplyCrate();
        }});
        
        // 6-second prep countdown
        this.time.delayedCall(6000, () => this.startDefenseWave());
    }
    
    _spawnDefenseSupplyCrate() {
        const cx = this.modeState.convoyX;
        const cy = this.modeState.convoyY;
        const d = 10 + cy * 0.01;
        
        const crateX = cx - 90 + Phaser.Math.Between(-20, 20);
        const crateY = cy + Phaser.Math.Between(-15, 15);
        
        const crate = this.add.container(cx - 40, cy).setDepth(d + 2);
        crate.add(this.add.rectangle(0, 2, 20, 8, 0x4a5a3a));
        const crateTop = this.add.rectangle(0, -3, 20, 6, 0x5a6a4a);
        crate.add(crateTop);
        crate.add(this.add.rectangle(10, 0, 4, 14, 0x3a4a2a));
        crate.add(this.add.rectangle(0, -3, 18, 1, 0x3a3a2a));
        crate.add(this.add.rectangle(0, 2, 18, 1, 0x3a3a2a));
        const crateIcon = this.add.text(0, -1, '◆', { fontSize: uiPx(8), fill: '#ddaa44' }).setOrigin(0.5);
        crate.add(crateIcon);
        
        this.tweens.add({
            targets: crate, x: crateX, y: crateY + 20, duration: 500, ease: 'Bounce.out',
            onComplete: () => {
                crate.lootType = 'ammo';
                crate.lootAmount = Phaser.Math.Between(3, 6);
                crate.lootColor = 0xddaa44;
                crate.isSupplyCrate = true;
                crate._bonusHealth = Phaser.Math.Between(5, 12);
                this.tweens.add({ targets: crateTop, alpha: 0.6, duration: 500, yoyo: true, repeat: -1 });
                if (!this.lootDrops) this.lootDrops = [];
                this.lootDrops.push(crate);
                this.time.delayedCall(15000, () => {
                    if (crate.active) {
                        const idx = this.lootDrops.indexOf(crate);
                        if (idx > -1) this.lootDrops.splice(idx, 1);
                        this.tweens.add({ targets: crate, alpha: 0, scale: 0.3, duration: 300, onComplete: () => crate.destroy() });
                    }
                });
            }
        });
        this.showModeAnnouncement('SUPPLY DROP', 'Ammo & med kit deployed', true);
    }
    
    // ── CHECKPOINT PANEL (waves 3, 6, 9) ──
    showCheckpointPanel(wave) {
        this.modeState.phase = 'checkpoint';
        this.popupActive = true;
        
        const cpDef = DEFENSE_DATA.checkpoints[wave];
        if (!cpDef) { this.startDefenseWave(); return; }
        
        const W = CONFIG.width, H = CONFIG.height;
        const p = this.modeState.foundry.palette;
        const pInt = (hex) => parseInt(hex.replace('#', ''), 16);
        const accentInt = pInt(p.accent);
        
        this._checkpointUI = [];
        const addEl = (el) => { this._checkpointUI.push(el); el.setScrollFactor(0); return el; };
        
        // Full-screen dim
        addEl(this.add.rectangle(W / 2, H / 2, W, H, 0x000000, 0.6).setDepth(199));
        
        // Panel
        const panelW = Math.min(320, W - 16);
        const panelH = 260;
        addEl(this.add.rectangle(W / 2, H / 2 - 10, panelW, panelH, 0x0a0a14, 0.95)
            .setStrokeStyle(1, accentInt, 0.6).setDepth(200));
        
        // Title
        addEl(this.add.text(W / 2, H / 2 - 10 - panelH / 2 + 16, cpDef.title, {
            fontFamily: CONFIG.font, fontSize: uiPx(13), fill: p.accent, fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(201));
        addEl(this.add.text(W / 2, H / 2 - 10 - panelH / 2 + 32, cpDef.subtitle, {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#888888'
        }).setOrigin(0.5).setDepth(201));
        
        // 3 upgrade cards
        const cardW = Math.floor((panelW - 24) / 3);
        const cardH = 140;
        const cardY = H / 2 - 10 + 8;
        
        cpDef.upgrades.forEach((upg, i) => {
            const cardX = W / 2 - panelW / 2 + 10 + cardW / 2 + i * (cardW + 4);
            
            const card = addEl(this.add.rectangle(cardX, cardY, cardW, cardH, 0x111122, 0.9)
                .setStrokeStyle(1, upg.color, 0.5).setDepth(201).setInteractive({ useHandCursor: true }));
            
            // Icon
            addEl(this.add.text(cardX, cardY - cardH / 2 + 20, upg.icon, {
                fontSize: uiPx(18), fill: '#' + upg.color.toString(16).padStart(6, '0')
            }).setOrigin(0.5).setDepth(202));
            
            // Name
            addEl(this.add.text(cardX, cardY - cardH / 2 + 42, upg.name, {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#' + upg.color.toString(16).padStart(6, '0'),
                fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(202));
            
            // Description
            addEl(this.add.text(cardX, cardY - cardH / 2 + 58, upg.desc, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#aaaaaa',
                wordWrap: { width: cardW - 10 }, lineSpacing: 2, align: 'center'
            }).setOrigin(0.5, 0).setDepth(202));
            
            card.on('pointerover', () => card.setStrokeStyle(2, upg.color, 0.9));
            card.on('pointerout', () => card.setStrokeStyle(1, upg.color, 0.5));
            card.on('pointerdown', () => {
                this.closeCheckpointPanel();
                this.applyCheckpointUpgrade(wave, upg.id);
            });
        });
        
        // Extract button
        const extY = H / 2 - 10 + panelH / 2 - 22;
        const extBtn = addEl(this.add.rectangle(W / 2, extY, 120, 28, 0x2a1a1a, 0.85)
            .setStrokeStyle(1, 0xcc6644, 0.5).setDepth(201).setInteractive({ useHandCursor: true }));
        addEl(this.add.text(W / 2, extY, 'EXTRACT', {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#cc6644'
        }).setOrigin(0.5).setDepth(202));
        extBtn.on('pointerdown', () => {
            this.closeCheckpointPanel();
            this.defenseExtractSuccess();
        });
        
        // NPC line
        this.showNPCSpeechBubble(DEFENSE_DATA.npcLines.checkpoint[Math.floor(Math.random() * DEFENSE_DATA.npcLines.checkpoint.length)]);
    }
    
    closeCheckpointPanel() {
        this.popupActive = false;
        if (this._checkpointUI) {
            this._checkpointUI.forEach(el => { if (el && el.destroy) el.destroy(); });
            this._checkpointUI = null;
        }
    }
    
    // ── APPLY CHECKPOINT UPGRADE ──
    applyCheckpointUpgrade(wave, upgradeId) {
        const ms = this.modeState;
        ms.repairStage = Math.floor(wave / 3); // 1 at wave 3, 2 at wave 6, 3 at wave 9
        this.updateConvoyRepairVisuals();
        
        if (wave === 3) {
            // Shield installation
            ms.shieldType = upgradeId;
            const cfg = DEFENSE_DATA.shields[upgradeId];
            ms.shieldHp = cfg.hp;
            ms.shieldMaxHp = cfg.hp;
            ms.shieldActive = true;
            ms.shieldCooldown = 0;
            this.createConvoyShield(upgradeId);
            this.showModeAnnouncement('SHIELD ONLINE', `${upgradeId.replace('_', ' ').toUpperCase()} installed`);
        } else if (wave === 6) {
            if (upgradeId === 'foundry_arsenal') {
                ms.arsenalUpgraded = true;
                ms.soldiers.forEach(s => {
                    if (!s.downed) {
                        // Brief glow effect
                        if (s.sprite && s.sprite.active) {
                            const glow = this.add.circle(s.x, s.y, 15, parseInt(ms.foundry.palette.accent.replace('#',''), 16), 0.4).setDepth(100);
                            this.tweens.add({ targets: glow, alpha: 0, scale: 2, duration: 600, onComplete: () => glow.destroy() });
                        }
                    }
                });
                this.showModeAnnouncement('ARSENAL UPGRADED', 'Foundry soldiers armed with heavy weapons');
            } else if (upgradeId === 'power_surge') {
                ms.powerSurge = true;
                // Player glow
                if (this.player) {
                    const glow = this.add.circle(this.player.x, this.player.y, 18, parseInt(ms.foundry.palette.accent.replace('#',''), 16), 0.3).setDepth(100);
                    this.tweens.add({ targets: glow, alpha: 0, scale: 2.5, duration: 800, onComplete: () => glow.destroy() });
                }
                this.showModeAnnouncement('POWER SURGE', '+30% damage, +20% attack speed');
            } else if (upgradeId === 'foundry_rep') {
                ms.lootQualityBonus = 0.15;
                this.state.bits = (this.state.bits || 0) + 50;
                ms.bitsEarned += 50;
                this.showModeAnnouncement('FOUNDRY STANDING', `+50 bits — The ${ms.foundry.name} will remember this`);
            }
        } else if (wave === 9) {
            if (upgradeId === 'manual_turret') {
                ms.turretInstalled = true;
                this._buildTurretVisual();
                this.showModeAnnouncement('TURRET INSTALLED', 'Approach convoy and press E to mount');
            } else if (upgradeId === 'reinforcements') {
                ms.reinforcementsArrived = true;
                ms.caravanMaxHp += 40;
                ms.caravanHp = ms.caravanMaxHp;
                this._spawnReinforcementHumvee();
                this.showModeAnnouncement('REINFORCEMENTS', 'Foundry backup has arrived! Convoy HP +40');
            } else if (upgradeId === 'emergency_repair') {
                ms.caravanMaxHp += 20;
                ms.caravanHp = ms.caravanMaxHp;
                // Heal player
                const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(this.state.equipment).maxHealth || 0);
                this.state.health = maxHp;
                // Revive soldiers
                ms.soldiers.forEach(s => { s.downed = false; s.hp = s.maxHp; s.downTimer = 0; });
                this.showModeAnnouncement('EMERGENCY REPAIR', 'Full heal — all soldiers revived');
            }
        }
        
        // Resume waves after upgrade
        this.modeState.phase = 'intermission';
        this.showModeAnnouncement('WAVE ' + (ms.wavesCurrent + 1) + ' INCOMING', 'Prepare yourself', true);
        this.time.delayedCall(5000, () => this.startDefenseWave());
    }
    
    // ── CONVOY SHIELD ──
    createConvoyShield(type) {
        const cx = this.modeState.convoyX;
        const cy = this.modeState.convoyY;
        const cfg = DEFENSE_DATA.shields[type];
        const d = 10 + cy * 0.01 + 1;
        
        // Shield device on truck bed
        const p = this.modeState.foundry.palette;
        const pInt = (hex) => parseInt(hex.replace('#', ''), 16);
        this._shieldDevice = this.add.container(cx - 8, cy - 20 * 1.6).setDepth(d + 2);
        // Small box
        this._shieldDevice.add(this.add.rectangle(0, 0, 8, 6, pInt(p.metal)));
        this._shieldDevice.add(this.add.rectangle(0, -4, 6, 2, cfg.color, 0.8));
        // Pulsing indicator
        const indicator = this.add.circle(0, -6, 2, cfg.color, 0.8);
        this._shieldDevice.add(indicator);
        this.tweens.add({ targets: indicator, alpha: 0.3, duration: 800, yoyo: true, repeat: -1 });
        
        // Shield visual — large isometric dome bubble covering convoy + near area
        // Visual radius is larger than gameplay radius for dramatic effect
        const sr = Math.max(cfg.radius, 80); // minimum 80px visual radius
        const shieldG = this.add.graphics().setDepth(d - 0.5);
        this._shieldVisual = shieldG;
        
        // Dome geometry — sized to fully enclose the truck (125x50 at 1.6 scale)
        const baseW = sr * 2.8; // wide enough to cover truck + buffer
        const baseH = sr * 1.4; // iso ¾ squish
        const domeH = sr * 1.6; // dome height above base center
        
        // Helper: extract RGB from hex color
        const r = (cfg.color >> 16) & 0xff, g = (cfg.color >> 8) & 0xff, b = cfg.color & 0xff;
        
        // Hemisphere gradient fill — stacked ellipses shrinking upward
        for (let i = 0; i < 8; i++) {
            const frac = i / 7;
            const crossR = Math.sqrt(Math.max(0.01, 1 - frac * frac));
            const sliceW = baseW * crossR;
            const sliceH = baseH * crossR * (1 - frac * 0.3);
            const sliceY = cy - domeH * frac;
            const sliceAlpha = 0.06 * (1 - frac * 0.5);
            if (sliceW > 15) {
                shieldG.fillStyle(cfg.color, sliceAlpha);
                shieldG.fillEllipse(cx, sliceY, sliceW, sliceH);
            }
        }
        
        // Base ellipse — bright ground ring
        shieldG.fillStyle(cfg.color, 0.10);
        shieldG.fillEllipse(cx, cy, baseW, baseH);
        shieldG.lineStyle(2.0, cfg.color, 0.50);
        shieldG.strokeEllipse(cx, cy, baseW, baseH);
        
        // Longitude arcs (front-to-back bezier curves)
        // Each goes from south edge of base ellipse, up over dome, to north edge
        const longitudes = [-0.6, -0.3, 0, 0.3, 0.6];
        longitudes.forEach(t => {
            const x1 = cx + t * baseW * 0.45;
            const y1S = Math.sqrt(Math.max(0, 1 - (t*0.9)**2)) * baseH / 2;
            const y1 = cy + y1S; // south point on ellipse
            const y2 = cy - y1S; // north point on ellipse
            const peakY = cy - domeH * (1 - Math.abs(t) * 0.3);
            const ctrlX = cx + t * baseW * 0.15; // control point x (toward center)
            
            const alpha = 0.35 * (1 - Math.abs(t) * 0.4);
            shieldG.lineStyle(1.2, cfg.color, alpha);
            shieldG.beginPath();
            // Approximate quadratic bezier with 24 segments
            for (let s = 0; s <= 24; s++) {
                const u = s / 24;
                // Quadratic bezier: P = (1-u)²·P0 + 2(1-u)u·Ctrl + u²·P1
                const px = (1-u)*(1-u)*x1 + 2*(1-u)*u*ctrlX + u*u*x1;
                const py = (1-u)*(1-u)*y1 + 2*(1-u)*u*peakY + u*u*y2;
                if (s === 0) shieldG.moveTo(px, py);
                else shieldG.lineTo(px, py);
            }
            shieldG.strokePath();
        });
        
        // Latitude rings at 3 heights
        [0.25, 0.5, 0.75].forEach(hFrac => {
            const h = domeH * hFrac;
            const crossR = Math.sqrt(Math.max(0, 1 - hFrac * hFrac));
            const ringW = baseW * crossR;
            const ringH = baseH * crossR;
            const alpha = 0.25 * (1 - hFrac * 0.3);
            shieldG.lineStyle(1.0, cfg.color, alpha);
            shieldG.strokeEllipse(cx, cy - h, ringW, ringH);
        });
        
        // Top cap — bright spot
        shieldG.lineStyle(1.0, cfg.color, 0.35);
        shieldG.strokeEllipse(cx, cy - domeH * 0.92, 14, 7);
        shieldG.fillStyle(cfg.color, 0.15);
        shieldG.fillEllipse(cx, cy - domeH * 0.92, 14, 7);
        
        // Pulse: tween alpha instead of redrawing every frame
        this.tweens.add({
            targets: shieldG,
            alpha: { from: 1.0, to: 0.55 },
            duration: 1800,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.inOut'
        });
        
        // Shield HP bar (small, above truck)
        this._shieldHpBar = this.add.rectangle(cx - 30, cy - 30, 60, 3, cfg.color, 0.6).setDepth(d + 2).setOrigin(0, 0.5);
    }
    
    updateConvoyShield(dt) {
        const ms = this.modeState;
        if (!ms.shieldType) return;
        
        const cfg = DEFENSE_DATA.shields[ms.shieldType];
        const cx = ms.convoyX, cy = ms.convoyY;
        
        if (ms.shieldActive) {
            // Damage field — damage nearby enemies
            if (ms.shieldType === 'damage_field') {
                this.enemies.getChildren().forEach(e => {
                    if (!e.active) return;
                    const dist = Phaser.Math.Distance.Between(e.x, e.y, cx, cy);
                    if (dist < cfg.radius) {
                        e.hp -= cfg.dps * dt;
                        if (Math.random() < 0.02) {
                            const sp = this.add.circle(e.x + Phaser.Math.Between(-4, 4), e.y + Phaser.Math.Between(-4, 4), 1, cfg.color, 0.6).setDepth(20);
                            this.tweens.add({ targets: sp, alpha: 0, y: sp.y - 6, duration: 200, onComplete: () => sp.destroy() });
                        }
                        if (e.hp <= 0) this.killEnemy(e);
                    }
                });
            }
            
            // Repair aura — heal convoy + player
            if (ms.shieldType === 'repair_aura') {
                ms.caravanHp = Math.min(ms.caravanMaxHp, ms.caravanHp + cfg.convoyHps * dt);
                if (this.player) {
                    const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, cx, cy);
                    if (dist < cfg.radius) {
                        const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(this.state.equipment).maxHealth || 0);
                        this.state.health = Math.min(maxHp, this.state.health + cfg.playerHps * dt);
                    }
                }
            }
            
            // Barrier — check for enemy contact damaging the shield
            this.enemies.getChildren().forEach(e => {
                if (!e.active) return;
                const dist = Phaser.Math.Distance.Between(e.x, e.y, cx, cy);
                if (dist < cfg.radius + 5) {
                    const eCfg = CONFIG.enemyTypes[e.enemyType];
                    const dmg = (eCfg ? eCfg.damage : 10) * 0.15 * dt;
                    ms.shieldHp -= dmg;
                }
            });
            
            // Update shield HP bar
            if (this._shieldHpBar && this._shieldHpBar.active) {
                const pct = Math.max(0, ms.shieldHp / ms.shieldMaxHp);
                this._shieldHpBar.setDisplaySize(60 * pct, 3);
            }
            
            // Shield destroyed
            if (ms.shieldHp <= 0) {
                ms.shieldActive = false;
                ms.shieldHp = 0;
                ms.shieldCooldown = cfg.cooldown;
                // Visual destruction
                if (this._shieldVisual) { this._shieldVisual.setVisible(false); }
                if (this._shieldDevice) {
                    this._shieldDevice.list.forEach(c => { if (c.setTint) c.setTint(0x333333); });
                }
                // Sparks
                for (let i = 0; i < 5; i++) {
                    const sp = this.add.circle(cx + Phaser.Math.Between(-20, 20), cy + Phaser.Math.Between(-10, 10), 2, 0xffcc44, 0.7).setDepth(25);
                    this.tweens.add({ targets: sp, alpha: 0, y: sp.y - 10, duration: 300, onComplete: () => sp.destroy() });
                }
            }
        } else if (ms.shieldCooldown > 0) {
            // Cooldown
            ms.shieldCooldown -= dt * 1000;
            if (ms.shieldCooldown <= 0) {
                // Shield regenerates
                ms.shieldActive = true;
                ms.shieldHp = ms.shieldMaxHp;
                ms.shieldCooldown = 0;
                if (this._shieldVisual) { this._shieldVisual.setVisible(true); }
                if (this._shieldDevice) {
                    this._shieldDevice.list.forEach(c => { if (c.clearTint) _restoreTint(c); });
                }
            }
        }
    }
    
    // ── TURRET SYSTEM ──
    _buildTurretVisual() {
        if (!this._turretMount) return;
        this._turretMount.setVisible(true);
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const p = this.modeState.foundry.palette;
        const pInt = (hex) => parseInt(hex.replace('#', ''), 16);
        const met = tc(pInt(p.metal));
        const metL = tc(pInt(p.metalLight));
        const accent = tc(pInt(p.accent));
        
        // Turret base — rotating platform
        this._turretMount.add(this.add.ellipse(0, 2, 14, 8, met)); // base plate
        this._turretMount.add(this.add.rectangle(0, 0, 10, 10, met)); // body
        this._turretMount.add(this.add.rectangle(0, -3, 8, 3, metL)); // top housing
        
        // Gun barrel — extends forward (toward right = east by default)
        this._turretBarrel = this.add.container(0, -2);
        // Main barrel tube
        this._turretBarrel.add(this.add.rectangle(10, 0, 18, 3, met)); // barrel shaft
        this._turretBarrel.add(this.add.rectangle(19, 0, 4, 4, metL)); // muzzle brake
        this._turretBarrel.add(this.add.rectangle(19, 0, 2, 6, accent, 0.7)); // muzzle flash point (hidden until firing)
        // Ammo feed
        this._turretBarrel.add(this.add.rectangle(-2, 3, 6, 4, tc(0x3a3a2a))); // ammo box
        this._turretBarrel.add(this.add.rectangle(3, 2, 8, 1, tc(0x8a8a3a), 0.5)); // belt
        // Handle grips
        this._turretBarrel.add(this.add.rectangle(-4, -2, 3, 5, tc(0x2a2a1a)));
        this._turretBarrel.add(this.add.rectangle(5, -3, 2, 3, tc(0x2a2a1a)));
        
        this._turretMount.add(this._turretBarrel);
        
        // Accent ring
        this._turretMount.add(this.add.circle(0, -1, 6, accent, 0.3));
        
        // Overheat bar (HUD — screen-space, only visible when mounted)
        const hbX = CONFIG.width / 2 - 25;
        const hbY = CONFIG.height - 30;
        this._turretHeatBar = this.add.rectangle(
            hbX, hbY, 50, 4, 0x44cc44, 0.6
        ).setDepth(200).setScrollFactor(0).setVisible(false).setOrigin(0, 0.5);
        this._turretHeatBg = this.add.rectangle(
            hbX, hbY, 50, 4, 0x222222, 0.6
        ).setDepth(199).setScrollFactor(0).setVisible(false).setOrigin(0, 0.5).setStrokeStyle(1, 0x444444);
        this._turretHeatLabel = this.add.text(
            hbX + 25, hbY - 8,
            'TURRET HEAT', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#ccaa44' }
        ).setOrigin(0.5).setDepth(200).setScrollFactor(0).setVisible(false);
    }
    
    mountTurret() {
        if (this.modeState.turretMounted || !this.modeState.turretInstalled) return;
        this.modeState.turretMounted = true;
        
        // Move player to turret position
        const tx = this.modeState.convoyX - 5 * 1.6;
        const ty = this.modeState.convoyY - 18 * 1.6;
        this.player.setPosition(tx, ty);
        this.player.body.setVelocity(0, 0);
        this.player.setAlpha(0.5); // Dim player — they're "on" the turret
        
        // Show heat bar
        if (this._turretHeatBar) this._turretHeatBar.setVisible(true);
        if (this._turretHeatBg) this._turretHeatBg.setVisible(true);
        if (this._turretHeatLabel) this._turretHeatLabel.setVisible(true);
        
        this.showModeAnnouncement('TURRET MOUNTED', 'Auto-aim active — press E to dismount', true);
    }
    
    dismountTurret() {
        if (!this.modeState.turretMounted) return;
        this.modeState.turretMounted = false;
        this.player.setAlpha(1);
        
        // Move player slightly away from truck
        this.player.setPosition(this.modeState.convoyX + 30, this.modeState.convoyY + 30);
        
        if (this._turretHeatBar) this._turretHeatBar.setVisible(false);
        if (this._turretHeatBg) this._turretHeatBg.setVisible(false);
        if (this._turretHeatLabel) this._turretHeatLabel.setVisible(false);
    }
    
    updateTurret(dt) {
        const ms = this.modeState;
        if (!ms.turretInstalled || !ms.turretMounted) return;
        
        const tCfg = DEFENSE_DATA.turret;
        
        // Handle overheat
        if (ms.turretOverheated) {
            ms.turretHeat -= tCfg.coolRate * dt;
            if (ms.turretHeat <= 0) {
                ms.turretHeat = 0;
                ms.turretOverheated = false;
            }
            // Update heat bar
            if (this._turretHeatBar) {
                const pct = ms.turretHeat / tCfg.maxHeat;
                this._turretHeatBar.setDisplaySize(50 * pct, 4).setFillStyle(0xcc4444);
            }
            return;
        }
        
        // Find nearest enemy
        let nearest = null, nearDist = tCfg.range;
        this.enemies.getChildren().forEach(e => {
            if (!e.active) return;
            const dist = Phaser.Math.Distance.Between(ms.convoyX, ms.convoyY, e.x, e.y);
            if (dist < nearDist) { nearDist = dist; nearest = e; }
        });
        
        if (!nearest) return;
        
        // Rotate barrel toward target
        const angle = Phaser.Math.Angle.Between(ms.convoyX, ms.convoyY, nearest.x, nearest.y);
        if (this._turretBarrel) this._turretBarrel.setRotation(angle);
        
        // Fire
        if (!this._turretFireTimer) this._turretFireTimer = 0;
        this._turretFireTimer += dt * 1000;
        if (this._turretFireTimer >= tCfg.fireRate) {
            this._turretFireTimer = 0;
            
            // Create bullet
            const bx = ms.convoyX + Math.cos(angle) * 30;
            const by = ms.convoyY + Math.sin(angle) * 30;
            const bullet = this.add.rectangle(bx, by, 6, 2, tCfg.bulletColor, 0.9).setDepth(25).setRotation(angle);
            
            // Muzzle flash
            const flash = this.add.circle(bx, by, 4, 0xffcc44, 0.7).setDepth(26);
            this.tweens.add({ targets: flash, alpha: 0, scale: 2, duration: 80, onComplete: () => flash.destroy() });
            
            // Bullet travel
            const dist = Phaser.Math.Distance.Between(bx, by, nearest.x, nearest.y);
            const travelTime = (dist / tCfg.bulletSpeed) * 1000;
            this.tweens.add({
                targets: bullet, x: nearest.x, y: nearest.y, duration: travelTime,
                onComplete: () => {
                    bullet.destroy();
                    if (nearest.active) {
                        this.damageEnemy(nearest, tCfg.damage, 'turret');
                    }
                }
            });
            
            // Heat buildup
            ms.turretHeat += tCfg.heatPerShot;
            if (ms.turretHeat >= tCfg.maxHeat) {
                ms.turretOverheated = true;
                this.showModeAnnouncement('TURRET OVERHEATED', `Cooling — ${tCfg.overheatCooldown / 1000}s`, true);
            }
            
            // Update heat bar
            if (this._turretHeatBar) {
                const pct = ms.turretHeat / tCfg.maxHeat;
                const color = pct > 0.7 ? 0xcc4444 : pct > 0.4 ? 0xccaa44 : 0x44cc44;
                this._turretHeatBar.setDisplaySize(50 * pct, 4).setFillStyle(color);
            }
        }
        
        // Passive heat dissipation
        if (!ms.turretOverheated) {
            ms.turretHeat = Math.max(0, ms.turretHeat - tCfg.coolRate * 0.3 * dt);
        }
    }
    
    // ── REINFORCEMENT HUMVEE ──
    _spawnReinforcementHumvee() {
        const cx = this.modeState.convoyX;
        const cy = this.modeState.convoyY;
        const w = CONFIG.world.width;
        
        // Humvee drives in from east
        const humvee = SpriteManager.createVehicle(this, w + 60, cy + 30, 'side');
        humvee.setScale(1.0).setDepth(10 + (cy + 30) * 0.01);
        
        const parkX = cx - 80;
        this.tweens.add({
            targets: humvee, x: parkX, duration: 2500, ease: 'Quad.out',
            onComplete: () => {
                // Deploy 2 extra soldiers using character sprite system
                const solCfg = DEFENSE_DATA.soldier;
                const fIdR = this.modeState.foundry.id;
                
                for (let i = 0; i < 2; i++) {
                    const sx = parkX + Phaser.Math.Between(-15, 15);
                    const sy = cy + 30 + (i === 0 ? -12 : 12);
                    const d = 10 + sy * 0.01;
                    
                    const sol = SpriteManager.createNPCSprite(this, sx, sy, NPCManager.getFoundryPreset(fIdR, 'patrol'));
                    sol.setDepth(d);
                    
                    // Entrance animation
                    sol.setAlpha(0).setScale(0.5);
                    this.tweens.add({ targets: sol, alpha: 1, scaleX: 1, scaleY: 1, duration: 400, delay: 400 + i * 300 });
                    
                    this.modeState.soldiers.push({
                        sprite: sol, x: sx, y: sy,
                        role: 'reinforcement', name: 'Backup',
                        hp: solCfg.hp, maxHp: solCfg.hp,
                        downed: false, downTimer: 0, fireTimer: 0,
                        combatActive: true, _patrolDir: 1, _patrolTimer: 0
                    });
                }
            }
        });
    }
    
    // ── SOLDIER COMBAT AI ──
    updateFoundrySoldiers(dt) {
        const ms = this.modeState;
        if (!ms.soldiers) return;
        
        const cx = ms.convoyX, cy = ms.convoyY;
        const solCfg = DEFENSE_DATA.soldier;
        const arsenalMult = ms.arsenalUpgraded ? 2 : 1;
        const fireRate = ms.arsenalUpgraded ? solCfg.fireRate * 0.67 : solCfg.fireRate;
        const isIdle = ms.phase === 'discovery' || ms.phase === 'prepare';
        const isDialogue = ms.phase === 'dialogue';
        
        // Convoy exclusion zone — full truck footprint at 1.6 scale with 5px buffer
        // Bed: local(-8,0) 50x28 → world cx-53 to cx+27, cy±22
        // Cab: local(32,4) 22x22 → world cx+34 to cx+69, cy-11 to cy+24
        // Combined rect + buffer:
        const cvL = cx - 56, cvR = cx + 72, cvT = cy - 26, cvB = cy + 28;
        // Sliding collision: moves soldier outside convoy bounds axis-by-axis
        // instead of teleporting. Like wall collision — they slide along the edge.
        const convoyAvoid = (sol, prevX, prevY) => {
            if (sol.x > cvL && sol.x < cvR && sol.y > cvT && sol.y < cvB) {
                // Inside convoy. Undo each axis independently to find which one caused it
                const xInside = prevX > cvL && prevX < cvR;
                const yInside = prevY > cvT && prevY < cvB;
                if (!xInside) {
                    // X movement caused entry — revert X, keep Y
                    sol.x = prevX;
                } else if (!yInside) {
                    // Y movement caused entry — revert Y, keep X
                    sol.y = prevY;
                } else {
                    // Was already inside (e.g. spawned there) — push to nearest edge
                    const dL = sol.x - cvL, dR = cvR - sol.x, dT = sol.y - cvT, dB = cvB - sol.y;
                    const minD = Math.min(dL, dR, dT, dB);
                    if (minD === dL) sol.x = cvL - 2;
                    else if (minD === dR) sol.x = cvR + 2;
                    else if (minD === dT) sol.y = cvT - 2;
                    else sol.y = cvB + 2;
                }
                sol.sprite.setPosition(sol.x, sol.y);
            }
        };
        // Leash target: pull toward convoy but aim for a point OUTSIDE the body
        const leashTarget = (sol) => {
            // Project soldier angle onto convoy perimeter + buffer
            const dx = sol.x - cx, dy = sol.y - cy;
            const angle = Math.atan2(dy, dx);
            // Scale to be safely outside the rectangular convoy body
            const cos = Math.cos(angle), sin = Math.sin(angle);
            // Half-widths of convoy + buffer
            const hx = (cos >= 0 ? (cvR - cx) : (cx - cvL)) + 10;
            const hy = (sin >= 0 ? (cvB - cy) : (cy - cvT)) + 10;
            // Find the intersection of the ray with the expanded rect
            const tx = Math.abs(cos) < 0.01 ? 0 : hx / Math.abs(cos);
            const ty = Math.abs(sin) < 0.01 ? 0 : hy / Math.abs(sin);
            const t = Math.min(tx || 999, ty || 999);
            return { x: cx + cos * t, y: cy + sin * t };
        };
        
        ms.soldiers.forEach(sol => {
            if (!sol.sprite || !sol.sprite.active) return;
            
            // Downed recovery
            if (sol.downed) {
                sol.downTimer -= dt * 1000;
                if (sol.downTimer <= 0) {
                    sol.downed = false;
                    sol.hp = sol.maxHp * solCfg.recoveryHp;
                    sol.sprite.setAlpha(1);
                    if (sol.sprite.clearTint) _restoreTint(sol.sprite);
                    this.showNPCSpeechBubble(DEFENSE_DATA.npcLines.soldierUp[Math.floor(Math.random() * DEFENSE_DATA.npcLines.soldierUp.length)], 1500);
                }
                return;
            }
            
            // Dialogue phase — freeze all NPCs
            if (isDialogue) {
                SpriteManager.stopNPC(sol.sprite);
                return;
            }
            
            // Save position before movement for convoy sliding collision
            const prevX = sol.x, prevY = sol.y;
            
            // Idle behaviors (discovery, prepare, or not yet in combat)
            if (isIdle || !sol.combatActive) {
                if (sol.role === 'guard') {
                    // Guard: pace ±20px, face player when close
                    const playerDist = this.player ? Phaser.Math.Distance.Between(
                        this.player.x, this.player.y, sol.x, sol.y
                    ) : 999;
                    
                    if (playerDist < 45) {
                        // Within interact range — stop and face player
                        SpriteManager.stopNPC(sol.sprite);
                        const dx = this.player.x - sol.x;
                        const dy = this.player.y - sol.y;
                        const dir = Math.abs(dx) > Math.abs(dy)
                            ? (dx > 0 ? 'right' : 'left')
                            : (dy > 0 ? 'down' : 'up');
                        sol.sprite._npcDir = dir;
                        const dirMap = { down:0, down_right:1, right:2, up_right:3, up:4, up_left:5, left:6, down_left:7 };
                        sol.sprite.setFrame((dirMap[dir] || 0) * 3);
                    } else if (playerDist < 60) {
                        // Near — stop pacing, face player
                        SpriteManager.stopNPC(sol.sprite);
                        const dx = this.player.x - sol.x;
                        const dir = dx > 0 ? 'right' : 'left';
                        sol.sprite._npcDir = dir;
                        const dirMap = { down:0, down_right:1, right:2, up_right:3, up:4, up_left:5, left:6, down_left:7 };
                        sol.sprite.setFrame((dirMap[dir] || 0) * 3);
                    } else {
                        // Pace back and forth ±20px from home
                        sol._guardPaceTimer = (sol._guardPaceTimer || 0) + dt * 1000;
                        if (sol._guardPaceTimer > 3000) {
                            sol._guardPaceTimer = 0;
                            sol._guardPaceDir = (sol._guardPaceDir || 1) * -1;
                        }
                        const targetX = sol._homeX + sol._guardPaceDir * 20;
                        const dx = targetX - sol.x;
                        if (Math.abs(dx) > 1) {
                            sol.x += Math.sign(dx) * 18 * dt;
                            sol.sprite.setPosition(sol.x, sol.y);
                            SpriteManager.playNPCWalk(sol.sprite, dx > 0 ? 'right' : 'left');
                        } else {
                            SpriteManager.stopNPC(sol.sprite);
                        }
                    }
                    // Keep ! mark tracking guard position
                    if (sol.exclMark) sol.exclMark.setPosition(sol.x, sol.y - 24);
                    
                } else if (sol.role === 'patrol' || sol.role === 'reinforcement') {
                    // Waypoint patrol around convoy perimeter
                    if (sol._waypoints && sol._waypoints.length > 0) {
                        // Pause at waypoint
                        if (sol._waypointPause > 0) {
                            sol._waypointPause -= dt * 1000;
                            SpriteManager.stopNPC(sol.sprite);
                            convoyAvoid(sol, prevX, prevY);
                            return;
                        }
                        const wp = sol._waypoints[sol._waypointIdx || 0];
                        const dx = wp.x - sol.x;
                        const dy = wp.y - sol.y;
                        const dist = Math.sqrt(dx * dx + dy * dy);
                        
                        if (dist < 3) {
                            // Arrived at waypoint — pause 1-2s, advance
                            sol._waypointPause = 1000 + Math.random() * 1000;
                            sol._waypointIdx = ((sol._waypointIdx || 0) + 1) % sol._waypoints.length;
                            SpriteManager.stopNPC(sol.sprite);
                        } else {
                            // Walk toward waypoint
                            const speed = 22;
                            sol.x += (dx / dist) * speed * dt;
                            sol.y += (dy / dist) * speed * dt;
                            sol.sprite.setPosition(sol.x, sol.y);
                            // Pick best walk direction from dx/dy
                            const absDx = Math.abs(dx), absDy = Math.abs(dy);
                            let walkDir;
                            if (absDx > absDy * 1.5) walkDir = dx > 0 ? 'right' : 'left';
                            else if (absDy > absDx * 1.5) walkDir = dy > 0 ? 'down' : 'up';
                            else if (dx > 0) walkDir = dy > 0 ? 'down_right' : 'up_right';
                            else walkDir = dy > 0 ? 'down_left' : 'up_left';
                            SpriteManager.playNPCWalk(sol.sprite, walkDir);
                        }
                    } else {
                        // Fallback: simple left-right (reinforcements without waypoints)
                        sol._patrolTimer += dt * 1000;
                        if (sol._patrolTimer > 2000) {
                            sol._patrolTimer = 0;
                            sol._patrolDir *= -1;
                        }
                        const newX = sol.x + sol._patrolDir * 15 * dt;
                        if (sol._patrolMinX && (newX < sol._patrolMinX || newX > sol._patrolMaxX)) sol._patrolDir *= -1;
                        else sol.x = newX;
                        sol.sprite.setPosition(sol.x, sol.y);
                        SpriteManager.playNPCWalk(sol.sprite, sol._patrolDir > 0 ? 'right' : 'left');
                    }
                    
                } else if (sol.role === 'mechanic') {
                    // Work cycle: working(6-8s) → standing(1s) → walk to tool(1s) → walk back(1s) → working
                    sol._mechTimer = (sol._mechTimer || 0) + dt * 1000;
                    const state = sol._mechState || 'working';
                    
                    if (state === 'working') {
                        // Crouched at convoy, sparks handled by timed event
                        sol.sprite.setScale(0.9);
                        SpriteManager.stopNPC(sol.sprite);
                        if (!sol._mechWorkDur) sol._mechWorkDur = 7000 + Math.random() * 2000;
                        if (sol._mechTimer > sol._mechWorkDur) {
                            sol._mechState = 'standing';
                            sol._mechTimer = 0;
                            sol._mechWorkDur = 0; // Reset for next cycle
                            sol.sprite.setScale(1.0);
                        }
                    } else if (state === 'standing') {
                        SpriteManager.stopNPC(sol.sprite);
                        if (sol._mechTimer > 800) {
                            sol._mechState = 'walking_away';
                            sol._mechTimer = 0;
                        }
                    } else if (state === 'walking_away') {
                        // Walk toward tool bench
                        const toolX = sol._mechToolX || (sol._homeX + 15);
                        const dx = toolX - sol.x;
                        if (Math.abs(dx) > 1) {
                            sol.x += Math.sign(dx) * 20 * dt;
                            sol.sprite.setPosition(sol.x, sol.y);
                            SpriteManager.playNPCWalk(sol.sprite, dx > 0 ? 'right' : 'left');
                        } else {
                            SpriteManager.stopNPC(sol.sprite);
                            if (sol._mechTimer > 1200) {
                                sol._mechState = 'walking_back';
                                sol._mechTimer = 0;
                            }
                        }
                    } else if (state === 'walking_back') {
                        const dx = sol._homeX - sol.x;
                        if (Math.abs(dx) > 1) {
                            sol.x += Math.sign(dx) * 20 * dt;
                            sol.sprite.setPosition(sol.x, sol.y);
                            SpriteManager.playNPCWalk(sol.sprite, dx > 0 ? 'right' : 'left');
                        } else {
                            sol.x = sol._homeX;
                            sol.sprite.setPosition(sol.x, sol.y);
                            sol._mechState = 'working';
                            sol._mechTimer = 0;
                        }
                    }
                } else {
                    SpriteManager.stopNPC(sol.sprite);
                }
                convoyAvoid(sol, prevX, prevY);
                return;
            }
            
            // Combat — find nearest enemy, face them continuously, shoot on timer
            // Track nearest enemy for facing (even between shots)
            let nearestEnemy = null, nearestDist = Infinity;
            this.enemies.getChildren().forEach(e => {
                if (!e.active) return;
                const d = Phaser.Math.Distance.Between(sol.x, sol.y, e.x, e.y);
                if (d < solCfg.range && d < nearestDist) { nearestDist = d; nearestEnemy = e; }
            });
            
            // Face nearest enemy between shots (unless currently in shoot animation)
            if (nearestEnemy && !sol._shootAnimActive) {
                const dx = nearestEnemy.x - sol.x, dy = nearestEnemy.y - sol.y;
                const adx = Math.abs(dx), ady = Math.abs(dy);
                let faceDir;
                if (ady > adx * 1.5) faceDir = dy > 0 ? 'down' : 'up';
                else if (adx > ady * 1.5) faceDir = dx > 0 ? 'right' : 'left';
                else if (dx > 0) faceDir = dy > 0 ? 'down_right' : 'up_right';
                else faceDir = dy > 0 ? 'down_left' : 'up_left';
                const dirMap8 = {down:0,down_right:1,right:2,up_right:3,up:4,up_left:5,left:6,down_left:7};
                sol.sprite.setFrame((dirMap8[faceDir] || 0) * 3);
            }
            
            sol.fireTimer += dt * 1000;
            if (sol.fireTimer >= fireRate) {
                // Find nearest enemy prioritizing those near convoy
                let target = null, bestScore = Infinity;
                this.enemies.getChildren().forEach(e => {
                    if (!e.active) return;
                    const distToSol = Phaser.Math.Distance.Between(sol.x, sol.y, e.x, e.y);
                    const distToConvoy = Phaser.Math.Distance.Between(cx, cy, e.x, e.y);
                    if (distToSol > solCfg.range) return;
                    const score = distToConvoy < 80 ? distToSol * 0.5 : distToSol;
                    if (score < bestScore) { bestScore = score; target = e; }
                });
                
                if (target) {
                    sol.fireTimer = 0;
                    const damage = solCfg.damage * arsenalMult;
                    
                    // Face target — 8-direction
                    const dx = target.x - sol.x, dy = target.y - sol.y;
                    const adx = Math.abs(dx), ady = Math.abs(dy);
                    let faceDir;
                    if (ady > adx * 1.5) faceDir = dy > 0 ? 'down' : 'up';
                    else if (adx > ady * 1.5) faceDir = dx > 0 ? 'right' : 'left';
                    else if (dx > 0) faceDir = dy > 0 ? 'down_right' : 'up_right';
                    else faceDir = dy > 0 ? 'down_left' : 'up_left';
                    const dirMap8 = {down:0,down_right:1,right:2,up_right:3,up:4,up_left:5,left:6,down_left:7};
                    const dirIdx = dirMap8[faceDir] || 0;
                    
                    // Shooting pose: walk frame 1 (arm forward) + brief white flash
                    sol._shootAnimActive = true;
                    sol.sprite.setFrame(dirIdx * 3 + 1);
                    sol.sprite.setTint(0xffffff);
                    this.time.delayedCall(120, () => {
                        if (sol.sprite && sol.sprite.active) {
                            sol.sprite.setFrame(dirIdx * 3); // back to idle
                            _restoreTint(sol.sprite);
                            sol._shootAnimActive = false;
                        }
                    });
                    
                    // Bullet visual
                    const angle = Phaser.Math.Angle.Between(sol.x, sol.y, target.x, target.y);
                    const bx = sol.x + Math.cos(angle) * 12;
                    const by = sol.y + Math.sin(angle) * 12;
                    const bullet = this.add.rectangle(bx, by, 4, 2, solCfg.bulletColor, 0.8).setDepth(20).setRotation(angle);
                    
                    // Muzzle flash
                    const mf = this.add.circle(bx, by, 3, 0xffcc44, 0.7).setDepth(21);
                    this.tweens.add({ targets: mf, alpha: 0, scale: 2, duration: 80, onComplete: () => mf.destroy() });
                    
                    const dist = Phaser.Math.Distance.Between(sol.x, sol.y, target.x, target.y);
                    const travelTime = (dist / solCfg.bulletSpeed) * 1000;
                    
                    this.tweens.add({
                        targets: bullet, x: target.x, y: target.y, duration: Math.max(50, travelTime),
                        onComplete: () => {
                            bullet.destroy();
                            if (target.active) {
                                this.damageEnemy(target, damage, 'soldier');
                                // Arsenal AoE splash
                                if (ms.arsenalUpgraded) {
                                    this.enemies.getChildren().forEach(e2 => {
                                        if (!e2.active || e2 === target) return;
                                        if (Phaser.Math.Distance.Between(target.x, target.y, e2.x, e2.y) < 10) {
                                            this.damageEnemy(e2, Math.floor(damage * 0.3), 'soldier_splash');
                                        }
                                    });
                                }
                            }
                        }
                    });
                }
            }
            
            // Soldiers stay near convoy — leash to position outside convoy body
            const distToConvoy = Phaser.Math.Distance.Between(sol.x, sol.y, cx, cy);
            if (distToConvoy > solCfg.leashDist) {
                const lt = leashTarget(sol);
                const angle = Phaser.Math.Angle.Between(sol.x, sol.y, lt.x, lt.y);
                sol.x += Math.cos(angle) * 30 * dt;
                sol.y += Math.sin(angle) * 30 * dt;
                sol.sprite.setPosition(sol.x, sol.y);
            }
            // Sliding collision: prevent soldiers from entering convoy body
            convoyAvoid(sol, prevX, prevY);
        });
    }
    
    // Damage a soldier (called from enemy contact in updateDefenseMode)
    damageSoldier(sol, dmg) {
        if (sol.downed) return;
        sol.hp -= dmg;
        if (sol.hp <= 0) {
            sol.downed = true;
            sol.hp = 0;
            sol.downTimer = DEFENSE_DATA.soldier.downTime;
            // Visual — grey tint, half alpha
            if (sol.sprite && sol.sprite.active) {
                sol.sprite.setAlpha(0.4);
                if (sol.sprite.setTint) sol.sprite.setTint(0x666666);
            }
            this.showNPCSpeechBubble(DEFENSE_DATA.npcLines.soldierDown[Math.floor(Math.random() * DEFENSE_DATA.npcLines.soldierDown.length)], 2000);
        }
    }
    
    // ── CONVOY REPAIR VISUALS ──
    updateConvoyRepairVisuals() {
        const stage = this.modeState.repairStage;
        // Smoke rate decreases with repair
        if (this._convoySmoke) {
            this._convoySmoke.rate = [3, 2, 1, 0.3, 0][stage] || 0;
        }
        // At stage 3 (wave 9), engine rumble starts
        if (stage >= 3 && this.caravanContainer) {
            this.tweens.killTweensOf(this.caravanContainer);
            this.tweens.add({
                targets: this.caravanContainer,
                y: this.modeState.convoyY - 1, duration: 200, yoyo: true, repeat: -1, ease: 'Sine.inOut'
            });
        }
    }
    
    // ── DEFENSE MODE — 12-wave Foundry convoy protection ===
    
    getDefenseWaveEnemies(wave, reach) {
        // Tiered enemy composition for 12-wave Foundry defense
        let tier;
        if (wave <= 3) tier = 'light';
        else if (wave <= 6) tier = 'medium';
        else if (wave <= 9) tier = 'heavy';
        else tier = 'intense';
        
        const comp = DEFENSE_DATA.waveComposition[tier];
        // Build weighted pool — husks always common, advanced types rarer
        const pool = [];
        comp.types.forEach(t => {
            const weight = (t === 'husk') ? 4 : (t === 'flicker' || t === 'husk_crawl') ? 3 : 1;
            for (let i = 0; i < weight; i++) pool.push(t);
        });
        return pool;
    }
    
    getDefenseWaveSize(wave, reach) {
        // Smaller than before — buildings slow enemies, more tactical
        const base = 3 + wave * 2 + Math.floor(reach * 0.3);
        return Math.min(base, 24);
    }
    
    createDefenseObjective() {
        const cx = CONFIG.world.width / 2;
        const cy = CONFIG.world.height / 2;
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const d = 10 + cy * 0.01;
        
        // === SUPPLY CARAVAN — large military-style truck, isometric ¾ view ===
        this.caravanContainer = this.add.container(cx, cy).setDepth(d).setScale(1.6);
        
        // Ground shadow
        this.caravanContainer.add(this.add.ellipse(0, 22, 90, 20, 0x000000, 0.35));
        
        const bodyColor = tc(0x4a5a3a);    // olive drab
        const bodyDark = tc(0x3a4a2a);
        const bodyLight = tc(0x5a6a4a);
        const metalColor = tc(0x3a3a3a);
        const canvasColor = tc(0x6a6a55);  // tarp cover
        const canvasDark = tc(0x5a5a45);
        const wheelColor = 0x1a1a1a;
        
        // === WHEELS (large, military-style) ===
        const wOff = 28;
        const wY = 18;
        // Rear axle (dual wheels)
        this.caravanContainer.add(this.add.ellipse(-wOff, wY, 13, 7, wheelColor));
        this.caravanContainer.add(this.add.ellipse(-wOff, wY, 8, 5, tc(0x2a2a2a)));
        this.caravanContainer.add(this.add.ellipse(-wOff, wY, 3, 2, tc(0x3a3a3a)));
        this.caravanContainer.add(this.add.ellipse(-wOff - 4, wY + 1, 11, 6, wheelColor));
        // Front axle
        this.caravanContainer.add(this.add.ellipse(wOff, wY, 13, 7, wheelColor));
        this.caravanContainer.add(this.add.ellipse(wOff, wY, 8, 5, tc(0x2a2a2a)));
        this.caravanContainer.add(this.add.ellipse(wOff, wY, 3, 2, tc(0x3a3a3a)));
        
        // Undercarriage / chassis
        this.caravanContainer.add(this.add.rectangle(0, 16, 72, 5, tc(0x1a1a1a)));
        
        // === TRUCK BED (cargo area) — rear 2/3 of vehicle ===
        // Bed floor (visible as top surface)
        this.caravanContainer.add(this.add.rectangle(-8, 0, 50, 28, bodyDark));
        // Bed walls — front face (lower panel showing depth)
        this.caravanContainer.add(this.add.rectangle(-8, 10, 50, 8, bodyColor));
        // Side wall (right edge depth strip)
        this.caravanContainer.add(this.add.rectangle(17, 2, 4, 26, tc(IsoRenderer.darken(0x4a5a3a, 0.2))));
        // Bed rail / top edge
        this.caravanContainer.add(this.add.rectangle(-8, -5, 50, 2, bodyLight));
        
        // === CANVAS TARP COVER (arched over cargo) ===
        // Tarp ribs (hoops)
        this.caravanContainer.add(this.add.rectangle(-22, -10, 3, 12, metalColor));
        this.caravanContainer.add(this.add.rectangle(-8, -11, 3, 14, metalColor));
        this.caravanContainer.add(this.add.rectangle(6, -10, 3, 12, metalColor));
        // Tarp surface (top)
        this.caravanContainer.add(this.add.rectangle(-8, -14, 48, 10, canvasColor));
        // Tarp front face
        this.caravanContainer.add(this.add.rectangle(-8, -8, 48, 4, canvasDark));
        // Tarp highlight ridge
        this.caravanContainer.add(this.add.rectangle(-8, -17, 44, 2, tc(IsoRenderer.lighten(0x6a6a55, 0.12))));
        // Side lashing ropes
        this.caravanContainer.add(this.add.rectangle(17, -8, 1, 10, tc(0x5a5a4a)));
        this.caravanContainer.add(this.add.rectangle(-33, -8, 1, 10, tc(0x5a5a4a)));
        // Tarp back (open, showing dark interior)
        this.caravanContainer.add(this.add.rectangle(-32, -6, 3, 16, canvasDark));
        this.caravanContainer.add(this.add.rectangle(-31, -2, 2, 8, tc(0x1a1a0a)));
        
        // === CARGO visible inside (supply crates) ===
        this.caravanContainer.add(this.add.rectangle(-18, -4, 10, 8, tc(0x5a4a2a)));
        this.caravanContainer.add(this.add.rectangle(-18, -6, 10, 4, tc(0x6a5a3a)));
        this.caravanContainer.add(this.add.rectangle(-6, -3, 8, 7, tc(0x4a5a3a)));
        this.caravanContainer.add(this.add.rectangle(-6, -5, 8, 3, tc(0x5a6a4a)));
        
        // === CAB (front 1/3) ===
        // Cab body
        this.caravanContainer.add(this.add.rectangle(32, 4, 22, 22, bodyDark));
        this.caravanContainer.add(this.add.rectangle(32, 0, 20, 16, bodyColor));
        // Cab roof
        this.caravanContainer.add(this.add.rectangle(32, -8, 20, 6, bodyDark));
        this.caravanContainer.add(this.add.rectangle(32, -10, 18, 4, bodyLight));
        // Windshield
        this.caravanContainer.add(this.add.rectangle(32, -3, 14, 8, tc(0x1a2530)));
        // Side window
        this.caravanContainer.add(this.add.rectangle(42, -2, 3, 6, tc(0x1a2530)));
        // Cab side depth strip
        this.caravanContainer.add(this.add.rectangle(42, 4, 3, 20, tc(IsoRenderer.darken(0x4a5a3a, 0.18))));
        
        // Headlights
        this.caravanContainer.add(this.add.rectangle(43, 8, 3, 4, tc(0xaaaa7a)));
        this.caravanContainer.add(this.add.rectangle(43, -1, 3, 3, tc(0x9a9a6a)));
        // Front bumper (heavy duty)
        this.caravanContainer.add(this.add.rectangle(44, 10, 4, 16, metalColor));
        // Grille
        this.caravanContainer.add(this.add.rectangle(43, 6, 2, 8, tc(0x2a2a2a)));
        
        // Taillights
        this.caravanContainer.add(this.add.rectangle(-33, 8, 2, 4, tc(0x8a2222)));
        // Rear bumper
        this.caravanContainer.add(this.add.rectangle(-34, 10, 3, 12, metalColor));
        
        // Mud flaps
        this.caravanContainer.add(this.add.rectangle(-wOff - 2, wY - 4, 6, 3, tc(0x1a1a1a)));
        this.caravanContainer.add(this.add.rectangle(wOff + 2, wY - 4, 5, 3, tc(0x1a1a1a)));
        
        // Wheel well arches
        this.caravanContainer.add(this.add.ellipse(-wOff, 11, 16, 8, bodyDark));
        this.caravanContainer.add(this.add.ellipse(wOff, 11, 14, 8, bodyDark));
        
        // === CARAVAN HP BAR (below vehicle) ===
        this.caravanHpBg = this.add.rectangle(cx, cy + 32, 80, 6, 0x222222, 0.8).setDepth(d + 1).setStrokeStyle(1, 0x444444);
        this.caravanHpBar = this.add.rectangle(cx - 39, cy + 32, 78, 4, 0x44cc44).setDepth(d + 1.01).setOrigin(0, 0.5);
        this.caravanHpLabel = this.add.text(cx, cy + 32, 'TRANSPORT', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#aaaaaa'
        }).setOrigin(0.5).setDepth(d + 1.02).setAlpha(0.7);
        
        // Collision body for the caravan
        this.caravanBody = this.add.zone(cx, cy, 90, 36);
        this.physics.add.existing(this.caravanBody, true);
        this.physics.add.collider(this.player, this.caravanBody);
        
        // === DEFENSE HUD — compact pill at top-left ===
        const hudX = 12, hudY = 36;
        this.defenseHudBg = this.add.rectangle(hudX + 56, hudY + 10, 120, 30, 0x000000, 0.6)
            .setStrokeStyle(1, 0x443322, 0.4).setScrollFactor(0).setDepth(99);
        this.defenseWaveText = this.add.text(hudX + 6, hudY + 2, 'WAVE 0/15', {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#ccaa66', fontStyle: 'bold'
        }).setScrollFactor(0).setDepth(100);
        this.defenseEnemyText = this.add.text(hudX + 6, hudY + 15, '', {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866'
        }).setScrollFactor(0).setDepth(100);
        
        // === CARAVAN IDLE ANIMATION ===
        // Engine idle bob
        this.tweens.add({
            targets: this.caravanContainer,
            y: cy - 0.5, duration: 800, yoyo: true, repeat: -1, ease: 'Sine.inOut'
        });
        // Exhaust smoke from rear
        this.time.addEvent({ delay: 500, loop: true, callback: () => {
            if (!this.caravanContainer || !this.caravanContainer.active) return;
            if (this.modeState.phase === 'complete' || this.modeState.phase === 'failed') return;
            const ex = cx - 38 + Phaser.Math.Between(-3, 3);
            const ey = cy + 12 + Phaser.Math.Between(-2, 2);
            const smoke = this.add.circle(ex, ey, Phaser.Math.Between(2, 4), 0x444444, 0.35).setDepth(d - 0.1);
            this.tweens.add({
                targets: smoke, alpha: 0, x: ex - Phaser.Math.Between(8, 18),
                y: ey - Phaser.Math.Between(6, 14), scale: 1.8,
                duration: Phaser.Math.Between(600, 1000),
                onComplete: () => smoke.destroy()
            });
        }});
        
        // === AMMO SUPPLY DROPS — caravan ejects a supply crate every 20s during waves ===
        this.time.addEvent({ delay: 20000, loop: true, callback: () => {
            if (!this.caravanContainer || !this.caravanContainer.active) return;
            if (this.modeState.phase !== 'wave' && this.modeState.phase !== 'spawning') return;
            
            // Animate crate ejecting from truck rear
            const crateX = cx - 90 + Phaser.Math.Between(-20, 20); // well behind truck
            const crateY = cy + Phaser.Math.Between(-15, 15);
            
            // Crate visual — isometric supply box (¾ view: front face wide, side face strip, foreshortened top)
            const crate = this.add.container(cx - 40, cy).setDepth(d + 2);
            // Front face (wide, main visible surface)
            const crateFront = this.add.rectangle(0, 2, 20, 8, 0x4a5a3a);
            // Top surface (foreshortened)
            const crateTop = this.add.rectangle(0, -3, 20, 6, 0x5a6a4a);
            // Side face (depth strip on right)
            const crateSide = this.add.rectangle(10, 0, 4, 14, 0x3a4a2a);
            // Strap detail
            const crateStrap1 = this.add.rectangle(0, -3, 18, 1, 0x3a3a2a);
            const crateStrap2 = this.add.rectangle(0, 2, 18, 1, 0x3a3a2a);
            // Stencil marking on top
            const crateMark = this.add.rectangle(-3, -3, 6, 3, 0x2a3a1a);
            // Icon
            const crateIcon = this.add.text(0, -1, '◆', { fontSize: uiPx(8), fill: '#ddaa44' }).setOrigin(0.5);
            crate.add([crateFront, crateTop, crateSide, crateStrap1, crateStrap2, crateMark, crateIcon]);
            
            // Eject animation — arc out from truck rear, bounce landing
            this.tweens.add({
                targets: crate, x: crateX, y: crateY + 20,
                duration: 500, ease: 'Bounce.out',
                onComplete: () => {
                    // Supply crate gives ammo (primary purpose)
                    crate.lootType = 'ammo';
                    crate.lootAmount = Phaser.Math.Between(3, 6);
                    crate.lootColor = 0xddaa44;
                    crate.isSupplyCrate = true;
                    // Bonus health on pickup handled via override
                    crate._bonusHealth = Phaser.Math.Between(5, 12);
                    
                    // Pulse glow
                    this.tweens.add({
                        targets: crateTop, alpha: 0.6, duration: 500, yoyo: true, repeat: -1
                    });
                    
                    // Add to loot drops for auto-pickup
                    if (!this.lootDrops) this.lootDrops = [];
                    this.lootDrops.push(crate);
                    
                    // Despawn after 15s
                    this.time.delayedCall(15000, () => {
                        if (crate.active) {
                            const idx = this.lootDrops.indexOf(crate);
                            if (idx > -1) this.lootDrops.splice(idx, 1);
                            this.tweens.add({
                                targets: crate, alpha: 0, scale: 0.3, duration: 300,
                                onComplete: () => crate.destroy()
                            });
                        }
                    });
                }
            });
            
            // Notification
            this.showModeAnnouncement('SUPPLY DROP', 'Ammo & med kit deployed', true);
        }});
    }
    
    startDefenseWave() {
        if (this.modeState.phase === 'complete' || this.modeState.phase === 'failed' || this.state.dead) return;
        
        const reach = this.destinationNode?.reach || 1;
        this.modeState.wavesCurrent++;
        this.modeState.phase = 'spawning';
        this.modeState.waveStartTime = Date.now();
        
        const wave = this.modeState.wavesCurrent;
        const waveSize = this.getDefenseWaveSize(wave, reach);
        const enemyPool = this.getDefenseWaveEnemies(wave, reach);
        this.modeState.enemiesInWave = waveSize;
        this.modeState.enemiesSpawned = 0;
        
        // Wave announcement
        const isFinal = wave === 12;
        let subtitle = `${waveSize} hostiles inbound`;
        if (isFinal) subtitle = 'FINAL WAVE — ELITE HOSTILE INCOMING';
        
        this.showModeAnnouncement(`WAVE ${wave}/12`, subtitle);
        if (this.defenseWaveText) this.defenseWaveText.setText(`WAVE ${wave}/12`);
        
        // NPC speech bubble
        const startLines = DEFENSE_DATA.npcLines.waveStart;
        this.showNPCSpeechBubble(startLines[Math.floor(Math.random() * startLines.length)]);
        
        // Staggered spawning from edges
        const w = CONFIG.world.width, h = CONFIG.world.height;
        for (let i = 0; i < waveSize; i++) {
            this.time.delayedCall(i * 350, () => {
                if (this.state.dead || this.modeState.phase === 'failed') return;
                
                // Spawn from random edge
                const edge = Math.floor(Math.random() * 4);
                let x, y;
                if (edge === 0) { x = Phaser.Math.Between(30, w - 30); y = 15; }
                else if (edge === 1) { x = Phaser.Math.Between(30, w - 30); y = h - 15; }
                else if (edge === 2) { x = 15; y = Phaser.Math.Between(30, h - 30); }
                else { x = w - 15; y = Phaser.Math.Between(30, h - 30); }
                
                const type = enemyPool[Math.floor(Math.random() * enemyPool.length)];
                this.spawnEnemy(x, y, type);
                this.modeState.enemiesSpawned++;
                
                if (this.modeState.enemiesSpawned >= waveSize) {
                    this.modeState.phase = 'wave';
                }
            });
        }
        
        // Wave 12: spawn mini-boss 3 seconds after last enemy
        if (isFinal) {
            this.time.delayedCall(waveSize * 350 + 3000, () => {
                if (this.state.dead) return;
                this._spawnWave12MiniBoss(reach);
            });
        }
    }
    
    _spawnWave12MiniBoss(reach) {
        const w = CONFIG.world.width, h = CONFIG.world.height;
        
        // Select boss type based on reach
        const bossIndex = Math.min(4, Math.floor((reach - 1) / 2));
        const bossTypes = ['warden', 'swarmQueen', 'phantom', 'ironclad', 'cubeAnomaly'];
        const bossType = bossTypes[bossIndex];
        
        // Use existing miniboss spawn but with boss-type flavor
        const mbx = w / 2;
        const mby = 30;
        
        // Ground shake + red flash
        this.cameras.main.shake(400, 0.008);
        const redFlash = this.add.rectangle(CONFIG.width / 2, CONFIG.height / 2, CONFIG.width, CONFIG.height, 0xff0000, 0.15)
            .setScrollFactor(0).setDepth(97);
        this.tweens.add({ targets: redFlash, alpha: 0, duration: 600, onComplete: () => redFlash.destroy() });
        
        this.showModeAnnouncement('ELITE HOSTILE DETECTED', bossType.toUpperCase() + ' — HOLD THE LINE');
        
        // Spawn as enhanced deadlock with boss modifiers
        this.spawnDefenseMiniboss(mbx, mby, 12, reach);
        
        // Store boss type for modifier effects in updateDefenseMode
        this.modeState.wave12BossType = bossType;
    }
    
    spawnDefenseMiniboss(x, y, wave, reach) {
        // Miniboss: enhanced deadlock with extra HP and size
        const cfg = CONFIG.enemyTypes['deadlock'];
        if (!cfg) return;
        
        SpriteManager.buildEnemySheet(this, 'deadlock');
        const sheetKey = 'enemy_deadlock_sheet';
        const hasSheet = this.textures.exists(sheetKey);
        if (!hasSheet) SpriteManager.getTexture(this, 'enemy_deadlock');
        
        const e = this.physics.add.sprite(x, y, hasSheet ? sheetKey : 'enemy_deadlock');
        e.setDisplaySize(44, 44).setDepth(20); // Larger than normal deadlock (38)
        e.enemyType = 'deadlock';
        e.hasAnimSheet = hasSheet;
        e.isMiniboss = true;
        
        // Scaled stats
        const hpMult = wave >= 10 ? 3.5 : 2.5;
        e.hp = Math.floor(cfg.health * hpMult + reach * 20);
        e.maxHp = e.hp;
        e.canAttack = true;
        e.setCollideWorldBounds(true);
        e.aiState = 'chase';
        e.awareness = 100;
        e.lastKnownPos = { x: this.player.x, y: this.player.y };
        e.patrolTarget = null;
        e.patrolPauseTimer = 0;
        e.stuckTimer = 0;
        e.lastPos = { x, y };
        
        // Miniboss alternates: chase player, then charge at caravan
        e._targetingCaravan = false;
        e._slamCooldown = 0;
        e._slamReady = false;
        
        // Tinted red to distinguish from normal enemies
        e.setTint(0xff6644);
        
        // Dramatic entrance
        e.setAlpha(0).setScale(0.3);
        this.tweens.add({ targets: e, alpha: 1, scale: 1, duration: 500, ease: 'Back.out' });
        this.enemies.add(e);
        
        // Miniboss HP indicator (UIManager)
        e._minibossHP = UIManager.createHealthBar(this, 'enemy', {
            x: x, y: y - 28, depth: 25, width: 50, height: 6
        });
        e._minibossHP.updateHP(e.hp, e.maxHp);
        const hpLabel = this.add.text(x, y - 28, 'ELITE', {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#ffaa66'
        }).setOrigin(0.5).setDepth(25.2);
        e._minibossHpLabel = hpLabel;
        
        // AoE slam timer — every 6 seconds, stored for cleanup
        e._slamTimer = this.time.addEvent({ delay: 6000, loop: true, callback: () => {
            if (!e.active || e.hp <= 0) { if (e._slamTimer) e._slamTimer.destroy(); return; }
            this.minibossSlam(e);
        }});
        
        this.showModeAnnouncement('MINIBOSS', 'Elite hostile detected!', true);
    }
    
    minibossSlam(e) {
        if (!e.active || e.hp <= 0) return;
        
        // Windup — freeze in place, flash
        e.setVelocity(0, 0);
        e.setTint(0xffcc44);
        
        // Warning ring
        const warn = this.add.circle(e.x, e.y, 60, 0xff4444, 0.15).setDepth(9);
        const warnBorder = this.add.circle(e.x, e.y, 60, 0xff4444, 0).setDepth(9).setStrokeStyle(2, 0xff6644, 0.5);
        this.tweens.add({ targets: [warn, warnBorder], scale: 1.2, alpha: 0.3, duration: 600 });
        
        this.time.delayedCall(700, () => {
            if (!e.active) { warn.destroy(); warnBorder.destroy(); return; }
            
            // SLAM — damage everything in radius
            const slamRadius = 65;
            const slamDmg = 20;
            const cx = this.modeState?.convoyX || CONFIG.world.width / 2;
            const cy = this.modeState?.convoyY || CONFIG.world.height / 2;
            
            // Damage player
            const distP = Phaser.Math.Distance.Between(e.x, e.y, this.player.x, this.player.y);
            if (distP < slamRadius && !this.isInvincible && !this.state.dead) {
                const equipStats = ItemManager.getEquipmentStats(this.state.equipment);
                const slamDodge = (this._defDodge || 0) + (equipStats.dodgeChance || 0);
                if (slamDodge > 0 && Math.random() * 100 < slamDodge) {
                    this.player.setAlpha(0.3);
                    this.time.delayedCall(200, () => { if (!this.state.dead) this.player.setAlpha(1); });
                    Blurbs.show(this, this.player, 'DODGE', { color: '#66ccff', fontSize: 11, duration: 400 });
                } else {
                let dmg = slamDmg;
                // Temp armor
                if (this._tempArmor && this._tempArmor > 0) {
                    const absorbed = Math.min(this._tempArmor, dmg);
                    this._tempArmor -= absorbed;
                    dmg -= absorbed;
                }
                if (equipStats.armor > 0) dmg = Math.max(1, Math.round(dmg * (1 - equipStats.armor / 100)));
                if (equipStats.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - equipStats.damageResist / 100)));
                // Survivor mark damage resistance
                const _tsMods = this.state.survivorMods;
                if (_tsMods && _tsMods.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - _tsMods.damageResist)));
                // Threshold mark: dynamic resist
                const _tsConds = _tsMods?.conditionals;
                if (_tsConds && _tsConds.thresholdHigh) {
                    const _tsMaxHP = CONFIG.player.health + (equipStats.maxHealth || 0);
                    const _tsRatio = this.state.health / _tsMaxHP;
                    const _tsThreshR = _tsRatio < _tsConds.thresholdHigh ? _tsConds.thresholdResistBelow : _tsConds.thresholdResistAbove;
                    if (_tsThreshR) dmg = Math.max(1, Math.round(dmg * (1 - _tsThreshR)));
                }
                // Blood Pact
                if (this._bloodPactResist && this._bloodPactResist > 0) {
                    dmg = Math.max(1, Math.round(dmg * (1 - this._bloodPactResist / 100)));
                }
                // Hardened (Bane)
                if (this._hardenedActive && this._hardenedReduction) {
                    dmg = Math.max(1, Math.round(dmg * (1 - this._hardenedReduction)));
                }
                // Sheltered
                if (this._shelteredActive) {
                    dmg = Math.max(1, Math.round(dmg * 0.8));
                }
                this.state.health -= dmg;
                SignatureEffects.buildBloodPactStack(this);
                ConsumableSystem.interruptChannel();
                this.player.setTint(0xff0000);
                this.time.delayedCall(150, () => { if (!this.state.dead) _restoreTint(this.player); });
                this.isInvincible = true;
                this.time.delayedCall(500, () => this.isInvincible = false);
                // Knockback
                const ka = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
                this.player.setVelocity(Math.cos(ka) * 200, Math.sin(ka) * 200);
                if (this.state.health <= 0) {
                    this.playerDeath();
                }
                } // end dodge else
            }
            
            // Damage caravan if close enough
            const distC = Phaser.Math.Distance.Between(e.x, e.y, cx, cy);
            if (distC < slamRadius + 30) {
                this.modeState.caravanHp -= 8;
            }
            
            // Visual: shockwave ring + debris
            const ring = this.add.circle(e.x, e.y, 10, 0xff6622, 0.6).setDepth(20);
            this.tweens.add({
                targets: ring, scale: 8, alpha: 0, duration: 400,
                onComplete: () => ring.destroy()
            });
            for (let i = 0; i < 10; i++) {
                const da = Math.random() * Math.PI * 2;
                const dd = Phaser.Math.Between(5, 30);
                const deb = this.add.rectangle(
                    e.x + Math.cos(da) * dd, e.y + Math.sin(da) * dd,
                    Phaser.Math.Between(2, 5), Phaser.Math.Between(2, 4),
                    [0x665544, 0x554433, 0x4a4a3a][Math.floor(Math.random() * 3)]
                ).setDepth(20).setAngle(Phaser.Math.Between(0, 180));
                this.tweens.add({
                    targets: deb, x: deb.x + Math.cos(da) * 30, y: deb.y + Math.sin(da) * 30 - 10,
                    alpha: 0, duration: 500, onComplete: () => deb.destroy()
                });
            }
            
            // Screen shake
            this.cameras.main.shake(200, 0.008);
            
            warn.destroy();
            warnBorder.destroy();
            e.setTint(0xff6644); // restore tint
        });
    }
    
    showDefenseExtractChoice() {
        // Legacy — redirects to checkpoint panel for new system
        const wave = this.modeState.wavesCurrent;
        if ([3, 6, 9].includes(wave)) {
            this.showCheckpointPanel(wave);
        } else {
            // Non-checkpoint wave — just continue
            this.modeState.phase = 'intermission';
            this.time.delayedCall(4000, () => this.startDefenseWave());
        }
    }

    
    closeDefenseExtractChoice() {
        this.popupActive = false;
        if (this._defExtractUI) {
            this._defExtractUI.forEach(el => { if (el && el.destroy) el.destroy(); });
            this._defExtractUI = null;
        }
    }
    
    defenseExtractSuccess() {
        this.modeState.phase = 'complete';
        const wave = this.modeState.wavesCurrent;
        const ms = this.modeState;
        const isVictory = wave >= 12;
        
        // Reward scaling — steep curve for staying longer
        let baseBits, lootTable, dropCount;
        if (isVictory) {
            baseBits = 100;
            lootTable = 'boss_high';
            dropCount = 3;
        } else if (wave >= 9) {
            baseBits = 120;
            lootTable = 'boss';
            dropCount = 2;
        } else if (wave >= 6) {
            baseBits = 80;
            lootTable = 'boss';
            dropCount = 2;
        } else {
            baseBits = 40;
            lootTable = 'normal';
            dropCount = 1;
        }
        
        const caravanBonus = Math.floor(ms.caravanHp * 0.5);
        this.state.bits = (this.state.bits || 0) + baseBits + caravanBonus;
        ms.bitsEarned += baseBits + caravanBonus;
        
        // Drop loot near convoy
        const cx = ms.convoyX || CONFIG.world.width / 2;
        const cy = ms.convoyY || CONFIG.world.height / 2;
        for (let i = 0; i < dropCount; i++) {
            this.spawnItemDrop(
                cx + Phaser.Math.Between(-80, 80),
                cy + Phaser.Math.Between(40, 100),
                lootTable,
                this.destinationNode?.reach || 1
            );
        }
        
        // Announcement
        if (isVictory) {
            const foundryName = ms.foundry.name.toUpperCase();
            this.showModeAnnouncement('CONVOY OPERATIONAL', `${foundryName} SENDS THEIR THANKS\n+${baseBits + caravanBonus} bits`);
            this.showNPCSpeechBubble(DEFENSE_DATA.npcLines.victory[Math.floor(Math.random() * DEFENSE_DATA.npcLines.victory.length)], 5000);
            // Final repair stage
            ms.repairStage = 4;
            this.updateConvoyRepairVisuals();
        } else {
            this.showModeAnnouncement('EXTRACTION SUCCESSFUL', `+${baseBits + caravanBonus} bits — Loot the area!`);
        }
        
        // Convoy drives away
        if (this.caravanContainer) {
            // Speed depends on repair stage — limps if early extract
            const driveSpeed = isVictory ? 2000 : wave >= 6 ? 3500 : 5000;
            const driveDir = isVictory ? CONFIG.world.width + 100 : this.caravanContainer.x + CONFIG.world.width;
            this.tweens.add({
                targets: this.caravanContainer,
                x: driveDir, duration: driveSpeed, ease: isVictory ? 'Quad.in' : 'Sine.in',
                onComplete: () => { if (this.caravanContainer) this.caravanContainer.destroy(); }
            });
        }
        // Hide caravan HP UI
        if (this.caravanHpBg) this.caravanHpBg.destroy();
        if (this.caravanHpBar) this.caravanHpBar.destroy();
        if (this.caravanHpLabel) this.caravanHpLabel.destroy();
        if (this.caravanBody) this.caravanBody.destroy();
        // Hide shield
        if (this._shieldVisual) { this._shieldVisual.destroy(); this._shieldVisual = null; }
        if (this._shieldDevice) { this._shieldDevice.destroy(); this._shieldDevice = null; }
        // Dismount turret if mounted
        if (ms.turretMounted) this.dismountTurret();
        // Hide defense HUD
        if (this.defenseHudBg) this.defenseHudBg.destroy();
        // Soldiers walk off with convoy
        ms.soldiers.forEach(s => {
            if (s.sprite && s.sprite.active) {
                this.tweens.add({ targets: s.sprite, alpha: 0, x: s.x + 200, duration: 2500, onComplete: () => { if (s.sprite) s.sprite.destroy(); } });
            }
        });
        
        // Switch to free-roam (can loot and leave via vehicle)
        this.gameMode = 'freeRoam';
        if (this.defenseWaveText) this.defenseWaveText.setText('COMPLETE');
    }
    
    updateDefenseMode() {
        if (!this.modeState) return;
        if (this.modeState.phase === 'complete' || this.modeState.phase === 'failed' || this.modeState.phase === 'checkpoint') return;
        
        const ms = this.modeState;
        const cx = ms.convoyX || CONFIG.world.width / 2;
        const cy = ms.convoyY || CONFIG.world.height / 2;
        const dt = this.game.loop.delta / 1000; // delta seconds
        
        // === DISCOVERY PHASE — check NPC interaction proximity ===
        if (ms.phase === 'discovery') {
            if (this.player && this._questGiverSoldier && !this.popupActive) {
                const dist = Phaser.Math.Distance.Between(
                    this.player.x, this.player.y,
                    this._questGiverSoldier.x, this._questGiverSoldier.y
                );
                if (dist < 45) {
                    // Show InteractHighlight for touch — tap-to-interact handles the rest
                    InteractHighlight.show(this, this._questGiverSoldier, 'Talk');
                    // Also accept E key for keyboard/desktop
                    if (this.keys && this.keys.e && Phaser.Input.Keyboard.JustDown(this.keys.e)) {
                        InteractHighlight.hide(this);
                        ms.phase = 'dialogue';
                        this.showDialoguePanel();
                    }
                } else {
                    InteractHighlight.hide(this);
                }
            }
            // Update pre-combat soldier behaviors
            this.updateFoundrySoldiers(dt);
            return;
        }
        
        // === TURRET MOUNTING — touch + E key near convoy ===
        if (ms.turretInstalled && !this.popupActive && this.player) {
            const distToConvoy = Phaser.Math.Distance.Between(this.player.x, this.player.y, cx, cy);
            if (ms.turretMounted) {
                // Show dismount highlight on convoy
                InteractHighlight.show(this, { x: cx, y: cy }, 'Dismount');
                if (this.keys && this.keys.e && Phaser.Input.Keyboard.JustDown(this.keys.e)) {
                    InteractHighlight.hide(this);
                    this.dismountTurret();
                }
            } else if (distToConvoy < 55) {
                InteractHighlight.show(this, { x: cx, y: cy }, 'Mount Turret');
                if (this.keys && this.keys.e && Phaser.Input.Keyboard.JustDown(this.keys.e)) {
                    InteractHighlight.hide(this);
                    this.mountTurret();
                }
            } else {
                // Only hide if no other highlight active (discovery NPC might be showing)
                if (InteractHighlight.getTarget(this) && ms.phase !== 'discovery') {
                    InteractHighlight.hide(this);
                }
            }
            // Prevent player movement when mounted
            if (ms.turretMounted) {
                this.player.body.setVelocity(0, 0);
            }
        }
        
        // === Enemy caravan damage + miniboss tracking ===
        if (ms.phase === 'wave' || ms.phase === 'spawning') {
            // Assign caravan-targeting to some enemies
            this.enemies.getChildren().forEach((e, idx) => {
                if (!e.active) return;
                
                // Random caravan targeting assignment
                if (e._targetingCaravan === undefined) {
                    const wave = ms.wavesCurrent;
                    let tier;
                    if (wave <= 3) tier = 'light';
                    else if (wave <= 6) tier = 'medium';
                    else if (wave <= 9) tier = 'heavy';
                    else tier = 'intense';
                    e._targetingCaravan = Math.random() < (DEFENSE_DATA.waveComposition[tier]?.caravanTargetChance || 0.3);
                }
                
                // Caravan damage on contact (delta-time based)
                const distToCaravan = Phaser.Math.Distance.Between(e.x, e.y, cx, cy);
                if (distToCaravan < 45) {
                    const cfg = CONFIG.enemyTypes[e.enemyType];
                    const baseDmg = (cfg ? cfg.damage : 10) * (e._dmgMult || 1);
                    const dmgPerSec = baseDmg * 0.2;
                    ms.caravanHp -= dmgPerSec * dt;
                    if (e.isMiniboss) ms.caravanHp -= dmgPerSec * dt;
                    
                    // Flash caravan red (throttled)
                    if (!this._caravanFlashCD || this._caravanFlashCD <= 0) {
                        this._caravanFlashCD = 0.3;
                        if (this.caravanContainer) {
                            this.caravanContainer.list.forEach(c => { if (c.setTint) c.setTint(0xff4444); });
                            this.time.delayedCall(80, () => {
                                if (this.caravanContainer) this.caravanContainer.list.forEach(c => { if (c.clearTint) _restoreTint(c); });
                            });
                        }
                    }
                    
                    // Damage nearby soldiers too
                    ms.soldiers.forEach(sol => {
                        if (sol.downed) return;
                        const distToSol = Phaser.Math.Distance.Between(e.x, e.y, sol.x, sol.y);
                        if (distToSol < 20) {
                            this.damageSoldier(sol, baseDmg * 0.1 * dt);
                        }
                    });
                }
                
                // Update miniboss HP bar + label positions
                if (e.isMiniboss) {
                    if (e._minibossHP) {
                        e._minibossHP.setPosition(e.x, e.y - 28);
                        if (e._minibossHpLabel) e._minibossHpLabel.setPosition(e.x, e.y - 28);
                        e._minibossHP.updateHP(Math.max(0, e.hp), e.maxHp);
                    }
                    if (e.hp <= 0 || !e.active) {
                        if (e._slamTimer) { e._slamTimer.destroy(); e._slamTimer = null; }
                        if (e._minibossHP) { e._minibossHP.destroy(); e._minibossHP = null; }
                        if (e._minibossHpLabel) { e._minibossHpLabel.destroy(); e._minibossHpLabel = null; }
                    }
                }
            });
        }
        
        // Flash cooldown
        if (this._caravanFlashCD > 0) this._caravanFlashCD -= dt;
        
        // === Update Foundry soldiers (combat AI) ===
        this.updateFoundrySoldiers(dt);
        
        // === Update convoy shield ===
        this.updateConvoyShield(dt);
        
        // === Update turret ===
        this.updateTurret(dt);
        
        // === Caravan-targeting enemies: steer with wall avoidance ===
        this.enemies.getChildren().forEach(e => {
            if (!e.active || !e._targetingCaravan) return;
            const distToCaravan = Phaser.Math.Distance.Between(e.x, e.y, cx, cy);
            if (distToCaravan > 45) {
                let targetX = cx, targetY = cy;
                const cfg = CONFIG.enemyTypes[e.enemyType];
                const speed = cfg ? cfg.chaseSpeed * 0.75 : 50;
                
                // Stuck detection — track movement over 1s windows
                if (e._prevStuckX === undefined) { e._prevStuckX = e.x; e._prevStuckY = e.y; e._stuckAccum = 0; e._stuckCount = 0; }
                e._stuckAccum += dt;
                if (e._stuckAccum >= 1.0) {
                    const moved = Math.abs(e.x - e._prevStuckX) + Math.abs(e.y - e._prevStuckY);
                    if (moved < 6) {
                        e._stuckCount++;
                        // Progressive: first stuck → nudge perpendicular, second → bigger nudge, third → teleport
                        if (e._stuckCount >= 3) {
                            // Teleport to a clear position near convoy
                            const tAngle = Math.random() * Math.PI * 2;
                            const tDist = 60 + Math.random() * 40;
                            e.setPosition(cx + Math.cos(tAngle) * tDist, cy + Math.sin(tAngle) * tDist);
                            e.setAlpha(0.3);
                            this.tweens.add({ targets: e, alpha: 1, duration: 200 });
                            e._stuckCount = 0;
                        } else {
                            // Nudge perpendicular to caravan direction
                            const toCaravan = Phaser.Math.Angle.Between(e.x, e.y, cx, cy);
                            const nudgeDir = (Math.random() < 0.5) ? Math.PI/2 : -Math.PI/2;
                            const nudgeDist = 20 + e._stuckCount * 15;
                            e.x += Math.cos(toCaravan + nudgeDir) * nudgeDist;
                            e.y += Math.sin(toCaravan + nudgeDir) * nudgeDist;
                        }
                    } else {
                        e._stuckCount = 0;
                    }
                    e._prevStuckX = e.x; e._prevStuckY = e.y; e._stuckAccum = 0;
                }
                
                // Wall avoidance — redirect around walls proactively
                // Check TWO walls ahead: current position AND predicted next-frame position
                let wallHit = false;
                if (this.wallRects) {
                    const nextX = e.x + (targetX - e.x) * 0.1;
                    const nextY = e.y + (targetY - e.y) * 0.1;
                    for (const wr of this.wallRects) {
                        const wx = wr.x || 0, wy = wr.y || 0;
                        const ww = (wr.width || 20) + 18, wh = (wr.height || 12) + 18;
                        // Check current OR predicted position
                        const inNow = (e.x > wx - ww/2 && e.x < wx + ww/2 && e.y > wy - wh/2 && e.y < wy + wh/2);
                        const inNext = (nextX > wx - ww/2 && nextX < wx + ww/2 && nextY > wy - wh/2 && nextY < wy + wh/2);
                        if (inNow || inNext) {
                            const toCaravan = Phaser.Math.Angle.Between(e.x, e.y, cx, cy);
                            // Choose nudge direction based on which side of wall center enemy is on
                            const nudge = (e.y < wy) ? -Math.PI/2 : Math.PI/2;
                            targetX = e.x + Math.cos(toCaravan + nudge) * 55;
                            targetY = e.y + Math.sin(toCaravan + nudge) * 55;
                            wallHit = true;
                            break;
                        }
                    }
                }
                
                const angle = Phaser.Math.Angle.Between(e.x, e.y, targetX, targetY);
                // Move faster when avoiding walls to clear the obstacle
                const moveSpeed = wallHit ? speed * 1.3 : speed;
                e.setVelocity(Math.cos(angle) * moveSpeed, Math.sin(angle) * moveSpeed);
            }
            // Re-aggro to player if very close
            const distToPlayer = Phaser.Math.Distance.Between(e.x, e.y, this.player.x, this.player.y);
            if (distToPlayer < 45) e._targetingCaravan = false;
        });
        
        // === STRAGGLER LEASH — prevent enemies stuck at far edges ===
        if (ms.phase === 'wave') {
            const arenaRadius = Math.min(CONFIG.world.width, CONFIG.world.height) * 0.42;
            this.enemies.getChildren().forEach(e => {
                if (!e.active) return;
                const distToCenter = Phaser.Math.Distance.Between(e.x, e.y, cx, cy);
                const distToPlayer = Phaser.Math.Distance.Between(e.x, e.y, this.player.x, this.player.y);
                
                if (distToCenter > arenaRadius && distToPlayer > 200) {
                    const angle = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
                    const cfg = CONFIG.enemyTypes[e.enemyType];
                    const speed = cfg ? cfg.chaseSpeed : 60;
                    e.setVelocity(Math.cos(angle) * speed, Math.sin(angle) * speed);
                    e._targetingCaravan = false;
                    e.aiState = 'chase';
                    
                    if (!e._strandedTime) e._strandedTime = 0;
                    e._strandedTime += dt;
                    if (e._strandedTime > 8) {
                        const tAngle = Math.random() * Math.PI * 2;
                        const tDist = 100 + Math.random() * 60;
                        e.setPosition(
                            this.player.x + Math.cos(tAngle) * tDist,
                            this.player.y + Math.sin(tAngle) * tDist
                        );
                        e._strandedTime = 0;
                        e.setAlpha(0.3);
                        this.tweens.add({ targets: e, alpha: 1, duration: 300 });
                    }
                } else {
                    e._strandedTime = 0;
                }
            });
        }
        
        // === WALL-STUCK RECOVERY — all enemies in defense mode ===
        // Physics colliders prevent wall penetration, but enemies push against walls
        // in straight lines without pathfinding. Detect stuck enemies and steer around.
        if (ms.phase === 'wave' || ms.phase === 'spawning') {
            this.enemies.getChildren().forEach(e => {
                if (!e.active) return;
                // Init stuck tracking
                if (e._wallStuckX === undefined) {
                    e._wallStuckX = e.x; e._wallStuckY = e.y;
                    e._wallStuckTimer = 0; e._wallSteerAngle = 0;
                }
                
                const vx = e.body ? e.body.velocity.x : 0;
                const vy = e.body ? e.body.velocity.y : 0;
                const speed = Math.sqrt(vx * vx + vy * vy);
                const moved = Math.abs(e.x - e._wallStuckX) + Math.abs(e.y - e._wallStuckY);
                
                // Only check if enemy is trying to move but barely moving
                if (speed > 15 && moved < 3) {
                    e._wallStuckTimer += dt;
                    
                    if (e._wallStuckTimer > 0.35) {
                        // Stuck for 0.35s — steer perpendicular to current direction
                        // Pick a consistent direction (based on position hash) so they don't oscillate
                        if (e._wallSteerAngle === 0) {
                            const moveAngle = Math.atan2(vy, vx);
                            // Choose perpendicular direction that's closer to ultimate target
                            const targetX = e._targetingCaravan ? cx : this.player.x;
                            const targetY = e._targetingCaravan ? cy : this.player.y;
                            const perpA = moveAngle + Math.PI / 2;
                            const perpB = moveAngle - Math.PI / 2;
                            const testAx = e.x + Math.cos(perpA) * 30;
                            const testAy = e.y + Math.sin(perpA) * 30;
                            const testBx = e.x + Math.cos(perpB) * 30;
                            const testBy = e.y + Math.sin(perpB) * 30;
                            const distA = Phaser.Math.Distance.Between(testAx, testAy, targetX, targetY);
                            const distB = Phaser.Math.Distance.Between(testBx, testBy, targetX, targetY);
                            e._wallSteerAngle = distA < distB ? perpA : perpB;
                        }
                        // Apply perpendicular velocity to slide along the wall
                        const steerSpeed = speed * 0.8;
                        e.setVelocity(
                            Math.cos(e._wallSteerAngle) * steerSpeed,
                            Math.sin(e._wallSteerAngle) * steerSpeed
                        );
                    }
                    
                    if (e._wallStuckTimer > 1.2) {
                        // Stuck over 1.2s — hard teleport to a clear position near target
                        const targetX = e._targetingCaravan ? cx : this.player.x;
                        const targetY = e._targetingCaravan ? cy : this.player.y;
                        const tAngle = Phaser.Math.Angle.Between(e.x, e.y, targetX, targetY) + (Math.random() - 0.5) * Math.PI;
                        e.setPosition(e.x + Math.cos(tAngle) * 40, e.y + Math.sin(tAngle) * 40);
                        e._wallStuckTimer = 0;
                        e._wallSteerAngle = 0;
                    }
                } else {
                    // Moving normally — reset
                    e._wallStuckTimer = 0;
                    e._wallSteerAngle = 0;
                }
                
                e._wallStuckX = e.x;
                e._wallStuckY = e.y;
            });
        }
        
        // === Update caravan HP bar ===
        if (this.caravanHpBar) {
            const pct = Math.max(0, ms.caravanHp / ms.caravanMaxHp);
            this.caravanHpBar.setDisplaySize(78 * pct, 4);
            const color = pct > 0.6 ? 0x44cc44 : pct > 0.3 ? 0xccaa44 : 0xcc4444;
            this.caravanHpBar.setFillStyle(color);
        }
        
        // === Convoy low HP warning ===
        if (ms.caravanHp < ms.caravanMaxHp * 0.4 && !this._convoyLowWarned) {
            this._convoyLowWarned = true;
            this.showNPCSpeechBubble(DEFENSE_DATA.npcLines.convoyLow[Math.floor(Math.random() * DEFENSE_DATA.npcLines.convoyLow.length)], 3000);
            this.time.delayedCall(15000, () => { this._convoyLowWarned = false; }); // Reset after 15s
        }
        
        // === Update enemy count display ===
        if (this.defenseEnemyText) {
            const alive = this.enemies.getChildren().filter(e => e.active).length;
            if (ms.phase === 'wave' || ms.phase === 'spawning') {
                this.defenseEnemyText.setText(`${alive} remaining`);
                this.defenseEnemyText.setFill(alive > 10 ? '#cc6644' : alive > 5 ? '#ccaa44' : '#88cc66');
            } else if (ms.phase === 'intermission') {
                this.defenseEnemyText.setText('Regrouping...');
                this.defenseEnemyText.setFill('#88aa88');
            } else {
                this.defenseEnemyText.setText('');
            }
        }
        
        // === Caravan destroyed — mission failure ===
        if (ms.caravanHp <= 0) {
            ms.caravanHp = 0;
            ms.phase = 'failed';
            this.showModeAnnouncement('CONVOY LOST', 'The transport has been destroyed...');
            
            if (this.caravanContainer) {
                for (let burst = 0; burst < 3; burst++) {
                    this.time.delayedCall(burst * 150, () => {
                        for (let i = 0; i < 6; i++) {
                            const px = cx + Phaser.Math.Between(-35, 35);
                            const py = cy + Phaser.Math.Between(-18, 12);
                            const spark = this.add.circle(px, py, Phaser.Math.Between(2, 6),
                                [0xff6622, 0xff4411, 0xffaa33][Math.floor(Math.random() * 3)], 0.8
                            ).setDepth(30);
                            this.tweens.add({ targets: spark, alpha: 0, scale: 2.5, y: py - 25, duration: 700, onComplete: () => spark.destroy() });
                        }
                        const sm = this.add.circle(cx + Phaser.Math.Between(-15, 15), cy, Phaser.Math.Between(6, 12), 0x333333, 0.5).setDepth(29);
                        this.tweens.add({ targets: sm, alpha: 0, scale: 3, y: sm.y - 40, duration: 1200, onComplete: () => sm.destroy() });
                    });
                }
                this.cameras.main.shake(400, 0.012);
                this.tweens.add({ targets: this.caravanContainer, alpha: 0, scaleY: 0.3, duration: 600 });
            }
            
            // Dismount turret
            if (ms.turretMounted) this.dismountTurret();
            
            this.state.bits = (this.state.bits || 0) + Math.floor(ms.bitsEarned * 0.5);
            this.time.delayedCall(3000, () => {
                this.gameMode = 'freeRoam';
                if (this.defenseWaveText) this.defenseWaveText.setText('FAILED');
                if (this.defenseHudBg) this.defenseHudBg.destroy();
            });
            return;
        }
        
        // === Per-wave passive convoy heal ===
        if (ms.phase === 'wave' || ms.phase === 'spawning') {
            // Convoy slowly self-repairs: 0.5 HP/sec
            ms.caravanHp = Math.min(ms.caravanMaxHp, ms.caravanHp + 0.5 * dt);
        }
        
        // === Check wave completion ===
        if (ms.phase === 'wave') {
            const aliveEnemies = this.enemies.getChildren().filter(e => e.active).length;
            
            if (aliveEnemies === 0) {
                const wave = ms.wavesCurrent;
                ms.wavesCompleted = wave;
                
                // Per-wave reward
                const waveBits = 10 + wave * 3;
                this.state.bits = (this.state.bits || 0) + waveBits;
                ms.bitsEarned += waveBits;
                
                // NPC speech bubble
                const endLines = DEFENSE_DATA.npcLines.waveEnd;
                this.showNPCSpeechBubble(endLines[Math.floor(Math.random() * endLines.length)]);
                
                if (wave >= 12) {
                    // VICTORY
                    this.defenseExtractSuccess();
                } else if (wave === 3 || wave === 6 || wave === 9) {
                    // CHECKPOINT — show upgrade panel with extract option
                    const healAmt = 3 + wave;
                    ms.caravanHp = Math.min(ms.caravanMaxHp, ms.caravanHp + healAmt);
                    this.showCheckpointPanel(wave);
                } else {
                    // Regular intermission
                    ms.phase = 'intermission';
                    // Heal convoy between waves
                    ms.caravanHp = Math.min(ms.caravanMaxHp, ms.caravanHp + 3);
                    
                    const delay = wave >= 9 ? 4000 : 5000;
                    this.showModeAnnouncement('WAVE CLEARED', `+${waveBits} bits`, true);
                    this.time.delayedCall(delay, () => this.startDefenseWave());
                }
            }
        }
    }
    
    
    // === DEFENSE ROGUELIKE ABILITIES ===
    
    getAbilityPool() {
        // All available defense-mode abilities with tiers
        return [
            // Offensive
            { id: 'rapid_fire', name: 'Rapid Fire', desc: 'Attack speed +25%', icon: '⚡',
              color: 0xcc4444, apply: (s) => { s._defAttkSpeedMult = (s._defAttkSpeedMult || 1) * 0.75; }},
            { id: 'piercing', name: 'Piercing Rounds', desc: 'Attacks hit through 1 extra enemy', icon: '➤',
              color: 0xcc6644, apply: (s) => { s._defPierce = (s._defPierce || 0) + 1; }},
            { id: 'explosive', name: 'Explosive Kills', desc: 'Enemies explode on death (30 radius)', icon: '💥',
              color: 0xff6622, apply: (s) => { s._defExplosiveKills = true; s._defExplosionRadius = 30; }},
            { id: 'crit_chance', name: 'Sharpshooter', desc: 'Critical hit chance +15%', icon: '◎',
              color: 0xdd5555, apply: (s) => { s._defCritBonus = (s._defCritBonus || 0) + 15; }},
              
            // Defensive
            { id: 'armor_up', name: 'Reinforced Plating', desc: 'Convoy gains +20 max HP', icon: '🛡',
              color: 0x4488cc, apply: (s) => { 
                s.modeState.caravanMaxHp += 20; 
                s.modeState.caravanHp = Math.min(s.modeState.caravanMaxHp, s.modeState.caravanHp + 20);
              }},
            { id: 'regen', name: 'Field Medic', desc: 'Regenerate 1 HP every 3 seconds', icon: '+',
              color: 0x44cc44, apply: (s) => { 
                s._defRegenRate = (s._defRegenRate || 0) + 1;
                if (!s._defRegenTimer) {
                    s._defRegenTimer = s.time.addEvent({ delay: 3000, loop: true, callback: () => {
                        if (s.state.dead) return;
                        const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(s.state.equipment).maxHealth || 0);
                        s.state.health = Math.min(maxHp, s.state.health + (s._defRegenRate || 1));
                    }});
                }
              }},
            { id: 'thorns', name: 'Razor Wire', desc: 'Enemies near convoy take 5 dmg/sec', icon: '⚔',
              color: 0x6688aa, apply: (s) => { s._defThorns = (s._defThorns || 0) + 5; }},
            { id: 'dodge', name: 'Evasive Maneuvers', desc: '15% chance to dodge attacks', icon: '↺',
              color: 0x66aacc, apply: (s) => { s._defDodge = (s._defDodge || 0) + 15; }},
              
            // Utility
            { id: 'speed', name: 'Adrenaline Rush', desc: 'Movement speed +20%', icon: '»',
              color: 0xccaa44, apply: (s) => { s._defSpeedMult = (s._defSpeedMult || 1) * 1.2; }},
            { id: 'supply_freq', name: 'Supply Line', desc: 'Convoy drops supplies 40% faster', icon: '📦',
              color: 0xaaaa44, apply: (s) => { s._defSupplyMult = (s._defSupplyMult || 1) * 0.6; }},
            { id: 'slow_aura', name: 'Concussion Field', desc: 'Enemies near you are 20% slower', icon: '◉',
              color: 0x8866cc, apply: (s) => { s._defSlowAura = (s._defSlowAura || 0) + 20; }},
            { id: 'convoy_repair', name: 'Emergency Repair', desc: 'Instantly restore 25 convoy HP', icon: '🔧',
              color: 0x44ccaa, apply: (s) => { 
                s.modeState.caravanHp = Math.min(s.modeState.caravanMaxHp, s.modeState.caravanHp + 25);
              }}
        ];
    }
    
    showAbilityChoice(stageNum, subtitle) {
        this.popupActive = true;
        const pool = this.getAbilityPool();
        if (!this._chosenAbilities) this._chosenAbilities = [];
        const available = pool.filter(a => !this._chosenAbilities.includes(a.id));
        const shuffled = available.sort(() => Math.random() - 0.5);
        const choices = shuffled.slice(0, 3);
        if (choices.length === 0) {
            this.popupActive = false;
            if (this._abilityResumeCallback) { const cb = this._abilityResumeCallback; this._abilityResumeCallback = null; this.time.delayedCall(3000, cb); }
            return;
        }
        UIAtlas.build(this);
        const panel = UIManager.createPanel(this, CONFIG.width/2, CONFIG.height/2, 280, 190, {
            title: 'CHOOSE UPGRADE', accent: 'barter', closable: false, depth: 200, modal: true
        });
        panel.setScrollFactor(0);
        this._abilityUI = [panel];
        const cb = panel._contentBounds;
        const subText = subtitle || `Stage ${stageNum} bonus - pick one`;
        panel.add(this.add.text(0, cb.y + 4, subText, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#887766' }).setOrigin(0.5));
        const cardW = 80, cardH = 100;
        const startX = -(choices.length - 1) * (cardW + 8) / 2;
        const cardY = cb.y + 18 + cardH/2;
        choices.forEach((ability, i) => {
            const ax = startX + i * (cardW + 8);
            const card = this.add.rectangle(ax, cardY, cardW, cardH, 0x0c0c18, 0.9).setStrokeStyle(1, ability.color);
            card.setInteractive({ useHandCursor: true });
            panel.add(card);
            panel.add(this.add.text(ax, cardY - 32, ability.icon, { fontSize: uiPx(18), fill: '#ffffff' }).setOrigin(0.5));
            panel.add(this.add.text(ax, cardY - 10, ability.name, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#ffffff', fontStyle: 'bold', wordWrap: { width: cardW - 8 }, align: 'center' }).setOrigin(0.5));
            panel.add(this.add.text(ax, cardY + 18, ability.desc, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#aa9977', wordWrap: { width: cardW - 10 }, align: 'center' }).setOrigin(0.5));
            card.on('pointerover', () => card.setFillStyle(ability.color, 0.3));
            card.on('pointerout', () => card.setFillStyle(0x0c0c18, 0.9));
            card.on('pointerdown', () => this.selectAbility(ability));
        });
    }

    
    selectAbility(ability) {
        ability.apply(this);
        if (!this._chosenAbilities) this._chosenAbilities = [];
        this._chosenAbilities.push(ability.id);
        
        this.popupActive = false;
        if (this._abilityUI) {
            this._abilityUI.forEach(el => { if (el && el.destroy) el.destroy(); });
            this._abilityUI = null;
        }
        
        this.showModeAnnouncement(ability.name, ability.desc, true);
        
        // Call mode-specific resume callback
        if (this._abilityResumeCallback) {
            const cb = this._abilityResumeCallback;
            this._abilityResumeCallback = null;
            this.time.delayedCall(3000, cb);
        }
    }
    
    
    // === HORDE MODE (DEPRECATED) ===
    // startHordeWave removed - deprecated
    
    // updateHordeMode removed - deprecated
    
    updateOcclusion() {
        if (!this.occludables || !this.player) return;
        const px = this.player.x;
        const py = this.player.y;
        const pw = 12, ph = 12; // player half-size
        
        for (const occ of this.occludables) {
            const ox = occ.x, oy = occ.y;
            const hw = occ.w / 2, hh = occ.h / 2;
            
            // Check if player overlaps with this occludable's bounding box
            const overlaps = px + pw > ox - hw && px - pw < ox + hw &&
                             py + ph > oy - hh && py - ph < oy + hh;
            
            const targetAlpha = overlaps ? 0.35 : occ.baseAlpha;
            
            for (const part of occ.parts) {
                if (!part || !part.active) continue;
                // Smooth transition
                const current = part.alpha;
                const diff = targetAlpha - current;
                if (Math.abs(diff) > 0.02) {
                    part.setAlpha(current + diff * 0.15);
                } else {
                    part.setAlpha(targetAlpha);
                }
            }
        }
    }
    
    enterBuilding(door) {
        this._transitioning = true;
        // Check if door is locked
        if (door.isLocked) {
            // Look for lockpick in backpack
            const lockpickIdx = this.state.backpack.findIndex(i => i && i.id === 'lockpick');
            if (lockpickIdx === -1) {
                // No lockpick — show locked message
                const txt = this.add.text(this.player.x, this.player.y - 30, 'LOCKED - Need Lockpick', {
                    fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#ff6644', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(100);
                this.tweens.add({ targets: txt, y: this.player.y - 55, alpha: 0, duration: 1200, onComplete: () => txt.destroy() });
                return;
            }
            // Consume lockpick
            this.state.backpack[lockpickIdx] = null;
            door.isLocked = false;
            door.wasLocked = true; // Flag for interior to use locked loot tables
            const txt = this.add.text(this.player.x, this.player.y - 30, 'UNLOCKED', {
                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#44cc44', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(100);
            this.tweens.add({ targets: txt, y: this.player.y - 55, alpha: 0, duration: 800, onComplete: () => txt.destroy() });
            // Remove lock visual if present
            if (door._lockIcon) { door._lockIcon.destroy(); door._lockIcon = null; }
        }
        
        // Check if this building has the breakdown toolkit
        const hasToolkit = false /* breakdown deprecated */ && this.modeState && 
            this.modeState.toolkitBuildingId && door.buildingId === this.modeState.toolkitBuildingId &&
            !this.modeState.objectiveFound;
        
        // Track building explored
        if (this._runStats) this._runStats.buildingsExplored++;
        
        // Persist magazine state through transition
        if (this._magazine !== undefined) this.state._magazine = this._magazine;
        
        AudioManager.doorOpen();
        Haptics.light();
        SceneTransition.fadeTo(this, 'InteriorScene', { 
            archetype: door.archetype,
            subtype: door.subtype,
            buildingType: door.buildingType || null,
            buildingName: door.buildingName,
            buildingWidth: door.buildingWidth || 140,
            buildingHeight: door.buildingHeight || 100,
            interiorScale: door.interiorScale || null,
            buildingId: door.buildingId || null,
            doorSide: door.doorSide || 'south',
            isGarage: door.isGarage || false,
            wasLocked: door.wasLocked || false,
            playerState: this.state,
            savedPlayerPos: { x: this.player.x, y: this.player.y },
            savedRouteSeed: this.currentRouteSeed,
            fromMap: this.fromMap,
            destinationNode: this.destinationNode,
            currentNodeId: this.currentNodeId,
            previousNodeId: this.previousNodeId,
            completedNodes: this.completedNodes,
            traveledRoutes: this.traveledRoutes,
            mapSeed: this.mapSeed,
            currentRow: this.currentRow,
            breakdownToolkit: hasToolkit,
            locationType: this.locationType,
            lootMultiplier: this.lootMultiplier,
            rescueMode: this.rescueMode || false
        }, { duration: 300 });
    }

    update(time, delta) {
        if (!this.player || !this.state) return;
        if (this._arrivalActive) return; // Block during vehicle arrival
        if (this._transitioning) return; // Block during scene fade-out
        
        // Update overhead zones (canopies, awnings)
        if (this.player) OverheadZone.update(this, this.player.x, this.player.y);
        
        // Cache equipment stats once per frame — used by combat, movement, signatures
        this._eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        
        const paused = this.state.dead || this.lootMenuOpen || this.inventoryUI || this.popupActive || this._noteOverlayActive;
        if (paused) {
            this._wasPaused = true;
            if (this.state.dead || this.lootMenuOpen) return;
            if (this.inventoryUI) {
                if (Phaser.Input.Keyboard.JustDown(this.keys.i)) {
                    this.inventoryUI.close();
                }
                return;
            }
            return;
        }
        if (this._wasPaused) {
            this._wasPaused = false;
            if (this.player) { this.player.anims.stop(); this.player.isMoving = false; }
            this.moveDir = { x: 0, y: 0 };
            this.movePointer = null;
        }
        
        // Update consumable system (channels, AOE zones)
        ConsumableSystem.update(this, delta, this.player);
        
        // DOT system — tick player DOTs and render debuff HUD
        DOTSystem.updatePlayer(this, delta);
        DOTSystem.renderDebuffHUD(this);
        
        // Dodge Time — bullet-time slowdown system
        // Cube Metabolized: passive HP regen (mark conditional)
        const _cubeRegen = this.state.survivorMods?.conditionals;
        if (_cubeRegen && _cubeRegen.cubeRegenRate > 0) {
            this._cubeRegenTimer = (this._cubeRegenTimer || 0) + delta;
            if (this._cubeRegenTimer >= _cubeRegen.cubeRegenRate) {
                this._cubeRegenTimer -= _cubeRegen.cubeRegenRate;
                const _crMaxHP = CONFIG.player.health + (this._eqStats.maxHealth || 0);
                if (this.state.health < _crMaxHP && this.state.health > 0) {
                    const _crHeal = _cubeRegen.cubeRegenAmount || 1;
                    this.state.health = Math.min(_crMaxHP, this.state.health + _crHeal);
                }
            }
        }

        // Movement
        let vx = this.moveDir.x, vy = this.moveDir.y;
        if (this.keys.a.isDown) vx -= 1;
        if (this.keys.d.isDown) vx += 1;
        if (this.keys.w.isDown) vy -= 1;
        if (this.keys.s.isDown) vy += 1;
        const len = Math.sqrt(vx*vx + vy*vy);
        if (len > 1) { vx /= len; vy /= len; }
        // Cube Anomaly control inversion
        const inv = this._invertMult || 1;
        vx *= inv; vy *= inv;
        if (!this.isDodging) {
            const speedMult = (this._eqStats.moveSpeed / 100) * (1 + (this._speedBoost || 0)) * (this._defSpeedMult || 1) * (this._channelSpeedMult || 1) * (this.state.survivorMods?.speedMultiplier || 1);
            this.player.setVelocity(vx * CONFIG.player.speed * speedMult, vy * CONFIG.player.speed * speedMult);
        }
        
        // Snap player position to integer pixels every frame to eliminate sub-pixel jitter
        this.player.x = Math.round(this.player.x);
        this.player.y = Math.round(this.player.y);
        
        // Update player animation based on movement
        SpriteManager.updatePlayerAnimation(this.player, vx, vy, this);
        
        // Reload text follows player
        if (this._reloadText && this.player) {
            this._reloadText.x = this.player.x;
            this._reloadText.y = this.player.y - 30;
        }
        
        // Update player depth based on Y position (Y-sorting)
        this.player.setDepth(10 + this.player.y * 0.01);
        
        // Occlusion transparency — show player through canopies/objects they walk behind
        this.updateOcclusion();

        // Keyboard controls
        if (Phaser.Input.Keyboard.JustDown(this.keys.e)) {
            this.handleInteract();
        }
        if (Phaser.Input.Keyboard.JustDown(this.keys.i)) {
            this.openInventory();
        }

        // Track distance traveled
        if (this._lastPlayerPos && this.player) {
            const dx = this.player.x - this._lastPlayerPos.x;
            const dy = this.player.y - this._lastPlayerPos.y;
            const dist = Math.sqrt(dx*dx + dy*dy);
            if (dist > 0.5 && dist < 50) this._runStats.distanceTraveled += dist;
        }
        if (this.player) this._lastPlayerPos = { x: this.player.x, y: this.player.y };

        // Find target
        this.findTarget();

        // Aim
        this.updateAim();
        
        // Weapon flair effects
        this.updateWeaponFlair();

        // Combat — auto-switch: melee when close, shoot when at range
        this.autoMelee();
        this.autoShoot();
        
        // === DOT + SIGNATURE UPDATE TICK ===
        DOTManager.update(this, delta, (e) => this.killEnemy(e));
        DOTManager.renderEnemyDebuffs(this);
        DOTSystem.updatePlayer(this, delta);
        DOTSystem.renderDebuffHUD(this);
        
        // Dodge Time — bullet-time slowdown system
        // Parasitic Rounds: auto-load every 10s (Bane: Swarm Queen)
        if (this._eqStats.signatures) {
            const parasitic = this._eqStats.signatures.find(s => s.effect === 'parasiticRounds');
            if (parasitic) SignatureEffects.updateParasiticRounds(this, this.state, parasitic);
        }
        
        // Player buff/debuff status icons — disabled, HUD dropdown shows buffs
        // PlayerStatusIcons.update(this);
        
        // Gym buff timer (runs outside safehouse, syncs every 5s)
        if (!this._gymBuffChecked) {
            try { const sd = SaveManager.load(); this._gymBuffLocal = sd && sd.gymBuff && sd.gymBuff.remainingMs > 0 ? sd.gymBuff : null; } catch(e) {}
            this._gymBuffChecked = true; this._gymSyncTimer = 0;
        }
        if (this._gymBuffLocal) {
            this._gymBuffLocal.remainingMs -= delta;
            this._gymSyncTimer = (this._gymSyncTimer || 0) + delta;
            if (this._gymBuffLocal.remainingMs <= 0) {
                this._gymBuffLocal = null;
                try { const sd = SaveManager.load(); if (sd) { sd.gymBuff = null; SaveManager.save(sd); } } catch(e) {}
            } else if (this._gymSyncTimer > 5000) {
                this._gymSyncTimer = 0;
                try { const sd = SaveManager.load(); if (sd) { sd.gymBuff = this._gymBuffLocal; SaveManager.save(sd); } } catch(e) {}
            }
        }
        
        // Enemies
        this.updateEnemies(delta);
        
        // Mode-specific updates
        if (this.gameMode === 'defense') {
            this.updateDefenseMode();
            // Wave 15 boss — run boss encounter AI alongside defense
            if (this.modeState && this.modeState.hasBoss && this.modeState.bossEntity) {
                BossAI.updateBossEncounter(this, delta / 1000);
            }
        }
        else if (this.gameMode === 'boss') BossAI.updateBossEncounter(this, delta / 1000);
        
        // Rescue encounter check (overlays any mode)
        if (this.rescueMode && !this._rescueComplete && !this._rescuePanelOpen) this._updateRescue();
        
        // Check interactions
        this.checkInteractions();
        
        // Check loot pickups (currency - auto)
        this.checkLootPickup();
        
        // Check item drops (tangible - manual pickup)
        this.checkItemPickup();
        
        // Process passive relic abilities
        this.processPassiveRelics(time, delta);

        // Update dynamic shadows
        DynamicShadows.update(this);

        // UI
        this.updateUI();
    }
    
    checkInteractions() {
        // Check door proximity
        this.nearestDoor = null;
        this.buildingDoors.forEach(door => {
            const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, door.x, door.y);
            if (d < 45) this.nearestDoor = door;
        });
        
        // Check siphon vehicle proximity
        this.nearestSiphon = null;
        if (this.siphonVehicles) {
            for (const zone of this.siphonVehicles) {
                if (!zone._siphon || zone._siphon.siphoned) continue;
                const sd = Phaser.Math.Distance.Between(this.player.x, this.player.y, zone.x, zone.y);
                if (sd < 40) { this.nearestSiphon = zone; break; }
            }
        }
        
        // Check vehicle proximity (only in free-roam modes)
        this.nearVehicle = false;
        const freeRoamMode = this.gameMode === 'freeRoam' || !this.gameMode;
        if (this.parkedVehicle && freeRoamMode) {
            const vd = Phaser.Math.Distance.Between(this.player.x, this.player.y, this.parkedVehicle.x, this.parkedVehicle.y);
            if (vd < 55) this.nearVehicle = true;
        }
        
        // Check searchable prop proximity
        this.nearestSearchable = null;
        if (this.searchableProps) {
            for (const sp of this.searchableProps) {
                if (sp.searched) continue;
                const sd = Phaser.Math.Distance.Between(this.player.x, this.player.y, sp.x, sp.y);
                if (sd < 40) { this.nearestSearchable = sp; break; }
            }
        }
        
        // Check world note proximity
        this.nearestNote = null;
        if (this.worldNoteProps) {
            for (const np of this.worldNoteProps) {
                if (np.noteRead) continue;
                const nd = Phaser.Math.Distance.Between(this.player.x, this.player.y, np.x, np.y);
                if (nd < 35) { this.nearestNote = np; break; }
            }
        }
        
        // Highlight nearest interactable — doors > siphon > vehicle > searchable > note > items
        if (this.nearestDoor) {
            InteractHighlight.show(this, this.nearestDoor, this.nearestDoor.isLocked ? 'LOCKED' : 'ENTER', { padding: 5 });
        } else if (this.nearestSiphon) {
            InteractHighlight.show(this, this.nearestSiphon, 'SIPHON', { padding: 5 });
        } else if (this.nearVehicle) {
            const vTarget = this.parkedVehicleSprite || this.parkedVehicle;
            InteractHighlight.show(this, vTarget, 'VEHICLE', { padding: 6 });
        } else if (this.nearestSearchable) {
            InteractHighlight.show(this, this.nearestSearchable, 'SEARCH', { padding: 5 });
        } else if (this.nearestNote) {
            InteractHighlight.show(this, this.nearestNote, 'READ', { padding: 4 });
        } else {
            // Don't hide if defense discovery phase is managing its own highlight
            if (!(this.gameMode === 'defense' && this.modeState && this.modeState.phase === 'discovery' && InteractHighlight.getTarget(this))) {
                InteractHighlight.hide(this);
            }
        }
    }
    
    handleInteract() {
        if (this._noteOverlayActive) return; // Block interaction while reading a note
        
        // === DEFENSE MODE INTERACTIONS ===
        if (this.gameMode === 'defense' && this.modeState) {
            // Discovery phase — talk to quest-giver NPC
            if (this.modeState.phase === 'discovery' && this._questGiverSoldier && !this.popupActive) {
                const dist = Phaser.Math.Distance.Between(
                    this.player.x, this.player.y,
                    this._questGiverSoldier.x, this._questGiverSoldier.y
                );
                if (dist < 50) {
                    InteractHighlight.hide(this);
                    if (this._npcInteractHint) { this._npcInteractHint.destroy(); this._npcInteractHint = null; }
                    this.showDialoguePanel();
                    return;
                }
            }
            // Turret mount/dismount
            if (this.modeState.turretInstalled) {
                if (this.modeState.turretMounted) {
                    InteractHighlight.hide(this);
                    this.dismountTurret();
                    return;
                } else {
                    const dist = Phaser.Math.Distance.Between(
                        this.player.x, this.player.y,
                        this.modeState.convoyX, this.modeState.convoyY
                    );
                    if (dist < 60) {
                        InteractHighlight.hide(this);
                        this.mountTurret();
                        return;
                    }
                }
            }
        }
        
        if (this.nearestDoor) {
            this.enterBuilding(this.nearestDoor);
        } else if (this.nearestSiphon) {
            this.siphonFuel(this.nearestSiphon);
        } else if (this.nearVehicle) {
            this.showVehicleMenu();
        } else if (this.nearestSearchable) {
            this.searchProp(this.nearestSearchable);
        } else if (this.nearestNote) {
            this.readNote(this.nearestNote);
        } else if (this.nearestItemDrop) {
            this.pickupItemDrop();
        }
    }
    
    searchProp(prop) {
        if (prop.searched) return;
        prop.searched = true;
        AudioManager.lootCrate();
        Haptics.light();
        
        const px = prop.x, py = prop.y;
        
        // Searching visual
        const searchText = this.add.text(px, py - 20, 'Searching...', {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa9966'
        }).setOrigin(0.5).setDepth(100);
        
        this.time.delayedCall(600, () => {
            searchText.destroy();
            
            const reach = this.destinationNode?.reach || 1;
            const reachMult = CONFIG.reachCurrencyMult[Math.min(reach, 8)] || 1.0;
            const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
            const luckBonus = eqStats.lootLuck || 0;
            
            // Hidden chest — special loot table, guaranteed good drops
            if (prop.isHiddenChest) {
                this.showModeAnnouncement('HIDDEN CACHE!', 'Rare loot found!', true);
                // Chest opening VFX
                if (prop.chestContainer) {
                    this.tweens.add({ targets: prop.chestContainer, scaleY: 0.5, alpha: 0.3, duration: 300 });
                }
                if (prop.chestGlow) {
                    this.tweens.add({ targets: prop.chestGlow, alpha: 0.5, scaleX: 3, scaleY: 3, duration: 500, onComplete: () => {
                        this.tweens.add({ targets: prop.chestGlow, alpha: 0, duration: 400, onComplete: () => prop.chestGlow.destroy() });
                    }});
                }
                // Drop 2-3 items from chest_hidden table
                const chestDrops = Phaser.Math.Between(2, 3);
                for (let cd = 0; cd < chestDrops; cd++) {
                    this.time.delayedCall(cd * 250, () => {
                        const ox = Phaser.Math.Between(-20, 20);
                        const oy = Phaser.Math.Between(-15, 15);
                        this.spawnItemDrop(px + ox, py + oy, 'chest_hidden', reach);
                    });
                }
                // Bonus currency burst
                for (let cc = 0; cc < 4; cc++) {
                    this.time.delayedCall(cc * 80, () => {
                        this.spawnLootDrop(px + Phaser.Math.Between(-25, 25), py + Phaser.Math.Between(-20, 20), reachMult * 1.5);
                    });
                }
                prop.setAlpha(0);
                return;
            }
            
            // Roll from location-aware loot table for real items
            const locType = this.locationType;
            const locConfig = locType ? CONFIG.locations[locType] : null;
            const propTable = locConfig?.lootTable || 'prop_search';
            const biomeLootMult = this.biome?.lootQuantityMult || 1.0;
            const rollCount = Math.min(4, Math.max(1, Math.round(Phaser.Math.Between(1, 2) * (this.lootMultiplier || 1.0) * biomeLootMult)));
            let foundSomething = false;
            const gainTexts = [];
            
            for (let i = 0; i < rollCount; i++) {
                const result = ItemManager.rollLootTable(propTable, luckBonus, reach, null, locConfig?.lootModifiers);
                if (!result) continue;
                
                let item;
                if (typeof result === 'string') {
                    item = ItemManager.createItem(result);
                } else {
                    item = result;
                }
                if (!item) continue;
                foundSomething = true;
                
                // Scrap items: add directly as currency-equivalent (or to backpack if room)
                if (item.category === 'scrap') {
                    // Try to add to backpack for safehouse scrapping
                    if (!ItemManager.addItem(this.state.backpack, item)) {
                        // Backpack full — convert to bits on the spot
                        const bits = Math.round((item.scrapValue || 1) * reachMult);
                        this.state.bits += bits;
                        gainTexts.push(`+${bits} bits`);
                    } else {
                        gainTexts.push(`+${item.name}`);
                    }
                } else if (item.category === 'consumable') {
                    // Try to add consumable to backpack
                    if (!ItemManager.addItem(this.state.backpack, item)) {
                        // Full — apply immediately if healing
                        if (item.healPercent > 0 || item.healAmount > 0) {
                            const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
                            const eqMaxHp = CONFIG.player.health + (eqStats.maxHealth || 0);
                            const bonus = eqStats.healBonus || 0;
                            const baseHeal = item.healPercent ? Math.round(eqMaxHp * item.healPercent / 100) : item.healAmount;
                            const heal = Math.min(Math.round(baseHeal * (1 + bonus / 100)), eqMaxHp - this.state.health);
                            if (heal > 0) { this.state.health += heal; gainTexts.push(`+${heal} HP`); }
                            else gainTexts.push('Full');
                        } else {
                            gainTexts.push('Full');
                        }
                    } else {
                        gainTexts.push(`+${item.name}`);
                    }
                } else {
                    // Procedural item — spawn as world drop
                    this.time.delayedCall(i * 200, () => {
                        const ox = Phaser.Math.Between(-15, 15);
                        const oy = Phaser.Math.Between(-10, 10);
                        const drop = this.add.container(px + ox, py + oy - 10).setDepth(16);
                        const color = ItemManager.getItemColor(item);
                        const glow = ItemManager.getItemGlow(item);
                        // Actual pixel sprite
                        const spriteC = this.add.container(0, 0);
                        ItemManager.drawItemPixelArt(this, spriteC, 0, -2, item, 1.0, 0);
                        drop.add(spriteC);
                        // Rarity glow ellipse
                        const glowE = this.add.ellipse(0, 0, 24, 20, glow, 0.15);
                        drop.add(glowE);
                        drop.sendToBack(glowE);
                        drop.itemData = item;
                        drop.rarityColor = color;
                        drop.rarityGlow = glow;
                        drop.setScale(0);
                        this.tweens.add({ targets: drop, scale: 1, duration: 300, ease: 'Back.out' });
                        this.tweens.add({ targets: drop, y: drop.y - 6, duration: 900, yoyo: true, repeat: -1, ease: 'Sine.inOut', delay: 300 });
                        this.tweens.add({ targets: glowE, alpha: 0.35, scaleX: 1.4, scaleY: 1.4, duration: 700, yoyo: true, repeat: -1 });
                        
                        // === ANIMATED FLAIR on ground drops ===
                        if (item.flair) {
                            const fc = item.flair.color;
                            const fid = item.flair.id;
                            
                            if (fid === 'electric') {
                                // Electric arcs pulse around the drop
                                const arc = this.add.rectangle(0, 0, 2, 10, fc, 0.8).setDepth(1);
                                drop.add(arc);
                                this.tweens.add({ targets: arc, angle: 360, duration: 600, repeat: -1, ease: 'Linear' });
                                this.tweens.add({ targets: arc, alpha: 0.3, duration: 100, yoyo: true, repeat: -1 });
                                const arc2 = this.add.rectangle(0, 0, 10, 2, fc, 0.6).setDepth(1);
                                drop.add(arc2);
                                this.tweens.add({ targets: arc2, angle: -360, duration: 800, repeat: -1, ease: 'Linear' });
                                this.tweens.add({ targets: arc2, alpha: 0.2, duration: 120, yoyo: true, repeat: -1, delay: 50 });
                            } else if (fid === 'ember') {
                                // Rising ember particles
                                for (let ei = 0; ei < 3; ei++) {
                                    const ember = this.add.rectangle((Math.random()-0.5)*12, 8, 2, 2, fc, 0.7).setDepth(1);
                                    drop.add(ember);
                                    this.tweens.add({ targets: ember, y: -14, alpha: 0, duration: 800 + ei * 200, repeat: -1, delay: ei * 250 });
                                }
                            } else if (fid === 'void') {
                                // Dark pulse expanding ring
                                const ring = this.add.circle(0, 0, 6, fc, 0).setStrokeStyle(1, fc, 0.6).setDepth(0);
                                drop.add(ring);
                                this.tweens.add({ targets: ring, scaleX: 2.5, scaleY: 2.5, alpha: 0, duration: 1200, repeat: -1 });
                            } else if (fid === 'frost') {
                                // Shimmer sparkles
                                for (let fi = 0; fi < 4; fi++) {
                                    const spark = this.add.rectangle((Math.random()-0.5)*16, (Math.random()-0.5)*16, 1, 1, fc, 0).setDepth(1);
                                    drop.add(spark);
                                    this.tweens.add({ targets: spark, alpha: 0.9, duration: 300, yoyo: true, repeat: -1, delay: fi * 200 });
                                }
                            } else if (fid === 'gilded') {
                                // Golden pulse glow
                                const goldGlow = this.add.rectangle(0, 0, 22, 22, fc, 0).setAngle(45).setDepth(0);
                                drop.add(goldGlow);
                                this.tweens.add({ targets: goldGlow, alpha: 0.35, duration: 600, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
                            } else if (fid === 'spectral') {
                                // Ghostly afterimage that orbits
                                const ghost = this.add.rectangle(8, 0, 6, 6, fc, 0.3).setAngle(45).setDepth(0);
                                drop.add(ghost);
                                this.tweens.add({ targets: ghost, angle: 360, duration: 2000, repeat: -1, ease: 'Linear' });
                                this.tweens.add({ targets: ghost, alpha: 0.1, duration: 500, yoyo: true, repeat: -1 });
                            }
                        }
                        
                        this.itemDrops.push(drop);
                        this.time.delayedCall(45000, () => { if (drop.active) { this.tweens.add({ targets: drop, alpha: 0, scale: 0, duration: 400, onComplete: () => { const idx = this.itemDrops.indexOf(drop); if (idx > -1) this.itemDrops.splice(idx, 1); drop.destroy(); } }); } });
                    });
                    gainTexts.push(`${item.name}!`);
                }
            }
            
            // Also award small currency from the search (bits/ammo)
            const currBits = Math.round(Phaser.Math.Between(1, 3) * reachMult);
            this.state.bits += currBits;
            gainTexts.push(`+${currBits} bits`);
            
            if (foundSomething || currBits > 0) {
                const gainText = this.add.text(px, py - 25, gainTexts.join('  '), {
                    fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#ddcc88', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(100);
                this.tweens.add({
                    targets: gainText, y: gainText.y - 30, alpha: 0,
                    duration: 1500, onComplete: () => gainText.destroy()
                });
            } else {
                const emptyText = this.add.text(px, py - 20, 'Nothing useful', {
                    fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#665544'
                }).setOrigin(0.5).setDepth(100);
                this.tweens.add({
                    targets: emptyText, alpha: 0, y: emptyText.y - 15,
                    duration: 1200, onComplete: () => emptyText.destroy()
                });
            }
            
            // Dim the prop hitbox
            prop.setAlpha(0);
        });
    }
    
    // === HIDDEN CHEST — rare discoverable loot cache ===
    spawnHiddenChest(route) {
        const w = CONFIG.world.width, h = CONFIG.world.height;
        // Place in a semi-concealed spot — corner or edge area
        const spots = [
            { x: Phaser.Math.Between(30, 80), y: Phaser.Math.Between(30, 80) },
            { x: Phaser.Math.Between(w - 80, w - 30), y: Phaser.Math.Between(30, 80) },
            { x: Phaser.Math.Between(30, 80), y: Phaser.Math.Between(h - 80, h - 30) },
            { x: Phaser.Math.Between(w - 80, w - 30), y: Phaser.Math.Between(h - 80, h - 30) },
            { x: Phaser.Math.Between(w/2 - 60, w/2 + 60), y: Phaser.Math.Between(30, 60) },
            { x: Phaser.Math.Between(w/2 - 60, w/2 + 60), y: Phaser.Math.Between(h - 60, h - 30) }
        ];
        const spot = spots[Math.floor(Math.random() * spots.length)];
        const cx = spot.x, cy = spot.y;
        const d = 14 + cy * 0.01;
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        
        // Isometric chest — ¾ view crate with lock
        const chestContainer = this.add.container(cx, cy).setDepth(d);
        // Chest body — front face (wide, visible)
        chestContainer.add(this.add.rectangle(0, 0, 18, 12, tc(0x5a4a2a)).setOrigin(0.5)); // front
        chestContainer.add(this.add.rectangle(0, -7, 18, 3, tc(0x7a6a3a)).setOrigin(0.5)); // top
        chestContainer.add(this.add.rectangle(9, -1, 3, 12, tc(0x4a3a1a)).setOrigin(0.5)); // side
        // Metal bands
        chestContainer.add(this.add.rectangle(0, -2, 16, 1, tc(0x888866), 0.6).setOrigin(0.5));
        chestContainer.add(this.add.rectangle(0, 3, 16, 1, tc(0x888866), 0.6).setOrigin(0.5));
        // Lock/clasp
        chestContainer.add(this.add.rectangle(0, 0, 4, 4, tc(0xccaa44), 0.8).setOrigin(0.5));
        // Subtle glow — not obvious, rewards exploration
        const chestGlow = this.add.ellipse(cx, cy + 8, 22, 10, 0xffaa22, 0.06).setDepth(d - 0.01);
        this.tweens.add({ targets: chestGlow, alpha: 0.12, scaleX: 1.2, scaleY: 1.2, duration: 1500, yoyo: true, repeat: -1 });
        // Tiny sparkle particles — very subtle
        this.time.addEvent({
            delay: 2000, loop: true, callback: () => {
                if (!chestContainer.active) return;
                const sx = cx + Phaser.Math.Between(-8, 8);
                const sy = cy + Phaser.Math.Between(-6, 4);
                const spark = this.add.rectangle(sx, sy, 2, 2, 0xffcc44, 0.5).setDepth(d + 0.01).setAngle(45);
                this.tweens.add({ targets: spark, alpha: 0, y: sy - 12, scale: 0.3, duration: 800, onComplete: () => spark.destroy() });
            }
        });
        
        // Hitbox for interaction
        const hitbox = this.add.rectangle(cx, cy, 24, 18, 0x000000, 0).setDepth(d + 0.02);
        hitbox.isHiddenChest = true;
        hitbox.chestContainer = chestContainer;
        hitbox.chestGlow = chestGlow;
        hitbox.searched = false;
        hitbox.propIcon = 'LOOT';
        if (!this.searchableProps) this.searchableProps = [];
        this.searchableProps.push(hitbox);
        if (!this.hiddenChests) this.hiddenChests = [];
        this.hiddenChests.push(hitbox);
    }
    
    spawnWorldNotes(route) {
        const biomeType = CONFIG.currentBiome?.type || 'grassy';
        const notePool = CONFIG.worldNotes[biomeType];
        if (!notePool || notePool.length === 0) return;
        
        // Filter out already-found notes this run
        const found = this.state.foundNotes || [];
        const available = notePool.filter(n => !found.includes(n.id));
        if (available.length === 0) return;
        
        // Roll for 0-2 notes per zone (30% for 1, 10% for 2)
        const roll = Math.random();
        let noteCount = 0;
        if (roll < 0.10) noteCount = 2;
        else if (roll < 0.40) noteCount = 1;
        if (noteCount === 0) return;
        
        const w = CONFIG.world.width, h = CONFIG.world.height;
        const shuffled = [...available].sort(() => Math.random() - 0.5);
        
        for (let i = 0; i < Math.min(noteCount, shuffled.length); i++) {
            const note = shuffled[i];
            
            // Place away from roads and edges
            let nx, ny, attempts = 0, valid = false;
            while (attempts < 20 && !valid) {
                nx = Phaser.Math.Between(40, w - 40);
                ny = Phaser.Math.Between(40, h - 40);
                valid = true;
                for (const seg of route.road.segments) {
                    if (Math.abs(ny - seg.y) < seg.height / 2 + 30) { valid = false; break; }
                }
                attempts++;
            }
            if (!valid) continue;
            
            this.renderWorldNote(nx, ny, note);
        }
    }
    
    renderWorldNote(x, y, note) {
        const d = 10 + y * 0.01;
        const tc = (c) => this.tintColor(c, this.lighting.ambient, this.lighting.intensity);
        const fmt = note.format.toLowerCase();
        
        // Visual varies by format type
        if (fmt.includes('spray') || fmt.includes('stencil') || fmt.includes('marker on') || fmt.includes('scratched') || fmt.includes('blood') || fmt.includes('graffiti')) {
            // Wall text / graffiti — paint marks on ground or nearby surface
            const paintColor = fmt.includes('blood') ? 0x6a2a2a : 0xaaaaaa;
            this.add.rectangle(x, y, Phaser.Math.Between(12, 20), Phaser.Math.Between(4, 8), tc(paintColor), 0.3)
                .setAngle(Phaser.Math.Between(-10, 10)).setDepth(d + 0.001);
            // Second line
            this.add.rectangle(x + 2, y + 3, Phaser.Math.Between(8, 14), Phaser.Math.Between(2, 4), tc(paintColor), 0.2)
                .setAngle(Phaser.Math.Between(-5, 5)).setDepth(d + 0.001);
        } else if (fmt.includes('terminal') || fmt.includes('log ') || fmt.includes('printout') || fmt.includes('transcript')) {
            // Powered terminal / electronic — faint screen glow
            this.add.rectangle(x, y - 2, 8, 6, tc(0x2a2a3a)).setDepth(d + 0.001);
            this.add.rectangle(x, y - 2, 6, 4, tc(0x3a5a4a), 0.4).setDepth(d + 0.002);
            // Screen glow
            this.add.ellipse(x, y, 12, 8, 0x4a8a6a, 0.06).setDepth(d - 0.001);
            // Text lines on screen
            this.add.rectangle(x, y - 3, 4, 1, tc(0x6aaa8a), 0.3).setDepth(d + 0.003);
            this.add.rectangle(x, y - 1, 3, 1, tc(0x6aaa8a), 0.2).setDepth(d + 0.003);
        } else {
            // Paper-based note — small paper scrap on the ground
            const paperColor = fmt.includes('crayon') || fmt.includes('child') ? 0xddddcc : 0xccccbb;
            // Paper
            this.add.rectangle(x, y, 6, 8, tc(paperColor), 0.6)
                .setAngle(Phaser.Math.Between(-15, 15)).setDepth(d + 0.002);
            // Shadow beneath
            this.add.ellipse(x + 1, y + 1, 8, 4, 0x000000, 0.08).setDepth(d - 0.001);
            // Text line representation
            this.add.rectangle(x, y - 1, 4, 1, tc(0x3a3a3a), 0.2)
                .setAngle(Phaser.Math.Between(-15, 15)).setDepth(d + 0.003);
            this.add.rectangle(x, y + 1, 3, 1, tc(0x3a3a3a), 0.15)
                .setAngle(Phaser.Math.Between(-15, 15)).setDepth(d + 0.003);
        }
        
        // Subtle indicator — tiny pulsing dot so the player knows it's interactable
        const indicator = this.add.circle(x, y - 8, 2, 0xccaa66, 0.35).setDepth(d + 0.01);
        this.tweens.add({ targets: indicator, alpha: 0.1, duration: 1200, yoyo: true, repeat: -1 });
        
        // Interaction hitbox
        const hitbox = this.add.rectangle(x, y, 16, 14, 0x000000, 0).setDepth(15);
        hitbox.noteData = note;
        hitbox.noteRead = false;
        hitbox.noteIndicator = indicator;
        this.worldNoteProps.push(hitbox);
    }
    
    readNote(noteProp) {
        if (noteProp.noteRead) return;
        noteProp.noteRead = true;
        const note = noteProp.noteData;
        
        AudioManager.lootCrate();
        Haptics.light();
        
        // Track as found (runtime + persistent)
        if (!this.state.foundNotes.includes(note.id)) {
            this.state.foundNotes.push(note.id);
        }
        try { StatTracker.addFoundNote(note.id); } catch(e) {}
        
        // Fade out the indicator
        if (noteProp.noteIndicator) {
            this.tweens.add({ targets: noteProp.noteIndicator, alpha: 0, duration: 400, onComplete: () => noteProp.noteIndicator.destroy() });
        }
        
        // Pause gameplay
        this._noteOverlayActive = true;
        
        // Build reading overlay
        const cam = this.cameras.main;
        const cx = cam.scrollX + cam.width / 2;
        const cy = cam.scrollY + cam.height / 2;
        const panelW = Math.min(cam.width * 0.85, 340);
        const panelH = Math.min(cam.height * 0.75, 420);
        
        const noteContainer = this.add.container(cx, cy).setDepth(200);
        
        // Dim background
        const dimBg = this.add.rectangle(0, 0, cam.width + 20, cam.height + 20, 0x000000, 0.6);
        noteContainer.add(dimBg);
        
        // Paper panel — slightly off-white, torn edge feel
        const panelBg = this.add.rectangle(0, 0, panelW, panelH, 0x1a1a18, 0.92);
        noteContainer.add(panelBg);
        // Inner border
        const border = this.add.rectangle(0, 0, panelW - 4, panelH - 4, 0x000000, 0)
            .setStrokeStyle(1, 0x4a4a3a, 0.5);
        noteContainer.add(border);
        
        // Format header
        const headerStyle = { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#8a7a5a', wordWrap: { width: panelW - 30 } };
        const headerText = this.add.text(0, -panelH / 2 + 18, note.format.toUpperCase(), headerStyle).setOrigin(0.5, 0);
        noteContainer.add(headerText);
        
        // Divider line
        const divider = this.add.rectangle(0, -panelH / 2 + 18 + headerText.height + 6, panelW - 40, 1, 0x4a4a3a, 0.4);
        noteContainer.add(divider);
        
        // Note text body
        const bodyY = divider.y + 10;
        const bodyMaxH = panelH - (bodyY + panelH / 2) - 40;
        const bodyStyle = { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#ccccbb', wordWrap: { width: panelW - 36 }, lineSpacing: 3 };
        const bodyText = this.add.text(0, bodyY, note.text, bodyStyle).setOrigin(0.5, 0);
        
        // If text overflows, truncate with scroll hint
        if (bodyText.height > bodyMaxH) {
            const mask = this.add.rectangle(cx, cy + bodyY + bodyMaxH / 2 - panelH / 2 + panelH / 2, panelW, bodyMaxH, 0x000000, 0);
            // Simple crop — just limit the visible area (no scroll needed for these note lengths)
            bodyText.setCrop(0, 0, panelW - 36, bodyMaxH);
        }
        noteContainer.add(bodyText);
        
        // "NOTE FOUND" label at bottom
        const foundLabel = this.add.text(0, panelH / 2 - 30, 'NOTE FOUND', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#6a8a5a'
        }).setOrigin(0.5);
        noteContainer.add(foundLabel);
        
        // Dismiss prompt
        const dismissText = this.add.text(0, panelH / 2 - 14, 'tap to close', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#5a5a4a'
        }).setOrigin(0.5);
        noteContainer.add(dismissText);
        
        // Fade in
        noteContainer.setAlpha(0);
        this.tweens.add({ targets: noteContainer, alpha: 1, duration: 300 });
        
        // Dismiss handler — tap anywhere or press any key
        const dismiss = () => {
            if (!noteContainer.active) return;
            this.tweens.add({ targets: noteContainer, alpha: 0, duration: 200, onComplete: () => {
                noteContainer.destroy();
                this._noteOverlayActive = false;
            }});
        };
        
        // Delay before allowing dismiss (prevent accidental instant close)
        this.time.delayedCall(400, () => {
            this.input.once('pointerdown', dismiss);
            this.input.keyboard.once('keydown', dismiss);
        });
    }
    
    siphonFuel(zone) {
        if (!zone._siphon || zone._siphon.siphoned) return;
        zone._siphon.siphoned = true;
        
        const fuel = zone._siphon.fuelAmount;
        const px = this.player.x, py = this.player.y;
        
        if (fuel > 0) {
            // Siphon animation — brief delay then reward
            this.state.fuel = Math.min((this.state.fuel || 0) + fuel, CONFIG.player.fuel || 100);
            
            // Siphoning visual
            const siphonText = this.add.text(px, py - 20, 'Siphoning...', {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#aa8844'
            }).setOrigin(0.5).setDepth(100);
            
            this.time.delayedCall(800, () => {
                siphonText.destroy();
                const gainText = this.add.text(px, py - 25, `+${fuel} FUEL`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#ddaa44', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(100);
                this.tweens.add({
                    targets: gainText, y: gainText.y - 25, alpha: 0,
                    duration: 1200, onComplete: () => gainText.destroy()
                });
            });
        } else {
            // Dry — no fuel
            const dryText = this.add.text(px, py - 20, 'Tank is dry', {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#886655'
            }).setOrigin(0.5).setDepth(100);
            this.tweens.add({
                targets: dryText, alpha: 0, y: dryText.y - 15,
                duration: 1500, onComplete: () => dryText.destroy()
            });
        }
    }
    
    showVehicleMenu() {
        if (this.popupActive) return;
        if (this.vehicleMenu || this.inventoryUI) return;
        const W = CONFIG.width, H = CONFIG.height;
        this.vehicleMenu = [];
        UIAtlas.build(this);
        const panel = UIManager.createPanel(this, W/2, H/2, 180, 200, {
            title: 'VEHICLE', accent: 0x446655, closable: true,
            onClose: () => this.closeVehicleMenu(), depth: 491, modal: true
        });
        panel.setScrollFactor(0);
        this.vehicleMenu.push(panel);
        const cb = panel._contentBounds;
        const invBtn = UIManager.createButton(this, 0, cb.y + 18, 'INVENTORY', {
            width: 140, height: 28, style: 'normal', fontSize: uiPx(10), depth: 492,
            onClick: () => { this.closeVehicleMenu(); this.openInventory(); }
        });
        panel.add(invBtn);
        const mapBtn = UIManager.createButton(this, 0, cb.y + 52, 'MAP', {
            width: 140, height: 28, style: 'normal', fontSize: uiPx(10), depth: 492,
            onClick: () => { this.closeVehicleMenu(); this.returnToMap(); }
        });
        panel.add(mapBtn);
        const extractFuel = this.getExtractFuelCost();
        const canExtract = this.state.fuel >= extractFuel;
        const extBtn = UIManager.createButton(this, 0, cb.y + 86, `EXTRACT (${extractFuel})`, {
            width: 140, height: 28, style: canExtract ? 'confirm' : 'danger', fontSize: uiPx(10), depth: 492,
            onClick: canExtract ? () => { this.closeVehicleMenu(); this.extractToSafehouse(extractFuel); } : null
        });
        panel.add(extBtn);
    }

    
    closeVehicleMenu() {
        if (this.vehicleMenu) {
            this.vehicleMenu.forEach(e => { if (e && e.destroy) e.destroy(); });
            this.vehicleMenu = null;
        }
    }
    
    getExtractFuelCost() {
        // Base cost + scales with distance from start
        // Use the route's node row if available
        const row = this.currentRow || 1;
        return Math.max(5, Math.floor(row * 3));
    }
    
    extractToSafehouse(fuelCost) {
        this.state.fuel -= fuelCost;
        
        // Cube Resonance: convert cube charge to bonus bits
        
        
        
        SceneTransition.fadeTo(this, 'SafehouseScene', SceneTransition.safehouseReturnData(this));
    }
    
    openInventory() {
        if (this.inventoryUI) return; // Already open
        this.inventoryUI = new InventoryUI(
            this,
            this.state.backpack,
            this.state.equipment,
            () => {
                this.inventoryUI = null;
                if (this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
                this.updateConsumableButton();
                // Refresh magazine/reload from potentially swapped weapon
                const eqStats = ItemManager.getEquippedStats(this.state);
                const newMag = eqStats.mag || 10;
                if (newMag !== this._magazineMax) {
                    this._magazineMax = newMag;
                    this._magazine = Math.min(this._magazine, this._magazineMax);
                }
                if (this._ammoHud) this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
            }
        );
    }
    
    quickUseConsumable() {
        // If currently channeling, ignore
        if (ConsumableSystem.isChanneling()) return;
        
        // Use equipped consumable first, then fall back to backpack
        let item = null;
        let fromEquipped = false;
        if (this.state.equipment && this.state.equipment.consumable) {
            item = this.state.equipment.consumable;
            fromEquipped = true;
        } else {
            const idx = ItemManager.findFirstConsumable(this.state.backpack);
            if (idx === -1) {
                Blurbs.show(this, this.player, 'NO CONSUMABLES', { color: '#ff4444' });
                this.updateConsumableButton();
                return;
            }
            item = this.state.backpack[idx];
        }
        if (!item) return;
        
        // Grenades require lock-on
        if (item.effect === 'grenade' && (!this.lockedTarget || !this.lockedTarget.active)) {
            Blurbs.show(this, this.player, 'No target locked!', { color: '#ff4444' });
            return;
        }
        
        // Attempt to use — ConsumableSystem returns false if can't use
        const used = ConsumableSystem.use(this, this.state, item, this.player);
        if (used) {
            if (fromEquipped) {
                this.state.equipment.consumable = null;
            } else {
                const idx = this.state.backpack.indexOf(item);
                if (idx >= 0) ItemManager.removeOneFromStack(this.state.backpack, idx);
            }
        }
        
        this.updateConsumableButton();
    }
    
    updateConsumableButton() {
        // Check equipped consumable first
        const equipped = this.state.equipment && this.state.equipment.consumable;
        if (equipped) {
            this.consumeIcon.setText(equipped.icon);
            const bpCount = this.state.backpack.reduce((sum, i) => sum + (i && i.category === 'consumable' ? (i.stackCount || 1) : 0), 0);
            this.consumeCount.setText(`×${1 + bpCount}`);
            this.consumeBtn._bg.setTint(0x66aa66).setAlpha(0.9);
            return;
        }
        
        const idx = ItemManager.findFirstConsumable(this.state.backpack);
        if (idx >= 0) {
            const item = this.state.backpack[idx];
            this.consumeIcon.setText(item.icon);
            const count = this.state.backpack.reduce((sum, i) => sum + (i && i.category === 'consumable' ? (i.stackCount || 1) : 0), 0);
            this.consumeCount.setText(`×${count}`);
            this.consumeBtn._bg.setTint(0x66aa66).setAlpha(0.9);
        } else {
            this.consumeIcon.setText('X');
            this.consumeCount.setText('');
            _restoreTint(this.consumeBtn._bg); this.consumeBtn._bg.setAlpha(0.5);
        }
        
        // Update active relic button
        this.updateRelicButton();
    }
    
    updateRelicButton() {
        // Find active augment — check weapon augment first, then melee augment
        const wAug = this.state.equipment?.weapon?.augment;
        const mAug = this.state.equipment?.melee?.augment;
        // Primary augment: prefer active over passive, weapon over melee
        const activeAug = (wAug?.relicType === 'active' ? wAug : null) || (mAug?.relicType === 'active' ? mAug : null);
        const passiveAug = (wAug?.relicType === 'passive' ? wAug : null) || (mAug?.relicType === 'passive' ? mAug : null);
        const augment = activeAug || passiveAug;
        
        if (!augment || !augment.relicType) {
            if (this.relicBtnBg) this.relicBtnBg.setVisible(false);
            this.relicIcon.setVisible(false);
            this.relicCooldownText.setVisible(false);
            this.relicActiveText.setVisible(false);
            this.relicCooldownOverlay.setVisible(false);
            return;
        }
        
        this.relicBtnBg.setVisible(true);
        
        const now = this.time.now;
        const onCooldown = now < this._relicCooldownEnd;
        const abilityActive = now < this._relicActiveEnd;
        
        if (augment.relicType === 'passive') {
            this.relicIcon.setVisible(true).setText(augment.icon);
            this.relicCooldownText.setVisible(false);
            this.relicActiveText.setVisible(false);
            this.relicCooldownOverlay.setVisible(false);
            return;
        }
        
        // Active augment states — three phases: active → cooldown → ready
        if (abilityActive) {
            const secs = Math.ceil((this._relicActiveEnd - now) / 1000);
            this.relicIcon.setVisible(true).setText(augment.icon);
            this.relicActiveText.setVisible(true).setText(`${secs}s`);
            this.relicCooldownText.setVisible(false);
            this.relicCooldownOverlay.setVisible(false);
            
        } else if (onCooldown) {
            const secs = Math.ceil((this._relicCooldownEnd - now) / 1000);
            this.relicIcon.setVisible(false);
            this.relicActiveText.setVisible(false);
            this.relicCooldownText.setVisible(true).setText(`${secs}`);
            this.relicCooldownOverlay.setVisible(true);
            
        } else {
            this.relicIcon.setVisible(true).setText(augment.icon);
            this.relicCooldownText.setVisible(false);
            this.relicActiveText.setVisible(false);
            this.relicCooldownOverlay.setVisible(false);
            
        }
    }
    
    activateRelic() {
        // Find active augment chip — weapon priority
        const wAug = this.state.equipment?.weapon?.augment;
        const mAug = this.state.equipment?.melee?.augment;
        const augment = (wAug?.relicType === 'active' ? wAug : null) || (mAug?.relicType === 'active' ? mAug : null);
        if (!augment) return;
        
        const now = this.time.now;
        if (now < this._relicCooldownEnd) {
            this.tweens.add({ targets: this.relicBtnBg, scaleX: 0.8, scaleY: 0.8, duration: 100, yoyo: true });
            return;
        }
        
        this._relicCooldownEnd = now + (augment.relicCooldown || 45000);
        this.tweens.add({ targets: this.relicBtnBg, scaleX: 1.3, scaleY: 1.3, duration: 150, yoyo: true });
        
        const px = this.player.x, py = this.player.y;
        
        if (augment.relicAbility === 'firepower') {
            // Firepower: fire slug ammo for 10s, applies Burn DOT
            const fpSig = { cooldown: augment.relicCooldown || 15000, duration: 10000, value: 15, dotDuration: 5000 };
            SignatureEffects.activateFirepower(this, fpSig);
            this._relicActiveEnd = now + 10000;
        } else if (augment.relicAbility === 'sharpshooter') {
            // Sharpshooter: 100% accuracy + 25% damage for 8s
            const ssSig = { cooldown: augment.relicCooldown || 20000, duration: 8000, value: 25 };
            SignatureEffects.activateSharpshooter(this, ssSig);
            this._relicActiveEnd = now + 8000;
        } else if (augment.relicAbility === 'warTotem') {
            // War Totem: ward bubble — heals 3 HP/s, +25% damage, 8s duration
            this._relicActiveEnd = now + 8000;
            this._warTotemActive = true;
            this._warTotemX = px;
            this._warTotemY = py;
            this._warTotemDmgBonus = 0.25;
            
            const wardRadius = 55;
            const wardParts = [];
            
            // === WAR TOTEM: 3D isometric dome bubble (Ward of Dawn style) ===
            // Ground ring — elliptical base showing the dome's footprint
            const groundRing = this.add.ellipse(px, py + 8, wardRadius * 2.2, wardRadius * 1.1, 0x44aaff, 0.06).setDepth(2);
            const groundEdge = this.add.ellipse(px, py + 8, wardRadius * 2.2, wardRadius * 1.1, 0x000000, 0).setDepth(2);
            groundEdge.setStrokeStyle(1.5, 0x44aaff, 0.25);
            wardParts.push(groundRing, groundEdge);
            
            // Dome body — stacked ellipses creating a translucent hemisphere
            // Bottom band (widest)
            const band0 = this.add.ellipse(px, py, wardRadius * 2, wardRadius * 1.0, 0x3388cc, 0.04).setDepth(3);
            wardParts.push(band0);
            // Mid band
            const band1 = this.add.ellipse(px, py - 14, wardRadius * 1.75, wardRadius * 0.88, 0x44aaff, 0.05).setDepth(3);
            wardParts.push(band1);
            // Upper band
            const band2 = this.add.ellipse(px, py - 28, wardRadius * 1.35, wardRadius * 0.68, 0x55bbff, 0.06).setDepth(3);
            wardParts.push(band2);
            // Crown (top of dome)
            const crown = this.add.ellipse(px, py - 40, wardRadius * 0.7, wardRadius * 0.35, 0x66ccff, 0.08).setDepth(3);
            wardParts.push(crown);
            
            // Dome outline arcs — front arc (visible curve) 
            const arcPts = [];
            for (let a = 0; a <= Math.PI; a += Math.PI / 12) {
                const ax = px + Math.cos(a) * wardRadius * 1.1;
                const ay = py + 8 - Math.sin(a) * wardRadius * 0.9;
                arcPts.push(new Phaser.Geom.Point(ax, ay));
            }
            const arcGfx = this.add.graphics().setDepth(4);
            arcGfx.lineStyle(1.5, 0x44aaff, 0.3);
            arcGfx.beginPath();
            arcGfx.moveTo(arcPts[0].x, arcPts[0].y);
            for (let i = 1; i < arcPts.length; i++) {
                arcGfx.lineTo(arcPts[i].x, arcPts[i].y);
            }
            arcGfx.strokePath();
            wardParts.push(arcGfx);
            
            // Side arcs (depth curves showing dome is 3D)
            const sideArc = this.add.graphics().setDepth(4);
            sideArc.lineStyle(1, 0x44aaff, 0.15);
            sideArc.beginPath();
            for (let a = 0; a <= Math.PI; a += Math.PI / 12) {
                const sx = px + Math.cos(a) * wardRadius * 0.5;
                const sy = py + 8 - Math.sin(a) * wardRadius * 0.9;
                if (a === 0) sideArc.moveTo(sx, sy);
                else sideArc.lineTo(sx, sy);
            }
            sideArc.strokePath();
            wardParts.push(sideArc);
            
            // Hexagonal shield patterns on dome surface
            const hexGfx = this.add.graphics().setDepth(4);
            hexGfx.lineStyle(0.5, 0x66ccff, 0.12);
            const hexPositions = [
                { x: 0, y: -20, s: 12 }, { x: -18, y: -10, s: 10 }, { x: 18, y: -10, s: 10 },
                { x: -28, y: 2, s: 8 }, { x: 0, y: 2, s: 11 }, { x: 28, y: 2, s: 8 },
                { x: -14, y: -30, s: 8 }, { x: 14, y: -30, s: 8 }
            ];
            hexPositions.forEach(h => {
                const hx = px + h.x, hy = py + h.y;
                hexGfx.beginPath();
                for (let i = 0; i <= 6; i++) {
                    const angle = (Math.PI / 3) * i - Math.PI / 6;
                    const vx = hx + Math.cos(angle) * h.s;
                    const vy = hy + Math.sin(angle) * h.s * 0.6; // Squished for isometric
                    if (i === 0) hexGfx.moveTo(vx, vy);
                    else hexGfx.lineTo(vx, vy);
                }
                hexGfx.strokePath();
            });
            wardParts.push(hexGfx);
            
            // Center glow pillar — faint vertical light beam
            const pillar = this.add.rectangle(px, py - 15, 3, 38, 0x44aaff, 0.12).setDepth(4);
            wardParts.push(pillar);
            
            // Shimmer / pulse animation on dome bands
            this.tweens.add({ targets: [band0, band1, band2, crown], alpha: '+=0.03', duration: 600, yoyo: true, repeat: 6, ease: 'Sine.easeInOut' });
            this.tweens.add({ targets: hexGfx, alpha: 0.3, duration: 400, yoyo: true, repeat: 9, ease: 'Sine.easeInOut' });
            this.tweens.add({ targets: pillar, alpha: 0.25, scaleY: 1.1, duration: 500, yoyo: true, repeat: 7 });
            
            // Spawn flash — dome materializes
            const spawnFlash = this.add.ellipse(px, py, wardRadius * 2.5, wardRadius * 1.2, 0x44aaff, 0.3).setDepth(5);
            this.tweens.add({ targets: spawnFlash, alpha: 0, scaleX: 0.8, scaleY: 0.8, duration: 400, onComplete: () => spawnFlash.destroy() });
            
            // Heal tick every second
            let ticks = 0;
            const healTimer = this.time.addEvent({ delay: 1000, repeat: 7, callback: () => {
                if (!this._warTotemActive) return;
                const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(this.state.equipment).maxHealth || 0);
                const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, px, py);
                if (dist < wardRadius + 10) {
                    this.state.health = Math.min(maxHp, this.state.health + 3);
                    const ht = this.add.text(this.player.x, this.player.y - 20, '+3', { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#44aaff' }).setOrigin(0.5).setDepth(100);
                    this.tweens.add({ targets: ht, y: ht.y - 15, alpha: 0, duration: 500, onComplete: () => ht.destroy() });
                }
                ticks++;
                if (ticks >= 8) {
                    // Dome collapse — fade all parts
                    wardParts.forEach(p => {
                        if (p && p.active) this.tweens.add({ targets: p, alpha: 0, duration: 400, onComplete: () => p.destroy() });
                    });
                    this._warTotemActive = false;
                    this._warTotemDmgBonus = 0;
                }
            }});
            
            this.time.delayedCall(8000, () => {
                this._warTotemActive = false;
                this._warTotemDmgBonus = 0;
                wardParts.forEach(p => { if (p && p.active) { this.tweens.add({ targets: p, alpha: 0, duration: 300, onComplete: () => p.destroy() }); } });
            });
            
            const txt = this.add.text(px, py - 55, 'WAR TOTEM', { fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#44aaff', fontStyle: 'bold' }).setOrigin(0.5).setDepth(100);
            this.tweens.add({ targets: txt, y: py - 75, alpha: 0, duration: 800, onComplete: () => txt.destroy() });
        }
        
        this.updateRelicButton();
    }
    
    // === PASSIVE AUGMENT PROCESSING — called from update loop ===
    processPassiveRelics(time, delta) {
        // Collect all augments from weapon and melee
        const augments = [this.state.equipment?.weapon?.augment, this.state.equipment?.melee?.augment].filter(a => a && a.relicType);
        if (augments.length === 0) return;
        
        augments.forEach(aug => {
            const ability = aug.relicAbility;
        
            // === FIELD MEDIC: auto-consume lowest bandage below 25% HP ===
            if (ability === 'fieldMedic') {
                const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(this.state.equipment).maxHealth || 0);
                if (this.state.health < maxHp * 0.25) {
                    if (!this._fieldMedicCooldownEnd || time > this._fieldMedicCooldownEnd) {
                        let bestIdx = -1, bestTier = 99;
                        this.state.backpack.forEach((item, i) => {
                            if (item && item.subtype === 'bandage' && (item.tier || 1) < bestTier) {
                                bestTier = item.tier || 1;
                                bestIdx = i;
                            }
                        });
                        if (bestIdx >= 0) {
                            const item = this.state.backpack[bestIdx];
                            this.state.backpack[bestIdx] = null;
                            const baseHeal = item.healPercent ? Math.round(maxHp * item.healPercent / 100) : (item.healAmount || 0);
                            const fmBonus = ItemManager.getEquipmentStats(this.state.equipment).healBonus || 0;
                            const boostedHeal = fmBonus > 0 ? Math.round(baseHeal * (1 + fmBonus / 100)) : baseHeal;
                            const heal = Math.min(boostedHeal, maxHp - this.state.health);
                            this.state.health += heal;
                            if (this._runStats) this._runStats.timesHealed++;
                            this._fieldMedicCooldownEnd = time + (aug.relicCooldown || 30000);
                            const txt = this.add.text(this.player.x, this.player.y - 30, `AUTO-HEAL +${heal}`, {
                                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#44dd44', fontStyle: 'bold'
                            }).setOrigin(0.5).setDepth(100);
                            this.tweens.add({ targets: txt, y: this.player.y - 55, alpha: 0, duration: 800, onComplete: () => txt.destroy() });
                            this.player.setTint(0x44ff44);
                            this.time.delayedCall(150, () => _restoreTint(this.player));
                            this.updateConsumableButton();
                        }
                    }
                }
            }
        
            // === BLOOD PACT: damage taken stacks offense + defense (managed in enemyHitPlayer) ===
            if (ability === 'bloodPact') {
                if (this._bloodPactStacks > 0 && time - (this._bloodPactLastHit || 0) > 8000) {
                    this._bloodPactStacks = 0;
                    this._bloodPactDmgBonus = 0;
                    this._bloodPactResist = 0;
                }
            }
        });
        
        // Always update augment button display
        this.updateRelicButton();
    }

    findTarget() {
        // Helper: check if enemy is within the visible camera viewport (with small margin)
        const cam = this.cameras.main;
        const margin = 30;
        const isOnScreen = (e) => {
            const sx = e.x - cam.scrollX;
            const sy = e.y - cam.scrollY;
            return sx >= -margin && sx <= CONFIG.width + margin && sy >= -margin && sy <= CONFIG.height + margin;
        };
        
        // Helper: check line of sight — true if NO wall blocks the line from player to target
        const hasLOS = (tx, ty) => {
            if (!this.wallRects || this.wallRects.length === 0) return true;
            const line = new Phaser.Geom.Line(this.player.x, this.player.y, tx, ty);
            for (let i = 0; i < this.wallRects.length; i++) {
                const r = this.wallRects[i];
                // Quick distance check — skip distant walls
                const wcx = r.x + r.width/2, wcy = r.y + r.height/2;
                const wd = Math.abs(this.player.x - wcx) + Math.abs(this.player.y - wcy);
                if (wd > 500) continue;
                if (Phaser.Geom.Intersects.LineToRectangle(line, r)) return false;
            }
            return true;
        };
        
        // Lock-on system: keep current target if still valid AND on screen AND visible
        if (this.lockedTarget && this.lockedTarget.active) {
            if (!isOnScreen(this.lockedTarget)) {
                this.lockedTarget = null;
            } else if (!hasLOS(this.lockedTarget.x, this.lockedTarget.y)) {
                // Lost line of sight — drop lock
                this.lockedTarget = null;
            } else {
                const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, this.lockedTarget.x, this.lockedTarget.y);
                const equipStats = ItemManager.getEquipmentStats(this.state.equipment);
                let lockRange = equipStats.range || CONFIG.player.firingRange;
                if (equipStats.targetRange > 0) lockRange = Math.round(lockRange * (1 + equipStats.targetRange / 100));
                const maxLock = (lockRange * 2) + 100;
                if (d > maxLock) {
                    this.lockedTarget = null;
                } else {
                    this.target = this.lockedTarget;
                    return;
                }
            }
        }
        // Lock target died or deactivated — clear
        if (this.lockedTarget && (!this.lockedTarget.active)) {
            this.lockedTarget = null;
        }
        
        // Auto-acquire: find nearest enemy within weapon range AND on screen AND with LOS
        this.target = null;
        const equipStats = ItemManager.getEquipmentStats(this.state.equipment);
        let weaponRange = equipStats.range || CONFIG.player.firingRange;
        // Target Range mod: percentage bonus to acquisition distance
        if (equipStats.targetRange > 0) weaponRange = Math.round(weaponRange * (1 + equipStats.targetRange / 100));
        let closest = weaponRange + 50;
        
        this.enemies.getChildren().forEach(e => {
            if (!e.active) return;
            if (!isOnScreen(e)) return;
            const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, e.x, e.y);
            if (d < closest && hasLOS(e.x, e.y)) {
                closest = d;
                this.target = e;
            }
        });
        
        // Auto-lock onto acquired target
        if (this.target && !this.lockedTarget) {
            this.lockedTarget = this.target;
        }
    }

    tapSwitchTarget(screenX, screenY) {
        const worldX = screenX + this.cameras.main.scrollX;
        const worldY = screenY + this.cameras.main.scrollY;
        
        // Check if tapping near the currently locked target — unlock
        if (this.lockedTarget && this.lockedTarget.active) {
            const dToLocked = Phaser.Math.Distance.Between(worldX, worldY, this.lockedTarget.x, this.lockedTarget.y);
            if (dToLocked < 50) {
                // Unlock flash
                const ring = this.add.circle(this.lockedTarget.x, this.lockedTarget.y, 18, 0xffffff, 0).setStrokeStyle(2, 0x666666, 0.6).setDepth(30);
                this.tweens.add({ targets: ring, scaleX: 0.3, scaleY: 0.3, alpha: 0, duration: 200, onComplete: () => ring.destroy() });
                this.lockedTarget = null;
                this.target = null;
                return true;
            }
        }
        
        // Find enemy nearest to tap point (excluding current lock) with LOS check
        let nearest = null;
        let nearestDist = 150;
        const hasLOS = (tx, ty) => {
            if (!this.wallRects || this.wallRects.length === 0) return true;
            const line = new Phaser.Geom.Line(this.player.x, this.player.y, tx, ty);
            for (let i = 0; i < this.wallRects.length; i++) {
                const r = this.wallRects[i];
                const wcx = r.x + r.width/2, wcy = r.y + r.height/2;
                if (Math.abs(this.player.x - wcx) + Math.abs(this.player.y - wcy) > 500) continue;
                if (Phaser.Geom.Intersects.LineToRectangle(line, r)) return false;
            }
            return true;
        };
        this.enemies.getChildren().forEach(e => {
            if (!e.active) return;
            if (e === this.lockedTarget) return;
            const d = Phaser.Math.Distance.Between(worldX, worldY, e.x, e.y);
            if (d < nearestDist && hasLOS(e.x, e.y)) {
                nearestDist = d;
                nearest = e;
            }
        });
        
        if (nearest) {
            this.lockedTarget = nearest;
            this.target = nearest;
            // Lock flash
            const ring = this.add.circle(nearest.x, nearest.y, 18, 0xffffff, 0).setStrokeStyle(2, 0xff4444, 0.8).setDepth(30);
            this.tweens.add({ targets: ring, scaleX: 1.8, scaleY: 1.8, alpha: 0, duration: 200, onComplete: () => ring.destroy() });
            return true;
        }
        return false;
    }

    // Weapon sprite created in create() — simple gun graphic, no spritesheet needed

    // === WEAPON FLAIR — Animated effects on held weapons ===
    updateWeaponFlair() {
        CombatSystem.updateFlairEffects(this);
    }

    updateAim() {
        if (this.target && this.target.active) {
            this.aimAngle = Phaser.Math.Angle.Between(this.player.x, this.player.y, this.target.x, this.target.y);
            const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, this.target.x, this.target.y);
            
            this.reticle.setPosition(this.target.x, this.target.y).setVisible(true);
            
            // Lock indicator — slightly larger when locked
            if (this.lockedTarget === this.target) {
                this.reticle.setScale(1.2);
                this.reticle.setAlpha(0.9);
            } else {
                this.reticle.setScale(1.0);
                this.reticle.setAlpha(0.5);
            }
            
            const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
            const mRange = Math.max(eqStats.meleeRange || 0, CONFIG.player.meleeRange);
            const weaponRange = 130 + (eqStats.targetRange || 1) * 30;
            
            if (dist <= mRange) {
                this.reticle._drawCrosshair(0xffaa44);
                this.player.isArmed = false;
            } else if (dist <= weaponRange) {
                this.reticle._drawCrosshair(0xddccbb);
                this.player.isArmed = true;
            } else {
                this.reticle._drawCrosshair(0x666666);
                this.reticle.setAlpha(0.3);
                this.player.isArmed = false;
            }
        } else {
            this.reticle.setVisible(false);
            this.player.isArmed = false;
            const ml = Math.sqrt(this.moveDir.x*this.moveDir.x + this.moveDir.y*this.moveDir.y);
            if (ml > 0.1) this.aimAngle = Math.atan2(this.moveDir.y, this.moveDir.x);
        }
        
        // Armed state — swap player texture when locked on and in gun range
        const wt = this.player.weaponType || 'pistol';
        const armedSheetKey = 'player_sheet_armed_' + wt;
        const shouldBeArmed = this.lockedTarget && this.lockedTarget.active && this.player.isArmed;
        
        if (shouldBeArmed && this.textures.exists(armedSheetKey)) {
            // Create armed walk animations if they don't exist
            if (!this.anims.exists(`player_armed_${wt}_down`)) {
                const dirs = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
                dirs.forEach((dir, i) => {
                    const key = `player_armed_${wt}_${dir}`;
                    if (!this.anims.exists(key)) {
                        this.anims.create({ key, frames: this.anims.generateFrameNumbers(armedSheetKey, { start: i*3, end: i*3+2 }), frameRate: 8, repeat: -1 });
                    }
                });
            }
            
            if (!this.player._isArmedTexture) {
                this.player._isArmedTexture = true;
                // Force texture swap and restart animation
                const dir = this.player.lastDir || 'down';
                const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                this.player.setTexture(armedSheetKey, frameMap[dir] || 0);
                this.player.setDisplaySize(40, 40);
                // Refresh backpack — weapon leaves holster
                if (this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
            }
        } else {
            if (this.player._isArmedTexture) {
                this.player._isArmedTexture = false;
                const dir = this.player.lastDir || 'down';
                const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                this.player.setTexture('player_sheet', frameMap[dir] || 0);
                this.player.setDisplaySize(40, 40);
                // Refresh backpack — weapon returns to holster
                if (this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
            }
        }
    }

    autoMelee() {
        if (!this.canMelee) return;
        if (ConsumableSystem.isChanneling()) return;
        
        const result = CombatSystem.melee(this, {
            state: this.state,
            equipment: this.state.equipment,
            player: this.player,
            enemies: this.enemies,
            onDamage: (e, dmg) => {
                this.damageEnemy(e, dmg, 'melee');
            }
        });
        
        if (result) {
            this.canMelee = false;
            this.time.delayedCall(result.cooldown, () => this.canMelee = true);
        }
    }
    
    meleeSwing(baseAngle) {
        // Get melee type from equipment
        const meleeItem = this.state.equipment && this.state.equipment.melee;
        const meleeType = meleeItem ? (meleeItem.baseId || 'blade') : 'blade';
        
        // Map melee baseId to sheet type
        const sheetType = (meleeType === 'blunt') ? 'blunt' : (meleeType === 'heavy') ? 'heavy' : 'blade';
        const sheetKey = 'player_sheet_melee_' + sheetType;
        
        // Determine swing direction from angle
        const angleDeg = ((baseAngle * 180 / Math.PI) + 360) % 360;
        let dir;
        if (angleDeg >= 337.5 || angleDeg < 22.5) dir = 'right';
        else if (angleDeg < 67.5) dir = 'down_right';
        else if (angleDeg < 112.5) dir = 'down';
        else if (angleDeg < 157.5) dir = 'down_left';
        else if (angleDeg < 202.5) dir = 'left';
        else if (angleDeg < 247.5) dir = 'up_left';
        else if (angleDeg < 292.5) dir = 'up';
        else dir = 'up_right';
        
        const animKey = `player_melee_${sheetType}_${dir}`;
        
        // Play swing animation on the player sprite
        if (this.textures.exists(sheetKey) && this.anims.exists(animKey)) {
            const wasArmed = this.player._isArmedTexture;
            const prevTexture = wasArmed ? ('player_sheet_armed_' + (this.player.weaponType || 'pistol')) : 'player_sheet';
            
            this.player._isMeleeSwinging = true;
            this.player._meleeSwingAngle = baseAngle;
            this.player.setTexture(sheetKey);
            this.player.play(animKey);
            
            // Refresh backpack — melee leaves holster
            if (this.player.backpack) {
                SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
            }
            
            // On animation complete, return to previous state
            this.player.once('animationcomplete', () => {
                this.player._isMeleeSwinging = false;
                const curDir = this.player.lastDir || 'down';
                const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                this.player.setTexture(prevTexture, frameMap[curDir] || 0);
                this.player.setDisplaySize(40, 40);
                // Refresh backpack — melee returns to holster
                if (this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
                // Resume walk anim if moving
                const prefix = wasArmed ? `player_armed_${this.player.weaponType || 'pistol'}_` : 'player_walk_';
                const walkKey = prefix + curDir;
                if (this.anims.exists(walkKey)) {
                    this.player.play(walkKey, true);
                }
            });
        }
        // VFX (shake, trails, sparks) handled by CombatSystem.melee using foundry profiles
    }

    autoShoot() {
        if (!this.canShoot || this._reloading) return;
        if (ConsumableSystem.isChanneling()) return;
        
        // Magazine check
        if (this._magazine !== undefined && this._magazine <= 0) {
            this._startReload();
            return;
        }
        
        this.canShoot = false;
        const result = CombatSystem.shoot(this, {
            state: this.state,
            equipment: this.state.equipment,
            aimAngle: this.aimAngle,
            bullets: this.bullets,
            target: this.target,
            player: this.player
        });
        
        if (result) {
            if (this._magazine !== undefined) this._magazine--;
            this.time.delayedCall(result.fireRate, () => this.canShoot = true);
        } else {
            this.canShoot = true;
        }
    }
    
    _startReload(blurbOverride) {
        if (this._reloading) return;
        this._reloading = true;
        this.canShoot = false;
        AudioManager.reload();
        
        // Player blurb — follows player via update loop
        const blurb = blurbOverride || 'Reloading';
        if (this.player) {
            this._reloadText = this.add.text(this.player.x, this.player.y - 30, blurb, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#ffcc44'
            }).setOrigin(0.5).setDepth(7.5);
        }
        
        // Notify HUD
        if (this._ammoHud) this._ammoHud.setReloading(true);
        
        const eqStats = ItemManager.getEquippedStats(this.state);
        const reloadMs = Math.max(500, 3000 - (eqStats.reload || 50) * 25);
        
        this.time.delayedCall(reloadMs, () => {
            // Infinite regular ammo — just refill mag
            this._magazine = this._magazineMax;
            this._reloading = false;
            this.canShoot = true;
            if (this._reloadText) { this._reloadText.destroy(); this._reloadText = null; }
            if (this._ammoHud) this._ammoHud.setReloading(false);
            // Update HUD to reflect power ammo state change
            if (this._ammoHud) this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
        });
    }

    spark(x, y, fromAngle, fx) {
        CombatSystem.spark(this, x, y, fromAngle, fx || null);
    }

    dodge(dx, dy) {
        if (!this.canDodge || this.isDodging) return;
        
        let len = Math.sqrt(dx*dx + dy*dy);
        if (len === 0) { dx = 0; dy = -1; len = 1; }
        
        this.canDodge = false;
        this.isDodging = true;
        this.isInvincible = true;
        this.player.setAlpha(0.4);
        const dodgeAngle = Math.atan2(dy, dx);
        this.player.setVelocity((dx/len) * CONFIG.player.dodgeSpeed, (dy/len) * CONFIG.player.dodgeSpeed);
        this._dodgeStart = Date.now();
        this._dodgeAngle = dodgeAngle;
        
        // Shake off any latched skitterlings
        EnemyAI._shakeOffLatched(this);

        // Phantom Coil: damage trail (relic enhancement)
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        const dodgeSigs = eqStats.signatures || [];
        
        // === BANE: Phase Shift — invisibility on dodge (Phantom) ===
        const phaseShift = dodgeSigs.find(s => s.effect === 'phaseShift');
        if (phaseShift) SignatureEffects.doPhaseShift(this, phaseShift);
        
        // === BANE: Hardened — damage reduction on dodge (Ironclad) ===
        const hardened = dodgeSigs.find(s => s.effect === 'hardened');
        if (hardened) SignatureEffects.doHardened(this, hardened);

        // Track enemies we've dodge-impacted to avoid double hits
        const impacted = new Set();

        for (let i = 0; i < 5; i++) {
            this.time.delayedCall(i * 40, () => {
                if (!this.isDodging) return;
                const ghost = this.add.rectangle(this.player.x, this.player.y, 22, 22, 0xccddee, 0.5 - i*0.08);
                ghost.setAngle(Phaser.Math.Between(-15, 15));
                this.tweens.add({ 
                    targets: ghost, alpha: 0, scale: 0.3,
                    angle: ghost.angle + Phaser.Math.Between(-30, 30),
                    duration: 200, onComplete: () => ghost.destroy() 
                });
                
                // === DODGE IMPACT: damage + stagger enemies you dodge through ===
                this.enemies.getChildren().forEach(e => {
                    if (!e.active || e._dying || impacted.has(e)) return;
                    const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, e.x, e.y);
                    if (d < 30) {
                        impacted.add(e);
                        const impactDmg = 10;
                        this.damageEnemy(e, impactDmg, 'dodge');
                        
                        // Knockback burst away from dodge path
                        const ka = Math.atan2(e.y - this.player.y, e.x - this.player.x);
                        e.setVelocity(Math.cos(ka) * 250, Math.sin(ka) * 250);
                        
                        // Stagger — 800ms stun (bosses immune)
                        if (!e.isBoss) {
                            e._staggered = true;
                            e.setTint(0x8899cc);
                            this.time.delayedCall(800, () => {
                                if (e.active) { e._staggered = false; _restoreTint(e); }
                            });
                        }
                        
                        // Impact flash — dodge blue
                        const imp = this.add.circle(e.x, e.y, 15, 0xccddee, 0.6);
                        this.tweens.add({ targets: imp, alpha: 0, scaleX: 2, scaleY: 2, duration: 150, onComplete: () => imp.destroy() });
                    }
                });
            });
        }

        // === PERFECT DODGE DETECTION — continuous checks during first 180ms ===
        let perfected = false;
        const scene = this;
        for (let t = 0; t < 5; t++) {
            this.time.delayedCall(t * 40, () => {
                if (!scene.isDodging || perfected) return;
                
                // Check enemy projectiles within 55px
                scene.physics.world.bodies.entries.forEach(body => {
                    if (!body.gameObject || !body.gameObject._isEnemyProjectile) return;
                    const d = Phaser.Math.Distance.Between(scene.player.x, scene.player.y, body.gameObject.x, body.gameObject.y);
                    if (d < 55) perfected = true;
                });
                
                // Check enemies mid-attack or at contact range
                scene.enemies.getChildren().forEach(e => {
                    if (!e.active || perfected) return;
                    const d = Phaser.Math.Distance.Between(scene.player.x, scene.player.y, e.x, e.y);
                    // Any enemy within dodge contact range — you phased through them
                    if (d < 25) { perfected = true; return; }
                    // Enemies actively attacking within 55px
                    if (d < 55 && (CONFIG.enemyTypes[e.enemyType]?.attackFlags || []).some(f => e[f])) {
                        perfected = true;
                    }
                });
                
                if (perfected) scene.triggerPerfectDodge();
            });
        }

        // === DODGE END: power melee on terminus ===
        this.time.delayedCall(CONFIG.player.dodgeDuration, () => {
            this.isDodging = false;
            this.isInvincible = false;
            this.player.setAlpha(1);
            
            // Power melee: closest enemy within 35px at dodge end
            let strikeTarget = null;
            let strikeDist = 35;
            this.enemies.getChildren().forEach(e => {
                if (!e.active || e._dying) return;
                const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, e.x, e.y);
                if (d < strikeDist) { strikeDist = d; strikeTarget = e; }
            });
            
            if (strikeTarget) {
                const baseMelee = eqStats.meleeDamage || CONFIG.player.meleeDamage;
                const strikeDmg = Math.round(baseMelee * 2);
                const strikeAngle = Math.atan2(strikeTarget.y - this.player.y, strikeTarget.x - this.player.x);
                
                this.damageEnemy(strikeTarget, strikeDmg, 'melee');
                
                // Heavy knockback
                const ka = Math.atan2(strikeTarget.y - this.player.y, strikeTarget.x - this.player.x);
                if (!strikeTarget.isBoss && strikeTarget.active) {
                    strikeTarget.setVelocity(Math.cos(ka) * 300, Math.sin(ka) * 300);
                    strikeTarget._staggered = true;
                    strikeTarget.setTint(0x8899cc);
                    this.time.delayedCall(600, () => {
                        if (strikeTarget.active) { strikeTarget._staggered = false; _restoreTint(strikeTarget); }
                    });
                }
                
                // VFX: power strike flash — larger, brighter, dodge-blue
                AudioManager.melee();
                Haptics.heavy();
                this.cameras.main.shake(120, 0.012);
                
                const strikeFlash = this.add.circle(strikeTarget.x, strikeTarget.y, 20, 0xccddee, 0.7).setDepth(30);
                this.tweens.add({ targets: strikeFlash, alpha: 0, scaleX: 2.5, scaleY: 2.5, duration: 200, onComplete: () => strikeFlash.destroy() });
                
                // Burst sparks
                for (let s = 0; s < 8; s++) {
                    const sa = (s / 8) * Math.PI * 2;
                    const spark = this.add.rectangle(
                        strikeTarget.x, strikeTarget.y, 5, 5,
                        s % 2 === 0 ? 0xccddee : 0xffffff, 0.8
                    ).setAngle(45).setDepth(30);
                    this.tweens.add({
                        targets: spark,
                        x: spark.x + Math.cos(sa) * 35, y: spark.y + Math.sin(sa) * 35,
                        alpha: 0, scale: 0.2, duration: 180,
                        onComplete: () => spark.destroy()
                    });
                }
                
                // Blurb
                Blurbs.show(this, strikeTarget, 'STRIKE', { color: '#ccddee', fontSize: 11, duration: 500 });
                
                // Brief i-frames for the strike moment
                this.isInvincible = true;
                this.time.delayedCall(150, () => { this.isInvincible = false; });
            }
        });
        this.time.delayedCall(CONFIG.player.dodgeCooldown, () => {
            this.canDodge = true;
            if (this.player && this.player.active) {
                this.player.setTint(0xccddee);
                this.time.delayedCall(120, () => { if (this.player?.active) _restoreTint(this.player); });
            }
        });
    }

    triggerPerfectDodge() {
        if (this._perfectDodgeActive) return;
        this._perfectDodgeActive = true;
        this._nextShotBoosted = true;
        
        // Brief slow-mo effect (200ms at 30% speed)
        this.time.timeScale = 0.3;
        this.physics.world.timeScale = 3.3; // inverse to compensate
        
        // Visual: white edge flash
        const flash = this.add.rectangle(CONFIG.width/2, CONFIG.height/2, CONFIG.width, CONFIG.height, 0xffffff, 0.2)
            .setScrollFactor(0).setDepth(250);
        this.tweens.add({ targets: flash, alpha: 0, duration: 250, onComplete: () => flash.destroy() });
        
        // Shockwave ripple from player
        const ring = this.add.circle(this.player.x, this.player.y, 8, 0x000000, 0)
            .setStrokeStyle(2, 0xccddee, 0.6).setDepth(30);
        this.tweens.add({ targets: ring, scaleX: 8, scaleY: 8, alpha: 0, duration: 350, onComplete: () => ring.destroy() });
        const ring2 = this.add.circle(this.player.x, this.player.y, 5, 0x000000, 0)
            .setStrokeStyle(1.5, 0xffffff, 0.35).setDepth(30);
        this.tweens.add({ targets: ring2, scaleX: 12, scaleY: 12, alpha: 0, duration: 450, delay: 50, onComplete: () => ring2.destroy() });
        
        // "PERFECT" text
        const pt = this.add.text(CONFIG.width/2, CONFIG.height/2 - 40, 'PERFECT', {
            fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#eeeeff', fontStyle: 'bold',
            stroke: '#000000', strokeThickness: 3
        }).setOrigin(0.5).setScrollFactor(0).setDepth(251);
        this.tweens.add({ targets: pt, y: pt.y - 25, alpha: 0, duration: 600, onComplete: () => pt.destroy() });
        
        // Restore time after 200ms real time
        this.time.delayedCall(60, () => { // 60 * (1/0.3) ≈ 200ms real time
            this.time.timeScale = 1;
            this.physics.world.timeScale = 1;
            this._perfectDodgeActive = false;
        });
        
        // Boosted shot expires after 2 seconds if not used
        this.time.delayedCall(2000, () => { this._nextShotBoosted = false; });
    }

    damageEnemy(enemy, dmg, source = 'bullet', bullet = null) {
        if (!enemy || !enemy.active || enemy._dying) return;
        // Pass miss/crit source from bullet data
        if (bullet) {
            if (bullet.didMiss) { source = 'miss'; dmg = 0; }
            else if (bullet.isRedCrit) source = 'redcrit';
            else if (bullet.isCrit) source = 'crit';
        }
        // Power Surge defense upgrade — +30% player damage (not soldier/turret)
        if (this.modeState?.powerSurge && source !== 'soldier' && source !== 'soldier_splash' && source !== 'turret') {
            dmg = Math.round(dmg * 1.3);
        }
        CombatSystem.damageEnemy(this, enemy, dmg, source, this.player, this.state, this.state.equipment);
        if (enemy.hp <= 0 && !enemy.hasShield) this.killEnemy(enemy);
    }

    killEnemy(enemy) {
        EnemyManager.killEnemy(this, enemy, {
            onPreGore: (enemy, cfg) => {
                if (enemy.enemyType === 'boss' && this.modeState && this.modeState.bossEntity === enemy) {
                    this.bossHP.setVisible(false);
                    if (this.grimBossName) { this.grimBossName.destroy(); this.grimBossName = null; }
                    this.modeState.bossEntity = null;
                    for (let i = 0; i < 15; i++) {
                        const particle = this.add.circle(enemy.x + Phaser.Math.Between(-20, 20), enemy.y + Phaser.Math.Between(-20, 20), Phaser.Math.Between(3, 8), [0xff4444, 0xffaa44, 0xffcc66, 0xcc44ff][Phaser.Math.Between(0, 3)], 0.8).setDepth(30);
                        this.tweens.add({ targets: particle, alpha: 0, x: particle.x + Phaser.Math.Between(-60, 60), y: particle.y + Phaser.Math.Between(-60, 60), duration: 600 + Math.random() * 400, onComplete: () => particle.destroy() });
                    }
                    this.cameras.main.shake(500, 0.03);
                    this.cameras.main.flash(300, 255, 200, 100);
                    if (this.gameMode === 'defense' && this.modeState.hasBoss) {
                        this.showModeAnnouncement('BOSS DEFEATED', 'Clear the remaining hostiles!', true);
                        for (let d = 0; d < 2; d++) { this.spawnItemDrop(enemy.x + Phaser.Math.Between(-30, 30), enemy.y + Phaser.Math.Between(-30, 30), 'boss_high', this.destinationNode?.reach || 1); }
                    } else {
                        this.modeState.phase = 'complete';
                        const reach = this.modeState.reach || 1, bitsReward = 100 + reach * 40, matsReward = 10 + reach * 5;
                        this.state.bits += bitsReward; this.state.materials = (this.state.materials || 0) + matsReward; this.state.fuel = Math.min(100, this.state.fuel + 20);
                        const bossType = this.modeState.bossType, baneChance = CONFIG.baneDropChance || 0.04;
                        let baneDropped = false;
                        if (bossType && Math.random() < baneChance) {
                            const baneItem = ItemManager.generateBaneWeapon(bossType);
                            if (baneItem) {
                                baneDropped = true; const bx = enemy.x, by = enemy.y - 10;
                                this.cameras.main.shake(600, 0.025); this.cameras.main.flash(500, 136, 0, 255, true);
                                const bDrop = this.add.container(bx, by - 30).setDepth(50);
                                const pillar = this.add.rectangle(bx, by, 6, 120, 0x8800ff, 0.4).setDepth(49);
                                this.tweens.add({ targets: pillar, alpha: 0, scaleX: 8, duration: 1200, onComplete: () => pillar.destroy() });
                                for (let i = 0; i < 8; i++) { const pa = (Math.PI * 2 / 8) * i; const pp = this.add.circle(bx + Math.cos(pa) * 40, by + Math.sin(pa) * 40, 3, 0xaa44ff, 0.8).setDepth(50); this.tweens.add({ targets: pp, x: bx, y: by, alpha: 0.2, duration: 800, delay: i * 100, onComplete: () => pp.destroy() }); }
                                const baneGlow = this.add.circle(0, 0, 22, 0x8800ff, 0.3); this.tweens.add({ targets: baneGlow, scaleX: 1.5, scaleY: 1.5, alpha: 0.1, duration: 800, yoyo: true, repeat: -1 }); bDrop.add(baneGlow);
                                bDrop.add(this.add.rectangle(0, 0, 22, 22, 0x8800ff, 0.9).setAngle(45)); bDrop.add(this.add.rectangle(0, 0, 16, 16, 0xaa44ff, 0.7).setAngle(45));
                                bDrop.add(this.add.text(0, -1, baneItem.icon, { fontSize: uiPx(12), fill: '#ffffff' }).setOrigin(0.5));
                                bDrop.itemData = baneItem; this.physics.add.existing(bDrop); bDrop.body.setSize(30, 30).setOffset(-15, -15);
                                if (!this.lootDrops) this.lootDrops = []; this.lootDrops.push(bDrop);
                                this.physics.add.overlap(this.player, bDrop, () => this.collectLoot(bDrop));
                                this.tweens.add({ targets: bDrop, y: by, duration: 600, ease: 'Bounce.easeOut' });
                                this.showModeAnnouncement('BANE WEAPON', baneItem.name + ' has dropped!');
                                this.time.delayedCall(2500, () => { this.showModeAnnouncement('BOSS DEFEATED', '+' + bitsReward + ' bits  +' + matsReward + ' materials'); });
                            }
                        }
                        for (let d = 0; d < 3; d++) { this.spawnItemDrop(enemy.x + Phaser.Math.Between(-30, 30), enemy.y + Phaser.Math.Between(-30, 30), reach >= 5 ? 'boss_high' : 'boss', reach); }
                        const bossReachMult = CONFIG.reachCurrencyMult[Math.min(reach, 8)] || 1.0;
                        for (let d = 0; d < 5; d++) { this.spawnLootDrop(enemy.x + Phaser.Math.Between(-40, 40), enemy.y + Phaser.Math.Between(-40, 40), bossReachMult); }
                        if (!baneDropped) this.showModeAnnouncement('BOSS DEFEATED', '+' + bitsReward + ' bits  +' + matsReward + ' materials');
                        this.time.delayedCall(2000, () => { this.gameMode = 'freeRoam'; this.showModeAnnouncement('LOOT THE AREA', 'Collect your spoils.', true); this.time.addEvent({ delay: 15000, callback: () => this.spawnWave(1), loop: true }); });
                    }
                } else if (cfg && cfg.isBoss) { this.bossHP.setVisible(false); if (this.grimBossName) { this.grimBossName.destroy(); this.grimBossName = null; } }
            },
            onPostKill: (ex, ey, cfg) => { this.tryDropLoot(ex, ey, cfg.isBoss, enemy.enemyType); }
        });
    }
    
    tryDropLoot(x, y, isBoss = false, enemyType = null) {
        // Lucky Ducky: +50% currency drops
        const hasLuckyDucky = (this.state.equipment?.weapon?.augment?.relicAbility === 'luckyDucky') ||
                              (this.state.equipment?.melee?.augment?.relicAbility === 'luckyDucky');
        const currencyMult = hasLuckyDucky ? 1.5 : 1;
        
        // Reach-based scaling
        const reach = this.destinationNode?.reach || 1;
        const reachCurrMult = CONFIG.reachCurrencyMult[Math.min(reach, 8)] || 1.0;
        const biomeDropMult = this.biome?.enemyDropMult || 1.0;
        const itemDropChance = (CONFIG.reachDropChance[Math.min(reach, 8)] || 0.12) * (this.lootMultiplier || 1.0) * biomeDropMult;
        
        // Currency drops: normal enemies 60%, boss 100% (multiple)
        let dropCount = isBoss ? Phaser.Math.Between(3, 5) : (Math.random() < 0.6 ? 1 : 0);
        dropCount = Math.round(dropCount * currencyMult);
        
        for (let i = 0; i < dropCount; i++) {
            const offsetX = isBoss ? Phaser.Math.Between(-30, 30) : 0;
            const offsetY = isBoss ? Phaser.Math.Between(-30, 30) : 0;
            
            this.time.delayedCall(i * 100, () => {
                this.spawnLootDrop(x + offsetX, y + offsetY, reachCurrMult);
            });
        }
        
        // Tangible item drops: reach-scaled chance, boss always drops
        const itemCount = isBoss ? Phaser.Math.Between(1, 2) : (Math.random() < itemDropChance ? 1 : 0);
        // Use enemy-specific loot table if available, else reach-based generic
        const enemyCfg = enemyType ? CONFIG.enemyTypes[enemyType] : null;
        const tableName = isBoss ? (reach >= 5 ? 'boss_high' : 'boss') :
                          (enemyCfg?.lootTable || ItemManager.getEnemyTable(reach));
        for (let i = 0; i < itemCount; i++) {
            const ox = Phaser.Math.Between(-20, 20);
            const oy = Phaser.Math.Between(-15, 15);
            this.time.delayedCall(200 + i * 150, () => {
                this.spawnItemDrop(x + ox, y + oy, tableName, reach);
            });
        }
    }
    
    spawnLootDrop(x, y, reachMult = 1.0) {
        // In defense mode, push loot away from caravan so it's not buried under the truck
        if (this.gameMode === 'defense' && this.modeState && this.modeState.phase !== 'complete') {
            const cx = CONFIG.world.width / 2, cy = CONFIG.world.height / 2;
            const distToCaravan = Phaser.Math.Distance.Between(x, y, cx, cy);
            if (distToCaravan < 70) {
                // Push outward from caravan center
                const angle = Phaser.Math.Angle.Between(cx, cy, x, y) || (Math.random() * Math.PI * 2);
                x = cx + Math.cos(angle) * (75 + Math.random() * 25);
                y = cy + Math.sin(angle) * (75 + Math.random() * 25);
            }
        }
        // Currency loot table — amounts scaled by reach
        const lootTable = [
            { type: 'ammo', chance: 0.35, color: 0xddaa44, icon: '▪', min: 2, max: 5 },
            { type: 'health', chance: 0.22, color: 0x44dd44, icon: '+', min: 5, max: 12 },
            { type: 'bits', chance: 0.25, color: 0xaaccee, icon: '◈', min: 1, max: 3 },
            { type: 'fuel', chance: 0.06, color: 0xdd8844, icon: '⛽', min: 2, max: 5 },
            { type: 'nothing', chance: 0.12 }
        ];
        
        // Roll for loot
        let roll = Math.random();
        let selectedLoot = null;
        
        for (const loot of lootTable) {
            if (roll < loot.chance) {
                selectedLoot = loot;
                break;
            }
            roll -= loot.chance;
        }
        
        if (!selectedLoot || selectedLoot.type === 'nothing') return;
        
        // Create ground loot object
        const lootDrop = this.add.container(x, y).setDepth(15);
        
        // Small glowing diamond
        const glow = this.add.rectangle(0, 0, 10, 10, selectedLoot.color, 0.3);
        glow.setAngle(45);
        lootDrop.add(glow);
        
        // Inner gem
        const cube = this.add.rectangle(0, 0, 7, 7, selectedLoot.color, 0.85);
        cube.setAngle(45);
        lootDrop.add(cube);
        
        // Icon
        const icon = this.add.text(0, 0, selectedLoot.icon, { 
            fontSize: uiPx(7), 
            fill: '#ffffff', 
            fontStyle: 'bold' 
        }).setOrigin(0.5);
        lootDrop.add(icon);
        
        // Store loot data
        lootDrop.lootType = selectedLoot.type;
        lootDrop.lootAmount = Math.round(Phaser.Math.Between(selectedLoot.min, selectedLoot.max) * reachMult);
        lootDrop.lootColor = selectedLoot.color;
        
        // Spawn animation - pop up
        lootDrop.setScale(0);
        this.tweens.add({
            targets: lootDrop,
            scale: 1,
            duration: 200,
            ease: 'Back.out'
        });
        
        // Gentle float animation
        this.tweens.add({
            targets: lootDrop,
            y: y - 3,
            duration: 800,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.inOut'
        });
        
        // Glow pulse
        this.tweens.add({
            targets: glow,
            alpha: 0.5,
            scale: 1.2,
            duration: 600,
            yoyo: true,
            repeat: -1
        });
        
        // Add to loot drops array
        if (!this.lootDrops) this.lootDrops = [];
        this.lootDrops.push(lootDrop);
        
        // Auto-despawn after 30 seconds
        this.time.delayedCall(30000, () => {
            if (lootDrop.active) {
                this.tweens.add({
                    targets: lootDrop,
                    alpha: 0,
                    scale: 0,
                    duration: 300,
                    onComplete: () => {
                        const idx = this.lootDrops.indexOf(lootDrop);
                        if (idx > -1) this.lootDrops.splice(idx, 1);
                        lootDrop.destroy();
                    }
                });
            }
        });
    }
    
    checkLootPickup() {
        if (!this.lootDrops) return;
        
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        const pickupDist = 30 + (eqStats.pickupRange || 0);
        
        for (let i = this.lootDrops.length - 1; i >= 0; i--) {
            const loot = this.lootDrops[i];
            if (!loot.active) continue;
            
            const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, loot.x, loot.y);
            if (dist < pickupDist) {
                this.collectLootDrop(loot, i);
            }
        }
    }
    
    collectLootDrop(loot, index) {
        let message = '';
        AudioManager.pickup();
        Haptics.light();
        EventBus.emit('lootPickup', { scene: this, type: loot.lootType, amount: loot.lootAmount });
        
        switch (loot.lootType) {
            case 'ammo':
                this.state.powerAmmo = (this.state.powerAmmo || 0) + loot.lootAmount;
                message = `+${loot.lootAmount} POWER AMMO`;
                // Supply crate bonus: also heals
                if (loot._bonusHealth) {
                    const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(this.state.equipment).maxHealth || 0);
                    this.state.health = Math.min(maxHp, this.state.health + loot._bonusHealth);
                    message += ` +${loot._bonusHealth} HP`;
                }
                break;
            case 'health':
                const maxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(this.state.equipment).maxHealth || 0);
                this.state.health = Math.min(maxHp, this.state.health + loot.lootAmount);
                AudioManager.heal();
                message = `+${loot.lootAmount} HP`;
                break;
            case 'bits':
                this.state.bits += loot.lootAmount;
                message = `+${loot.lootAmount} BITS`;
                break;
            case 'fuel':
                this.state.fuel = Math.min(100, (this.state.fuel || 0) + loot.lootAmount);
                message = `+${loot.lootAmount} FUEL`;
                break;
        }
        
        // Braveheart: currency pickups also restore health
        if (loot.lootType !== 'health') {
            const braveheart = (ItemManager.getEquipmentStats(this.state.equipment).signatures || []).find(s => s.effect === 'braveheart');
            if (braveheart) {
                const bhMaxHp = CONFIG.player.health + (ItemManager.getEquipmentStats(this.state.equipment).maxHealth || 0);
                const bhHeal = Math.min(3, bhMaxHp - this.state.health);
                if (bhHeal > 0) {
                    this.state.health += bhHeal;
                    message += ` +${bhHeal} HP`;
                }
            }
        }
        
        // Pickup effect - cubes fly to player
        for (let i = 0; i < 4; i++) {
            const cube = this.add.rectangle(loot.x, loot.y, 6, 6, loot.lootColor);
            cube.setAngle(Phaser.Math.Between(0, 45)).setDepth(25);
            
            this.tweens.add({
                targets: cube,
                x: this.player.x,
                y: this.player.y,
                scale: 0.3,
                alpha: 0,
                angle: cube.angle + Phaser.Math.Between(-90, 90),
                duration: 200 + i * 50,
                ease: 'Power2',
                onComplete: () => cube.destroy()
            });
        }
        
        // Popup text — stagger Y for rapid pickups
        const now = this.time.now;
        if (!this._lastLootTextTime || now - this._lastLootTextTime > 600) {
            this._lootTextOffset = 0;
        } else {
            this._lootTextOffset = (this._lootTextOffset || 0) + 14;
        }
        this._lastLootTextTime = now;
        const txtY = loot.y - 10 - (this._lootTextOffset || 0);
        const txt = this.add.text(loot.x, txtY, message, { 
            fontFamily: CONFIG.font, fontSize: uiPx(10), 
            fill: '#' + loot.lootColor.toString(16).padStart(6, '0'), 
            fontStyle: 'bold' 
        }).setOrigin(0.5).setDepth(100);
        
        this.tweens.add({ 
            targets: txt, 
            y: txtY - 28, 
            alpha: 0, 
            duration: 500, 
            onComplete: () => txt.destroy() 
        });
        
        // Remove from array and destroy
        this.lootDrops.splice(index, 1);
        loot.destroy();
    }
    
    // === PHASE 2B: TANGIBLE ITEM DROPS ===
    
    spawnItemDrop(x, y, tableName = 'normal', reach = 1) {
        // In defense mode, push drops away from caravan
        if (this.gameMode === 'defense' && this.modeState && this.modeState.phase !== 'complete') {
            const cx = CONFIG.world.width / 2, cy = CONFIG.world.height / 2;
            const distToCaravan = Phaser.Math.Distance.Between(x, y, cx, cy);
            if (distToCaravan < 70) {
                const angle = Phaser.Math.Angle.Between(cx, cy, x, y) || (Math.random() * Math.PI * 2);
                x = cx + Math.cos(angle) * (80 + Math.random() * 30);
                y = cy + Math.sin(angle) * (80 + Math.random() * 30);
            }
        }
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        const baseLuck = eqStats.lootLuck || 0;
        const luckBonus = baseLuck + ((this._todLoot || 1.0) - 1.0) * 10; // Convert multiplier to luck bonus
        const locMods = this.locationType ? CONFIG.locations[this.locationType]?.lootModifiers : null;
        const result = ItemManager.rollLootTable(tableName, luckBonus, reach, this.state.equipment, locMods);
        if (!result) return;
        
        // Resolve item — result is either a string (static ID) or object (procedural)
        let item, color, glow;
        if (typeof result === 'string') {
            item = ItemManager.createItem(result);
            if (!item) return;
        } else {
            item = result;
        }
        color = ItemManager.getItemColor(item);
        glow = ItemManager.getItemGlow(item);
        
        const drop = this.add.container(x, y).setDepth(16);
        
        // === ACTUAL PIXEL SPRITE instead of icon cube ===
        const spriteContainer = this.add.container(0, 0);
        ItemManager.drawItemPixelArt(this, spriteContainer, 0, -2, item, 1.0, 0);
        drop.add(spriteContainer);
        
        // Rarity glow surrounding sprite — ellipse that pulses
        const glowEllipse = this.add.ellipse(0, 0, 24, 20, glow, 0.15);
        drop.add(glowEllipse);
        drop.sendToBack(glowEllipse);
        
        // Data
        drop.itemData = item;
        drop.rarityColor = color;
        drop.rarityGlow = glow;
        
        // Floor shadow
        const isInterior = !!this.locationType;
        DynamicShadows.add(this, drop, { offsetY: 4, scale: 0.3, alpha: 0.10, interior: isInterior });
        
        // === LOOT BEAM — pulsing vertical line, size by rarity ===
        const itemTier = item.tier || 1;
        const beamCfg = CONFIG.lootBeamConfig[Math.min(itemTier, 6)] || CONFIG.lootBeamConfig[1];
        if (beamCfg.height > 0) {
            const beamX = 0, beamBaseY = -4;
            // Main beam shaft
            const beam = this.add.rectangle(beamX, beamBaseY - beamCfg.height / 2, 
                2, beamCfg.height, beamCfg.color, 0.35);
            drop.add(beam);
            drop.sendToBack(beam);
            // Beam glow (wider, more transparent)
            const beamGlow = this.add.rectangle(beamX, beamBaseY - beamCfg.height / 2,
                6 + itemTier, beamCfg.height, beamCfg.color, 0.08);
            drop.add(beamGlow);
            drop.sendToBack(beamGlow);
            // Pulsing animation — alpha + width oscillation
            this.tweens.add({
                targets: beam,
                alpha: { from: 0.35, to: 0.12 },
                scaleX: { from: 1.0, to: 0.5 },
                duration: 700 + itemTier * 80,
                yoyo: true, repeat: -1, ease: 'Sine.inOut'
            });
            this.tweens.add({
                targets: beamGlow,
                alpha: { from: 0.08, to: 0.2 },
                scaleX: { from: 1.0, to: 1.6 },
                duration: 700 + itemTier * 80,
                yoyo: true, repeat: -1, ease: 'Sine.inOut'
            });
            // Rising particles along beam
            if (beamCfg.particles > 0) {
                this.time.addEvent({
                    delay: Math.max(150, 600 - itemTier * 80), loop: true, callback: () => {
                        if (!drop.active) return;
                        const px = drop.x + Phaser.Math.Between(-4, 4);
                        const py = drop.y - Phaser.Math.Between(0, 10);
                        const particle = this.add.rectangle(px, py, 
                            Phaser.Math.Between(1, 2 + Math.floor(itemTier / 2)),
                            Phaser.Math.Between(1, 2 + Math.floor(itemTier / 2)),
                            beamCfg.color, 0.6 + Math.random() * 0.3
                        ).setDepth(drop.depth + 0.01).setAngle(45);
                        this.tweens.add({
                            targets: particle,
                            y: particle.y - beamCfg.height * 0.8,
                            alpha: 0, scale: 0.3,
                            duration: 600 + Math.random() * 400,
                            onComplete: () => particle.destroy()
                        });
                    }
                });
            }
            // Ground glow ring
            const groundGlow = this.add.ellipse(0, 8, 20 + itemTier * 4, 10 + itemTier * 2, beamCfg.color, 0.12);
            drop.add(groundGlow);
            drop.sendToBack(groundGlow);
            this.tweens.add({
                targets: groundGlow, scaleX: 1.3, scaleY: 1.3, alpha: 0.04,
                duration: 900, yoyo: true, repeat: -1
            });
        }
        
        // Spawn pop
        drop.setScale(0);
        this.tweens.add({ targets: drop, scale: 1, duration: 300, ease: 'Back.out' });
        
        // Float
        this.tweens.add({
            targets: drop, y: y - 6,
            duration: 900, yoyo: true, repeat: -1,
            ease: 'Sine.inOut', delay: 300
        });
        
        // Glow pulse around sprite
        this.tweens.add({
            targets: glowEllipse, alpha: 0.35, scaleX: 1.4, scaleY: 1.4,
            duration: 700, yoyo: true, repeat: -1
        });
        
        this.itemDrops.push(drop);
        
        // Despawn after 45s
        this.time.delayedCall(45000, () => {
            if (drop.active) {
                this.tweens.add({
                    targets: drop, alpha: 0, scale: 0, duration: 400,
                    onComplete: () => {
                        const idx = this.itemDrops.indexOf(drop);
                        if (idx > -1) this.itemDrops.splice(idx, 1);
                        drop.destroy();
                    }
                });
            }
        });
        
        // === LORE CHIP DROP — small chance alongside regular loot ===
        const loreChance = tableName.includes('boss') ? 0.35 : 0.06;
        if (Math.random() < loreChance) {
            const chipId = StatTracker.getRandomUndiscoveredChip();
            if (chipId) {
                const chipDef = CONFIG.loreChips[chipId];
                const seriesDef = CONFIG.loreSeries[chipDef.series];
                const chipColor = Phaser.Display.Color.HexStringToColor(seriesDef.color).color;
                
                const cx = x + Phaser.Math.Between(-15, 15);
                const cy = y + Phaser.Math.Between(-15, 15);
                
                const chipDrop = this.add.container(cx, cy).setDepth(17);
                chipDrop.add(this.add.rectangle(0, 0, 12, 8, chipColor, 0.9).setStrokeStyle(1, 0xffffff, 0.5));
                chipDrop.add(this.add.text(0, 0, 'DATA', { fontSize: uiPx(6), fill: '#4488cc' }).setOrigin(0.5));
                
                // Pulse glow
                const chipGlow = this.add.rectangle(cx, cy, 16, 12, chipColor, 0.15).setDepth(16.5);
                this.tweens.add({ targets: chipGlow, alpha: { from: 0.1, to: 0.3 }, scaleX: { from: 1, to: 1.3 }, scaleY: { from: 1, to: 1.3 }, duration: 500, yoyo: true, repeat: -1 });
                
                chipDrop.chipId = chipId;
                chipDrop.chipDef = chipDef;
                chipDrop.chipGlow = chipGlow;
                
                // Auto-pickup on proximity
                this.time.addEvent({
                    delay: 100, loop: true, callback: () => {
                        if (!chipDrop.active || !this.player || !this.player.active) return;
                        const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, cx, cy);
                        if (dist < 30) {
                            const isNew = StatTracker.addLoreChip(chipId);
                            if (this._runStats) this._runStats.loreChipsFound.push(chipId);
                            
                            // Pickup feedback
                            const rarityColors = { common: '#888888', uncommon: '#44aa44', rare: '#4488ff', legendary: '#ffaa22' };
                            const rc = rarityColors[chipDef.rarity] || '#888888';
                            const msg = isNew ? `NEW CHIP: ${chipDef.title}` : `CHIP: ${chipDef.title} (duplicate)`;
                            const txt = this.add.text(this.player.x, this.player.y - 35, msg, {
                                fontFamily: 'monospace', fontSize: uiPx(9), fill: rc, fontStyle: 'bold'
                            }).setOrigin(0.5).setDepth(100);
                            this.tweens.add({ targets: txt, y: txt.y - 30, alpha: 0, duration: 1500, onComplete: () => txt.destroy() });
                            
                            chipGlow.destroy();
                            chipDrop.destroy();
                        }
                    }
                });
            }
        }
    }
    
    checkItemPickup() {
        if (!this.itemDrops || this.itemDrops.length === 0) {
            if (this.nearestItemDrop) this._hideProximityCard();
            this.nearestItemDrop = null;
            return;
        }
        
        // Hide card when other popups are open (but not our own inspect card)
        if (this.popupActive && !this._dropInspectOpen) {
            if (this._proximityCard) this._hideProximityCard();
            return;
        }
        // While inspect card is open, keep tag visible but skip nearest-swap logic
        if (this._dropInspectOpen) return;
        
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        const detectDist = 45 + (eqStats.pickupRange || 0);
        
        let nearest = null;
        let nearDist = detectDist;
        for (const drop of this.itemDrops) {
            if (!drop.active) continue;
            const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, drop.x, drop.y);
            if (d < nearDist) { nearDist = d; nearest = drop; }
        }
        
        // Hysteresis: only swap if new nearest is 8px closer or current left range
        if (this.nearestItemDrop && this.nearestItemDrop.active && nearest !== this.nearestItemDrop) {
            const currentDist = Phaser.Math.Distance.Between(
                this.player.x, this.player.y, this.nearestItemDrop.x, this.nearestItemDrop.y
            );
            if (currentDist < detectDist && (!nearest || nearDist > currentDist - 8)) {
                nearest = this.nearestItemDrop; // keep current
            }
        }
        
        // Show/hide proximity card when nearest drop changes
        if (nearest !== this.nearestItemDrop) {
            this._hideProximityCard();
            this.nearestItemDrop = nearest;
            if (nearest && !this.popupActive) {
                this._showProximityCard(nearest);
            }
        }
        
        // Per-frame tag position sync — follows drop bob animation
        if (this._proximityCard && this._proximityCardDrop && this._proximityCardDrop.active) {
            const tag = this._proximityCard[0];
            if (tag && tag.active) {
                tag.x = this._proximityCardDrop.x;
                tag.y = this._proximityCardDrop.y - 26;
            }
        }
    }
    
    _showProximityCard(drop) {
        if (!drop || !drop.itemData) return;
        this._hideProximityCard();
        
        const item = drop.itemData;
        const color = ItemManager.getItemColor(item);
        const colorHex = '#' + color.toString(16).padStart(6, '0');
        
        // Build name string
        let nameText = item.name;
        if (item.enhanceLevel >= 1) nameText += ` +${item.enhanceLevel}`;
        
        // Measure name to size the tag dynamically
        const measureText = this.add.text(0, 0, nameText, {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fontStyle: 'bold'
        }).setVisible(false);
        const nameW = measureText.width;
        measureText.destroy();
        
        const tagW = Math.max(70, nameW + 32);
        const tagH = 24;
        
        // World-space container — positioned above the drop
        const tag = this.add.container(drop.x, drop.y - 26).setDepth(500);
        this._proximityCard = [tag];
        this._proximityCardDrop = drop;
        
        // Tag background
        const bg = this.add.rectangle(0, 0, tagW, tagH, 0x0c0c1a, 0.92)
            .setStrokeStyle(1, color, 0.5);
        tag.add(bg);
        
        // Rarity accent line at top
        tag.add(this.add.rectangle(0, -tagH/2 + 1, tagW - 2, 2, color, 0.7));
        
        // Item sprite (left side)
        const spriteX = -tagW/2 + 14;
        const spriteC = this.add.container(spriteX, -2);
        ItemManager.drawItemPixelArt(this, spriteC, 0, 0, item, 1.4, 0);
        tag.add(spriteC);
        
        // Stack count badge
        if (item.stackCount && item.stackCount >= 1) {
            tag.add(this.add.text(spriteX + 8, 6, `×${item.stackCount}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#ffffff', fontStyle: 'bold'
            }).setOrigin(0.5));
        }
        
        // Item name (right of sprite)
        const nameLabel = this.add.text(spriteX + 14, -2, nameText, {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: colorHex, fontStyle: 'bold',
            wordWrap: { width: tagW - 36 }
        }).setOrigin(0, 0);
        tag.add(nameLabel);
        
        // Interactive hit zone — covers entire tag
        bg.setInteractive({ useHandCursor: true });
        let holdTimer = null, didHold = false;
        bg.on('pointerdown', () => {
            didHold = false;
            holdTimer = this.time.delayedCall(400, () => {
                didHold = true;
                holdTimer = null;
                Haptics.light();
                this._showDropInspectCard(item);
            });
        });
        bg.on('pointerup', () => {
            if (holdTimer) { holdTimer.remove(); holdTimer = null; }
            if (!didHold) {
                this.pickupItemDrop();
            }
        });
        bg.on('pointerout', () => {
            if (holdTimer) { holdTimer.remove(); holdTimer = null; }
        });
        
        // Pop-in animation
        tag.setScale(0);
        this.tweens.add({ targets: tag, scale: 1, duration: 200, ease: 'Back.out' });
    }
    
    _showDropInspectCard(item) {
        // Full item card — same as safehouse hold-to-inspect, with compare
        this._closeDropInspectCard();
        this._dropInspectOpen = true; // Dedicated flag so checkItemPickup doesn't self-destruct
        this.popupActive = true; // Block other interactions while card is open
        const W = CONFIG.width, H = CONFIG.height, D = 700;
        this._dropInspectCard = [];
        const add = (obj) => { this._dropInspectCard.push(obj); return obj; };
        
        // Dim overlay — tap to dismiss
        const ov = add(this.add.rectangle(W/2, H/2, W, H, 0x000000, 0.7).setDepth(D).setScrollFactor(0));
        ov.setInteractive();
        ov.on('pointerdown', () => this._closeDropInspectCard());
        
        InteractHighlight.hide(this);
        
        const cardW = W - 40, cx = W / 2;
        const cardH = InventoryUI.calcCardHeight(item);
        const cy = H / 2;
        UIAtlas.build(this);
        const F = UIAtlas.FRAME;
        add(this.add.nineslice(cx, cy, 'ui_panel', null, cardW, cardH, F, F, F, F).setDepth(D+1).setScrollFactor(0));
        InventoryUI.renderItemCard(this, item, add, cx, cy, cardW, cardH, D, { interactive: false });
        
        // Compare bar — show currently equipped item of same slot
        const eqSlotMap = { weapon: 'weapon', melee: 'melee', gear: 'gear', consumable: 'consumable' };
        const eqSlot = eqSlotMap[item.category];
        if (eqSlot && this.state.equipment && this.state.equipment[eqSlot]) {
            const equipped = this.state.equipment[eqSlot];
            const eqColor = ItemManager.getItemColor(equipped);
            const eqHex = '#' + eqColor.toString(16).padStart(6, '0');
            const cmpY = cy + cardH / 2 + 16;
            const cmpH = 24;
            add(this.add.rectangle(cx, cmpY, cardW, cmpH, 0x0a0a16, 0.95)
                .setStrokeStyle(0.5, eqColor, 0.4).setDepth(D+1).setScrollFactor(0));
            let cmpText = `EQUIPPED: ${equipped.name}`;
            if ((item.category === 'weapon' || item.category === 'melee') && equipped.damage) cmpText += ` (DMG ${equipped.damage})`;
            else if (item.category === 'gear' && equipped.armor) cmpText += ` (DEF ${equipped.armor})`;
            add(this.add.text(cx, cmpY, cmpText, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: eqHex
            }).setOrigin(0.5).setDepth(D+2).setScrollFactor(0));
        }
    }
    
    _closeDropInspectCard() {
        if (this._dropInspectCard) {
            this._dropInspectCard.forEach(obj => { if (obj && obj.destroy) obj.destroy(); });
            this._dropInspectCard = null;
            this._dropInspectOpen = false;
            this.popupActive = false; // Restore interactions
        }
    }
    
    _hideProximityCard() {
        if (this._proximityCard) {
            this._proximityCard.forEach(obj => { if (obj && obj.destroy) obj.destroy(); });
            this._proximityCard = null;
        }
        this._proximityCardDrop = null;
        this._closeDropInspectCard();
    }
    
    pickupItemDrop() {
        if (!this.nearestItemDrop || !this.nearestItemDrop.active) return;
        const drop = this.nearestItemDrop;
        const item = drop.itemData;
        
        // Auto-use currency_grant key items — convert directly to resources on pickup
        if (item.category === 'key_item' && item.subtype === 'currency_grant') {
            let bits = 0, mats = 0, ammo = 0;
            
            // Format B: fixed grantBits/grantMats (husk/flicker items)
            if (item.grantBits) bits = item.grantBits;
            if (item.grantMats) mats = item.grantMats;
            
            // Format A: useAction with random range (purse, wallet, scrap_box, ammo_box)
            if (item.useAction && item.grantMin != null && item.grantMax != null) {
                const amount = item.grantMin + Math.floor(Math.random() * (item.grantMax - item.grantMin + 1));
                if (item.useAction === 'grant_bits') bits = amount;
                else if (item.useAction === 'grant_materials') mats = amount;
                else if (item.useAction === 'grant_powerAmmo') ammo = amount;
            }
            
            if (bits) this.state.bits = (this.state.bits || 0) + bits;
            if (mats) this.state.materials = (this.state.materials || 0) + mats;
            if (ammo) this.state.powerAmmo = (this.state.powerAmmo || 0) + ammo;
            
            AudioManager.pickup(); Haptics.light();
            // Floating gain text
            let gainText = '';
            if (bits) gainText += `+${bits} bits`;
            if (mats) gainText += (gainText ? '  ' : '') + `+${mats} mats`;
            if (ammo) gainText += (gainText ? '  ' : '') + `+${ammo} ammo`;
            if (!gainText) gainText = item.name; // fallback
            const txt = this.add.text(drop.x, drop.y - 12, gainText, {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#ffcc44', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(100);
            this.tweens.add({ targets: txt, y: drop.y - 40, alpha: 0, duration: 700, onComplete: () => txt.destroy() });
            // Pickup particles
            for (let i = 0; i < 3; i++) {
                const c = this.add.rectangle(drop.x, drop.y, 4, 4, 0xffcc44).setDepth(26);
                this.tweens.add({ targets: c, x: this.player.x, y: this.player.y, scale: 0.2, alpha: 0, duration: 250 + i * 40, ease: 'Power2', onComplete: () => c.destroy() });
            }
            const idx = this.itemDrops.indexOf(drop);
            if (idx > -1) this.itemDrops.splice(idx, 1);
            drop.destroy();
            this._hideProximityCard();
            this.nearestItemDrop = null;
            if (this._runStats) this._runStats.itemsLooted++;
            return;
        }
        
        // Check backpack space — stackable items can merge into existing stacks
        const canStack = ItemManager.isStackable(item) && ItemManager.findExistingStack(this.state.backpack, item) !== -1;
        if (!canStack && !ItemManager.hasSpace(this.state.backpack)) {
            const txt = this.add.text(this.player.x, this.player.y - 30, 'BACKPACK FULL!', {
                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#ff4444', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(100);
            this.tweens.add({ targets: txt, y: this.player.y - 55, alpha: 0, duration: 800, onComplete: () => txt.destroy() });
            return;
        }
        
        // Add item directly to backpack
        ItemManager.addItem(this.state.backpack, item);
        const tier = item.tier || 1;
        if (tier >= 4) { AudioManager.pickupRare(); Haptics.success(); }
        else { AudioManager.pickup(); Haptics.light(); }
        
        // Track stats
        if (this._runStats) {
            this._runStats.itemsLooted++;
            if (item.flair) this._runStats.flairWeaponsFound++;
            if (item.isBane) this._runStats.baneWeaponsFound++;
            if (item.baseId === 'cube') this._runStats.cubesCollected++;
            if (tier >= 3) this._runStats.rareFinds++; // rare tier or better
        }
        
        // Update backpack sprite
        if (this.player.backpack) {
            SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
        }
        
        // Pickup effect — cubes fly to player
        for (let i = 0; i < 5; i++) {
            const c = this.add.rectangle(drop.x, drop.y, 5, 5, drop.rarityColor);
            c.setAngle(Phaser.Math.Between(0, 45)).setDepth(26);
            this.tweens.add({
                targets: c, x: this.player.x, y: this.player.y,
                scale: 0.2, alpha: 0,
                angle: c.angle + Phaser.Math.Between(-120, 120),
                duration: 250 + i * 40, ease: 'Power2',
                onComplete: () => c.destroy()
            });
        }
        
        // Popup with item name — stagger Y to prevent overlap with recent pickups
        const colorHex = '#' + drop.rarityColor.toString(16).padStart(6, '0');
        const tierTag = item.tierLabel ? `[${item.tierLabel}] ` : '';
        const now = this.time.now;
        if (!this._lastPickupTextTime || now - this._lastPickupTextTime > 800) {
            this._pickupTextOffset = 0;
        } else {
            this._pickupTextOffset = (this._pickupTextOffset || 0) + 16;
        }
        this._lastPickupTextTime = now;
        const txtY = drop.y - 12 - (this._pickupTextOffset || 0);
        const txt = this.add.text(drop.x, txtY, `${tierTag}${item.name}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: colorHex, fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(100);
        this.tweens.add({ targets: txt, y: txtY - 28, alpha: 0, duration: 600, onComplete: () => txt.destroy() });
        
        // Remove
        const idx = this.itemDrops.indexOf(drop);
        if (idx > -1) this.itemDrops.splice(idx, 1);
        drop.destroy();
        this._hideProximityCard();
        this.nearestItemDrop = null;
        this.updateConsumableButton();
    }

    enemyHitPlayer(enemy) {
        EnemyManager.enemyHitPlayer(this, enemy, {
            todDamage: this._todDamage || 1.0, defDodge: this._defDodge || 0,
            onDeath: (dmg, eqStats) => {
                const lastStand = eqStats.signatures?.find(s => s.effect === 'lastStand');
                if (lastStand && !this._lastStandUsed) {
                    this._lastStandUsed = true; this.state.health = 1;
                    this.cameras.main.flash(300, 255, 50, 50);
                    const ls = this.add.text(this.player.x, this.player.y - 30, 'LAST STAND', { fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#ff2244', fontStyle: 'bold' }).setOrigin(0.5);
                    this.tweens.add({ targets: ls, y: ls.y - 30, alpha: 0, duration: 1200, onComplete: () => ls.destroy() });
                    this.isInvincible = true; this.time.delayedCall(1500, () => this.isInvincible = false);
                    return;
                }
                this.die();
            }
        });
    }

    die() {
        if (this.state.dead) return;
        
        // ── MARK DEATH PREVENTION: Twice Born / The Following ──
        const _conds = this.state.survivorMods?.conditionals;
        if (_conds) {
            // Twice Born: survive killing blow at 1HP once per run
            if (_conds.twiceBorn && !this.state._twiceBornUsed) {
                this.state._twiceBornUsed = true;
                this.state.health = 1;
                this.cameras.main.flash(400, 100, 255, 100);
                const tb = this.add.text(this.player.x, this.player.y - 30, 'TWICE BORN', {
                    fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#44ff88', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(200);
                this.tweens.add({ targets: tb, y: tb.y - 35, alpha: 0, duration: 1500, onComplete: () => tb.destroy() });
                this.isInvincible = true;
                this.time.delayedCall(2000, () => this.isInvincible = false);
                return;
            }
            // The Following: cube-twisted auto-dodge killing blow once per run
            if (_conds.theFollowingActive && !this.state._theFollowingUsed) {
                this.state._theFollowingUsed = true;
                this.state.health = 1;
                this.cameras.main.flash(400, 140, 60, 200);
                const tf = this.add.text(this.player.x, this.player.y - 30, 'THE FOLLOWING', {
                    fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#aa44cc', fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(200);
                this.tweens.add({ targets: tf, y: tf.y - 35, alpha: 0, duration: 1500, onComplete: () => tf.destroy() });
                this.isInvincible = true;
                this.time.delayedCall(2000, () => this.isInvincible = false);
                // Cube visual: brief purple distortion ring
                const ring = this.add.circle(this.player.x, this.player.y, 8, 0x8844aa, 0.4).setDepth(199);
                this.tweens.add({ targets: ring, scale: 5, alpha: 0, duration: 600, onComplete: () => ring.destroy() });
                return;
            }
        }
        
        this.state.dead = true;
        this.state.health = 0;
        this._hideProximityCard(); // Clean up loot tag
        DOTSystem.clearPlayer();
        TelegraphSystem.cancelAll();
        EnemyAI._shakeOffLatched(this);
        
        // Track death context for memorial
        this._deathContext = {
            cause: this.gameMode === 'boss' ? 'boss' : 'defense',
            biome: CONFIG.currentBiome?.type || null,
            reach: this.destinationNode?.reach || this._runStats?.reach || 0,
            mode: this.gameMode
        };
        
        ConsumableSystem.cleanupScene(this);
        AudioManager.playerDeath();
        Haptics.death();
        EventBus.emit('playerDeath', { scene: this });
        this.player.setTint(0x440000).setVelocity(0, 0);
        this.cameras.main.shake(300, 0.02);
        
        // Process equipment loss (soulbound items survive)
        const eqResult = ItemManager.processDeathEquipment(this.state.equipment);
        
        // Build death summary
        this.deathKills.setText(`Kills: ${this.state.kills}`);
        const bpCount = this.state.backpack ? this.state.backpack.filter(i => i !== null).length : 0;
        const losses = [];
        if (this.state.bits > 0) losses.push(`${this.state.bits} Bits`);
        if (this.state.powerAmmo > 0) losses.push(`${this.state.powerAmmo} Power Ammo`);
        if (bpCount > 0) losses.push(`${bpCount} Items`);
        if (eqResult.lost.length > 0) losses.push(eqResult.lost.map(i => i.name).join(', '));
        this.deathLost.setText(losses.length > 0 ? `Lost: ${losses.join('  ')}` : '');
        
        // Show soulbound saves
        if (eqResult.saved.length > 0) {
            let saveMsg;
            if (eqResult.soulSurvivorTriggered) {
                saveMsg = 'SOUL SURVIVOR — All equipment protected!';
            } else {
                saveMsg = eqResult.saved.map(i => `${i.name} (${i.remaining} left)`).join(', ');
            }
            const saveTxt = this.add.text(0, 50, `${eqResult.soulSurvivorTriggered ? '' : 'Soulbound: '}${saveMsg}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: eqResult.soulSurvivorTriggered ? '#ff2244' : '#ffaa22', align: 'center',
                wordWrap: { width: 260 }
            }).setOrigin(0.5).setScrollFactor(0).setDepth(201);
            this.deathScreen.add(saveTxt);
        }
        
        // Clear backpack (items lost on death)
        if (this.state.backpack) ItemManager.clearInventory(this.state.backpack);
        // Clear run currencies
        this.state.bits = 0;
        this.state.powerAmmo = 0;
        // Vehicle storage persists through death
        
        this.time.delayedCall(500, () => this.deathScreen.setVisible(true));
    }

    spawnWave(count) {
        const current = this.enemies.getChildren().length;
        if (current >= 10) return;
        const toSpawn = Math.min(count, 10 - current);
        
        const biomeConfig = CONFIG.biomes[CONFIG.currentBiome.type];
        const types = biomeConfig ? biomeConfig.enemyTypes : ['husk', 'husk_crawl', 'flicker'];
        const px = this.player?.x || 0, py = this.player?.y || 0;
        const minDist = 120; // Minimum spawn distance from player
        
        for (let i = 0; i < toSpawn; i++) {
            let sx, sy, attempts = 0;
            do {
                const pt = Phaser.Utils.Array.GetRandom(this.spawnPoints);
                sx = pt.x + Phaser.Math.Between(-30, 30);
                sy = pt.y + Phaser.Math.Between(-30, 30);
                attempts++;
            } while (attempts < 8 && Phaser.Math.Distance.Between(sx, sy, px, py) < minDist);
            
            const type = Phaser.Utils.Array.GetRandom(types);
            this.spawnEnemy(sx, sy, type);
        }
    }
    
    // ── PRE-PLACE ENEMIES — Already patrolling when player arrives ──
    // Places enemies at spawn points far from entry, no pop-in
    _prePlaceEnemies(count) {
        if (!this.spawnPoints || this.spawnPoints.length === 0) return;
        
        const biomeConfig = CONFIG.biomes[CONFIG.currentBiome.type];
        const types = biomeConfig ? biomeConfig.enemyTypes : ['husk', 'husk_crawl', 'flicker'];
        const px = this.player?.x || 100;
        const py = this.player?.y || CONFIG.world.height / 2;
        const minDist = 250; // Much further than spawnWave's 120px
        
        // Sort spawn points by distance from player — furthest first
        const sorted = [...this.spawnPoints].sort((a, b) => {
            const dA = Phaser.Math.Distance.Between(a.x, a.y, px, py);
            const dB = Phaser.Math.Distance.Between(b.x, b.y, px, py);
            return dB - dA; // furthest first
        });
        
        // Pick points that are far enough, up to count
        let placed = 0;
        for (let i = 0; i < sorted.length && placed < count; i++) {
            const pt = sorted[i];
            const dist = Phaser.Math.Distance.Between(pt.x, pt.y, px, py);
            if (dist < minDist) continue; // too close to entry
            
            const sx = pt.x + Phaser.Math.Between(-20, 20);
            const sy = pt.y + Phaser.Math.Between(-20, 20);
            const type = Phaser.Utils.Array.GetRandom(types);
            this.spawnEnemy(sx, sy, type);
            placed++;
        }
        
        // If not enough far points, fill remaining from medium-distance ones (180px+)
        if (placed < count) {
            for (let i = 0; i < sorted.length && placed < count; i++) {
                const pt = sorted[i];
                const dist = Phaser.Math.Distance.Between(pt.x, pt.y, px, py);
                if (dist < 180 || dist >= minDist) continue; // skip too-close and already-used
                
                const sx = pt.x + Phaser.Math.Between(-20, 20);
                const sy = pt.y + Phaser.Math.Between(-20, 20);
                const type = Phaser.Utils.Array.GetRandom(types);
                this.spawnEnemy(sx, sy, type);
                placed++;
            }
        }
    }
    
    // ── EDGE WAVE — Reinforcements arrive from map borders ──
    spawnEdgeWave(count, typeOverride) {
        const current = this.enemies.getChildren().length;
        if (current >= 12) return; // slightly higher cap for edge waves
        const toSpawn = Math.min(count, 12 - current);
        if (toSpawn <= 0) return;
        
        const biomeConfig = CONFIG.biomes[CONFIG.currentBiome.type];
        const types = typeOverride || (biomeConfig ? biomeConfig.enemyTypes : ['husk', 'husk_crawl', 'flicker']);
        const w = CONFIG.world.width, h = CONFIG.world.height;
        const px = this.player?.x || w / 2;
        const py = this.player?.y || h / 2;
        
        for (let i = 0; i < toSpawn; i++) {
            let sx, sy, attempts = 0;
            // Pick an edge that's not directly on top of the player
            do {
                const edge = Math.floor(Math.random() * 4);
                if (edge === 0)      { sx = Phaser.Math.Between(40, w - 40); sy = 15; }       // top
                else if (edge === 1) { sx = Phaser.Math.Between(40, w - 40); sy = h - 15; }   // bottom
                else if (edge === 2) { sx = 15; sy = Phaser.Math.Between(40, h - 40); }       // left
                else                 { sx = w - 15; sy = Phaser.Math.Between(40, h - 40); }   // right
                attempts++;
            } while (attempts < 6 && Phaser.Math.Distance.Between(sx, sy, px, py) < 150);
            
            const type = Array.isArray(types) ? Phaser.Utils.Array.GetRandom(types) : types;
            this.spawnEnemy(sx, sy, type);
        }
    }
    
    // ── ESCALATION SYSTEM — Reinforcements ramp over time ──
    // Tier 1 (0-25s):   Quiet. Only pre-placed enemies.
    // Tier 2 (25-60s):  Light pressure. 1-2 enemies every 10s from edges.
    // Tier 3 (60-120s): Medium. 2-3 enemies every 7s, tougher types mixed in.
    // Tier 4 (120s+):   Heavy. 3-4 enemies every 5s, dangerous types appear.
    _startEscalation(reach) {
        const biomeConfig = CONFIG.biomes[CONFIG.currentBiome.type];
        const baseTypes = biomeConfig ? biomeConfig.enemyTypes : ['husk', 'husk_crawl', 'flicker'];
        
        // Dangerous types added at higher tiers — filtered to what this biome supports
        const allEnemyIds = Object.keys(CONFIG.enemyTypes || {});
        const dangerTypes = ['deadlock', 'reaper', 'flicker'].filter(t => allEnemyIds.includes(t));
        const eliteTypes = ['reaper', 'deadlock'].filter(t => allEnemyIds.includes(t));
        
        this._escalationTier = 0;
        this._escalationTime = 0;
        this._escalationReach = reach || 1;
        
        // Tier 1: quiet period — no timer needed
        // Tier 2 starts at 25s
        this._escalationTimer = this.time.delayedCall(25000, () => {
            this._escalationTier = 2;
            this._escalationLoop = this.time.addEvent({
                delay: 10000,
                loop: true,
                callback: () => {
                    if (this.state?.dead || this.gameMode === 'defense') return;
                    
                    const tier = this._escalationTier;
                    let count, types;
                    
                    if (tier <= 2) {
                        count = Phaser.Math.Between(1, 2);
                        types = baseTypes;
                    } else if (tier === 3) {
                        count = Phaser.Math.Between(2, 3);
                        // Mix in a danger type 30% of the time
                        types = Math.random() < 0.3 && dangerTypes.length > 0
                            ? [...baseTypes, Phaser.Utils.Array.GetRandom(dangerTypes)]
                            : baseTypes;
                    } else {
                        count = Phaser.Math.Between(3, 4);
                        // Mix in elite types 40% of the time
                        types = Math.random() < 0.4 && eliteTypes.length > 0
                            ? [...baseTypes, ...eliteTypes]
                            : [...baseTypes, ...(dangerTypes.length ? [Phaser.Utils.Array.GetRandom(dangerTypes)] : [])];
                    }
                    
                    // Reach scaling — slightly more at higher reaches
                    if (this._escalationReach >= 4) count += 1;
                    
                    this.spawnEdgeWave(count, types);
                }
            });
            
            // Tier 3 at 60s
            this.time.delayedCall(35000, () => {
                this._escalationTier = 3;
                if (this._escalationLoop) this._escalationLoop.delay = 7000;
            });
            
            // Tier 4 at 120s
            this.time.delayedCall(95000, () => {
                this._escalationTier = 4;
                if (this._escalationLoop) this._escalationLoop.delay = 5000;
            });
        });
    }
    
    spawnBoss() {
        // Legacy — redirect to new system
        BossAI.spawnBossEntity(this);
    }
    
    spawnEnemy(x, y, type = 'husk') {
        const shieldMult = 1 + (this.state?.reach || 1) * 0.1;
        const caravanTarget = this.gameMode === 'defense' && this.modeState && this.modeState.phase !== 'complete' && this.modeState.phase !== 'discovery' && !this.modeState.foundryId && Math.random() < 0.4;
        const e = EnemyManager.createEnemy(this, x, y, type, {
            hpMult: 1.0, shieldMult,
            aiState: 'patrol', patrolPoint: this.getValidPatrolPoint(x, y, true),
            caravanTarget
        });
        return e;
    }

    updateEnemies(delta) {
        if (!delta) delta = 16;
        this.enemies.getChildren().forEach(e => {
            if (!e.active) return;
            e.setDepth(10 + e.y * 0.01);
            
            // DOTSystem: tick enemy DOTs + render HP bar with debuffs
            DOTSystem.updateEnemy(this, e, delta);
            DOTSystem.ensureEnemyBar(this, e);
            
            // Stumbling enemies don't act
            if (e._stumbling) {
                e.setVelocity(e.body.velocity.x * 0.9, e.body.velocity.y * 0.9);
                SpriteManager.updateEnemyAnimation(e);
                return;
            }
            
            // Blood trail — crawlers leave blood drops as they drag
            if (e._isCrawler && e.body) {
                const spd = Math.sqrt(e.body.velocity.x ** 2 + e.body.velocity.y ** 2);
                if (spd > 5) {
                    if (!e._bloodTimer) e._bloodTimer = 0;
                    if (!e._bloodDrops) e._bloodDrops = [];
                    e._bloodTimer += delta;
                    if (e._bloodTimer > 250) {
                        e._bloodTimer = 0;
                        if (e._bloodDrops.length >= 20) {
                            const old = e._bloodDrops.shift();
                            if (old && old.active !== false) old.destroy();
                        }
                        const bSize = 1.5 + Math.random() * 1.5;
                        const ox = (Math.random() - 0.5) * 5;
                        const oy = 3 + Math.random() * 3;
                        const drop = this.add.circle(e.x + ox, e.y + oy, bSize, 0x551010, 0.18 + Math.random() * 0.08).setDepth(1);
                        this.tweens.add({ targets: drop, alpha: 0.02, duration: 8000, onComplete: () => drop.destroy() });
                        e._bloodDrops.push(drop);
                    }
                }
            }
            
            // Acid trail — maimed flickers leave a continuous toxic slick behind them
            if (e.enemyType === 'flicker_maimed' && e.body && this.acidPuddles) {
                const spd = Math.sqrt(e.body.velocity.x ** 2 + e.body.velocity.y ** 2);
                const mCfg = CONFIG.enemyTypes.flicker_maimed;
                const dur = mCfg.acidDuration || 8000;
                const now = this.time.now;
                
                // Init trail state
                if (!e._acidPoints) e._acidPoints = [];
                if (!e._acidTrail) e._acidTrail = [];
                if (!e._acidGfx) e._acidGfx = this.add.graphics().setDepth(1);
                if (!e._acidTimer) e._acidTimer = 0;
                if (!e._acidPuddleTimer) e._acidPuddleTimer = 0;
                
                // Record positions while moving
                if (spd > 5) {
                    e._acidTimer += delta;
                    if (e._acidTimer > 50) { // Record every 50ms for smooth line
                        e._acidTimer = 0;
                        // Slight lateral wobble for organic feel
                        const wobX = (Math.random() - 0.5) * 3;
                        const wobY = (Math.random() - 0.5) * 2;
                        e._acidPoints.push({ x: e.x + wobX, y: e.y + 5 + wobY, t: now });
                    }
                    
                    // Spawn hitbox puddles less often (every 200ms) along the trail
                    e._acidPuddleTimer += delta;
                    if (e._acidPuddleTimer > 200) {
                        e._acidPuddleTimer = 0;
                        // Cap hitbox count
                        if (e._acidTrail.length >= 25) {
                            const old = e._acidTrail.shift();
                            if (old && old.active !== false) { this.acidPuddles.remove(old); old.destroy(); }
                        }
                        const puddle = this.physics.add.sprite(e.x, e.y + 5, '__DEFAULT');
                        puddle.setVisible(false);
                        puddle.body.setSize(16, 12);
                        puddle._acidActive = true;
                        puddle._acidDmg = mCfg.acidDamage || 2;
                        puddle._tickRate = mCfg.acidTickRate || 500;
                        this.acidPuddles.add(puddle);
                        e._acidTrail.push(puddle);
                        this.time.delayedCall(dur, () => {
                            if (puddle.active !== false) {
                                puddle._acidActive = false;
                                this.acidPuddles.remove(puddle);
                                puddle.destroy();
                            }
                        });
                    }
                }
                
                // Prune expired points
                while (e._acidPoints.length > 0 && now - e._acidPoints[0].t > dur) {
                    e._acidPoints.shift();
                }
                
                // Redraw the continuous trail
                const pts = e._acidPoints;
                const g = e._acidGfx;
                g.clear();
                
                if (pts.length >= 2) {
                    // Draw filled trail as thick polyline with organic edges
                    for (let i = 0; i < pts.length - 1; i++) {
                        const p0 = pts[i], p1 = pts[i + 1];
                        const age0 = (now - p0.t) / dur; // 0 = fresh, 1 = expired
                        const age1 = (now - p1.t) / dur;
                        const alpha0 = Math.max(0, 1 - age0 * 0.6); // stays opaque longer
                        const alpha1 = Math.max(0, 1 - age1 * 0.6);
                        
                        const dx = p1.x - p0.x, dy = p1.y - p0.y;
                        const len = Math.sqrt(dx * dx + dy * dy);
                        if (len < 0.5) continue;
                        // Perpendicular for width
                        const nx = -dy / len, ny = dx / len;
                        
                        // Width varies — thicker in middle, thinner at tail
                        const w0 = (4 + Math.sin(i * 0.7) * 1.5) * (1 - age0 * 0.3);
                        const w1 = (4 + Math.sin((i + 1) * 0.7) * 1.5) * (1 - age1 * 0.3);
                        
                        // Outer fill — dark green
                        g.fillStyle(0x2a6622, 0.35 * alpha0);
                        g.beginPath();
                        g.moveTo(p0.x + nx * w0, p0.y + ny * w0);
                        g.lineTo(p1.x + nx * w1, p1.y + ny * w1);
                        g.lineTo(p1.x - nx * w1, p1.y - ny * w1);
                        g.lineTo(p0.x - nx * w0, p0.y - ny * w0);
                        g.closePath(); g.fill();
                        
                        // Inner fill — brighter green core
                        const cw0 = w0 * 0.55, cw1 = w1 * 0.55;
                        g.fillStyle(0x44aa33, 0.45 * alpha0);
                        g.beginPath();
                        g.moveTo(p0.x + nx * cw0, p0.y + ny * cw0);
                        g.lineTo(p1.x + nx * cw1, p1.y + ny * cw1);
                        g.lineTo(p1.x - nx * cw1, p1.y - ny * cw1);
                        g.lineTo(p0.x - nx * cw0, p0.y - ny * cw0);
                        g.closePath(); g.fill();
                    }
                    
                    // Edge detail — occasional drip blobs and bubble highlights
                    for (let i = 0; i < pts.length; i += 3) {
                        const p = pts[i];
                        const age = (now - p.t) / dur;
                        if (age > 0.8) continue;
                        const a = Math.max(0, 0.3 * (1 - age));
                        // Bright bubble
                        g.fillStyle(0x66dd44, a);
                        g.fillCircle(p.x + ((i * 7) % 5 - 2), p.y + ((i * 3) % 3 - 1), 1.2);
                        // Edge drip
                        if (i % 6 === 0) {
                            g.fillStyle(0x338822, a * 0.7);
                            const side = (i % 12 === 0) ? 1 : -1;
                            g.fillEllipse(p.x + side * (3 + (i % 4)), p.y, 2, 1.5);
                        }
                    }
                    
                }
            }
            
            // Enemies that lost aggro wander randomly
            if (e._lostAggro) {
                if (!e._wanderAngle || Math.random() < 0.02) {
                    e._wanderAngle = Math.random() * Math.PI * 2;
                }
                e.setVelocity(Math.cos(e._wanderAngle) * 15, Math.sin(e._wanderAngle) * 15);
                SpriteManager.updateEnemyAnimation(e);
                return;
            }
            
            // Defense mode: caravan-targeting enemies skip normal AI
            if (e._targetingCaravan) {
                SpriteManager.updateEnemyAnimation(e);
                return;
            }
            
            const cfg = CONFIG.enemyTypes[e.enemyType];
            if (!cfg) {
                // Decoy or custom enemy — simple chase AI
                if (e.speed) {
                    const a = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
                    e.setVelocity(Math.cos(a) * e.speed, Math.sin(a) * e.speed);
                }
                return;
            }
            const distToPlayer = Phaser.Math.Distance.Between(e.x, e.y, this.player.x, this.player.y);
            const angleToPlayer = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
            
            if (cfg.isBoss) { 
                // New boss system manages its own AI — just update HP bar
                if (this.modeState && this.modeState.bossEntity === e) {
                    this.bossHP.updateHP(e.hp, e.maxHp);
                    return;
                }
                // Boss defeated or not managed — skip
                if (this.modeState && this.modeState.phase === 'complete') return;
                this.updateBoss(e, distToPlayer, cfg); 
                return; 
            }
            
            // Stuck check
            const movedDist = Phaser.Math.Distance.Between(e.x, e.y, e.lastPos.x, e.lastPos.y);
            if (movedDist < 1 && e.patrolPauseTimer <= 0 && !e._charging && !e._deadlockCharging && !e._deadlockWindup && !e._deadlockSlamWindup && !e._deadlockSlamming) {
                e.stuckTimer++;
                if (e.stuckTimer > 30) { e.patrolTarget = this.getValidPatrolPoint(e.x, e.y, true); e.stuckTimer = 0; }
            } else { e.stuckTimer = 0; }
            e.lastPos = { x: e.x, y: e.y };
            
            // Sight check — sightline stat adds awareness delay before aggro
            const eqStats = this._eqStats || ItemManager.getEquipmentStats(this.state.equipment);
            const sightlineDelay = (eqStats.sightline || 0) / 10; // convert tenths to seconds
            const canSeePlayer = !this._phantomInvis && distToPlayer < CONFIG.enemy.sightRange && 
                                 this.hasLineOfSight(e.x, e.y, this.player.x, this.player.y);
            
            const aiType = cfg.ai || 'melee';
            
            if (canSeePlayer) {
                // Sightline: enemies need time to recognize the player
                if (sightlineDelay > 0 && !e._fullyAware) {
                    e._awarenessTimer = (e._awarenessTimer || 0) + (this.game.loop.delta || 16) / 1000;
                    if (e._awarenessTimer >= sightlineDelay) {
                        e._fullyAware = true;
                    } else {
                        // Not yet aware — skip aggro, continue patrol
                        if (e.patrolPauseTimer > 0) { e.patrolPauseTimer -= (this.game.loop.delta || 16); }
                        else { EnemyAI.aiPatrol(this, e, cfg); }
                        return;
                    }
                }
                e.awareness = 100;
                e.lastKnownPos = { x: this.player.x, y: this.player.y };
                e.setAlpha(1);
                
                switch (aiType) {
                    case 'ranged': EnemyAI.aiHost(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    case 'host': EnemyAI.aiHost(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    case 'reaper': EnemyAI.aiReaper(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    case 'deadlock': EnemyAI.aiDeadlock(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    case 'flank': EnemyAI.aiFlank(this, e, cfg, distToPlayer, angleToPlayer); break;
                    case 'overseer': EnemyAI.aiOverseer(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    case 'spawner': EnemyAI.aiOverseer(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    case 'erratic': EnemyAI.aiErratic(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    case 'erratic_maimed': EnemyAI.aiErraticMaimed(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    case 'skitter': EnemyAI.aiSkitter(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                    default: EnemyAI.aiMelee(this, e, cfg, distToPlayer, angleToPlayer); break;
                }
            } else {
                // Lost sight — reset awareness delay
                e._awarenessTimer = 0;
                e._fullyAware = false;
                if (aiType === 'overseer') { 
                    // Drift slowly when player out of sight
                    if (!e._driftAngle) e._driftAngle = Math.random() * Math.PI * 2;
                    if (Math.random() < 0.02) e._driftAngle += (Math.random() - 0.5) * 1.0;
                    e.setVelocity(Math.cos(e._driftAngle) * cfg.speed * 0.3, Math.sin(e._driftAngle) * cfg.speed * 0.3);
                    return; 
                }
                e.aiState = 'patrol';
                e.setAlpha(0.85);
                EnemyAI.aiPatrol(this, e, cfg);
            }
            
            // Update animation based on velocity
            if (e.hasAnimSheet) SpriteManager.updateEnemyAnimation(e);
            
            // Wall pushout — slide along walls instead of teleporting through
            if (this.wallRects && this.wallRects.length > 0) {
                for (const wr of this.wallRects) {
                    const wx = wr.x, wy = wr.y, ww = wr.width, wh = wr.height;
                    if (e.x > wx + 2 && e.x < wx + ww - 2 && e.y > wy + 2 && e.y < wy + wh - 2) {
                        const dL = e.x - wx, dR = (wx + ww) - e.x;
                        const dT = e.y - wy, dB = (wy + wh) - e.y;
                        const minD = Math.min(dL, dR, dT, dB);
                        // Push out on axis with least overlap (sliding collision)
                        if (minD === dL) { e.x = wx - 1; if (e.body) e.body.velocity.x = Math.max(0, e.body.velocity.x); }
                        else if (minD === dR) { e.x = wx + ww + 1; if (e.body) e.body.velocity.x = Math.min(0, e.body.velocity.x); }
                        else if (minD === dT) { e.y = wy - 1; if (e.body) e.body.velocity.y = Math.max(0, e.body.velocity.y); }
                        else { e.y = wy + wh + 1; if (e.body) e.body.velocity.y = Math.min(0, e.body.velocity.y); }
                        break;
                    }
                }
            }
        });
    }
    
    

    
    spawnSingleEnemy(x, y, type) {
        const cfg = CONFIG.enemyTypes[type];
        if (!cfg) return null;
        
        // Build animated spritesheet (same as spawnEnemy)
        SpriteManager.buildEnemySheet(this, type);
        const sheetKey = 'enemy_' + type + '_sheet';
        const hasSheet = this.textures.exists(sheetKey);
        if (!hasSheet) SpriteManager.getTexture(this, 'enemy_' + type);
        
        const e = this.physics.add.sprite(x, y, hasSheet ? sheetKey : ('enemy_' + type));
        e.setDisplaySize(cfg.size, cfg.size).setDepth(20);
        e.enemyType = type;
        e.hasAnimSheet = hasSheet;
        e.hp = cfg.health;
        e.maxHp = e.hp;
        e.canAttack = true;
        e.setCollideWorldBounds(true);
        e.aiState = 'chase';
        e.awareness = 100;
        e.lastKnownPos = { x: this.player.x, y: this.player.y };
        e.patrolTarget = null;
        e.patrolPauseTimer = 0;
        e.stuckTimer = 0;
        e.lastPos = { x: x, y: y };
        
        // Start animation
        if (hasSheet) {
            try { e.anims.play(`enemy_${type}_idle`, true); } catch(ex) {}
        }
        
        e.setAlpha(0).setScale(0.3);
        this.tweens.add({ targets: e, alpha: 1, scale: 1, duration: 300 });
        this.enemies.add(e);
        return e;
    }
    
    isPointInWall(x, y) {
        for (const wall of this.wallRects) {
            if (wall.contains(x, y)) {
                return true;
            }
        }
        return false;
    }
    
    getValidPatrolPoint(fromX, fromY, longRange = false) {
        // Patrol targets - spread across entire map
        for (let i = 0; i < 30; i++) {
            let x, y;
            
            if (longRange && Math.random() < 0.6) {
                // Pick a distant random point anywhere on map
                x = Phaser.Math.Between(80, CONFIG.world.width - 80);
                y = Phaser.Math.Between(80, CONFIG.world.height - 80);
            } else {
                // Random direction from current position
                const angle = Math.random() * Math.PI * 2;
                const dist = Phaser.Math.Between(120, 300);
                x = fromX + Math.cos(angle) * dist;
                y = fromY + Math.sin(angle) * dist;
            }
            
            const clampedX = Phaser.Math.Clamp(x, 50, CONFIG.world.width - 50);
            const clampedY = Phaser.Math.Clamp(y, 50, CONFIG.world.height - 50);
            
            // Check if target point is in a wall
            if (this.isPointInWall(clampedX, clampedY)) continue;
            
            // Check if path has line of sight
            if (this.hasLineOfSight(fromX, fromY, clampedX, clampedY)) {
                return { x: clampedX, y: clampedY };
            }
        }
        
        // Fallback - pick a random open spot
        const fallbackX = Phaser.Math.Between(100, CONFIG.world.width - 100);
        const fallbackY = Phaser.Math.Between(100, CONFIG.world.height - 100);
        return { x: fallbackX, y: fallbackY };
    }
    
    hasLineOfSight(x1, y1, x2, y2) {
        const ray = new Phaser.Geom.Line(x1, y1, x2, y2);
        for (const wall of this.wallRects) {
            if (Phaser.Geom.Intersects.LineToRectangle(ray, wall)) {
                return false;
            }
        }
        return true;
    }
    
    updateBoss(e, dist, cfg) {
        // Show and update UI health bar
        this.bossHP.setVisible(true);
        this.bossHP.updateHP(e.hp, e.maxHp);
        
        // If winding up, don't move
        if (e.windingUp) return;
        
        // Always chase player
        e.state = 'chase';
        const a = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
        e.setVelocity(Math.cos(a) * cfg.chaseSpeed, Math.sin(a) * cfg.chaseSpeed);
        
        // Ability timer - attack every 4 seconds
        e.abilityTimer = (e.abilityTimer || 0) + 1;
        
        if (e.abilityTimer > 240) {
            this.bossWindup(e);
        }
    }
    
    bossWindup(e) {
        e.windingUp = true;
        e.abilityTimer = 0;
        e.setVelocity(0, 0);
        
        // Store target position
        const targetX = this.player.x;
        const targetY = this.player.y;
        
        // Boss windup animation - flash and grow
        e.setTint(0xffffff);
        this.tweens.add({
            targets: e,
            scaleX: 1.3,
            scaleY: 1.3,
            duration: 200,
            yoyo: true,
            repeat: 2
        });
        
        // Attack indicator - outer square border
        const indicator = this.add.rectangle(targetX, targetY, 100, 100, 0xff0000, 0).setStrokeStyle(3, 0xff0000, 0.8);
        indicator.setAngle(45).setDepth(50);
        
        // Fill square that grows (starts at scale 0)
        const fill = this.add.rectangle(targetX, targetY, 100, 100, 0xff0000, 0.35);
        fill.setAngle(45).setScale(0).setDepth(49);
        
        // Warning text
        const warning = this.add.text(targetX, targetY - 80, '!', { fontFamily: CONFIG.font, fontSize: uiPx(28), fill: '#ff0000', fontStyle: 'bold' }).setOrigin(0.5).setDepth(51);
        this.tweens.add({ targets: warning, alpha: 0.3, duration: 150, yoyo: true, repeat: 5 });
        
        // Animate fill square using scale - 1.5 second windup
        this.tweens.add({
            targets: fill,
            scale: 1,
            duration: 1500,
            ease: 'Linear',
            onComplete: () => {
                // Execute attack
                indicator.destroy();
                fill.destroy();
                warning.destroy();
                e.setTint(CONFIG.enemyTypes.boss.color);
                e.windingUp = false;
                
                // Damage player if in zone (square check - rotated 45 deg so check diamond)
                const dx = Math.abs(this.player.x - targetX);
                const dy = Math.abs(this.player.y - targetY);
                if (dx + dy < 70 && !this.isInvincible) {
                    this.state.health -= 40;
                    ConsumableSystem.interruptChannel();
                    this.player.setTint(0xff0000);
                    this.cameras.main.shake(200, 0.03);
                    this.time.delayedCall(150, () => { if (!this.state.dead) _restoreTint(this.player); });
                    if (this.state.health <= 0) this.die();
                }
                
                // Impact effect - cube explosion
                for (let i = 0; i < 12; i++) {
                    const angle = (i / 12) * Math.PI * 2;
                    const cube = this.add.rectangle(targetX, targetY, 10, 10, 0xff4400, 0.9);
                    cube.setAngle(Phaser.Math.Between(0, 45));
                    this.tweens.add({
                        targets: cube,
                        x: targetX + Math.cos(angle) * 80,
                        y: targetY + Math.sin(angle) * 80,
                        angle: cube.angle + Phaser.Math.Between(-180, 180),
                        alpha: 0,
                        scale: 0.2,
                        duration: 350,
                        onComplete: () => cube.destroy()
                    });
                }
                
                // Ground crack effect - square shards
                for (let i = 0; i < 8; i++) {
                    const angle = (i / 8) * Math.PI * 2;
                    const crack = this.add.rectangle(
                        targetX + Math.cos(angle) * 30,
                        targetY + Math.sin(angle) * 30,
                        4, 20, 0x330000
                    ).setRotation(angle);
                    this.tweens.add({ targets: crack, alpha: 0, duration: 500, delay: 100, onComplete: () => crack.destroy() });
                }
            }
        });
    }

    updateUI() {
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        const maxHp = CONFIG.player.health + (eqStats.maxHealth || 0);
        // HP updates via Survivor HUD panel
        if (this.hud && this.hud.updateHP) this.hud.updateHP(this.state.health, maxHp);
        if (this._ammoHud) this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
        if (this.killsText) this.killsText.setText(`KILLS: ${this.state.kills}`);
        if (this.bitsText) this.bitsText.setText(`${this.state.bits}`);
        if (this.magText) this.magText.setText(`${this._magazineMax || 10}`);
    }
}

// ==================== INTERIOR SCENE ====================
// Building interior exploration and looting

