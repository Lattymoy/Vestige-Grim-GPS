// Vestige GPS — SafehouseScene
// Extracted from monolith lines 40317-48721
// Imports will be wired in integration pass

import { Haptics } from '../../core/haptics.js';
import { ItemManager } from '../../core/itemManager.js';
import { RealtimeTOD } from '../../core/realtimeTOD.js';
import { SaveManager } from '../../core/saveManager.js';
import { SurvivorGenerator } from '../../core/survivorGenerator.js';
import { Utils, uiPx } from '../../core/utils.js';
import { WeatherSystem } from '../../core/weatherSystem.js';
import { BIOMES } from '../../data/biomesLookup.js';
import { CONFIG } from '../../data/config.js';
import { GrimFont } from '../../data/grimFont.js';
import { ISO_DEFS } from '../../data/isoDefs.js';
import { TitleFont } from '../../data/titleFont.js';
import { AudioManager } from '../audioManager.js';
import { CRTTerminal } from '../crtTerminal.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { GymPanel } from '../gymPanel.js';
import { InteractHighlight } from '../interactHighlight.js';
import { IsoRenderer } from '../isoRenderer.js';
import { CrownAura } from '../rendering/crownAura.js';
import { FloorRenderer } from '../rendering/floorRenderer.js';
import { ParallaxBG } from '../rendering/parallaxBG.js';
import { WallRenderer } from '../rendering/wallRenderer.js';
import { SleepPanel } from '../sleepPanel.js';
import { SpriteManager } from '../spriteManager.js';
import { GameHUD } from '../ui/gameHUD.js';
import { InventoryUI } from '../ui/inventoryUI.js';
import { UIAtlas } from '../uiAtlas.js';
import { UIManager } from '../uiManager.js';
import { WorkbenchPanel } from '../workbenchPanel.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { InputManager } from '../rendering/inputManager.js';
import { CubeSimScene } from './CubeSimScene.js';
import { InteriorScene } from './InteriorScene.js';
import { MapScene } from './MapScene.js';


export class SafehouseScene extends Phaser.Scene {
    constructor() {
        super({ key: 'SafehouseScene' });
    }
    
    init(data) {
        // Stop any biome ambient audio
        try { AudioManager.stopAmbient(500); } catch(e) {}
        // Load save data via SaveManager
        this.loadSaveData();
        this._deathNotifications = null; // Clear stale data from previous scene run
        CONFIG._activeLootQualityBonus = 0; // Clear run-scoped loot quality bonus
        CONFIG._activeBiomeLootQualityBonus = 0; // Clear biome-scoped quality bonus
        
        // Snapshot pre-return state for notification comparison
        const preQuests = [...(this.saveData.quests?.completed || [])];
        const preAchievements = [...(this.saveData.achievements || [])];
        
        // If returning from a successful extraction — deposit via SaveManager
        if (data && data.returnedLoot) {
            this.saveData = SaveManager.depositLoot(data.returnedLoot, data.returnedBackpack, data.returnedEquipment);
            if (data.returnedVehicle) {
                if (!this.runState) this.runState = {};
                this.runState.vehicle = data.returnedVehicle;
            }
        }
        
        // If returning from death
        if (data && data.died) {
            this.saveData = SaveManager.handleDeath(data.returnedEquipment, data.returnedVehicle);
            if (data.returnedVehicle) {
                if (!this.runState) this.runState = {};
                this.runState.vehicle = data.returnedVehicle;
            }
            
            // Clear active route — death resets all progress
            this.saveData.activeRoute = null;
            
            // Irreplaceable mark penalty: lose 5% of stash bits on death
            if (data.deployedSurvivor) {
                const _irrSurv = this.saveData.survivors?.find(s => s.id === data.deployedSurvivor.id);
                const _irrConds = _irrSurv ? SurvivorGenerator.getMarkEffects(_irrSurv)?.conditionals : null;
                if (_irrConds && _irrConds.irreplaceablePenalty && this.saveData.stash?.bits > 0) {
                    const _irrLoss = Math.round(this.saveData.stash.bits * 0.05);
                    this.saveData.stash.bits -= _irrLoss;
                    if (!this._deathNotifications) this._deathNotifications = [];
                    if (_irrLoss > 0) this._deathNotifications.push({ type: 'death', title: `Irreplaceable: -${_irrLoss} Bits`, subtitle: 'The convoy mourns the loss.' });
                }
            }
            
            // PERMADEATH / INJURY SOFT OFF-RAMP
            if (data.deployedSurvivor && this.saveData.survivors) {
                const deadSurv = this.saveData.survivors.find(s => s.id === data.deployedSurvivor.id);
                if (deadSurv) {
                    this._deathNotifications = [];
                    
                    // Soft off-ramp: if survivor has NO existing injury, downgrade to maimed
                    // If already injured (any type), permadeath triggers — the wastes don't forgive twice
                    if (!deadSurv.injury) {
                        // Apply maimed instead of killing
                        SurvivorGenerator.applyInjury(deadSurv, 'maimed');
                        this._deathNotifications.push({
                            type: 'injury',
                            title: `${deadSurv.name} is maimed`,
                            subtitle: 'Barely dragged back. Cannot deploy until treated.'
                        });
                        // Un-deploy — maimed survivors can't deploy
                        deadSurv.deployed = false;
                        // Auto-deploy next available survivor
                        const deployable = this.saveData.survivors.filter(s => s.alive && s.id !== deadSurv.id && SurvivorGenerator.isDeployable(s));
                        if (deployable.length > 0) {
                            deployable.forEach(s => s.deployed = false);
                            deployable[0].deployed = true;
                        }
                    } else {
                        // Already injured — true permadeath
                        SurvivorGenerator.kill(deadSurv, data.deathContext);
                        this._deadSurvivorName = deadSurv.name;
                        this._deathNotifications.push({
                            type: 'death',
                            title: `${deadSurv.name} has fallen`,
                            subtitle: data.deathContext?.biome 
                                ? `Lost in the ${data.deathContext.biome} — Reach ${data.deathContext.reach || '?'}`
                                : 'The wastes claim another.'
                        });
                        
                        // Check if ALL survivors are now dead — auto-recruit emergency survivor
                        const alive = this.saveData.survivors.filter(s => s.alive);
                        if (alive.length === 0) {
                            const emergSurv = SurvivorGenerator.generate(Date.now(), 'common');
                            emergSurv.deployed = true;
                            this.saveData.survivors.push(emergSurv);
                            this._deathNotifications.push({
                                type: 'rescue',
                                title: `${emergSurv.name} arrived at the safehouse`,
                                subtitle: 'A lone wanderer stumbled in from the wastes.'
                            });
                        } else {
                            // Auto-deploy first alive deployable survivor
                            alive.forEach(s => s.deployed = false);
                            const nextDeploy = alive.find(s => SurvivorGenerator.isDeployable(s)) || alive[0];
                            nextDeploy.deployed = true;
                        }
                    }
                    
                    SaveManager.save(this.saveData);
                }
            }
        }
        
        // If returning from a SUCCESSFUL extraction — check low-HP injury trigger
        if (data && data.returnedLoot && data.deployedSurvivor && this.saveData.survivors) {
            const retSurv = this.saveData.survivors.find(s => s.id === data.deployedSurvivor.id);
            if (retSurv && retSurv.alive && !retSurv.injury) {
                const hpRatio = (data.returnedHealth || 0) / (data.maxHealth || 100);
                if (hpRatio < 0.25 && hpRatio > 0) {
                    // Weighted random injury: wounded 50%, exhausted 35%, shell_shocked 15%
                    const roll = Math.random();
                    const injType = roll < 0.50 ? 'wounded' : roll < 0.85 ? 'exhausted' : 'shell_shocked';
                    SurvivorGenerator.applyInjury(retSurv, injType);
                    const injDef = SurvivorGenerator.INJURY_TYPES[injType];
                    if (!this._deathNotifications) this._deathNotifications = [];
                    this._deathNotifications.push({
                        type: 'injury',
                        title: `${retSurv.name} is ${injDef.label.toLowerCase()}`,
                        subtitle: 'Returned from the run in bad shape.'
                    });
                    SaveManager.save(this.saveData);
                }
            }
            
            // ── Recovery checks for all non-deployed survivors ──
            // Each successful run ticks down recovery counters
            const globalRuns = this.saveData.stats?.runsCompleted || 0;
            this.saveData.survivors.forEach(s => {
                if (s.alive && s.injury && s.id !== data.deployedSurvivor.id) {
                    SurvivorGenerator.checkRecovery(s, globalRuns);
                }
            });
            SaveManager.save(this.saveData);
        }
        
        // Check for newly completed quests/achievements
        this._pendingNotifications = this._deathNotifications || [];
        
        // ── MARK AWARD NOTIFICATIONS ──
        if (data && data._markNotifications && data._markNotifications.length > 0) {
            data._markNotifications.forEach(mn => {
                const tierCol = { mundane: '#888899', strange: '#9966cc', legendary: '#cc8822', earned: '#4488aa', cube: '#aa44cc' };
                this._pendingNotifications.push({
                    type: 'mark',
                    title: `${mn.mark.name}`,
                    subtitle: mn.mark.desc,
                    markTier: mn.mark.tier,
                    markColor: tierCol[mn.mark.tier] || '#4488aa'
                });
            });
        }
        
        const postQuests = this.saveData.quests?.completed || [];
        const postAchievements = this.saveData.achievements || [];
        
        postQuests.filter(q => !preQuests.includes(q)).forEach(qId => {
            const qDef = CONFIG.quests[qId];
            if (qDef) this._pendingNotifications.push({ type: 'quest', title: qDef.title, reward: qDef.reward });
        });
        postAchievements.filter(a => !preAchievements.includes(a)).forEach(aId => {
            const aDef = CONFIG.achievements[aId];
            if (aDef) this._pendingNotifications.push({ type: 'achievement', title: aDef.title, icon: aDef.icon, reward: aDef.reward });
        });
        
        // XP notification from the run
        if (data && data.runXP) {
            this._pendingNotifications.unshift({ type: 'xp', xp: data.runXP, leveledUp: data.leveledUp, newLevel: data.newLevel });
        }
    }
    
    loadSaveData() {
        this.saveData = SaveManager.load();
        // Migrate survivor data: perks→vestiges→marks rename, injury field, mark fields
        if (this.saveData.survivors) {
            this.saveData.survivors.forEach(s => SurvivorGenerator.migrateSurvivorData(s));
            SaveManager.save(this.saveData);
        }
    }
    
    saveSaveData() {
        SaveManager.save(this.saveData);
    }
    
    create() {
        // ═══════════════════════════════════════════════════════
        // ROOM DEFINITIONS — world-coordinate layout
        // ═══════════════════════════════════════════════════════
        this.ROOMS = {
            hub: {
                id: 'hub', name: 'Main Hub',
                x: 360, y: 500, w: 280, h: 400,
                floor: 0x2a2a2e, floorAlt: 0x252528,
                wall: 0x3a3a44, wallStyle: 'steel',
                light: { color: 0xffffcc, size: [180, 140], inner: [100, 70], alpha: [0.06, 0.15], innerAlpha: [0.03, 0.09], speed: 120, innerSpeed: 60, scale: [1, 1.03], pos: 0.4 },
                doors: [
                    { id: 'hub_containment', wall: 'west', pos: 0.25, target: 'containment', targetDoor: 'containment_hub' },
                    { id: 'hub_bedroom', wall: 'west', pos: 0.75, target: 'bedroom', targetDoor: 'bedroom_hub' },
                    { id: 'hub_armory', wall: 'east', pos: 0.25, target: 'armory', targetDoor: 'armory_hub' },
                    { id: 'hub_barracks', wall: 'east', pos: 0.75, target: 'barracks', targetDoor: 'barracks_hub' },
                    { id: 'hub_garage', wall: 'south', pos: 0.5, target: 'garage', targetDoor: 'garage_hub' }
                ]
            },
            containment: {
                id: 'containment', name: 'Containment',
                x: 160, y: 500, w: 200, h: 200,
                floor: 0x2e2e32, floorAlt: 0x28282c,
                wall: 0x3a3a48, wallStyle: 'reinforced',
                light: { color: 0xff6633, size: [110, 80], inner: [55, 40], alpha: [0.04, 0.12], innerAlpha: [0.02, 0.08], speed: 800, innerSpeed: 400, scale: [1, 1.06], pos: 0.45 },
                doors: [
                    { id: 'containment_hub', wall: 'east', pos: 0.5, target: 'hub', targetDoor: 'hub_containment' }
                ]
            },
            bedroom: {
                id: 'bedroom', name: 'Quarters',
                x: 160, y: 700, w: 200, h: 200,
                floor: 0x3a3428, floorAlt: 0x342e24,
                wall: 0x4a4438, wallStyle: 'plaster',
                light: { color: 0xffaa66, size: [110, 80], inner: [55, 40], alpha: [0.06, 0.10], innerAlpha: [0.04, 0.07], speed: 2000, innerSpeed: 1500, scale: [1, 1.01], pos: 0.4 },
                doors: [
                    { id: 'bedroom_hub', wall: 'east', pos: 0.5, target: 'hub', targetDoor: 'hub_bedroom' }
                ]
            },
            armory: {
                id: 'armory', name: 'Cubesim',
                x: 640, y: 500, w: 200, h: 200,
                floor: 0x0e0e18, floorAlt: 0x0a0a14,
                wall: 0x1a1a2e, wallStyle: 'cubesim',
                light: { color: 0x44bbff, size: [110, 80], inner: [55, 40], alpha: [0.04, 0.10], innerAlpha: [0.02, 0.07], speed: 2500, innerSpeed: 1200, scale: [1, 1.03], pos: 0.4 },
                doors: [
                    { id: 'armory_hub', wall: 'west', pos: 0.5, target: 'hub', targetDoor: 'hub_armory' }
                ]
            },
            barracks: {
                id: 'barracks', name: 'Barracks',
                x: 640, y: 700, w: 200, h: 200,
                floor: 0x2e2e2a, floorAlt: 0x28282a,
                wall: 0x3a3a38, wallStyle: 'bare',
                light: { color: 0xddbb88, size: [110, 80], inner: [55, 40], alpha: [0.03, 0.07], innerAlpha: [0.02, 0.05], speed: 3000, innerSpeed: 2000, scale: [1, 1.01], pos: 0.45 },
                doors: [
                    { id: 'barracks_hub', wall: 'west', pos: 0.5, target: 'hub', targetDoor: 'hub_barracks' }
                ]
            },
            garage: {
                id: 'garage', name: 'Garage',
                x: 360, y: 900, w: 280, h: 230,
                floor: 0x34342e, floorAlt: 0x2e2e28,
                wall: 0x44403a, wallStyle: 'cinderblock',
                light: { color: 0xffcc44, size: [160, 120], inner: [90, 65], alpha: [0.05, 0.14], innerAlpha: [0.03, 0.10], speed: 150, innerSpeed: 70, scale: [1, 1.04], pos: 0.4 },
                doors: [
                    { id: 'garage_hub', wall: 'north', pos: 0.5, target: 'hub', targetDoor: 'hub_garage' }
                ]
            }
        };
        
        // Wall rendering constants (shared with InteriorScene)
        this._wallConst = { frontH: 24, topH: 4, sideW: 8, sideSliver: 3 };
        
        // Current room tracking
        this.currentRoom = 'hub';
        
        // Popup state
        this.popupActive = false;
        
        // ── REALTIME TIME-OF-DAY — safehouse uses real clock ──
        CONFIG.timeOfDay = RealtimeTOD.getFromClock();
        this._realtimeTod = CONFIG.timeOfDay;
        
        // Render all rooms
        this.renderAllRooms();
        this.createExterior();
        this.createOpenings();
        this.buildCollisionBounds();
        
        // Legacy properties (used by garage animation, customization — will be replaced)
        this.wallElements = [];
        this.floorRect = null;
        this.garageDoor = null;
        this.garageFrame = null;
        this.behindDoorContainer = null;
        this.doorLightSpill = null;
        this._southWall = null;
        
        this.createStations();
        this.createRoomProps();
        this.updateStationVisibility(); // hide stations in unrevealed rooms
        this.createUI();
        this.createPlayer();
        this.spawnSurvivorNPCs();
        this.createTimeOfDayOverlay();
        
        // ── REALTIME WEATHER — fetch and render biome-mapped effects ──
        this._weatherCleanup = null;
        const biomeId = (this.saveData && this.saveData.biome) || 'grassy';
        WeatherSystem.fetchWeather().then(condition => {
            if (!this.scene || !this.scene.isActive()) return;
            const effect = WeatherSystem.getEffect(condition, biomeId);
            this._weatherEffect = effect;
            this._weatherCondition = condition;
            this._weatherCleanup = WeatherSystem.render(this, effect, biomeId);
        });
        
        this.setupInput();
        
        // Camera follow setup
        const cam = this.cameras.main;
        cam.setBounds(0, 0, 1000, 1800);
        cam.startFollow(this.player, true, 0.12, 0.12);
        
        // Periodic console notification refresh (every 10s — checks barracks timer)
        this.time.addEvent({
            delay: 10000, loop: true,
            callback: () => this._updateConsoleNotifications()
        });
        
        // Show welcome message on first visit
        if (this.saveData.firstVisit) {
            this.showWelcome();
            this.saveData.firstVisit = false;
            this.saveSaveData();
        }
        
        SceneTransition.fadeIn(this, 400);
        
        // Show queued notifications (quest/achievement completions)
        if (this._pendingNotifications && this._pendingNotifications.length > 0) {
            let delay = 800;
            this._pendingNotifications.forEach(note => {
                this.time.delayedCall(delay, () => this.showNotificationToast(note));
                delay += 1200;
            });
            this._pendingNotifications = [];
        }
    }
    
    // ═══════════════════════════════════════════════════════
    // MULTI-ROOM RENDERER — draws walls/floors for all rooms
    // ═══════════════════════════════════════════════════════
    renderAllRooms() {
        // World background (steel foundation between rooms)
        this.add.rectangle(500, 900, 1000, 1800, 0x22222a).setDepth(0);
        
        // Container per room for visibility toggling
        this._roomContainers = {};
        // South walls live at scene-level for proper depth sorting
        this._southWallParts = {};
        
        // Render each room into its own container
        for (const room of Object.values(this.ROOMS)) {
            const container = this.add.container(0, 0).setDepth(1);
            this._roomContainers[room.id] = container;
            this.renderRoom(room, container);
            // All rooms always visible — shrouds handle darkness
        }
        
        // === ROOM SHROUD SYSTEM — darken rooms player is not in ===
        this._roomShrouds = {};
        const WC = this._wallConst;
        for (const room of Object.values(this.ROOMS)) {
            const shroud = this.add.rectangle(
                room.x + room.w/2, room.y + room.h/2,
                room.w + 2, room.h + 2,
                0x000000, 0.65
            ).setDepth(50); // above room contents but below HUD
            shroud.setVisible(room.id !== 'hub'); // hub starts unshrouded
            // Store original geometry for reset
            shroud._origY = room.y + room.h/2;
            shroud._origH = room.h + 2;
            this._roomShrouds[room.id] = shroud;
        }
    }
    
    renderRoom(room, container) {
        const { x, y, w, h, floor, floorAlt } = room;
        const WC = this._wallConst;
        
        // North wall (feature wall visible from inside) uses room theme
        const wallBase = room.wall;
        const wallDk = IsoRenderer.darken(wallBase, 0.15);
        const wallLt = IsoRenderer.lighten(wallBase, 0.1);
        const wallEdge = IsoRenderer.darken(wallBase, 0.25);
        const wallHi = IsoRenderer.lighten(wallBase, 0.2);
        
        // Perimeter walls (E/W/S) use hub color for unified building exterior
        const perimBase = this.ROOMS.hub.wall;
        const perimDk = IsoRenderer.darken(perimBase, 0.15);
        const perimLt = IsoRenderer.lighten(perimBase, 0.1);
        const perimEdge = IsoRenderer.darken(perimBase, 0.25);
        const perimHi = IsoRenderer.lighten(perimBase, 0.2);
        
        const add = (obj) => { container.add(obj); return obj; };
        
        // === Determine which walls are shared with hub (skip those) ===
        const skipWalls = new Set();
        if (room.id !== 'hub') {
            for (const d of (room.doors || [])) {
                if (d.target === 'hub') skipWalls.add(d.wall);
            }
        }
        
        // === Collect door gaps per wall ===
        const wallGaps = { north: [], south: [], west: [], east: [] };
        for (const d of (room.doors || [])) {
            const DOOR_W = (SafehouseScene.CONNECTOR_SIZES[d.size || 'small'] || SafehouseScene.CONNECTOR_SIZES.small).doorW;
            if (d.wall === 'west' || d.wall === 'east') {
                const doorY = y + h * d.pos;
                wallGaps[d.wall].push({ min: doorY - DOOR_W/2, max: doorY + DOOR_W/2 });
            } else {
                const doorX = x + w * d.pos;
                wallGaps[d.wall].push({ min: doorX - DOOR_W/2, max: doorX + DOOR_W/2 });
            }
        }
        
        // === FLOOR (room-specific) ===
        add(this.add.rectangle(x + w/2, y + h/2, w, h, floor).setDepth(1));
        this._renderRoomFloor(room, add);
        
        // === BACK WALL (north) — front face + top strip, split for door gaps ===
        if (!skipWalls.has('north')) {
            const nSegs = this._splitWallSegments(x, x + w, wallGaps.north);
            for (const seg of nSegs) {
                const sw = seg.max - seg.min, scx = seg.min + sw/2;
                add(this.add.rectangle(scx, y + WC.topH/2, sw, WC.topH, wallLt).setDepth(3));
                add(this.add.rectangle(scx, y + 1, sw, 1, wallHi, 0.4).setDepth(3.04));
                add(this.add.rectangle(scx, y + WC.topH + WC.frontH/2, sw, WC.frontH, wallBase).setDepth(3.1));
                for (let i = 1; i <= 3; i++) {
                    add(this.add.rectangle(scx, y + WC.topH + WC.frontH * (i/4), sw, 1, wallDk, 0.3).setDepth(3.11));
                }
                add(this.add.rectangle(scx, y + WC.topH + WC.frontH, sw, 2, wallEdge).setDepth(3.12));
            }
        }
        
        // === Side wall Y extension — when a room skips its north/south wall,
        // its side walls must extend to cover the shared wall thickness ===
        const wallThick = WC.frontH + WC.topH;
        const sideYStart = skipWalls.has('north') ? y - wallThick : y;
        const sideYEnd = skipWalls.has('south') ? y + h + wallThick : y + h;
        const sideH = sideYEnd - sideYStart;
        
        // === LEFT WALL (west) — ¾ iso: side face + front sliver, split for door gaps ===
        if (!skipWalls.has('west')) {
            const wSegs = this._splitWallSegments(sideYStart, sideYEnd, wallGaps.west);
            for (const seg of wSegs) {
                const sh = seg.max - seg.min, scy = seg.min + sh/2;
                add(this.add.rectangle(x + WC.sideW/2, scy, WC.sideW, sh, perimDk).setDepth(5));
                add(this.add.rectangle(x + WC.sideW - WC.sideSliver/2, scy, WC.sideSliver, sh, perimBase, 0.5).setDepth(5.01));
                add(this.add.rectangle(x + 1, scy, 1, sh, perimEdge, 0.5).setDepth(5.01));
            }
        }
        
        // === RIGHT WALL (east) — skip for garage (retractable door panels replace it) ===
        if (!skipWalls.has('east') && room.id !== 'garage') {
            const eSegs = this._splitWallSegments(sideYStart, sideYEnd, wallGaps.east);
            const rightX = x + w;
            for (const seg of eSegs) {
                const sh = seg.max - seg.min, scy = seg.min + sh/2;
                add(this.add.rectangle(rightX - WC.sideW/2, scy, WC.sideW, sh, perimDk).setDepth(5));
                add(this.add.rectangle(rightX - WC.sideW + WC.sideSliver/2, scy, WC.sideSliver, sh, perimBase, 0.5).setDepth(5.01));
                add(this.add.rectangle(rightX - 1, scy, 1, sh, perimEdge, 0.5).setDepth(5.01));
            }
        }
        
        // === SOUTH WALL — scene-level for true depth sorting, split for door gaps ===
        const botD = 10 + (y + h) * 0.01;
        const botFaceTop = y + h - WC.frontH;
        const botTopTop = botFaceTop - WC.topH;
        const southParts = [];
        
        if (!skipWalls.has('south')) {
            const southSegs = this._splitWallSegments(x, x + w, wallGaps.south);
            for (const seg of southSegs) {
                const sw = seg.max - seg.min, scx = seg.min + sw/2;
                southParts.push(this.add.rectangle(scx, y + h - WC.frontH / 2, sw, WC.frontH, perimDk).setDepth(botD));
                southParts.push(this.add.rectangle(scx, botFaceTop - WC.topH / 2, sw, WC.topH, perimBase).setDepth(botD + 0.03));
                southParts.push(this.add.rectangle(scx, botTopTop + 1, sw, 1, perimHi, 0.3).setDepth(botD + 0.04));
            }
        }
        
        if (!this._occlusionWalls) this._occlusionWalls = [];
        this._occlusionWalls.push({
            parts: southParts, facing: 'south', cx: x + w/2,
            groundY: y + h, w: w, left: x, right: x + w,
            visualTop: botTopTop, visualBot: y + h, roomId: room.id
        });
        
        // === WALL TEXTURE OVERLAY — also gap-split and skip-aware ===
        const ws = room.wallStyle;
        if (ws && WallRenderer[ws]) {
            const wfn = WallRenderer[ws];
            // North face overlay (room theme)
            if (!skipWalls.has('north')) {
                const nSegs = this._splitWallSegments(x, x + w, wallGaps.north);
                for (const seg of nSegs) {
                    const sw = seg.max - seg.min;
                    const nfg = this.add.graphics().setDepth(3.13);
                    wfn(nfg, seg.min, y + WC.topH, sw, WC.frontH, wallBase, 'north');
                    add(nfg);
                }
            }
            // West side overlay (perimeter — hub style)
            if (!skipWalls.has('west')) {
                const wSegs = this._splitWallSegments(sideYStart, sideYEnd, wallGaps.west);
                for (const seg of wSegs) {
                    const sh = seg.max - seg.min;
                    const wsg = this.add.graphics().setDepth(5.02);
                    WallRenderer.steel(wsg, x, seg.min, WC.sideW, sh, perimDk, 'west');
                    add(wsg);
                }
            }
            // East side overlay (perimeter — hub style, skip for garage)
            if (!skipWalls.has('east') && room.id !== 'garage') {
                const eSegs = this._splitWallSegments(sideYStart, sideYEnd, wallGaps.east);
                for (const seg of eSegs) {
                    const sh = seg.max - seg.min;
                    const esg = this.add.graphics().setDepth(5.02);
                    WallRenderer.steel(esg, x + w - WC.sideW, seg.min, WC.sideW, sh, perimDk, 'east');
                    add(esg);
                }
            }
            // South face overlay (perimeter — hub style)
            if (!skipWalls.has('south')) {
                const southSegs = this._splitWallSegments(x, x + w, wallGaps.south);
                for (const seg of southSegs) {
                    const sw = seg.max - seg.min;
                    const sfg = this.add.graphics().setDepth(botD + 0.05);
                    WallRenderer.steel(sfg, seg.min, y + h - WC.frontH, sw, WC.frontH, perimDk, 'south');
                    southParts.push(sfg);
                }
            }
        }
        
        // Track south wall parts for room visibility toggling
        if (!this._southWallParts) this._southWallParts = {};
        this._southWallParts[room.id] = southParts;
    }
    
    // ═══════════════════════════════════════════════════════
    // ROOM FLOOR DETAIL — unique floor per room theme
    // ═══════════════════════════════════════════════════════
    _renderRoomFloor(room, add) {
        const fn = {
            hub: '_floorHub', containment: '_floorContainment', bedroom: '_floorBedroom',
            armory: '_floorArmory', barracks: '_floorBarracks', garage: '_floorGarage'
        }[room.id];
        if (fn && this[fn]) this[fn](room, add);
    }
    
    _floorHub(room, add) {
        const g = this.add.graphics().setDepth(1.1);
        FloorRenderer.steelPlate(g, room.x, room.y, room.w, room.h, room.floor);
        add(g);
    }
    _floorContainment(room, add) {
        const g = this.add.graphics().setDepth(1.1);
        FloorRenderer.sealedLab(g, room.x, room.y, room.w, room.h, room.floor);
        add(g);
    }
    _floorBedroom(room, add) {
        const g = this.add.graphics().setDepth(1.1);
        FloorRenderer.hardwood(g, room.x, room.y, room.w, room.h, room.floor, room.floorAlt);
        add(g);
    }
    _floorArmory(room, add) {
        const g = this.add.graphics().setDepth(1.1);
        const { x, y, w, h, floor } = room;
        const cyan = 0x2288aa;
        
        // Base: smooth dark floor
        g.fillStyle(floor, 0.6);
        g.fillRect(x, y, w, h);
        
        // Grid lines — faint cyan, tight spacing for digital feel
        g.lineStyle(1, cyan, 0.06);
        const gridStep = 16;
        for (let gx = x + gridStep; gx < x + w; gx += gridStep) {
            g.beginPath(); g.moveTo(gx, y); g.lineTo(gx, y + h); g.stroke();
        }
        for (let gy = y + gridStep; gy < y + h; gy += gridStep) {
            g.beginPath(); g.moveTo(x, gy); g.lineTo(x + w, gy); g.stroke();
        }
        
        // Brighter grid ring around center (neural interface focal area)
        const cx = x + w/2, cy = y + h/2 + 10;
        const ringR = 36;
        g.lineStyle(1, cyan, 0.12);
        g.strokeCircle(cx, cy, ringR);
        g.lineStyle(1, cyan, 0.06);
        g.strokeCircle(cx, cy, ringR + 8);
        g.strokeCircle(cx, cy, ringR - 8);
        
        // Cross hairs through center
        g.lineStyle(1, cyan, 0.08);
        g.beginPath(); g.moveTo(cx - ringR - 12, cy); g.lineTo(cx + ringR + 12, cy); g.stroke();
        g.beginPath(); g.moveTo(cx, cy - ringR - 12); g.lineTo(cx, cy + ringR + 12); g.stroke();
        
        // Corner data nodes — small bright dots at grid intersections near corners
        [[x + gridStep, y + gridStep], [x + w - gridStep, y + gridStep],
         [x + gridStep, y + h - gridStep], [x + w - gridStep, y + h - gridStep]].forEach(([nx, ny]) => {
            g.fillStyle(cyan, 0.15);
            g.fillCircle(nx, ny, 2);
            g.fillStyle(cyan, 0.05);
            g.fillCircle(nx, ny, 5);
        });
        
        // Data stream traces — thin bright lines along specific grid paths
        g.lineStyle(1, 0x44ddff, 0.07);
        g.beginPath(); g.moveTo(x + gridStep, y + gridStep * 3); g.lineTo(x + w/2 - ringR, y + gridStep * 3); g.stroke();
        g.beginPath(); g.moveTo(x + w - gridStep, y + h - gridStep * 2); g.lineTo(x + w/2 + ringR, y + h - gridStep * 2); g.stroke();
        
        add(g);
    }
    _floorBarracks(room, add) {
        const g = this.add.graphics().setDepth(1.1);
        FloorRenderer.bareConcrete(g, room.x, room.y, room.w, room.h, room.floor);
        // Room-specific: faded walkway lines + dust
        g.lineStyle(3, 0x999944, 0.18);
        g.beginPath(); g.moveTo(room.x + 18, room.y + 4); g.lineTo(room.x + 18, room.y + room.h - 4); g.stroke();
        g.beginPath(); g.moveTo(room.x + room.w - 18, room.y + 4); g.lineTo(room.x + room.w - 18, room.y + room.h - 4); g.stroke();
        g.fillStyle(IsoRenderer.lighten(room.floor, 0.05), 0.18);
        g.fillEllipse(room.x + 14, room.y + 12, 30, 18);
        g.fillEllipse(room.x + room.w - 14, room.y + room.h - 12, 28, 16);
        add(g);
    }
    _floorGarage(room, add) {
        const g = this.add.graphics().setDepth(1.1);
        FloorRenderer.workshopConcrete(g, room.x, room.y, room.w, room.h, room.floor);
        add(g);
    }
    
    // ═══════════════════════════════════════════════════════
    // EXTERIOR — terrain, building shell, horizon, road
    // ═══════════════════════════════════════════════════════
    createExterior() {
        // Track all objects created by this method for rebuild on ToD change
        const beforeCount = this.children.list.length;
        
        const W = 1000, H = 1800;
        const tod = CONFIG.timeOfDay || 'midday';
        
        // ── Biome-driven palette ──
        const biomeId = (this.saveData && this.saveData.biome) || 'grassy';
        const biome = BIOMES[biomeId] || BIOMES.grassy;
        
        // Sky colors per time-of-day, tinted by biome
        const skyMap = { dawn: biome.skyDawn || 0xffaa77, midday: biome.sky, dusk: biome.skyDusk || 0xff7755, night: biome.skyNight || 0x0a0a1e };
        const skyLowMap = { dawn: IsoRenderer.lighten(skyMap.dawn, 0.15), midday: biome.skyLow, dusk: IsoRenderer.lighten(skyMap.dusk, 0.15), night: 0x141428 };
        const sky = skyMap[tod] || skyMap.midday;
        const skyB = skyLowMap[tod] || skyLowMap.midday;
        
        // Mountain colors
        const mtCol = tod === 'night' ? IsoRenderer.darken(biome.mountain, 0.4) : biome.mountain;
        
        // Ground color per time-of-day
        const gColMap = { dawn: IsoRenderer.lighten(biome.ground, 0.05), midday: biome.ground, dusk: IsoRenderer.darken(biome.ground, 0.05), night: IsoRenderer.darken(biome.ground, 0.3) };
        const gCol = gColMap[tod] || gColMap.midday;
        
        // ── Building footprint computed from actual ROOMS ──
        const margin = 12;
        const roomList = Object.values(this.ROOMS);
        
        // Main block = everything except garage
        const mainRooms = roomList.filter(r => r.id !== 'garage');
        const garageRoom = this.ROOMS.garage;
        
        const upperLeft  = Math.min(...mainRooms.map(r => r.x)) - margin;
        const upperRight = Math.max(...mainRooms.map(r => r.x + r.w)) + margin;
        const upperTop   = Math.min(...mainRooms.map(r => r.y)) - margin;
        const upperBot   = Math.max(...mainRooms.map(r => r.y + r.h)) + margin;
        
        const lowerLeft  = garageRoom.x - margin;
        const lowerRight = garageRoom.x + garageRoom.w + margin;
        const lowerTop   = upperBot;
        const lowerBot   = garageRoom.y + garageRoom.h + margin;
        
        // Notch = bottom-right open area (garage east → building right)
        const notchLeft = lowerRight, notchRight = upperRight;
        const notchTop = lowerTop, notchBot = lowerBot;
        
        // ─── PARALLAX LANDSCAPE BACKGROUND ───
        const horizonY = 380;
        this._parallaxLayers = ParallaxBG.createForSafehouse(this, biomeId, tod);
        
        // ─── GROUND TERRAIN ───
        // Fill below horizon
        this.add.rectangle(W/2, (horizonY + H) / 2, W, H - horizonY, gCol).setDepth(0.2);
        
        // Ground patches (biome-tinted)
        const grassG = this.add.graphics().setDepth(0.3);
        const grassDk = IsoRenderer.darken(biome.groundAccent, 0.1);
        for (let i = 0; i < 60; i++) {
            const zone = Phaser.Math.Between(0, 3);
            let gx, gy;
            if (zone === 0) {
                gx = Phaser.Math.Between(20, W - 20); gy = Phaser.Math.Between(horizonY, upperTop - 5);
            } else if (zone === 1) {
                gx = Phaser.Math.Between(20, W - 20); gy = Phaser.Math.Between(lowerBot + 5, H - 20);
            } else if (zone === 2) {
                gx = Phaser.Math.Between(10, upperLeft - 5); gy = Phaser.Math.Between(upperTop, lowerBot);
            } else {
                gx = Phaser.Math.Between(notchLeft, W - 10); gy = Phaser.Math.Between(notchTop, notchBot);
            }
            grassG.fillStyle(grassDk, Phaser.Math.FloatBetween(0.2, 0.5));
            grassG.fillEllipse(gx, gy, Phaser.Math.Between(8, 25), Phaser.Math.Between(5, 14));
        }
        
        // ─── L-SHAPED ROOF ───
        const roofCol = { dawn: 0x4a4440, midday: 0x4a4a48, dusk: 0x4a3a30, night: 0x2a2a28 };
        const rCol = roofCol[tod] || roofCol.midday;
        
        // Upper block roof
        const uW = upperRight - upperLeft, uH = upperBot - upperTop;
        const uCX = (upperLeft + upperRight) / 2, uCY = (upperTop + upperBot) / 2;
        const upperRoof = this.add.rectangle(uCX, uCY - 4, uW, uH, rCol, 0.7).setDepth(0.5);
        
        // Lower block roof (garage wing)
        const lW = lowerRight - lowerLeft, lH = lowerBot - lowerTop;
        const lCX = (lowerLeft + lowerRight) / 2, lCY = (lowerTop + lowerBot) / 2;
        const lowerRoof = this.add.rectangle(lCX, lCY - 4, lW, lH, rCol, 0.7).setDepth(0.5);
        
        // Roof panel lines
        const roofG = this.add.graphics().setDepth(0.55);
        
        // Store for departure cinematic
        this._roofElements = [upperRoof, lowerRoof, roofG];
        
        // ─── INTERIOR FOUNDATION (steel fill under roof — covers entire footprint) ───
        const voidCol = 0x22222a;
        this.add.rectangle(uCX, uCY - 4, uW, uH, voidCol).setDepth(0.9);
        this.add.rectangle(lCX, lCY - 4, lW, lH, voidCol).setDepth(0.9);
        
        roofG.lineStyle(1, IsoRenderer.darken(rCol, 0.15), 0.3);
        for (let ry = upperTop + 30; ry < upperBot - 10; ry += 40) {
            roofG.beginPath(); roofG.moveTo(upperLeft + 5, ry); roofG.lineTo(upperRight - 5, ry); roofG.stroke();
        }
        for (let ry = lowerTop + 20; ry < lowerBot - 10; ry += 40) {
            roofG.beginPath(); roofG.moveTo(lowerLeft + 5, ry); roofG.lineTo(lowerRight - 5, ry); roofG.stroke();
        }
        
        // ─── DIRT DRIVEWAY (exits east from garage — connects to interior) ───
        const roadY = garageRoom.y + garageRoom.h / 2; // centered on garage
        const roadH = garageRoom.h * 0.6; // wide enough to feel connected
        const roadStartX = garageRoom.x + garageRoom.w - 10; // overlap into wall edge
        const roadEndX = W + 20;
        
        // Packed dirt base
        this.add.rectangle((roadStartX + roadEndX) / 2, roadY, roadEndX - roadStartX, roadH,
            0x4a3e2e, 0.85).setDepth(0.4);
        
        // Dirt apron at garage exit (wider, compacted)
        this.add.rectangle(roadStartX + 18, roadY, 44, roadH + 24, 0x3e3428, 0.7).setDepth(0.39);
        
        const roadG = this.add.graphics().setDepth(0.45);
        
        // Tire ruts (two parallel grooves)
        const rutOffset = 10;
        roadG.fillStyle(0x3a3020, 0.4);
        roadG.fillRect(roadStartX + 30, roadY - rutOffset - 2, roadEndX - roadStartX - 40, 3);
        roadG.fillRect(roadStartX + 30, roadY + rutOffset - 1, roadEndX - roadStartX - 40, 3);
        // Rut shadows (darker inside)
        roadG.fillStyle(0x2a2218, 0.3);
        roadG.fillRect(roadStartX + 30, roadY - rutOffset - 1, roadEndX - roadStartX - 40, 1.5);
        roadG.fillRect(roadStartX + 30, roadY + rutOffset, roadEndX - roadStartX - 40, 1.5);
        
        // Gravel scatter
        for (let i = 0; i < 40; i++) {
            const gx = Phaser.Math.Between(roadStartX + 10, roadEndX - 10);
            const gy = roadY + Phaser.Math.Between(-roadH/2 + 3, roadH/2 - 3);
            const gs = Phaser.Math.FloatBetween(0.5, 2);
            const gc = Phaser.Utils.Array.GetRandom([0x5a5044, 0x6a5e4e, 0x4a4438, 0x786a56]);
            roadG.fillStyle(gc, Phaser.Math.FloatBetween(0.2, 0.5));
            roadG.fillCircle(gx, gy, gs);
        }
        
        // Road edges — eroded dirt border
        roadG.lineStyle(1.5, 0x3a3428, 0.35);
        roadG.beginPath(); roadG.moveTo(roadStartX, roadY - roadH/2);
        for (let ex = roadStartX; ex < roadEndX; ex += 15) {
            roadG.lineTo(ex, roadY - roadH/2 + Phaser.Math.FloatBetween(-1.5, 1.5));
        }
        roadG.stroke();
        roadG.beginPath(); roadG.moveTo(roadStartX, roadY + roadH/2);
        for (let ex = roadStartX; ex < roadEndX; ex += 15) {
            roadG.lineTo(ex, roadY + roadH/2 + Phaser.Math.FloatBetween(-1.5, 1.5));
        }
        roadG.stroke();
        
        // Weeds encroaching from edges
        for (let i = 0; i < 12; i++) {
            const wx = Phaser.Math.Between(roadStartX + 40, roadEndX - 30);
            const side = Phaser.Utils.Array.GetRandom([-1, 1]);
            const wy = roadY + side * (roadH/2 - Phaser.Math.Between(0, 6));
            roadG.fillStyle(0x3a5a2a, Phaser.Math.FloatBetween(0.15, 0.35));
            roadG.fillEllipse(wx, wy, Phaser.Math.Between(4, 10), Phaser.Math.Between(3, 6));
        }
        
        // Puddle patches (dark wet spots)
        [roadStartX + 80, roadStartX + 180, roadStartX + 290].forEach(px => {
            const pw = Phaser.Math.Between(12, 22);
            const ph = Phaser.Math.Between(6, 12);
            const py = roadY + Phaser.Math.Between(-6, 6);
            roadG.fillStyle(0x2a2820, 0.2);
            roadG.fillEllipse(px, py, pw, ph);
            roadG.fillStyle(0x3a3a38, 0.1);
            roadG.fillEllipse(px + 2, py - 1, pw - 4, ph - 3);
        });
        
        // ─── EXTERIOR DETAILS ───
        const rockPositions = [
            { rx: upperLeft - 25, ry: upperTop + 60 },
            { rx: upperRight + 20, ry: upperTop + 100 },
            { rx: 80, ry: upperTop + 200 },
            { rx: notchLeft + 40, ry: notchBot - 30 },
            { rx: roadEndX - 200, ry: roadY + 50 },
        ];
        rockPositions.forEach(({ rx, ry }) => {
            const rw = Phaser.Math.Between(10, 20), rh = Phaser.Math.Between(6, 12);
            const rockCol = IsoRenderer.darken(gCol, 0.15);
            this.add.ellipse(rx, ry - rh * 0.3, rw, rh * 0.5, IsoRenderer.lighten(rockCol, 0.1), 0.7).setDepth(0.7);
            this.add.ellipse(rx, ry, rw, rh, rockCol, 0.7).setDepth(0.65);
        });
        
        // Antenna on upper roof
        const antX = upperLeft + 30, antY = upperTop + 20;
        this.add.rectangle(antX, antY - 20, 2, 40, 0x666666, 0.5).setDepth(0.8);
        this.add.rectangle(antX, antY - 38, 8, 2, 0x555555, 0.5).setDepth(0.8);
        const antLight = this.add.circle(antX, antY - 40, 2, 0xcc3333, 0.7).setDepth(0.85);
        this.tweens.add({ targets: antLight, alpha: 0.1, duration: 800, yoyo: true, repeat: -1 });
        
        // Power pole near road
        const poleX = roadStartX + 120, poleY = roadY - 50;
        this.add.rectangle(poleX, poleY - 15, 3, 50, 0x555544, 0.5).setDepth(0.8);
        this.add.rectangle(poleX, poleY - 38, 14, 2, 0x555544, 0.4).setDepth(0.8);
        const plG = this.add.graphics().setDepth(0.75);
        plG.lineStyle(1, 0x444444, 0.3);
        plG.beginPath(); plG.moveTo(antX + 4, antY - 37);
        plG.lineTo((antX + poleX) / 2, antY - 30);
        plG.lineTo(poleX, poleY - 37); plG.stroke();
        plG.beginPath(); plG.moveTo(poleX + 7, poleY - 37);
        plG.lineTo(W + 20, poleY - 25); plG.stroke();
        
        // Store all new objects created during this method for ToD rebuild
        this._extObjs = this.children.list.slice(beforeCount);
    }
    
    _rebuildExterior() {
        // Destroy all exterior objects and recreate with current ToD
        if (this._extObjs) {
            this._extObjs.forEach(o => { try { if (o && o.destroy) o.destroy(); } catch(e) {} });
            this._extObjs = [];
        }
        // Also destroy roof elements tracked separately
        if (this._roofElements) {
            this._roofElements.forEach(o => { try { if (o && o.destroy) o.destroy(); } catch(e) {} });
            this._roofElements = [];
        }
        // Destroy parallax layers
        if (this._parallaxLayers) {
            ParallaxBG.destroy(this._parallaxLayers);
            this._parallaxLayers = null;
        }
        // Also rebuild time-of-day overlay
        if (this._todOverlay) { try { this._todOverlay.destroy(); } catch(e) {} this._todOverlay = null; }
        
        this.createExterior();
        this.createTimeOfDayOverlay();
        this.updateSafehouseTime();
    }
    // ═══════════════════════════════════════════════════════
    // OPENINGS — gaps in walls between connected rooms
    // ═══════════════════════════════════════════════════════
    // === CONNECTOR SIZE CONFIGS (stored for future module building system) ===
    static CONNECTOR_SIZES = {
        small:  { doorW: 24, label: 'Personnel',  grateSpacing: 5, pipes: 0 },
        medium: { doorW: 36, label: 'Utility',     grateSpacing: 6, pipes: 1 },
        large:  { doorW: 56, label: 'Cargo/Vehicle', grateSpacing: 7, pipes: 2 }
    };
    
    // Neutral connector palette — distinct from any room
    static CONNECTOR_PALETTE = {
        base: 0x222230, dk: 0x1a1a28, lt: 0x2e2e3e,
        edge: 0x141420, hi: 0x3a3a4a, floor: 0x16161e,
        void: 0x0e0e14, pipe: 0x2e2e38, pipeHi: 0x3a3a48
    };
    
    createOpenings() {
        const WC = this._wallConst;
        this._openings = [];
        this._isoDoors = []; // Track door objects for proximity detection
        const builtPairs = new Set(); // Avoid building duplicate doors for same connection
        
        for (const room of Object.values(this.ROOMS)) {
            if (!room.doors) continue;
            for (const door of room.doors) {
                const targetRoom = this.ROOMS[door.target];
                if (!targetRoom) continue;
                
                const sizeKey = door.size || 'small';
                const sizeConf = SafehouseScene.CONNECTOR_SIZES[sizeKey];
                const DOOR_W = sizeConf.doorW;
                
                let ox, oy, ow, oh;
                if (door.wall === 'west') {
                    // Flush rooms: door sits IN the hub's west wall (sideW thick)
                    ox = room.x;
                    oy = room.y + room.h * door.pos - DOOR_W/2;
                    ow = WC.sideW;
                    oh = DOOR_W;
                } else if (door.wall === 'east') {
                    ox = room.x + room.w - WC.sideW;
                    oy = room.y + room.h * door.pos - DOOR_W/2;
                    ow = WC.sideW;
                    oh = DOOR_W;
                } else if (door.wall === 'south') {
                    ox = room.x + room.w * door.pos - DOOR_W/2;
                    oy = room.y + room.h - WC.frontH - WC.topH;
                    ow = DOOR_W;
                    oh = WC.frontH + WC.topH;
                } else if (door.wall === 'north') {
                    ox = room.x + room.w * door.pos - DOOR_W/2;
                    oy = room.y;
                    ow = DOOR_W;
                    oh = WC.frontH + WC.topH;
                } else continue;
                
                // Build isometric door (only once per connection)
                const pairKey = [room.id, door.target].sort().join(':');
                if (!builtPairs.has(pairKey)) {
                    builtPairs.add(pairKey);
                    this._buildIsoDoor(ox, oy, ow, oh, door.wall, room, targetRoom, WC);
                }
                
                this._openings.push({
                    roomId: room.id, targetRoom: door.target,
                    wall: door.wall, size: sizeKey,
                    x: ox, y: oy, w: ow, h: oh
                });
            }
        }
    }
    
    // Reusable connector builder — works for any size
    _buildConnector(ox, oy, ow, oh, wall, sizeConf, WC) {
        const isHoriz = (wall === 'west' || wall === 'east');
        const CON = SafehouseScene.CONNECTOR_PALETTE;
        
        // Dark fill + floor
        this.add.rectangle(ox + ow/2, oy + oh/2, ow + 2, oh + 2, CON.void).setDepth(1);
        this.add.rectangle(ox + ow/2, oy + oh/2, ow, oh, CON.floor).setDepth(1.5);
        
        // Floor grate lines
        const cfg = this.add.graphics().setDepth(1.6);
        const gs = sizeConf.grateSpacing;
        if (isHoriz) {
            for (let gi = ox + 4; gi < ox + ow; gi += gs) {
                cfg.fillStyle(CON.void, 0.4);
                cfg.fillRect(gi, oy + 2, 1, oh - 4);
            }
            // Center rail for medium+
            if (sizeConf.pipes >= 1) {
                cfg.fillStyle(CON.pipe, 0.5);
                cfg.fillRect(ox, oy + oh/2 - 0.5, ow, 1);
            }
        } else {
            for (let gi = oy + 4; gi < oy + oh; gi += gs) {
                cfg.fillStyle(CON.void, 0.4);
                cfg.fillRect(ox + 2, gi, ow - 4, 1);
            }
            if (sizeConf.pipes >= 1) {
                cfg.fillStyle(CON.pipe, 0.5);
                cfg.fillRect(ox + ow/2 - 0.5, oy, 1, oh);
            }
        }
        
        // Pipe runs along walls (scale with size)
        if (sizeConf.pipes >= 1) {
            const pfg = this.add.graphics().setDepth(1.7);
            if (isHoriz) {
                // Pipe along north interior wall
                pfg.fillStyle(CON.pipe, 0.5);
                pfg.fillRect(ox + 2, oy + 3, ow - 4, 2);
                pfg.fillStyle(CON.pipeHi, 0.25);
                pfg.fillRect(ox + 2, oy + 3, ow - 4, 1);
                // Pipe along south interior wall
                pfg.fillStyle(CON.pipe, 0.5);
                pfg.fillRect(ox + 2, oy + oh - 5, ow - 4, 2);
                pfg.fillStyle(CON.pipeHi, 0.25);
                pfg.fillRect(ox + 2, oy + oh - 5, ow - 4, 1);
            } else {
                pfg.fillStyle(CON.pipe, 0.5);
                pfg.fillRect(ox + 3, oy + 2, 2, oh - 4);
                pfg.fillStyle(CON.pipeHi, 0.25);
                pfg.fillRect(ox + 3, oy + 2, 1, oh - 4);
                pfg.fillStyle(CON.pipe, 0.5);
                pfg.fillRect(ox + ow - 5, oy + 2, 2, oh - 4);
                pfg.fillStyle(CON.pipeHi, 0.25);
                pfg.fillRect(ox + ow - 5, oy + 2, 1, oh - 4);
            }
        }
        // Dual pipe runs for large
        if (sizeConf.pipes >= 2) {
            const pfg2 = this.add.graphics().setDepth(1.7);
            if (isHoriz) {
                const thirdH = oh / 3;
                pfg2.fillStyle(CON.pipe, 0.4);
                pfg2.fillRect(ox + 2, oy + thirdH - 1, ow - 4, 2);
                pfg2.fillRect(ox + 2, oy + thirdH * 2 - 1, ow - 4, 2);
            } else {
                const thirdW = ow / 3;
                pfg2.fillStyle(CON.pipe, 0.4);
                pfg2.fillRect(ox + thirdW - 1, oy + 2, 2, oh - 4);
                pfg2.fillRect(ox + thirdW * 2 - 1, oy + 2, 2, oh - 4);
            }
        }
        
        // === WALLS — iso structure matching rooms ===
        if (isHoriz) {
            // North wall
            this.add.rectangle(ox + ow/2, oy - WC.frontH - WC.topH/2, ow, WC.topH, CON.lt).setDepth(3);
            this.add.rectangle(ox + ow/2, oy - WC.frontH - WC.topH + 1, ow, 1, CON.hi, 0.4).setDepth(3.01);
            this.add.rectangle(ox + ow/2, oy - WC.frontH/2, ow, WC.frontH, CON.base).setDepth(3.1);
            for (let gi = 1; gi <= 3; gi++) {
                this.add.rectangle(ox + ow/2, oy - WC.frontH + WC.frontH * (gi/4), ow, 1, CON.dk, 0.3).setDepth(3.11);
            }
            this.add.rectangle(ox + ow/2, oy, ow, 2, CON.edge).setDepth(3.12);
            
            // South wall — Y-based depth
            const sY = oy + oh;
            const sD = 10 + (sY + WC.frontH) * 0.01;
            const csParts = [];
            csParts.push(this.add.rectangle(ox + ow/2, sY + WC.topH/2, ow, WC.topH, CON.base).setDepth(sD + 0.01));
            csParts.push(this.add.rectangle(ox + ow/2, sY + 1, ow, 1, CON.hi, 0.3).setDepth(sD + 0.02));
            csParts.push(this.add.rectangle(ox + ow/2, sY + WC.topH + WC.frontH/2, ow, WC.frontH, CON.dk).setDepth(sD));
            for (let gi = 1; gi <= 3; gi++) {
                csParts.push(this.add.rectangle(ox + ow/2, sY + WC.topH + WC.frontH * (gi/4), ow, 1, CON.edge, 0.3).setDepth(sD + 0.03));
            }
            if (!this._occlusionWalls) this._occlusionWalls = [];
            this._occlusionWalls.push({
                parts: csParts, facing: 'south', cx: ox + ow/2,
                groundY: sY + WC.topH + WC.frontH, w: ow,
                left: ox - 1, right: ox + ow + 1,
                visualTop: sY, visualBot: sY + WC.topH + WC.frontH,
                roomId: null
            });
        } else {
            // West wall
            this.add.rectangle(ox - WC.sideW/2, oy + oh/2, WC.sideW, oh, CON.dk).setDepth(5);
            this.add.rectangle(ox - WC.sideSliver/2, oy + oh/2, WC.sideSliver, oh, CON.base, 0.5).setDepth(5.01);
            this.add.rectangle(ox - WC.sideW + 0.5, oy + oh/2, 1, oh, CON.edge, 0.5).setDepth(5.01);
            // East wall
            this.add.rectangle(ox + ow + WC.sideW/2, oy + oh/2, WC.sideW, oh, CON.dk).setDepth(5);
            this.add.rectangle(ox + ow + WC.sideSliver/2, oy + oh/2, WC.sideSliver, oh, CON.base, 0.5).setDepth(5.01);
            this.add.rectangle(ox + ow + WC.sideW - 0.5, oy + oh/2, 1, oh, CON.edge, 0.5).setDepth(5.01);
        }
    }
    
    // Isometric door — sits in wall gap, slides up on proximity
    _buildIsoDoor(ox, oy, ow, oh, wall, sourceRoom, targetRoom, WC) {
        const isHoriz = (wall === 'west' || wall === 'east');
        const cx = ox + ow/2, cy = oy + oh/2;
        
        // Door theme: use hub wall color for all doors (consistent structural look)
        const hubWall = this.ROOMS.hub.wall;
        const wallColor = hubWall;
        const wallDk = IsoRenderer.darken(wallColor, 0.15);
        const wallLt = IsoRenderer.lighten(wallColor, 0.1);
        const wallEdge = IsoRenderer.darken(wallColor, 0.25);
        const wallHi = IsoRenderer.lighten(wallColor, 0.2);
        const metalDk = IsoRenderer.darken(wallColor, 0.3);
        const metalLt = IsoRenderer.lighten(wallColor, 0.05);
        
        // Floor patch behind door (visible when door opens, covers any void)
        const floorColor = targetRoom.floor || 0x2a2a2e;
        this.add.rectangle(cx, cy, ow + 2, oh + 2, floorColor).setDepth(1.2);
        // Subtle threshold strip on floor
        this.add.rectangle(cx, cy, isHoriz ? 2 : (oh + 2), isHoriz ? (oh + 2) : 2, IsoRenderer.darken(floorColor, 0.2), 0.5).setDepth(1.3);
        
        // Door panel — built as TWO faces for isometric swing animation
        const doorD = isHoriz ? 5.5 : (10 + cy * 0.01 + 0.1);
        
        // === Indicator light — red when closed, green when open ===
        let indicatorLight;
        if (isHoriz) {
            // Light above door on the side wall face
            const lx = cx;
            const ly = oy - 4;
            indicatorLight = this.add.circle(lx, ly, 2, 0xcc2222).setDepth(doorD + 0.5);
            // Glow around indicator
            this.add.circle(lx, ly, 4, 0xcc2222, 0.15).setDepth(doorD + 0.49);
        } else {
            // Light above door on the front wall face
            const lx = ox + ow / 2;
            const ly = (wall === 'south') ? (oy + oh - WC.frontH - WC.topH - 4) : (oy + WC.frontH + WC.topH + 4);
            indicatorLight = this.add.circle(lx, ly, 2, 0xcc2222).setDepth(doorD + 0.5);
            this.add.circle(lx, ly, 4, 0xcc2222, 0.15).setDepth(doorD + 0.49);
        }
        
        if (isHoriz) {
            // === SIDE WALL DOOR (E/W) ===
            const panelW = WC.sideW;
            const panelH = oh;
            
            const doorContainer = this.add.container(cx, oy).setDepth(doorD);
            
            // -- closedFace: side face (what you see when door is flush with wall) --
            const closedFace = this.add.container(0, 0);
            closedFace.add(this.add.rectangle(0, panelH/2, panelW, panelH, wallDk));
            for (let i = 1; i <= 2; i++) {
                closedFace.add(this.add.rectangle(0, panelH * (i/3), panelW, 1, wallEdge, 0.15));
            }
            if (wall === 'east') {
                closedFace.add(this.add.rectangle(-panelW/2 + WC.sideSliver/2, panelH/2, WC.sideSliver, panelH, wallColor, 0.5));
                closedFace.add(this.add.rectangle(panelW/2 - 0.5, panelH/2, 1, panelH, wallEdge, 0.5));
            } else {
                closedFace.add(this.add.rectangle(panelW/2 - WC.sideSliver/2, panelH/2, WC.sideSliver, panelH, wallColor, 0.5));
                closedFace.add(this.add.rectangle(-panelW/2 + 0.5, panelH/2, 1, panelH, wallEdge, 0.5));
            }
            closedFace.add(this.add.rectangle(0, panelH/2 + 2, panelW - 2, 2, metalDk));
            closedFace.add(this.add.rectangle(0, panelH/2 + 1, panelW - 3, 1, metalLt, 0.5));
            closedFace.add(this.add.circle(-panelW/2 + 1, 3, 1.5, metalLt, 0.6));
            closedFace.add(this.add.circle(panelW/2 - 1, 3, 1.5, metalLt, 0.6));
            doorContainer.add(closedFace);
            
            // -- openFace: front face visible when door swings 90° --
            const openFace = this.add.container(0, 0);
            const openW = panelH * 0.18;
            const openDir = (wall === 'west') ? -1 : 1;
            openFace.add(this.add.rectangle(openDir * openW/2, 2, openW, panelW, wallColor));
            openFace.add(this.add.rectangle(openDir * openW/2, 2, openW, 1, wallEdge, 0.3));
            openFace.add(this.add.rectangle(openDir * openW/2, 2 - panelW/2, openW, 1, wallLt, 0.5));
            openFace.add(this.add.rectangle(openDir * (openW * 0.3), 2, 2, panelW - 2, metalDk, 0.7));
            openFace.setAlpha(0);
            doorContainer.add(openFace);
            
            this._isoDoors.push({
                container: doorContainer,
                closedFace: closedFace, openFace: openFace,
                indicator: indicatorLight,
                cx: cx, cy: cy,
                isOpen: false, isAnimating: false,
                wall: wall, axis: 'scaleY',
                sourceRoom: sourceRoom.id, targetRoom: targetRoom.id
            });
            
        } else {
            // === FRONT WALL DOOR (N/S) ===
            const panelW = ow;
            const panelH = WC.frontH;
            const doorY = (wall === 'south') ? (oy + oh - WC.frontH/2) : (oy + WC.frontH/2);
            const faceColor = (wall === 'south') ? wallDk : wallColor;
            
            const doorContainer = this.add.container(ox, doorY).setDepth(doorD);
            
            // -- closedFace: front face --
            const closedFace = this.add.container(0, 0);
            closedFace.add(this.add.rectangle(panelW/2, 0, panelW, panelH, faceColor));
            for (let i = 1; i <= 3; i++) {
                closedFace.add(this.add.rectangle(panelW/2, -panelH/2 + panelH * (i/4), panelW, 1, wallEdge, 0.3));
            }
            closedFace.add(this.add.rectangle(panelW/2, panelH/2 - 1, panelW, 2, wallEdge));
            closedFace.add(this.add.rectangle(panelW/2, -panelH/2 - WC.topH/2, panelW, WC.topH, wallLt));
            closedFace.add(this.add.rectangle(panelW/2, -panelH/2 - WC.topH + 1, panelW, 1, wallHi, 0.3));
            closedFace.add(this.add.rectangle(panelW/2, 2, panelW * 0.35, 2, metalDk));
            closedFace.add(this.add.rectangle(panelW/2, 1, panelW * 0.35, 1, metalLt, 0.5));
            closedFace.add(this.add.circle(2, -panelH/3, 1.5, metalLt, 0.6));
            closedFace.add(this.add.circle(2, panelH/3, 1.5, metalLt, 0.6));
            doorContainer.add(closedFace);
            
            // -- openFace: side face visible when door swings 90° --
            const openFace = this.add.container(0, 0);
            const openSW = WC.sideW;
            openFace.add(this.add.rectangle(openSW/2, 0, openSW, panelH, wallDk));
            openFace.add(this.add.rectangle(openSW - WC.sideSliver/2, 0, WC.sideSliver, panelH, wallColor, 0.5));
            openFace.add(this.add.rectangle(1, 0, 1, panelH, wallEdge, 0.5));
            openFace.add(this.add.rectangle(openSW/2, 2, openSW - 2, 2, metalDk, 0.6));
            openFace.setAlpha(0);
            doorContainer.add(openFace);
            
            this._isoDoors.push({
                container: doorContainer,
                closedFace: closedFace, openFace: openFace,
                indicator: indicatorLight,
                cx: cx, cy: cy,
                isOpen: false, isAnimating: false,
                wall: wall, axis: 'scaleX',
                sourceRoom: sourceRoom.id, targetRoom: targetRoom.id
            });
        }
    }
    
    // Build collision bounds for entire building (all rooms + openings)
    buildCollisionBounds() {
        const WC = this._wallConst;
        // Walkable rectangles: one per room interior + one per opening corridor
        this._walkableRects = [];
        
        for (const room of Object.values(this.ROOMS)) {
            // Determine which walls this room skips (shared with hub)
            const skip = new Set();
            if (room.doors) {
                for (const d of room.doors) {
                    if (d.target === 'hub') skip.add(d.wall);
                }
            }
            const wallInset = WC.topH + WC.frontH + 2;
            this._walkableRects.push({
                left:   room.x + WC.sideW + 2,
                right:  room.x + room.w - WC.sideW - 2,
                top:    skip.has('north') ? room.y + 2 : room.y + wallInset,
                bottom: skip.has('south') ? room.y + room.h - 2 : room.y + room.h - wallInset,
                roomId: room.id
            });
        }
        
        // Opening corridors are also walkable — expanded generously to bridge
        // both rooms' walkable areas. Must cover full wall thickness on each side.
        // Also expand perpendicular axis by 6px for comfortable player passage.
        for (const op of this._openings) {
            const isHorizontal = (op.wall === 'west' || op.wall === 'east');
            const bridgeExpand = WC.sideW + WC.frontH; // 32px: covers wall+gap on each side
            const perpExpand = 6; // comfort zone perpendicular to door
            this._walkableRects.push({
                left:   op.x - (isHorizontal ? bridgeExpand : perpExpand),
                right:  op.x + op.w + (isHorizontal ? bridgeExpand : perpExpand),
                top:    op.y - (isHorizontal ? perpExpand : bridgeExpand),
                bottom: op.y + op.h + (isHorizontal ? perpExpand : bridgeExpand),
                roomId: null
            });
        }
        
        // Build wall colliders — thin blocking rects along each room wall
        // with gaps cut where openings exist
        this._wallColliders = [];
        const WALL_THICK = 6;
        
        for (const room of Object.values(this.ROOMS)) {
            const rx = room.x, ry = room.y, rw = room.w, rh = room.h;
            
            // Collect opening positions on each wall of this room
            const openingsOnWall = { west: [], east: [], north: [], south: [] };
            if (room.doors) {
                for (const door of room.doors) {
                    const DOOR_W = (SafehouseScene.CONNECTOR_SIZES[door.size || 'small'] || SafehouseScene.CONNECTOR_SIZES.small).doorW;
                    if (door.wall === 'west' || door.wall === 'east') {
                        const doorY = ry + rh * door.pos;
                        openingsOnWall[door.wall].push({ min: doorY - DOOR_W/2 - 2, max: doorY + DOOR_W/2 + 2 });
                    } else {
                        const doorX = rx + rw * door.pos;
                        openingsOnWall[door.wall].push({ min: doorX - DOOR_W/2 - 2, max: doorX + DOOR_W/2 + 2 });
                    }
                }
            }
            
            // West wall — vertical segments
            const westSegs = this._splitWallSegments(ry, ry + rh, openingsOnWall.west);
            for (const seg of westSegs) {
                this._wallColliders.push({ x: rx, y: seg.min, w: WC.sideW + 2, h: seg.max - seg.min });
            }
            
            // East wall
            const eastSegs = this._splitWallSegments(ry, ry + rh, openingsOnWall.east);
            for (const seg of eastSegs) {
                this._wallColliders.push({ x: rx + rw - WC.sideW - 2, y: seg.min, w: WC.sideW + 2, h: seg.max - seg.min });
            }
            
            // North wall — horizontal segments
            const northSegs = this._splitWallSegments(rx, rx + rw, openingsOnWall.north);
            for (const seg of northSegs) {
                this._wallColliders.push({ x: seg.min, y: ry, w: seg.max - seg.min, h: WC.topH + WC.frontH + 2 });
            }
            
            // South wall
            const southSegs = this._splitWallSegments(rx, rx + rw, openingsOnWall.south);
            for (const seg of southSegs) {
                this._wallColliders.push({ x: seg.min, y: ry + rh - WC.frontH - WC.topH - 2, w: seg.max - seg.min, h: WC.frontH + WC.topH + 2 });
            }
        }
    }
    
    // Split a wall span into segments with gaps for openings
    _splitWallSegments(wallMin, wallMax, openings) {
        if (!openings.length) return [{ min: wallMin, max: wallMax }];
        
        // Sort openings by position
        openings.sort((a, b) => a.min - b.min);
        
        const segs = [];
        let cursor = wallMin;
        for (const op of openings) {
            if (op.min > cursor) {
                segs.push({ min: cursor, max: op.min });
            }
            cursor = op.max;
        }
        if (cursor < wallMax) {
            segs.push({ min: cursor, max: wallMax });
        }
        return segs;
    }
    
    // Clamp player position to nearest walkable rect
    clampToWalkable(newX, newY) {
        // Check if position is inside any walkable rect
        for (const r of this._walkableRects) {
            if (newX >= r.left && newX <= r.right && newY >= r.top && newY <= r.bottom) {
                return { x: newX, y: newY }; // inside a valid area
            }
        }
        
        // Not inside any — clamp to the current room
        const room = this.ROOMS[this.currentRoom];
        if (!room) return { x: newX, y: newY };
        const WC = this._wallConst;
        const cr = {
            left: room.x + WC.sideW + 2,
            right: room.x + room.w - WC.sideW - 2,
            top: room.y + WC.topH + WC.frontH + 2,
            bottom: room.y + room.h - WC.frontH - WC.topH - 2
        };
        return {
            x: Phaser.Math.Clamp(newX, cr.left, cr.right),
            y: Phaser.Math.Clamp(newY, cr.top, cr.bottom)
        };
    }
    
    // Detect which room the player is in and manage visibility
    updateCurrentRoom() {
        const px = this.player.x, py = this.player.y;
        
        for (const room of Object.values(this.ROOMS)) {
            const inside = px > room.x && px < room.x + room.w &&
                           py > room.y && py < room.y + room.h;
            if (inside && room.id !== this.currentRoom) {
                const prevRoom = this.currentRoom;
                this.currentRoom = room.id;
                this.revealRoom(room.id);
                this.updateStationVisibility();
                // Show room name popup for non-hub rooms
                if (room.id !== 'hub') this._showRoomTitle(room.name);
                
                // === SHROUD TOGGLE — darken all rooms except current ===
                if (this._roomShrouds) {
                    const WC = this._wallConst;
                    const wallStrip = WC.frontH + WC.topH; // 28px south wall strip
                    
                    for (const [rid, shroud] of Object.entries(this._roomShrouds)) {
                        this.tweens.killTweensOf(shroud);
                        
                        if (rid === room.id) {
                            // Unshroud current room
                            this.tweens.add({ targets: shroud, alpha: 0, duration: 200, onComplete: () => shroud.setVisible(false) });
                        } else {
                            // Shroud other rooms
                            shroud.setVisible(true);
                            
                            // Special case: when in garage, hub shroud leaves south wall strip exposed
                            // (garage has no north wall — hub's south wall IS the visible back wall)
                            if (room.id === 'garage' && rid === 'hub') {
                                const hub = this.ROOMS.hub;
                                const trimH = hub.h - wallStrip; // shroud covers hub minus south wall strip
                                shroud.setY(hub.y + trimH / 2);
                                shroud.setDisplaySize(hub.w + 2, trimH);
                            } else {
                                // Reset to full room coverage
                                shroud.setY(shroud._origY);
                                shroud.setDisplaySize(this.ROOMS[rid].w + 2, shroud._origH);
                            }
                            
                            this.tweens.add({ targets: shroud, alpha: 0.65, duration: 300 });
                        }
                    }
                }
                break;
            }
        }
    }
    
    // Room name popup — same font/logic as Base of Operations title
    _showRoomTitle(name) {
        // Destroy previous room title if still showing
        if (this._roomTitleContainer) {
            this._roomTitleContainer.destroy();
            this._roomTitleContainer = null;
        }
        if (this._roomTitleTween) {
            this._roomTitleTween.remove();
            this._roomTitleTween = null;
        }
        
        const W = CONFIG.width;
        const D = 100; // same depth tier as HUD
        const titleY = 46;
        
        const container = GrimFont.drawText(this, W / 2, titleY, name.toUpperCase(), {
            scale: 0.45, rust: true, depth: D + 2, center: true
        });
        container.setScrollFactor(0).setAlpha(0);
        this._roomTitleContainer = container;
        
        this.tweens.add({
            targets: container, alpha: 0.85, duration: 600, ease: 'Sine.easeIn',
            onComplete: () => {
                this._roomTitleTween = this.time.delayedCall(2000, () => {
                    this.tweens.add({
                        targets: container, alpha: 0, duration: 1200, ease: 'Sine.easeOut',
                        onComplete: () => {
                            if (this._roomTitleContainer === container) {
                                container.destroy();
                                this._roomTitleContainer = null;
                            }
                        }
                    });
                });
            }
        });
    }
    
    // Room reveal — rooms are always visible now (shrouds handle darkness)
    // Kept as no-op for call sites that reference it
    revealRoom(roomId) {
        // No-op: all room containers + south wall parts are always visible
        // Shroud system handles visual darkness
    }
    
    // Stations are always visible — shrouds cover non-current rooms
    updateStationVisibility() {
        // No-op: stations render under room shrouds
    }
    
    createStations() {
        const WC = this._wallConst;
        const wallH = WC.topH + WC.frontH;
        
        this.stations = [];
        this.stationColliders = [];
        
        // ─── HUB: command center essentials ───
        this._stationRoom = 'hub';
        const hub = this.ROOMS.hub;
        const hx = hub.x, hy = hub.y, hw = hub.w, hh = hub.h;
        const hLeftX = hx + WC.sideW + 10;
        const hRightX = hx + hw - WC.sideW - 10;
        const hBackY = hy + wallH + 8;
        
        // Legacy compat — some station methods reference these
        this.offsetX = hx;
        this.offsetY = hy;
        this.roomW = hw;
        this.roomH = hh;
        
        // Computer terminal (back wall, spans full width)
        this.createComputerDeskBackWall(hx + hw/2, hBackY + 5, hw - WC.sideW * 2 - 20);
        
        // Stash crates (east wall, between doors)
        this.createStashCrates(hRightX - 6, hy + hh/2);
        
        // Loadout chest (west wall, midway — facing east into room)
        this.createLoadoutChest(hx + WC.sideW + 16, hy + hh * 0.45);
        
        // Backpack display (west wall, below chest)
        this.createBackpackDisplay(hx + WC.sideW + 16, hy + hh * 0.45 + 38);
        
        // ─── CONTAINMENT: anomaly converter ───
        this._stationRoom = 'containment';
        const cont = this.ROOMS.containment;
        this.createAnomalyConverter(cont.x + cont.w/2, cont.y + cont.h/2 - 14);
        
        // ─── BEDROOM: rest + training ───
        this._stationRoom = 'bedroom';
        const bed = this.ROOMS.bedroom;
        const bLeftX = bed.x + WC.sideW + 10;
        const bBackY = bed.y + wallH + 8;
        
        // Bed (centered on north wall, facing south)
        this.createBedWestWall(bed.x + bed.w / 2, bed.y + wallH + 30);
        
        // Gym mat + tools (south wall area)
        this.createGymStation(bed);
        
        // Locker deprecated — retained for future player customization
        // this.createLocker(bLeftX + 6, bed.y + bed.h/2 + 20);
        
        // ─── ARMORY: neural interface chair ───
        this._stationRoom = 'armory';
        const arm = this.ROOMS.armory;
        const aLeftX = arm.x + WC.sideW + 10;
        const aBackY = arm.y + wallH + 8;
        
        // Old workbench deprecated — function moved to garage right bench
        // this.createWorkbenchLeftWall(aLeftX + 16, aBackY + 25);
        
        // Neural interface chair (center of armory)
        this.createNeuralChair(arm.x + arm.w/2, arm.y + arm.h/2 + 10);
        
        // ─── GARAGE: vehicle + workbench ───
        this._stationRoom = 'garage';
        const gar = this.ROOMS.garage;
        this.createVehicleStation(gar.x + gar.w/2, gar.y + gar.h/2 + 20);
        
        // If route is locked, start vehicle idle rumble
        if (this.saveData.activeRoute && this.saveData.activeRoute.status === 'locked') {
            this.time.delayedCall(500, () => this._vehicleIgnitionRumble());
        }
        
        // Workbench interaction on right bench (north edge, east of door)
        const wbInteractX = gar.x + gar.w * 0.5 + 71;
        const wbInteractY = gar.y + 18;
        this.createGarageWorkbench(wbInteractX, wbInteractY);
        
        // Vehicle bench proximity on left bench (north edge, west of door)
        const vbInteractX = gar.x + gar.w * 0.5 - 71;
        const vbInteractY = gar.y + 18;
        this.createGarageVehicleBench(vbInteractX, vbInteractY);
        
        // === DYNAMIC SHADOWS for all stations ===
        this.stations.forEach(station => {
            if (station._handcraftedType === 'workbench_garage' || station._handcraftedType === 'vehicle_bench') return; // invisible zones
            const sy = station._handcraftedType === 'gym' ? 24 : 
                       station.config && station.config.id === 'vehicle' ? 18 :
                       station._handcraftedType === 'anomaly' ? 26 :
                       station._handcraftedType === 'neural_chair' ? 20 : 16;
            const sc = station._handcraftedType === 'gym' ? 1.3 : 
                       station.config && station.config.id === 'vehicle' ? 1.2 :
                       station._handcraftedType === 'neural_chair' ? 1.1 : 1.0;
            DynamicShadows.add(this, station, { offsetY: sy, scale: sc });
        });
    }
    
    // ═══════════════════════════════════════════════════════
    // ROOM DETAIL PROPS — non-interactive visual elements
    // ¾ iso camera: north=front wide, east/west=side dominant
    // ═══════════════════════════════════════════════════════
    createRoomProps() {
        const WC = this._wallConst;
        const wallH = WC.topH + WC.frontH;
        
        // Helper: add to room container
        const addTo = (roomId, obj) => {
            const c = this._roomContainers[roomId];
            if (c) c.add(obj);
            return obj;
        };
        
        // ─── HUB PROPS ───
        this._createHubProps(addTo, WC, wallH);
        this._createContainmentProps(addTo, WC, wallH);
        this._createBedroomProps(addTo, WC, wallH);
        this._createArmoryProps(addTo, WC, wallH);
        this._createGarageProps(addTo, WC, wallH);
        this._createBarracksProps(addTo, WC, wallH);
        this._createAllWallConsoles(addTo, WC, wallH);
        
        // ─── PROCEDURAL CEILING LIGHTS (all rooms) ───
        Object.keys(this.ROOMS).forEach(roomId => {
            this._createCeilingLight(roomId, addTo);
        });
    }
    
    // Procedural ceiling light — reads light config from room definition
    // Dual-ellipse with outer glow + inner hotspot, each with independent flicker
    _createCeilingLight(roomId, addTo) {
        const r = this.ROOMS[roomId];
        if (!r || !r.light) return;
        const L = r.light;
        const cx = r.x + r.w / 2;
        const cy = r.y + r.h * (L.pos || 0.4);
        
        // Outer glow ellipse
        const outer = this.add.ellipse(cx, cy, L.size[0], L.size[1], L.color, L.alpha[0]).setDepth(2);
        addTo(roomId, outer);
        this.tweens.add({
            targets: outer,
            alpha: { from: L.alpha[0], to: L.alpha[1] },
            scaleX: { from: L.scale[0], to: L.scale[1] },
            scaleY: { from: L.scale[0], to: L.scale[1] },
            duration: L.speed,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.inOut'
        });
        
        // Inner hotspot ellipse (brighter center)
        const inner = this.add.ellipse(cx, cy, L.inner[0], L.inner[1], L.color, L.innerAlpha[0]).setDepth(2);
        addTo(roomId, inner);
        this.tweens.add({
            targets: inner,
            alpha: { from: L.innerAlpha[0], to: L.innerAlpha[1] },
            duration: L.innerSpeed,
            yoyo: true,
            repeat: -1
        });
        
        // Store reference for hub (legacy compat)
        if (roomId === 'hub') this.ceilingLight = outer;
    }
    
    _createHubProps(addTo, WC, wallH) {
        const r = this.ROOMS.hub;
        const x = r.x, y = r.y, w = r.w, h = r.h;
        const d = 2; // floor prop depth
        
        // Floor cable mess — scattered, unorganized from terminal to walls
        // Each cable: shadow + core + highlight + ribs for sheathed look
        const cg = this.add.graphics().setDepth(d);
        const termX = x + w/2;
        const termY = y + wallH + 30;
        const westWall = x + WC.sideW + 4;
        const eastWall = x + w - WC.sideW - 4;
        const southWall = y + h - wallH - 10;
        
        // Draw a cable with shadow, core, highlight, and ribs
        const drawCable = (points, thickness, color, hiColor) => {
            // Shadow
            cg.lineStyle(thickness + 2, 0x08080c, 0.25);
            cg.beginPath();
            cg.moveTo(points[0][0] + 1.2, points[0][1] + 1.2);
            for (let i = 1; i < points.length; i++) cg.lineTo(points[i][0] + 1.2, points[i][1] + 1.2);
            cg.stroke();
            // Core
            cg.lineStyle(thickness, color, 0.8);
            cg.beginPath();
            cg.moveTo(points[0][0], points[0][1]);
            for (let i = 1; i < points.length; i++) cg.lineTo(points[i][0], points[i][1]);
            cg.stroke();
            // Highlight (center ridge)
            cg.lineStyle(thickness * 0.3, hiColor, 0.35);
            cg.beginPath();
            cg.moveTo(points[0][0], points[0][1] - 0.5);
            for (let i = 1; i < points.length; i++) cg.lineTo(points[i][0], points[i][1] - 0.5);
            cg.stroke();
            // Ribs (perpendicular ticks for sheath texture)
            for (let i = 1; i < points.length - 1; i += 2) {
                const px = points[i][0], py = points[i][1];
                const dx = (points[i+1] ? points[i+1][0] : px) - (points[i-1] ? points[i-1][0] : px);
                const dy = (points[i+1] ? points[i+1][1] : py) - (points[i-1] ? points[i-1][1] : py);
                const len = Math.sqrt(dx*dx + dy*dy) || 1;
                const perpX = -dy / len * thickness * 0.6;
                const perpY = dx / len * thickness * 0.6;
                cg.lineStyle(0.7, hiColor, 0.28);
                cg.beginPath();
                cg.moveTo(px - perpX, py - perpY);
                cg.lineTo(px + perpX, py + perpY);
                cg.stroke();
            }
        };
        
        // Generate wiggly path with sag and wobble (deterministic from seed coords)
        const wiggle = (x0, y0, x1, y1, segs, sag, wob) => {
            const pts = [];
            for (let i = 0; i <= segs; i++) {
                const t = i / segs;
                const bx = x0 + (x1 - x0) * t;
                const by = y0 + (y1 - y0) * t;
                const s = Math.sin(t * Math.PI) * sag;
                const wx = (Math.sin(t * 17.3 + x0 * 0.1) + Math.sin(t * 7.1 + y0 * 0.05)) * wob;
                const wy = (Math.sin(t * 13.7 + x0 * 0.07) + Math.cos(t * 9.3 + y0 * 0.03)) * wob;
                pts.push([bx + wx, by + s + wy]);
            }
            return pts;
        };
        
        // === 7 scattered cables — distinct hues + thickness per type ===
        // 1. POWER (thick, dark red-brown) — terminal left to west wall
        drawCable(wiggle(termX - 12, termY + 2, westWall, termY + 50, 14, 8, 3), 4, 0x2a1818, 0x3e2828);
        // 2. DATA (medium, dark blue) — terminal left, lazy arc to west wall
        drawCable(wiggle(termX - 8, termY + 5, westWall + 8, termY + 90, 16, 12, 4), 2.5, 0x16182a, 0x262e44);
        // 3. SIGNAL (medium, dark teal) — terminal right to east wall
        drawCable(wiggle(termX + 14, termY + 3, eastWall, termY + 55, 14, 10, 3.5), 2.5, 0x142222, 0x223838);
        // 4. ETHERNET (thin, dark green) — terminal right to east wall lower
        drawCable(wiggle(termX + 8, termY + 8, eastWall - 5, termY + 80, 16, 14, 5), 2, 0x162016, 0x263826);
        // 5. TRUNK (thickest, dark gray) — terminal center, runs south
        drawCable(wiggle(termX - 3, termY + 4, termX - 12, southWall, 18, 6, 3), 4.5, 0x1a1a20, 0x2e2e38);
        // 6. STRAY (thin, dark purple) — wanders east, dies on floor
        drawCable(wiggle(termX + 5, termY + 6, termX + 30, termY + 70, 12, 15, 6), 1.5, 0x1e162a, 0x302640);
        // 7. LOOSE (thin, yellow-brown) — terminal left, puddles nearby
        drawCable(wiggle(termX - 6, termY, termX - 25, termY + 35, 8, 5, 4), 2, 0x24201a, 0x3a3428);
        
        // Loose cable coils on floor (matching cable hues)
        cg.lineStyle(2, 0x2a1818, 0.4);
        cg.strokeEllipse(termX - 20, termY + 42, 8, 5);
        cg.lineStyle(1.5, 0x1e162a, 0.35);
        cg.strokeEllipse(termX + 25, termY + 65, 6, 4);
        cg.lineStyle(1.5, 0x1a1a20, 0.3);
        cg.strokeEllipse(termX - 8, southWall - 30, 7, 5);
        
        // Cable ties on floor
        cg.fillStyle(0x2a2a30, 0.45);
        cg.fillRect(termX - 16, termY + 18, 5, 1.5);
        cg.fillRect(termX + 10, termY + 25, 5, 1.5);
        cg.fillRect(termX - 10, termY + 55, 4, 1.5);
        // Loose connector dangling off stray cable
        cg.fillStyle(0x2a2a34, 0.55);
        cg.fillRect(termX + 30, termY + 68, 3, 4);
        cg.fillStyle(0x3a3a44, 0.45);
        cg.fillRect(termX + 30, termY + 68, 2, 2);
        addTo('hub', cg);
        
        // Status LEDs on east wall near doors (side face = red dot on depth panel)
        const ledPositions = [
            { lx: x + w - 3, ly: y + h * 0.20 - 20 },  // above upper east door
            { lx: x + w - 3, ly: y + h * 0.20 + 20 },  // below upper east door
            { lx: x + w - 3, ly: y + h * 0.75 - 20 },  // above lower east door
        ];
        ledPositions.forEach(lp => {
            addTo('hub', this.add.circle(lp.lx, lp.ly, 1.5, 0xcc3333, 0.8).setDepth(5.5));
            addTo('hub', this.add.circle(lp.lx, lp.ly, 4, 0xcc3333, 0.08).setDepth(5.4)); // glow
        });
        
        // West wall LEDs (mirror)
        [y + h * 0.20 - 20, y + h * 0.75 + 20].forEach(ly => {
            addTo('hub', this.add.circle(x + 3, ly, 1.5, 0xcc3333, 0.8).setDepth(5.5));
            addTo('hub', this.add.circle(x + 3, ly, 4, 0xcc3333, 0.08).setDepth(5.4));
        });
        
        // (Terminal fills wall — no standalone chair needed)
    }
    
    _createContainmentProps(addTo, WC, wallH) {
        const r = this.ROOMS.containment;
        const x = r.x, y = r.y, w = r.w, h = r.h;
        
        // Caution striping — yellow/black diagonal hash centered on converter
        const cg = this.add.graphics().setDepth(1.5);
        const cx = x + w/2, cy = y + h/2;
        const ringR = 35;
        cg.lineStyle(3, 0xccaa22, 0.35);
        for (let a = 0; a < Math.PI * 2; a += Math.PI / 8) {
            const sx = cx + Math.cos(a) * (ringR - 4);
            const sy = cy + Math.sin(a) * (ringR - 4) * 0.6; // foreshortened Y for ¾ view
            const ex = cx + Math.cos(a) * (ringR + 6);
            const ey = cy + Math.sin(a) * (ringR + 6) * 0.6;
            cg.beginPath(); cg.moveTo(sx, sy); cg.lineTo(ex, ey); cg.stroke();
        }
        // Ring outline
        cg.lineStyle(1, 0xccaa22, 0.25);
        cg.strokeEllipse(cx, cy, ringR * 2, ringR * 1.2);
        cg.strokeEllipse(cx, cy, (ringR + 8) * 2, (ringR + 8) * 1.2);
        addTo('containment', cg);
        
        // Corner conduits — thick vertical cables in each corner
        const corners = [
            [x + WC.sideW + 4, y + wallH + 4],
            [x + w - WC.sideW - 4, y + wallH + 4],
            [x + WC.sideW + 4, y + h - wallH - 4],
            [x + w - WC.sideW - 4, y + h - wallH - 4]
        ];
        corners.forEach(([cx2, cy2]) => {
            // Vertical conduit pipe — ¾ iso: we see front + top
            addTo('containment', this.add.rectangle(cx2, cy2, 5, 12, 0x2a2a3a).setDepth(3.5));
            addTo('containment', this.add.rectangle(cx2, cy2 - 5, 5, 2, 0x3a3a4a).setDepth(3.6)); // top cap
            addTo('containment', this.add.rectangle(cx2, cy2 + 3, 7, 2, 0x222230).setDepth(3.5));   // clamp
        });
        
        // Warning sign on north wall — front face wide (player faces head-on)
        const signX = x + w * 0.75, signY = y + WC.topH + WC.frontH * 0.4;
        // Backing plate (dark metal, weathered)
        addTo('containment', this.add.rectangle(signX, signY, 20, 14, 0x2a2a30).setDepth(3.5));
        addTo('containment', this.add.rectangle(signX, signY, 18, 12, 0x1e1e24).setDepth(3.51));
        // Border frame (dull amber, not bright)
        addTo('containment', this.add.rectangle(signX, signY - 6, 18, 1, 0x6a6033, 0.6).setDepth(3.52));
        addTo('containment', this.add.rectangle(signX, signY + 6, 18, 1, 0x6a6033, 0.6).setDepth(3.52));
        addTo('containment', this.add.rectangle(signX - 9, signY, 1, 12, 0x6a6033, 0.6).setDepth(3.52));
        addTo('containment', this.add.rectangle(signX + 9, signY, 1, 12, 0x6a6033, 0.6).setDepth(3.52));
        // Hazard triangle (muted amber)
        addTo('containment', this.add.triangle(signX, signY - 2, -5, 5, 5, 5, 0, -4, 0x7a7040, 0.7).setDepth(3.55));
        addTo('containment', this.add.triangle(signX, signY - 2, -3.5, 3.5, 3.5, 3.5, 0, -2.5, 0x1e1e24, 0.9).setDepth(3.56));
        // Exclamation mark inside triangle
        addTo('containment', this.add.rectangle(signX, signY - 2, 1, 3, 0x7a7040, 0.8).setDepth(3.57));
        addTo('containment', this.add.circle(signX, signY + 0.5, 0.5, 0x7a7040, 0.8).setDepth(3.57));
        // Text bar below triangle (faded label strip)
        addTo('containment', this.add.rectangle(signX, signY + 3.5, 12, 2.5, 0x222228).setDepth(3.55));
        addTo('containment', this.add.rectangle(signX, signY + 3.5, 10, 1, 0x555540, 0.3).setDepth(3.56));
        // Corner mounting screws
        addTo('containment', this.add.circle(signX - 8, signY - 5, 0.6, 0x444450).setDepth(3.58));
        addTo('containment', this.add.circle(signX + 8, signY - 5, 0.6, 0x444450).setDepth(3.58));
        addTo('containment', this.add.circle(signX - 8, signY + 5, 0.6, 0x444450).setDepth(3.58));
        addTo('containment', this.add.circle(signX + 8, signY + 5, 0.6, 0x444450).setDepth(3.58));
        
        // Monitoring console near east door — EAST WALL: side face dominant
        // Player sees the left side panel (depth) as the wide face, front is narrow sliver going left
        const monX = x + w - WC.sideW - 2, monY = y + h/2 + 30;
        // Side face (dominant) — depth panel facing player
        addTo('containment', this.add.rectangle(monX - 2, monY, 10, 22, 0x2a2a38).setDepth(5.3));
        // Front face (narrow sliver receding left)
        addTo('containment', this.add.rectangle(monX - 8, monY, 3, 22, 0x222230).setDepth(5.2));
        // Top face (thin foreshortened strip)
        addTo('containment', this.add.rectangle(monX - 4, monY - 11, 10, 3, 0x3a3a48).setDepth(5.4));
        // Screen on side face (greenish)
        addTo('containment', this.add.rectangle(monX - 2, monY - 3, 6, 8, 0x224422, 0.7).setDepth(5.35));
        // Blinking light
        addTo('containment', this.add.circle(monX - 2, monY + 8, 1, 0x33cc66, 0.8).setDepth(5.4));
        
        // Decontamination floor grate near entrance (east side)
        const grateG = this.add.graphics().setDepth(1.4);
        const grateX = x + w - 30, grateY = y + h/2;
        grateG.fillStyle(0x1a1a1e, 0.5);
        grateG.fillRect(grateX - 12, grateY - 8, 24, 16);
        for (let i = 0; i < 5; i++) {
            grateG.fillStyle(0x0e0e12, 0.6);
            grateG.fillRect(grateX - 10 + i * 5, grateY - 6, 2, 12);
        }
        addTo('containment', grateG);
        
        // === HEAVY POWER CABLES — converter to wall sockets ===
        const cabG = this.add.graphics().setDepth(1.6);
        const convX = cx, convY = cy;  // converter center
        
        // Cable draw helper (same system as hub cables)
        const drawHeavyCable = (points, thickness, color, hiColor) => {
            cabG.lineStyle(thickness + 2, 0x08080c, 0.2);
            cabG.beginPath();
            cabG.moveTo(points[0][0] + 1.2, points[0][1] + 1.2);
            for (let i = 1; i < points.length; i++) cabG.lineTo(points[i][0] + 1.2, points[i][1] + 1.2);
            cabG.stroke();
            cabG.lineStyle(thickness, color, 0.75);
            cabG.beginPath();
            cabG.moveTo(points[0][0], points[0][1]);
            for (let i = 1; i < points.length; i++) cabG.lineTo(points[i][0], points[i][1]);
            cabG.stroke();
            cabG.lineStyle(thickness * 0.3, hiColor, 0.3);
            cabG.beginPath();
            cabG.moveTo(points[0][0], points[0][1] - 0.5);
            for (let i = 1; i < points.length; i++) cabG.lineTo(points[i][0], points[i][1] - 0.5);
            cabG.stroke();
            for (let i = 1; i < points.length - 1; i += 2) {
                const px = points[i][0], py = points[i][1];
                const ddx = (points[i+1] ? points[i+1][0] : px) - (points[i-1] ? points[i-1][0] : px);
                const ddy = (points[i+1] ? points[i+1][1] : py) - (points[i-1] ? points[i-1][1] : py);
                const len = Math.sqrt(ddx*ddx + ddy*ddy) || 1;
                const perpX = -ddy / len * thickness * 0.55;
                const perpY = ddx / len * thickness * 0.55;
                cabG.lineStyle(0.7, hiColor, 0.22);
                cabG.beginPath();
                cabG.moveTo(px - perpX, py - perpY);
                cabG.lineTo(px + perpX, py + perpY);
                cabG.stroke();
            }
        };
        const wiggle = (x0, y0, x1, y1, segs, sag, wob) => {
            const pts = [];
            for (let i = 0; i <= segs; i++) {
                const t = i / segs;
                const bx = x0 + (x1 - x0) * t;
                const by = y0 + (y1 - y0) * t;
                const s = Math.sin(t * Math.PI) * sag;
                const wx = (Math.sin(t * 17.3 + x0 * 0.1) + Math.sin(t * 7.1 + y0 * 0.05)) * wob;
                const wy = (Math.sin(t * 13.7 + x0 * 0.07) + Math.cos(t * 9.3 + y0 * 0.03)) * wob;
                pts.push([bx + wx, by + s + wy]);
            }
            return pts;
        };
        
        // North wall cable — thick power (red-brown), from converter top to north wall center
        const nSocketX = x + w * 0.4, nSocketY = y + wallH + 3;
        drawHeavyCable(wiggle(convX - 8, convY - 12, nSocketX, nSocketY + 6, 14, 6, 2.5), 4, 0x2a1818, 0x3e2828);
        drawHeavyCable(wiggle(convX - 5, convY - 10, nSocketX + 5, nSocketY + 6, 14, 5, 3), 3, 0x221616, 0x362424);
        
        // West wall cable — data (blue), from converter left to west wall mid
        const wSocketX = x + WC.sideW + 2, wSocketY = y + h * 0.35;
        drawHeavyCable(wiggle(convX - 18, convY + 4, wSocketX + 6, wSocketY, 16, 8, 3), 4, 0x16182a, 0x262e44);
        drawHeavyCable(wiggle(convX - 16, convY + 7, wSocketX + 6, wSocketY + 5, 14, 10, 4), 2.5, 0x141626, 0x222a3e);
        
        // East wall cable — signal (teal), from converter right to east wall below door
        const eSocketX = x + w - WC.sideW - 2, eSocketY = y + h * 0.78;
        drawHeavyCable(wiggle(convX + 18, convY + 4, eSocketX - 6, eSocketY, 16, 10, 3.5), 4, 0x142222, 0x223838);
        drawHeavyCable(wiggle(convX + 16, convY + 8, eSocketX - 6, eSocketY - 5, 14, 8, 4), 2.5, 0x121e1e, 0x1e3232);
        
        // Cable clamps where they cross the floor
        cabG.fillStyle(0x2a2a38, 0.5);
        cabG.fillRect(convX - 14, convY - 4, 6, 2);
        cabG.fillRect(convX + 10, convY + 2, 6, 2);
        cabG.fillRect(nSocketX - 3, nSocketY + 16, 5, 2);
        cabG.fillRect(wSocketX + 20, wSocketY + 2, 5, 2);
        cabG.fillRect(eSocketX - 25, eSocketY - 3, 5, 2);
        addTo('containment', cabG);
        
        // === WALL SOCKETS — ¾ iso facing ===
        // NORTH socket — front face wide (player faces head-on)
        const ns = this.add.container(nSocketX, nSocketY);
        ns.add(this.add.rectangle(0, 0, 18, 10, 0x1e1e2a).setDepth(5.3));        // front face
        ns.add(this.add.rectangle(0, 0, 16, 8, 0x262638).setDepth(5.31));
        ns.add(this.add.rectangle(0, -5, 18, 2, 0x2e2e42).setDepth(5.35));        // top face (foreshortened)
        // Port holes
        ns.add(this.add.circle(-4, 0, 2.5, 0x0e0e18).setDepth(5.32));
        ns.add(this.add.circle(-4, 0, 1.5, 0x1a1a2a).setDepth(5.33));
        ns.add(this.add.circle(4, 0, 2.5, 0x0e0e18).setDepth(5.32));
        ns.add(this.add.circle(4, 0, 1.5, 0x1a1a2a).setDepth(5.33));
        // Mounting bolts
        ns.add(this.add.circle(-7, -3, 0.6, 0x444450).setDepth(5.34));
        ns.add(this.add.circle(7, -3, 0.6, 0x444450).setDepth(5.34));
        ns.add(this.add.circle(-7, 3, 0.6, 0x444450).setDepth(5.34));
        ns.add(this.add.circle(7, 3, 0.6, 0x444450).setDepth(5.34));
        // Status LED
        ns.add(this.add.circle(0, 3, 0.8, 0x44aa44, 0.5).setDepth(5.35));
        addTo('containment', ns);
        
        // WEST socket — SOUTH SIDE dominant (plain panel), front sliver recedes RIGHT
        const ws = this.add.container(wSocketX, wSocketY);
        ws.add(this.add.rectangle(2, 0, 10, 14, 0x1e1e2a).setDepth(5.3));        // side face (dominant)
        ws.add(this.add.rectangle(2, 0, 8, 12, 0x262638).setDepth(5.31));
        ws.add(this.add.rectangle(8, 0, 3, 14, 0x181824).setDepth(5.28));          // front sliver receding right
        ws.add(this.add.rectangle(5, -7, 10, 2, 0x2e2e42).setDepth(5.35));        // top face
        // Port holes on side face
        ws.add(this.add.circle(2, -2, 2.5, 0x0e0e18).setDepth(5.32));
        ws.add(this.add.circle(2, -2, 1.5, 0x1a1a2a).setDepth(5.33));
        ws.add(this.add.circle(2, 3, 2.5, 0x0e0e18).setDepth(5.32));
        ws.add(this.add.circle(2, 3, 1.5, 0x1a1a2a).setDepth(5.33));
        // Mounting bolts on side
        ws.add(this.add.circle(-1, -5, 0.6, 0x444450).setDepth(5.34));
        ws.add(this.add.circle(5, -5, 0.6, 0x444450).setDepth(5.34));
        ws.add(this.add.circle(-1, 5, 0.6, 0x444450).setDepth(5.34));
        ws.add(this.add.circle(5, 5, 0.6, 0x444450).setDepth(5.34));
        ws.add(this.add.circle(2, 6, 0.8, 0x44aa44, 0.5).setDepth(5.35));
        addTo('containment', ws);
        
        // EAST socket — SOUTH SIDE dominant (plain panel), front sliver recedes LEFT
        const es = this.add.container(eSocketX, eSocketY);
        es.add(this.add.rectangle(-2, 0, 10, 14, 0x1e1e2a).setDepth(5.3));       // side face (dominant)
        es.add(this.add.rectangle(-2, 0, 8, 12, 0x262638).setDepth(5.31));
        es.add(this.add.rectangle(-8, 0, 3, 14, 0x181824).setDepth(5.28));         // front sliver receding left
        es.add(this.add.rectangle(-5, -7, 10, 2, 0x2e2e42).setDepth(5.35));       // top face
        // Port holes on side face
        es.add(this.add.circle(-2, -2, 2.5, 0x0e0e18).setDepth(5.32));
        es.add(this.add.circle(-2, -2, 1.5, 0x1a1a2a).setDepth(5.33));
        es.add(this.add.circle(-2, 3, 2.5, 0x0e0e18).setDepth(5.32));
        es.add(this.add.circle(-2, 3, 1.5, 0x1a1a2a).setDepth(5.33));
        // Mounting bolts
        es.add(this.add.circle(-5, -5, 0.6, 0x444450).setDepth(5.34));
        es.add(this.add.circle(1, -5, 0.6, 0x444450).setDepth(5.34));
        es.add(this.add.circle(-5, 5, 0.6, 0x444450).setDepth(5.34));
        es.add(this.add.circle(1, 5, 0.6, 0x444450).setDepth(5.34));
        es.add(this.add.circle(-2, 6, 0.8, 0x44aa44, 0.5).setDepth(5.35));
        addTo('containment', es);
    }
    
    _createBedroomProps(addTo, WC, wallH) {
        const r = this.ROOMS.bedroom;
        const x = r.x, y = r.y, w = r.w, h = r.h;
        
        // Bedside table — left of bed (¾ iso: top + front)
        const btX = x + w/2 - 36, btY = y + wallH + 30;
        addTo('bedroom', this.add.rectangle(btX, btY - 3, 14, 5, 0x5a4a3a).setDepth(2));        // top face
        addTo('bedroom', this.add.rectangle(btX, btY + 3, 14, 10, 0x4a3a2a).setDepth(2));       // front face
        addTo('bedroom', this.add.rectangle(btX, btY - 1, 12, 1, 0x3a2a1a, 0.5).setDepth(2.1)); // drawer line
        
        // Photos pinned to north wall — front face visible
        const photoY = y + WC.topH + WC.frontH * 0.35;
        [x + w/2 + 40, x + w/2 + 52, x + w/2 + 46].forEach((px, i) => {
            const py = photoY + (i === 1 ? -2 : i === 2 ? 3 : 0);
            addTo('bedroom', this.add.rectangle(px, py, 8, 6, 0x887766).setDepth(3.5).setAngle(i * 5 - 5));
            addTo('bedroom', this.add.rectangle(px, py, 6, 4, 0xaa9988, 0.6).setDepth(3.6).setAngle(i * 5 - 5));
        });
        
        // (west wall cleared)
        
        // Water bottle near gym area
        const wbX = x + w - 40, wbY = y + h - wallH - 50;
        addTo('bedroom', this.add.ellipse(wbX, wbY - 5, 5, 3, 0x4488aa).setDepth(2.1));
        addTo('bedroom', this.add.rectangle(wbX, wbY, 5, 8, 0x3377aa).setDepth(2));
    }
    
    _createArmoryProps(addTo, WC, wallH) {
        const r = this.ROOMS.armory;
        const x = r.x, y = r.y, w = r.w, h = r.h;
        const d = 3.5;
        const cyan = 0x44bbff;
        const cyanDk = 0x1a4466;
        
        // === NORTH WALL — DATA SERVER RACK ARRAY ===
        // Full-width server bank against north wall, ¾ iso: front face dominant
        const rackY = y + WC.topH + 2;
        const rackH = WC.frontH - 4;
        const rackLeft = x + WC.sideW + 12;
        const rackRight = x + w - WC.sideW - 12;
        const rackW = rackRight - rackLeft;
        const rackCX = rackLeft + rackW / 2;
        
        // Rack housing (dark recessed)
        addTo('armory', this.add.rectangle(rackCX, rackY + rackH/2, rackW, rackH, 0x0a0a14).setDepth(3.5));
        addTo('armory', this.add.rectangle(rackCX, rackY + rackH/2, rackW - 2, rackH - 2, 0x0e0e1a).setDepth(3.51));
        
        // Server modules — small colored blocks in a grid
        const modW = 10, modH = 3, modGap = 2;
        const cols = Math.floor((rackW - 8) / (modW + modGap));
        const rows = Math.floor((rackH - 6) / (modH + modGap));
        const modStartX = rackLeft + (rackW - cols * (modW + modGap) + modGap) / 2;
        
        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const mx = modStartX + col * (modW + modGap) + modW/2;
                const my = rackY + 3 + row * (modH + modGap) + modH/2;
                // Module body
                addTo('armory', this.add.rectangle(mx, my, modW, modH, 0x141428).setDepth(3.52));
                addTo('armory', this.add.rectangle(mx, my, modW - 1, modH - 1, 0x1a1a30).setDepth(3.53));
                // Status LED (randomly cyan or dim)
                const ledOn = ((row * cols + col) % 3) !== 0;
                addTo('armory', this.add.circle(mx + modW/2 - 2, my, 0.8, ledOn ? cyan : 0x222238, ledOn ? 0.4 : 0.2).setDepth(3.54));
            }
        }
        
        // Blinking LED animation — pick 3 random LEDs to pulse
        for (let bi = 0; bi < 3; bi++) {
            const bx = modStartX + (bi * 4 + 1) * (modW + modGap) % (cols * (modW + modGap)) + modW/2 + modW/2 - 2;
            const by = rackY + 3 + ((bi * 2) % rows) * (modH + modGap) + modH/2;
            const blink = this.add.circle(bx, by, 1.2, cyan, 0.5).setDepth(3.55);
            addTo('armory', blink);
            this.tweens.add({
                targets: blink, alpha: { from: 0.15, to: 0.55 },
                duration: 800 + bi * 400, yoyo: true, repeat: -1, ease: 'Sine.inOut'
            });
        }
        
        // === EAST WALL — NEURAL INTERFACE MECHANISM (south of center) ===
        // East wall: side face dominant (depth panel), front face narrow sliver receding left
        const mechX = x + w - WC.sideW/2 - 1;
        const mechY = y + h/2 + 20; // shifted south
        
        // Main housing — side face (dominant, player sees depth)
        addTo('armory', this.add.rectangle(mechX - 4, mechY, 10, 54, 0x0e0e1a).setDepth(5.1));
        addTo('armory', this.add.rectangle(mechX - 4, mechY, 8, 52, 0x121224).setDepth(5.15));
        // Front face sliver (narrow, receding left)
        addTo('armory', this.add.rectangle(mechX - 10, mechY, 3, 54, 0x0a0a16).setDepth(5.0));
        // Top face (foreshortened)
        addTo('armory', this.add.rectangle(mechX - 5, mechY - 28, 10, 3, 0x1e1e30).setDepth(5.2));
        
        // Section dividers (horizontal seams on side face)
        [-20, -8, 4, 16].forEach(sy => {
            addTo('armory', this.add.rectangle(mechX - 4, mechY + sy, 8, 0.5, 0x060610, 0.5).setDepth(5.16));
        });
        
        // === GEARS (visible on side face — rotate on chair approach) ===
        const gears = [];
        // Large gear (top section)
        const gear1 = this.add.container(mechX - 4, mechY - 14);
        gear1.add(this.add.circle(0, 0, 5, 0x1e1e38).setDepth(5.2));
        gear1.add(this.add.circle(0, 0, 3.5, 0x14142a).setDepth(5.21));
        gear1.add(this.add.circle(0, 0, 1.5, 0x2a2a44).setDepth(5.22));
        for (let ti = 0; ti < 8; ti++) {
            const a = (ti / 8) * Math.PI * 2;
            const tx = Math.cos(a) * 4.5, ty = Math.sin(a) * 4.5;
            gear1.add(this.add.rectangle(tx, ty, 2, 2, 0x2a2a40).setDepth(5.19));
        }
        addTo('armory', gear1);
        gears.push(gear1);
        
        // Small gear (meshed below)
        const gear2 = this.add.container(mechX - 4, mechY - 5);
        gear2.add(this.add.circle(0, 0, 3.5, 0x1e1e38).setDepth(5.2));
        gear2.add(this.add.circle(0, 0, 2, 0x14142a).setDepth(5.21));
        gear2.add(this.add.circle(0, 0, 1, 0x2a2a44).setDepth(5.22));
        for (let ti = 0; ti < 6; ti++) {
            const a = (ti / 6) * Math.PI * 2;
            const tx = Math.cos(a) * 3, ty = Math.sin(a) * 3;
            gear2.add(this.add.rectangle(tx, ty, 1.5, 1.5, 0x2a2a40).setDepth(5.19));
        }
        addTo('armory', gear2);
        gears.push(gear2);
        
        // Third gear (lower section)
        const gear3 = this.add.container(mechX - 4, mechY + 6);
        gear3.add(this.add.circle(0, 0, 4, 0x1e1e38).setDepth(5.2));
        gear3.add(this.add.circle(0, 0, 2.5, 0x14142a).setDepth(5.21));
        gear3.add(this.add.circle(0, 0, 1.2, 0x2a2a44).setDepth(5.22));
        for (let ti = 0; ti < 7; ti++) {
            const a = (ti / 7) * Math.PI * 2;
            const tx = Math.cos(a) * 3.5, ty = Math.sin(a) * 3.5;
            gear3.add(this.add.rectangle(tx, ty, 1.5, 1.5, 0x2a2a40).setDepth(5.19));
        }
        addTo('armory', gear3);
        gears.push(gear3);
        
        // Store gears on scene for chair approach handler
        this._mechGears = gears;
        
        // Dials below gears
        addTo('armory', this.add.circle(mechX - 4, mechY + 14, 2.5, 0x14142a).setDepth(5.17));
        addTo('armory', this.add.circle(mechX - 4, mechY + 14, 1.5, 0x1e1e38).setDepth(5.18));
        addTo('armory', this.add.rectangle(mechX - 4, mechY + 13.5, 0.5, 1.5, 0x3344aa).setDepth(5.19));
        
        // Toggle switches
        [18, 22].forEach(sy => {
            addTo('armory', this.add.rectangle(mechX - 4, mechY + sy, 2, 3, 0x1a1a30).setDepth(5.17));
            addTo('armory', this.add.rectangle(mechX - 4, mechY + sy - 0.5, 1.5, 1.5, 0x3344aa).setDepth(5.18));
        });
        
        // === PULSING LED (status indicator — cyan throb) ===
        const mechLed = this.add.circle(mechX - 4, mechY + 12, 1.2, cyan, 0.15);
        mechLed.setDepth(5.25);
        addTo('armory', mechLed);
        this._mechLed = mechLed;
        this.tweens.add({
            targets: mechLed, alpha: { from: 0.10, to: 0.35 },
            duration: 1500, yoyo: true, repeat: -1, ease: 'Sine.inOut'
        });
        
        // Vent grille (bottom)
        for (let vi = 0; vi < 3; vi++) {
            addTo('armory', this.add.rectangle(mechX - 4, mechY + 24 + vi * 2, 6, 0.8, 0x080814, 0.6).setDepth(5.17));
        }
        
        // Corner rivets
        [[-7, -26], [0, -26], [-7, 26], [0, 26]].forEach(([rx, ry]) => {
            addTo('armory', this.add.circle(mechX + rx, mechY + ry, 0.6, 0x333344).setDepth(5.19));
        });
        
        // === HEADGEAR on swing arm (top of mechanism) ===
        const hgX = mechX - 8, hgY = mechY - 36;
        addTo('armory', this.add.rectangle(mechX - 4, hgY + 6, 8, 2, 0x2a2a40).setDepth(5.3));
        addTo('armory', this.add.rectangle(mechX - 8, hgY + 6, 2, 2, 0x2a2a40).setDepth(5.3));
        addTo('armory', this.add.rectangle(hgX, hgY + 3, 2, 5, 0x2a2a40).setDepth(5.3));
        // Headpiece
        addTo('armory', this.add.rectangle(hgX, hgY - 2, 14, 8, 0x0e0e1a).setDepth(5.35));
        addTo('armory', this.add.rectangle(hgX, hgY - 2, 12, 6, 0x141428).setDepth(5.36));
        addTo('armory', this.add.rectangle(hgX, hgY, 10, 2, 0x060610).setDepth(5.37));
        addTo('armory', this.add.rectangle(hgX, hgY, 8, 1, cyan, 0.15).setDepth(5.38));
        addTo('armory', this.add.rectangle(hgX - 7, hgY - 2, 2, 5, 0x2a2a40).setDepth(5.36));
        addTo('armory', this.add.rectangle(hgX + 7, hgY - 2, 2, 5, 0x2a2a40).setDepth(5.36));
        addTo('armory', this.add.rectangle(hgX - 4, hgY - 6, 2, 2, 0x3a3a50).setDepth(5.38));
        addTo('armory', this.add.rectangle(hgX, hgY - 7, 2, 3, 0x3a3a50).setDepth(5.38));
        addTo('armory', this.add.rectangle(hgX + 4, hgY - 6, 2, 2, 0x3a3a50).setDepth(5.38));
        addTo('armory', this.add.rectangle(hgX, hgY - 7, 14, 2, 0x1e1e30).setDepth(5.39));
        
        // === FIBER OPTIC CABLE from mechanism to chair ===
        const cg = this.add.graphics().setDepth(4);
        cg.lineStyle(1.5, cyanDk, 0.4);
        cg.beginPath();
        cg.moveTo(hgX + 7, hgY);
        cg.lineTo(mechX - 2, hgY + 6);
        cg.lineTo(mechX - 2, mechY + 14);
        cg.lineTo(mechX - 12, mechY + 18);
        const chairCX = x + w/2, chairCY = y + h/2 + 10;
        const midX = (mechX - 12 + chairCX + 16) / 2;
        const midY = Math.max(mechY + 18, chairCY) + 10;
        cg.lineTo(midX + 12, midY - 3);
        cg.lineTo(midX, midY);
        cg.lineTo(midX - 18, midY - 4);
        cg.lineTo(chairCX + 20, chairCY - 6);
        cg.stroke();
        // Glow trace over cable
        cg.lineStyle(1, cyan, 0.06);
        cg.beginPath();
        cg.moveTo(mechX - 2, mechY + 14);
        cg.lineTo(midX, midY);
        cg.lineTo(chairCX + 20, chairCY - 6);
        cg.stroke();
        addTo('armory', cg);
        [[mechX - 8, mechY + 16], [midX + 6, midY - 2], [midX - 10, midY - 3]].forEach(([clipX, clipY]) => {
            addTo('armory', this.add.rectangle(clipX, clipY, 3, 2, 0x2a2a40, 0.5).setDepth(4.1));
        });
        
        // === FIBER OPTIC from server rack to chair ===
        const fg2 = this.add.graphics().setDepth(1.5);
        fg2.lineStyle(1, cyanDk, 0.25);
        fg2.beginPath();
        fg2.moveTo(rackCX, rackY + rackH + 2);
        fg2.lineTo(rackCX, y + wallH + 14);
        fg2.lineTo(chairCX - 10, chairCY - 20);
        fg2.lineTo(chairCX - 5, chairCY - 8);
        fg2.stroke();
        // Glow
        fg2.lineStyle(1, cyan, 0.04);
        fg2.beginPath();
        fg2.moveTo(rackCX, y + wallH + 14);
        fg2.lineTo(chairCX - 5, chairCY - 8);
        fg2.stroke();
        addTo('armory', fg2);
        
        // === VISOR HELMET DISPLAY STAND (right of chair) ===
        const vsX = chairCX + 36, vsY = chairCY - 5;
        
        // Base (ellipse on floor)
        addTo('armory', this.add.ellipse(vsX, vsY + 12, 18, 6, 0x0a0a14).setDepth(d + 0.01));
        addTo('armory', this.add.ellipse(vsX, vsY + 12, 16, 5, 0x0e0e1a).setDepth(d + 0.015));
        // Column
        addTo('armory', this.add.rectangle(vsX, vsY + 4, 4, 14, 0x0e0e1a).setDepth(d + 0.02));
        addTo('armory', this.add.rectangle(vsX, vsY + 4, 3, 12, 0x141428).setDepth(d + 0.025));
        // Ring detail on column
        addTo('armory', this.add.rectangle(vsX, vsY + 1, 6, 1, cyanDk).setDepth(d + 0.03));
        addTo('armory', this.add.rectangle(vsX, vsY + 8, 6, 1, cyanDk).setDepth(d + 0.03));
        
        // Display cradle
        addTo('armory', this.add.rectangle(vsX, vsY - 3, 12, 3, 0x1a1a2e).setDepth(d + 0.04));
        addTo('armory', this.add.rectangle(vsX, vsY - 4, 10, 1.5, 0x222238).setDepth(d + 0.045));
        addTo('armory', this.add.rectangle(vsX - 5, vsY - 5, 1.5, 4, 0x2a2a40).setDepth(d + 0.05));
        addTo('armory', this.add.rectangle(vsX + 5, vsY - 5, 1.5, 4, 0x2a2a40).setDepth(d + 0.05));
        
        // === VISOR HELMET (resting on cradle) ===
        addTo('armory', this.add.rectangle(vsX, vsY - 9, 16, 10, 0x0e0e1a).setDepth(d + 0.06));
        addTo('armory', this.add.rectangle(vsX, vsY - 9, 14, 8, 0x141428).setDepth(d + 0.065));
        // Visor slit (glowing band)
        addTo('armory', this.add.rectangle(vsX, vsY - 8, 12, 3, 0x060610).setDepth(d + 0.07));
        addTo('armory', this.add.rectangle(vsX, vsY - 8, 10, 2, 0x0a1a2e, 0.6).setDepth(d + 0.075));
        addTo('armory', this.add.rectangle(vsX, vsY - 8, 8, 1, cyan, 0.2).setDepth(d + 0.08));
        // Temple nodes
        addTo('armory', this.add.rectangle(vsX - 8, vsY - 9, 2, 6, 0x2a2a40).setDepth(d + 0.065));
        addTo('armory', this.add.rectangle(vsX + 8, vsY - 9, 2, 6, 0x2a2a40).setDepth(d + 0.065));
        // Crown
        addTo('armory', this.add.rectangle(vsX, vsY - 14, 12, 2, 0x1e1e30).setDepth(d + 0.08));
        addTo('armory', this.add.rectangle(vsX, vsY - 15, 10, 1.5, 0x222238).setDepth(d + 0.085));
        addTo('armory', this.add.rectangle(vsX, vsY - 15.5, 14, 2, 0x1a1a2e).setDepth(d + 0.09));
        // Crown electrodes
        addTo('armory', this.add.rectangle(vsX - 3, vsY - 16, 1.5, 2, 0x3a3a50).setDepth(d + 0.09));
        addTo('armory', this.add.rectangle(vsX + 3, vsY - 16, 1.5, 2, 0x3a3a50).setDepth(d + 0.09));
        // Tiny LED on visor
        addTo('armory', this.add.circle(vsX + 5, vsY - 12, 0.6, cyan, 0.3).setDepth(d + 0.095));
        
        // === HOLOGRAPHIC PROJECTION RING (around chair on floor) ===
        const hfg = this.add.graphics().setDepth(1.4);
        // Cyan ring with pulsing segments
        hfg.lineStyle(1, cyan, 0.08);
        hfg.strokeCircle(chairCX, chairCY, 28);
        // Cardinal markers
        [[0, -28], [0, 28], [-28, 0], [28, 0]].forEach(([dx, dy]) => {
            hfg.fillStyle(cyan, 0.15);
            hfg.fillCircle(chairCX + dx, chairCY + dy, 2);
        });
        // Diagonal tick marks
        const r45 = 28 * 0.707;
        [[-r45, -r45], [r45, -r45], [-r45, r45], [r45, r45]].forEach(([dx, dy]) => {
            hfg.lineStyle(1, cyan, 0.06);
            hfg.beginPath();
            hfg.moveTo(chairCX + dx * 0.85, chairCY + dy * 0.85);
            hfg.lineTo(chairCX + dx * 1.15, chairCY + dy * 1.15);
            hfg.stroke();
        });
        addTo('armory', hfg);
        
        // Pulsing ring glow
        const ringGlow = this.add.circle(chairCX, chairCY, 30, cyan, 0.03).setDepth(1.35);
        addTo('armory', ringGlow);
        this.tweens.add({
            targets: ringGlow, alpha: { from: 0.02, to: 0.06 },
            scaleX: { from: 0.95, to: 1.05 }, scaleY: { from: 0.95, to: 1.05 },
            duration: 3000, yoyo: true, repeat: -1, ease: 'Sine.inOut'
        });
    }
    
    _createGarageProps(addTo, WC, wallH) {
        const r = this.ROOMS.garage;
        const x = r.x, y = r.y, w = r.w, h = r.h;
        const doorCX = x + w * 0.5;
        // Garage skips north wall — benches sit directly at top edge
        const benchY = y + 4;
        const d = 3.5;
        
        // === WORKBENCH (right of door) ===
        // Mechanical table: front face + drawers + cavity. Top IS the hinged lid.
        // On approach: lid folds back against wall, tool panel rises from cavity.
        const wbX = doorCX + 71;
        const wbHW = 48;
        const topW = wbHW * 2;
        
        // Heavy legs (4 pairs — front visible, back behind wall)
        [-40, -14, 14, 40].forEach(lx => {
            addTo('garage', this.add.rectangle(wbX + lx, benchY + 22, 3, 7, 0x2a2a2a).setDepth(d - 0.01));
            addTo('garage', this.add.rectangle(wbX + lx, benchY + 16, 3, 7, 0x222222).setDepth(d - 0.02));
        });
        
        // Front face — steel panel with drawers
        addTo('garage', this.add.rectangle(wbX, benchY + 13, topW, 12, 0x4a4a4a).setDepth(d + 0.01));
        addTo('garage', this.add.rectangle(wbX, benchY + 13, topW - 2, 10, 0x555555).setDepth(d + 0.015));
        addTo('garage', this.add.rectangle(wbX, benchY + 13, topW - 6, 1, 0x3a3a3a).setDepth(d + 0.018));
        // Drawer bank (3 across)
        [-30, 0, 30].forEach(dx => {
            addTo('garage', this.add.rectangle(wbX + dx, benchY + 13, 24, 8, 0x484848).setDepth(d + 0.02));
            addTo('garage', this.add.rectangle(wbX + dx, benchY + 13, 22, 6, 0x525252).setDepth(d + 0.025));
            addTo('garage', this.add.rectangle(wbX + dx, benchY + 13, 10, 1, 0x6a6a6a).setDepth(d + 0.03));
        });
        // Lower shelf
        addTo('garage', this.add.rectangle(wbX, benchY + 21, topW - 8, 4, 0x3a3a3a).setDepth(d + 0.01));
        
        // Metal edge trim (stays visible as the frame of the cavity opening)
        addTo('garage', this.add.rectangle(wbX, benchY + 0, topW, 1.5, 0x777777).setDepth(d + 0.05));
        
        // Cavity interior (visible when lid opens — dark recess)
        addTo('garage', this.add.rectangle(wbX, benchY + 4, topW - 4, 8, 0x1a1a1e).setDepth(d + 0.035));
        addTo('garage', this.add.rectangle(wbX, benchY + 4, topW - 6, 6, 0x222226).setDepth(d + 0.036));
        
        // Hinge brackets at back wall edge (fixed — never animate)
        [-wbHW + 6, wbHW - 6].forEach(hx => {
            addTo('garage', this.add.rectangle(wbX + hx, benchY - 1, 8, 3, 0x555558).setDepth(d + 0.08));
            addTo('garage', this.add.rectangle(wbX + hx, benchY - 1, 6, 2, 0x6a6a6e).setDepth(d + 0.085));
            addTo('garage', this.add.circle(wbX + hx, benchY - 1, 1.2, 0x77777a).setDepth(d + 0.09));
        });
        
        // === LID (the bench top surface — hinged at back/wall edge) ===
        // Container origin at hinge line; content extends downward (toward player)
        const lidH = 10;
        const toolLid = this.add.container(wbX, benchY);
        toolLid.setDepth(d + 0.06);
        // Steel top plate
        toolLid.add(this.add.rectangle(0, lidH/2, topW, lidH, 0x5a5a5a));
        toolLid.add(this.add.rectangle(0, lidH/2, topW - 2, lidH - 1, 0x666666));
        // Surface details: grip ridges + edge bevel
        for (let rx = -topW/2 + 8; rx < topW/2 - 8; rx += 12) {
            toolLid.add(this.add.rectangle(rx, lidH/2, 8, 0.5, 0x777777, 0.5));
        }
        // Handle strip across front
        toolLid.add(this.add.rectangle(0, lidH - 1.5, 24, 2, 0x6a6a6a));
        toolLid.add(this.add.rectangle(0, lidH - 1.5, 22, 1, 0x7a7a7a));
        addTo('garage', toolLid);
        this._garageToolLid = toolLid;
        
        // === TOOL PANEL (rises from cavity when lid opens) ===
        const toolPanelH = 24;
        const toolPanel = this.add.container(wbX, benchY + 14);
        toolPanel.setDepth(d + 0.095);
        // Steel backing
        toolPanel.add(this.add.rectangle(0, 0, topW - 10, toolPanelH, 0x3a3a3e));
        toolPanel.add(this.add.rectangle(0, 0, topW - 12, toolPanelH - 2, 0x44444a));
        // Border frame — raised edge
        const toolBorder = this.add.rectangle(0, 0, topW - 10, toolPanelH);
        toolBorder.setFillStyle(0x000000, 0);
        toolBorder.setStrokeStyle(1.5, 0x5e5e66, 0.8);
        toolPanel.add(toolBorder);
        // Inner bevel highlights
        toolPanel.add(this.add.rectangle(0, -toolPanelH/2 + 0.5, topW - 12, 1, 0x6a6a72, 0.4)); // top highlight
        toolPanel.add(this.add.rectangle(0, toolPanelH/2 - 0.5, topW - 12, 1, 0x2a2a2e, 0.5));  // bottom shadow
        toolPanel.add(this.add.rectangle(-(topW-12)/2 + 0.5, 0, 1, toolPanelH - 2, 0x5a5a62, 0.3)); // left highlight
        toolPanel.add(this.add.rectangle((topW-12)/2 - 0.5, 0, 1, toolPanelH - 2, 0x2e2e34, 0.4));  // right shadow
        // Brushed metal
        for (let tl = -10; tl <= 10; tl += 2) {
            toolPanel.add(this.add.rectangle(0, tl, topW - 16, 0.5, 0x4a4a50, 0.3));
        }
        // Hanging tools
        toolPanel.add(this.add.rectangle(-32, 1, 2, 10, 0x5a5a60)); // hammer shaft
        toolPanel.add(this.add.rectangle(-32, -5, 7, 3, 0x6e6e74)); // hammer head
        toolPanel.add(this.add.rectangle(-20, 0, 1.5, 12, 0x6a6a72)); // wrench
        toolPanel.add(this.add.rectangle(-20, -6, 4, 2.5, 0x7a7a82));
        toolPanel.add(this.add.rectangle(-20, 6, 4, 2.5, 0x7a7a82));
        toolPanel.add(this.add.rectangle(-8, -1, 2.5, 8, 0x5a5a64)); // pliers
        toolPanel.add(this.add.rectangle(-8, 3, 4, 3, 0x6a6a72));
        [4, 12, 20].forEach((sx, i) => {
            toolPanel.add(this.add.rectangle(sx, 1, 1, 9, 0x8a8a90)); // screwdriver shafts
            toolPanel.add(this.add.rectangle(sx, -4, 3, 4, [0x884444, 0x448844, 0x446688][i])); // grips
        });
        toolPanel.add(this.add.rectangle(30, 0, 8, 3, 0x6e6e76)); // socket wrench
        toolPanel.add(this.add.circle(30, 0, 2.5, 0x5a5a62));
        // Mask: clip to cavity region — bottom edge above hinge line
        const toolMask = this.make.graphics();
        toolMask.fillStyle(0xffffff);
        toolMask.fillRect(wbX - wbHW, y, topW, benchY + 4 - y);
        toolPanel.setMask(toolMask.createGeometryMask());
        toolPanel._hiddenY = benchY + 14;
        toolPanel._shownY = benchY - 2;
        addTo('garage', toolPanel);
        this._garageToolPanel = toolPanel;
        
        // === VEHICLE WORKBENCH (left of door) ===
        // Same mechanical structure, vehicle-themed contents
        const vbX = doorCX - 71;
        const vbHW = 48;
        const vTopW = vbHW * 2;
        
        // Heavy legs
        [-40, -14, 14, 40].forEach(lx => {
            addTo('garage', this.add.rectangle(vbX + lx, benchY + 22, 4, 7, 0x2a2a2a).setDepth(d - 0.01));
            addTo('garage', this.add.rectangle(vbX + lx, benchY + 16, 4, 7, 0x222222).setDepth(d - 0.02));
        });
        
        // Front face — heavier steel, cabinet + drawers
        addTo('garage', this.add.rectangle(vbX, benchY + 13, vTopW, 12, 0x3a3a3a).setDepth(d + 0.01));
        addTo('garage', this.add.rectangle(vbX, benchY + 13, vTopW - 2, 10, 0x444444).setDepth(d + 0.015));
        addTo('garage', this.add.rectangle(vbX, benchY + 13, vTopW - 6, 1.5, 0x333333).setDepth(d + 0.018));
        // Cabinet doors (right half)
        addTo('garage', this.add.rectangle(vbX + 22, benchY + 13, 44, 10, 0x3e3e3e).setDepth(d + 0.02));
        addTo('garage', this.add.rectangle(vbX + 11, benchY + 13, 20, 8, 0x484848).setDepth(d + 0.025));
        addTo('garage', this.add.rectangle(vbX + 33, benchY + 13, 20, 8, 0x484848).setDepth(d + 0.025));
        addTo('garage', this.add.rectangle(vbX + 11, benchY + 13, 3, 1, 0x6a6a6a).setDepth(d + 0.03));
        addTo('garage', this.add.rectangle(vbX + 33, benchY + 13, 3, 1, 0x6a6a6a).setDepth(d + 0.03));
        // Drawer bank (left half)
        addTo('garage', this.add.rectangle(vbX - 22, benchY + 10, 40, 4, 0x404040).setDepth(d + 0.02));
        addTo('garage', this.add.rectangle(vbX - 22, benchY + 10, 38, 3, 0x4a4a4a).setDepth(d + 0.025));
        addTo('garage', this.add.rectangle(vbX - 22, benchY + 10, 10, 1, 0x6a6a6a).setDepth(d + 0.03));
        addTo('garage', this.add.rectangle(vbX - 22, benchY + 16, 40, 4, 0x404040).setDepth(d + 0.02));
        addTo('garage', this.add.rectangle(vbX - 22, benchY + 16, 38, 3, 0x4a4a4a).setDepth(d + 0.025));
        addTo('garage', this.add.rectangle(vbX - 22, benchY + 16, 10, 1, 0x6a6a6a).setDepth(d + 0.03));
        // Lower shelf with oil cans
        addTo('garage', this.add.rectangle(vbX, benchY + 21, vTopW - 8, 4, 0x333333).setDepth(d + 0.01));
        [-30, -22, -14, 10, 18].forEach(ox => {
            addTo('garage', this.add.rectangle(vbX + ox, benchY + 20, 5, 3, 0x3a4a3a).setDepth(d + 0.02));
            addTo('garage', this.add.ellipse(vbX + ox, benchY + 18.5, 5, 2, 0x4a5a4a).setDepth(d + 0.025));
        });
        
        // Metal edge trim
        addTo('garage', this.add.rectangle(vbX, benchY + 0, vTopW, 1.5, 0x666666).setDepth(d + 0.05));
        
        // Cavity interior
        addTo('garage', this.add.rectangle(vbX, benchY + 4, vTopW - 4, 8, 0x1a1a1e).setDepth(d + 0.035));
        addTo('garage', this.add.rectangle(vbX, benchY + 4, vTopW - 6, 6, 0x222226).setDepth(d + 0.036));
        
        // Hinge brackets
        [-vbHW + 6, vbHW - 6].forEach(hx => {
            addTo('garage', this.add.rectangle(vbX + hx, benchY - 1, 8, 3, 0x555558).setDepth(d + 0.08));
            addTo('garage', this.add.rectangle(vbX + hx, benchY - 1, 6, 2, 0x6a6a6e).setDepth(d + 0.085));
            addTo('garage', this.add.circle(vbX + hx, benchY - 1, 1.2, 0x77777a).setDepth(d + 0.09));
        });
        
        // === VEHICLE LID ===
        const vehLid = this.add.container(vbX, benchY);
        vehLid.setDepth(d + 0.06);
        vehLid.add(this.add.rectangle(0, lidH/2, vTopW, lidH, 0x4a4a4a));
        vehLid.add(this.add.rectangle(0, lidH/2, vTopW - 2, lidH - 1, 0x555555));
        for (let rx = -vTopW/2 + 8; rx < vTopW/2 - 8; rx += 12) {
            vehLid.add(this.add.rectangle(rx, lidH/2, 8, 0.5, 0x666666, 0.5));
        }
        vehLid.add(this.add.rectangle(0, lidH - 1.5, 24, 2, 0x5a5a5a));
        vehLid.add(this.add.rectangle(0, lidH - 1.5, 22, 1, 0x6a6a6a));
        addTo('garage', vehLid);
        this._garageVehLid = vehLid;
        
        // === VEHICLE PANEL (rises from cavity) ===
        const vehPanel = this.add.container(vbX, benchY + 14);
        vehPanel.setDepth(d + 0.095);
        vehPanel.add(this.add.rectangle(0, 0, vTopW - 10, toolPanelH, 0x383840));
        vehPanel.add(this.add.rectangle(0, 0, vTopW - 12, toolPanelH - 2, 0x424248));
        // Border frame — raised edge
        const vehBorder = this.add.rectangle(0, 0, vTopW - 10, toolPanelH);
        vehBorder.setFillStyle(0x000000, 0);
        vehBorder.setStrokeStyle(1.5, 0x5a5a62, 0.8);
        vehPanel.add(vehBorder);
        // Inner bevel highlights
        vehPanel.add(this.add.rectangle(0, -toolPanelH/2 + 0.5, vTopW - 12, 1, 0x5e5e66, 0.4));
        vehPanel.add(this.add.rectangle(0, toolPanelH/2 - 0.5, vTopW - 12, 1, 0x28282e, 0.5));
        vehPanel.add(this.add.rectangle(-(vTopW-12)/2 + 0.5, 0, 1, toolPanelH - 2, 0x545460, 0.3));
        vehPanel.add(this.add.rectangle((vTopW-12)/2 - 0.5, 0, 1, toolPanelH - 2, 0x2a2a30, 0.4));
        // Diamond plate pattern
        for (let dx = -38; dx <= 38; dx += 6) {
            for (let dy = -10; dy <= 10; dy += 6) {
                const off = (Math.floor(dy / 6) % 2) * 3;
                vehPanel.add(this.add.rectangle(dx + off, dy, 2, 1, 0x4e4e54, 0.25).setAngle(45));
            }
        }
        // Vehicle parts
        vehPanel.add(this.add.circle(-32, 0, 6, 0x55555c, 0.7)); // brake disc
        vehPanel.add(this.add.circle(-32, 0, 4, 0x3e3e44, 0.6));
        vehPanel.add(this.add.circle(-32, 0, 1.5, 0x6a6a72));
        [-16, -10].forEach(sx => { // spark plugs
            vehPanel.add(this.add.rectangle(sx, 0, 1.5, 9, 0x8a8a90));
            vehPanel.add(this.add.rectangle(sx, -5, 3, 3, 0x776644));
        });
        vehPanel.add(this.add.ellipse(2, 0, 14, 9, 0x000000, 0).setStrokeStyle(1.5, 0x4a4a52, 0.5)); // belt
        vehPanel.add(this.add.rectangle(18, 0, 7, 9, 0x5a5a64)); // piston
        vehPanel.add(this.add.rectangle(18, -5, 5, 3, 0x6e6e76));
        vehPanel.add(this.add.circle(32, -1, 4, 0x2a4a2a)); // oil filter
        vehPanel.add(this.add.circle(32, -1, 2.5, 0x3a5a3a));
        // Mask to cavity region — bottom edge above hinge line
        const vehMask = this.make.graphics();
        vehMask.fillStyle(0xffffff);
        vehMask.fillRect(vbX - vbHW, y, vTopW, benchY + 4 - y);
        vehPanel.setMask(vehMask.createGeometryMask());
        vehPanel._hiddenY = benchY + 14;
        vehPanel._shownY = benchY - 2;
        addTo('garage', vehPanel);
        this._garageVehPanel = vehPanel;
        
        // === RETRACTABLE EAST WALL (split door — north/south halves) ===
        // The east wall IS the door. Two halves retract away from center.
        // ¾ iso: east wall = side face dominant + front sliver left (NO top strip)
        const garWall = this.ROOMS.hub.wall; // Match perimeter wall color
        const garDk = IsoRenderer.darken(garWall, 0.15);
        const garLt = IsoRenderer.lighten(garWall, 0.1);
        const garEdge = IsoRenderer.darken(garWall, 0.25);
        const garHi = IsoRenderer.lighten(garWall, 0.2);
        const garMetal = IsoRenderer.darken(garWall, 0.2);
        const garMetalLt = IsoRenderer.lighten(garWall, 0.05);
        
        const doorW = WC.sideW;
        const wallInnerTop = y + WC.frontH + WC.topH;
        const wallInnerBot = y + h - WC.frontH;
        const wallSpan = wallInnerBot - wallInnerTop;
        const doorX = x + w - WC.sideW / 2;
        const doorMidY = wallInnerTop + wallSpan / 2;
        const halfSpan = wallSpan / 2;
        const doorD = 10 + doorMidY * 0.01;
        
        // === STATIC EAST WALL SEGMENT above retractable door ===
        // Fills gap from hub south wall junction down to where retractable door starts
        // Extends upward by wallThick to cover the hub south wall corner
        {
            const extTop = y - (WC.frontH + WC.topH); // extend up to cover hub junction
            const extBot = wallInnerTop;
            const extH = extBot - extTop;
            const extCY = extTop + extH/2;
            addTo('garage', this.add.rectangle(x + w - WC.sideW/2, extCY, WC.sideW, extH, garDk).setDepth(5));
            addTo('garage', this.add.rectangle(x + w - WC.sideW + WC.sideSliver/2, extCY, WC.sideSliver, extH, garWall, 0.5).setDepth(5.01));
            addTo('garage', this.add.rectangle(x + w - 1, extCY, 1, extH, garEdge, 0.5).setDepth(5.01));
        }
        
        // === CENTER SEAM (visible when closed — the split line) ===
        addTo('garage', this.add.rectangle(doorX, doorMidY, doorW + 2, 2, garEdge).setDepth(doorD + 0.02));
        addTo('garage', this.add.rectangle(doorX, doorMidY, doorW, 1, garLt, 0.4).setDepth(doorD + 0.025));
        
        // Helper: build one isometric half-panel for east wall
        const buildIsoHalf = (container, halfH, panelCount) => {
            const panelH = halfH / panelCount;
            for (let i = 0; i < panelCount; i++) {
                const py = -halfH/2 + i * panelH + panelH/2;
                const shade = i % 2 === 0 ? garDk : IsoRenderer.darken(garWall, 0.12);
                // Side face (dominant depth panel)
                container.add(this.add.rectangle(0, py, doorW, panelH - 1, shade));
                // Horizontal groove at panel joint
                container.add(this.add.rectangle(0, py + panelH/2 - 0.5, doorW, 1.5, garEdge, 0.7));
                // Front sliver (left side — east wall, front recedes left)
                container.add(this.add.rectangle(-doorW/2 - 1, py, 2, panelH - 1, garMetalLt, 0.5));
                // Far edge highlight (right side)
                container.add(this.add.rectangle(doorW/2 - 0.5, py, 1, panelH - 1, garEdge, 0.5));
                // Rivet pairs at joints
                if (i < panelCount - 1) {
                    [-doorW/2 + 2, doorW/2 - 2].forEach(rx => {
                        container.add(this.add.circle(rx, py + panelH/2 - 0.5, 1.2, garMetalLt, 0.5));
                    });
                }
            }
            // ¾ iso east wall: NO top strip (camera doesn't see top of side walls)
        };
        
        // === NORTH HALF (retracts upward/north) ===
        const panelsPerHalf = 4;
        const northDoor = this.add.container(doorX, wallInnerTop + halfSpan / 2).setDepth(doorD);
        buildIsoHalf(northDoor, halfSpan, panelsPerHalf);
        // Front face strip at bottom edge (visible during retraction, ¾ iso depth)
        northDoor.add(this.add.rectangle(0, halfSpan/2 + 1, doorW + 2, 3, garWall));
        northDoor.add(this.add.rectangle(0, halfSpan/2 + 2.5, doorW, 1, garLt, 0.4));
        // Handle bar on north half
        northDoor.add(this.add.rectangle(0, 8, doorW * 0.5, 2, garMetal));
        northDoor.add(this.add.rectangle(0, 7, doorW * 0.5, 1, garMetalLt, 0.4));
        const northMask = this.make.graphics();
        northMask.fillStyle(0xffffff);
        northMask.fillRect(doorX - doorW/2 - 4, wallInnerTop - halfSpan - WC.topH - 4, doorW + 8, halfSpan * 2 + WC.topH + 8);
        northDoor.setMask(northMask.createGeometryMask());
        addTo('garage', northDoor);
        
        // === SOUTH HALF (retracts downward/south) ===
        const southDoor = this.add.container(doorX, wallInnerTop + halfSpan + halfSpan / 2).setDepth(doorD);
        buildIsoHalf(southDoor, halfSpan, panelsPerHalf);
        // Front face strip at top edge (visible during retraction, ¾ iso depth)
        southDoor.add(this.add.rectangle(0, -halfSpan/2 - 1, doorW + 2, 3, garWall));
        southDoor.add(this.add.rectangle(0, -halfSpan/2 - 2.5, doorW, 1, garLt, 0.4));
        // Handle bar on south half
        southDoor.add(this.add.rectangle(0, -8, doorW * 0.5, 2, garMetal));
        southDoor.add(this.add.rectangle(0, -9, doorW * 0.5, 1, garMetalLt, 0.4));
        const southMask = this.make.graphics();
        southMask.fillStyle(0xffffff);
        southMask.fillRect(doorX - doorW/2 - 4, doorMidY, doorW + 8, halfSpan * 2 + WC.topH + 8);
        southDoor.setMask(southMask.createGeometryMask());
        addTo('garage', southDoor);
        
        // Store for departure — collapse animation uses scaleY, not translation
        this._garageDoorNorth = northDoor;
        this._garageDoorSouth = southDoor;
        this._garageDoorMidY = doorMidY;
        this._garageDoorX = doorX;
        this._garageDoorHalf = halfSpan;
    }
    
    _createBarracksProps(addTo, WC, wallH) {
        const r = this.ROOMS.barracks;
        const x = r.x, y = r.y, w = r.w, h = r.h;
        const innerL = x + WC.sideW;
        const innerW = w - 2 * WC.sideW;
        
        // === 3 BUNK BEDS on north wall ===
        // ¾ iso north wall: 70% front face + 30% top visible
        // Player looks head-on but slightly from above — mattress tops clearly visible
        const bunkW = 48, bunkGap = (innerW - 3 * bunkW) / 4;
        const bunkY = y + wallH + 6;
        
        for (let bi = 0; bi < 3; bi++) {
            const cx = innerL + bunkGap + bunkW/2 + bi * (bunkW + bunkGap);
            const d = 3.5;
            const hx = bunkW/2 - 2; // post offset
            
            // ── CORNER POSTS (4 vertical bars) ──
            [[-hx, 0], [hx, 0]].forEach(([px]) => {
                addTo('barracks', this.add.rectangle(cx + px, bunkY + 6, 3, 48, 0x3a3a3a).setDepth(d + 0.01));
                addTo('barracks', this.add.rectangle(cx + px, bunkY + 6, 1, 46, 0x4a4a4a, 0.4).setDepth(d + 0.015));
            });
            // Back posts (darker)
            [[-hx, 0], [hx, 0]].forEach(([px]) => {
                addTo('barracks', this.add.rectangle(cx + px, bunkY, 3, 42, 0x2e2e2e).setDepth(d - 0.01));
            });
            
            // ── LOWER BUNK ──
            const lowerY = bunkY + 18;
            // Support rail (front face)
            addTo('barracks', this.add.rectangle(cx, lowerY + 2, bunkW - 4, 2, 0x3a3a3a).setDepth(d + 0.02));
            
            // --- Mattress TOP surface (visible from above — the key ¾ view element) ---
            addTo('barracks', this.add.rectangle(cx, lowerY - 4, bunkW - 8, 8, 0x6a6a5a).setDepth(d + 0.04));  // mattress top
            addTo('barracks', this.add.rectangle(cx, lowerY - 4, bunkW - 10, 6, 0x7a7a6a).setDepth(d + 0.045)); // lighter center
            // Pillow on top surface (seen from above — puffy ellipse)
            addTo('barracks', this.add.ellipse(cx - bunkW/2 + 14, lowerY - 5, 12, 6, 0x8a8a7a).setDepth(d + 0.05));
            addTo('barracks', this.add.ellipse(cx - bunkW/2 + 14, lowerY - 6, 9, 4, 0x9a9a8a).setDepth(d + 0.055));
            // Blanket on top surface (covers right half)
            addTo('barracks', this.add.rectangle(cx + 6, lowerY - 3, bunkW/2 - 6, 6, 0x4a5a5a, 0.6).setDepth(d + 0.048));
            addTo('barracks', this.add.rectangle(cx + 6, lowerY - 1, bunkW/2 - 8, 0.5, 0x3a4a4a, 0.3).setDepth(d + 0.049)); // wrinkle
            
            // --- Mattress FRONT face (front edge visible below top surface) ---
            addTo('barracks', this.add.rectangle(cx, lowerY + 0, bunkW - 8, 3, 0x5a5a4a).setDepth(d + 0.03));
            addTo('barracks', this.add.rectangle(cx, lowerY + 0, bunkW - 10, 2, 0x5e5e4e).setDepth(d + 0.035));
            
            // ── UPPER BUNK ──
            const upperY = bunkY - 8;
            // Support rail
            addTo('barracks', this.add.rectangle(cx, upperY + 2, bunkW - 4, 2, 0x3a3a3a).setDepth(d + 0.06));
            
            // --- Mattress TOP surface ---
            addTo('barracks', this.add.rectangle(cx, upperY - 4, bunkW - 8, 8, 0x6a6a5a).setDepth(d + 0.08));
            addTo('barracks', this.add.rectangle(cx, upperY - 4, bunkW - 10, 6, 0x7a7a6a).setDepth(d + 0.085));
            // Pillow
            addTo('barracks', this.add.ellipse(cx - bunkW/2 + 14, upperY - 5, 12, 6, 0x8a8a7a).setDepth(d + 0.09));
            addTo('barracks', this.add.ellipse(cx - bunkW/2 + 14, upperY - 6, 9, 4, 0x9a9a8a).setDepth(d + 0.095));
            // Blanket
            addTo('barracks', this.add.rectangle(cx + 6, upperY - 3, bunkW/2 - 6, 6, 0x4a5a5a, 0.6).setDepth(d + 0.088));
            
            // --- Mattress FRONT face ---
            addTo('barracks', this.add.rectangle(cx, upperY + 0, bunkW - 8, 3, 0x5a5a4a).setDepth(d + 0.07));
            
            // ── SAFETY RAIL (upper bunk front) ──
            addTo('barracks', this.add.rectangle(cx, upperY - 9, bunkW - 4, 1.5, 0x444444).setDepth(d + 0.10));
            addTo('barracks', this.add.rectangle(cx, upperY - 9, bunkW - 6, 0.5, 0x555555, 0.4).setDepth(d + 0.105));
            
            // ── LADDER (right side) ──
            const ladX = cx + hx + 3;
            addTo('barracks', this.add.rectangle(ladX - 2, bunkY + 4, 1.5, 34, 0x4a4a4a).setDepth(d + 0.11));
            addTo('barracks', this.add.rectangle(ladX + 2, bunkY + 4, 1.5, 34, 0x4a4a4a).setDepth(d + 0.11));
            for (let ri = 0; ri < 4; ri++) {
                const ry2 = bunkY - 6 + ri * 8;
                addTo('barracks', this.add.rectangle(ladX, ry2, 5, 1.5, 0x555555).setDepth(d + 0.12));
                addTo('barracks', this.add.rectangle(ladX, ry2 - 0.5, 4, 0.5, 0x666666, 0.3).setDepth(d + 0.125));
            }
            
            // ── TOP CROSSBAR + POST CAPS ──
            addTo('barracks', this.add.rectangle(cx, bunkY - 16, bunkW - 2, 2, 0x3a3a3a).setDepth(d + 0.13));
            addTo('barracks', this.add.rectangle(cx, bunkY - 17, bunkW - 4, 1, 0x4a4a4a, 0.3).setDepth(d + 0.135));
            addTo('barracks', this.add.rectangle(cx - hx, bunkY - 17, 4, 2, 0x4a4a4a).setDepth(d + 0.14));
            addTo('barracks', this.add.rectangle(cx + hx, bunkY - 17, 4, 2, 0x4a4a4a).setDepth(d + 0.14));
            
            // ── UNDER-BED SHADOW (lower bunk) ──
            addTo('barracks', this.add.rectangle(cx, lowerY + 12, bunkW - 10, 14, 0x000000, 0.15).setDepth(d - 0.02));
        }
        
        // Dust particles (static specks)
        for (let i = 0; i < 10; i++) {
            const dx = x + Phaser.Math.Between(20, w - 20);
            const dy = y + Phaser.Math.Between(wallH + 10, h - wallH - 10);
            addTo('barracks', this.add.circle(dx, dy, 0.5, 0xaaaaaa, Phaser.Math.FloatBetween(0.05, 0.15)).setDepth(8));
        }
    }
    
    // === WALL CONSOLES — Small upgrade terminals in every room ===
    // ¾ iso: north wall = front face wide (screen visible), thin top strip
    //        east wall  = side face dominant, screen as thin sliver  
    //        west wall  = mirror of east
    _createWallConsole(roomId, x, y, wallDir, addTo) {
        const c = this.add.container(x, y);
        const d = 10;
        
        if (wallDir === 'north') {
            // Front face dominant — screen visible, 16w × 14h body
            // Mounting bracket (bolted to wall)
            c.add(this.add.rectangle(0, -2, 20, 2, 0x2a2a30).setDepth(d - 0.01));
            c.add(this.add.rectangle(-9, -1, 2, 2, 0x3a3a40).setDepth(d - 0.005)); // left bolt
            c.add(this.add.rectangle(9, -1, 2, 2, 0x3a3a40).setDepth(d - 0.005));  // right bolt
            // Top strip (foreshortened — 3px tall)
            c.add(this.add.rectangle(0, 0, 18, 3, 0x3a3a42).setDepth(d));
            c.add(this.add.rectangle(0, 0, 16, 2, 0x444450).setDepth(d + 0.001)); // highlight
            // Front face body
            c.add(this.add.rectangle(0, 6, 18, 10, 0x1e1e28).setDepth(d + 0.01));
            c.add(this.add.rectangle(0, 6, 16, 8, 0x222230).setDepth(d + 0.011));
            // Screen inset
            c.add(this.add.rectangle(0, 5, 12, 5, 0x0a1a12).setDepth(d + 0.02));
            c.add(this.add.rectangle(0, 5, 10, 4, 0x0e2218).setDepth(d + 0.021));
            // Screen glow line (standby pulse)
            const glow = this.add.rectangle(0, 5, 8, 1, 0x33aa55, 0.4).setDepth(d + 0.025);
            c.add(glow);
            c._screenGlow = glow;
            // Status LED
            c.add(this.add.circle(6, 9, 1, 0x44aa44, 0.6).setDepth(d + 0.03));
            // Bottom edge + vent slits
            c.add(this.add.rectangle(0, 11, 18, 1, 0x2a2a34).setDepth(d + 0.012));
            for (let vi = -5; vi <= 5; vi += 2.5) {
                c.add(this.add.rectangle(vi, 10, 0.5, 2, 0x161620, 0.5).setDepth(d + 0.013));
            }
            // Side depth edges (thin vertical lines)
            c.add(this.add.rectangle(-9, 6, 1, 10, 0x161620).setDepth(d + 0.009));
            c.add(this.add.rectangle(9, 6, 1, 10, 0x161620).setDepth(d + 0.009));
        } else if (wallDir === 'east') {
            // Side face dominant — right wall, looking at angle
            // Side panel (dominant, 8w × 12h)
            c.add(this.add.rectangle(0, 4, 8, 12, 0x1e1e28).setDepth(d + 0.01));
            c.add(this.add.rectangle(0, 4, 6, 10, 0x222230).setDepth(d + 0.011));
            // Top strip
            c.add(this.add.rectangle(0, -2, 8, 2, 0x3a3a42).setDepth(d));
            // Front face sliver (3px wide, receding left)
            c.add(this.add.rectangle(-5, 4, 3, 12, 0x1a1a24).setDepth(d + 0.008));
            c.add(this.add.rectangle(-5, 4, 2, 8, 0x0e2218).setDepth(d + 0.02)); // screen edge
            const glow = this.add.rectangle(-5, 4, 1, 6, 0x33aa55, 0.3).setDepth(d + 0.025);
            c.add(glow);
            c._screenGlow = glow;
            // Mounting bracket
            c.add(this.add.rectangle(3, -1, 2, 2, 0x3a3a40).setDepth(d - 0.005));
            // Bottom edge
            c.add(this.add.rectangle(0, 10, 8, 1, 0x2a2a34).setDepth(d + 0.012));
            // LED
            c.add(this.add.circle(-3, 8, 0.8, 0x44aa44, 0.5).setDepth(d + 0.03));
        } else if (wallDir === 'west') {
            // Mirror of east — left wall
            c.add(this.add.rectangle(0, 4, 8, 12, 0x1e1e28).setDepth(d + 0.01));
            c.add(this.add.rectangle(0, 4, 6, 10, 0x222230).setDepth(d + 0.011));
            c.add(this.add.rectangle(0, -2, 8, 2, 0x3a3a42).setDepth(d));
            // Front face sliver receding right
            c.add(this.add.rectangle(5, 4, 3, 12, 0x1a1a24).setDepth(d + 0.008));
            c.add(this.add.rectangle(5, 4, 2, 8, 0x0e2218).setDepth(d + 0.02));
            const glow = this.add.rectangle(5, 4, 1, 6, 0x33aa55, 0.3).setDepth(d + 0.025);
            c.add(glow);
            c._screenGlow = glow;
            c.add(this.add.rectangle(-3, -1, 2, 2, 0x3a3a40).setDepth(d - 0.005));
            c.add(this.add.rectangle(0, 10, 8, 1, 0x2a2a34).setDepth(d + 0.012));
            c.add(this.add.circle(3, 8, 0.8, 0x44aa44, 0.5).setDepth(d + 0.03));
        }
        
        // Standby screen pulse
        if (c._screenGlow) {
            this.tweens.add({
                targets: c._screenGlow, alpha: { from: 0.15, to: 0.5 },
                duration: 2000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
            });
        }
        
        // Notification exclamation (hidden by default, shown when upgrade available)
        const notif = this.add.container(wallDir === 'north' ? 0 : (wallDir === 'east' ? -5 : 5), -10);
        // Exclamation body
        notif.add(this.add.rectangle(0, 0, 5, 7, 0xffcc22).setDepth(d + 0.05));
        notif.add(this.add.rectangle(0, 0, 3, 5, 0xffdd44).setDepth(d + 0.051));
        // Dot below
        notif.add(this.add.rectangle(0, 5, 3, 3, 0xffcc22).setDepth(d + 0.05));
        notif.add(this.add.rectangle(0, 5, 2, 2, 0xffdd44).setDepth(d + 0.051));
        notif.setVisible(false);
        c.add(notif);
        c._notifIcon = notif;
        
        // Bob animation (runs when visible)
        this.tweens.add({
            targets: notif, y: { from: -12, to: -8 },
            duration: 600, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
        });
        
        addTo(roomId, c);
        c.setDepth(d);
        return c;
    }
    
    // Place wall consoles in all rooms and wire notification checks
    _createAllWallConsoles(addTo, WC, wallH) {
        this._wallConsoles = {};
        // North wall face center Y = room.y + WC.topH + WC.frontH * 0.5
        // East wall strip center X = room.x + room.w - WC.sideW/2
        // West wall strip center X = room.x + WC.sideW/2
        const wallFaceY = (rm) => rm.y + WC.topH + Math.floor(WC.frontH * 0.5);
        
        // Barracks — north wall, right side (clear of center bunk bed)
        const bar = this.ROOMS.barracks;
        this._wallConsoles.barracks = this._createWallConsole('barracks',
            bar.x + bar.w - WC.sideW - 18, wallFaceY(bar), 'north', addTo);
        
        // Wire barracks console as interactive station
        this._stationRoom = 'barracks';
        const bConsole = this._wallConsoles.barracks;
        bConsole._handcraftedType = 'barracks_console';
        this.addStationInteraction(bConsole,
            bar.x + bar.w - WC.sideW - 18, bar.y + wallH + 14, 40, 30, 'barracks_upgrade', 'BARRACKS',
            () => this.showBarracksUpgrade());
        
        // Check for upgrade notifications
        this._updateConsoleNotifications();
    }
    
    _updateConsoleNotifications() {
        if (!this._wallConsoles) return;
        const sd = this.saveData;
        const level = sd.upgrades.barracks || 1;
        const maxLevel = CONFIG.barracks.maxLevel;
        const upgrading = sd.barracksUpgrade;
        
        // Barracks console: show notification if upgrade available and affordable
        const barConsole = this._wallConsoles.barracks;
        if (barConsole && barConsole._notifIcon) {
            let show = false;
            if (upgrading) {
                // Check if upgrade finished
                show = Date.now() >= upgrading.finishesAt;
            } else if (level < maxLevel) {
                const next = CONFIG.barracks.levels[level + 1];
                if (next && sd.stash.bits >= next.costBits && (sd.stash.materials || 0) >= next.costMaterials) {
                    show = true;
                }
            }
            barConsole._notifIcon.setVisible(show);
        }
    }
    
    showBarracksUpgrade() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const sd = this.saveData;
        const level = sd.upgrades.barracks || 1;
        const maxLevel = CONFIG.barracks.maxLevel;
        const currentDef = CONFIG.barracks.levels[level];
        const upgrading = sd.barracksUpgrade;
        
        UIAtlas.build(this);
        const panel = UIManager.createPanel(this, W/2, H/2, 280, 260, {
            title: 'BARRACKS', accent: 'default', closable: true,
            onClose: () => { this.popupActive = false; }, depth: 200, modal: true
        });
        const cb = panel._contentBounds;
        let yOff = cb.y;
        
        // Current level info
        panel.add(this.add.text(0, yOff, `${currentDef.label} — Level ${level}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#ccddee', fontStyle: 'bold'
        }).setOrigin(0.5));
        yOff += 18;
        
        const alive = (sd.survivors || []).filter(s => s.alive).length;
        panel.add(this.add.text(0, yOff, `Survivors: ${alive} / ${currentDef.maxSurvivors}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: alive >= currentDef.maxSurvivors ? '#cc6644' : '#88aa88'
        }).setOrigin(0.5));
        yOff += 22;
        
        // Divider
        const dg = this.add.graphics();
        dg.lineStyle(1, 0x334455, 0.4);
        dg.lineBetween(-120, yOff, 120, yOff);
        panel.add(dg);
        yOff += 8;
        
        if (upgrading && Date.now() < upgrading.finishesAt) {
            // Upgrade in progress — show timer
            const remaining = upgrading.finishesAt - Date.now();
            const mins = Math.ceil(remaining / 60000);
            const nextDef = CONFIG.barracks.levels[upgrading.toLevel];
            
            panel.add(this.add.text(0, yOff, `Upgrading to ${nextDef.label}...`, {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#aaaa44'
            }).setOrigin(0.5));
            yOff += 16;
            
            // Progress bar
            const barW = 200, barH = 10;
            const total = upgrading.finishesAt - upgrading.startedAt;
            const elapsed = Date.now() - upgrading.startedAt;
            const pct = Math.min(1, elapsed / total);
            const bg2 = this.add.graphics();
            bg2.fillStyle(0x1a1a24, 0.8);
            bg2.fillRect(-barW/2, yOff, barW, barH);
            bg2.fillStyle(0x44aa66, 0.7);
            bg2.fillRect(-barW/2, yOff, barW * pct, barH);
            bg2.lineStyle(1, 0x334455, 0.5);
            bg2.strokeRect(-barW/2, yOff, barW, barH);
            panel.add(bg2);
            yOff += barH + 6;
            
            panel.add(this.add.text(0, yOff, mins > 1 ? `${mins} minutes remaining` : 'Less than a minute', {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#667788'
            }).setOrigin(0.5));
            yOff += 20;
            
            // Refresh timer
            this._barracksRefreshTimer = this.time.addEvent({
                delay: 5000, loop: true,
                callback: () => {
                    if (!this.popupActive) { this._barracksRefreshTimer.remove(); return; }
                    const now = Date.now();
                    if (now >= upgrading.finishesAt) {
                        this._barracksRefreshTimer.remove();
                        panel.destroy(); this.popupActive = false;
                        this.showBarracksUpgrade(); // Re-open to show completion
                    }
                }
            });
            
        } else if (upgrading && Date.now() >= upgrading.finishesAt) {
            // Upgrade complete — claim it
            panel.add(this.add.text(0, yOff, 'UPGRADE COMPLETE', {
                fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#44cc66', fontStyle: 'bold'
            }).setOrigin(0.5));
            yOff += 24;
            
            const nextDef = CONFIG.barracks.levels[upgrading.toLevel];
            panel.add(this.add.text(0, yOff, `${nextDef.label} — Capacity: ${nextDef.maxSurvivors}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aabbcc'
            }).setOrigin(0.5));
            yOff += 24;
            
            const claimBtn = UIManager.createButton(this, 0, yOff + 10, 'CLAIM', {
                width: 120, height: 34, style: 'confirm', fontSize: uiPx(12), depth: 201,
                onClick: () => {
                    sd.upgrades.barracks = upgrading.toLevel;
                    sd.barracksUpgrade = null;
                    SaveManager.save(sd);
                    AudioManager.uiClick();
                    panel.destroy(); this.popupActive = false;
                    this._updateConsoleNotifications();
                }
            });
            panel.add(claimBtn);
            
        } else if (level >= maxLevel) {
            // Max level
            panel.add(this.add.text(0, yOff + 10, 'MAX LEVEL REACHED', {
                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#cc8822', fontStyle: 'bold'
            }).setOrigin(0.5));
            panel.add(this.add.text(0, yOff + 28, `Capacity: ${currentDef.maxSurvivors} survivors`, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#667788'
            }).setOrigin(0.5));
            
        } else {
            // Show next level upgrade
            const nextLevel = level + 1;
            const nextDef = CONFIG.barracks.levels[nextLevel];
            
            panel.add(this.add.text(0, yOff, `Upgrade to ${nextDef.label} (Lv ${nextLevel})`, {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#aabbcc'
            }).setOrigin(0.5));
            yOff += 16;
            
            panel.add(this.add.text(0, yOff, `Capacity: ${currentDef.maxSurvivors} > ${nextDef.maxSurvivors} survivors`, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#44aa66'
            }).setOrigin(0.5));
            yOff += 18;
            
            // Costs
            const hasBits = sd.stash.bits >= nextDef.costBits;
            const hasMats = (sd.stash.materials || 0) >= nextDef.costMaterials;
            const canAfford = hasBits && hasMats;
            
            panel.add(this.add.text(-60, yOff, `Bits: ${nextDef.costBits}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: hasBits ? '#aaccaa' : '#cc4444'
            }));
            panel.add(this.add.text(40, yOff, `Materials: ${nextDef.costMaterials}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: hasMats ? '#aaccaa' : '#cc4444'
            }));
            yOff += 16;
            
            // Time
            const mins = Math.round(nextDef.upgradeMs / 60000);
            panel.add(this.add.text(0, yOff, `Build time: ${mins >= 60 ? Math.round(mins/60) + 'h' : mins + 'min'}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#667788'
            }).setOrigin(0.5));
            yOff += 22;
            
            if (canAfford) {
                const upgradeBtn = UIManager.createButton(this, 0, yOff + 6, 'BEGIN UPGRADE', {
                    width: 140, height: 34, style: 'confirm', fontSize: uiPx(10), depth: 201,
                    onClick: () => {
                        sd.stash.bits -= nextDef.costBits;
                        sd.stash.materials = (sd.stash.materials || 0) - nextDef.costMaterials;
                        sd.barracksUpgrade = {
                            startedAt: Date.now(),
                            finishesAt: Date.now() + nextDef.upgradeMs,
                            toLevel: nextLevel
                        };
                        SaveManager.save(sd);
                        AudioManager.uiClick();
                        panel.destroy(); this.popupActive = false;
                        this._updateConsoleNotifications();
                        this.showBarracksUpgrade(); // Re-open to show timer
                    }
                });
                panel.add(upgradeBtn);
            } else {
                panel.add(this.add.text(0, yOff + 10, 'INSUFFICIENT RESOURCES', {
                    fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#cc4444'
                }).setOrigin(0.5));
            }
        }
    }
    
    // === WALL-MOUNTED STATIONS (with perspective) ===
    // ╔════════════════════════════════════════════════════════════════╗
    // ║  SAFEHOUSE HANDCRAFTED PROPS — LOCKED                        ║
    // ║  The following station methods contain hand-positioned        ║
    // ║  ¾ iso props with per-pixel detail (rivets, wood grain,      ║
    // ║  tool profiles, hinges, vents, etc.)                         ║
    // ║                                                              ║
    // ║  DO NOT replace with buildStationVisual() or IsoRenderer.    ║
    // ║  DO NOT reduce to 3-line stubs.                              ║
    // ║  DO NOT "refactor" into ISO_DEFS.                            ║
    // ║  These are the safehouse's visual identity.                  ║
    // ║                                                              ║
    // ║  LOCKED METHODS:                                             ║
    // ║    createWorkbenchLeftWall    createChestLeftWall             ║
    // ║    createWorkbenchRightWall   createBedLeftWall               ║
    // ║    createComputerDeskLeftWall createComputerDeskBackWall      ║
    // ║    createStashCrates          createLocker                    ║
    // ║    createBedFloor             createGymEquipment              ║
    // ╚════════════════════════════════════════════════════════════════╝
    
    // === UNIVERSAL ISO STATION BUILDER ===
    // Detects nearest wall and renders via IsoRenderer with correct orientation
    detectWallOrientation(x, y) {
        const L = this.offsetX;
        const R = this.offsetX + this.roomW;
        const T = this.offsetY;
        const B = this.offsetY + this.roomH;
        const dists = {
            left: x - L,
            right: R - x,
            top: y - T,
            bottom: B - y
        };
        const wallMap = { left: 'left', right: 'right', top: 'top', bottom: 'bottom' };
        let minWall = 'top';
        let minDist = Infinity;
        for (const [wall, dist] of Object.entries(dists)) {
            if (dist < minDist) { minDist = dist; minWall = wall; }
        }
        return wallMap[minWall];
    }
    
    buildStationVisual(station, defName, x, y, scale) {
        const def = ISO_DEFS[defName];
        if (!def) return;
        const roomWall = this.detectWallOrientation(x, y);
        const wallMap = { top: 'front', left: 'left', right: 'right', bottom: 'back' };
        const wall = wallMap[roomWall] || 'front';
        // Clear existing children
        station.removeAll(true);
        // Use IsoRenderer to build into the container
        IsoRenderer.render(def, {
            scene: this,
            x: 0,
            y: 0,
            wall: wall,
            scale: scale || 1.3,
            container: station
        });
        station.setDepth(10);
        station._isoDefName = defName;
        station._isoScale = scale || 1.3;
    }
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createWorkbenchLeftWall(wx, wy) {
        // HANDCRAFTED left-wall workbench — camera sees side face as dominant (10w×16h depth panel)
        // Front face is a narrow 4px compressed sliver receding right
        const station = this.add.container(wx, wy);
        const d = 10; // base depth
        
        // === SIDE FACE (dominant — the depth of the workbench viewed from left) ===
        // Legs (back leg darker, front leg lighter — depth cue)
        station.add(this.add.rectangle(-4, 10, 3, 10, 0x3a3025).setDepth(d));      // back leg
        station.add(this.add.rectangle(4, 10, 3, 10, 0x4a4035).setDepth(d));       // front leg
        // Cross brace between legs
        station.add(this.add.rectangle(0, 8, 6, 2, 0x3a3025).setDepth(d + 0.001));
        // Workbench top surface (side view — shows thickness)
        station.add(this.add.rectangle(0, 2, 12, 4, 0x5a4a35).setDepth(d + 0.002));    // main tabletop
        station.add(this.add.rectangle(0, 0, 12, 2, 0x6a5a45).setDepth(d + 0.003));     // top highlight
        station.add(this.add.rectangle(0, 4, 12, 1, 0x3a3025).setDepth(d + 0.003));     // bottom shadow
        // Metal edge strip along the top
        station.add(this.add.rectangle(0, 0, 12, 1, 0x5a5a5a).setDepth(d + 0.004));
        // Pegboard back panel (tall, behind workbench)
        station.add(this.add.rectangle(-4, -10, 3, 16, 0x4a4a42).setDepth(d - 0.001));  // pegboard edge (dark)
        station.add(this.add.rectangle(-3, -10, 1, 16, 0x3a3a32).setDepth(d - 0.001));  // pegboard shadow
        // Tools hanging on pegboard (side view — just their profiles/edges)
        station.add(this.add.rectangle(-4, -14, 2, 6, 0x2a2a2a).setDepth(d + 0.001));   // hammer handle
        station.add(this.add.rectangle(-4, -17, 3, 2, 0x6a6a6a).setDepth(d + 0.001));   // hammer head
        station.add(this.add.rectangle(-4, -6, 1, 4, 0x5a5a5a).setDepth(d + 0.001));    // wrench
        // Vice mounted on edge (protruding toward camera)
        station.add(this.add.rectangle(5, 0, 3, 4, 0x6a6a6a).setDepth(d + 0.005));      // vice jaw
        station.add(this.add.rectangle(6, 0, 1, 3, 0x888888).setDepth(d + 0.006));       // vice screw
        // Drawer underneath
        station.add(this.add.rectangle(0, 6, 8, 3, 0x4a3a28).setDepth(d + 0.002));      // drawer body
        station.add(this.add.rectangle(2, 6, 2, 1, 0x666666).setDepth(d + 0.003));       // drawer pull
        
        // === FRONT FACE (compressed sliver receding right — ~4px wide) ===
        station.add(this.add.rectangle(7, 2, 4, 4, 0x5a4a35).setDepth(d + 0.001));      // tabletop sliver
        station.add(this.add.rectangle(7, 0, 4, 2, 0x5a5a5a).setDepth(d + 0.002));       // metal edge sliver
        station.add(this.add.rectangle(7, -6, 4, 10, 0x3a3a32).setDepth(d));             // pegboard front
        // Tool silhouette on front sliver
        station.add(this.add.rectangle(7, -10, 2, 4, 0x2a2a2a).setDepth(d + 0.001));    // tool handle
        
        // Shadow on floor
        
        station.setDepth(d);
        station.setScale(1.8);
        station._handcraftedType = 'workbench_left';
        this.addStationInteraction(station, wx + 28, wy, 55, 40, 'workbench', 'WORKBENCH',
            () => this.showWorkbench());
    }
    // ═══ END LOCKED: createWorkbenchLeftWall ═══
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createChestLeftWall(cx, cy) {
        // HANDCRAFTED left-wall chest — side face dominant (10w×18h)
        // Reinforced storage chest viewed from the left side
        const station = this.add.container(cx, cy);
        const d = 10;
        
        // === SIDE FACE (dominant — left side panel of chest) ===
        // Main body panel
        station.add(this.add.rectangle(0, 2, 14, 18, 0x5a3a25).setDepth(d));            // wood body
        station.add(this.add.rectangle(0, 2, 12, 16, 0x6a4a35).setDepth(d + 0.001));     // lighter inner panel
        // Metal reinforcement bands (horizontal straps)
        station.add(this.add.rectangle(0, -2, 14, 2, 0x555555).setDepth(d + 0.002));     // top band
        station.add(this.add.rectangle(0, 6, 14, 2, 0x555555).setDepth(d + 0.002));      // bottom band
        // Band rivets
        station.add(this.add.circle(-4, -2, 1, 0x666666).setDepth(d + 0.003));
        station.add(this.add.circle(4, -2, 1, 0x666666).setDepth(d + 0.003));
        station.add(this.add.circle(-4, 6, 1, 0x666666).setDepth(d + 0.003));
        station.add(this.add.circle(4, 6, 1, 0x666666).setDepth(d + 0.003));
        // Corner braces (L-shaped metal pieces)
        station.add(this.add.rectangle(-6, -6, 3, 3, 0x4a4a4a).setDepth(d + 0.002));    // top-left brace
        station.add(this.add.rectangle(6, -6, 3, 3, 0x4a4a4a).setDepth(d + 0.002));     // top-right brace
        station.add(this.add.rectangle(-6, 10, 3, 3, 0x4a4a4a).setDepth(d + 0.002));    // bottom-left brace
        station.add(this.add.rectangle(6, 10, 3, 3, 0x4a4a4a).setDepth(d + 0.002));     // bottom-right brace
        // Hinge visible on side (connects lid to body)
        station.add(this.add.rectangle(0, -5, 4, 3, 0x555555).setDepth(d + 0.003));
        station.add(this.add.circle(0, -5, 1.5, 0x666666).setDepth(d + 0.004));          // hinge pin
        // Wood grain detail
        station.add(this.add.rectangle(-2, 0, 8, 1, 0x5a3a20, 0.2).setDepth(d + 0.001));
        station.add(this.add.rectangle(1, 4, 6, 1, 0x5a3a20, 0.15).setDepth(d + 0.001));
        
        // === LID (top face — foreshortened, showing depth) ===
        station.add(this.add.rectangle(0, -8, 14, 5, 0x7a5a45).setDepth(d + 0.005));    // lid top
        station.add(this.add.rectangle(0, -9, 12, 3, 0x8a6a55).setDepth(d + 0.006));     // lid highlight
        // Lid metal strap
        station.add(this.add.rectangle(0, -8, 14, 1, 0x555555).setDepth(d + 0.006));
        
        // === FRONT FACE (compressed sliver receding right — ~4px) ===
        station.add(this.add.rectangle(8, 2, 4, 16, 0x6a4a35).setDepth(d + 0.001));     // front sliver
        station.add(this.add.rectangle(8, 2, 3, 5, 0x555555).setDepth(d + 0.002));       // lock plate
        station.add(this.add.circle(8, 2, 1.5, 0x666666).setDepth(d + 0.003));           // keyhole
        
        // Shadow
        
        station.setDepth(d);
        station.setScale(1.8);
        station._handcraftedType = 'chest_left';
        this.addStationInteraction(station, cx + 20, cy, 40, 38, 'stash', 'STASH',
            () => this.showStash());
    }
    // ═══ END LOCKED: createChestLeftWall ═══
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createWorkbenchRightWall(wx, wy) {
        // HANDCRAFTED right-wall workbench — camera sees right side face as dominant
        // Mirror of left wall: side face dominant, front sliver recedes LEFT
        const station = this.add.container(wx, wy);
        const d = 10;
        
        // === SIDE FACE (dominant — depth of workbench, mirrored) ===
        station.add(this.add.rectangle(4, 10, 3, 10, 0x3a3025).setDepth(d));             // back leg
        station.add(this.add.rectangle(-4, 10, 3, 10, 0x4a4035).setDepth(d));            // front leg
        station.add(this.add.rectangle(0, 8, 6, 2, 0x3a3025).setDepth(d + 0.001));
        // Workbench top
        station.add(this.add.rectangle(0, 2, 12, 4, 0x5a4a35).setDepth(d + 0.002));
        station.add(this.add.rectangle(0, 0, 12, 2, 0x6a5a45).setDepth(d + 0.003));
        station.add(this.add.rectangle(0, 4, 12, 1, 0x3a3025).setDepth(d + 0.003));
        station.add(this.add.rectangle(0, 0, 12, 1, 0x5a5a5a).setDepth(d + 0.004));
        // Pegboard
        station.add(this.add.rectangle(4, -10, 3, 16, 0x4a4a42).setDepth(d - 0.001));
        station.add(this.add.rectangle(3, -10, 1, 16, 0x3a3a32).setDepth(d - 0.001));
        // Tools
        station.add(this.add.rectangle(4, -14, 2, 6, 0x2a2a2a).setDepth(d + 0.001));
        station.add(this.add.rectangle(4, -17, 3, 2, 0x6a6a6a).setDepth(d + 0.001));
        station.add(this.add.rectangle(4, -6, 1, 4, 0x5a5a5a).setDepth(d + 0.001));
        // Vice (protrudes left toward camera)
        station.add(this.add.rectangle(-5, 0, 3, 4, 0x6a6a6a).setDepth(d + 0.005));
        station.add(this.add.rectangle(-6, 0, 1, 3, 0x888888).setDepth(d + 0.006));
        // Drawer
        station.add(this.add.rectangle(0, 6, 8, 3, 0x4a3a28).setDepth(d + 0.002));
        station.add(this.add.rectangle(-2, 6, 2, 1, 0x666666).setDepth(d + 0.003));
        
        // === FRONT FACE (compressed sliver receding LEFT) ===
        station.add(this.add.rectangle(-7, 2, 4, 4, 0x5a4a35).setDepth(d + 0.001));
        station.add(this.add.rectangle(-7, 0, 4, 2, 0x5a5a5a).setDepth(d + 0.002));
        station.add(this.add.rectangle(-7, -6, 4, 10, 0x3a3a32).setDepth(d));
        
        // Shadow
        
        station.setDepth(d);
        station.setScale(1.8);
        station._handcraftedType = 'workbench_right';
        this.addStationInteraction(station, wx - 22, wy + 5, 50, 35, 'workbench', 'WORKBENCH',
            () => this.showWorkbench());
    }
    // ═══ END LOCKED: createWorkbenchRightWall ═══
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createBedLeftWall(bx, by) {
        // HANDCRAFTED left-wall bed — side face dominant
        // Bed viewed from the left: see full side rail, mattress edge, headboard edge, footboard
        const station = this.add.container(bx, by);
        const d = 10;
        
        // === SIDE FACE (dominant — full length of bed visible) ===
        // Side rail (the long wooden bar running the bed length)
        station.add(this.add.rectangle(0, 6, 30, 3, 0x4a3a2a).setDepth(d));             // rail body
        station.add(this.add.rectangle(0, 5, 28, 1, 0x5a4a3a).setDepth(d + 0.001));      // rail top highlight
        station.add(this.add.rectangle(0, 8, 28, 1, 0x3a2a1a).setDepth(d + 0.001));      // rail bottom shadow
        // Headboard (tall panel at head end — toward wall/left)
        station.add(this.add.rectangle(-14, -2, 5, 16, 0x4a3a2a).setDepth(d + 0.002));  // headboard body
        station.add(this.add.rectangle(-14, -2, 3, 14, 0x5a4a3a).setDepth(d + 0.003));   // headboard front
        station.add(this.add.rectangle(-14, -10, 6, 3, 0x5a4a3a).setDepth(d + 0.004));   // headboard cap
        station.add(this.add.rectangle(-14, -4, 2, 6, 0x3a2a1a, 0.3).setDepth(d + 0.003)); // carved detail
        // Footboard (shorter panel at foot end — toward camera/right)
        station.add(this.add.rectangle(14, 2, 5, 10, 0x4a3a2a).setDepth(d + 0.002));    // footboard body
        station.add(this.add.rectangle(14, 2, 3, 8, 0x5a4a3a).setDepth(d + 0.003));      // footboard front
        station.add(this.add.rectangle(14, -3, 6, 3, 0x5a4a3a).setDepth(d + 0.004));     // footboard cap
        // Legs visible under the bed
        station.add(this.add.rectangle(-12, 10, 3, 4, 0x3a2a1a).setDepth(d - 0.001));   // back leg
        station.add(this.add.rectangle(12, 10, 3, 4, 0x3a2a1a).setDepth(d - 0.001));    // front leg
        // Mattress (viewed from side — see the edge/thickness)
        station.add(this.add.rectangle(0, 0, 24, 6, 0x6a6a7a).setDepth(d + 0.005));     // mattress side
        station.add(this.add.rectangle(0, 0, 22, 4, 0x7a7a8a).setDepth(d + 0.006));      // mattress lighter center
        // Mattress seam piping
        station.add(this.add.rectangle(0, -3, 22, 1, 0x8a8a9a).setDepth(d + 0.007));    // top edge piping
        station.add(this.add.rectangle(0, 3, 22, 1, 0x5a5a6a).setDepth(d + 0.007));     // bottom edge
        // Sheet/blanket (draped over, visible from side)
        station.add(this.add.rectangle(4, -2, 16, 4, 0x8a8a9a).setDepth(d + 0.008));    // sheet
        station.add(this.add.rectangle(4, -3, 14, 2, 0x9a9aaa).setDepth(d + 0.009));     // sheet fold highlight
        station.add(this.add.rectangle(10, -1, 4, 3, 0x7a7a8a).setDepth(d + 0.008));    // sheet drape
        // Pillow (viewed from side — just the edge, puffy)
        station.add(this.add.ellipse(-8, -4, 8, 5, 0x9a9aaa).setDepth(d + 0.010));      // pillow
        station.add(this.add.ellipse(-8, -5, 6, 3, 0xaaaabb).setDepth(d + 0.011));       // pillow highlight
        
        // === FRONT FACE (compressed sliver receding right — ~4px) ===
        station.add(this.add.rectangle(18, 0, 4, 10, 0x4a3a2a).setDepth(d + 0.001));    // footboard front sliver
        station.add(this.add.rectangle(18, 0, 3, 6, 0x6a6a7a).setDepth(d + 0.002));      // mattress front sliver
        
        // Shadow
        
        station.setDepth(d);
        station.setScale(1.8);
        station._handcraftedType = 'bed_left';
        this.addStationInteraction(station, bx + 26, by, 50, 40, 'bed', 'REST',
            () => this.showBed());
    }
    // ═══ END LOCKED: createBedLeftWall ═══
    
    // NEW: West wall single bed, FACING SOUTH — full bed visible
    // Positioned against west wall. Headboard north, footboard south (toward camera).
    // ¾ iso: front face (mattress/blanket/pillow) wide + dominant
    createBedWestWall(bx, by) {
        const station = this.add.container(bx, by);
        const d = 10;
        
        // === FRAME (dark wood) — single bed ~22w x 34h ===
        // Footboard (south — closest to camera, wide front face)
        station.add(this.add.rectangle(0, 16, 22, 5, 0x3a2a1a).setDepth(d + 0.02));       // body
        station.add(this.add.rectangle(0, 16, 20, 3, 0x4a3a2a).setDepth(d + 0.03));        // face
        station.add(this.add.rectangle(0, 14, 22, 2, 0x5a4a3a).setDepth(d + 0.04));        // cap
        station.add(this.add.rectangle(0, 16, 14, 1, 0x3a2a1a, 0.4).setDepth(d + 0.035));  // panel groove
        
        // Side rails (thin depth perspective)
        station.add(this.add.rectangle(-10, 0, 2, 30, 0x3a2a1a).setDepth(d + 0.01));      // left
        station.add(this.add.rectangle(10, 0, 2, 30, 0x3a2a1a).setDepth(d + 0.01));        // right
        
        // Headboard (north — against wall, taller)
        station.add(this.add.rectangle(0, -14, 22, 4, 0x3a2a1a).setDepth(d));              // front strip
        station.add(this.add.rectangle(0, -14, 20, 2, 0x4a3a2a).setDepth(d + 0.001));       // face
        station.add(this.add.rectangle(0, -17, 22, 3, 0x5a4a3a).setDepth(d + 0.005));       // top cap
        station.add(this.add.rectangle(0, -18, 20, 1, 0x6a5a4a, 0.4).setDepth(d + 0.006));  // highlight
        station.add(this.add.rectangle(0, -14, 14, 1.5, 0x3a2a1a, 0.5).setDepth(d + 0.002)); // carved recess
        // Corner posts
        station.add(this.add.rectangle(-10, -17, 3, 4, 0x4a3a2a).setDepth(d + 0.005));
        station.add(this.add.rectangle(10, -17, 3, 4, 0x4a3a2a).setDepth(d + 0.005));
        
        // Legs
        station.add(this.add.rectangle(-9, 19, 2, 3, 0x2a1a0a).setDepth(d - 0.01));
        station.add(this.add.rectangle(9, 19, 2, 3, 0x2a1a0a).setDepth(d - 0.01));
        
        // === MATTRESS (top-down view — fills frame) ===
        station.add(this.add.rectangle(0, 0, 18, 26, 0x6a6a7a).setDepth(d + 0.04));        // body
        station.add(this.add.rectangle(0, 0, 16, 24, 0x7a7a8a).setDepth(d + 0.05));         // lighter
        // Seam piping
        station.add(this.add.rectangle(0, -12, 16, 1, 0x8a8a9a).setDepth(d + 0.055));
        station.add(this.add.rectangle(0, 12, 16, 1, 0x5a5a6a).setDepth(d + 0.055));
        station.add(this.add.rectangle(-8, 0, 1, 24, 0x5a5a6a).setDepth(d + 0.055));
        station.add(this.add.rectangle(8, 0, 1, 24, 0x6a6a7a).setDepth(d + 0.055));
        // Tufting (2 columns)
        [[-4,-6],[4,-6],[-4,0],[4,0],[-4,6],[4,6]].forEach(([tx,ty]) => {
            station.add(this.add.circle(tx, ty, 0.6, 0x5a5a6a, 0.5).setDepth(d + 0.06));
        });
        
        // === SINGLE PILLOW (north end, centered) ===
        station.add(this.add.ellipse(0, -9, 14, 7, 0x9a9aaa).setDepth(d + 0.07));
        station.add(this.add.ellipse(0, -10, 11, 5, 0xaaaabb).setDepth(d + 0.08));
        station.add(this.add.rectangle(0, -9, 8, 0.5, 0x8a8a9a, 0.3).setDepth(d + 0.085));
        
        // === BLANKET (covers lower half — foldable) ===
        const coverParts = [];
        const coverMain = this.add.rectangle(0, 5, 16, 16, 0x556688).setDepth(d + 0.09);
        station.add(coverMain); coverParts.push(coverMain);
        const coverFold = this.add.rectangle(0, -2, 14, 1.5, 0x667799).setDepth(d + 0.095);
        station.add(coverFold); coverParts.push(coverFold);
        const coverDrape = this.add.rectangle(0, 13, 14, 3, 0x445577).setDepth(d + 0.092);
        station.add(coverDrape); coverParts.push(coverDrape);
        const coverWrinkle = this.add.rectangle(-2, 6, 0.5, 10, 0x4a5a77, 0.3).setDepth(d + 0.095);
        station.add(coverWrinkle); coverParts.push(coverWrinkle);
        
        station._coverParts = coverParts;
        station._coverClosed = true;
        station._coverOriginal = coverParts.map(p => ({ x: p.x, y: p.y, scaleX: p.scaleX, scaleY: p.scaleY, alpha: p.alpha }));
        station._coverOpen = [
            { x: 0, y: 12, scaleX: 1, scaleY: 0.35, alpha: 0.85 },
            { x: 0, y: 10, scaleX: 0.9, scaleY: 1, alpha: 0 },
            { x: 0, y: 15, scaleX: 1.05, scaleY: 1.2, alpha: 0.9 },
            { x: -2, y: 12, scaleX: 1, scaleY: 0.4, alpha: 0.15 }
        ];
        
        station._onApproach = (scene) => {
            if (!station._coverClosed) return;
            station._coverClosed = false;
            station._coverParts.forEach((p, i) => {
                const o = station._coverOpen[i];
                scene.tweens.add({ targets: p, x: o.x, y: o.y, scaleX: o.scaleX, scaleY: o.scaleY, alpha: o.alpha, duration: 500, ease: 'Power2' });
            });
        };
        station._onLeave = (scene) => {
            if (station._coverClosed) return;
            station._coverClosed = true;
            station._coverParts.forEach((p, i) => {
                const o = station._coverOriginal[i];
                scene.tweens.add({ targets: p, x: o.x, y: o.y, scaleX: o.scaleX, scaleY: o.scaleY, alpha: o.alpha, duration: 400, ease: 'Power2' });
            });
        };
        
        station.setDepth(d);
        station.setScale(1.8);
        station._handcraftedType = 'bed_west';
        this.addStationInteraction(station, bx + 26, by, 45, 45, 'bed', 'REST',
            () => this.showBed());
    }
    
    // NEW: Gym station with mat + 3 tools
    createGymStation(room) {
        const WC = this._wallConst;
        const wallH = WC.topH + WC.frontH;
        
        // Mat area — against south wall, scaled for 200×200 room
        const matCX = room.x + room.w / 2 + 5;
        const matCY = room.y + room.h - wallH - 22;
        const matW = 120, matH = 42;
        
        // The station container holds the mat and all 3 tools
        const station = this.add.container(matCX, matCY);
        const d = 5;
        
        // === GYM MAT (large rubberized floor mat) ===
        // Main mat body
        station.add(this.add.rectangle(0, 0, matW, matH, 0x2a2a3a).setDepth(d - 0.5));
        station.add(this.add.rectangle(0, 0, matW - 2, matH - 2, 0x333344).setDepth(d - 0.49));
        // Mat texture lines
        for (let li = -matW/2 + 10; li < matW/2; li += 12) {
            station.add(this.add.rectangle(li, 0, 0.5, matH - 6, 0x2a2a38, 0.3).setDepth(d - 0.48));
        }
        // Mat border stripe
        station.add(this.add.rectangle(0, -matH/2 + 1.5, matW - 4, 2, 0x444466, 0.4).setDepth(d - 0.47));
        station.add(this.add.rectangle(0, matH/2 - 1.5, matW - 4, 2, 0x222238, 0.4).setDepth(d - 0.47));
        // Corner grips
        [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([sx,sy]) => {
            station.add(this.add.circle(sx * (matW/2 - 4), sy * (matH/2 - 4), 2, 0x444455, 0.5).setDepth(d - 0.46));
        });
        
        // === TOOL 1: PUNCHING BAG — left (Arms/Firepower) ===
        const bagX = -matW/2 + 25;
        // Support frame (A-frame viewed from front)
        station.add(this.add.rectangle(bagX, -16, 2, 22, 0x4a4a4a).setDepth(d + 0.01));   // left post
        station.add(this.add.rectangle(bagX + 16, -16, 2, 22, 0x4a4a4a).setDepth(d + 0.01)); // right post
        station.add(this.add.rectangle(bagX + 8, -26, 20, 3, 0x555555).setDepth(d + 0.02));  // crossbar
        station.add(this.add.rectangle(bagX + 8, -27, 18, 1, 0x666666).setDepth(d + 0.03));  // bar highlight
        // Chain
        station.add(this.add.rectangle(bagX + 8, -23, 1, 4, 0x888888).setDepth(d + 0.02));
        // Bag body (heavy bag — cylinder viewed from front = rectangle)
        const bagBody = this.add.rectangle(bagX + 8, -12, 14, 20, 0x8a2222).setDepth(d + 0.04);
        station.add(bagBody);
        station.add(this.add.rectangle(bagX + 8, -12, 12, 18, 0x993333).setDepth(d + 0.05)); // face
        station.add(this.add.rectangle(bagX + 8, -12, 2, 16, 0xaa4444, 0.3).setDepth(d + 0.06)); // center highlight
        // Bag top/bottom caps
        station.add(this.add.rectangle(bagX + 8, -22, 12, 2, 0x772222).setDepth(d + 0.04));
        station.add(this.add.rectangle(bagX + 8, -2, 12, 2, 0x772222).setDepth(d + 0.04));
        // Stitching lines
        station.add(this.add.rectangle(bagX + 2, -12, 0.5, 16, 0x661111, 0.4).setDepth(d + 0.06));
        station.add(this.add.rectangle(bagX + 14, -12, 0.5, 16, 0x661111, 0.4).setDepth(d + 0.06));
        // Base feet
        station.add(this.add.rectangle(bagX, 6, 8, 2, 0x3a3a3a).setDepth(d));
        station.add(this.add.rectangle(bagX + 16, 6, 8, 2, 0x3a3a3a).setDepth(d));
        
        // === TOOL 2: AB MAT + ROLLER — center (Core/Endurance) ===
        const abX = 0;
        // Exercise mat (smaller, on top of main mat)
        station.add(this.add.rectangle(abX, 4, 28, 16, 0x444466).setDepth(d + 0.01));
        station.add(this.add.rectangle(abX, 4, 26, 14, 0x555577).setDepth(d + 0.02));
        station.add(this.add.rectangle(abX, 4, 24, 1, 0x666688, 0.3).setDepth(d + 0.03)); // center line
        // Ab roller beside mat
        station.add(this.add.rectangle(abX + 18, 6, 8, 2, 0x5a5a5a).setDepth(d + 0.04)); // axle
        station.add(this.add.circle(abX + 14, 6, 4, 0x333333).setDepth(d + 0.05));         // wheel
        station.add(this.add.circle(abX + 14, 6, 2.5, 0x444444).setDepth(d + 0.06));       // wheel face
        station.add(this.add.circle(abX + 22, 6, 4, 0x333333).setDepth(d + 0.05));         // wheel 2
        station.add(this.add.circle(abX + 22, 6, 2.5, 0x444444).setDepth(d + 0.06));
        // Grip handles
        station.add(this.add.rectangle(abX + 12, 6, 2, 5, 0x666666).setDepth(d + 0.04));
        station.add(this.add.rectangle(abX + 24, 6, 2, 5, 0x666666).setDepth(d + 0.04));
        
        // === TOOL 3: JUMP ROPE — right (Legs/Mobility) ===
        const ropeX = matW/2 - 25;
        // Rope handles
        station.add(this.add.rectangle(ropeX - 8, 2, 3, 8, 0x4a3a2a).setDepth(d + 0.04)); // left handle
        station.add(this.add.rectangle(ropeX - 8, -1, 2, 3, 0x5a4a3a).setDepth(d + 0.05)); // grip wrap
        station.add(this.add.rectangle(ropeX + 8, 4, 3, 8, 0x4a3a2a).setDepth(d + 0.04));  // right handle
        station.add(this.add.rectangle(ropeX + 8, 1, 2, 3, 0x5a4a3a).setDepth(d + 0.05));
        // Rope coiled on floor (series of arcs approximated with small rects/circles)
        const ropeCfg = this.add.graphics().setDepth(d + 0.03);
        ropeCfg.lineStyle(1.5, 0x888877, 0.6);
        ropeCfg.beginPath();
        for (let t = 0; t < Math.PI * 4; t += 0.3) {
            const rx = ropeX + Math.cos(t) * (5 + t * 0.8);
            const ry = 2 + Math.sin(t) * (3 + t * 0.4);
            if (t === 0) ropeCfg.moveTo(rx, ry); else ropeCfg.lineTo(rx, ry);
        }
        ropeCfg.strokePath();
        station.add(ropeCfg);
        // Speed counter on rope (small bump)
        station.add(this.add.circle(ropeX, -2, 2, 0x555544).setDepth(d + 0.04));
        
        // Store tool world positions for player walk-to + animated refs
        station._toolPositions = {
            arms: { x: matCX + bagX + 8, y: matCY + 10 },
            core: { x: matCX + abX, y: matCY + 10 },
            legs: { x: matCX + ropeX, y: matCY + 10 }
        };
        station._bagBody = bagBody;
        station._ropeGraphics = ropeCfg;
        
        station.setDepth(d);
        station.setScale(1.3);
        station._handcraftedType = 'gym';
        this.addStationInteraction(station, matCX + 10, matCY - 10, 80, 50, 'gym', 'GYM',
            () => this.showTraining());
    }
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createComputerDeskLeftWall(cx, cy) {
        // HANDCRAFTED left-wall computer desk — side face dominant
        // Desk depth panel visible, monitor viewed from side (thin screen edge), keyboard edge
        const station = this.add.container(cx, cy);
        const d = 10;
        
        // === SIDE FACE (dominant — desk depth panel) ===
        // Desk legs
        station.add(this.add.rectangle(-4, 18, 3, 10, 0x3a3025).setDepth(d - 0.001));   // back leg
        station.add(this.add.rectangle(4, 18, 3, 10, 0x4a4035).setDepth(d - 0.001));    // front leg
        // Desk body (side panel, shows drawer depth)
        station.add(this.add.rectangle(0, 6, 12, 12, 0x5a5045).setDepth(d + 0.002));
        station.add(this.add.rectangle(0, 4, 12, 2, 0x6a6055).setDepth(d + 0.003));      // top edge
        station.add(this.add.rectangle(0, 12, 12, 1, 0x4a4035).setDepth(d + 0.003));     // bottom edge
        // Drawer side (visible depth)
        station.add(this.add.rectangle(-3, 8, 6, 3, 0x4a4035).setDepth(d + 0.002));
        station.add(this.add.rectangle(-3, 12, 6, 3, 0x4a4035).setDepth(d + 0.002));
        
        // === MONITOR (side view — thin screen edge, stand visible) ===
        station.add(this.add.rectangle(0, -2, 3, 8, 0x2a2a2a).setDepth(d + 0.003));      // stand/neck
        station.add(this.add.rectangle(0, 2, 6, 3, 0x2a2a2a).setDepth(d + 0.003));        // stand base
        // Screen viewed from side — very thin panel
        station.add(this.add.rectangle(0, -12, 3, 18, 0x2a2a2a).setDepth(d + 0.004));    // monitor edge (thin!)
        station.add(this.add.rectangle(-1, -12, 1, 16, 0x1a3a4a).setDepth(d + 0.005));   // screen edge glow
        // Screen back panel (visible from side)
        station.add(this.add.rectangle(1, -12, 1, 16, 0x1a1a1a).setDepth(d + 0.004));
        // Monitor top
        station.add(this.add.rectangle(0, -21, 3, 1, 0x3a3a3a).setDepth(d + 0.006));
        
        // === KEYBOARD (side view — just the edge) ===
        station.add(this.add.rectangle(0, 6, 8, 2, 0x3a3a3a).setDepth(d + 0.004));
        station.add(this.add.rectangle(0, 5, 6, 1, 0x4a4a4a).setDepth(d + 0.005));
        
        // === CHAIR (side view — armrest and back) ===
        station.add(this.add.rectangle(2, 22, 10, 8, 0x4a3a3a).setDepth(d + 0.001));     // seat side
        station.add(this.add.rectangle(-1, 20, 6, 12, 0x5a4a4a).setDepth(d + 0.002));    // backrest side
        station.add(this.add.rectangle(4, 18, 6, 2, 0x4a3a3a).setDepth(d + 0.003));      // armrest
        station.add(this.add.ellipse(2, 28, 12, 4, 0x3a3a3a).setDepth(d));               // base
        
        // === FRONT FACE (compressed sliver receding right — ~4px) ===
        station.add(this.add.rectangle(7, 6, 4, 12, 0x5a5045).setDepth(d + 0.001));
        station.add(this.add.rectangle(7, -12, 4, 16, 0x2a2a2a).setDepth(d + 0.004));    // monitor front sliver
        station.add(this.add.rectangle(7, -12, 3, 14, 0x1a3a4a).setDepth(d + 0.005));    // screen sliver
        
        // Shadow
        
        station.setDepth(d);
        station.setScale(1.8);
        station._handcraftedType = 'computer_left';
        this.addStationInteraction(station, cx + 24, cy + 5, 50, 35, 'computer', 'TERMINAL',
            () => this.showTerminal());
    }
    // ═══ END LOCKED: createComputerDeskLeftWall ═══
    
    // === BACK WALL STATIONS (front-facing) ===
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createComputerDeskBackWall(cx, cy, wallW) {
        // HANDCRAFTED command terminal — NORTH wall, front face dominant, spans FULL WALL
        // Giant CRT screen bank, industrial console, green phosphor display
        // Dead screen idle, flickers on approach, flickers off on leave
        const station = this.add.container(cx, cy);
        const d = 10;
        const hw = (wallW || 240) / 2;
        
        // === FULL-WIDTH CONSOLE BANK (lower body) ===
        // Feet
        for (let fi = -1; fi <= 1; fi++) {
            station.add(this.add.rectangle(fi * hw * 0.6, 22, 6, 3, 0x18181e).setDepth(d - 0.002));
        }
        // Lower housing — spans wall
        station.add(this.add.rectangle(0, 16, hw * 2, 10, 0x1e1e28).setDepth(d));
        station.add(this.add.rectangle(0, 16, hw * 2 - 4, 8, 0x24242e).setDepth(d + 0.001));
        // Vent grille
        for (let vi = -hw + 10; vi <= hw - 10; vi += 4) {
            station.add(this.add.rectangle(vi, 16, 1, 6, 0x121220, 0.6).setDepth(d + 0.002));
        }
        // Section dividers
        station.add(this.add.rectangle(-hw * 0.33, 16, 2, 10, 0x121220).setDepth(d + 0.002));
        station.add(this.add.rectangle(hw * 0.33, 16, 2, 10, 0x121220).setDepth(d + 0.002));
        // LED bank (left section)
        for (let li = 0; li < 5; li++) {
            station.add(this.add.circle(-hw + 16 + li * 6, 14, 1.5, 0x1a3a1a, 0.35).setDepth(d + 0.003));
        }
        // Data ports (right section)
        for (let pi = 0; pi < 3; pi++) {
            const px = hw - 28 + pi * 10;
            station.add(this.add.rectangle(px, 16, 6, 3, 0x121220).setDepth(d + 0.003));
        }
        
        // === CONTROL SURFACE (full width mid section) ===
        station.add(this.add.rectangle(0, 6, hw * 2, 12, 0x26263a).setDepth(d + 0.003));
        station.add(this.add.rectangle(0, 1, hw * 2 - 4, 2, 0x34344a).setDepth(d + 0.004));
        station.add(this.add.rectangle(0, 12, hw * 2 - 4, 1, 0x14141e).setDepth(d + 0.004));
        // Side depth
        station.add(this.add.rectangle(-hw, 6, 3, 12, 0x121220).setDepth(d + 0.002));
        station.add(this.add.rectangle(hw, 6, 3, 12, 0x121220).setDepth(d + 0.002));
        // Left switches
        for (let sw = 0; sw < 4; sw++) {
            const sx = -hw + 18 + sw * 7;
            station.add(this.add.rectangle(sx, 6, 2, 4, 0x34344a).setDepth(d + 0.005));
            station.add(this.add.rectangle(sx, 5, 2, 2, 0x50506a).setDepth(d + 0.006));
        }
        // Right dials
        for (let di = 0; di < 2; di++) {
            const dx = hw - 26 + di * 14;
            station.add(this.add.circle(dx, 6, 4, 0x2a2a3a).setDepth(d + 0.005));
            station.add(this.add.circle(dx, 6, 3, 0x34344a).setDepth(d + 0.006));
            station.add(this.add.rectangle(dx, 5, 1, 3, 0x50506a).setDepth(d + 0.007));
        }
        // Button cluster (center)
        for (let bi = 0; bi < 3; bi++) {
            station.add(this.add.rectangle(-8 + bi * 8, 5, 4, 3, 0x34344a).setDepth(d + 0.005));
        }
        // Corner rivets
        station.add(this.add.circle(-hw + 4, 2, 1, 0x444450).setDepth(d + 0.005));
        station.add(this.add.circle(hw - 4, 2, 1, 0x444450).setDepth(d + 0.005));
        
        // === FLANKING EQUIPMENT — LEFT ROUTER/SERVER STACK ===
        const eqL = -hw * 0.7;  // left equipment center x
        // Server housing (front face, north wall)
        station.add(this.add.rectangle(eqL, -12, 28, 30, 0x1a1a24).setDepth(d + 0.008));
        station.add(this.add.rectangle(eqL, -12, 26, 28, 0x22222c).setDepth(d + 0.009));
        // Rack-mount units (3 stacked boxes with LED rows)
        for (let ri = 0; ri < 3; ri++) {
            const ry = -22 + ri * 10;
            station.add(this.add.rectangle(eqL, ry, 24, 8, 0x1e1e2a).setDepth(d + 0.010));
            station.add(this.add.rectangle(eqL, ry, 22, 6, 0x26263a).setDepth(d + 0.011));
            // Horizontal vent slots
            for (let vi = -8; vi <= 8; vi += 4) {
                station.add(this.add.rectangle(eqL + vi, ry, 1, 4, 0x16161e, 0.5).setDepth(d + 0.012));
            }
            // Activity LEDs (2 per unit)
            station.add(this.add.circle(eqL - 8, ry - 2, 1, 0x1a3a1a, 0.4).setDepth(d + 0.013));
            station.add(this.add.circle(eqL - 5, ry - 2, 1, 0x3a3a1a, 0.3).setDepth(d + 0.013));
        }
        // Ethernet port bank at bottom
        for (let ei = 0; ei < 4; ei++) {
            station.add(this.add.rectangle(eqL - 6 + ei * 4, 1, 3, 2, 0x0e0e16).setDepth(d + 0.012));
        }
        // Cable bundle exiting bottom
        station.add(this.add.rectangle(eqL + 4, 5, 2, 6, 0x1a1a22, 0.6).setDepth(d + 0.008));
        station.add(this.add.rectangle(eqL + 7, 4, 2, 8, 0x1a1a22, 0.5).setDepth(d + 0.008));
        // Top face (foreshortened)
        station.add(this.add.rectangle(eqL, -28, 28, 3, 0x28282e).setDepth(d + 0.015));
        
        // === FLANKING EQUIPMENT — RIGHT ROUTER/SERVER STACK ===
        const eqR = hw * 0.7;
        station.add(this.add.rectangle(eqR, -12, 28, 30, 0x1a1a24).setDepth(d + 0.008));
        station.add(this.add.rectangle(eqR, -12, 26, 28, 0x22222c).setDepth(d + 0.009));
        // Rack-mount units
        for (let ri = 0; ri < 3; ri++) {
            const ry = -22 + ri * 10;
            station.add(this.add.rectangle(eqR, ry, 24, 8, 0x1e1e2a).setDepth(d + 0.010));
            station.add(this.add.rectangle(eqR, ry, 22, 6, 0x26263a).setDepth(d + 0.011));
            for (let vi = -8; vi <= 8; vi += 4) {
                station.add(this.add.rectangle(eqR + vi, ry, 1, 4, 0x16161e, 0.5).setDepth(d + 0.012));
            }
            station.add(this.add.circle(eqR + 8, ry - 2, 1, 0x1a3a1a, 0.4).setDepth(d + 0.013));
            station.add(this.add.circle(eqR + 5, ry - 2, 1, 0x3a1a1a, 0.3).setDepth(d + 0.013));
        }
        // Patch panel — row of ports
        for (let ei = 0; ei < 4; ei++) {
            station.add(this.add.rectangle(eqR - 6 + ei * 4, 1, 3, 2, 0x0e0e16).setDepth(d + 0.012));
        }
        // Cables
        station.add(this.add.rectangle(eqR - 4, 5, 2, 6, 0x1a1a22, 0.6).setDepth(d + 0.008));
        station.add(this.add.rectangle(eqR - 7, 4, 2, 8, 0x1a1a22, 0.5).setDepth(d + 0.008));
        // Top face
        station.add(this.add.rectangle(eqR, -28, 28, 3, 0x28282e).setDepth(d + 0.015));
        
        // === CRT SCREEN (centered between router stacks) ===
        const scrW = hw * 1.1;
        const scrH = 28;
        const scrY = -17;
        // Heavy bezel
        station.add(this.add.rectangle(0, scrY, scrW + 10, scrH + 8, 0x1e1e24).setDepth(d + 0.008));
        station.add(this.add.rectangle(0, scrY, scrW + 6, scrH + 4, 0x24242a).setDepth(d + 0.009));
        // Bezel screws
        const bsx = (scrW + 8) / 2, bsy = (scrH + 6) / 2;
        [[-bsx, -bsy], [bsx, -bsy], [-bsx, bsy], [bsx, bsy]].forEach(([x, y]) => {
            station.add(this.add.circle(x, scrY + y, 1.2, 0x3a3a40).setDepth(d + 0.010));
        });
        // Screen glass — dead black idle
        const screenBg = this.add.rectangle(0, scrY, scrW, scrH, 0x040404).setDepth(d + 0.011);
        station.add(screenBg);
        station._screenBg = screenBg;
        // Scan lines (permanent subtle CRT texture)
        const scanG = this.add.graphics().setDepth(d + 0.014);
        scanG.fillStyle(0x000000, 0.10);
        for (let sl = scrY - scrH / 2; sl <= scrY + scrH / 2; sl += 2) {
            scanG.fillRect(-scrW / 2, sl, scrW, 1);
        }
        station.add(scanG);
        
        // Screen content (hidden until approach) — REAL TEXT LINES
        const screenContent = this.add.container(0, 0);
        // Phosphor green fill
        screenContent.add(this.add.rectangle(0, scrY, scrW - 4, scrH - 4, 0x061206).setDepth(d + 0.012));
        // Terminal text — monospace, green phosphor, FILLS screen width
        const termLines = [
            '> RAUM-OS v2.4.1 BOOT SEQ',
            'REACTOR CORE.........STABLE',
            'CONTAINMENT..........ONLINE',
            'CUBESIM ACCESS.......LOCKED',
            'COMMS ARRAY.........OFFLINE',
            'PERIMETER GRID......HOLDING',
            'FUEL CELL.........78% FULL',
            'THREATS DETECTED.........02',
            '> AWAITING INPUT_',
        ];
        const fontSize = 6;
        const lineH = (scrH - 6) / (termLines.length + 1);
        const textX = -scrW / 2 + 6;
        termLines.forEach((txt, i) => {
            const ty = scrY - (scrH - 6) / 2 + lineH * (i + 1);
            const alpha = (i === 0 || i === termLines.length - 1) ? 0.9 : 0.6 + Math.random() * 0.25;
            const tObj = this.add.text(textX, ty, txt, {
                fontFamily: 'monospace', fontSize: fontSize + 'px',
                color: '#33aa44', padding: { x: 0, y: 0 }
            }).setOrigin(0, 0.5).setAlpha(alpha).setDepth(d + 0.013);
            screenContent.add(tObj);
        });
        // Blinking cursor block
        const cursorY = scrY - (scrH - 6) / 2 + lineH * (termLines.length + 1);
        const cursor = this.add.rectangle(textX + 2, cursorY, 4, fontSize, 0x44cc55, 0.9).setDepth(d + 0.013);
        screenContent.add(cursor);
        station._cursor = cursor;
        // Green edge glow
        screenContent.add(this.add.rectangle(0, scrY, scrW + 8, scrH + 6, 0x1a4a1a, 0.08).setDepth(d + 0.0085));
        screenContent.setVisible(false);
        screenContent.setAlpha(0);
        station.add(screenContent);
        station._screenContent = screenContent;
        
        // Top face (foreshortened strip)
        station.add(this.add.rectangle(0, scrY - scrH / 2 - 5, scrW + 10, 4, 0x282830).setDepth(d + 0.015));
        station.add(this.add.rectangle(0, scrY - scrH / 2 - 6.5, scrW + 6, 1, 0x32323a).setDepth(d + 0.016));
        // Manufacturer plate
        station.add(this.add.rectangle(scrW / 2 - 14, scrY + scrH / 2 - 2, 10, 2, 0x222228).setDepth(d + 0.012));
        // Power LED
        const powerLed = this.add.circle(-scrW / 2 + 8, scrY + scrH / 2 - 2, 1.8, 0x0e1e0e, 0.35).setDepth(d + 0.012);
        station.add(powerLed);
        
        // Keyboard tray
        station.add(this.add.rectangle(0, 14, 42, 5, 0x1e1e28).setDepth(d + 0.005));
        station.add(this.add.rectangle(0, 13, 38, 3, 0x26263a).setDepth(d + 0.006));
        for (let kr = 0; kr < 2; kr++) {
            for (let kc = 0; kc < 16; kc++) {
                station.add(this.add.rectangle(-15 + kc * 2, 12.5 + kr * 1.5, 1.5, 1, 0x34344a, 0.4).setDepth(d + 0.007));
            }
        }
        
        station.setDepth(d);
        station._handcraftedType = 'command_terminal';
        
        // === FLICKER ON (approach) ===
        station._onApproach = (scene) => {
            station._screenContent.setVisible(true);
            screenBg.setFillStyle(0x061206);
            // Stutter on: 3 rapid flash pulses then hold
            let flickCount = 0;
            const flickIn = () => {
                station._screenContent.setAlpha(flickCount % 2 === 0 ? 0.7 : 0);
                flickCount++;
                if (flickCount < 6) {
                    scene.time.delayedCall(60, flickIn);
                } else {
                    station._screenContent.setAlpha(1);
                    // Start persistent CRT wobble
                    station._flickerTween = scene.tweens.add({ targets: station._screenContent,
                        alpha: { from: 0.92, to: 1 }, duration: 80, yoyo: true, repeat: -1 });
                }
            };
            flickIn();
            // Power LED on
            powerLed.setFillStyle(0x33cc44);
            scene.tweens.add({ targets: powerLed, alpha: { from: 0.35, to: 0.9 }, duration: 200 });
            // Cursor blink
            station._cursorTween = scene.tweens.add({ targets: cursor,
                alpha: { from: 0.9, to: 0.1 }, duration: 400, yoyo: true, repeat: -1 });
        };
        
        // === FLICKER OFF (leave) ===
        station._onLeave = (scene) => {
            if (station._cursorTween) station._cursorTween.destroy();
            if (station._flickerTween) station._flickerTween.destroy();
            // Stutter off: flash bright, flicker, die
            let flickCount = 0;
            const flickOff = () => {
                station._screenContent.setAlpha(flickCount % 2 === 0 ? 0.5 : 0.9);
                flickCount++;
                if (flickCount < 5) {
                    scene.time.delayedCall(50, flickOff);
                } else {
                    station._screenContent.setAlpha(0);
                    station._screenContent.setVisible(false);
                    screenBg.setFillStyle(0x040404);
                    powerLed.setFillStyle(0x0e1e0e);
                    powerLed.setAlpha(0.35);
                }
            };
            flickOff();
        };
        
        this.addStationInteraction(station, cx, cy + 14, hw * 1.6, 45, 'computer', 'TERMINAL',
            () => this.showTerminal());
    }
    // ═══ END LOCKED: createComputerDeskBackWall ═══
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createStashCrates(sx, sy) {
        // HANDCRAFTED stash crates — EAST wall, front faces WEST
        // Camera is south. SOUTH-FACING SIDE = dominant (plain wood/metal side panel).
        // Front (west, where latches/stencils are) = narrow sliver RECEDING LEFT.
        // Three stacked crates — individual containers for per-crate shake.
        const station = this.add.container(sx, sy);
        const d = 10;
        
        // === BOTTOM CRATE (large, olive drab wood) ===
        const botCrate = this.add.container(0, 8);
        const bsW = 12, bfW = 4, bbH = 18;
        // South-facing side (dominant) — PLAIN wood side panel
        botCrate.add(this.add.rectangle(0, 0, bsW, bbH, 0x3a4a2a).setDepth(d));
        botCrate.add(this.add.rectangle(0, 0, bsW - 2, bbH - 2, 0x4a5a3a).setDepth(d + 0.001));
        // Vertical plank seams (planks run front-to-back)
        botCrate.add(this.add.rectangle(-2, 0, 1, bbH - 4, 0x344828, 0.3).setDepth(d + 0.002));
        botCrate.add(this.add.rectangle(3, 0, 1, bbH - 4, 0x344828, 0.25).setDepth(d + 0.002));
        // Metal bands wrapping around from front (just the ends visible)
        botCrate.add(this.add.rectangle(0, -bbH * 0.3, bsW, 2, 0x4a4a45).setDepth(d + 0.003));
        botCrate.add(this.add.rectangle(0, bbH * 0.3, bsW, 2, 0x444440).setDepth(d + 0.003));
        // Band rivets on side
        botCrate.add(this.add.circle(-3, -bbH * 0.3, 0.7, 0x5a5a55).setDepth(d + 0.004));
        botCrate.add(this.add.circle(3, -bbH * 0.3, 0.7, 0x5a5a55).setDepth(d + 0.004));
        // Corner bracket at front-side edge (left edge, where front wraps)
        botCrate.add(this.add.rectangle(-bsW / 2 + 1, -bbH / 2 + 3, 2, 4, 0x4a4a45).setDepth(d + 0.004));
        botCrate.add(this.add.rectangle(-bsW / 2 + 1, bbH / 2 - 3, 2, 4, 0x404040).setDepth(d + 0.004));
        // Scuff
        botCrate.add(this.add.rectangle(1, 3, 4, 1, 0x344828, 0.15).setDepth(d + 0.002));
        // Front sliver (west, recedes LEFT of side)
        const bfx = -bsW / 2 - bfW / 2;
        botCrate.add(this.add.rectangle(bfx, 0, bfW, bbH, 0x2a3a1a).setDepth(d - 0.001));
        botCrate.add(this.add.rectangle(bfx, 0, bfW - 1, bbH - 2, 0x344a28).setDepth(d));
        // Latch on front (barely visible)
        botCrate.add(this.add.rectangle(bfx, -3, bfW - 1, 2, 0x484844).setDepth(d + 0.001));
        // Band ends on front
        botCrate.add(this.add.rectangle(bfx, -bbH * 0.3, bfW, 2, 0x3a3a35).setDepth(d + 0.001));
        botCrate.add(this.add.rectangle(bfx, bbH * 0.3, bfW, 2, 0x3a3a35).setDepth(d + 0.001));
        // Top surface
        botCrate.add(this.add.rectangle(-bfW / 4, -bbH / 2, bsW + bfW, 3, 0x5a6a4a).setDepth(d + 0.006));
        botCrate.add(this.add.rectangle(-bfW / 4, -bbH / 2 - 0.5, bsW + bfW - 2, 1, 0x6a7a5a).setDepth(d + 0.007));
        station.add(botCrate);
        station._botCrate = botCrate;
        
        // === MIDDLE CRATE (medium, darker brown) ===
        const midCrate = this.add.container(1, -6);
        const msW = 10, mfW = 3, mbH = 12;
        // South-facing side (dominant) — plain
        midCrate.add(this.add.rectangle(0, 0, msW, mbH, 0x4a3a2a).setDepth(d + 0.008));
        midCrate.add(this.add.rectangle(0, 0, msW - 2, mbH - 2, 0x5a4a3a).setDepth(d + 0.009));
        // Plank seam
        midCrate.add(this.add.rectangle(-1, 0, 1, mbH - 3, 0x4a3a28, 0.25).setDepth(d + 0.010));
        // Bands
        midCrate.add(this.add.rectangle(0, -mbH * 0.3, msW, 1.5, 0x444440).setDepth(d + 0.011));
        midCrate.add(this.add.rectangle(0, mbH * 0.3, msW, 1.5, 0x3a3a38).setDepth(d + 0.011));
        // Corner bracket at front edge
        midCrate.add(this.add.rectangle(-msW / 2 + 1, -mbH / 2 + 2, 2, 3, 0x444440).setDepth(d + 0.012));
        midCrate.add(this.add.rectangle(-msW / 2 + 1, mbH / 2 - 2, 2, 3, 0x3a3a38).setDepth(d + 0.012));
        // Front sliver (left)
        const mfx = -msW / 2 - mfW / 2;
        midCrate.add(this.add.rectangle(mfx, 0, mfW, mbH, 0x3a2a1a).setDepth(d + 0.007));
        // Rope cross on front (barely visible)
        midCrate.add(this.add.rectangle(mfx, 0, mfW, 1, 0x5a4a3a, 0.3).setDepth(d + 0.008));
        // Top surface
        midCrate.add(this.add.rectangle(-mfW / 4, -mbH / 2, msW + mfW, 2, 0x6a5a4a).setDepth(d + 0.013));
        midCrate.add(this.add.rectangle(-mfW / 4, -mbH / 2 - 0.5, msW + mfW - 2, 1, 0x7a6a5a).setDepth(d + 0.014));
        station.add(midCrate);
        station._midCrate = midCrate;
        
        // === TOP CRATE (small metal ammo box) ===
        const topCrate = this.add.container(-1, -16);
        const tsW = 8, tfW = 3, tbH = 8;
        // South-facing side (dominant) — plain metal
        topCrate.add(this.add.rectangle(0, 0, tsW, tbH, 0x3a3a3a).setDepth(d + 0.015));
        topCrate.add(this.add.rectangle(0, 0, tsW - 2, tbH - 2, 0x4a4a4a).setDepth(d + 0.016));
        // Horizontal seam
        topCrate.add(this.add.rectangle(0, 0, tsW - 2, 1, 0x333338, 0.35).setDepth(d + 0.017));
        // Front sliver (left)
        const tfx = -tsW / 2 - tfW / 2;
        topCrate.add(this.add.rectangle(tfx, 0, tfW, tbH, 0x2a2a2a).setDepth(d + 0.014));
        topCrate.add(this.add.rectangle(tfx, -1, tfW - 1, 2, 0x404044).setDepth(d + 0.015));  // latch
        // Handle and top
        topCrate.add(this.add.rectangle(-tfW / 4, -tbH / 2, tsW + tfW, 2, 0x4a4a4a).setDepth(d + 0.019));
        topCrate.add(this.add.rectangle(0, -tbH / 2 - 1, 5, 2, 0x505050).setDepth(d + 0.020));
        topCrate.add(this.add.rectangle(0, -tbH / 2 - 1, 3, 1, 0x606060).setDepth(d + 0.021));
        station.add(topCrate);
        station._topCrate = topCrate;
        
        station.setDepth(d);
        station.setScale(1.6);
        station._handcraftedType = 'stash_crates';
        
        // Proximity — staggered shake per crate
        station._onApproach = (scene) => {
            const shakeOpts = (target, delay) => ({
                targets: target, x: target.x, duration: 60, yoyo: true,
                repeat: 2, delay: delay, ease: 'Sine.easeInOut',
                onStart: () => { target._origX = target.x; },
                onUpdate: (tween) => {
                    const p = tween.progress;
                    target.x = target._origX + Math.sin(p * Math.PI * 3) * 0.8;
                },
                onComplete: () => { target.x = target._origX || target.x; }
            });
            scene.tweens.add(shakeOpts(station._botCrate, 0));
            scene.tweens.add(shakeOpts(station._midCrate, 80));
            scene.tweens.add(shakeOpts(station._topCrate, 160));
        };
        station._onLeave = () => {};
        
        this.addStationInteraction(station, sx - 12, sy, 45, 40, 'stash', 'STASH',
            () => this.showStash());
    }
    // ═══ END LOCKED: createStashCrates ═══
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createLocker(lx, ly) {
        // HANDCRAFTED back-wall (north) locker — front face wide and dominant
        // Double-door metal locker, seen head-on: doors, vents, handles, name tag all visible
        const station = this.add.container(lx, ly);
        const d = 10;
        
        // === FRONT FACE (dominant — full locker front with both doors) ===
        // Main body
        station.add(this.add.rectangle(0, 0, 22, 38, 0x5a6a6a).setDepth(d));             // outer frame
        station.add(this.add.rectangle(0, 0, 20, 36, 0x6a7a7a).setDepth(d + 0.001));      // inner panel
        // Door divider (center seam)
        station.add(this.add.rectangle(0, 0, 1, 34, 0x4a5a5a).setDepth(d + 0.004));
        // Left door panel
        station.add(this.add.rectangle(-5, 0, 9, 34, 0x6a7a7a).setDepth(d + 0.002));     // left door
        station.add(this.add.rectangle(-5, 0, 7, 32, 0x7a8a8a).setDepth(d + 0.003));      // left door face
        // Right door panel (slightly darker — depth cue)
        station.add(this.add.rectangle(5, 0, 9, 34, 0x5a6a6a).setDepth(d + 0.002));      // right door
        station.add(this.add.rectangle(5, 0, 7, 32, 0x6a7a7a).setDepth(d + 0.003));       // right door face
        // Door handles (vertical bars)
        station.add(this.add.rectangle(-2, -4, 1.5, 6, 0x888888).setDepth(d + 0.005));   // left handle
        station.add(this.add.rectangle(-2, -5, 2, 1, 0x9a9a9a).setDepth(d + 0.006));     // left handle top
        station.add(this.add.rectangle(2, -4, 1.5, 6, 0x888888).setDepth(d + 0.005));    // right handle
        station.add(this.add.rectangle(2, -5, 2, 1, 0x9a9a9a).setDepth(d + 0.006));      // right handle top
        // Vents (bottom of each door — horizontal slats)
        for (let v = 0; v < 4; v++) {
            const vy = 11 + v * 2;
            station.add(this.add.rectangle(-5, vy, 6, 1, 0x4a5a5a).setDepth(d + 0.004));  // left vent slat
            station.add(this.add.rectangle(5, vy, 6, 1, 0x4a5a5a).setDepth(d + 0.004));   // right vent slat
        }
        // Name label plate (top left door)
        station.add(this.add.rectangle(-5, -12, 7, 3, 0xaaaa88).setDepth(d + 0.005));    // label plate
        station.add(this.add.rectangle(-5, -12, 5, 1, 0x888866, 0.5).setDepth(d + 0.006)); // text line
        // Keyhole
        station.add(this.add.circle(-2, -1, 1, 0x333333).setDepth(d + 0.006));
        station.add(this.add.rectangle(-2, 0, 0.5, 2, 0x333333).setDepth(d + 0.006));
        // Hinges (left edge of left door, right edge of right door)
        station.add(this.add.rectangle(-9, -8, 1.5, 3, 0x4a5a5a).setDepth(d + 0.004));   // top left hinge
        station.add(this.add.rectangle(-9, 8, 1.5, 3, 0x4a5a5a).setDepth(d + 0.004));    // bottom left hinge
        station.add(this.add.rectangle(9, -8, 1.5, 3, 0x4a5a5a).setDepth(d + 0.004));    // top right hinge
        station.add(this.add.rectangle(9, 8, 1.5, 3, 0x4a5a5a).setDepth(d + 0.004));     // bottom right hinge
        
        // === TOP FACE (shares edge with body top at y=-19) ===
        station.add(this.add.rectangle(0, -20.5, 22, 3, 0x7a8a8a).setDepth(d + 0.008));    // top surface
        station.add(this.add.rectangle(0, -21, 20, 1, 0x8a9a9a).setDepth(d + 0.009));       // top highlight
        // Dust/items on top
        station.add(this.add.rectangle(-4, -20.5, 5, 2, 0x3a3a3a, 0.3).setDepth(d + 0.009));
        station.add(this.add.circle(6, -20.5, 1.5, 0x5a5a4a, 0.4).setDepth(d + 0.009));
        
        // === SIDE FACE (thin sliver showing depth — right edge) ===
        station.add(this.add.rectangle(12, 0, 3, 38, 0x4a5a5a).setDepth(d - 0.001));
        
        // Shadow
        
        station.setDepth(d);
        station.setScale(1.6);
        station._handcraftedType = 'locker';
        this.addStationInteraction(station, lx, ly + 2, 30, 48, 'closet', 'CLOSET',
            () => this.showCloset());
    }
    // ═══ END LOCKED: createLocker ═══
    
    createLoadoutChest(rx, ry) {
        // HANDCRAFTED loadout chest — WEST wall, front faces EAST
        // Camera is south. We see the SOUTH-FACING SIDE = dominant tall panel.
        // Front (east, where latch/opening is) = narrow sliver RECEDING RIGHT.
        // SIDE IS PLAIN WOOD. Latch, stencil, decoration are on the FRONT (barely visible).
        const station = this.add.container(rx, ry);
        const d = 10;
        
        // Dimensions (pre-scale):
        // Side (south-facing, dominant): 12w × 24h — plain wood depth panel
        // Front (east, sliver): 4w × 24h — recedes right of side
        const sW = 12, fW = 4, bH = 24;
        
        // === SOUTH-FACING SIDE (dominant — plain wood side panel) ===
        // This is the DEPTH of the chest. Plain planks, no front decoration.
        station.add(this.add.rectangle(0, 0, sW, bH, 0x3a3525).setDepth(d));
        station.add(this.add.rectangle(0, 0, sW - 2, bH - 2, 0x4a4535).setDepth(d + 0.001));
        // Vertical plank seams (planks run front-to-back, seams run top-to-bottom)
        station.add(this.add.rectangle(-2, 0, 1, bH - 4, 0x342f20, 0.3).setDepth(d + 0.002));
        station.add(this.add.rectangle(3, 0, 1, bH - 4, 0x342f20, 0.25).setDepth(d + 0.002));
        // Horizontal metal bands WRAPPING AROUND from front — visible as ends
        station.add(this.add.rectangle(0, -bH * 0.3, sW, 2, 0x4a4a45).setDepth(d + 0.003));
        station.add(this.add.rectangle(0, bH * 0.3, sW, 2, 0x444440).setDepth(d + 0.003));
        // Band rivets where they attach to side panel
        station.add(this.add.circle(-3, -bH * 0.3, 0.8, 0x5a5a55).setDepth(d + 0.004));
        station.add(this.add.circle(3, -bH * 0.3, 0.8, 0x5a5a55).setDepth(d + 0.004));
        station.add(this.add.circle(-3, bH * 0.3, 0.8, 0x5a5a55).setDepth(d + 0.004));
        station.add(this.add.circle(3, bH * 0.3, 0.8, 0x5a5a55).setDepth(d + 0.004));
        // Corner bracket where front meets side (visible at right edge only)
        station.add(this.add.rectangle(sW / 2 - 1, -bH / 2 + 3, 2, 5, 0x4a4a45).setDepth(d + 0.004));
        station.add(this.add.rectangle(sW / 2 - 1, bH / 2 - 3, 2, 5, 0x404040).setDepth(d + 0.004));
        // Wood scuffs / age
        station.add(this.add.rectangle(1, 4, 4, 1, 0x3a3520, 0.15).setDepth(d + 0.002));
        station.add(this.add.rectangle(-2, -6, 3, 1, 0x443e30, 0.12).setDepth(d + 0.002));
        // Lid seam visible on side (horizontal line where lid meets body)
        station.add(this.add.rectangle(0, -bH / 2 + 7, sW, 1, 0x2a2520).setDepth(d + 0.003));
        
        // === EAST-FACING FRONT (sliver, recedes RIGHT of side) ===
        const fx = sW / 2 + fW / 2;
        station.add(this.add.rectangle(fx, 0, fW, bH, 0x2a2520).setDepth(d - 0.001));
        station.add(this.add.rectangle(fx, 0, fW - 1, bH - 2, 0x32301a).setDepth(d));
        // Latch hardware (compressed on front — barely visible)
        station.add(this.add.rectangle(fx, -2, fW - 1, 3, 0x4a4a42).setDepth(d + 0.001));
        station.add(this.add.circle(fx, -2, 0.8, 0x5a5a50).setDepth(d + 0.002));
        // Band ends wrapping onto front
        station.add(this.add.rectangle(fx, -bH * 0.3, fW, 2, 0x3a3a35).setDepth(d + 0.001));
        station.add(this.add.rectangle(fx, bH * 0.3, fW, 2, 0x3a3a35).setDepth(d + 0.001));
        // Lid seam on front
        station.add(this.add.rectangle(fx, -bH / 2 + 7, fW, 1, 0x1a1815).setDepth(d + 0.001));
        
        // === BOTTOM (floor shadow line — matches body footprint) ===
        station.add(this.add.rectangle(fW / 2, bH / 2, sW + fW, 2, 0x1a1815).setDepth(d - 0.002));
        
        // === LID / TOP FACE — origin at LEFT (wall) edge = hinge point ===
        const lidW = sW + fW;  // 16 — covers side + front
        // Hinge at wall-side edge of body: x = -sW/2
        const lid = this.add.container(-sW / 2, -bH / 2 - 2);
        // Single clean rectangle, left edge at origin, extends right
        lid.add(this.add.rectangle(lidW / 2, 0, lidW, 4, 0x5a5545).setDepth(d + 0.006));
        lid.add(this.add.rectangle(lidW / 2, -1, lidW - 2, 1, 0x6a6555).setDepth(d + 0.007));
        station.add(lid);
        station._lid = lid;
        
        // === INTERIOR (dark recess visible when open) ===
        const interior = this.add.container(fW / 4, -bH / 2 + 3);
        interior.add(this.add.rectangle(0, 0, sW + fW - 2, 6, 0x1a1815).setDepth(d + 0.0005));
        interior.add(this.add.rectangle(0, 0, sW + fW - 4, 5, 0x22201a).setDepth(d + 0.001));
        interior.add(this.add.rectangle(-3, 0, 1, 5, 0x2a2520).setDepth(d + 0.001));
        interior.add(this.add.rectangle(3, 0, 1, 5, 0x2a2520).setDepth(d + 0.001));
        interior.setVisible(false);
        station.add(interior);
        station._interior = interior;
        
        // === EQUIPPED ITEMS (visible when open) ===
        const eq = this.saveData.equipment || {};
        const eqSlots = [
            { item: eq.weapon, x: -2, y: -bH / 2 + 3 },
            { item: eq.melee, x: 4, y: -bH / 2 + 3 },
            { item: eq.gear, x: 4, y: -bH / 2 + 7 }
        ];
        const itemLayer = this.add.container(0, 0);
        eqSlots.forEach(es => {
            if (es.item) {
                const color = ItemManager.getItemColor(es.item);
                itemLayer.add(this.add.circle(es.x, es.y, 4, color, 0.25).setDepth(d + 0.002));
                if (es.item.flair && (es.item.category === 'weapon' || es.item.category === 'melee')) {
                    InventoryUI.addFlairRackEffect(this, itemLayer, es.x, es.y, es.item.flair);
                }
                ItemManager.drawItemPixelArt(this, itemLayer, es.x, es.y, es.item, 0.7, d + 0.003);
            }
        });
        itemLayer.setVisible(false);
        station.add(itemLayer);
        station._itemLayer = itemLayer;
        
        station.setDepth(d);
        station.setScale(1.6);
        this.loadoutRack = station;
        this.loadoutRackPos = { x: rx, y: ry };
        
        // Proximity — lid rotates open EAST (pivots from wall/left hinge edge)
        // Children are offset so container origin = hinge point
        // Negative angle = CCW = east/right edge lifts up
        station._onApproach = (scene) => {
            station._interior.setVisible(true);
            station._itemLayer.setVisible(true);
            scene.tweens.add({ targets: station._lid,
                angle: -78,
                duration: 350, ease: 'Back.easeOut'
            });
        };
        station._onLeave = (scene) => {
            scene.tweens.add({ targets: station._lid,
                angle: 0,
                duration: 280, ease: 'Sine.easeIn',
                onComplete: () => { station._interior.setVisible(false); station._itemLayer.setVisible(false); }
            });
        };
        
        this.addStationInteraction(station, rx + 14, ry, 40, 35, 'loadout', 'LOADOUT',
            () => this.showLoadout());
    }
    

    
    refreshLoadoutRack() {
        if (this.loadoutRack) {
            const curX = this.loadoutRack.x;
            const curY = this.loadoutRack.y;
            const roomId = this.loadoutRack._roomId || 'hub';
            
            const oldIdx = this.stations.indexOf(this.loadoutRack);
            if (oldIdx >= 0) this.stations.splice(oldIdx, 1);
            
            this.loadoutRack.destroy();
            this.loadoutRackPos = { x: curX, y: curY };
            
            // Restore correct room context before recreating
            const prevRoom = this._stationRoom;
            this._stationRoom = roomId;
            this.createLoadoutChest(curX, curY);
            this._stationRoom = prevRoom;
        }
    }
    
    createBackpackDisplay(bx, by, facing) {
        // Backpack drawn in proper ¾ isometric perspective for each facing
        // facing: 0=North (front face visible), 1=East (right side), 2=South (back), 3=West (left side)
        if (facing === undefined) facing = (this.saveData.safehouse && this.saveData.safehouse.backpackFacing) || 0;
        const station = this.add.container(bx, by);
        
        // Get backpack color
        const bpId = (SpriteManager.playerCustomization && SpriteManager.playerCustomization.backpack) || 'green';
        const bpDef = CONFIG.customization.backpackColors.find(c => c.id === bpId) || CONFIG.customization.backpackColors[0];
        const base = parseInt(bpDef.base.replace('#', ''), 16);
        const dark = parseInt(bpDef.dark.replace('#', ''), 16);
        const light = parseInt(bpDef.light.replace('#', ''), 16);
        const accent = parseInt(bpDef.accent.replace('#', ''), 16);
        
        if (facing === 0) {
            // NORTH — player faces it head-on. Front face wide, thin top strip.
            // Front face (wide, dominant — pocket visible)
            station.add(this.add.rectangle(0, 0, 14, 18, base));
            // Top surface (foreshortened)
            station.add(this.add.rectangle(0, -10, 14, 3, light));
            // Top flap
            station.add(this.add.rectangle(0, -8, 12, 2, accent));
            // Front pocket
            station.add(this.add.rectangle(0, 3, 8, 6, dark));
            station.add(this.add.rectangle(0, 3, 7, 5, light).setAlpha(0.3));
            // Buckle
            station.add(this.add.rectangle(0, 0, 4, 2, accent));
            // Side edges (thin depth lines)
            station.add(this.add.rectangle(-7, 0, 1, 16, dark));
            station.add(this.add.rectangle(7, 0, 1, 16, dark));
            // Straps dangling
            station.add(this.add.rectangle(-3, 10, 2, 5, dark));
            station.add(this.add.rectangle(3, 10, 2, 5, dark));
        } else if (facing === 1) {
            // EAST — right side dominant (depth face), front recedes left
            // Side face (dominant — depth/thickness)
            station.add(this.add.rectangle(1, 0, 10, 18, base));
            // Top
            station.add(this.add.rectangle(1, -10, 10, 2, light));
            // Front face (narrow, receding left)
            station.add(this.add.rectangle(-5, 0, 4, 16, dark));
            // Front pocket on narrow face
            station.add(this.add.rectangle(-5, 2, 3, 6, light).setAlpha(0.3));
            // Back edge
            station.add(this.add.rectangle(6, 0, 1, 16, dark));
            // Top flap
            station.add(this.add.rectangle(1, -8, 9, 2, accent));
            // Straps (on side)
            station.add(this.add.rectangle(-1, 10, 2, 5, dark));
            station.add(this.add.rectangle(3, 10, 2, 5, dark));
            // Buckle
            station.add(this.add.rectangle(1, 4, 3, 2, accent));
        } else if (facing === 2) {
            // SOUTH — player's back to it. Back panel visible, straps prominent.
            // Back face (wide, plain)
            station.add(this.add.rectangle(0, 0, 14, 18, dark));
            // Top
            station.add(this.add.rectangle(0, -10, 14, 3, light));
            // Straps (prominent — two vertical bands)
            station.add(this.add.rectangle(-3, 0, 3, 16, base));
            station.add(this.add.rectangle(3, 0, 3, 16, base));
            // Strap buckles
            station.add(this.add.rectangle(-3, 6, 2, 2, accent));
            station.add(this.add.rectangle(3, 6, 2, 2, accent));
            // Top handle loop
            station.add(this.add.rectangle(0, -9, 6, 2, accent));
            // Side edges
            station.add(this.add.rectangle(-7, 0, 1, 16, dark));
            station.add(this.add.rectangle(7, 0, 1, 16, dark));
        } else {
            // WEST — left side dominant, front recedes right (mirror of East)
            // Side face (dominant)
            station.add(this.add.rectangle(-1, 0, 10, 18, base));
            // Top
            station.add(this.add.rectangle(-1, -10, 10, 2, light));
            // Front face (narrow, receding right)
            station.add(this.add.rectangle(5, 0, 4, 16, dark));
            // Front pocket
            station.add(this.add.rectangle(5, 2, 3, 6, light).setAlpha(0.3));
            // Back edge
            station.add(this.add.rectangle(-6, 0, 1, 16, dark));
            // Top flap
            station.add(this.add.rectangle(-1, -8, 9, 2, accent));
            // Straps
            station.add(this.add.rectangle(-3, 10, 2, 5, dark));
            station.add(this.add.rectangle(1, 10, 2, 5, dark));
            // Buckle
            station.add(this.add.rectangle(-1, 4, 3, 2, accent));
        }
        
        station.setDepth(10);
        this.backpackDisplay = station;
        this.backpackDisplayPos = { x: bx, y: by };
    }
    
    showCloset() {
        if (this.popupActive) return;
        if (this.currentPopup) this.currentPopup.destroy();
        this.popupActive = true;
        this.closetTab = this.closetTab || 'character';
        const W = CONFIG.width, H = CONFIG.height;
        let custom = {};
        try { custom = SaveManager.getCustomization(); } catch(e) {}
        const cur = {
            skin: custom.skin || 'light', hair: custom.hair || 'brown',
            hairStyle: custom.hairStyle || 'short', shirt: custom.shirt || 'green',
            pants: custom.pants || 'dark', vehicle: custom.vehicle || 'blue',
            backpack: custom.backpack || 'green'
        };
        const panel = UIManager.createPanel(this, W/2, H/2, W - 20, 420, {
            title: 'CLOSET', accent: 'default', closable: true,
            onClose: () => { this.popupActive = false; }, depth: 200
        });
        this.currentPopup = panel;
        const cb = panel._contentBounds;
        const tabLabels = ['CHARACTER', 'VEHICLE', 'BACKPACK'];
        const tabKeys = ['character', 'vehicle', 'backpack'];
        const tabs = UIManager.createTabs(this, 0, cb.y + 4, tabLabels,
            tabKeys.indexOf(this.closetTab),
            (idx) => { this.closetTab = tabKeys[idx]; panel.destroy(); this.popupActive = false; this.showCloset(); },
            { tabWidth: 80, depth: 201 }
        );
        panel.add(tabs);
        let rowY = cb.y + 28;
        const leftEdge = cb.x;
        const refreshCloset = () => {
            try { SaveManager.saveCustomization(cur); } catch(e) {}
            panel.destroy(); this.popupActive = false; this.showCloset();
        };
        if (this.closetTab === 'character') {
            const prevY = rowY + 25;
            panel.add(this.add.rectangle(0, prevY, 60, 60, 0x0a0a14).setStrokeStyle(0.5, 0x222244));
            try {
                const pc = SpriteManager.generatePlayerSheet(cur);
                const pk = 'cp_' + Date.now();
                this.textures.addSpriteSheet(pk, pc, { frameWidth: 48, frameHeight: 48 });
                panel.add(this.add.sprite(0, prevY + 3, pk, 0).setDisplaySize(48, 48));
            } catch(e) { panel.add(this.add.text(0, prevY, '', { fontSize: uiPx(24) }).setOrigin(0.5)); }
            rowY = prevY + 48;
            const cats = [
                { key: 'skin', label: 'SKIN', opts: CONFIG.customization.skinTones, ck: 'base' },
                { key: 'hair', label: 'HAIR', opts: CONFIG.customization.hairColors, ck: 'base' },
                { key: 'hairStyle', label: 'STYLE', opts: CONFIG.customization.hairStyles, ck: null },
                { key: 'shirt', label: 'SHIRT', opts: CONFIG.customization.shirtColors, ck: 'base' },
                { key: 'pants', label: 'PANTS', opts: CONFIG.customization.pantsColors, ck: 'base' }
            ];
            cats.forEach(cat => {
                panel.add(this.add.text(leftEdge, rowY, cat.label, {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#666688'
                }).setOrigin(0, 0.5));
                if (cat.ck) {
                    const sz = 20, g = 3;
                    const maxPerRow = Math.min(cat.opts.length, 8);
                    const totalRowW = maxPerRow * (sz + g) - g;
                    const sx0 = -totalRowW / 2 + sz / 2;
                    cat.opts.forEach((o, i) => {
                        const col = i % maxPerRow, row = Math.floor(i / maxPerRow);
                        const sx = sx0 + col * (sz + g);
                        const sy = rowY + row * (sz + g + 2);
                        const hex = parseInt(o[cat.ck].replace('#', ''), 16);
                        const sel = cur[cat.key] === o.id;
                        // Atlas slot border
                        if (this.textures.exists('ui_slot_empty')) {
                            panel.add(this.add.image(sx, sy, 'ui_slot_empty').setDisplaySize(sz + 2, sz + 2).setAlpha(0.5));
                        }
                        const sw = this.add.rectangle(sx, sy, sz - 2, sz - 2, hex, 0.95)
                            .setStrokeStyle(sel ? 1 : 0, sel ? 0xffffff : 0x333344);
                        sw.setInteractive({ useHandCursor: true });
                        sw.on('pointerdown', () => { cur[cat.key] = o.id; refreshCloset(); });
                        panel.add(sw);
                        if (sel) {
                            panel.add(this.add.text(sx, sy, 'OK', { fontSize: uiPx(7), fill: '#fff', fontStyle: 'bold' }).setOrigin(0.5));
                        }
                    });
                    const extraRows = Math.floor((cat.opts.length - 1) / maxPerRow);
                    rowY += extraRows * (sz + g + 2);
                } else {
                    const bw = 44, g = 3;
                    const totalW = cat.opts.length * (bw + g) - g;
                    const sx0 = -totalW / 2 + bw / 2;
                    cat.opts.forEach((o, i) => {
                        const sx = sx0 + i * (bw + g);
                        const sel = cur[cat.key] === o.id;
                        const b = UIManager.createButton(this, sx, rowY, o.name, {
                            width: bw, height: 20, style: sel ? 'confirm' : 'normal',
                            fontSize: uiPx(7), depth: 1,
                            onClick: () => { cur[cat.key] = o.id; refreshCloset(); }
                        });
                        panel.add(b);
                    });
                }
                rowY += 30;
            });
        } else if (this.closetTab === 'vehicle') {
            panel.add(this.add.text(0, rowY + 15, 'PAINT JOB', { fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#8888aa' }).setOrigin(0.5));
            rowY += 40;
            const sz = 32, g = 6, cols = 3;
            const colW = sz + g + 55;
            const totalW = cols * colW - g;
            const sx0 = -totalW / 2 + sz / 2;
            CONFIG.customization.vehicleColors.forEach((o, i) => {
                const col = i % cols, row = Math.floor(i / cols);
                const sx = sx0 + col * colW, sy = rowY + row * (sz + g + 14);
                const hex = parseInt(o.body.replace('#', ''), 16);
                const sel = cur.vehicle === o.id;
                if (this.textures.exists('ui_slot_empty')) {
                    panel.add(this.add.image(sx, sy, 'ui_slot_empty').setDisplaySize(sz + 2, sz + 2).setAlpha(0.5));
                }
                const sw = this.add.rectangle(sx, sy, sz - 2, sz - 2, hex, 0.95)
                    .setStrokeStyle(sel ? 1 : 0, sel ? 0xffffff : 0x333344);
                sw.setInteractive({ useHandCursor: true });
                panel.add(sw);
                panel.add(this.add.text(sx + sz/2 + 4, sy, o.name, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: sel ? '#ffffff' : '#555566' }).setOrigin(0, 0.5));
                if (sel) panel.add(this.add.text(sx, sy, 'OK', { fontSize: uiPx(7), fill: '#fff', fontStyle: 'bold' }).setOrigin(0.5));
                sw.on('pointerdown', () => { cur.vehicle = o.id; refreshCloset(); });
            });
        } else if (this.closetTab === 'backpack') {
            panel.add(this.add.text(0, rowY + 15, 'PACK COLOR', { fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#8888aa' }).setOrigin(0.5));
            rowY += 40;
            const sz = 32, g = 6, cols = 3;
            const colW = sz + g + 55;
            const totalW = cols * colW - g;
            const sx0 = -totalW / 2 + sz / 2;
            CONFIG.customization.backpackColors.forEach((o, i) => {
                const col = i % cols, row = Math.floor(i / cols);
                const sx = sx0 + col * colW, sy = rowY + row * (sz + g + 14);
                const hex = parseInt(o.base.replace('#', ''), 16);
                const sel = cur.backpack === o.id;
                if (this.textures.exists('ui_slot_empty')) {
                    panel.add(this.add.image(sx, sy, 'ui_slot_empty').setDisplaySize(sz + 2, sz + 2).setAlpha(0.5));
                }
                const sw = this.add.rectangle(sx, sy, sz - 2, sz - 2, hex, 0.95)
                    .setStrokeStyle(sel ? 1 : 0, sel ? 0xffffff : 0x333344);
                sw.setInteractive({ useHandCursor: true });
                panel.add(sw);
                panel.add(this.add.text(sx + sz/2 + 4, sy, o.name, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: sel ? '#ffffff' : '#555566' }).setOrigin(0, 0.5));
                if (sel) panel.add(this.add.text(sx, sy, 'OK', { fontSize: uiPx(7), fill: '#fff', fontStyle: 'bold' }).setOrigin(0.5));
                sw.on('pointerdown', () => { cur.backpack = o.id; refreshCloset(); });
            });
        }
        const saveBtn = UIManager.createButton(this, 0, 420/2 - 40, 'SAVE & CLOSE', {
            width: 130, height: 32, style: 'confirm', fontSize: uiPx(11), depth: 201,
            onClick: () => {
                try { SaveManager.saveCustomization(cur); } catch(e) {}
                if (cur.shirt && cur.shirt.id) SpriteManager._baseShirtId = cur.shirt.id;
                if (cur.pants && cur.pants.id) SpriteManager._basePantsId = cur.pants.id;
                SpriteManager.rebuildPlayerSheet(this, cur);
                if (this.player) this.player.setFrame(0);
                if (this.vehicleStation && this.vehicleStationPos) {
                    const curVX = this.vehicleStation.x, curVY = this.vehicleStation.y;
                    const oldVIdx = this.stations.indexOf(this.vehicleStation);
                    if (oldVIdx >= 0) this.stations.splice(oldVIdx, 1);
                    DynamicShadows.remove(this, this.vehicleStation);
                    this.vehicleStation.destroy();
                    this.vehicleStationPos = { x: curVX, y: curVY };
                    const vs = SpriteManager.createVehicle(this, curVX, curVY, 'iso');
                    vs.setDepth(10); vs.setScale(1.4); this.vehicleStation = vs;
                    const _scn1 = this;
                    vs.config = { id: 'vehicle', x: curVX, y: curVY, width: 50, height: 30, get label() { return (_scn1.saveData?.activeRoute?.status === 'locked') ? 'DEPART' : 'VEHICLE'; }, action: () => this.showVehicleMenu() };
                    this.stations.push(vs);
                    DynamicShadows.add(this, vs, { offsetY: 18, scale: 1.2 });
                }
                if (this.backpackDisplay && this.backpackDisplayPos) {
                    const curBX = this.backpackDisplay.x, curBY = this.backpackDisplay.y;
                    this.backpackDisplay.destroy();
                    this.backpackDisplayPos = { x: curBX, y: curBY };
                    this.createBackpackDisplay(curBX, curBY);
                }
                panel.destroy(); this.popupActive = false;
            }
        });
        panel.add(saveBtn);
        this.currentPopup = panel;
    }

    
    closeCloset() {
        if (this.currentPopup) {
            this.currentPopup.destroy();
            this.currentPopup = null;
        }
        this.popupActive = false;
    }
    
    
    // === FLOOR STATIONS ===
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createBedFloor(bx, by) {
        // HANDCRAFTED floor bed — front face dominant (¾ view, camera above+south)
        // Bed seen from ¾ above: mattress surface visible, footboard at front, headboard receding
        const station = this.add.container(bx, by);
        const d = 10;
        
        // === FOOTBOARD (front face — player sees this head-on) ===
        station.add(this.add.rectangle(0, 14, 40, 6, 0x4a3a2a).setDepth(d + 0.003));    // footboard body
        station.add(this.add.rectangle(0, 14, 38, 4, 0x5a4a3a).setDepth(d + 0.004));      // footboard face
        station.add(this.add.rectangle(0, 11, 40, 2, 0x5a4a3a).setDepth(d + 0.005));      // footboard top rail
        // Footboard posts
        station.add(this.add.rectangle(-19, 12, 4, 10, 0x4a3a2a).setDepth(d + 0.003));
        station.add(this.add.rectangle(19, 12, 4, 10, 0x4a3a2a).setDepth(d + 0.003));
        // Post caps
        station.add(this.add.rectangle(-19, 7, 5, 3, 0x5a4a3a).setDepth(d + 0.006));
        station.add(this.add.rectangle(19, 7, 5, 3, 0x5a4a3a).setDepth(d + 0.006));
        
        // === MATTRESS (top surface — foreshortened, receding toward headboard) ===
        station.add(this.add.rectangle(0, 0, 36, 20, 0x6a6a7a).setDepth(d + 0.001));     // mattress
        station.add(this.add.rectangle(0, 0, 34, 18, 0x7a7a8a).setDepth(d + 0.002));      // mattress lighter
        // Sheet/blanket
        station.add(this.add.rectangle(0, 4, 32, 12, 0x8a8a9a).setDepth(d + 0.003));     // sheet
        station.add(this.add.rectangle(0, 4, 30, 10, 0x9a9aaa).setDepth(d + 0.004));      // sheet lighter
        station.add(this.add.rectangle(0, 2, 28, 1, 0x7a7a8a).setDepth(d + 0.005));       // fold line
        // Pillows (at head, partially foreshortened)
        station.add(this.add.ellipse(-8, -6, 12, 6, 0x9a9aaa).setDepth(d + 0.004));      // left pillow
        station.add(this.add.ellipse(-8, -7, 10, 3, 0xaaaabb).setDepth(d + 0.005));       // left pillow highlight
        station.add(this.add.ellipse(8, -6, 12, 6, 0x9a9aaa).setDepth(d + 0.004));       // right pillow
        station.add(this.add.ellipse(8, -7, 10, 3, 0xaaaabb).setDepth(d + 0.005));        // right pillow highlight
        
        // === HEADBOARD (foreshortened, against far edge) ===
        station.add(this.add.rectangle(0, -10, 42, 4, 0x4a3a2a).setDepth(d));
        station.add(this.add.rectangle(0, -11, 40, 2, 0x5a4a3a).setDepth(d + 0.001));
        
        // === SIDE RAILS ===
        station.add(this.add.rectangle(-19, 2, 2, 24, 0x3a2a1a).setDepth(d));
        station.add(this.add.rectangle(19, 2, 2, 24, 0x3a2a1a).setDepth(d));
        
        // Legs
        station.add(this.add.rectangle(-17, 18, 3, 4, 0x3a2a1a).setDepth(d - 0.001));
        station.add(this.add.rectangle(17, 18, 3, 4, 0x3a2a1a).setDepth(d - 0.001));
        
        // Shadow
        
        station.setDepth(d);
        station.setScale(1.6);
        station._handcraftedType = 'bed_floor';
        this.addStationInteraction(station, bx, by, 50, 38, 'bed', 'REST',
            () => this.showBed());
    }
    // ═══ END LOCKED: createBedFloor ═══
    
    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createGymEquipment(gx, gy) {
        // HANDCRAFTED floor gym station — front face dominant (¾ view, camera above+south)
        // Barbell rack with plates, flat bench beside it, dumbbells on floor
        const station = this.add.container(gx, gy);
        const d = 5;  // below south wall (depth 6) so wall occludes base
        
        // === RACK UPRIGHTS (front face — two tall posts with hooks) ===
        // Left upright
        station.add(this.add.rectangle(-14, -4, 5, 38, 0x3a3a3a).setDepth(d));           // post body
        station.add(this.add.rectangle(-14, -4, 3, 36, 0x4a4a4a).setDepth(d + 0.001));    // post face
        station.add(this.add.rectangle(-14, -4, 1, 34, 0x555555, 0.3).setDepth(d + 0.002)); // center highlight
        // Right upright
        station.add(this.add.rectangle(14, -4, 5, 38, 0x3a3a3a).setDepth(d));
        station.add(this.add.rectangle(14, -4, 3, 36, 0x4a4a4a).setDepth(d + 0.001));
        station.add(this.add.rectangle(14, -4, 1, 34, 0x555555, 0.3).setDepth(d + 0.002));
        // Top crossbar
        station.add(this.add.rectangle(0, -22, 32, 4, 0x4a4a4a).setDepth(d + 0.003));
        station.add(this.add.rectangle(0, -23, 30, 2, 0x555555).setDepth(d + 0.004));     // crossbar highlight
        // Top face strip
        station.add(this.add.rectangle(0, -24, 32, 2, 0x5a5a5a).setDepth(d + 0.008));
        
        // === J-HOOKS (barbell holders — protruding forward) ===
        // Left hooks
        station.add(this.add.rectangle(-14, -12, 8, 3, 0x5a5a5a).setDepth(d + 0.004));  // hook arm
        station.add(this.add.rectangle(-10, -12, 3, 5, 0x5a5a5a).setDepth(d + 0.005));   // hook cup
        station.add(this.add.rectangle(-10, -14, 2, 1, 0x666666).setDepth(d + 0.005));    // hook tip
        // Right hooks
        station.add(this.add.rectangle(14, -12, 8, 3, 0x5a5a5a).setDepth(d + 0.004));
        station.add(this.add.rectangle(10, -12, 3, 5, 0x5a5a5a).setDepth(d + 0.005));
        station.add(this.add.rectangle(10, -14, 2, 1, 0x666666).setDepth(d + 0.005));
        
        // === BARBELL (resting on hooks) ===
        station.add(this.add.rectangle(0, -12, 36, 3, 0x6a6a6a).setDepth(d + 0.005));   // bar
        station.add(this.add.rectangle(0, -13, 34, 1, 0x7a7a7a).setDepth(d + 0.006));    // bar highlight
        // Knurling marks
        station.add(this.add.rectangle(-4, -12, 8, 2, 0x5a5a5a, 0.4).setDepth(d + 0.006));
        station.add(this.add.rectangle(4, -12, 8, 2, 0x5a5a5a, 0.4).setDepth(d + 0.006));
        // Weight plates (left side — stacked)
        station.add(this.add.rectangle(-17, -12, 4, 14, 0x2a2a2a).setDepth(d + 0.004)); // outer plate
        station.add(this.add.rectangle(-17, -12, 3, 12, 0x3a3a3a).setDepth(d + 0.005)); // plate face
        station.add(this.add.rectangle(-15, -12, 3, 10, 0x2a2a2a).setDepth(d + 0.004)); // inner plate
        // Weight plates (right side)
        station.add(this.add.rectangle(17, -12, 4, 14, 0x2a2a2a).setDepth(d + 0.004));
        station.add(this.add.rectangle(17, -12, 3, 12, 0x3a3a3a).setDepth(d + 0.005));
        station.add(this.add.rectangle(15, -12, 3, 10, 0x2a2a2a).setDepth(d + 0.004));
        // Plate collars
        station.add(this.add.rectangle(-13, -12, 2, 4, 0x555555).setDepth(d + 0.006));
        station.add(this.add.rectangle(13, -12, 2, 4, 0x555555).setDepth(d + 0.006));
        
        // === BASE FEET (stabilizer pads) ===
        station.add(this.add.rectangle(-14, 16, 12, 3, 0x3a3a3a).setDepth(d));
        station.add(this.add.rectangle(14, 16, 12, 3, 0x3a3a3a).setDepth(d));
        
        // === WEIGHT PLATE STORAGE (lower hooks on uprights) ===
        station.add(this.add.rectangle(-14, 4, 6, 2, 0x4a4a4a).setDepth(d + 0.003));    // storage peg
        station.add(this.add.rectangle(-11, 4, 3, 8, 0x2a2a2a).setDepth(d + 0.003));     // stored plate
        station.add(this.add.rectangle(14, 4, 6, 2, 0x4a4a4a).setDepth(d + 0.003));
        station.add(this.add.rectangle(11, 4, 3, 8, 0x2a2a2a).setDepth(d + 0.003));
        
        // === DUMBBELLS on floor (small, in front of rack) ===
        // Left dumbbell
        station.add(this.add.rectangle(-8, 20, 8, 2, 0x5a5a5a).setDepth(d + 0.001));    // bar
        station.add(this.add.rectangle(-11, 20, 3, 4, 0x2a2a2a).setDepth(d + 0.001));    // left weight
        station.add(this.add.rectangle(-5, 20, 3, 4, 0x2a2a2a).setDepth(d + 0.001));     // right weight
        // Right dumbbell (angled)
        station.add(this.add.rectangle(8, 22, 8, 2, 0x5a5a5a).setDepth(d + 0.001).setAngle(20));
        station.add(this.add.rectangle(5, 21, 3, 4, 0x2a2a2a).setDepth(d + 0.001));
        station.add(this.add.rectangle(11, 23, 3, 4, 0x2a2a2a).setDepth(d + 0.001));
        
        // Rack shadow (under the rack base, not under dumbbells)
        
        station.setDepth(5);
        station.setScale(1.5);
        station._handcraftedType = 'gym';
        this.addStationInteraction(station, gx + 28, gy - 30, 60, 50, 'gym', 'GYM',
            () => this.showTraining());
    }
    // ═══ END LOCKED: createGymEquipment ═══
    
    addStationInteraction(station, x, y, w, h, id, labelText, action) {
        station.config = { id, x, y, width: w, height: h, action, label: labelText };
        station._roomId = this._stationRoom || 'hub';
        
        this.stations.push(station);
        const colIdx = this.stationColliders.length;
        this.stationColliders.push({ x: x - w/2, y: y - h/2, width: w, height: h, roomId: station._roomId });
        station._colliderIdx = colIdx;
    }

    // ═══ LOCKED — HANDCRAFTED PROP — DO NOT REPLACE WITH buildStationVisual() OR IsoRenderer ═══
    createAnomalyConverter(ax, ay) {
        // ═══ LOCKED — ANOMALY CONVERTER (console-style, mechanical base, holo cube) ═══
        // Freestanding unit at room center. Mimics hub terminal aesthetic.
        // Idle: dark, mechanical base still, no hologram.
        // Active (proximity): screen flickers on, base spins up, holo cube rotates.
        const station = this.add.container(ax, ay);
        const d = 10;
        
        // === MECHANICAL BASE — rotating platform ===
        // Floor shadow
        station.add(this.add.ellipse(0, 22, 48, 14, 0x08080c, 0.3).setDepth(d - 0.01));
        // Base ring (static housing)
        station.add(this.add.ellipse(0, 18, 44, 12, 0x1a1a24).setDepth(d));
        station.add(this.add.ellipse(0, 18, 40, 10, 0x222232).setDepth(d + 0.001));
        // Track groove
        station.add(this.add.ellipse(0, 18, 36, 8, 0x0e0e18, 0.5).setDepth(d + 0.002).setStrokeStyle(0.5, 0x333345, 0.4));
        // Rotating armature (container for spin animation)
        const armature = this.add.container(0, 18);
        // Cross-arms
        armature.add(this.add.rectangle(0, 0, 30, 2, 0x3a3a4a).setDepth(d + 0.003));
        armature.add(this.add.rectangle(0, 0, 2, 8, 0x3a3a4a).setDepth(d + 0.003));
        // Arm-end nodes
        armature.add(this.add.circle(-14, 0, 2, 0x4a4a5a).setDepth(d + 0.004));
        armature.add(this.add.circle(14, 0, 2, 0x4a4a5a).setDepth(d + 0.004));
        armature.add(this.add.circle(0, -3, 1.5, 0x4a4a5a).setDepth(d + 0.004));
        armature.add(this.add.circle(0, 3, 1.5, 0x4a4a5a).setDepth(d + 0.004));
        // Center hub
        armature.add(this.add.circle(0, 0, 4, 0x2a2a3a).setDepth(d + 0.005));
        armature.add(this.add.circle(0, 0, 2.5, 0x3a3a50).setDepth(d + 0.006));
        station.add(armature);
        station._armature = armature;
        
        // === CONSOLE BODY — hub terminal style ===
        // Main housing front face
        station.add(this.add.rectangle(0, 4, 50, 24, 0x1e1e2a).setDepth(d + 0.01));
        station.add(this.add.rectangle(0, 4, 48, 22, 0x24243a).setDepth(d + 0.011));
        // Side depth edges
        station.add(this.add.rectangle(-25, 4, 2, 24, 0x141420).setDepth(d + 0.009));
        station.add(this.add.rectangle(25, 4, 2, 24, 0x141420).setDepth(d + 0.009));
        // Section divider seam
        station.add(this.add.rectangle(0, -3, 48, 0.5, 0x1a1a28).setDepth(d + 0.012));
        station.add(this.add.rectangle(0, 10, 48, 0.5, 0x1a1a28).setDepth(d + 0.012));
        
        // === VENT GRILLE (lower section) ===
        for (let vi = -18; vi <= 18; vi += 3) {
            station.add(this.add.rectangle(vi, 12, 0.8, 5, 0x121220, 0.6).setDepth(d + 0.013));
        }
        
        // === CONTROL PANEL (mid section — switches, dials) ===
        // Left switches
        for (let sw = 0; sw < 3; sw++) {
            const sx = -18 + sw * 6;
            station.add(this.add.rectangle(sx, 4, 2.5, 4, 0x2a2a3e).setDepth(d + 0.014));
            station.add(this.add.rectangle(sx, 3, 2, 2, 0x44445a).setDepth(d + 0.015));
        }
        // Right dials
        for (let di = 0; di < 2; di++) {
            const dx = 12 + di * 10;
            station.add(this.add.circle(dx, 4, 3.5, 0x222238).setDepth(d + 0.014));
            station.add(this.add.circle(dx, 4, 2.5, 0x2e2e44).setDepth(d + 0.015));
            station.add(this.add.rectangle(dx, 3, 0.8, 2.5, 0x44445a).setDepth(d + 0.016));
        }
        // Center button cluster
        for (let bi = 0; bi < 2; bi++) {
            station.add(this.add.rectangle(-2 + bi * 5, 4, 3, 2.5, 0x2e2e44).setDepth(d + 0.014));
        }
        // Corner rivets
        station.add(this.add.circle(-22, -4, 0.8, 0x444450).setDepth(d + 0.014));
        station.add(this.add.circle(22, -4, 0.8, 0x444450).setDepth(d + 0.014));
        station.add(this.add.circle(-22, 12, 0.8, 0x444450).setDepth(d + 0.014));
        station.add(this.add.circle(22, 12, 0.8, 0x444450).setDepth(d + 0.014));
        
        // === VIEWPORT SCREEN (upper section — dark when idle) ===
        const scrW = 30, scrH = 10;
        station.add(this.add.rectangle(0, -4, scrW + 2, scrH + 2, 0x0a0a14).setDepth(d + 0.016));
        const screen = this.add.rectangle(0, -4, scrW, scrH, 0x060a12, 0.8);
        screen.setDepth(d + 0.017);
        station.add(screen);
        // Viewport frame bolts
        station.add(this.add.circle(-scrW/2, -scrH/2 - 4 + scrH/2, 0.6, 0x555565).setDepth(d + 0.018));
        station.add(this.add.circle(scrW/2, -scrH/2 - 4 + scrH/2, 0.6, 0x555565).setDepth(d + 0.018));
        station.add(this.add.circle(-scrW/2, scrH/2 - 4 - scrH/2 + scrH, 0.6, 0x555565).setDepth(d + 0.018));
        station.add(this.add.circle(scrW/2, scrH/2 - 4 - scrH/2 + scrH, 0.6, 0x555565).setDepth(d + 0.018));
        // Screen scanlines (visible when active)
        const scanlines = [];
        for (let sl = 0; sl < 4; sl++) {
            const sline = this.add.rectangle(0, -7 + sl * 2.5, scrW - 2, 0.5, 0x33aa44, 0);
            sline.setDepth(d + 0.019);
            station.add(sline);
            scanlines.push(sline);
        }
        // Status text (visible when active)
        const statusText = this.add.text(0, -4, 'CVT:ONLINE', {
            fontFamily: 'monospace', fontSize: '3.5px', color: '#33aa44'
        }).setOrigin(0.5).setAlpha(0).setDepth(d + 0.02);
        station.add(statusText);
        
        // === LED BANK (right side of console) ===
        const ledGreen = this.add.circle(20, -5, 1, 0x44aa44, 0.2);
        station.add(ledGreen.setDepth(d + 0.018));
        const ledBlue = this.add.circle(20, -3, 1, 0x4488ff, 0.15);
        station.add(ledBlue.setDepth(d + 0.018));
        const ledRed = this.add.circle(20, -1, 1, 0xaa4444, 0.3);
        station.add(ledRed.setDepth(d + 0.018));
        
        // === INPUT SLOT (left side — where cubes go in) ===
        station.add(this.add.rectangle(-20, -4, 5, 7, 0x0e0e1a).setDepth(d + 0.016));
        station.add(this.add.rectangle(-20, -4, 3.5, 5, 0x181828).setDepth(d + 0.017));
        station.add(this.add.rectangle(-20, -7, 3.5, 0.5, 0x444455).setDepth(d + 0.018));
        station.add(this.add.rectangle(-20, -1, 3.5, 0.5, 0x444455).setDepth(d + 0.018));
        
        // === TOP FACE (foreshortened strip) ===
        station.add(this.add.rectangle(0, -9, 50, 3, 0x2e2e42).setDepth(d + 0.02));
        station.add(this.add.rectangle(0, -10, 48, 1.5, 0x36364e).setDepth(d + 0.021));
        station.add(this.add.rectangle(0, -10.5, 50, 0.5, 0x44445a, 0.5).setDepth(d + 0.021));
        // Heat vents on top
        station.add(this.add.rectangle(-10, -9.5, 5, 1, 0x1a1a28).setDepth(d + 0.022));
        station.add(this.add.rectangle(0, -9.5, 5, 1, 0x1a1a28).setDepth(d + 0.022));
        station.add(this.add.rectangle(10, -9.5, 5, 1, 0x1a1a28).setDepth(d + 0.022));
        
        // === WARNING STRIPES (below control panel) ===
        for (let si = -18; si <= 18; si += 7) {
            station.add(this.add.rectangle(si, 8, 3, 1.5, 0x8a8a22, 0.4).setDepth(d + 0.013));
        }
        // Serial plate
        station.add(this.add.rectangle(0, 14, 16, 3, 0x2a2a38).setDepth(d + 0.013));
        station.add(this.add.rectangle(0, 14, 14, 1.5, 0x222230).setDepth(d + 0.014));
        
        // === CABLE PORT HOLES (sides of base) ===
        station.add(this.add.circle(-22, 12, 3, 0x0e0e18).setDepth(d + 0.008));
        station.add(this.add.circle(-22, 12, 2, 0x1a1a2a).setDepth(d + 0.009));
        station.add(this.add.circle(22, 12, 3, 0x0e0e18).setDepth(d + 0.008));
        station.add(this.add.circle(22, 12, 2, 0x1a1a2a).setDepth(d + 0.009));
        station.add(this.add.circle(0, 16, 3, 0x0e0e18).setDepth(d + 0.008));
        station.add(this.add.circle(0, 16, 2, 0x1a1a2a).setDepth(d + 0.009));
        
        // === HOLOGRAPHIC EMITTER (on top, activates on approach) ===
        // Emitter ring base
        const emitRing = this.add.ellipse(0, -11, 16, 5, 0x4444aa, 0);
        emitRing.setStrokeStyle(0.5, 0x6666cc, 0);
        station.add(emitRing.setDepth(d + 0.025));
        // Holographic cube (container for rotation)
        const holoCube = this.add.container(0, -26);
        // Cube front face
        holoCube.add(this.add.rectangle(0, 0, 12, 12, 0x4444cc, 0).setDepth(d + 0.03));
        // Cube top face (foreshortened)
        holoCube.add(this.add.rectangle(0, -7, 12, 3, 0x5555dd, 0).setDepth(d + 0.031));
        // Cube right face (depth sliver)
        holoCube.add(this.add.rectangle(7, 0, 3, 12, 0x3333aa, 0).setDepth(d + 0.029));
        // Edge highlights
        holoCube.add(this.add.rectangle(0, -6, 12, 0.5, 0x8888ff, 0).setDepth(d + 0.032));
        holoCube.add(this.add.rectangle(0, 6, 12, 0.5, 0x6666cc, 0).setDepth(d + 0.032));
        holoCube.add(this.add.rectangle(-6, 0, 0.5, 12, 0x7777dd, 0).setDepth(d + 0.032));
        holoCube.add(this.add.rectangle(6, 0, 0.5, 12, 0x5555bb, 0).setDepth(d + 0.032));
        // Core glow
        holoCube.add(this.add.rectangle(0, 0, 6, 6, 0x8888ff, 0).setDepth(d + 0.033));
        station.add(holoCube);
        station._holoCube = holoCube;
        station._emitRing = emitRing;
        
        // Floating data particles (inactive until approach)
        const particles = [];
        for (let pi = 0; pi < 6; pi++) {
            const py = -16 - pi * 4;
            const px = (Math.random() - 0.5) * 8;
            const p = this.add.rectangle(px, py, 1.5, 1.5, 0x8888ff, 0);
            p.setDepth(d + 0.028);
            station.add(p);
            particles.push(p);
        }
        
        // === IDLE ANIMATIONS (minimal — just LED pulse) ===
        this.tweens.add({ targets: ledRed, alpha: { from: 0.2, to: 0.5 }, duration: 1200, yoyo: true, repeat: -1, ease: 'Sine.inOut' });
        
        // Store refs for approach/leave animations
        station._screen = screen;
        station._scanlines = scanlines;
        station._statusText = statusText;
        station._ledGreen = ledGreen;
        station._ledBlue = ledBlue;
        station._particles = particles;
        station._spinTween = null;
        station._holoTweens = [];
        
        // === PROXIMITY: FLICK TO LIFE ===
        station._onApproach = (scene) => {
            // Screen flickers on
            scene.tweens.add({ targets: station._screen, fillColor: 0x0a1a0a, fillAlpha: 1, duration: 150 });
            station._scanlines.forEach((sl, i) => {
                scene.tweens.add({ targets: sl, alpha: 0.15, duration: 100, delay: i * 40 });
            });
            scene.tweens.add({ targets: station._statusText, alpha: 0.8, duration: 200, delay: 150 });
            
            // LEDs activate
            scene.tweens.add({ targets: station._ledGreen, alpha: 0.9, duration: 200 });
            scene.tweens.add({ targets: station._ledBlue, alpha: 0.7, duration: 300 });
            
            // Mechanical base spins up
            if (station._spinTween) station._spinTween.stop();
            station._armature.angle = 0;
            station._spinTween = scene.tweens.add({
                targets: station._armature,
                angle: { from: 0, to: 360 },
                duration: 2000,
                repeat: -1,
                ease: 'Linear'
            });
            
            // Emitter ring glows
            scene.tweens.add({ targets: station._emitRing, alpha: 0.3, duration: 400 });
            station._emitRing.setStrokeStyle(0.5, 0x6666cc, 0.5);
            
            // Holographic cube fades in + rotates
            station._holoCube.list.forEach(child => {
                scene.tweens.add({ targets: child, alpha: { from: 0, to: child.type === 'Rectangle' && child.width === 6 ? 0.35 : child.height === 0.5 || child.width === 0.5 ? 0.5 : 0.3 }, duration: 600, delay: 300 });
            });
            // Cube bob + pulse
            const cubeBob = scene.tweens.add({
                targets: station._holoCube,
                y: -28,
                duration: 1500,
                yoyo: true, repeat: -1, ease: 'Sine.inOut'
            });
            const cubeRotate = scene.tweens.add({
                targets: station._holoCube,
                scaleX: { from: 1, to: -1 },
                duration: 3000,
                yoyo: true, repeat: -1, ease: 'Sine.inOut'
            });
            station._holoTweens = [cubeBob, cubeRotate];
            
            // Particles activate
            station._particles.forEach((p, i) => {
                const startY = p.y;
                const tw = scene.tweens.add({
                    targets: p, y: startY - 10, alpha: { from: 0.4, to: 0 },
                    duration: 1800 + i * 250, repeat: -1, delay: i * 300,
                    onRepeat: () => { p.y = startY; p.x = (Math.random() - 0.5) * 6; p.setAlpha(0.4); }
                });
                station._holoTweens.push(tw);
            });
        };
        
        // === PROXIMITY: POWER DOWN ===
        station._onLeave = (scene) => {
            // Screen off
            scene.tweens.add({ targets: station._screen, fillAlpha: 0.8, duration: 200 });
            station._scanlines.forEach(sl => scene.tweens.add({ targets: sl, alpha: 0, duration: 100 }));
            scene.tweens.add({ targets: station._statusText, alpha: 0, duration: 100 });
            
            // LEDs dim
            scene.tweens.add({ targets: station._ledGreen, alpha: 0.2, duration: 300 });
            scene.tweens.add({ targets: station._ledBlue, alpha: 0.15, duration: 300 });
            
            // Base spin-down (smooth deceleration)
            if (station._spinTween) { station._spinTween.stop(); station._spinTween = null; }
            scene.tweens.add({ targets: station._armature, angle: 0, duration: 800, ease: 'Power2' });
            
            // Hologram fade out
            station._holoTweens.forEach(tw => tw.stop());
            station._holoTweens = [];
            station._holoCube.list.forEach(child => {
                scene.tweens.add({ targets: child, alpha: 0, duration: 300 });
            });
            scene.tweens.add({ targets: station._emitRing, alpha: 0, duration: 300 });
            station._emitRing.setStrokeStyle(0.5, 0x6666cc, 0);
            
            // Particles off
            station._particles.forEach(p => p.setAlpha(0));
        };
        
        station.setDepth(10);
        station.setScale(1.3);
        station._handcraftedType = 'anomaly';
        this.addStationInteraction(station, ax, ay - 10, 55, 40, 'anomaly', 'ANOMALY CONVERTER',
            () => this.showAnomalyMenu());
    }
    // ═══ END LOCKED: createAnomalyConverter ═══
    
    showAnomalyMenu() {
        this._closeAnomalyUI();
        this._anomalyCards = [];
        this._anomalyDecrypting = false;
        const acAdd = (o) => { this._anomalyCards.push(o); o.setScrollFactor(0); this.cameras.main.ignore(o); return o; };
        
        // Decrypt tier tables — highest tier in each range is the "rare" decryption
        const DECRYPT = {
            cube_uncommon:  { tiers: [[2, 75], [3, 25]], color: 0x44aa44, label: 'Uncommon' },
            cube_rare:      { tiers: [[2, 30], [3, 55], [4, 15]], color: 0x4488ff, label: 'Rare' },
            cube_master:    { tiers: [[3, 35], [4, 50], [5, 15]], color: 0xffaa22, label: 'Master' },
            cube_legendary: { tiers: [[4, 60], [5, 40]], color: 0xff2244, label: 'Legendary' }
        };
        const CONSUMABLE_BY_TIER = {
            2: ['bandage_military', 'energy_drink'],
            3: ['medkit'],
            4: ['medkit_advanced', 'grenade_frag'],
            5: ['grenade_poison', 'grenade_inferno', 'pylon_heal', 'pylon_damage']
        };
        const CATEGORY_WEIGHTS = [
            { cat: 'weapon', weight: 28 },
            { cat: 'melee', weight: 18 },
            { cat: 'gear', weight: 20 },
            { cat: 'augment', weight: 8 },
            { cat: 'consumable', weight: 26 }
        ];
        
        function rollDecryptTier(cubeId) {
            const def = DECRYPT[cubeId];
            if (!def) return 2;
            const totalW = def.tiers.reduce((s, t) => s + t[1], 0);
            let roll = Math.random() * totalW, tier = def.tiers[0][0];
            for (const [t, w] of def.tiers) { roll -= w; if (roll <= 0) { tier = t; break; } }
            return tier;
        }
        
        function rollDecryptItem(cubeId) {
            const tier = rollDecryptTier(cubeId);
            const totalCW = CATEGORY_WEIGHTS.reduce((s, c) => s + c.weight, 0);
            let cRoll = Math.random() * totalCW, cat = 'weapon';
            for (const c of CATEGORY_WEIGHTS) { cRoll -= c.weight; if (cRoll <= 0) { cat = c.cat; break; } }
            if (cat === 'consumable') {
                const pool = CONSUMABLE_BY_TIER[tier];
                if (pool && pool.length > 0) {
                    return ItemManager.createItem(pool[Math.floor(Math.random() * pool.length)]);
                }
                cat = 'weapon';
            }
            return ItemManager.generateItem(cat, tier, 0, tier);
        }
        
        // Camera blur
        try {
            if (this.cameras.main.postFX) {
                this._anomalyBlur = this.cameras.main.postFX.addBlur(0, 2, 2, 1);
            }
        } catch(e) {}
        
        // Overlay camera
        const W = CONFIG.width, H = CONFIG.height;
        this._anomalyCam = this.cameras.add(0, 0, W, H).setName('anomalyOverlay');
        this._anomalyCam.setScroll(this.cameras.main.scrollX, this.cameras.main.scrollY);
        
        const GD = 250;
        const self = this;
        
        // Dim overlay
        const overlay = acAdd(this.add.rectangle(W/2, H/2, W, H, 0x000000, 0.5).setDepth(GD));
        overlay.setInteractive();
        overlay.on('pointerdown', () => {
            if (!self._anomalyDecrypting) self._closeAnomalyUI();
        });
        
        // Find cubes in stash
        const stash = this.saveData.stash.inventory || [];
        const cubes = [];
        stash.forEach((it, idx) => {
            if (it && it.category === 'cube' && DECRYPT[it.id]) {
                cubes.push({ item: it, slotIdx: idx });
            }
        });
        
        // Layout centered
        const cardSz = 60, cardGap = 10;
        const cols = Math.min(cubes.length, 4) || 1;
        const totalW = cols * cardSz + (cols - 1) * cardGap;
        const startX = W/2 - totalW/2 + cardSz/2;
        const baseY = H/2;
        
        // Subtitle
        const cubeCountStr = cubes.length > 0 ? `${cubes.length} CUBE${cubes.length > 1 ? 'S' : ''} AVAILABLE` : 'NO CUBES';
        acAdd(this.add.text(W/2, baseY - cardSz/2 - 22, cubeCountStr, {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: cubes.length > 0 ? '#8899bb' : '#554444', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(GD+1));
        
        // Hint
        if (cubes.length > 0) {
            acAdd(this.add.text(W/2, baseY - cardSz/2 - 10, 'TAP CUBE TO DECRYPT', {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#556677'
            }).setOrigin(0.5).setDepth(GD+1));
        }
        
        if (cubes.length === 0) return;
        
        // Cube cards
        cubes.forEach((entry, i) => {
            const col = i % cols, row = Math.floor(i / cols);
            const cx = startX + col * (cardSz + cardGap);
            const cy = baseY + row * (cardSz + cardGap + 8);
            const dec = DECRYPT[entry.item.id];
            const color = dec ? dec.color : 0x888888;
            const hex = '#' + color.toString(16).padStart(6, '0');
            
            // Card bg
            const bg = acAdd(this.add.rectangle(cx, cy, cardSz, cardSz, 0x0e0e1a, 0.95)
                .setStrokeStyle(1.5, color, 0.7).setDepth(GD+2));
            acAdd(this.add.rectangle(cx, cy, cardSz - 6, cardSz - 6, color, 0.06).setDepth(GD+2));
            
            // Cube icon
            const iconC = acAdd(this.add.container(cx, cy - 6).setDepth(GD+3));
            ItemManager.drawItemPixelArt(this, iconC, 0, 0, entry.item, 2.0, 0);
            
            // Label
            acAdd(this.add.text(cx, cy + 21, dec ? dec.label : 'Cube', {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: hex, fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(GD+3));
            
            bg.setInteractive();
            bg.on('pointerdown', () => {
                if (self._anomalyDecrypting) return;
                self._anomalyDecrypting = true;
                
                const resultItem = rollDecryptItem(entry.item.id);
                
                // Remove cube from stash
                stash[entry.slotIdx] = null;
                if (!self.saveData.stats) self.saveData.stats = {};
                self.saveData.stats.cubesDecrypted = (self.saveData.stats.cubesDecrypted || 0) + 1;
                
                // Clear current cards (keep overlay)
                self._anomalyCards.forEach(el => {
                    if (el && el !== overlay && el.destroy) el.destroy();
                });
                self._anomalyCards = [overlay];
                
                // === DECRYPTION ANIMATION (centered panel) ===
                const panelSz = 90;
                const px = W/2, py = H/2;
                
                const panel = acAdd(self.add.rectangle(px, py, panelSz, panelSz, 0x0a0a14, 0.95)
                    .setStrokeStyle(2, color, 0.8).setDepth(GD+5));
                
                const scanLine = acAdd(self.add.rectangle(px, py - panelSz/2, panelSz - 4, 2, color, 0.6)
                    .setDepth(GD+8));
                
                const glitchChars = '░▒▓█▀▄▌▐■□◆◇○●';
                const statusText = acAdd(self.add.text(px, py - panelSz/2 - 12, 'DECRYPTING...', {
                    fontFamily: CONFIG.font, fontSize: uiPx(9), fill: hex, fontStyle: 'bold'
                }).setOrigin(0.5).setDepth(GD+6));
                
                const noiseBlocks = [];
                for (let nx = 0; nx < 5; nx++) {
                    for (let ny = 0; ny < 5; ny++) {
                        const bx = px - panelSz/2 + 8 + nx * 16 + Math.random() * 4;
                        const by = py - panelSz/2 + 8 + ny * 16 + Math.random() * 4;
                        const nb = acAdd(self.add.rectangle(bx, by, 10 + Math.random()*4, 10 + Math.random()*4,
                            color, 0.1 + Math.random() * 0.15).setDepth(GD+6));
                        noiseBlocks.push(nb);
                    }
                }
                
                self.tweens.add({
                    targets: scanLine, y: py + panelSz/2,
                    duration: 800, ease: 'Linear', repeat: 1, yoyo: true
                });
                
                let noiseTimer = self.time.addEvent({
                    delay: 60, repeat: 25, callback: () => {
                        noiseBlocks.forEach(nb => {
                            nb.setAlpha(Math.random() * 0.3);
                            nb.setPosition(nb.x + (Math.random() - 0.5) * 3, nb.y + (Math.random() - 0.5) * 3);
                        });
                        let scrambled = '';
                        for (let ci = 0; ci < 12; ci++) scrambled += glitchChars[Math.floor(Math.random() * glitchChars.length)];
                        statusText.setText(scrambled);
                    }
                });
                
                self.time.delayedCall(1600, () => {
                    if (noiseTimer) noiseTimer.destroy();
                    noiseBlocks.forEach(nb => self.tweens.add({ targets: nb, alpha: 0, duration: 200 }));
                    scanLine.setAlpha(0);
                    statusText.setText('DECRYPTED');
                    self.tweens.add({ targets: statusText, alpha: { from: 1, to: 0.6 }, duration: 300 });
                    self.tweens.add({ targets: panel, alpha: { from: 1, to: 0.6 }, duration: 100, yoyo: true, repeat: 2 });
                    
                    self.time.delayedCall(400, () => {
                        const resultIcon = acAdd(self.add.container(px, py - 6).setDepth(GD+10));
                        if (resultItem.procedural && ItemManager.renderWeaponCanvas && (resultItem.category === 'weapon' || resultItem.category === 'melee')) {
                            const wc = ItemManager.renderWeaponCanvas(resultItem);
                            if (wc) {
                                const crop = InventoryUI._cropWeaponIcon ? InventoryUI._cropWeaponIcon(wc, resultItem, 34, 1.8) : wc;
                                const tk = '_anomResult_' + Date.now();
                                self.textures.addCanvas(tk, crop);
                                resultIcon.add(self.add.image(0, 0, tk).setDepth(GD+10));
                            }
                        } else {
                            ItemManager.drawItemPixelArt(self, resultIcon, 0, 0, resultItem, 2.2, 0);
                        }
                        resultIcon.setScale(0);
                        self.tweens.add({ targets: resultIcon, scaleX: 1, scaleY: 1, duration: 300, ease: 'Back.easeOut' });
                        
                        const itemColor = ItemManager.getItemColor ? ItemManager.getItemColor(resultItem) : 0xffffff;
                        const itemHex = '#' + itemColor.toString(16).padStart(6, '0');
                        const tierDef = resultItem.tier ? CONFIG.tiers[resultItem.tier] : null;
                        const isResultWMG = resultItem.category === 'weapon' || resultItem.category === 'melee' || resultItem.category === 'gear';
                        const tierLabel = tierDef ? (isResultWMG ? tierDef.name : tierDef.label) : (resultItem.rarity || '');
                        
                        const nameText = acAdd(self.add.text(px, py + 20, resultItem.name, {
                            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: itemHex, fontStyle: 'bold',
                            wordWrap: { width: panelSz - 10 }, align: 'center'
                        }).setOrigin(0.5).setDepth(GD+10).setAlpha(0));
                        self.tweens.add({ targets: nameText, alpha: 1, duration: 300 });
                        
                        acAdd(self.add.text(px, py + 33, tierLabel, {
                            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: itemHex
                        }).setOrigin(0.5).setDepth(GD+10).setAlpha(0));
                        self.tweens.add({ targets: self._anomalyCards[self._anomalyCards.length-1], alpha: 0.7, duration: 300, delay: 100 });
                        
                        const hint = acAdd(self.add.text(px, py + panelSz/2 + 12, 'tap to collect', {
                            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#555566'
                        }).setOrigin(0.5).setDepth(GD+10).setAlpha(0));
                        self.tweens.add({ targets: hint, alpha: 0.6, duration: 400, delay: 300 });
                        
                        // Collect on tap
                        const collectFn = () => {
                            const added = ItemManager.addItem(self.saveData.stash.inventory, resultItem);
                            if (!added && self.showNotification) self.showNotification('Stash full!', 'danger');
                            self._anomalyDecrypting = false;
                            self._closeAnomalyUI();
                            if (SaveManager && SaveManager.save) SaveManager.save(self.saveData);
                        };
                        overlay.off('pointerdown');
                        overlay.on('pointerdown', collectFn);
                        panel.setInteractive();
                        panel.off('pointerdown');
                        panel.on('pointerdown', collectFn);
                    });
                });
            });
        });
    }
    
    _closeAnomalyUI() {
        if (this._anomalyCards) { this._anomalyCards.forEach(e => { if (e && e.destroy) e.destroy(); }); }
        this._anomalyCards = [];
        this._anomalyDecrypting = false;
        if (this._anomalyBlur) {
            try { this.cameras.main.postFX.remove(this._anomalyBlur); } catch(e) {}
            this._anomalyBlur = null;
        }
        if (this._anomalyCam) {
            try { this.cameras.remove(this._anomalyCam); } catch(e) {}
            this._anomalyCam = null;
        }
    }

    // Garage workbench — invisible interaction zone over the right bench prop
    createGarageWorkbench(wx, wy) {
        const station = this.add.container(wx, wy);
        station.setDepth(10);
        station.setAlpha(0); // invisible — visual is in _createGarageProps
        station._handcraftedType = 'workbench_garage';
        
        // Lid folds open against wall + panel rises from cavity
        station._onApproach = (scene) => {
            const lid = scene._garageToolLid;
            const panel = scene._garageToolPanel;
            if (!lid || !panel) return;
            // Kill any conflicting tweens first
            scene.tweens.killTweensOf(lid);
            scene.tweens.killTweensOf(panel);
            // Lid folds back: scaleY→0.1 (top edge pinned at hinge, bottom rises)
            scene.tweens.add({ targets: lid, scaleY: 0.1, duration: 600, ease: 'Power2' });
            // Panel rises from cavity after lid starts opening
            scene.tweens.add({ targets: panel, y: panel._shownY, duration: 700, delay: 650, ease: 'Power2' });
        };
        station._onLeave = (scene) => {
            const lid = scene._garageToolLid;
            const panel = scene._garageToolPanel;
            if (!lid || !panel) return;
            scene.tweens.killTweensOf(lid);
            scene.tweens.killTweensOf(panel);
            // Panel sinks back into cavity
            scene.tweens.add({ targets: panel, y: panel._hiddenY, duration: 500, ease: 'Power2' });
            // Lid closes after panel starts descending
            scene.tweens.add({ targets: lid, scaleY: 1, duration: 500, delay: 200, ease: 'Power2' });
        };
        
        this.addStationInteraction(station, wx, wy, 80, 20, 'workbench', 'WORKBENCH',
            () => this.showWorkbench());
    }
    
    // Garage vehicle bench — proximity zone for rising vehicle panel
    createGarageVehicleBench(vx, vy) {
        const station = this.add.container(vx, vy);
        station.setDepth(10);
        station.setAlpha(0);
        station._handcraftedType = 'vehicle_bench';
        
        station._onApproach = (scene) => {
            const lid = scene._garageVehLid;
            const panel = scene._garageVehPanel;
            if (!lid || !panel) return;
            scene.tweens.killTweensOf(lid);
            scene.tweens.killTweensOf(panel);
            scene.tweens.add({ targets: lid, scaleY: 0.1, duration: 600, ease: 'Power2' });
            scene.tweens.add({ targets: panel, y: panel._shownY, duration: 700, delay: 650, ease: 'Power2' });
        };
        station._onLeave = (scene) => {
            const lid = scene._garageVehLid;
            const panel = scene._garageVehPanel;
            if (!lid || !panel) return;
            scene.tweens.killTweensOf(lid);
            scene.tweens.killTweensOf(panel);
            scene.tweens.add({ targets: panel, y: panel._hiddenY, duration: 500, ease: 'Power2' });
            scene.tweens.add({ targets: lid, scaleY: 1, duration: 500, delay: 200, ease: 'Power2' });
        };
        
        // No direct action — vehicle bench is visual only (vehicle station handles vehicle interaction)
        this.addStationInteraction(station, vx, vy, 80, 20, 'vbench', 'VEHICLE PARTS',
            () => {});
    }
    
    // Neural interface chair — converter/console themed rotating chair
    // Center of armory. Rotates on approach like the converter armature.
    createNeuralChair(cx, cy) {
        const station = this.add.container(cx, cy);
        const d = 10;
        
        // === FLOOR SHADOW ===
        station.add(this.add.ellipse(0, 14, 36, 10, 0x08080c, 0.3).setDepth(d - 0.01));
        
        // === BASE — rotating platform (converter style) ===
        // Static housing ring
        station.add(this.add.ellipse(0, 10, 32, 10, 0x1a1a24).setDepth(d));
        station.add(this.add.ellipse(0, 10, 28, 8, 0x222232).setDepth(d + 0.001));
        // Track groove
        station.add(this.add.ellipse(0, 10, 24, 6, 0x0e0e18, 0.5).setDepth(d + 0.002).setStrokeStyle(0.5, 0x333345, 0.4));
        
        // Rotating armature (spins on approach)
        const armature = this.add.container(0, 10);
        armature.add(this.add.rectangle(0, 0, 20, 1.5, 0x3a3a4a).setDepth(d + 0.003));
        armature.add(this.add.rectangle(0, 0, 1.5, 6, 0x3a3a4a).setDepth(d + 0.003));
        armature.add(this.add.circle(-9, 0, 1.5, 0x4a4a5a).setDepth(d + 0.004));
        armature.add(this.add.circle(9, 0, 1.5, 0x4a4a5a).setDepth(d + 0.004));
        armature.add(this.add.circle(0, 0, 3, 0x2a2a3a).setDepth(d + 0.005));
        armature.add(this.add.circle(0, 0, 1.8, 0x3a3a50).setDepth(d + 0.006));
        station.add(armature);
        station._armature = armature;
        
        // === PNEUMATIC COLUMN ===
        station.add(this.add.rectangle(0, 4, 6, 10, 0x1e1e2a).setDepth(d + 0.01));
        station.add(this.add.rectangle(0, 4, 4, 8, 0x24243a).setDepth(d + 0.015));
        // Piston rings
        station.add(this.add.rectangle(0, 1, 8, 1, 0x3a3a4a).setDepth(d + 0.02));
        station.add(this.add.rectangle(0, 7, 8, 1, 0x3a3a4a).setDepth(d + 0.02));
        
        // === SEAT — front face dominant ===
        // Seat pan (foreshortened top visible)
        station.add(this.add.rectangle(0, -2, 24, 6, 0x24243a).setDepth(d + 0.03));    // top surface
        station.add(this.add.rectangle(0, -2, 22, 4, 0x2a2a40).setDepth(d + 0.035));    // cushion
        // Seat front edge
        station.add(this.add.rectangle(0, 1, 24, 3, 0x1e1e2a).setDepth(d + 0.025));
        station.add(this.add.rectangle(0, 1, 22, 2, 0x222238).setDepth(d + 0.028));
        
        // === BACKREST (front face — player sees it head-on from south) ===
        station.add(this.add.rectangle(0, -10, 22, 14, 0x1e1e2a).setDepth(d + 0.04));   // main back
        station.add(this.add.rectangle(0, -10, 20, 12, 0x24243a).setDepth(d + 0.045));    // face panel
        // Padding segments
        station.add(this.add.rectangle(0, -12, 18, 4, 0x2a2a40).setDepth(d + 0.05));     // upper pad
        station.add(this.add.rectangle(0, -7, 18, 4, 0x2a2a40).setDepth(d + 0.05));      // lower pad
        // Seam between pads
        station.add(this.add.rectangle(0, -9.5, 16, 0.5, 0x1a1a28).setDepth(d + 0.055));
        // Side bolsters
        station.add(this.add.rectangle(-11, -10, 2, 12, 0x141420).setDepth(d + 0.038));
        station.add(this.add.rectangle(11, -10, 2, 12, 0x141420).setDepth(d + 0.038));
        
        // === HEADREST (top of backrest) ===
        station.add(this.add.rectangle(0, -19, 14, 5, 0x1e1e2a).setDepth(d + 0.06));
        station.add(this.add.rectangle(0, -19, 12, 3, 0x2a2a40).setDepth(d + 0.065));
        // Foreshortened top strip
        station.add(this.add.rectangle(0, -22, 14, 2, 0x2e2e44).setDepth(d + 0.07));
        
        // === ARMRESTS ===
        // Left armrest (side face)
        station.add(this.add.rectangle(-14, -4, 4, 10, 0x1e1e2a).setDepth(d + 0.04));
        station.add(this.add.rectangle(-14, -4, 3, 8, 0x24243a).setDepth(d + 0.045));
        // Right armrest
        station.add(this.add.rectangle(14, -4, 4, 10, 0x1e1e2a).setDepth(d + 0.04));
        station.add(this.add.rectangle(14, -4, 3, 8, 0x24243a).setDepth(d + 0.045));
        // Armrest pads (top — foreshortened)
        station.add(this.add.rectangle(-14, -9, 5, 2, 0x2e2e44).setDepth(d + 0.05));
        station.add(this.add.rectangle(14, -9, 5, 2, 0x2e2e44).setDepth(d + 0.05));
        
        // === TECH DETAILS — rivets, LED indicators ===
        // Corner rivets on backrest
        [[-9, -16], [9, -16], [-9, -4], [9, -4]].forEach(([rx, ry]) => {
            station.add(this.add.circle(rx, ry, 0.7, 0x444450).setDepth(d + 0.055));
        });
        // LED strip on headrest
        const ledG = this.add.circle(-4, -19, 0.8, 0x44aa44, 0.2);
        station.add(ledG.setDepth(d + 0.07));
        const ledB = this.add.circle(0, -19, 0.8, 0x4488ff, 0.15);
        station.add(ledB.setDepth(d + 0.07));
        const ledR = this.add.circle(4, -19, 0.8, 0xff4444, 0.1);
        station.add(ledR.setDepth(d + 0.07));
        
        // === CABLE PORT (back of chair — connects to east wall) ===
        station.add(this.add.rectangle(12, -10, 3, 4, 0x333345).setDepth(d + 0.04));
        station.add(this.add.circle(13, -10, 1.5, 0x2a2a3a).setDepth(d + 0.045));
        
        // Store LED refs for animation
        station._leds = [ledG, ledB, ledR];
        station._armature = armature;
        station._chairActive = false;
        
        // Proximity: spin armature + pulse LEDs + trigger east wall mechanism
        station._onApproach = (scene) => {
            if (station._chairActive) return;
            station._chairActive = true;
            // Armature spin
            if (station._spinTween) station._spinTween.stop();
            station._spinTween = scene.tweens.add({
                targets: armature, angle: 360, duration: 3000,
                repeat: -1, ease: 'Linear'
            });
            // LEDs pulse on
            station._leds.forEach((led, i) => {
                scene.tweens.add({
                    targets: led, alpha: 0.8, duration: 400,
                    delay: i * 100, ease: 'Power2'
                });
            });
            // Trigger east wall mechanism gears
            if (scene._mechGears) {
                scene._mechGears.forEach((gear, i) => {
                    if (gear._spinTween) gear._spinTween.stop();
                    gear._spinTween = scene.tweens.add({
                        targets: gear, angle: (i % 2 === 0 ? 360 : -360),
                        duration: 2000 + i * 500, repeat: -1, ease: 'Linear'
                    });
                });
            }
            if (scene._mechLed) {
                scene.tweens.add({ targets: scene._mechLed, alpha: 0.7, duration: 300 });
            }
        };
        station._onLeave = (scene) => {
            if (!station._chairActive) return;
            station._chairActive = false;
            if (station._spinTween) { station._spinTween.stop(); station._spinTween = null; }
            scene.tweens.add({ targets: armature, angle: 0, duration: 800, ease: 'Power2' });
            station._leds.forEach(led => {
                scene.tweens.add({ targets: led, alpha: led === ledG ? 0.2 : led === ledB ? 0.15 : 0.1, duration: 400 });
            });
            // Stop mechanism gears
            if (scene._mechGears) {
                scene._mechGears.forEach(gear => {
                    if (gear._spinTween) { gear._spinTween.stop(); gear._spinTween = null; }
                    scene.tweens.add({ targets: gear, angle: 0, duration: 600, ease: 'Power2' });
                });
            }
            if (scene._mechLed) {
                scene.tweens.add({ targets: scene._mechLed, alpha: 0.15, duration: 400 });
            }
        };
        
        station.setDepth(d);
        station.setScale(1.5);
        station._handcraftedType = 'neural_chair';
        // CubeSim interaction — enter simulation or dismiss
        this.addStationInteraction(station, cx, cy, 30, 30, 'neural', 'CUBESIM',
            () => this._showCubeSimChoice(station, cx, cy));
    }

    // === CUBESIM CHAIR INTERACTION ===
    _showCubeSimChoice(station, cx, cy) {
        if (this.popupActive) return;
        this.popupActive = true;
        
        const W = CONFIG.width, H = CONFIG.height;
        const D = 200;
        const _choiceItems = [];
        const addC = (obj) => { _choiceItems.push(obj); return obj; };
        
        const overlay = addC(this.add.rectangle(W/2, H/2, W, H, 0x000000, 0.5)
            .setScrollFactor(0).setDepth(D).setInteractive());
        
        const bg = addC(this.add.rectangle(W/2, H/2, 160, 90, 0x0e0e18, 0.95)
            .setStrokeStyle(1, 0x334455).setScrollFactor(0).setDepth(D + 1));
        
        addC(this.add.text(W/2, H/2 - 30, 'CUBESIM', {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#44ffcc', fontStyle: 'bold'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(D + 2));
        
        addC(this.add.text(W/2, H/2 - 14, 'Combat Simulator', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#667788'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(D + 2));
        
        const btnW = 120, btnH = 20;
        const enterBg = addC(this.add.rectangle(W/2, H/2 + 10, btnW, btnH, 0x1a3a3a)
            .setStrokeStyle(1, 0x44aa88).setScrollFactor(0).setDepth(D + 3).setInteractive({ useHandCursor: true }));
        addC(this.add.text(W/2, H/2 + 10, 'ENTER SIMULATION', {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#44ffcc'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(D + 4));
        
        const dismissBg = addC(this.add.rectangle(W/2, H/2 + 34, btnW, btnH, 0x2a1a1a)
            .setStrokeStyle(1, 0x664444).setScrollFactor(0).setDepth(D + 3).setInteractive({ useHandCursor: true }));
        addC(this.add.text(W/2, H/2 + 34, 'DISMISS', {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#aa6666'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(D + 4));
        
        const cleanup = () => { _choiceItems.forEach(o => o.destroy()); this.popupActive = false; };
        
        enterBg.on('pointerover', () => enterBg.setFillStyle(0x2a5a5a));
        enterBg.on('pointerout', () => enterBg.setFillStyle(0x1a3a3a));
        dismissBg.on('pointerover', () => dismissBg.setFillStyle(0x3a2a2a));
        dismissBg.on('pointerout', () => dismissBg.setFillStyle(0x2a1a1a));
        
        dismissBg.on('pointerdown', () => { AudioManager.uiClick(); cleanup(); });
        overlay.on('pointerdown', () => { AudioManager.uiClick(); cleanup(); });
        
        enterBg.on('pointerdown', (pointer, lx, ly, event) => {
            event.stopPropagation();
            AudioManager.uiClick();
            cleanup();
            this._beginCubeSimEntry(station, cx, cy);
        });
    }
    
    _beginCubeSimEntry(station, cx, cy) {
        this.popupActive = true;
        this.moveDir = { x: 0, y: 0 };
        
        // Hide player instantly
        this.player.setVisible(false);
        if (this.player.backpack) this.player.backpack.setVisible(false);
        if (this.player._crownSprite) this.player._crownSprite.setVisible(false);
        if (this.player._shadow) this.player._shadow.setVisible(false);
        
        // Store station ref for return
        this._cubeSimStation = station;
        
        // Launch CubeSimScene (it has its own square-dissolve reveal)
        this.scene.launch('CubeSimScene', {
            saveData: SaveManager.load(),
            returnScene: 'SafehouseScene'
        });
        this.scene.pause();
    }
    
    // Called when returning from CubeSimScene
    _returnFromCubeSim() {
        this.scene.resume();
        
        // Show player again
        this.player.setVisible(true);
        if (this.player.backpack) this.player.backpack.setVisible(true);
        if (this.player._crownSprite) this.player._crownSprite.setVisible(true);
        if (this.player._shadow) this.player._shadow.setVisible(true);
        this.popupActive = false;
    }
    
    createVehicleStation(vx, vy) {
        // Use isometric vehicle drawing - pointing right toward garage
        const station = SpriteManager.createVehicle(this, vx, vy, 'iso');
        station.setDepth(10);
        station.setScale(1.4);
        this.vehicleStation = station;
        this.vehicleStationPos = { x: vx, y: vy };
        
        const scn = this; // closure ref for label getter
        station.config = {
            id: 'vehicle',
            x: vx,
            y: vy,
            width: 50,
            height: 30,
            get label() {
                return (scn.saveData?.activeRoute?.status === 'locked') ? 'DEPART' : 'VEHICLE';
            },
            action: () => this.showVehicleMenu()
        };
        station._roomId = this._stationRoom || 'hub';
        
        this.stations.push(station);
        
        // Add collision box
        this.stationColliders.push({
            x: vx - 25,
            y: vy - 15,
            width: 50,
            height: 30,
            roomId: station._roomId
        });
    }
    
    showVehicleMenu() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const hasRoute = this.saveData.activeRoute && this.saveData.activeRoute.status === 'locked';
        const survivors = (this.saveData.survivors || []).filter(s => s.alive);
        const deployed = survivors.find(s => s.deployed) || survivors[0];
        
        const panelH = hasRoute ? 220 : 140;
        const panel = UIManager.createPanel(this, W/2, H/2, 280, panelH, {
            title: hasRoute ? 'ROUTE LOCKED' : 'VEHICLE', accent: hasRoute ? 'confirm' : 'default', closable: true,
            onClose: () => { this.popupActive = false; }, depth: 200
        });
        this.currentPopup = panel;
        const cb = panel._contentBounds;
        
        if (hasRoute && deployed) {
            // Show current deployed survivor
            const rDef = SurvivorGenerator.RARITIES[deployed.rarity];
            panel.add(this.add.text(0, cb.y + 10, 'DEPLOYED OPERATOR', {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#667788'
            }).setOrigin(0.5));
            
            panel.add(this.add.text(0, cb.y + 28, deployed.name, {
                fontFamily: CONFIG.font, fontSize: uiPx(12), fill: rDef.textColor, fontStyle: 'bold'
            }).setOrigin(0.5));
            
            // Equipped title
            let deployInfoY = cb.y + 46;
            if (deployed.equippedTitle) {
                const tDef = CONFIG.survivorTitles ? CONFIG.survivorTitles[deployed.equippedTitle] : null;
                const tCol = tDef ? tDef.color : '#bbaa66';
                panel.add(this.add.text(0, cb.y + 44, deployed.equippedTitle.toUpperCase(), {
                    fontFamily: CONFIG.font, fontSize: uiPx(7), fill: tCol,
                    fontStyle: 'bold', letterSpacing: 1
                }).setOrigin(0.5));
                deployInfoY = cb.y + 58;
            }
            
            const rank = SurvivorGenerator.getRank(deployed);
            panel.add(this.add.text(0, deployInfoY, `${rDef.label} | ${rank.label} | ${deployed.personality.label}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#556677'
            }).setOrigin(0.5));
            
            // Resource bar
            const resBar = UIManager.createResourceBar(this, 0, cb.y + 66, {
                bits: this.saveData.stash.bits, fuel: this.saveData.stash.fuel,
                mag: (ItemManager.getEquipmentStats(this.saveData.equipment || {}).mag || 10), materials: this.saveData.stash.materials || 0
            }, { depth: 201, compact: true });
            panel.add(resBar);
            
            // Depart button
            const departBtn = UIManager.createButton(this, 0, cb.y + 96, 'DEPART', {
                width: 180, height: 36, style: 'confirm', fontSize: uiPx(12), depth: 201,
                onClick: () => {
                    this._selectedSurvivorId = deployed.id;
                    this._lastDeployedSurvivor = deployed.id;
                    panel.destroy(); this.popupActive = false; this.startRun();
                }
            });
            panel.add(departBtn);
            
            // Vehicle storage
            const invBtn = UIManager.createButton(this, 0, cb.y + 134, 'VEHICLE STORAGE', {
                width: 180, height: 30, style: 'normal', fontSize: uiPx(10), depth: 201,
                onClick: () => { panel.destroy(); this.popupActive = false; this.openVehicleStashInventory(); }
            });
            panel.add(invBtn);
        } else if (!hasRoute) {
            // No route locked — just vehicle storage
            panel.add(this.add.text(0, cb.y + 16, 'No route planned.\nLock a route on the map first.', {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#778899', align: 'center'
            }).setOrigin(0.5));
            
            const invBtn = UIManager.createButton(this, 0, cb.y + 58, 'VEHICLE STORAGE', {
                width: 180, height: 32, style: 'normal', fontSize: uiPx(11), depth: 201,
                onClick: () => { panel.destroy(); this.popupActive = false; this.openVehicleStashInventory(); }
            });
            panel.add(invBtn);
        } else {
            // Route locked but no survivors alive
            panel.add(this.add.text(0, cb.y + 20, 'All survivors are dead.\nThe wastes have won.', {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#aa4444', align: 'center'
            }).setOrigin(0.5));
        }
    }

    
    openVehicleStashInventory() {
        if (this.popupActive) return;
        // Need vehicle inventory from run state or create fresh
        if (!this.runState) {
            this.runState = {
                vehicle: ItemManager.createInventory(CONFIG.inventory.vehicleSlots)
            };
        }
        if (!this.runState.vehicle) {
            this.runState.vehicle = ItemManager.createInventory(CONFIG.inventory.vehicleSlots);
        }
        
        this.popupActive = true;
        this.inventoryUI = new InventoryUI(
            this,
            this.runState.vehicle,
            this.saveData.stash.inventory,
            'VEHICLE',
            'STASH',
            () => {
                this.inventoryUI = null;
                this.popupActive = false;
                this.saveSaveData();
            }
        );
    }
    
    createStation(config) {
        const station = this.add.container(config.x, config.y);
        
        const w = config.width;
        const h = config.height;
        
        const baseColor = config.color;
        
        // Isometric cube faces
        const elevation = Math.min(h * 0.45, 10);
        const sideW = Math.max(2, Math.min(elevation * 0.45, w * 0.14));
        const topColor = IsoRenderer.lighten(baseColor, 0.18);
        const frontColor = baseColor;
        const sideColor = IsoRenderer.darken(baseColor, 0.22);
        
        // Side face
        station.add(this.add.rectangle(w/2 - sideW/2, -elevation/2, sideW, h + elevation, sideColor));
        
        // Front face
        station.add(this.add.rectangle(-sideW/2, h/2 - elevation/2 + elevation/2, w - sideW, elevation, frontColor));
        
        // Top surface
        const base = this.add.rectangle(-sideW/2, -elevation/2, w - sideW, h, topColor);
        station.add(base);
        
        // Subtle edge lines
        const edgeColor = IsoRenderer.darken(baseColor, 0.3);
        station.add(this.add.rectangle(-w/2 + 2, -elevation/2, 2, h, edgeColor, 0.25));
        station.add(this.add.rectangle(w/2 - sideW - 1, -elevation/2, 2, h, edgeColor, 0.25));
        
        // Icon
        const icon = this.add.text(0, -4, config.icon, { fontSize: uiPx(14) }).setOrigin(0.5);
        station.add(icon);
        
        // Label (hidden until nearby)
        const label = this.add.text(0, h/2 + elevation + 8, config.label, {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#888'
        }).setOrigin(0.5).setAlpha(0);
        station.add(label);
        
        station.setDepth(10);
        station.config = config;
        station.label = label;
        station.base = base;
        
        this.stations.push(station);
        
        this.stationColliders.push({
            x: config.x - w/2,
            y: config.y - h/2,
            width: w,
            height: h
        });
    }
    
    createUI() {
        const uiDepth = 100;
        const stash = this.saveData.stash;
        if (!this.saveData.player) this.saveData.player = {};
        if (!this.saveData.player.totalXP) this.saveData.player.totalXP = 0;
        
        // Find deployed survivor for HUD
        const survivors = (this.saveData.survivors || []).filter(s => s.alive);
        const deployed = survivors.find(s => s.deployed) || survivors[0] || null;
        
        // ── Shared top HUD ──
        this.hud = GameHUD.create(this, {
            title: 'BASE OF OPERATIONS',
            resources: {
                bits: stash.bits || 0,
                fuel: stash.fuel || 0,
                mag: (ItemManager.getEquipmentStats(this.saveData ? this.saveData.equipment : {}).mag || 10), materials: stash.materials || 0
            },
            survivor: deployed
        });
        
        // Wire legacy text refs for panels that update them
        this.bitsText = this.hud._texts.bits;
        this.fuelText = this.hud._texts.fuel;
        this.magText = this.hud._texts.mag;
        this.materialsText = this.hud._texts.materials;
        
        // Wire ID tab to show deployed survivor's card
        if (this.hud._onCardOpen === undefined) {
            this.hud._onCardOpen = () => {
                if (this.popupActive) return;
                if (this._survPanel) return; // already showing a card
                const surv = (this.saveData.survivors || []).find(s => s.deployed);
                if (!surv) return;
                // Use player_sheet since deployed survivor IS the player
                const sheetKey = this.textures.exists('player_sheet') ? 'player_sheet' : ('npc_sheet_' + surv.id);
                const mockNpc = {
                    surv,
                    sheetKey,
                    sprite: null,
                    x: 0, y: 0,
                    state: 'idle',
                    _selfView: true
                };
                try {
                    this.showSurvivorInteraction(mockNpc);
                } catch (e) {
                    console.error('ID card error:', e);
                    this.popupActive = false;
                }
            };
        }
    }
    
    createPlayer() {
        // Apply active survivor's appearance
        const survivors = (this.saveData.survivors || []).filter(s => s.alive);
        if (survivors.length > 0) {
            // Use last deployed or first alive
            const active = survivors.find(s => s.deployed) || survivors[0];
            // Ensure exactly one is deployed — prevents duplicate NPC of the player
            if (!active.deployed) {
                survivors.forEach(s => s.deployed = false);
                active.deployed = true;
                SaveManager.save(this.saveData);
            }
            const custom = SurvivorGenerator.toCustomization(active);
            SpriteManager.playerSheetReady = false;
            SpriteManager.initPlayerSheet(null, custom);
            this._activeSurvivorId = active.id;
        }
        
        // Player spawn point (center of hub room)
        const hub = this.ROOMS.hub;
        const WC = this._wallConst;
        const spawnX = hub.x + hub.w / 2;
        const spawnY = hub.y + hub.h / 2 + 40;
        
        // Create animated player sprite (no physics in safehouse)
        const _activeSurv = (this.saveData.survivors || []).find(s => s.deployed);
        const _activeAura = _activeSurv ? _activeSurv.equippedAura : null;
        this.player = SpriteManager.createPlayerSpriteNoPhysics(this, spawnX, spawnY, null, _activeAura);
        this.player.setDepth(20);
        DynamicShadows.add(this, this.player, { offsetY: 10, scale: 0.6, alpha: 0.15 });
        
        // Movement state
        this.moveDir = { x: 0, y: 0 };
        this.playerSpeed = 150;
    }
    
    setupInput() {
        InputManager.setup(this, { dodge: false, tapTarget: false });
        // Keyboard (optional - may not exist on mobile)
        if (this.input.keyboard) {
            this.keys = this.input.keyboard.addKeys({ w:'W', s:'S', a:'A', d:'D' });
        }
    }
    
    // ═══════════════════════════════════════════
    // TIME OF DAY — ambient overlay tint
    // ═══════════════════════════════════════════
    createTimeOfDayOverlay() {
        const tod = CONFIG.timeOfDay || 'midday';
        // Indoor safehouse — subtle ambient shift, not full outdoor exposure
        const tints = {
            dawn:   { color: 0xffcc88, alpha: 0.06 },
            midday: { color: 0x000000, alpha: 0 },
            dusk:   { color: 0xff8855, alpha: 0.08 },
            night:  { color: 0x223366, alpha: 0.14 }
        };
        const t = tints[tod] || tints.midday;
        const vw = CONFIG.width, vh = CONFIG.height;
        
        if (t.alpha > 0) {
            // Full-viewport tint overlay
            this._todOverlay = this.add.rectangle(vw/2, vh/2, vw + 20, vh + 20, t.color, t.alpha)
                .setDepth(198).setScrollFactor(0);
        }
        
        if (tod === 'night') {
            // Vignette darkening at screen edges for nighttime atmosphere
            const vigG = this.add.graphics().setDepth(199).setScrollFactor(0);
            for (let i = 0; i < 6; i++) {
                const a = 0.04 * (6 - i); // outer = darkest, inner = lightest
                vigG.fillStyle(0x000000, a);
                const inset = i * 18;
                // Top strip
                vigG.fillRect(inset, inset, vw - inset * 2, 18);
                // Bottom strip
                vigG.fillRect(inset, vh - inset - 18, vw - inset * 2, 18);
                // Left strip
                vigG.fillRect(inset, inset + 18, 18, vh - inset * 2 - 36);
                // Right strip
                vigG.fillRect(vw - inset - 18, inset + 18, 18, vh - inset * 2 - 36);
            }
        }
    }
    
    // ═══════════════════════════════════════════
    // SURVIVOR NPCs — alive non-deployed survivors wander safehouse
    // ═══════════════════════════════════════════
    spawnSurvivorNPCs() {
        this._survivorNPCs = [];
        const survivors = (this.saveData.survivors || []).filter(s => s.alive && !s.deployed);
        if (survivors.length === 0) return;
        
        const bar = this.ROOMS.barracks;
        const hub = this.ROOMS.hub;
        const WC = this._wallConst;
        const wallH = WC.topH + WC.frontH;
        const barVisible = this._roomContainers.barracks && this._roomContainers.barracks.visible;
        
        // Waypoints per room for NPC activities
        this._npcWaypoints = {
            barracks: [
                { x: bar.x + WC.sideW + 35, y: bar.y + wallH + 50, activity: 'idle' },
                { x: bar.x + bar.w/2, y: bar.y + wallH + 50, activity: 'idle' },
                { x: bar.x + bar.w - WC.sideW - 35, y: bar.y + wallH + 50, activity: 'idle' },
                { x: bar.x + bar.w/2, y: bar.y + bar.h - wallH - 30, activity: 'wander' },
                { x: bar.x + WC.sideW + 30, y: bar.y + bar.h - wallH - 20, activity: 'wander' },
                // Bunk sleeping spots
                { x: bar.x + WC.sideW + 35, y: bar.y + wallH + 24, activity: 'sleep' },
                { x: bar.x + bar.w/2, y: bar.y + wallH + 24, activity: 'sleep' },
                { x: bar.x + bar.w - WC.sideW - 35, y: bar.y + wallH + 24, activity: 'sleep' }
            ],
            hub: [
                { x: hub.x + hub.w/2, y: hub.y + hub.h/2, activity: 'wander' },
                { x: hub.x + WC.sideW + 40, y: hub.y + wallH + 60, activity: 'idle' },
                { x: hub.x + hub.w - WC.sideW - 40, y: hub.y + hub.h/2 + 20, activity: 'wander' },
                { x: hub.x + hub.w/2 - 30, y: hub.y + hub.h - wallH - 40, activity: 'idle' },
                { x: hub.x + hub.w/2 + 40, y: hub.y + hub.h/2 - 20, activity: 'wander' }
            ]
        };
        
        survivors.forEach((surv, i) => {
            // Assign room — barracks if revealed and most NPCs, hub as fallback
            const room = (barVisible && i < 3) ? 'barracks' : 'hub';
            const waypoints = this._npcWaypoints[room];
            const startWP = waypoints[i % waypoints.length];
            
            const npc = this._createSurvivorNPC(surv, startWP.x, startWP.y, room);
            this._survivorNPCs.push(npc);
        });
    }
    
    _createSurvivorNPC(surv, x, y, room) {
        const custom = SurvivorGenerator.toCustomization(surv);
        const sheetKey = 'npc_sheet_' + surv.id;
        
        // Generate sprite sheet for this survivor
        const canvas = SpriteManager.generatePlayerSheet(custom);
        if (this.textures.exists(sheetKey)) this.textures.remove(sheetKey);
        this.textures.addSpriteSheet(sheetKey, canvas, { frameWidth: 48, frameHeight: 48 });
        
        // Create walk animations for this NPC
        const dirs = ['down','down_right','right','up_right','up','up_left','left','down_left'];
        dirs.forEach((dir, i) => {
            const animKey = `npc_walk_${surv.id}_${dir}`;
            if (!this.anims.exists(animKey)) {
                this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 6, repeat: -1 });
            }
        });
        const idleKey = `npc_idle_${surv.id}`;
        if (!this.anims.exists(idleKey)) {
            this.anims.create({ key: idleKey, frames: [{ key: sheetKey, frame: 0 }], frameRate: 1 });
        }
        
        // Create sprite — NPCs appear larger than player to indicate non-playable
        const sprite = this.add.sprite(x, y, sheetKey, 0);
        sprite.setDisplaySize(40, 40);
        sprite.setDepth(10 + y * 0.01);
        
        // Shadow
        const shadow = this.add.ellipse(x, y + 14, 16, 6, 0x000000, 0.15).setDepth(9);
        
        // Name tag (fades in on approach)
        const rDef = SurvivorGenerator.RARITIES[surv.rarity];
        const nameTag = this.add.text(x, y - 22, surv.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: rDef.textColor
        }).setOrigin(0.5).setAlpha(0).setDepth(200);
        
        // Room visibility
        const roomContainer = this._roomContainers[room];
        const isVisible = roomContainer ? roomContainer.visible : true;
        sprite.setVisible(isVisible);
        shadow.setVisible(isVisible);
        nameTag.setVisible(isVisible);
        
        // Crown for mastery-tier aura NPCs
        let crownSprite = null;
        const npcAuraId = surv.equippedAura || 'none';
        const npcAuraDef = npcAuraId !== 'none' ? CONFIG.survivorAuras[npcAuraId] : null;
        if (npcAuraDef && npcAuraDef.tier === 'mastery') {
            // Create a temp target object for CrownAura
            const tmpTarget = { x: x, y: y, depth: sprite.depth };
            crownSprite = CrownAura.createCrown(this, tmpTarget);
            if (crownSprite) {
                crownSprite.setVisible(isVisible);
            }
        }
        
        const npcData = {
            sprite,
            shadow,
            crownSprite,
            surv,
            nameTag,
            sheetKey,
            room,
            x, y,
            targetX: x, targetY: y,
            state: 'idle',
            stateTimer: Phaser.Math.Between(2000, 6000),
            speed: 30 + Math.random() * 20,
            _breathPhase: Math.random() * Math.PI * 2,
            _walkDir: 'down',
            _baseScale: 40 / 48, // matches player displaySize
            // For InteractHighlight compatibility (needs .x, .y)
            get container() { return sprite; }
        };
        
        return npcData;
    }
    
    _updateSurvivorNPCs(dt) {
        if (!this._survivorNPCs) return;
        
        const playerX = this.player?.x || 0;
        const playerY = this.player?.y || 0;
        
        for (const npc of this._survivorNPCs) {
            // Room visibility sync
            const roomC = this._roomContainers[npc.room];
            const vis = roomC ? roomC.visible : true;
            npc.sprite.setVisible(vis);
            npc.shadow.setVisible(vis);
            npc.nameTag.setVisible(vis);
            if (npc.crownSprite) npc.crownSprite.setVisible(vis);
            if (!vis) continue;
            
            npc.stateTimer -= dt * 1000;
            
            if (npc.state === 'idle') {
                // Subtle breathing bob
                npc._breathPhase += dt * 1.5;
                npc.sprite.y = npc.y + Math.sin(npc._breathPhase) * 0.5;
                const bs = npc._baseScale || (40/48);
                npc.sprite.setScale(bs, bs);
                
                // Stop walk anim if playing
                if (npc.sprite.anims && npc.sprite.anims.isPlaying) {
                    npc.sprite.anims.stop();
                    // Set to idle frame based on direction
                    const dirFrames = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                    npc.sprite.setFrame(dirFrames[npc._walkDir] || 0);
                }
                
                if (npc.stateTimer <= 0) {
                    const waypoints = this._npcWaypoints[npc.room] || [];
                    if (waypoints.length > 0) {
                        const wp = waypoints[Math.floor(Math.random() * waypoints.length)];
                        if (wp.activity === 'sleep' && CONFIG.timeOfDay === 'night') {
                            npc.targetX = wp.x;
                            npc.targetY = wp.y;
                            npc.state = 'walking';
                            npc._nextState = 'sleeping';
                        } else {
                            npc.targetX = wp.x + Phaser.Math.Between(-15, 15);
                            npc.targetY = wp.y + Phaser.Math.Between(-10, 10);
                            npc.state = 'walking';
                            npc._nextState = 'idle';
                        }
                    }
                    npc.stateTimer = Phaser.Math.Between(3000, 8000);
                }
            } else if (npc.state === 'walking') {
                const dx = npc.targetX - npc.x;
                const dy = npc.targetY - npc.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                
                if (dist < 3) {
                    npc.x = npc.targetX;
                    npc.y = npc.targetY;
                    npc.state = npc._nextState || 'idle';
                    npc.stateTimer = npc.state === 'sleeping' ? Phaser.Math.Between(10000, 20000) : Phaser.Math.Between(3000, 7000);
                } else {
                    const moveX = (dx / dist) * npc.speed * dt;
                    const moveY = (dy / dist) * npc.speed * dt;
                    npc.x += moveX;
                    npc.y += moveY;
                    
                    // Determine walk direction for animation
                    const angle = Math.atan2(dy, dx) * (180 / Math.PI);
                    let dir = 'down';
                    if (angle >= -22.5 && angle < 22.5) dir = 'right';
                    else if (angle >= 22.5 && angle < 67.5) dir = 'down_right';
                    else if (angle >= 67.5 && angle < 112.5) dir = 'down';
                    else if (angle >= 112.5 && angle < 157.5) dir = 'down_left';
                    else if (angle >= 157.5 || angle < -157.5) dir = 'left';
                    else if (angle >= -157.5 && angle < -112.5) dir = 'up_left';
                    else if (angle >= -112.5 && angle < -67.5) dir = 'up';
                    else dir = 'up_right';
                    
                    npc._walkDir = dir;
                    const walkKey = `npc_walk_${npc.surv.id}_${dir}`;
                    if (npc.sprite.anims && this.anims.exists(walkKey)) {
                        if (!npc.sprite.anims.isPlaying || npc.sprite.anims.currentAnim?.key !== walkKey) {
                            npc.sprite.play(walkKey, true);
                        }
                    }
                }
                npc.sprite.x = npc.x;
                npc.sprite.y = npc.y;
            } else if (npc.state === 'sleeping') {
                const bs = npc._baseScale || (40/48);
                npc.sprite.setScale(bs, bs * 0.7);
                npc._breathPhase += dt * 0.8;
                npc.sprite.y = npc.y + Math.sin(npc._breathPhase) * 0.3;
                
                if (npc.stateTimer <= 0) {
                    npc.sprite.setScale(bs, bs);
                    npc.state = 'idle';
                    npc.stateTimer = Phaser.Math.Between(3000, 6000);
                }
            } else if (npc.state === 'interacting') {
                // Frozen facing player — no movement, no timer
                const bs = npc._baseScale || (40/48);
                npc.sprite.setScale(bs, bs);
            }
            
            // Update shadow + depth
            npc.shadow.setPosition(npc.sprite.x, npc.sprite.y + 14);
            npc.sprite.setDepth(10 + npc.y * 0.01);
            npc.shadow.setDepth(npc.sprite.depth - 0.5);
            
            // Update NPC crown bob
            if (npc.crownSprite && npc.crownSprite.active) {
                npc.crownSprite._bobPhase = (npc.crownSprite._bobPhase || 0) + CrownAura.BOB_SPEED * 16.67;
                const bobY = Math.sin(npc.crownSprite._bobPhase) * CrownAura.BOB_AMP;
                npc.crownSprite.x = Math.round(npc.sprite.x);
                npc.crownSprite.y = Math.round(npc.sprite.y - 22 + bobY);
                npc.crownSprite.setDepth(npc.sprite.depth + 0.2);
            }
            
            // Name tag follows and fades on proximity
            npc.nameTag.setPosition(npc.sprite.x, npc.sprite.y - 22);
            const distToPlayer = Math.sqrt((npc.x - playerX) ** 2 + (npc.y - playerY) ** 2);
            const nameAlpha = distToPlayer < 60 ? Math.min(1, (60 - distToPlayer) / 20) : 0;
            npc.nameTag.setAlpha(nameAlpha);
        }
    }
    
    // ═══════════════════════════════════════════
    // SURVIVOR INTERACTION — talk, switch, view card
    // ═══════════════════════════════════════════
    checkSurvivorProximity() {
        if (!this._survivorNPCs || this._survivorNPCs.length === 0) return;
        if (this.nearestStation) return; // station takes priority
        
        const px = this.player.x, py = this.player.y;
        let nearest = null, nearestDist = Infinity;
        
        for (const npc of this._survivorNPCs) {
            if (!npc.container.visible) continue;
            if (npc.room !== this.currentRoom) continue;
            const dist = Math.sqrt((npc.x - px) ** 2 + (npc.y - py) ** 2);
            if (dist < 50 && dist < nearestDist) {
                nearest = npc;
                nearestDist = dist;
            }
        }
        
        this._nearestNPC = nearest;
        
        if (nearest && !this.popupActive) {
            // Show interaction highlight on the NPC
            InteractHighlight.show(this, nearest.container, nearest.surv.name, { padding: 8 });
        }
    }
    
    handleInteract() {
        // Called by InputManager tap handler when highlight target isn't a station
        if (this._nearestNPC && !this.popupActive) {
            this.showSurvivorInteraction(this._nearestNPC);
        }
    }
    
    showSurvivorInteraction(npc) {
        if (this.popupActive) return;
        this.popupActive = true;
        AudioManager.uiClick();
        
        // Face NPC toward the player and freeze them (skip for self-view)
        if (this.player && npc.sprite && !npc._selfView) {
            const dx = this.player.x - npc.x;
            const dy = this.player.y - npc.y;
            const angle = Math.atan2(dy, dx) * (180 / Math.PI);
            let dir = 'down';
            if (angle >= -22.5 && angle < 22.5) dir = 'right';
            else if (angle >= 22.5 && angle < 67.5) dir = 'down_right';
            else if (angle >= 67.5 && angle < 112.5) dir = 'down';
            else if (angle >= 112.5 && angle < 157.5) dir = 'down_left';
            else if (angle >= 157.5 || angle < -157.5) dir = 'left';
            else if (angle >= -157.5 && angle < -112.5) dir = 'up_left';
            else if (angle >= -112.5 && angle < -67.5) dir = 'up';
            else dir = 'up_right';
            npc._walkDir = dir;
            const dirFrames = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
            if (npc.sprite.anims) npc.sprite.anims.stop();
            npc.sprite.setFrame(dirFrames[dir] || 0);
            npc.state = 'interacting';
        }
        this._interactingNPC = npc;
        
        const surv = npc.surv;
        const rDef = SurvivorGenerator.RARITIES[surv.rarity];
        const rank = SurvivorGenerator.getRank(surv);
        const W = CONFIG.width, H = CONFIG.height;
        const GD = 240;
        const rColor = rDef.color;
        const rHex = '#' + rColor.toString(16).padStart(6, '0');
        
        this._survPanel = [];
        this._survFlipped = false;
        const panelAdd = (o) => { this._survPanel.push(o); o.setScrollFactor(0); return o; };
        
        // ══════════════════════════════════════
        // SURVIVOR CARD — bottom-left, no overlay
        // ══════════════════════════════════════
        // ── Dynamic card height calculation ──
        const cardW = 220;
        // Front face: portrait section + rank + stats + achievement row + padding
        const hasSurvTitle = !!(surv.equippedTitle);
        let frontH = 10 + 46 + (hasSurvTitle ? 18 : 0) + 24 + 24 + 20 + 30 + 10;
        // Back face: injury? + marks header + each mark + padding
        const marks = surv.marks || [];
        let backH = 20; // top + bottom padding
        if (surv.injury) backH += 31;
        backH += 15; // marks header
        marks.forEach(m => { backH += m.desc ? 25 : 13; });
        if (marks.length === 0) backH += 14;
        // Use whichever face is taller, clamp to reasonable range
        const cardH = Math.max(160, Math.min(Math.max(frontH, backH), H - 30));
        const cardX = 8 + cardW / 2;
        const cardY = H - cardH / 2 - 6;
        
        // Card background with rarity border
        const rarityBorder = panelAdd(this.add.rectangle(cardX, cardY, cardW + 4, cardH + 4, rColor, 0.7).setDepth(GD));
        const cardBg = panelAdd(this.add.rectangle(cardX, cardY, cardW, cardH, 0x0a0a14, 0.95).setDepth(GD+0.1));
        
        // Corner accents (rarity color)
        const cg = panelAdd(this.add.graphics().setDepth(GD+0.2).setScrollFactor(0));
        cg.setPosition(cardX, cardY); // pivot point = card center for scaleX flip
        const hw = cardW/2, hh = cardH/2;
        cg.lineStyle(2, rColor, 0.8);
        cg.beginPath(); cg.moveTo(-hw, -hh+10); cg.lineTo(-hw, -hh); cg.lineTo(-hw+10, -hh); cg.stroke();
        cg.beginPath(); cg.moveTo(hw-10, -hh); cg.lineTo(hw, -hh); cg.lineTo(hw, -hh+10); cg.stroke();
        cg.beginPath(); cg.moveTo(-hw, hh-10); cg.lineTo(-hw, hh); cg.lineTo(-hw+10, hh); cg.stroke();
        cg.beginPath(); cg.moveTo(hw-10, hh); cg.lineTo(hw, hh); cg.lineTo(hw, hh+10); cg.stroke();
        
        // Bounds for content positioning and close detection
        const cl = cardX - cardW/2, ct = cardY - cardH/2, cr = cardX + cardW/2, cb = cardY + cardH/2;
        
        // ── FRONT FACE CONTENT ──
        this._survFront = [];
        this._survBack = [];
        const fAdd = (o) => { this._survFront.push(o); return panelAdd(o); };
        const bAdd = (o) => { this._survBack.push(o); o.setVisible(false); return panelAdd(o); };
        
        // Sprite portrait — positioned from card top
        const sheetKey = npc.sheetKey || ('npc_sheet_' + surv.id);
        const portX = cl + 40;
        const frontTop = ct + 10;
        if (this.textures.exists(sheetKey)) {
            fAdd(this.add.sprite(portX, frontTop + 28, sheetKey, 0)
                .setDisplaySize(56, 56).setDepth(GD+1));
        }
        
        // Info text — right of portrait
        const infoX = cl + 74;
        const nameTextObj = fAdd(this.add.text(infoX, frontTop, surv.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(13), fill: rHex, fontStyle: 'bold'
        }).setDepth(GD+1));
        
        const gLabel = surv.gender === 'unknown'
            ? (surv.unknownType ? surv.unknownType.charAt(0).toUpperCase() + surv.unknownType.slice(1) : 'Unknown')
            : surv.gender.charAt(0).toUpperCase() + surv.gender.slice(1);
        fAdd(this.add.text(infoX, frontTop + 20, `${rDef.label}  ·  ${gLabel}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(7.5), fill: '#8899aa'
        }).setDepth(GD+1));
        
        fAdd(this.add.text(infoX, frontTop + 36, surv.personality.label, {
            fontFamily: CONFIG.font, fontSize: uiPx(7.5), fill: '#99aabb', fontStyle: 'italic'
        }).setDepth(GD+1));
        
        // ── Equipped Title (centered below personality row) ──
        const eTitle = surv.equippedTitle || null;
        let titleRowH = 0;
        if (eTitle) {
            try {
                TitleFont.build();
                const titleMaxW = cardW - 50; // leave room for slots on right
                const titleG = TitleFont.drawTitle(this, cardX, frontTop + 52, eTitle, {
                    maxWidth: titleMaxW, maxScale: 1.1, minScale: 0.6,
                    depth: GD + 2, center: true
                });
                fAdd(titleG);
            } catch(e) {
                console.error('TitleFont error:', e);
                fAdd(this.add.text(cardX, frontTop + 52, eTitle.toUpperCase(), {
                    fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#ddaa33',
                    fontStyle: 'bold', letterSpacing: 2
                }).setOrigin(0.5, 0).setDepth(GD + 2));
            }
            titleRowH = 18;
        }
        
        // ── Title & Aura equip slots (right edge, stacked vertically) ──
        const slotSize = 20;
        const slotMarginR = 10;
        const slotX = cr - slotMarginR - slotSize / 2;
        const slotGapV = 6;
        const slotTitleY = ct + 10 + slotSize / 2;
        const slotAuraY = slotTitleY + slotSize + slotGapV;
        
        // Title slot (top)
        const titleSlotG = fAdd(this.add.graphics().setDepth(GD + 2).setScrollFactor(0));
        const hasTitles = (surv.unlockedTitles || []).length > 0;
        titleSlotG.lineStyle(1, hasTitles ? 0xddaa33 : 0x334455, hasTitles ? 0.7 : 0.4);
        titleSlotG.strokeRect(slotX - slotSize/2, slotTitleY - slotSize/2, slotSize, slotSize);
        if (eTitle) {
            titleSlotG.fillStyle(0xddaa33, 0.12);
            titleSlotG.fillRect(slotX - slotSize/2 + 1, slotTitleY - slotSize/2 + 1, slotSize - 2, slotSize - 2);
        }
        fAdd(this.add.text(slotX, slotTitleY, 'T', {
            fontFamily: CONFIG.font, fontSize: uiPx(8),
            fill: eTitle ? '#ddaa33' : '#445566', fontStyle: 'bold'
        }).setOrigin(0.5, 0.5).setDepth(GD + 3));
        
        // Aura slot (below title slot)
        const auraSlotG = fAdd(this.add.graphics().setDepth(GD + 2).setScrollFactor(0));
        const eAura = surv.equippedAura || 'none';
        const auraDef = CONFIG.survivorAuras[eAura];
        const hasAuras = (surv.unlockedAuras || []).filter(a => a !== 'none').length > 0;
        const auraAccent = hasAuras ? (auraDef && auraDef.color ? auraDef.color : 0x334455) : 0x334455;
        auraSlotG.lineStyle(1, auraAccent, hasAuras ? 0.7 : 0.4);
        auraSlotG.strokeRect(slotX - slotSize/2, slotAuraY - slotSize/2, slotSize, slotSize);
        if (eAura !== 'none' && auraDef && auraDef.color) {
            auraSlotG.fillStyle(auraDef.color, 0.15);
            auraSlotG.fillRect(slotX - slotSize/2 + 1, slotAuraY - slotSize/2 + 1, slotSize - 2, slotSize - 2);
        }
        const auraIconCol = (eAura !== 'none' && auraDef && auraDef.color) ? ('#' + auraDef.color.toString(16).padStart(6, '0')) : '#445566';
        fAdd(this.add.text(slotX, slotAuraY - 1, '\u25C6', {
            fontFamily: CONFIG.font, fontSize: uiPx(9),
            fill: auraIconCol
        }).setOrigin(0.5, 0.5).setDepth(GD + 3));
        
        // ── Interactive hit zones ──
        const hitPad = 6;
        const titleHit = fAdd(this.add.rectangle(slotX, slotTitleY, slotSize + hitPad, slotSize + hitPad, 0x000000, 0.001)
            .setDepth(GD + 4).setInteractive({ useHandCursor: true }));
        titleHit.on('pointerdown', () => {
            this._openTitleAuraSelector(surv, 'title', cardX, cardY, cardW, cardH, GD + 10, npc);
        });
        
        const auraHit = fAdd(this.add.rectangle(slotX, slotAuraY, slotSize + hitPad, slotSize + hitPad, 0x000000, 0.001)
            .setDepth(GD + 4).setInteractive({ useHandCursor: true }));
        auraHit.on('pointerdown', () => {
            this._openTitleAuraSelector(surv, 'aura', cardX, cardY, cardW, cardH, GD + 10, npc);
        });
        
        // ── Rank icon + label + XP bar row (centered, shifts down if title present) ──
        const rankY = frontTop + 62 + titleRowH;
        const rankIconKey = SurvivorGenerator.generateRankIcon(this, rank.level);
        const _rankCol = rank.level >= 7 ? '#bb77ff' : rank.level >= 6 ? '#ddbb55' : rank.level >= 5 ? '#dd8833' : rank.level >= 4 ? '#8899aa' : rank.level >= 3 ? '#cc5555' : rank.level >= 2 ? '#bb9966' : '#8899aa';
        
        // Measure rank label to center icon+label as a group
        const rankLabelTmp = this.add.text(0, 0, rank.label.toUpperCase(), {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: _rankCol, fontStyle: 'bold'
        });
        const rankLabelW = rankLabelTmp.width;
        rankLabelTmp.destroy();
        const rankGroupW = 20 + 4 + rankLabelW; // icon + gap + label
        const rankGroupX = cardX - rankGroupW / 2;
        
        fAdd(this.add.image(rankGroupX + 10, rankY, rankIconKey)
            .setDisplaySize(20, 20).setDepth(GD+1));
        fAdd(this.add.text(rankGroupX + 24, rankY - 7, rank.label.toUpperCase(), {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: _rankCol, fontStyle: 'bold'
        }).setDepth(GD+1));
        
        // Centered XP progress bar under rank (with gap + room for text on right)
        const xpToNext = SurvivorGenerator.getXPForNextRank(surv);
        const xpTextW = 32; // reserve space for "1234 XP" or "MAX"
        const barW = cardW - 50 - xpTextW, barH = 3;
        const barX = cardX - (barW + xpTextW) / 2, barY = rankY + 14;
        const xpG = fAdd(this.add.graphics().setDepth(GD+1).setScrollFactor(0));
        xpG.fillStyle(0x1a1a2a, 1); xpG.fillRect(barX, barY, barW, barH);
        if (xpToNext !== null) {
            const nextRank = SurvivorGenerator.RANKS.find(r => r.level === rank.level + 1);
            const prevXP = rank.xpNeeded;
            const nextXP = nextRank ? nextRank.xpNeeded : prevXP;
            const progress = nextXP > prevXP ? Math.min(1, (surv.xp - prevXP) / (nextXP - prevXP)) : 1;
            xpG.fillStyle(rColor, 0.6); xpG.fillRect(barX, barY, Math.round(barW * progress), barH);
            fAdd(this.add.text(barX + barW + 4, barY - 3, xpToNext > 0 ? `${xpToNext} XP` : 'MAX', {
                fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#778899'
            }).setDepth(GD+1));
        } else {
            xpG.fillStyle(rColor, 0.6); xpG.fillRect(barX, barY, barW, barH);
            fAdd(this.add.text(barX + barW + 4, barY - 3, 'MAX', {
                fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#ddaa44'
            }).setDepth(GD+1));
        }
        
        // ── Separator after XP ──
        const sepG1 = fAdd(this.add.graphics().setDepth(GD+1).setScrollFactor(0));
        sepG1.lineStyle(1, rColor, 0.15);
        sepG1.lineBetween(cl + 12, barY + 10, cr - 12, barY + 10);
        
        // ── Stats row: Runs + Kills + Bosses (centered) ──
        const statsY = barY + 16;
        const runsVal = surv.runsCompleted || 0;
        const killsVal = surv.kills || 0;
        const bossVal = surv.bossesKilled || 0;
        fAdd(this.add.text(cardX, statsY, `${runsVal} Run${runsVal !== 1 ? 's' : ''}  ·  ${killsVal} Kill${killsVal !== 1 ? 's' : ''}  ·  ${bossVal} Boss${bossVal !== 1 ? 'es' : ''}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#8899aa'
        }).setOrigin(0.5, 0).setDepth(GD+1));
        
        // ── Separator after stats ──
        const sepG2 = fAdd(this.add.graphics().setDepth(GD+1).setScrollFactor(0));
        sepG2.lineStyle(1, rColor, 0.15);
        sepG2.lineBetween(cl + 12, statsY + 14, cr - 12, statsY + 14);
        
        // ── Achievements header (centered) ──
        const survAchs = surv.achievements || [];
        const achComplete = survAchs.filter(a => a.complete).length;
        fAdd(this.add.text(cardX, statsY + 18, `ACHIEVEMENTS  ${achComplete}/${survAchs.length}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#667788', fontStyle: 'bold'
        }).setOrigin(0.5, 0).setDepth(GD+1));
        
        // ── Achievement icons (9 icons in adaptive grid — 3×3 when space allows, single row when tight) ──
        const achTopY = statsY + 32;
        const achBottomY = cb - 6;
        const achAvailH = achBottomY - achTopY;
        const achCount = survAchs.length || 9;
        
        // Decide layout: 3×3 grid if we have ≥ 48px height, otherwise single row
        const useGrid = achAvailH >= 48 && achCount === 9;
        const cols = useGrid ? 3 : achCount;
        const rows = useGrid ? 3 : 1;
        const achSize = useGrid
            ? Math.max(12, Math.min(Math.floor((achAvailH - (rows - 1) * 4) / rows), 22))
            : Math.max(12, Math.min(achAvailH, 18));
        const gridW = cardW - 32;
        const colGap = gridW / cols;
        const rowGap = useGrid ? (achAvailH - rows * achSize) / (rows + 1) : 0;
        const gridStartX = cl + 16 + colGap / 2;
        const gridStartY = useGrid ? achTopY + rowGap + achSize / 2 : achTopY + achAvailH / 2;
        
        survAchs.forEach((ach, i) => {
            const def = SurvivorGenerator.getAchievementDef(ach.id);
            if (!def) return;
            const iconKey = SurvivorGenerator.generateAchievementIcon(this, ach.id);
            const col = i % cols;
            const row = Math.floor(i / cols);
            const ax = gridStartX + col * colGap;
            const ay = gridStartY + row * (achSize + rowGap);
            const alpha = ach.complete ? 1.0 : 0.2;
            
            const icon = fAdd(this.add.image(ax, ay, iconKey)
                .setDisplaySize(achSize, achSize).setDepth(GD + 2).setAlpha(alpha)
                .setInteractive());
            
            // Completed glow ring
            if (ach.complete) {
                const glowCol = Phaser.Display.Color.HexStringToColor(def.color).color;
                fAdd(this.add.circle(ax, ay, achSize / 2 + 1, glowCol, 0.15).setDepth(GD + 1.5));
            }
            
            // Hold-to-view: 300ms hold on icon shows tooltip
            let holdTimer = null;
            icon.on('pointerdown', () => {
                holdTimer = this.time.delayedCall(300, () => {
                    holdTimer = null;
                    this._showAchievementTooltip(def, ach, ax, ay - achSize/2 - 4, cardX, cl, cr, GD);
                });
            });
            icon.on('pointerup', () => { if (holdTimer) { holdTimer.remove(); holdTimer = null; } });
            icon.on('pointerout', () => { if (holdTimer) { holdTimer.remove(); holdTimer = null; } });
        });
        
        // ── BACK FACE CONTENT (hidden) ──
        let py = ct + 10;
        
        // Tier color map — brighter for legibility
        const _tierCol = { mundane: '#99aabb', strange: '#bb88dd', legendary: '#ddaa44', earned: '#66aacc', cube: '#bb66dd' };
        const _typeCol = { positive: '#77cc77', mixed: '#cccc66', negative: '#cc7755' };
        
        // ── Injury section (top priority) ──
        if (surv.injury) {
            const injDef2 = SurvivorGenerator.INJURY_TYPES[surv.injury.type];
            const injCol = surv.injury.type === 'maimed' ? '#ee5555' : '#ddaa55';
            bAdd(this.add.text(cl + 12, py, '+', {
                fontFamily: CONFIG.font, fontSize: uiPx(8), fill: injCol, fontStyle: 'bold'
            }).setDepth(GD+1));
            const injName = injDef2 ? injDef2.label : surv.injury.type;
            const injStatus = surv.injury.treatedAt ? 'Treated' : 'Untreated';
            bAdd(this.add.text(cl + 22, py, `${injName} (${injStatus})`, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: injCol, fontStyle: 'bold'
            }).setDepth(GD+1));
            if (injDef2) {
                const treatName = surv.injury.treatedAt ? `Recovering — ${injDef2.recoveryRuns} runs` : `Cure: ${injDef2.treatment.replace(/_/g, ' ')}`;
                bAdd(this.add.text(cl + 22, py + 12, treatName, {
                    fontFamily: CONFIG.font, fontSize: uiPx(5.5), fill: '#bbaa77'
                }).setDepth(GD+1));
            }
            py += 26;
            // Thin separator
            const sepG = bAdd(this.add.graphics().setDepth(GD+1).setScrollFactor(0));
            sepG.lineStyle(1, 0x445566, 0.4);
            sepG.lineBetween(cl + 10, py, cr - 10, py);
            py += 5;
        }
        
        // ── Marks header ──
        bAdd(this.add.text(cl + 12, py, `MARKS  ${marks.length}/8`, {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: rHex, fontStyle: 'bold'
        }).setDepth(GD+1));
        py += 15;
        
        if (marks.length === 0) {
            bAdd(this.add.text(cl + 16, py, 'No marks yet', {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#667788'
            }).setDepth(GD+1));
        } else {
            // Sort marks: positive first, then mixed, then negative
            const sorted = [...marks].sort((a, b) => {
                const order = { positive: 0, mixed: 1, negative: 2 };
                return (order[a.type] || 1) - (order[b.type] || 1);
            });
            
            sorted.forEach((m) => {
                if (py > cb - 8) return; // use full card height
                
                const tCol = _tierCol[m.tier] || '#99aabb';
                
                // Mark icon + Name row
                const iconKey = SurvivorGenerator.generateMarkIcon(this, m.id);
                if (this.textures.exists(iconKey)) {
                    bAdd(this.add.image(cl + 18, py + 6, iconKey)
                        .setDisplaySize(12, 12).setDepth(GD+1));
                }
                bAdd(this.add.text(cl + 28, py, m.name, {
                    fontFamily: CONFIG.font, fontSize: uiPx(7), fill: tCol, fontStyle: 'bold'
                }).setDepth(GD+1));
                
                // Origin tag for earned/cube
                if (m.origin === 'earned') {
                    const tagX = cl + 28 + m.name.length * 5 + 6;
                    if (tagX < cr - 16) {
                        const tagLabel = m.tier === 'cube' ? 'CUBE' : 'EARNED';
                        const tagCol = m.tier === 'cube' ? '#aa66cc' : '#5599bb';
                        bAdd(this.add.text(tagX, py + 2, tagLabel, {
                            fontFamily: CONFIG.font, fontSize: uiPx(4), fill: tagCol
                        }).setDepth(GD+1));
                    }
                }
                py += 13;
                
                // Description
                if (m.desc && py < cb - 6) {
                    bAdd(this.add.text(cl + 28, py, m.desc, {
                        fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#8899aa',
                        wordWrap: { width: cardW - 42 }
                    }).setDepth(GD+1));
                    py += 12;
                }
            });
        }
        
        // ── Flip state (triggered by FLIP button, not tap) ──
        let flipping = false;
        const flipShell = [rarityBorder, cardBg, cg];
        this._flipCard = () => {
            if (flipping) return;
            flipping = true;
            AudioManager.uiClick();
            const allFlip = [...flipShell, ...this._survFront, ...this._survBack];
            this.tweens.add({
                targets: allFlip,
                scaleX: 0, duration: 120, ease: 'Sine.easeIn',
                onComplete: () => {
                    this._survFlipped = !this._survFlipped;
                    this._survFront.forEach(e => e.setVisible(!this._survFlipped));
                    this._survBack.forEach(e => e.setVisible(this._survFlipped));
                    const visFlip = [...flipShell, ...this._survFront.filter(e => e.visible), ...this._survBack.filter(e => e.visible)];
                    this.tweens.add({
                        targets: visFlip,
                        scaleX: 1, duration: 120, ease: 'Sine.easeOut',
                        onComplete: () => { flipping = false; }
                    });
                }
            });
        };
        
        // ══════════════════════════════════════
        // ACTION BUTTONS — bottom-right, stacked, pixel art nineslice
        // ══════════════════════════════════════
        const btnW = 80, btnH = 28, btnGap = 6;
        const btnX = W - btnW / 2 - 10;
        
        const makeBtn = (bx, by, label, style, onClick) => {
            const texKey = style === 'confirm' ? 'ui_btn_confirm' : 
                           style === 'danger' ? 'ui_btn_danger' : 'ui_btn';
            const pressKey = 'ui_btn_press';
            const textCol = style === 'confirm' ? '#66aa66' : 
                            style === 'danger' ? '#aa6666' : '#8888bb';
            
            // Nineslice bg — created directly (not in container) so scrollFactor works on hit area
            const bg = panelAdd(this.add.nineslice(bx, by, texKey, null, btnW, btnH, 6, 6, 4, 4)
                .setDepth(GD+3).setInteractive({ useHandCursor: true }));
            const txt = panelAdd(this.add.text(bx, by, label, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: textCol, fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(GD+4));
            
            bg.on('pointerdown', () => {
                bg.setTexture(pressKey);
                txt.y = by + 1;
                AudioManager.uiClick();
                Haptics.light();
                onClick();
            });
            bg.on('pointerup', () => { bg.setTexture(texKey); txt.y = by; });
            bg.on('pointerout', () => { bg.setTexture(texKey); txt.y = by; });
        };
        
        if (npc._selfView) {
            // Self-view: FLIP button only (tap outside to dismiss)
            const selfBtnBase = H - 1 * (btnH + btnGap) + btnH / 2 - 2;
            makeBtn(btnX, selfBtnBase, 'FLIP', 'normal', () => { this._flipCard(); });
            
            // Tap-away close (armed with delay so opening tap doesn't immediately dismiss)
            let selfViewArmed = false;
            this.time.delayedCall(200, () => { selfViewArmed = true; });
            this._survCloseListener = (p) => {
                if (!selfViewArmed) return;
                if (!this.popupActive || !this._survPanel) return;
                const px = p.x, ppy = p.y;
                const inCard = px >= cl-2 && px <= cr+2 && ppy >= ct-2 && ppy <= cb+2;
                const inBtn = px >= btnX - btnW/2 - 4 && px <= btnX + btnW/2 + 4 &&
                              ppy >= selfBtnBase - btnH/2 - 4 && ppy <= H;
                if (!inCard && !inBtn) this._closeSurvivorPanel();
            };
            this.input.on('pointerdown', this._survCloseListener);
        } else {
        // NPC: FLIP + TALK + EQUIP + SWITCH (4 buttons)
        const npcBtnBase = H - 4 * (btnH + btnGap) + btnH / 2 - 2;
        makeBtn(btnX, npcBtnBase, 'FLIP', 'normal', () => { this._flipCard(); });
        makeBtn(btnX, npcBtnBase + btnH + btnGap, 'TALK', 'normal', () => {
            const pId = surv.personality ? surv.personality.id : 'stoic';
            const pDef = SurvivorGenerator.PERSONALITIES.find(p => p.id === pId);
            const pool = (pDef && pDef.quips) ? [...pDef.quips] : [];
            const safePool = [...pool, 'This place could use some work.', 'You need something?', 'I\'ll be ready when you are.'];
            const q = safePool[Math.floor(Math.random() * safePool.length)];
            if (this._npcSpeechBubble) this._npcSpeechBubble.destroy();
            const bub = this.add.text(npc.sprite.x, npc.sprite.y - 32, `"${q}"`, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#ddddcc',
                fontStyle: 'italic', stroke: '#000000', strokeThickness: 2,
                wordWrap: { width: 120 }, align: 'center'
            }).setOrigin(0.5).setDepth(200);
            this._npcSpeechBubble = bub;
            this.tweens.add({ targets: bub, y: bub.y - 15, alpha: 0, duration: 3000, delay: 1500,
                onComplete: () => bub.destroy() });
        });
        
        makeBtn(btnX, npcBtnBase + 2 * (btnH + btnGap), 'EQUIP', 'normal', () => {
            this._closeSurvivorPanel();
            this._showSurvivorEquipment(surv);
        });
        
        makeBtn(btnX, npcBtnBase + 3 * (btnH + btnGap), 'SWITCH', 'confirm', () => {
            this._closeSurvivorPanel();
            this._switchToSurvivor(npc, surv);
        });
        
        // ── CLOSE on tap away from card/buttons ──
        this._survCloseListener = (p) => {
            if (!this.popupActive || !this._survPanel) return;
            const px = p.x, py = p.y;
            const inCard = px >= cl-2 && px <= cr+2 && py >= ct-2 && py <= cb+2;
            const inBtns = px >= btnX - btnW/2 - 4 && px <= btnX + btnW/2 + 4 &&
                           py >= npcBtnBase - btnH/2 - 4 && py <= npcBtnBase + 3*(btnH+btnGap) + btnH/2 + 4;
            if (!inCard && !inBtns) {
                this._closeSurvivorPanel();
            }
        };
        this.input.on('pointerdown', this._survCloseListener);
        } // end NPC buttons else
    }
    
    _showAchievementTooltip(def, ach, ax, ay, cardCenterX, cl, cr, GD) {
        // Remove existing tooltip
        if (this._achTooltip) { this._achTooltip.forEach(e => e.destroy()); this._achTooltip = null; }
        if (this._achTooltipTimer) { this._achTooltipTimer.remove(); this._achTooltipTimer = null; }
        const els = [];
        const ttW = 140, ttH = 52;
        let ttX = Math.max(cl + ttW/2 + 2, Math.min(ax, cr - ttW/2 - 2));
        const ttY = ay - ttH/2 - 4;
        
        const ttBg = this.add.rectangle(ttX, ttY, ttW, ttH, 0x0a0a18, 0.95)
            .setStrokeStyle(1, Phaser.Display.Color.HexStringToColor(def.color).color, 0.7)
            .setScrollFactor(0).setDepth(GD + 10).setInteractive();
        ttBg.on('pointerdown', () => {
            if (this._achTooltipTimer) { this._achTooltipTimer.remove(); this._achTooltipTimer = null; }
            if (this._achTooltip) { this._achTooltip.forEach(e => e.destroy()); this._achTooltip = null; }
        });
        els.push(ttBg);
        els.push(this.add.text(ttX, ttY - 16, def.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: def.color, fontStyle: 'bold'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(GD + 11));
        els.push(this.add.text(ttX, ttY - 4, def.desc, {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#8899aa',
            wordWrap: { width: ttW - 12 }, align: 'center'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(GD + 11));
        
        const progText = ach.complete ? 'COMPLETE' : `${ach.progress || 0} / ${def.target}`;
        const progCol = ach.complete ? '#44ff88' : '#889988';
        els.push(this.add.text(ttX, ttY + 8, progText, {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: progCol
        }).setOrigin(0.5).setScrollFactor(0).setDepth(GD + 11));
        
        const rParts = [];
        if (def.reward.xp) rParts.push(`+${def.reward.xp} XP`);
        if (def.reward.bits) rParts.push(`+${def.reward.bits} Bits`);
        if (def.reward.materials) rParts.push(`+${def.reward.materials} Mats`);
        if (rParts.length > 0) {
            els.push(this.add.text(ttX, ttY + 19, rParts.join('  '), {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#ccaa44'
            }).setOrigin(0.5).setScrollFactor(0).setDepth(GD + 11));
        }
        
        this._achTooltip = els;
        // Auto-dismiss after 3s
        this._achTooltipTimer = this.time.delayedCall(3000, () => {
            if (this._achTooltip) { this._achTooltip.forEach(e => e.destroy()); this._achTooltip = null; }
            this._achTooltipTimer = null;
        });
    }
    
    // ── Title/Aura Selection Popup ──
    _openTitleAuraSelector(surv, type, cardX, cardY, cardW, cardH, depth, npc) {
        // Close existing selector
        if (this._taSelector) { this._taSelector.forEach(e => { if (e && e.destroy) e.destroy(); }); this._taSelector = null; }
        AudioManager.uiClick();
        
        const isTitle = type === 'title';
        const items = isTitle
            ? (surv.unlockedTitles || []).map(t => ({ id: t, def: CONFIG.survivorTitles[t] || { name: t, color: '#8899aa', desc: '' } }))
            : (surv.unlockedAuras || []).map(a => ({ id: a, def: CONFIG.survivorAuras[a] || { name: a, color: null, desc: '' } }));
        
        const current = isTitle ? (surv.equippedTitle || null) : (surv.equippedAura || 'none');
        
        // Layout: centered popup overlaying the card
        const W = CONFIG.width, H = CONFIG.height;
        const popW = 180;
        const rowH = 34;
        const headerH = 28;
        const popH = Math.min(H - 40, headerH + items.length * rowH + (isTitle ? rowH : 0) + 10); // +1 for "None" option on titles
        const popX = cardX;
        const popY = cardY;
        const els = [];
        const D = depth;
        
        // Dimmed backdrop
        const backdrop = this.add.rectangle(W/2, H/2, W + 100, H + 100, 0x000000, 0.55)
            .setScrollFactor(0).setDepth(D).setInteractive();
        backdrop.on('pointerdown', () => this._closeTitleAuraSelector());
        els.push(backdrop);
        
        // Panel bg
        els.push(this.add.rectangle(popX, popY, popW, popH, 0x0a0a18, 0.97)
            .setScrollFactor(0).setDepth(D + 1));
        els.push(this.add.rectangle(popX, popY, popW, popH, 0x000000, 0)
            .setStrokeStyle(1, isTitle ? 0xddaa33 : 0x44aacc, 0.6)
            .setScrollFactor(0).setDepth(D + 1.5));
        
        // Header
        const headerY = popY - popH/2 + headerH/2 + 2;
        const headerColor = isTitle ? '#ddaa33' : '#44aacc';
        els.push(this.add.text(popX, headerY, isTitle ? 'EQUIP TITLE' : 'EQUIP AURA', {
            fontFamily: CONFIG.font,
            fontSize: uiPx(11), fill: headerColor, fontStyle: 'bold', letterSpacing: 3
        }).setOrigin(0.5).setScrollFactor(0).setDepth(D + 2));
        
        // Separator
        const sepG = this.add.graphics().setScrollFactor(0).setDepth(D + 2);
        sepG.lineStyle(1, isTitle ? 0xddaa33 : 0x44aacc, 0.3);
        sepG.lineBetween(popX - popW/2 + 10, headerY + 12, popX + popW/2 - 10, headerY + 12);
        els.push(sepG);
        
        // Build rows
        let rowY = headerY + 24;
        
        // "None" option for titles
        if (isTitle) {
            const isEquipped = current === null;
            this._addSelectorRow(els, popX, rowY, popW, 'None', 'No title equipped', isEquipped, isTitle ? '#8899aa' : '#8899aa', D, () => {
                surv.equippedTitle = null;
                SaveManager.save(this.saveData);
                this._closeTitleAuraSelector();
                this._refreshSurvivorCard(surv, npc);
            });
            rowY += rowH;
        }
        
        items.forEach(item => {
            if (isTitle && item.id === null) return; // skip null
            const isEquipped = isTitle ? (current === item.id) : (current === item.id);
            const color = isTitle
                ? (item.def.color || '#8899aa')
                : (item.def.color ? ('#' + item.def.color.toString(16).padStart(6, '0')) : '#8899aa');
            const name = item.def.name || item.id;
            const desc = item.def.desc || '';
            
            if (item.id === 'none' && !isTitle) {
                // "None" aura option
                this._addSelectorRow(els, popX, rowY, popW, 'None', 'No aura', isEquipped, '#8899aa', D, () => {
                    surv.equippedAura = 'none';
                    this._syncPlayerAura(surv);
                    SaveManager.save(this.saveData);
                    this._closeTitleAuraSelector();
                    this._refreshSurvivorCard(surv, npc);
                });
            } else {
                this._addSelectorRow(els, popX, rowY, popW, name, desc, isEquipped, color, D, () => {
                    if (isTitle) {
                        surv.equippedTitle = item.id;
                    } else {
                        surv.equippedAura = item.id;
                        this._syncPlayerAura(surv);
                    }
                    SaveManager.save(this.saveData);
                    this._closeTitleAuraSelector();
                    this._refreshSurvivorCard(surv, npc);
                });
            }
            rowY += rowH;
        });
        
        this._taSelector = els;
    }
    
    _addSelectorRow(els, cx, y, popW, name, desc, isEquipped, color, D, onSelect) {
        const rowW = popW - 16;
        const rowH = 30;
        
        // Row bg (highlight if equipped)
        const rowBg = this.add.rectangle(cx, y, rowW, rowH, isEquipped ? 0x1a2a1a : 0x0f0f1a, isEquipped ? 0.8 : 0.5)
            .setScrollFactor(0).setDepth(D + 2).setInteractive({ useHandCursor: true });
        if (isEquipped) {
            rowBg.setStrokeStyle(1, Phaser.Display.Color.HexStringToColor(color).color || 0x44aa44, 0.5);
        }
        els.push(rowBg);
        
        // Equipped indicator
        if (isEquipped) {
            els.push(this.add.text(cx - rowW/2 + 8, y, '\u2713', {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#44ff88', fontStyle: 'bold'
            }).setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 3));
        }
        
        // Name (use TitleFont for titles)
        const nameX = cx - rowW/2 + (isEquipped ? 22 : 8);
        const isTitle = name !== 'None' && CONFIG.survivorTitles && CONFIG.survivorTitles[name];
        if (isTitle) {
            try {
                TitleFont.build();
                els.push(TitleFont.drawInline(this, nameX, y - 4, name, {
                    maxWidth: rowW - 30, maxScale: 0.9, minScale: 0.5,
                    depth: D + 3
                }));
            } catch(e) {
                els.push(this.add.text(nameX, y - 4, name, {
                    fontFamily: CONFIG.font, fontSize: uiPx(9), fill: color, fontStyle: 'bold'
                }).setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 3));
            }
        } else {
            els.push(this.add.text(nameX, y - 4, name, {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: color, fontStyle: 'bold'
            }).setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 3));
        }
        
        // Description
        if (desc) {
            els.push(this.add.text(nameX, y + 8, desc, {
                fontFamily: CONFIG.font, fontSize: uiPx(5.5), fill: '#667788',
                wordWrap: { width: rowW - 30 }
            }).setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 3));
        }
        
        // Tap to select
        rowBg.on('pointerdown', () => {
            AudioManager.uiClick();
            onSelect();
        });
        rowBg.on('pointerover', () => { if (!isEquipped) rowBg.setFillStyle(0x1a1a2a, 0.7); });
        rowBg.on('pointerout', () => { if (!isEquipped) rowBg.setFillStyle(0x0f0f1a, 0.5); });
    }
    
    _closeTitleAuraSelector() {
        if (this._taSelector) {
            this._taSelector.forEach(e => { if (e && e.destroy) e.destroy(); });
            this._taSelector = null;
        }
    }
    
    _syncPlayerAura(surv) {
        if (!this.player) return;
        const auraId = surv.equippedAura || 'none';
        const auraDef = auraId !== 'none' ? CONFIG.survivorAuras[auraId] : null;
        const wantCrown = auraDef && auraDef.tier === 'mastery';
        
        if (wantCrown && !this.player._hasCrown) {
            const crown = CrownAura.createCrown(this, this.player);
            if (crown) {
                this.player._crownSprite = crown;
                this.player._hasCrown = true;
                CrownAura.updateCrown(this.player);
            }
        } else if (!wantCrown && this.player._hasCrown) {
            CrownAura.destroyCrown(this.player);
        }
    }
    
    _refreshSurvivorCard(surv, npc) {
        // Close and reopen the card to refresh display
        // Clear the panel elements but don't fully reset interaction state
        if (this._taSelector) { this._taSelector.forEach(e => { if (e && e.destroy) e.destroy(); }); this._taSelector = null; }
        if (this._achTooltipTimer) { this._achTooltipTimer.remove(); this._achTooltipTimer = null; }
        if (this._achTooltip) { this._achTooltip.forEach(e => e.destroy()); this._achTooltip = null; }
        if (this._survPanel) {
            this._survPanel.forEach(e => { if (e && e.destroy) e.destroy(); });
            this._survPanel = null;
        }
        this._survFront = null;
        this._survBack = null;
        this._survFlipped = false;
        this._flipCard = null;
        if (this._survCloseListener) {
            this.input.off('pointerdown', this._survCloseListener);
            this._survCloseListener = null;
        }
        // Re-open after a frame (keeps popupActive true, skips the guard)
        this.popupActive = false;
        this.time.delayedCall(50, () => {
            this.showSurvivorInteraction(npc);
        });
    }
    
    _closeSurvivorPanel() {
        if (this._taSelector) { this._taSelector.forEach(e => { if (e && e.destroy) e.destroy(); }); this._taSelector = null; }
        if (this._achTooltipTimer) { this._achTooltipTimer.remove(); this._achTooltipTimer = null; }
        if (this._achTooltip) { this._achTooltip.forEach(e => e.destroy()); this._achTooltip = null; }
        if (this._survPanel) {
            this._survPanel.forEach(e => { if (e && e.destroy) e.destroy(); });
            this._survPanel = null;
        }
        this._survFront = null;
        this._survBack = null;
        this._survFlipped = false;
        this._flipCard = null;
        if (this._npcSpeechBubble) { this._npcSpeechBubble.destroy(); this._npcSpeechBubble = null; }
        if (this._survCloseListener) {
            this.input.off('pointerdown', this._survCloseListener);
            this._survCloseListener = null;
        }
        // Resume interacting NPC
        if (this._interactingNPC && this._interactingNPC.state === 'interacting') {
            this._interactingNPC.state = 'idle';
            this._interactingNPC.stateTimer = Phaser.Math.Between(2000, 5000);
        }
        this._interactingNPC = null;
        this.popupActive = false;
        this.currentPopup = null;
        this._nearestNPC = null;
        InteractHighlight.hide(this);
    }
    
    _switchToSurvivor(npc, surv) {
        const survivors = this.saveData.survivors || [];
        survivors.forEach(s => s.deployed = false);
        surv.deployed = true;
        SaveManager.save(this.saveData);
        
        // Regenerate player sprite with new appearance
        const custom = SurvivorGenerator.toCustomization(surv);
        SpriteManager.playerSheetReady = false;
        SpriteManager.initPlayerSheet(null, custom);
        
        // Save positions before swap
        const playerOldX = this.player.x, playerOldY = this.player.y;
        const npcOldX = npc.x, npcOldY = npc.y;
        const oldSurvId = this._activeSurvivorId;
        
        // Update NPC to be the previously deployed survivor, at player's old spot
        const oldSurv = survivors.find(s => s.id === oldSurvId);
        if (oldSurv) {
            npc.surv = oldSurv;
            npc.x = playerOldX;
            npc.y = playerOldY;
            this._rebuildNPCSprite(npc);
            npc.state = 'idle';
            npc.stateTimer = 3000;
        }
        
        // Destroy old player, create new one at NPC's old position
        const oldPlayer = this.player;
        if (oldPlayer._crownSprite) { oldPlayer._crownSprite.destroy(); }
        if (oldPlayer.backpack) { oldPlayer.backpack.destroy(); }
        this.player = SpriteManager.createPlayerSpriteNoPhysics(this, npcOldX, npcOldY, null, surv.equippedAura);
        this.player.setDepth(10 + npcOldY * 0.01);
        this._activeSurvivorId = surv.id;
        this.cameras.main.startFollow(this.player, true, 0.12, 0.12);
        oldPlayer.destroy();
        DynamicShadows.add(this, this.player, { offsetY: 10, scale: 0.6, alpha: 0.15 });
        
        // Reset ALL interaction state to prevent stale debounces
        this._interactDebounce = false;
        this.nearestStation = null;
        this._nearestNPC = null;
        this.popupActive = false;
        this.currentPopup = null;
        this.inventoryUI = null;
        this.vehicleMenu = null;
        this.lootMenuOpen = false;
        InteractHighlight.hide(this);
        this.stations.forEach(s => { s._playerNear = false; });
        
        const rDef = SurvivorGenerator.RARITIES[surv.rarity];
        this.showNotificationToast({ text: `Now playing as ${surv.name}`, color: rDef.color });
        
        // Update top-right HUD to reflect new survivor
        if (this.hud && this.hud.updateSurvivor) this.hud.updateSurvivor(surv);
    }
    
    _showSurvivorEquipment(surv) {
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const eq = this.saveData.equipment || {};
        const rDef = SurvivorGenerator.RARITIES[surv.rarity];
        
        const panel = UIManager.createPanel(this, W/2, H/2, W - 20, H - 60, {
            title: `${surv.name} — LOADOUT`, accent: rDef.color, closable: true,
            onClose: () => { this.popupActive = false; }, depth: 200
        });
        this.currentPopup = panel;
        const cb = panel._contentBounds;
        
        // Shared equipment slots
        const slots = [
            { key: 'weapon', label: 'WEAPON' },
            { key: 'melee', label: 'MELEE' },
            { key: 'gear', label: 'ARMOR' },
            { key: 'consumable', label: 'CONSUMABLE' }
        ];
        
        let yOff = cb.y + 8;
        
        slots.forEach(slot => {
            const item = eq[slot.key];
            const rowH = item ? 58 : 36;
            
            // Slot row bg
            const rowBg = this.add.rectangle(0, yOff + rowH/2, cb.w, rowH, 0x0e0e18, 0.7);
            panel.add(rowBg);
            
            // Slot label
            panel.add(this.add.text(-cb.w/2 + 8, yOff + 4, slot.label, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#445566'
            }));
            
            if (item) {
                const color = ItemManager.getItemColor(item);
                const hex = '#' + color.toString(16).padStart(6, '0');
                
                // Colored left accent bar
                panel.add(this.add.rectangle(-cb.w/2 + 2, yOff + rowH/2, 3, rowH - 4, color, 0.6));
                
                // Item name
                panel.add(this.add.text(-cb.w/2 + 10, yOff + 16, item.name, {
                    fontFamily: CONFIG.font, fontSize: uiPx(10), fill: hex, fontStyle: 'bold'
                }));
                
                // Tier label + foundry
                let subLine = item.tierLabel || '';
                if (item.foundryId) {
                    const fDef = CONFIG.foundries[item.foundryId];
                    if (fDef) subLine += (subLine ? ' · ' : '') + fDef.name;
                }
                panel.add(this.add.text(-cb.w/2 + 10, yOff + 30, subLine, {
                    fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#556677'
                }));
                
                // Key stats (compact)
                const st = item.stats || {};
                const statParts = [];
                if (st.damage) statParts.push(`DMG ${st.damage}`);
                if (st.fireRate) statParts.push(`ROF ${st.fireRate}`);
                if (st.accuracy) statParts.push(`ACC ${st.accuracy}`);
                if (st.crit) statParts.push(`CRT ${st.crit}`);
                if (st.attackSpeed) statParts.push(`SPD ${st.attackSpeed}`);
                if (st.armor) statParts.push(`ARM ${st.armor}`);
                if (st.health) statParts.push(`HP +${st.health}`);
                if (st.moveSpeed) statParts.push(`MOV +${st.moveSpeed}`);
                if (st.dodge) statParts.push(`DDG +${st.dodge}`);
                
                if (statParts.length > 0) {
                    panel.add(this.add.text(-cb.w/2 + 10, yOff + 42, statParts.join('  '), {
                        fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#66778a'
                    }));
                }
                
                // Mods (right side, compact)
                if (item.mods && item.mods.length > 0) {
                    const modStr = item.mods.map(m => {
                        const dv = m.displayDiv ? (m.value / m.displayDiv).toFixed(1) : m.value;
                        return `+${dv}${m.unit || ''} ${m.name}`;
                    }).join(' · ');
                    panel.add(this.add.text(cb.w/2 - 8, yOff + 18, modStr, {
                        fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#6688aa',
                        wordWrap: { width: cb.w/2 - 10 }
                    }).setOrigin(1, 0));
                }
            } else {
                panel.add(this.add.text(-cb.w/2 + 10, yOff + 16, '[ Empty ]', {
                    fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#334455'
                }));
            }
            
            // Divider
            panel.add(this.add.rectangle(0, yOff + rowH, cb.w - 10, 1, 0x222233, 0.4));
            
            yOff += rowH + 4;
        });
        
        // Footer
        panel.add(this.add.text(0, yOff + 12, 'Equipment is shared across all survivors.\nManage loadout at the chest station.', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#445566', align: 'center'
        }).setOrigin(0.5));
    }
    
    _rebuildNPCSprite(npc) {
        const surv = npc.surv;
        const custom = SurvivorGenerator.toCustomization(surv);
        const sheetKey = 'npc_sheet_' + surv.id;
        
        const canvas = SpriteManager.generatePlayerSheet(custom);
        if (this.textures.exists(sheetKey)) this.textures.remove(sheetKey);
        this.textures.addSpriteSheet(sheetKey, canvas, { frameWidth: 48, frameHeight: 48 });
        
        const dirs = ['down','down_right','right','up_right','up','up_left','left','down_left'];
        dirs.forEach((dir, i) => {
            const animKey = `npc_walk_${surv.id}_${dir}`;
            if (this.anims.exists(animKey)) this.anims.remove(animKey);
            this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 6, repeat: -1 });
        });
        const idleKey = `npc_idle_${surv.id}`;
        if (this.anims.exists(idleKey)) this.anims.remove(idleKey);
        this.anims.create({ key: idleKey, frames: [{ key: sheetKey, frame: 0 }], frameRate: 1 });
        
        npc.sprite.setTexture(sheetKey, 0);
        npc.sprite.setDisplaySize(40, 40);
        npc.sprite.setPosition(npc.x, npc.y);
        npc.sheetKey = sheetKey;
        
        const rDef = SurvivorGenerator.RARITIES[surv.rarity];
        npc.nameTag.setText(surv.name);
        npc.nameTag.setStyle({ fill: rDef.textColor });
    }
    
    update(time, delta) {
        if (this.popupActive) {
            this._wasPopupActive = true;
            InteractHighlight.hide(this);
            return;
        }
        if (this._wasPopupActive) {
            this._wasPopupActive = false;
            if (this.player) { this.player.anims.stop(); this.player.isMoving = false; }
            this.moveDir = { x: 0, y: 0 };
            this.movePointer = null;
        }
        
        const dt = delta / 1000;
        
        // Keyboard input
        let vx = this.moveDir.x;
        let vy = this.moveDir.y;
        
        if (this.keys) {
            if (this.keys.a.isDown) vx -= 1;
            if (this.keys.d.isDown) vx += 1;
            if (this.keys.w.isDown) vy -= 1;
            if (this.keys.s.isDown) vy += 1;
        }
        
        // Normalize
        const len = Math.sqrt(vx * vx + vy * vy);
        if (len > 1) {
            vx /= len;
            vy /= len;
        }
        
        // Move player
        let newX = this.player.x + vx * this.playerSpeed * dt;
        let newY = this.player.y + vy * this.playerSpeed * dt;
        
        // Check collision with stations (current room only)
        const playerSize = 10;
        if (this.stationColliders) {
            for (const col of this.stationColliders) {
                if (col.roomId && col.roomId !== this.currentRoom) continue;
                if (newY + playerSize > col.y && newY - playerSize < col.y + col.height) {
                    if (this.player.x + playerSize <= col.x && newX + playerSize > col.x) {
                        newX = col.x - playerSize;
                    } else if (this.player.x - playerSize >= col.x + col.width && newX - playerSize < col.x + col.width) {
                        newX = col.x + col.width + playerSize;
                    }
                }
                if (newX + playerSize > col.x && newX - playerSize < col.x + col.width) {
                    if (this.player.y + playerSize <= col.y && newY + playerSize > col.y) {
                        newY = col.y - playerSize;
                    } else if (this.player.y - playerSize >= col.y + col.height && newY - playerSize < col.y + col.height) {
                        newY = col.y + col.height + playerSize;
                    }
                }
            }
        }
        
        // Check collision with wall segments (rooms have gaps at openings)
        if (this._wallColliders) {
            for (const wc of this._wallColliders) {
                if (newY + playerSize > wc.y && newY - playerSize < wc.y + wc.h) {
                    if (this.player.x + playerSize <= wc.x && newX + playerSize > wc.x) {
                        newX = wc.x - playerSize;
                    } else if (this.player.x - playerSize >= wc.x + wc.w && newX - playerSize < wc.x + wc.w) {
                        newX = wc.x + wc.w + playerSize;
                    }
                }
                if (newX + playerSize > wc.x && newX - playerSize < wc.x + wc.w) {
                    if (this.player.y + playerSize <= wc.y && newY + playerSize > wc.y) {
                        newY = wc.y - playerSize;
                    } else if (this.player.y - playerSize >= wc.y + wc.h && newY - playerSize < wc.y + wc.h) {
                        newY = wc.y + wc.h + playerSize;
                    }
                }
            }
        }
        
        // Clamp to walkable areas (rooms + corridors)
        const clamped = this.clampToWalkable(newX, newY);
        // If new position isn't walkable, try each axis independently
        if (clamped.x !== newX || clamped.y !== newY) {
            const tryX = this.clampToWalkable(newX, this.player.y);
            const tryY = this.clampToWalkable(this.player.x, newY);
            // Prefer whichever axis succeeded
            if (tryX.x === newX) {
                newX = tryX.x; newY = this.player.y;
            } else if (tryY.y === newY) {
                newX = this.player.x; newY = tryY.y;
            } else {
                newX = clamped.x; newY = clamped.y;
            }
        }
        
        this.player.x = newX;
        this.player.y = newY;
        
        // Snap to integer pixels when stationary
        if (Math.abs(vx) < 0.1 && Math.abs(vy) < 0.1) {
            this.player.x = Math.round(this.player.x);
            this.player.y = Math.round(this.player.y);
        }
        
        // Update player animation based on movement
        SpriteManager.updatePlayerAnimation(this.player, vx, vy, this);
        
        // Update player depth based on Y
        this.player.setDepth(10 + this.player.y * 0.01);
        
        // Gym blurb follows player
        
        // Check station proximity
        this.checkStations();
        
        // Update survivor NPCs (wandering, state machine)
        this._updateSurvivorNPCs(dt);
        
        // Check NPC interaction proximity (only if no station is highlighted)
        this.checkSurvivorProximity();
        
        // Detect room transitions (visibility)
        this.updateCurrentRoom();
        
        // Update dynamic shadows
        DynamicShadows.update(this);
        
        // Iso door proximity — open/close doors based on player distance
        this._updateIsoDoors();
        
        // Wall occlusion — fade south wall when player approaches (current room only)
        if (this._occlusionWalls && this.player) {
            const py = this.player.y;
            const px = this.player.x;
            this._occlusionWalls.forEach(ow => {
                const isRelevant = ow.roomId === this.currentRoom || ow.roomId === null;
                const inX = px > ow.left - 10 && px < ow.right + 10;
                let behindness = 0;
                if (isRelevant && ow.facing === 'south') {
                    if (inX && py < ow.groundY && py > ow.visualTop - 20) {
                        const dist = ow.groundY - py;
                        const wallH = ow.groundY - ow.visualTop;
                        behindness = Math.min(1, dist / Math.max(1, wallH));
                    }
                }
                const targetAlpha = behindness > 0.15 ? Math.max(0.2, 1 - behindness * 0.7) : 1.0;
                ow.parts.forEach(p => {
                    p.alpha += (targetAlpha - p.alpha) * 0.18;
                });
            });
        }
    }
    
    // Animate iso doors open/closed based on player proximity
    _updateIsoDoors() {
        if (!this._isoDoors || !this.player) return;
        const px = this.player.x, py = this.player.y;
        const OPEN_DIST = 40;
        const CLOSE_DIST = 60;
        
        for (const door of this._isoDoors) {
            const dist = Math.sqrt((px - door.cx) ** 2 + (py - door.cy) ** 2);
            const shouldOpen = dist < OPEN_DIST;
            const shouldClose = dist > CLOSE_DIST;
            const prop = door.axis; // 'scaleX' or 'scaleY'
            
            if (shouldOpen && !door.isOpen && !door.isAnimating) {
                door.isOpen = true;
                door.isAnimating = true;
                
                // Reveal adjacent room when door opens (so floor is visible through gap)
                const adjRoom = (door.sourceRoom === this.currentRoom) ? door.targetRoom : door.sourceRoom;
                this.revealRoom(adjRoom);
                
                // Indicator light → green
                if (door.indicator) {
                    door.indicator.setFillStyle(0x22cc44);
                }
                
                // closedFace shrinks (door turning away from closed position)
                const closedTween = {};
                closedTween[prop] = 0.08;
                this.tweens.add({
                    targets: door.closedFace,
                    ...closedTween,
                    duration: 220,
                    ease: 'Power2'
                });
                // openFace appears (front face becoming visible as door swings)
                this.tweens.add({
                    targets: door.openFace,
                    alpha: 1,
                    duration: 220,
                    ease: 'Power2',
                    onComplete: () => { door.isAnimating = false; }
                });
                
            } else if (shouldClose && door.isOpen && !door.isAnimating) {
                door.isOpen = false;
                door.isAnimating = true;
                
                // Indicator light → red
                if (door.indicator) {
                    door.indicator.setFillStyle(0xcc2222);
                }
                
                // closedFace returns to full (door closing back flush with wall)
                const closedTween = {};
                closedTween[prop] = 1;
                this.tweens.add({
                    targets: door.closedFace,
                    ...closedTween,
                    duration: 280,
                    ease: 'Back.easeOut'
                });
                // openFace fades (front face no longer visible)
                this.tweens.add({
                    targets: door.openFace,
                    alpha: 0,
                    duration: 200,
                    ease: 'Power2',
                    onComplete: () => { door.isAnimating = false; }
                });
            }
        }
    }
    
    checkStations() {
        let nearest = null;
        let nearestDist = Infinity;
        
        this.stations.forEach(station => {
            if (!station.config) return;
            if (station._roomId && station._roomId !== this.currentRoom) return;
            const cx = station.config.x;
            const cy = station.config.y;
            const dist = Phaser.Math.Distance.Between(
                this.player.x, this.player.y, cx, cy
            );
            
            if (dist < 60 && dist < nearestDist) {
                nearest = station;
                nearestDist = dist;
            }
            
            // Per-station proximity callbacks
            const wasNear = station._playerNear || false;
            const isNear = dist < 60 && station._roomId === this.currentRoom;
            if (isNear && !wasNear && station._onApproach) station._onApproach(this);
            if (!isNear && wasNear && station._onLeave) station._onLeave(this);
            station._playerNear = isNear;
        });
        
        this.nearestStation = nearest;
        
        // Hide highlight when a popup is open
        if (this.popupActive) {
            InteractHighlight.hide(this);
            return;
        }
        
        if (nearest) {
            InteractHighlight.show(this, nearest, nearest.config.label || nearest.config.id.toUpperCase(), { padding: 6 });
        } else {
            InteractHighlight.hide(this);
        }
    }
    
    startRun() {
        // Guard: must have a locked route
        if (!this.saveData.activeRoute || this.saveData.activeRoute.status !== 'locked') {
            return;
        }
        
        // Stop idle rumble if running
        this._stopVehicleRumble();
        
        // Mark route as active
        this.saveData.activeRoute.status = 'active';
        SaveManager.save(this.saveData);
        
        // Get deployed survivor
        const survId = this._selectedSurvivorId;
        const survivors = this.saveData.survivors || [];
        const deploySurv = survivors.find(s => s.id === survId) || survivors.find(s => s.alive) || null;
        
        if (deploySurv) {
            // Mark deployed
            survivors.forEach(s => s.deployed = false);
            deploySurv.deployed = true;
            this.saveData.survivors = survivors;
            
            // Reset per-run mark flags
            SurvivorGenerator.resetMarkFlags(deploySurv);
            SaveManager.save(this.saveData);
            
            // Apply survivor appearance to player sprite system
            const custom = SurvivorGenerator.toCustomization(deploySurv);
            SpriteManager.playerSheetReady = false;
            SpriteManager.initPlayerSheet(null, custom);
        }
        
        // ── Compute survivor modifiers from marks + rank + injury ──
        let survivorMods = null;
        const convoyPassives = SurvivorGenerator.getConvoyPassives(this.saveData);
        if (deploySurv) {
            const me = SurvivorGenerator.getMarkEffects(deploySurv);
            const rb = SurvivorGenerator.getRankBonus(deploySurv);
            const ip = SurvivorGenerator.getInjuryPenalties(deploySurv);
            survivorMods = {
                statMultiplier: (me.statMultiplier) * (rb.statMultiplier || 1) * (ip.statMultiplier),
                speedMultiplier: me.speedMultiplier,
                hpMultiplier: (me.hpMultiplier) * (ip.hpMultiplier),
                damageResist: (me.damageResist) + (rb.damageResist || 0),
                elementalResist: me.elementalResist,
                weaponSpread: me.weaponSpread,
                backpackBonus: me.backpackBonus,
                fuelCostMultiplier: me.fuelCostMultiplier * (1 - convoyPassives.fuelDiscount),
                materialsBonus: me.materialsBonus + convoyPassives.lootBonus,
                reloadSpeed: me.reloadSpeed,
                consumableEffectiveness: me.consumableEffectiveness,
                healingEffectiveness: me.healingEffectiveness,
                immunities: me.immunities,
                conditionals: me.conditionals,
                marksActive: ip.marksActive
            };
        }
        
        // Propagate loot quality bonus to global CONFIG for item generation
        CONFIG._activeLootQualityBonus = survivorMods?.conditionals?.lootQualityBonus || 0;
        
        // Store deployed survivor for scene passing
        this._deployedSurvivor = deploySurv;
        
        // Prepare run loadout from stash
        AudioManager.engineStart();
        Haptics.medium();
        const eq = this.saveData.equipment || {};
        
        // Calculate vehicle mod bonuses
        const vMods = this.saveData.vehicle?.mods || {};
        const armorMod = vMods.armor >= 0 ? CONFIG.vehicleMods.armor.tiers[vMods.armor] : null;
        const fuelMod = vMods.fuel >= 0 ? CONFIG.vehicleMods.fuel.tiers[vMods.fuel] : null;
        const maxFuel = 100 + (fuelMod ? fuelMod.stats.fuelCapacity : 0);
        const baseVehicleHP = 100 + (armorMod ? armorMod.stats.vehicleHP : 0);
        
        // Calculate starting HP: base player HP + gear health + survivor mods
        const eqForHP = { weapon: eq.weapon || null, melee: eq.melee || null, gear: eq.gear || null, consumable: null };
        const startEqStats = ItemManager.getEquipmentStats(eqForHP);
        const baseHP = CONFIG.player.health + (startEqStats.maxHealth || 0);
        const startHP = survivorMods ? Math.round(baseHP * survivorMods.hpMultiplier) : baseHP;
        
        const runState = {
            health: startHP,
            powerAmmo: Math.min(30, this.saveData.stash.powerAmmo),
            fuel: Math.min(maxFuel, this.saveData.stash.fuel),
            bits: 0,
            materials: 0,
            kills: 0,
            vehicleHealth: baseVehicleHP,
            backpack: ItemManager.createInventory(
                (eq.gear && eq.gear.stats && eq.gear.stats.backpack) ? eq.gear.stats.backpack : CONFIG.inventory.backpackSlots
            ),
            vehicle: (this.runState && this.runState.vehicle) ? this.runState.vehicle : ItemManager.createInventory(CONFIG.inventory.vehicleSlots),
            equipment: {
                weapon: eq.weapon || null,
                melee: eq.melee || null,
                gear: eq.gear || null,
                consumable: eq.consumable || null
            }
        };
        
        // Extend backpack based on gear carryCapacity mod
        const ccStats = ItemManager.getEquipmentStats(runState.equipment);
        if (ccStats.carryCapacity > 0) {
            for (let i = 0; i < ccStats.carryCapacity; i++) runState.backpack.push(null);
        }
        // Extend backpack from survivor mark bonus
        if (survivorMods && survivorMods.backpackBonus > 0) {
            for (let i = 0; i < survivorMods.backpackBonus; i++) runState.backpack.push(null);
        }
        
        // Store survivor modifiers on run state — read by combat, movement, damage systems
        runState.survivorMods = survivorMods;
        
        // Deduct from stash
        this.saveData.stash.powerAmmo -= runState.powerAmmo;
        this.saveData.stash.fuel -= runState.fuel;
        this.saveSaveData();
        
        // Store for transition
        this._pendingRunState = runState;
        
        // Play garage door opening + vehicle driveout
        this.playGarageDepartAnimation();
    }
    
    playGarageDepartAnimation() {
        // Disable interaction
        this.popupActive = true;
        const gar = this.ROOMS.garage;
        const WC = this._wallConst;
        const vx = this.vehicleStation ? this.vehicleStation.x : gar.x + gar.w/2;
        const vy = this.vehicleStation ? this.vehicleStation.y : gar.y + gar.h/2;
        
        // Step 1: Player walks to vehicle
        this.tweens.add({
            targets: this.player,
            x: vx,
            y: vy,
            duration: 500,
            ease: 'Sine.easeInOut',
            onComplete: () => {
                this.player.setVisible(false);
                this.time.delayedCall(300, () => {
                    this.startVehicleDeparture();
                });
            }
        });
    }
    
    startVehicleDeparture() {
        if (!this.vehicleStation) {
            this.completeDeparture();
            return;
        }
        
        const gar = this.ROOMS.garage;
        const WC = this._wallConst;
        const vehicle = this.vehicleStation;
        const tod = CONFIG.timeOfDay || 'midday';
        
        // ─── USE SPLIT RETRACTABLE EAST WALL ───
        const doorX = this._garageDoorX || (gar.x + gar.w - WC.sideW/2);
        const doorMidY = this._garageDoorMidY || (gar.y + gar.h/2);
        const northDoor = this._garageDoorNorth;
        const southDoor = this._garageDoorSouth;
        
        // Light shaft from east (outside light spilling in)
        const lightColors = {
            dawn: { col: 0xffddaa, alpha: 0.08 },
            midday: { col: 0xffffdd, alpha: 0.06 },
            dusk: { col: 0xffaa66, alpha: 0.10 },
            night: { col: 0x8888cc, alpha: 0.02 }
        };
        const lc = lightColors[tod] || lightColors.midday;
        
        const lightShaft = this.add.graphics().setDepth(2.5).setAlpha(0);
        const shaftSpread = 50;
        lightShaft.fillStyle(lc.col, lc.alpha);
        lightShaft.fillTriangle(
            doorX, doorMidY - shaftSpread,
            doorX, doorMidY + shaftSpread,
            doorX - 80, doorMidY
        );
        lightShaft.fillStyle(lc.col, lc.alpha * 2);
        lightShaft.fillTriangle(
            doorX, doorMidY - shaftSpread / 2,
            doorX, doorMidY + shaftSpread / 2,
            doorX - 40, doorMidY
        );
        
        // Engine rumble
        this.tweens.add({
            targets: vehicle,
            y: vehicle.y + 1,
            duration: 40, yoyo: true, repeat: 8, ease: 'Sine.inOut'
        });
        
        // Exhaust puffs (west of vehicle — it'll drive east)
        for (let p = 0; p < 5; p++) {
            this.time.delayedCall(p * 120, () => {
                if (!vehicle.active) return;
                const puff = this.add.circle(
                    vehicle.x - 20 - Math.random() * 10,
                    vehicle.y + Phaser.Math.Between(-4, 4),
                    3 + Math.random() * 4, 0x888888, 0.5
                ).setDepth(9.9);
                this.tweens.add({
                    targets: puff,
                    x: puff.x - 15, alpha: 0, scaleX: 2, scaleY: 2,
                    duration: 500, onComplete: () => puff.destroy()
                });
            });
        }
        
        // Doors collapse in place after 400ms — each half shrinks via scaleY
        this.time.delayedCall(400, () => {
            if (northDoor) {
                this.tweens.add({
                    targets: northDoor,
                    scaleY: 0.02,
                    duration: 1200,
                    ease: 'Power2.easeInOut'
                });
            }
            if (southDoor) {
                this.tweens.add({
                    targets: southDoor,
                    scaleY: 0.02,
                    duration: 1200,
                    ease: 'Power2.easeInOut'
                });
            }
            this.tweens.add({ targets: lightShaft, alpha: 1, duration: 1400, ease: 'Sine.easeIn' });
        });
        
        // Vehicle drives east after doors open
        this.time.delayedCall(1800, () => {
            // Start at interior depth (above garage props)
            vehicle.setDepth(10);
            
            // Exhaust burst
            for (let p = 0; p < 8; p++) {
                this.time.delayedCall(p * 80, () => {
                    if (!vehicle.active) return;
                    const puff = this.add.circle(
                        vehicle.x - 15,
                        vehicle.y + Phaser.Math.Between(-3, 3),
                        2 + Math.random() * 5, 0x666666, 0.6
                    ).setDepth(vehicle.depth - 0.01);
                    this.tweens.add({
                        targets: puff,
                        x: puff.x - 25, alpha: 0, scaleX: 2, scaleY: 1.5,
                        duration: 600, onComplete: () => puff.destroy()
                    });
                });
            }
            
            // Raise building shell smoothly for overhead perspective
            if (this._roofElements) {
                this._roofElements.forEach(el => {
                    if (!el || !el.setDepth) return;
                    const origAlpha = el.alpha;
                    el.setDepth(11);
                    el.setAlpha(0);
                    this.tweens.add({ targets: el, alpha: origAlpha, duration: 600, ease: 'Sine.easeIn' });
                });
            }
            
            // Drive straight east
            const exitX = gar.x + gar.w + 400;
            this.tweens.add({
                targets: vehicle,
                x: exitX,
                duration: 1500,
                ease: 'Quad.easeIn'
            });
            
            // === CINEMATIC: CONTINUOUS RISE + CLOUD COVER (no visible stop) ===
            const cam = this.cameras.main;
            cam.stopFollow();
            
            // Track overlay layers to counter-scale against zoom
            const overlayLayers = [];
            
            // Zoom out the ENTIRE duration — never stops moving
            this.tweens.add({
                targets: cam,
                zoom: 0.4,
                duration: 4000,
                ease: 'Sine.easeIn',
                onUpdate: () => {
                    // Counter-scale overlay layers so they stay screen-size
                    const invZoom = 1 / cam.zoom;
                    overlayLayers.forEach(layer => {
                        if (layer && layer.active) layer.setScale(invZoom);
                    });
                }
            });
            
            // Clouds start early — rolling in WHILE camera still pulling back
            this.time.delayedCall(400, () => {
                const cW = CONFIG.width, cH = CONFIG.height;
                
                // === LIGHT FOG (depth 498 — haze building before clouds) ===
                const fogLayer = this.add.container(cW / 2, cH / 2).setScrollFactor(0).setDepth(498).setAlpha(0);
                for (let f = 0; f < 8; f++) {
                    fogLayer.add(this.add.rectangle(
                        (Math.random() - 0.5) * cW * 0.4,
                        (Math.random() - 0.5) * cH * 0.4,
                        cW * 0.8, cH * 0.5,
                        0xcccccc, 0.06 + Math.random() * 0.05
                    ));
                }
                this.tweens.add({ targets: fogLayer, alpha: 1, duration: 2500, ease: 'Sine.easeIn' });
                overlayLayers.push(fogLayer);
                
                // === CLOUD BUILDER — big, soft, white/gray only ===
                const buildCloud = (scene, w, h) => {
                    const c = scene.add.container(0, 0);
                    
                    // Broad atmospheric base
                    c.add(scene.add.ellipse(0, 0, w * 1.3, h * 1.5, 0xd0d0d0, 0.15));
                    
                    // Main mass — 3-4 large overlapping ellipses
                    const offsets = [
                        { x: -w * 0.15, y: -h * 0.05, sw: 0.7, sh: 0.8 },
                        { x: w * 0.1, y: 0, sw: 0.8, sh: 0.7 },
                        { x: -w * 0.05, y: h * 0.05, sw: 0.9, sh: 0.65 },
                        { x: w * 0.2, y: -h * 0.08, sw: 0.5, sh: 0.6 },
                    ];
                    offsets.forEach(o => {
                        c.add(scene.add.ellipse(o.x, o.y, w * o.sw, h * o.sh, 0xcccccc, 0.45));
                    });
                    
                    // Bright core
                    c.add(scene.add.ellipse(0, -h * 0.05, w * 0.5, h * 0.4, 0xdddddd, 0.5));
                    
                    // Top highlights
                    c.add(scene.add.ellipse(-w * 0.1, -h * 0.2, w * 0.4, h * 0.2, 0xe8e8e8, 0.35));
                    c.add(scene.add.ellipse(w * 0.15, -h * 0.18, w * 0.3, h * 0.15, 0xeeeeee, 0.3));
                    
                    // Underbelly shadow
                    c.add(scene.add.ellipse(0, h * 0.15, w * 0.7, h * 0.25, 0x999999, 0.2));
                    
                    return c;
                };
                
                // === FOUR BANKS — massive clouds from each edge ===
                const cloudLayer = this.add.container(cW / 2, cH / 2).setScrollFactor(0).setDepth(500);
                overlayLayers.push(cloudLayer);
                
                // Each bank: 3 huge clouds that together cover a quarter of the screen
                // Positions relative to container center (0,0 = screen center)
                const banks = [
                    { sx: 0, sy: -cH * 0.9, tx: 0, ty: -cH * 0.3 },
                    { sx: 0, sy: cH * 0.9, tx: 0, ty: cH * 0.3 },
                    { sx: -cW * 0.9, sy: 0, tx: -cW * 0.3, ty: 0 },
                    { sx: cW * 0.9, sy: 0, tx: cW * 0.3, ty: 0 },
                ];
                
                banks.forEach((bank, bi) => {
                    for (let i = 0; i < 3; i++) {
                        const spread = (i - 1) * (bi < 2 ? cW * 0.35 : cH * 0.3);
                        const sx = bank.sx + (bi < 2 ? spread : 0);
                        const sy = bank.sy + (bi >= 2 ? spread : 0);
                        const tx = bank.tx + (bi < 2 ? spread * 0.4 : 0);
                        const ty = bank.ty + (bi >= 2 ? spread * 0.4 : 0);
                        
                        // Big clouds — 250-400px wide, 120-200px tall
                        const cw = 250 + Math.random() * 150;
                        const ch = 120 + Math.random() * 80;
                        const cloud = buildCloud(this, cw, ch);
                        cloud.setPosition(sx, sy);
                        cloud.setAlpha(0);
                        cloudLayer.add(cloud);
                        
                        this.tweens.add({
                            targets: cloud,
                            x: tx, y: ty,
                            alpha: 1,
                            duration: 2200 + Math.random() * 500,
                            delay: bi * 100 + i * 120,
                            ease: 'Sine.easeOut'
                        });
                    }
                });
                
                // White-out builds underneath
                const whiteout = this.add.rectangle(cW / 2, cH / 2, cW + 200, cH + 200,
                    0xcccccc, 0
                ).setScrollFactor(0).setDepth(499);
                overlayLayers.push(whiteout);
                
                this.tweens.add({
                    targets: whiteout,
                    alpha: 1,
                    duration: 2200,
                    delay: 1000,
                    ease: 'Sine.easeIn',
                    onComplete: () => {
                        this.completeDeparture(true);
                    }
                });
            });
        });
    }
    
    completeDeparture(withClouds) {
        const ar = this.saveData.activeRoute;
        this.scene.start('MapScene', {
            playerState: this._pendingRunState,
            currentNodeId: ar ? ar.nodes[0] : 'safehouse',
            mapSeed: ar ? ar.seed : Date.now(),
            completedNodes: [],
            traveledRoutes: [],
            fromSafehouse: true,
            cloudTransition: !!withClouds,
            activeRoute: ar || null,
            deployedSurvivor: this._deployedSurvivor || null
        });
    }
    
    
    showStash() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panel = UIManager.createPanel(this, W/2, H/2, 220, 160, {
            title: 'STASH', accent: 'barter', closable: true,
            onClose: () => { this.popupActive = false; }, depth: 200
        });
        this.currentPopup = panel;
        const cb = panel._contentBounds;
        const options = [
            { label: 'CURRENCIES', desc: 'View your resources', icon: '', action: () => { panel.destroy(); this.popupActive = false; this.showCurrencies(); } },
            { label: 'STASH', desc: 'Browse stored items', icon: 'BOX', action: () => { panel.destroy(); this.popupActive = false; this.showStashInventory(); } }
        ];
        options.forEach((opt, i) => {
            const ry = cb.y + 14 + i * 50;
            const row = this.add.container(0, ry).setDepth(201);
            const bg = this.add.rectangle(0, 0, cb.w, 42, 0x0c0c18, 0.6);
            row.add(bg);
            row.add(this.add.text(-cb.w/2 + 8, -8, `${opt.icon}  ${opt.label}`, { fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#aab0cc', fontStyle: 'bold' }));
            row.add(this.add.text(-cb.w/2 + 8, 7, opt.desc, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#556655' }));
            row.add(this.add.text(cb.w/2 - 8, 0, '>', { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#555544' }).setOrigin(0.5));
            bg.setInteractive({ useHandCursor: true })
                .on('pointerover', () => bg.setFillStyle(0x14141e))
                .on('pointerout', () => bg.setFillStyle(0x0c0c18))
                .on('pointerdown', opt.action);
            panel.add(row);
        });
    }

    
    showLoadout() {
        if (this.popupActive) return;
        this.popupActive = true;
        this.inventoryUI = new InventoryUI(
            this,
            this.saveData.stash.inventory,
            this.saveData.equipment,
            () => {
                this.inventoryUI = null;
                this.popupActive = false;
                this.saveSaveData();
                this.refreshLoadoutRack();
            }
        );
    }
    
    showCurrencies() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panel = UIManager.createPanel(this, W/2, H/2, 240, 350, {
            title: 'CURRENCIES', accent: 'barter', closable: true,
            onClose: () => { this.popupActive = false; this.showStash(); }, depth: 200
        });
        this.currentPopup = panel;
        const cb = panel._contentBounds;
        const stash = this.saveData.stash;
        const stats = this.saveData.stats || {};
        const currencies = [
            { atlasIcon: 'ui_icon_bits', name: 'BITS', value: stash.bits || 0, color: '#ffcc44', desc: 'Primary currency. Earned from runs.' },
            { atlasIcon: 'ui_icon_ammo', name: 'PWR AMMO', value: stash.powerAmmo || 0, color: '#cc88ff', desc: 'Power ammunition. Limited reserve.' },
            { atlasIcon: 'ui_icon_fuel', name: 'FUEL', value: stash.fuel || 0, color: '#66aa44', desc: 'Vehicle fuel. Required for runs.' },
            { atlasIcon: 'ui_icon_materials', name: 'MATERIALS', value: stash.materials || 0, color: '#aa8866', desc: 'Salvaged materials for crafting.' }
        ];
        let yOff = cb.y + 10;
        currencies.forEach(cur => {
            const row = this.add.container(0, yOff + 18).setDepth(201);
            row.add(this.add.rectangle(0, 0, cb.w, 48, 0x0c0c18, 0.4));
            // Atlas icon + name
            if (this.textures.exists(cur.atlasIcon)) {
                row.add(this.add.image(-cb.w/2 + 14, -12, cur.atlasIcon));
                row.add(this.add.text(-cb.w/2 + 26, -12, cur.name, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: cur.color, fontStyle: 'bold' }).setOrigin(0, 0.5));
            } else {
                row.add(this.add.text(-cb.w/2 + 8, -12, cur.name, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: cur.color, fontStyle: 'bold' }));
            }
            row.add(this.add.text(cb.w/2 - 8, -12, `${cur.value}`, { fontFamily: CONFIG.font, fontSize: uiPx(14), fill: cur.color, fontStyle: 'bold' }).setOrigin(1, 0));
            row.add(this.add.text(-cb.w/2 + 8, 6, cur.desc, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#555544', wordWrap: { width: cb.w - 20 } }));
            panel.add(row);
            yOff += 54;
        });
        yOff += 12;
        panel.add(UIManager.createDivider(this, 0, yOff, cb.w - 20, { depth: 201 }));
        yOff += 14;
        panel.add(this.add.text(0, yOff, 'LIFETIME', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#555544' }).setOrigin(0.5));
        yOff += 14;
        panel.add(this.add.text(-cb.w/2 + 8, yOff, 'Bits Earned', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#666655' }));
        panel.add(this.add.text(cb.w/2 - 8, yOff, `${stats.bitsEarned || 0}`, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#999966' }).setOrigin(1, 0));
        yOff += 12;
        panel.add(this.add.text(-cb.w/2 + 8, yOff, 'Bits Spent', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#666655' }));
        panel.add(this.add.text(cb.w/2 - 8, yOff, `${stats.bitsSpent || 0}`, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#996655' }).setOrigin(1, 0));
    }

    
    showStashInventory() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panel = UIManager.createPanel(this, W/2, H/2, W - 24, H - 50, {
            title: 'STASH INVENTORY', accent: 'stash', closable: true,
            onClose: () => { this.popupActive = false; this.showStash(); }, depth: 200
        });
        this.currentPopup = panel;
        const cb = panel._contentBounds;
        const inv = this.saveData.stash.inventory;
        const filledCount = inv.filter(i => i !== null).length;
        panel.add(this.add.text(0, cb.y, `${filledCount} / ${inv.length} slots used`, { fontFamily: 'Share Tech Mono, monospace', fontSize: uiPx(8), fill: '#666' }).setOrigin(0.5));
        const cols = 4, cellSize = 52, gridW = cols * cellSize;
        const gridStartX = -gridW/2, gridStartY = cb.y + 14;
        inv.forEach((item, i) => {
            const col = i % cols, row = Math.floor(i / cols);
            const slotX = gridStartX + col * cellSize + cellSize/2;
            const slotY = gridStartY + row * cellSize + cellSize/2;
            const slotItem = item ? { id: item.id, rarity: (CONFIG.tiers && CONFIG.tiers[item.tier] ? CONFIG.tiers[item.tier].label.toLowerCase() : 'common'), icon: item.icon, tier: item.tier } : null;
            const slot = UIManager.createItemSlot(this, slotX, slotY, slotItem, {
                depth: 201, onClick: item ? () => this.showStashItemCard(item, i, panel) : null
            });
            panel.add(slot);
        });
    }

    
    showStashItemCard(item, index, parentPopup) {
        const color = ItemManager.getItemColor(item);
        const hex = '#' + color.toString(16).padStart(6, '0');
        const modCount = (item.mods && item.mods.length) || 0;
        const cardH = Math.max(140, 100 + modCount * 14 + 50);
        const det = UIManager.createPanel(this, CONFIG.width/2, CONFIG.height/2 - 20, 220, cardH, {
            title: `${item.icon} ${item.name}`, accent: color, closable: true,
            onClose: () => {}, depth: 210, modal: true
        });
        const cb = det._contentBounds;
        const tierLabel = item.tierLabel || (CONFIG.tiers && CONFIG.tiers[item.tier] ? CONFIG.tiers[item.tier].label : 'Common');
        det.add(this.add.text(0, cb.y + 4, tierLabel, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: hex }).setOrigin(0.5));
        let my = cb.y + 20;
        if (item.mods && item.mods.length > 0) {
            item.mods.forEach(mod => {
                const mdv = mod.displayDiv ? (mod.value / mod.displayDiv).toFixed(1) : mod.value;
                det.add(this.add.text(-cb.w/2 + 4, my, `+ ${mod.name}: +${mdv}${mod.unit || ''}`, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#88aa88' }));
                my += 14;
            });
        }
        det.add(this.add.text(0, my + 4, `${(item.category || 'misc').toUpperCase()} - ${(item.slot || item.type || '?').toUpperCase()}`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#555555' }).setOrigin(0.5));
        const discBtn = UIManager.createButton(this, 0, cb.y + cb.h - 14, 'DISCARD', {
            width: 90, height: 22, style: 'danger', fontSize: uiPx(9), depth: 211,
            onClick: () => {
                this.saveData.stash.inventory[index] = null;
                this.saveSaveData();
                det.destroy();
                if (parentPopup && parentPopup.active !== false) { parentPopup.destroy(); }
                this.popupActive = false;
                this.showStashInventory();
            }
        });
        det.add(discBtn);
    }
    

    
    showPlaceholder(title, message) {
        if (this.currentPopup) this.currentPopup.destroy();
        this.popupActive = true;
        const panel = UIManager.createPanel(this, CONFIG.width/2, CONFIG.height/2, 240, 160, {
            title: title, accent: 'default', closable: true,
            onClose: () => { this.popupActive = false; }, depth: 200, modal: true
        });
        this.currentPopup = panel;
        const cb = panel._contentBounds;
        panel.add(this.add.text(0, 0, message, { fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#666', align: 'center', wordWrap: { width: 200 } }).setOrigin(0.5));
    }

    
    showCustomizeSafehouse() {
        if (this.popupActive) return;
        this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const panelW = 280, panelH = 300;
        const panel = UIManager.createPanel(this, W/2, H/2, panelW, panelH, {
            title: 'CUSTOMIZE SAFEHOUSE', accent: 0x886644, closable: true,
            onClose: () => { this.popupActive = false; }, depth: 200
        });
        this.currentPopup = panel;
        const cb = panel._contentBounds;
        if (!this.saveData.safehouse) this.saveData.safehouse = {};
        const sh = this.saveData.safehouse;
        if (!sh.floor) sh.floor = 'concrete';
        if (!sh.wall) sh.wall = 'default';
        if (!sh.props) sh.props = [];
        const matCount = this.saveData.stash.materials || 0;
        panel.add(this.add.text(cb.x + cb.w, cb.y - 8, `${matCount}`, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aa8866' }).setOrigin(1, 0));
        let currentTab = 'floors';
        const tabs = [{ id: 'floors', label: 'FLOORS' }, { id: 'walls', label: 'WALLS' }, { id: 'layout', label: 'LAYOUT' }, { id: 'props', label: 'PROPS' }];
        const contentContainer = this.add.container(0, 20);
        panel.add(contentContainer);
        const tabBtns = [];
        tabs.forEach((tab, i) => {
            const tx = -panelW/2 + 42 + i * 66;
            const tbg = this.add.rectangle(tx, cb.y + 8, 58, 18, currentTab === tab.id ? 0x332211 : 0x0c0c18).setStrokeStyle(1, 0x554433).setInteractive({ useHandCursor: true });
            const ttxt = this.add.text(tx, cb.y + 8, tab.label, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: currentTab === tab.id ? '#cc8844' : '#666' }).setOrigin(0.5);
            panel.add(tbg); panel.add(ttxt);
            tabBtns.push({ bg: tbg, txt: ttxt, id: tab.id });
            tbg.on('pointerdown', () => {
                currentTab = tab.id;
                tabBtns.forEach(tb => { tb.bg.setFillStyle(tb.id === currentTab ? 0x332211 : 0x0c0c18); tb.txt.setFill(tb.id === currentTab ? '#cc8844' : '#666'); });
                renderTabContent(tab.id);
            });
        });
        const self = this;
        const renderTabContent = (tabId) => {
            contentContainer.removeAll(true);
            if (tabId === 'floors') {
                const floors = [
                    { id: 'concrete', name: 'Concrete', color: 0x3a3a38, cost: 0 },
                    { id: 'wood', name: 'Hardwood', color: 0x5a4a3a, cost: 20 },
                    { id: 'tile', name: 'Industrial Tile', color: 0x4a4a50, cost: 30 },
                    { id: 'metal', name: 'Steel Plate', color: 0x4a4a4a, cost: 40 },
                    { id: 'rusted', name: 'Rusted Grate', color: 0x5a3a2a, cost: 25 },
                    { id: 'dark', name: 'Dark Stone', color: 0x2a2a2a, cost: 35 }
                ];
                floors.forEach((fl, i) => {
                    const row = Math.floor(i / 2), col = i % 2;
                    const fx = -60 + col * 120, fy = -40 + row * 55;
                    const isActive = sh.floor === fl.id;
                    contentContainer.add(self.add.rectangle(fx - 30, fy, 24, 24, fl.color).setStrokeStyle(1, isActive ? 0xcc8844 : 0x444444));
                    if (isActive) contentContainer.add(self.add.text(fx - 30, fy, 'OK', { fontSize: uiPx(10), fill: '#cc8844' }).setOrigin(0.5));
                    contentContainer.add(self.add.text(fx + 2, fy - 6, fl.name, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: isActive ? '#cc8844' : '#aaa' }));
                    if (!isActive) {
                        const buyBtn = self.add.text(fx + 2, fy + 6, fl.cost > 0 ? `${fl.cost} APPLY` : 'APPLY', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: matCount >= fl.cost ? '#88cc44' : '#aa4444' }).setInteractive({ useHandCursor: true });
                        contentContainer.add(buyBtn);
                        buyBtn.on('pointerdown', () => {
                            if (matCount >= fl.cost) { self.saveData.stash.materials -= fl.cost; sh.floor = fl.id; self.applyFloorStyle(fl.id); panel.destroy(); self.popupActive = false; if (self.showNotification) self.showNotification(`Floor: ${fl.name}`, 'common'); }
                        });
                    }
                });
            } else if (tabId === 'walls') {
                const walls = [
                    { id: 'default', name: 'Bunker Grey', color: 0x5a5550, cost: 0 },
                    { id: 'dark', name: 'Dark Steel', color: 0x3a3a3a, cost: 20 },
                    { id: 'warm', name: 'Warm Plaster', color: 0x6a5a4a, cost: 25 },
                    { id: 'military', name: 'Military Green', color: 0x4a5a3a, cost: 30 },
                    { id: 'industrial', name: 'Industrial Blue', color: 0x3a4a5a, cost: 30 },
                    { id: 'rust', name: 'Oxidized Iron', color: 0x6a4a3a, cost: 35 }
                ];
                walls.forEach((wl, i) => {
                    const row = Math.floor(i / 2), col = i % 2;
                    const wx = -60 + col * 120, wy = -40 + row * 55;
                    const isActive = sh.wall === wl.id;
                    contentContainer.add(self.add.rectangle(wx - 30, wy, 24, 24, wl.color).setStrokeStyle(1, isActive ? 0xcc8844 : 0x444444));
                    if (isActive) contentContainer.add(self.add.text(wx - 30, wy, 'OK', { fontSize: uiPx(10), fill: '#cc8844' }).setOrigin(0.5));
                    contentContainer.add(self.add.text(wx + 2, wy - 6, wl.name, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: isActive ? '#cc8844' : '#aaa' }));
                    if (!isActive) {
                        const buyBtn = self.add.text(wx + 2, wy + 6, wl.cost > 0 ? `${wl.cost} APPLY` : 'APPLY', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: matCount >= wl.cost ? '#88cc44' : '#aa4444' }).setInteractive({ useHandCursor: true });
                        contentContainer.add(buyBtn);
                        buyBtn.on('pointerdown', () => {
                            if (matCount >= wl.cost) { self.saveData.stash.materials -= wl.cost; sh.wall = wl.id; self.applyWallStyle(wl.id); panel.destroy(); self.popupActive = false; if (self.showNotification) self.showNotification(`Walls: ${wl.name}`, 'common'); }
                        });
                    }
                });
            } else if (tabId === 'layout') {
                contentContainer.add(self.add.text(0, -35, 'REARRANGE MODE', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#cc8844', fontStyle: 'bold' }).setOrigin(0.5));
                contentContainer.add(self.add.text(0, -12, 'Enter rearrange mode to drag\nall stations to new positions.\nIncludes vehicle and garage door.', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#777', align: 'center' }).setOrigin(0.5));
                const enterBtn = UIManager.createButton(self, 0, 35, 'ENTER REARRANGE', { width: 140, height: 32, style: 'confirm', fontSize: uiPx(9), depth: 202, onClick: () => { panel.destroy(); self.popupActive = false; self.enterRearrangeMode(); } });
                contentContainer.add(enterBtn);
                const resetBtn = UIManager.createButton(self, 0, 75, 'RESET DEFAULT', { width: 100, height: 22, style: 'danger', fontSize: uiPx(7), depth: 202, onClick: () => { if (sh.stationPositions) delete sh.stationPositions; panel.destroy(); self.popupActive = false; self.scene.restart(); } });
                contentContainer.add(resetBtn);
            } else if (tabId === 'props') {
                contentContainer.add(self.add.text(0, -35, 'DECORATIONS', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#cc8844', fontStyle: 'bold' }).setOrigin(0.5));
                contentContainer.add(self.add.text(0, -20, 'Purchase props for your safehouse', { fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#555' }).setOrigin(0.5));
                const props = [
                    { id: 'poster', name: 'Wall Poster', icon: 'IMG', cost: 10 },
                    { id: 'plant', name: 'Potted Plant', icon: 'PLT', cost: 15 },
                    { id: 'radio', name: 'Old Radio', icon: 'RAD', cost: 20 },
                    { id: 'flag', name: 'Faction Banner', icon: 'FLG', cost: 25 },
                    { id: 'lamp', name: 'Desk Lamp', icon: '', cost: 15 },
                    { id: 'skull', name: 'Trophy Skull', icon: 'SKL', cost: 30 },
                    { id: 'map', name: 'Wall Map', icon: 'MAP', cost: 20 },
                    { id: 'crate', name: 'Supply Crate', icon: 'BOX', cost: 10 }
                ];
                if (!sh.props) sh.props = [];
                props.forEach((pr, i) => {
                    const row = Math.floor(i / 2), col = i % 2;
                    const px = -55 + col * 125, py = -5 + row * 36;
                    const owned = sh.props.includes(pr.id);
                    contentContainer.add(self.add.text(px - 14, py, pr.icon, { fontSize: uiPx(12) }).setOrigin(0.5));
                    contentContainer.add(self.add.text(px + 6, py - 7, pr.name, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: owned ? '#88cc44' : '#aaa' }));
                    if (owned) {
                        contentContainer.add(self.add.text(px + 6, py + 5, 'OK PLACED', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#556633' }));
                    } else {
                        const buyBtn = self.add.text(px + 6, py + 5, `${pr.cost} BUY`, { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: matCount >= pr.cost ? '#88cc44' : '#aa4444' }).setInteractive({ useHandCursor: true });
                        contentContainer.add(buyBtn);
                        buyBtn.on('pointerdown', () => {
                            if ((self.saveData.stash.materials || 0) >= pr.cost) { self.saveData.stash.materials -= pr.cost; if (!sh.props.includes(pr.id)) sh.props.push(pr.id); if (self.showNotification) self.showNotification(`Placed: ${pr.name}`, 'common'); renderTabContent('props'); }
                        });
                    }
                });
            }
        };
        renderTabContent('floors');
    }

    
    applyFloorStyle(floorId) {
        const colors = {
            concrete: 0x3a3a38, wood: 0x5a4a3a, tile: 0x4a4a50,
            metal: 0x4a4a4a, rusted: 0x5a3a2a, dark: 0x2a2a2a
        };
        if (this.floorRect && colors[floorId]) {
            this.floorRect.setFillStyle(colors[floorId]);
        }
    }
    
    applyWallStyle(wallId) {
        const colors = {
            default: 0x5a5550, dark: 0x3a3a3a, warm: 0x6a5a4a,
            military: 0x4a5a3a, industrial: 0x3a4a5a, rust: 0x6a4a3a
        };
        if (colors[wallId] && this.wallElements) {
            const col = colors[wallId];
            this._wallBaseCol = col;
            this.wallElements.forEach(w => {
                if (w.type === 'back') w.obj.setFillStyle(col);
                else if (w.type === 'back_top') w.obj.setFillStyle(IsoRenderer.lighten(col, 0.1));
                else if (w.type === 'left') w.obj.setFillStyle(IsoRenderer.darken(col, 0.15));
                else if (w.type === 'right') w.obj.setFillStyle(IsoRenderer.lighten(col, 0.08));
            });
        }
    }
    
    enterRearrangeMode() {
        this.rearrangeMode = true;
        this.popupActive = true; // Block normal interactions
        
        const W = CONFIG.width, H = CONFIG.height;
        
        // Dim overlay
        const dimOverlay = this.add.rectangle(W/2, H/2, W, H, 0x000000, 0.3).setDepth(150).setScrollFactor(0);
        
        // Header bar
        const headerBg = this.add.rectangle(W/2, 20, W, 36, 0x1a1a0a, 0.9).setDepth(300).setScrollFactor(0);
        const headerText = this.add.text(W/2, 14, 'REARRANGE MODE - Drag stations to reposition', {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#cc8844'
        }).setOrigin(0.5).setDepth(301).setScrollFactor(0);
        
        // Done button
        UIAtlas.build(this);
        const doneBtn = UIManager.createButton(this, W - 45, 20, 'DONE', {
            width: 60, height: 22, style: 'confirm', fontSize: uiPx(9), depth: 301,
            onClick: null
        });
        doneBtn.setScrollFactor(0);
        const rearrangeElements = [dimOverlay, headerBg, headerText, doneBtn];
        const highlights = [];
        
        // Make each station draggable with a highlight box
        const draggables = [];
        
        // Only loadout is wall-fixed (slides along back wall X only)
        const backWallFixedIds = ['loadout'];
        const backWallY = this.offsetY + 28 / 2; // wall center Y
        
        this.stations.forEach((station, idx) => {
            if (!station || !station.config) return;
            const cfg = station.config;
            const isWallFixed = backWallFixedIds.includes(cfg.id);
            
            // Skip vehicle — handled in entangled garage group
            if (cfg.id === 'vehicle') {
                draggables.push({ station, dragZone: null, highlight: null, label: null, idx });
                return;
            }
            
            // For wall-fixed: track the offset between container position and interaction zone
            const containerOffY = isWallFixed ? (cfg.y - station.y) : 0;
            const fixedStationY = station.y; // preserve the container's wall Y
            
            const hlColor = isWallFixed ? 0x44aa88 : 0xcc8844;
            
            // Highlight box
            const hl = this.add.rectangle(cfg.x, cfg.y, cfg.width + 8, cfg.height + 8, hlColor, 0)
                .setStrokeStyle(1, hlColor, 0.6).setDepth(160);
            highlights.push(hl);
            
            // Label
            const tag = isWallFixed ? ' [WALL]' : '';
            const lbl = this.add.text(cfg.x, cfg.y - cfg.height/2 - 14, cfg.id.toUpperCase() + tag, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#' + hlColor.toString(16).padStart(6, '0'), fontStyle: 'bold',
                backgroundColor: '#000000aa', padding: { x: 3, y: 1 }
            }).setOrigin(0.5).setDepth(161);
            highlights.push(lbl);
            
            // Drag zone
            const dragZone = this.add.rectangle(cfg.x, cfg.y, cfg.width + 8, cfg.height + 8, 0xffffff, 0.01)
                .setDepth(170).setInteractive({ draggable: true });
            highlights.push(dragZone);
            
            draggables.push({ station, dragZone, highlight: hl, label: lbl, idx });
            
            dragZone.on('drag', (pointer, dragX, dragY) => {
                const minX = this.offsetX + 20;
                const maxX = this.offsetX + this.roomW - 20;
                const minY = this.offsetY + 40;
                const maxY = this.offsetY + this.roomH - 20;
                
                let cx, cy;
                if (isWallFixed) {
                    // Loadout: slides along back wall — only X moves, container stays at wall Y
                    cx = Phaser.Math.Clamp(dragX, minX, maxX);
                    station.x = cx;
                    station.y = fixedStationY; // container stays on wall
                    cy = fixedStationY + containerOffY; // interaction zone stays at offset
                } else {
                    cx = Phaser.Math.Clamp(dragX, minX, maxX);
                    cy = Phaser.Math.Clamp(dragY, minY, maxY);
                    station.x = cx; station.y = cy;
                }
                
                hl.x = cx; hl.y = cy;
                lbl.x = cx; lbl.y = cy - cfg.height/2 - 14;
                dragZone.x = cx; dragZone.y = cy;
                cfg.x = cx; cfg.y = cy;
            });
            
            dragZone.on('dragstart', () => hl.setStrokeStyle(1, 0xffcc44, 0.8));
            dragZone.on('dragend', () => {
                hl.setStrokeStyle(1, hlColor, 0.6);
                // Rebuild ISO station visual with new wall orientation
                if (station._isoDefName) {
                    this.buildStationVisual(station, station._isoDefName, station.x, station.y, station._isoScale);
                }
            });
        });
        
        // === BACKPACK as draggable + rotatable ===
        if (this.backpackDisplay) {
            const bpX = this.backpackDisplay.x;
            const bpY = this.backpackDisplay.y;
            const bpHl = this.add.rectangle(bpX, bpY, 30, 30, 0x88aa44, 0)
                .setStrokeStyle(1, 0x88aa44, 0.5).setDepth(160);
            highlights.push(bpHl);
            const bpLbl = this.add.text(bpX, bpY - 22, 'BACKPACK', {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#88aa44', fontStyle: 'bold',
                backgroundColor: '#000000aa', padding: { x: 3, y: 1 }
            }).setOrigin(0.5).setDepth(161);
            highlights.push(bpLbl);
            
            // Facing label + rotate button
            const dirLabels = ['N ↑', 'E →', 'S ↓', 'W ←'];
            if (!this.saveData.safehouse) this.saveData.safehouse = {};
            let bpFacing = this.saveData.safehouse.backpackFacing || 0;
            
            const bpFaceTxt = this.add.text(bpX, bpY + 20, dirLabels[bpFacing], {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#88aa44',
                backgroundColor: '#000000aa', padding: { x: 2, y: 1 }
            }).setOrigin(0.5).setDepth(172);
            highlights.push(bpFaceTxt);
            
            const bpRotBtn = this.add.text(bpX + 20, bpY, '↻', {
                fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#88aa44',
                backgroundColor: '#000000cc', padding: { x: 2, y: 0 }
            }).setOrigin(0.5).setDepth(172).setInteractive();
            highlights.push(bpRotBtn);
            
            bpRotBtn.on('pointerdown', () => {
                bpFacing = (bpFacing + 1) % 4;
                this.saveData.safehouse.backpackFacing = bpFacing;
                bpFaceTxt.setText(dirLabels[bpFacing]);
                // Rebuild backpack with proper isometric facing
                const curBpX = this.backpackDisplay.x;
                const curBpY = this.backpackDisplay.y;
                this.backpackDisplay.destroy();
                this.createBackpackDisplay(curBpX, curBpY, bpFacing);
            });
            
            // Drag
            const bpDrag = this.add.rectangle(bpX, bpY, 30, 30, 0xffffff, 0.01)
                .setDepth(170).setInteractive({ draggable: true });
            highlights.push(bpDrag);
            
            bpDrag.on('drag', (pointer, dragX, dragY) => {
                const cx = Phaser.Math.Clamp(dragX, this.offsetX + 20, this.offsetX + this.roomW - 20);
                const cy = Phaser.Math.Clamp(dragY, this.offsetY + 40, this.offsetY + this.roomH - 20);
                this.backpackDisplay.x = cx; this.backpackDisplay.y = cy;
                this.backpackDisplayPos = { x: cx, y: cy };
                bpHl.x = cx; bpHl.y = cy;
                bpLbl.x = cx; bpLbl.y = cy - 22;
                bpDrag.x = cx; bpDrag.y = cy;
                bpRotBtn.x = cx + 20; bpRotBtn.y = cy;
                bpFaceTxt.x = cx; bpFaceTxt.y = cy + 20;
            });
            bpDrag.on('dragstart', () => bpHl.setStrokeStyle(1, 0xbbdd44, 0.8));
            bpDrag.on('dragend', () => bpHl.setStrokeStyle(1, 0x88aa44, 0.5));
        }
        
        // Entangle VEHICLE + GARAGE DOOR as one draggable group
        if (this.garageDoor && this.garageDoorPos && this.vehicleStation) {
            const gdp = this.garageDoorPos;
            // Find vehicle station in the list
            const vehicleStn = this.stations.find(s => s && s.config && s.config.id === 'vehicle');
            
            // Calculate offset between vehicle and garage door
            const vehOffX = vehicleStn ? (vehicleStn.config.x - gdp.x) : -50;
            const vehOffY = vehicleStn ? (vehicleStn.config.y - gdp.y) : 0;
            
            // Big highlight encompassing both
            const groupW = Math.max(gdp.w, 80) + 20;
            const groupH = gdp.h + 30;
            const groupCX = gdp.x + vehOffX / 2;
            const groupCY = gdp.y;
            
            const gdHl = this.add.rectangle(groupCX, groupCY, groupW, groupH, 0x4444aa, 0)
                .setStrokeStyle(1, 0x4444aa, 0.5).setDepth(160);
            highlights.push(gdHl);
            const gdLbl = this.add.text(groupCX, groupCY - groupH/2 - 14, 'VEHICLE + GARAGE', {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#6666cc', fontStyle: 'bold',
                backgroundColor: '#000000aa', padding: { x: 3, y: 1 }
            }).setOrigin(0.5).setDepth(161);
            highlights.push(gdLbl);
            const gdDrag = this.add.rectangle(groupCX, groupCY, groupW, groupH, 0xffffff, 0.01)
                .setDepth(170).setInteractive({ draggable: true });
            highlights.push(gdDrag);
            
            // Remove vehicle from individual draggables (it moves with garage)
            const vehDragIdx = draggables.findIndex(d => d.station === vehicleStn);
            if (vehDragIdx >= 0) {
                const vd = draggables[vehDragIdx];
                if (vd.dragZone) vd.dragZone.disableInteractive();
                if (vd.highlight) vd.highlight.setAlpha(0.2);
                if (vd.label) vd.label.setText('(moves with garage)').setFill('#555588');
            }
            
            gdDrag.on('drag', (pointer, dragX, dragY) => {
                // Garage stays pinned to right wall — only Y changes
                const wallX = this.offsetX + this.roomW - 7; // right wall center
                const cy = Phaser.Math.Clamp(dragY, this.offsetY + 80, this.offsetY + this.roomH - 80);
                
                // Move garage door
                this.garageDoor.x = wallX; this.garageDoor.y = cy;
                gdp.x = wallX; gdp.y = cy;
                
                // Redraw mask at new position
                if (this.garageDoorMaskGraphics) {
                    this.garageDoorMaskGraphics.clear();
                    this.garageDoorMaskGraphics.fillStyle(0xffffff);
                    this.garageDoorMaskGraphics.fillRect(wallX - gdp.w/2 - 2, cy - gdp.h/2 - 2, gdp.w + 4, gdp.h + 4);
                }
                
                // Move behind-door scene
                if (this.behindDoorContainer) { this.behindDoorContainer.x = wallX; this.behindDoorContainer.y = cy; }
                if (this.garageFrame) { this.garageFrame.x = wallX; this.garageFrame.y = cy; }
                if (this.doorLightSpill) { this.doorLightSpill.x = wallX - 15; this.doorLightSpill.y = cy + gdp.h * 0.25; }
                
                // Move vehicle with offset (vehicle stays at same relative Y)
                if (this.vehicleStation) {
                    this.vehicleStation.x = wallX + vehOffX;
                    this.vehicleStation.y = cy + vehOffY;
                }
                if (vehicleStn && vehicleStn.config) {
                    vehicleStn.config.x = wallX + vehOffX;
                    vehicleStn.config.y = cy + vehOffY;
                }
                if (this.vehicleStationPos) {
                    this.vehicleStationPos.x = wallX + vehOffX;
                    this.vehicleStationPos.y = cy + vehOffY;
                }
                
                // Move highlight/label
                gdHl.x = wallX + vehOffX/2; gdHl.y = cy;
                gdLbl.x = wallX + vehOffX/2; gdLbl.y = cy - groupH/2 - 14;
                gdDrag.x = wallX + vehOffX/2; gdDrag.y = cy;
                
                // Update veh draggable highlight if it exists
                if (vehDragIdx >= 0) {
                    const vd = draggables[vehDragIdx];
                    if (vd.highlight) { vd.highlight.x = wallX + vehOffX; vd.highlight.y = cy + vehOffY; }
                    if (vd.label) { vd.label.x = wallX + vehOffX; vd.label.y = cy + vehOffY - vd.station.config.height/2 - 14; }
                }
            });
            
            gdDrag.on('dragstart', () => gdHl.setStrokeStyle(1, 0x6666ff, 0.8));
            gdDrag.on('dragend', () => gdHl.setStrokeStyle(1, 0x4444aa, 0.5));
        }
        
        // DONE button — save positions and exit
        doneBtn._bg.on('pointerdown', () => {
            // Save all positions
            if (!this.saveData.safehouse) this.saveData.safehouse = {};
            const positions = {};
            this.stations.forEach(s => {
                if (s && s.config) {
                    positions[s.config.id] = { x: s.config.x, y: s.config.y };
                }
            });
            if (this.garageDoorPos) {
                positions.garageDoor = { x: this.garageDoorPos.x, y: this.garageDoorPos.y };
            }
            // Save backpack position
            if (this.backpackDisplayPos) {
                positions.backpack = { x: this.backpackDisplayPos.x, y: this.backpackDisplayPos.y };
            }
            this.saveData.safehouse.stationPositions = positions;
            
            // Rebuild all colliders from current station positions
            this.stations.forEach(s => {
                if (s && s.config && s._colliderIdx !== undefined && this.stationColliders[s._colliderIdx]) {
                    const cfg = s.config;
                    this.stationColliders[s._colliderIdx] = {
                        x: cfg.x - cfg.width/2,
                        y: cfg.y - cfg.height/2,
                        width: cfg.width,
                        height: cfg.height
                    };
                }
            });
            
            // Clean up
            rearrangeElements.forEach(e => e.destroy());
            highlights.forEach(e => e.destroy());
            this.rearrangeMode = false;
            this.popupActive = false;
            
            if (this.showNotification) this.showNotification('Layout saved!', 'common');
        });
    }
    
    showNotificationToast(note) {
        const W = CONFIG.width;
        const toast = this.add.container(W/2, -40).setDepth(250);
        
        const isAch = note.type === 'achievement';
        const isXP = note.type === 'xp';
        const isDeath = note.type === 'death';
        const isRescue = note.type === 'rescue';
        const isInjury = note.type === 'injury';
        const isMark = note.type === 'mark';
        const bgColor = isXP ? 0x2a1a0a : isDeath ? 0x2a0a0a : isRescue ? 0x0a2a1a : isInjury ? 0x2a1a0a : isMark ? 0x0a1a2a : (isAch ? 0x1a2a1a : 0x1a1a2a);
        const borderColor = isXP ? 0xcc8844 : isDeath ? 0xaa3333 : isRescue ? 0x33aa66 : isInjury ? 0xcc8844 : isMark ? 0x4488aa : (isAch ? 0x4aba4a : 0x4a8aff);
        const titleColor = isXP ? '#cc8844' : isDeath ? '#aa3333' : isRescue ? '#33aa66' : isInjury ? '#cc8844' : isMark ? (note.markColor || '#4488aa') : (isAch ? '#4aba4a' : '#4a8aff');
        
        if (isXP) {
            const toastH = note.leveledUp ? 54 : 40;
            toast.add(this.add.rectangle(0, 0, W - 30, toastH, bgColor, 0.95).setStrokeStyle(1, borderColor, 0.8));
            toast.add(this.add.text(0, note.leveledUp ? -14 : -8, `+${note.xp} XP`, {
                fontFamily: 'monospace', fontSize: uiPx(12), fill: '#cc8844', fontStyle: 'bold'
            }).setOrigin(0.5));
            if (note.leveledUp) {
                toast.add(this.add.text(0, 4, `LEVEL UP - LV.${note.newLevel}`, {
                    fontFamily: 'monospace', fontSize: uiPx(10), fill: '#ffcc44', fontStyle: 'bold'
                }).setOrigin(0.5));
                const milestone = CONFIG.leveling.levelRewards.milestones[note.newLevel];
                if (milestone) {
                    toast.add(this.add.text(0, 18, `${milestone.title}: ${milestone.reward}`, {
                        fontFamily: 'monospace', fontSize: uiPx(7), fill: '#aa8844'
                    }).setOrigin(0.5));
                }
            }
        } else {
        const typeLabel = isDeath ? 'SURVIVOR LOST' : isRescue ? 'NEW ARRIVAL' : isInjury ? 'SURVIVOR INJURED' : isMark ? 'MARK EARNED' : isAch ? 'ACHIEVEMENT UNLOCKED' : 'QUEST COMPLETE';
        
        toast.add(this.add.rectangle(0, 0, W - 30, 44, bgColor, 0.95).setStrokeStyle(1, borderColor, 0.8));
        
        toast.add(this.add.text(0, -10, typeLabel, {
            fontFamily: 'monospace', fontSize: uiPx(7), fill: titleColor
        }).setOrigin(0.5));
        
        const icon = isAch && note.icon ? '' : '';
        toast.add(this.add.text(0, 5, `${icon}${note.title}`, {
            fontFamily: 'monospace', fontSize: uiPx(10), fill: '#ffffff', fontStyle: 'bold'
        }).setOrigin(0.5));
        
        // Reward line or subtitle
        if (note.subtitle && (isDeath || isRescue || isInjury || isMark)) {
            toast.add(this.add.text(0, 18, note.subtitle, {
                fontFamily: 'monospace', fontSize: uiPx(7), fill: isDeath ? '#884444' : isInjury ? '#886644' : isMark ? (note.markColor || '#668899') : '#448866'
            }).setOrigin(0.5));
        } else if (note.reward) {
            const parts = [];
            if (note.reward.bits) parts.push(`+${note.reward.bits} Bits`);
            if (note.reward.title) parts.push(`Title: ${note.reward.title}`);
            if (note.reward.aura) parts.push(`Aura unlocked`);
            if (parts.length) {
                toast.add(this.add.text(0, 18, parts.join(' · '), {
                    fontFamily: 'monospace', fontSize: uiPx(7), fill: '#aaaa66'
                }).setOrigin(0.5));
            }
        }
        } // close else for non-XP toasts
        
        // Slide in from top
        this.tweens.add({
            targets: toast, y: 30, duration: 400, ease: 'Back.out',
            onComplete: () => {
                this.time.delayedCall(2500, () => {
                    this.tweens.add({ targets: toast, y: -50, alpha: 0, duration: 400, onComplete: () => toast.destroy() });
                });
            }
        });
    }
    
    showWelcome() {
        this.showPlaceholder('Welcome Survivor', 
            'This is your safehouse.\n\nExplore the stations and interact with them.\n\nApproach your VEHICLE to begin a supply run.');
    }

    // ── Delegation stubs (extracted to helper objects) ──
    showTerminal() { CRTTerminal.showTerminal(this); }
    showTerminalTab(idx) { CRTTerminal.showTerminalTab(this, idx); }
    _tAdd(obj) { return CRTTerminal._tAdd(this, obj); }
    _vehicleIgnitionRumble() { CRTTerminal._vehicleIgnitionRumble(this); }
    _stopVehicleRumble() { CRTTerminal._stopVehicleRumble(this); }
    showTraining() { GymPanel.showTraining(this); }
    showBed() { SleepPanel.showBed(this); }
    updateSafehouseTime() { SleepPanel.updateSafehouseTime(this); }
    showWorkbench() { WorkbenchPanel.showWorkbench(this); }
}

// ==================== MAP SCENE ====================
// Node-based map for selecting destinations

