// Vestige GPS — Boot Scene
// Creates fallback textures, initializes systems, transitions to first scene

import Phaser from 'phaser';
import { CONFIG } from '../../data/config.js';
import { SaveManager } from '../../core/saveManager.js';
import { RealtimeTOD } from '../../core/realtimeTOD.js';
import { TitleScene } from './TitleScene.js';

// TOD → ambient tint mapping (matches monolith)
const TOD_TINTS = {
    dawn:   0xddaa88,
    midday: 0xffffff,
    dusk:   0xcc8866,
    night:  0x556688
};

export class BootScene extends Phaser.Scene {
    constructor() {
        super({ key: 'BootScene' });
    }

    preload() {
        // Create fallback textures procedurally
        this._createDefaultTextures();

        // Loading bar
        const w = this.cameras.main.width;
        const h = this.cameras.main.height;
        const barW = w * 0.6;
        const barH = 6;
        const barX = (w - barW) / 2;
        const barY = h / 2 + 20;

        const bg = this.add.rectangle(barX + barW / 2, barY, barW, barH, 0x222222).setOrigin(0.5);
        const fill = this.add.rectangle(barX + 1, barY, 0, barH - 2, 0x44ff88).setOrigin(0, 0.5);

        this.add.text(w / 2, barY - 20, 'VESTIGE', {
            fontFamily: 'monospace', fontSize: '16px', color: '#44ff88'
        }).setOrigin(0.5);

        this.load.on('progress', (val) => {
            fill.width = (barW - 2) * val;
        });
    }

    create() {
        // Initialize time-of-day
        const tod = RealtimeTOD.getFromClock();
        this._ambientTint = TOD_TINTS[tod] || 0xffffff;

        // Load saved state
        const state = SaveManager.load();
        this.registry.set('gameState', state);

        console.log('[Vestige] Boot complete, starting TitleScene');

        // Transition to test scene
        this.scene.start('TitleScene');
    }

    _createDefaultTextures() {
        // __DEFAULT: simple white square for fallback sprites
        if (!this.textures.exists('__DEFAULT')) {
            const gfx = this.make.graphics({ add: false });
            gfx.fillStyle(0xffffff, 1);
            gfx.fillRect(0, 0, 16, 16);
            gfx.generateTexture('__DEFAULT', 16, 16);
            gfx.destroy();
        }

        // Player texture: 12x16 humanoid silhouette
        if (!this.textures.exists('player')) {
            const gfx = this.make.graphics({ add: false });
            // Body
            gfx.fillStyle(0x88aacc, 1);
            gfx.fillRect(3, 4, 6, 8);  // torso
            gfx.fillRect(4, 0, 4, 4);  // head
            gfx.fillRect(1, 5, 2, 6);  // left arm
            gfx.fillRect(9, 5, 2, 6);  // right arm
            gfx.fillRect(3, 12, 3, 4); // left leg
            gfx.fillRect(6, 12, 3, 4); // right leg
            gfx.generateTexture('player', 12, 16);
            gfx.destroy();
        }

        // Enemy textures per type
        const enemyColors = {
            husk: 0x884422,
            runner: 0xaa6633,
            brute: 0x664422,
            spitter: 0x44aa33,
            husk_crawl: 0x553311
        };
        for (const [type, color] of Object.entries(enemyColors)) {
            const key = 'enemy_' + type;
            if (!this.textures.exists(key)) {
                const gfx = this.make.graphics({ add: false });
                const size = (CONFIG.enemyTypes?.[type]?.size) || 14;
                gfx.fillStyle(color, 1);
                // Blocky body
                gfx.fillRect(2, 2, size - 4, size - 4);
                // Eyes
                gfx.fillStyle(0xff4444, 1);
                gfx.fillRect(4, 3, 2, 2);
                gfx.fillRect(size - 6, 3, 2, 2);
                gfx.generateTexture(key, size, size);
                gfx.destroy();
            }
        }
    }
}
