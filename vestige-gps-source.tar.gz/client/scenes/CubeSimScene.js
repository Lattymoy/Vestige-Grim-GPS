// Vestige GPS — CubeSimScene
// Extracted from monolith lines 77657-79492
// Imports will be wired in integration pass

import { Blurbs } from '../../core/blurbs.js';
import { CombatHelper } from '../../core/combatHelper.js';
import { CombatSystem } from '../../core/combatSystem.js';
import { ConsumableSystem } from '../../core/consumableSystem.js';
import { DOTManager } from '../../core/dotManager.js';
import { DOTSystem } from '../../core/dotSystem.js';
import { EnemyAI } from '../../core/enemyAI.js';
import { EnemyManager } from '../../core/enemyManager.js';
import { ItemManager } from '../../core/itemManager.js';
import { SignatureEffects } from '../../core/signatureEffects.js';
import { SurvivorGenerator } from '../../core/survivorGenerator.js';
import { _restoreTint, uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { GrimFont } from '../../data/grimFont.js';
import { AudioManager } from '../audioManager.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { TelegraphSystem } from '../rendering/telegraphSystem.js';
import { SpriteManager } from '../spriteManager.js';
import { GameHUD } from '../ui/gameHUD.js';
import { PlayerStatusIcons } from '../ui/playerStatusIcons.js';
import { UIAtlas } from '../uiAtlas.js';
import { InputManager } from '../rendering/inputManager.js';
import { GameScene } from './GameScene.js';
import { SafehouseScene } from './SafehouseScene.js';


export class CubeSimScene extends Phaser.Scene {
    constructor() { super('CubeSimScene'); }
    
    init(data) {
        this._saveData = data.saveData || {};
        this._returnScene = data.returnScene || 'SafehouseScene';
    }
    
    create() {
        const W = CONFIG.width, H = CONFIG.height;
        const WORLD = 800;
        this.physics.world.setBounds(0, 0, WORLD, WORLD);
        this.cameras.main.setBounds(0, 0, WORLD, WORLD);
        
        // === STATE — mirror GameScene state from save data ===
        const sd = this._saveData;
        const eqData = sd.equipment || {};
        const eqStats = ItemManager.getEquipmentStats(eqData);
        this._eqStats = eqStats;
        
        const survivors = (sd.survivors || []).filter(s => s.alive);
        this.deployedSurvivor = survivors.find(s => s.deployed) || survivors[0] || null;
        
        this.state = {
            health: CONFIG.player.health + (eqStats.maxHealth || 0),
            maxHealth: CONFIG.player.health + (eqStats.maxHealth || 0),
            equipment: eqData,
            kills: 0,
            dead: false,
            backpack: sd.backpack || null,
            survivorMods: { statMultiplier: 1, conditionals: {} },
            _powerAmmoActive: false,
            powerAmmo: 0
        };
        
        if (this.deployedSurvivor) {
            try { this.state.survivorMods = SurvivorGenerator.calculateMods(this.deployedSurvivor); } catch(e) {}
        }
        
        // === HOLOGRAPHIC FLOOR ===
        this._drawHoloFloor(WORLD);
        
        // === PLAYER ===
        UIAtlas.build(this);
        GrimFont.build(this);
        
        const spawnX = WORLD / 2, spawnY = WORLD / 2;
        this.player = SpriteManager.createPlayerSprite(this, spawnX, spawnY, this.state.backpack,
            this.deployedSurvivor ? this.deployedSurvivor.equippedAura : null);
        this.player.setCollideWorldBounds(true).setDepth(20);
        DynamicShadows.add(this, this.player, { offsetY: 10, scale: 0.6, alpha: 0.15 });
        
        // Apply gear outfit
        if (eqData.gear && eqData.gear.outfit) {
            const custom = Object.assign({}, SpriteManager.playerCustomization);
            custom.shirt = eqData.gear.outfit.shirt;
            custom.pants = eqData.gear.outfit.pants;
            custom.gearType = eqData.gear.gearClass || eqData.gear.baseId;
            SpriteManager.rebuildPlayerSheet(this, custom);
            this.player.setTexture('player_sheet', 0).setDisplaySize(40, 40);
        }
        
        // Weapon sprite setup
        if (eqData.weapon) {
            const baseId = eqData.weapon.baseId || 'pistol';
            this.player.weaponType = SpriteManager.getWeaponSpriteType(baseId);
            this.player.weaponFoundry = eqData.weapon.foundry || null;
            this.player.weaponFlair = eqData.weapon.flair || null;
            const wt = this.player.weaponType;
            const fid = this.player.weaponFoundry;
            SpriteManager.armedSheets[wt] = SpriteManager.generatePlayerSheet(SpriteManager.playerCustomization, true, wt, fid, eqData.weapon);
            const sheetKey = 'player_sheet_armed_' + wt;
            if (this.textures.exists(sheetKey)) this.textures.remove(sheetKey);
            this.textures.addSpriteSheet(sheetKey, SpriteManager.armedSheets[wt], { frameWidth: 48, frameHeight: 48 });
            const dirs = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
            dirs.forEach((dir, i) => {
                const animKey = `player_armed_${wt}_${dir}`;
                if (this.anims.exists(animKey)) this.anims.remove(animKey);
                this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 8, repeat: -1 });
            });
        }
        
        // Melee sheet setup
        ['blade', 'blunt', 'heavy'].forEach(sheetType => {
            const meleeSheetKey = 'player_sheet_melee_' + sheetType;
            if (this.textures.exists(meleeSheetKey)) {
                const dirs = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
                dirs.forEach((dir, i) => {
                    const animKey = `player_melee_${sheetType}_${dir}`;
                    if (!this.anims.exists(animKey)) {
                        this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers(meleeSheetKey, { start: i*4, end: i*4+3 }), frameRate: 14, repeat: 0 });
                    }
                });
            }
        });
        
        // === RETICLE ===
        this.reticle = this.add.graphics().setVisible(false).setDepth(25).setAlpha(0.8);
        this.reticle._drawCrosshair = function(tintColor) {
            this.clear();
            const s = 12, c = tintColor || 0xccbbaa;
            this.lineStyle(1.5, c, 0.9);
            this.beginPath(); this.moveTo(-s, -s); this.lineTo(-s, -s+5); this.strokePath();
            this.beginPath(); this.moveTo(-s, -s); this.lineTo(-s+5, -s); this.strokePath();
            this.beginPath(); this.moveTo(s, -s); this.lineTo(s, -s+5); this.strokePath();
            this.beginPath(); this.moveTo(s, -s); this.lineTo(s-5, -s); this.strokePath();
            this.beginPath(); this.moveTo(-s, s); this.lineTo(-s, s-5); this.strokePath();
            this.beginPath(); this.moveTo(-s, s); this.lineTo(-s+5, s); this.strokePath();
            this.beginPath(); this.moveTo(s, s); this.lineTo(s, s-5); this.strokePath();
            this.beginPath(); this.moveTo(s, s); this.lineTo(s-5, s); this.strokePath();
            this.fillStyle(c, 0.5); this.fillCircle(0, 0, 1.5);
        };
        this.reticle._drawCrosshair();
        
        // === PHYSICS GROUPS ===
        this.bullets = this.physics.add.group();
        this.enemies = this.physics.add.group();
        this.walls = this.physics.add.staticGroup();
        this.wallRects = [];
        
        // === COLLISIONS ===
        this.physics.add.collider(this.bullets, this.enemies, (b, e) => {
            if (!b.active || !e.active) return;
            this.spark(b.x, b.y, b.rotation, b.fx);
            const dmg = b.damage || CONFIG.player.gunDamage;
            const doPierce = b.pierceLeft > 0 || (b.pierceChance && Math.random() < b.pierceChance);
            if (doPierce) {
                if (!b._hitEnemies) b._hitEnemies = new Set();
                if (b._hitEnemies.has(e)) return;
                b._hitEnemies.add(e);
                if (b.pierceLeft > 0) b.pierceLeft--;
            } else { b.destroy(); }
            this.damageEnemy(e, dmg, 'bullet', b);
            
            // Limb loss — husks can become crawlers when shot
            if (e.active && !e._dying) EnemyAI._limbLossToCrawler(this, e, b.x, b.y);
            // Blade loss — flickers lose arms, become acid-trailing maimed variant
            if (e.active && !e._dying) EnemyAI._flickerMaimCheck(this, e);
            
            // === SIGNATURE EFFECTS ON BULLET HIT ===
            const bSigs = b._sigs || [];
            const ricochet = bSigs.find(s => s.effect === 'ricochet');
            if (ricochet && !b._ricochetDone) {
                b._ricochetDone = true;
                SignatureEffects.doRicochet(this, b, e, dmg, ricochet);
            }
            if (b._isFirepower && e.active) {
                DOTManager.apply(this, e, 'burn', 15, 5000, 'firepower');
            }
            if (b._isParasitic && e.active) {
                SignatureEffects.consumeParasiticRound(this, this.state, e);
            }
        });
        this.physics.add.overlap(this.player, this.enemies, (p, e) => this.enemyHitPlayer(e));
        
        // Acid puddle DOT — stepping in acid applies toxic DOT
        this.acidPuddles = this.physics.add.group();
        this.physics.add.overlap(this.player, this.acidPuddles, (p, puddle) => {
            if (this.isInvincible || this.state.dead) return;
            if (!puddle._acidActive) return;
            DOTSystem.applyToPlayer(this, 'toxic', { damage: puddle._acidDmg || 2 });
        });
        
        // === ENEMY-ENEMY PHYSICS — husks push, stumble, trip over crawlers ===
        this.physics.add.collider(this.enemies, this.enemies, (a, b) => {
            if (!a.active || !b.active) return;
            const aSpd = Math.sqrt((a.body.velocity.x**2) + (a.body.velocity.y**2));
            const bSpd = Math.sqrt((b.body.velocity.x**2) + (b.body.velocity.y**2));
            
            // Trip over crawlers
            const aIsCrawler = a._isCrawler || a.enemyType === 'crawler' || a.enemyType === 'husk_crawl';
            const bIsCrawler = b._isCrawler || b.enemyType === 'crawler' || b.enemyType === 'husk_crawl';
            
            if (aIsCrawler && !bIsCrawler && bSpd > 30 && !b._stumbling) {
                EnemyAI._stumbleEnemy(this, b);
            } else if (bIsCrawler && !aIsCrawler && aSpd > 30 && !a._stumbling) {
                EnemyAI._stumbleEnemy(this, a);
            }
            // Speed stumble: only frenzy-speed husks (>100) rear-end slow/stopped husks
            else if (aSpd > 100 && bSpd < 15 && !b._stumbling && !aIsCrawler && !bIsCrawler) {
                EnemyAI._stumbleEnemy(this, b);
            } else if (bSpd > 100 && aSpd < 15 && !a._stumbling && !bIsCrawler && !aIsCrawler) {
                EnemyAI._stumbleEnemy(this, a);
            }
        });
        
        // === COMBAT STATE ===
        this.canShoot = true;
        this.canMelee = true;
        this.canDodge = true;
        this.isDodging = false;
        this.isInvincible = false;
        this.lockedTarget = null;
        this.target = null;
        this.aimAngle = 0;
        this.moveDir = { x: 0, y: 0 };
        this._magazine = eqStats.magSize || CONFIG.player.magSize || 10;
        this._maxMag = this._magazine;
        this._reloading = false;
        
        // === DPS TRACKING ===
        this._dpsLog = [];
        this._dpsValue = 0;
        this._totalDamage = 0;
        this._lastCombatTime = 0;
        
        // === INPUT ===
        InputManager.setup(this, {
            dodge: true,
            tapTarget: true,
            onDodge: (dx, dy) => this.dodge(dx, dy),
            onTapTarget: (px, py) => this.tapTarget(px, py)
        });
        this.keys = this.input.keyboard.addKeys({
            w: 'W', a: 'A', s: 'S', d: 'D', e: 'E', i: 'I',
            up: 'UP', down: 'DOWN', left: 'LEFT', right: 'RIGHT'
        });
        
        // === CAMERA ===
        this.cameras.main.startFollow(this.player, true, 0.08, 0.08);
        
        // === HUD ===
        this.hud = GameHUD.create(this, {
            title: 'CUBESIM',
            combat: true,
            persist: true,
            resources: { bits: 0, fuel: 0, mag: this._magazine, materials: 0 },
            survivor: this.deployedSurvivor
        });
        this.hud.updateHP(this.state.health, this.state.maxHealth);
        
        // === LEFT PANEL UI ===
        this._createSimPanel();
        
        // === RIGHT PANEL — MODIFIERS ===
        this._createModPanel();
        
        // === SPAWN MODIFIERS STATE ===
        this._spawnMods = { hpMult: 1, speedMult: 1, shielded: false };
        
        // === SQUARE TRANSITION IN ===
        this._squareTransitionIn();
    }
    
    _drawHoloFloor(worldSize) {
        const g = this.add.graphics().setDepth(0);
        g.fillStyle(0x050810, 1);
        g.fillRect(0, 0, worldSize, worldSize);
        
        const gridSize = 32;
        g.lineStyle(0.5, 0x22ffcc, 0.12);
        for (let x = 0; x <= worldSize; x += gridSize) {
            g.beginPath(); g.moveTo(x, 0); g.lineTo(x, worldSize); g.strokePath();
        }
        for (let y = 0; y <= worldSize; y += gridSize) {
            g.beginPath(); g.moveTo(0, y); g.lineTo(worldSize, y); g.strokePath();
        }
        g.lineStyle(1, 0x22ffcc, 0.3);
        for (let x = 0; x <= worldSize; x += gridSize * 4) {
            g.beginPath(); g.moveTo(x, 0); g.lineTo(x, worldSize); g.strokePath();
        }
        for (let y = 0; y <= worldSize; y += gridSize * 4) {
            g.beginPath(); g.moveTo(0, y); g.lineTo(worldSize, y); g.strokePath();
        }
        const cx = worldSize / 2, cy = worldSize / 2;
        for (let r = 150; r > 0; r -= 30) {
            g.fillStyle(0x22ffcc, 0.01);
            g.fillCircle(cx, cy, r);
        }
        g.lineStyle(2, 0x22ffcc, 0.25);
        g.strokeRect(4, 4, worldSize - 8, worldSize - 8);
        g.lineStyle(1, 0x22ffcc, 0.08);
        g.strokeRect(12, 12, worldSize - 24, worldSize - 24);
    }
    
    _createSimPanel() {
        const panelX = 4, panelY = 50;
        const panelW = 76, itemH = 16;
        const D = 150;
        
        // Track all panel objects for cleanup — NO container, all direct scene objects
        this._simPanelItems = [];
        const add = (obj) => { obj.setScrollFactor(0).setDepth(D + 2); this._simPanelItems.push(obj); return obj; };
        const addD = (obj, extraD) => { obj.setScrollFactor(0).setDepth(D + (extraD || 0)); this._simPanelItems.push(obj); return obj; };
        
        // Separate basic from boss
        const basicTypes = ['husk', 'husk_crawl', 'flicker', 'flicker_maimed', 'host', 'deadlock', 'reaper', 'spawn'];
        const bossTypes = [
            { key: 'boss', name: 'Tesseract', color: 0x8844aa },
            { key: 'boss', name: 'Warden', color: 0x886644, hpMult: 1.5 },
            { key: 'boss', name: 'Swarm Queen', color: 0x66aa44, hpMult: 1.2 },
            { key: 'boss', name: 'Phantom', color: 0x6644aa, hpMult: 0.8, spdMult: 1.5 },
            { key: 'boss', name: 'Ironclad', color: 0x667788, hpMult: 2.0, spdMult: 0.7 },
            { key: 'boss', name: 'Cube Anomaly', color: 0x8800ff, hpMult: 1.3 }
        ];
        
        // Calculate panel height (basic + controls, boss section starts collapsed)
        const basicCount = basicTypes.length;
        const basePanelH = 60 + basicCount * itemH + itemH * 3 + 20; // DPS + basics + clear/leave + boss header
        
        // Background
        this._simPanelBg = this.add.rectangle(panelX + panelW/2, panelY + basePanelH/2, panelW, basePanelH, 0x0a0e14, 0.92)
            .setStrokeStyle(1, 0x22ffcc, 0.3).setScrollFactor(0).setDepth(D);
        this._simPanelItems.push(this._simPanelBg);
        
        let curY = panelY + 8;
        
        // DPS header
        add(this.add.text(panelX + panelW/2, curY, 'DPS', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#446666', fontStyle: 'bold'
        }).setOrigin(0.5));
        curY += 12;
        
        this._dpsText = addD(this.add.text(panelX + panelW/2, curY, '0.0', {
            fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#22ffcc', fontStyle: 'bold'
        }).setOrigin(0.5), 1);
        curY += 18;
        
        this._totalDmgText = add(this.add.text(panelX + panelW/2, curY, 'Total: 0', {
            fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#335555'
        }).setOrigin(0.5));
        curY += 12;
        
        add(this.add.rectangle(panelX + panelW/2, curY, panelW - 8, 1, 0x22ffcc, 0.2));
        curY += 6;
        
        // ENEMIES header
        add(this.add.text(panelX + panelW/2, curY, 'ENEMIES', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#446666', fontStyle: 'bold'
        }).setOrigin(0.5));
        curY += 10;
        
        // Basic enemy buttons
        basicTypes.forEach(type => {
            const cfg = CONFIG.enemyTypes[type];
            if (!cfg) return;
            const btnBg = addD(this.add.rectangle(panelX + panelW/2, curY, panelW - 6, itemH - 2, 0x0e1820, 0.9)
                .setStrokeStyle(0.5, 0x22ffcc, 0.15).setInteractive({ useHandCursor: true }), 1);
            add(this.add.circle(panelX + 10, curY, 3, cfg.color || 0xaaaaaa));
            add(this.add.text(panelX + 17, curY, cfg.name || type, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#99bbaa'
            }).setOrigin(0, 0.5));
            
            btnBg.on('pointerover', () => btnBg.setFillStyle(0x1a2a30));
            btnBg.on('pointerout', () => btnBg.setFillStyle(0x0e1820));
            btnBg.on('pointerdown', () => { AudioManager.uiClick(); this._spawnSimEnemy(type); });
            curY += itemH;
        });
        
        curY += 4;
        add(this.add.rectangle(panelX + panelW/2, curY, panelW - 8, 1, 0x22ffcc, 0.2));
        curY += 6;
        
        // BOSS expander header
        this._bossExpanded = false;
        this._bossHeaderY = curY;
        const bossHeaderBg = addD(this.add.rectangle(panelX + panelW/2, curY, panelW - 6, itemH - 2, 0x1a0e20, 0.9)
            .setStrokeStyle(0.5, 0x8844aa, 0.3).setInteractive({ useHandCursor: true }), 1);
        this._bossArrow = add(this.add.text(panelX + 8, curY, '▶', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#8844aa'
        }).setOrigin(0, 0.5));
        add(this.add.text(panelX + 17, curY, 'BOSSES', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#aa66cc', fontStyle: 'bold'
        }).setOrigin(0, 0.5));
        
        bossHeaderBg.on('pointerover', () => bossHeaderBg.setFillStyle(0x2a1a30));
        bossHeaderBg.on('pointerout', () => bossHeaderBg.setFillStyle(0x1a0e20));
        bossHeaderBg.on('pointerdown', () => {
            AudioManager.uiClick();
            this._bossExpanded = !this._bossExpanded;
            this._bossArrow.setText(this._bossExpanded ? '▼' : '▶');
            this._toggleBossPanel(this._bossExpanded);
        });
        curY += itemH;
        
        // Boss items (hidden initially)
        this._bossItems = [];
        let bossY = curY;
        bossTypes.forEach(bt => {
            const btnBg = this.add.rectangle(panelX + panelW/2, bossY, panelW - 6, itemH - 2, 0x120e1a, 0.9)
                .setStrokeStyle(0.5, 0x8844aa, 0.15).setScrollFactor(0).setDepth(D + 1)
                .setInteractive({ useHandCursor: true }).setVisible(false);
            const dot = this.add.circle(panelX + 10, bossY, 3, bt.color)
                .setScrollFactor(0).setDepth(D + 2).setVisible(false);
            const label = this.add.text(panelX + 17, bossY, bt.name, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#bb88cc'
            }).setOrigin(0, 0.5).setScrollFactor(0).setDepth(D + 2).setVisible(false);
            
            btnBg.on('pointerover', () => btnBg.setFillStyle(0x1e1428));
            btnBg.on('pointerout', () => btnBg.setFillStyle(0x120e1a));
            btnBg.on('pointerdown', () => {
                AudioManager.uiClick();
                this._spawnSimBoss(bt);
            });
            
            this._bossItems.push(btnBg, dot, label);
            bossY += itemH;
        });
        this._bossBottomY = bossY;
        
        // Store curY for controls that shift when boss panel expands
        this._controlsBaseY = curY;
        
        curY += 4;
        add(this.add.rectangle(panelX + panelW/2, curY, panelW - 8, 1, 0x22ffcc, 0.2));
        curY += 6;
        
        // Clear all button
        this._clearBg = addD(this.add.rectangle(panelX + panelW/2, curY, panelW - 6, itemH - 2, 0x1a1a0e, 0.9)
            .setStrokeStyle(0.5, 0xaaaa44, 0.3).setInteractive({ useHandCursor: true }), 1);
        this._clearTxt = add(this.add.text(panelX + panelW/2, curY, 'CLEAR ALL', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#aaaa44'
        }).setOrigin(0.5));
        this._clearBg.on('pointerover', () => this._clearBg.setFillStyle(0x2a2a1a));
        this._clearBg.on('pointerout', () => this._clearBg.setFillStyle(0x1a1a0e));
        this._clearBg.on('pointerdown', () => { AudioManager.uiClick(); this._clearAllEnemies(); });
        this._clearBaseY = curY;
        curY += itemH + 2;
        
        // Leave button
        this._leaveBg = addD(this.add.rectangle(panelX + panelW/2, curY, panelW - 6, itemH, 0x2a0e0e, 0.9)
            .setStrokeStyle(1, 0xaa4444, 0.4).setInteractive({ useHandCursor: true }), 1);
        this._leaveTxt = add(this.add.text(panelX + panelW/2, curY, 'LEAVE SIM', {
            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#ff6666', fontStyle: 'bold'
        }).setOrigin(0.5));
        this._leaveBg.on('pointerover', () => this._leaveBg.setFillStyle(0x3a1a1a));
        this._leaveBg.on('pointerout', () => this._leaveBg.setFillStyle(0x2a0e0e));
        this._leaveBg.on('pointerdown', () => { AudioManager.uiClick(); this._leaveSim(); });
        this._leaveBaseY = curY;
    }
    
    _toggleBossPanel(show) {
        const itemH = 16;
        const bossCount = this._bossItems.length / 3; // 3 objects per boss (bg, dot, label)
        const shift = show ? bossCount * itemH : 0;
        const panelW = 76, panelX = 4;
        
        // Show/hide boss items
        this._bossItems.forEach(item => item.setVisible(show));
        
        // Shift controls down/up
        const sep1Y = this._controlsBaseY + shift + 4;
        const clearY = sep1Y + 6;
        const leaveY = clearY + itemH + 2;
        
        this._clearBg.setPosition(panelX + panelW/2, clearY);
        this._clearTxt.setPosition(panelX + panelW/2, clearY);
        this._leaveBg.setPosition(panelX + panelW/2, leaveY);
        this._leaveTxt.setPosition(panelX + panelW/2, leaveY);
        
        // Resize background
        const totalH = leaveY - 50 + 14;
        this._simPanelBg.setPosition(panelX + panelW/2, 50 + totalH/2);
        this._simPanelBg.setDisplaySize(panelW, totalH);
    }
    
    _spawnSimBoss(bt) {
        const WORLD = 800, margin = 60;
        // Spawn boss at random position away from player
        let sx, sy;
        do {
            sx = margin + Math.random() * (WORLD - margin*2);
            sy = margin + Math.random() * (WORLD - margin*2);
        } while (Phaser.Math.Distance.Between(sx, sy, this.player.x, this.player.y) < 150);
        
        // Spawn base boss type with overrides
        const cfg = CONFIG.enemyTypes.boss;
        if (!cfg) return;
        
        SpriteManager.buildEnemySheet(this, 'boss');
        const sheetKey = 'enemy_boss_sheet';
        const hasSheet = this.textures.exists(sheetKey);
        if (!hasSheet) SpriteManager.getTexture(this, 'enemy_boss');
        
        const e = this.physics.add.sprite(sx, sy, hasSheet ? sheetKey : 'enemy_boss');
        const hpMult = bt.hpMult || 1;
        const spdMult = bt.spdMult || 1;
        e.setDisplaySize(cfg.size, cfg.size).setDepth(20);
        e.enemyType = 'boss';
        e.hasAnimSheet = hasSheet;
        e.hp = Math.round(cfg.health * hpMult);
        e.maxHp = e.hp;
        e.canAttack = true;
        e.setCollideWorldBounds(true);
        e.setTint(bt.color);
        e._bossLabel = bt.name;
        
        if (hasSheet) {
            const idleKey = 'enemy_boss_idle';
            if (this.anims.exists(idleKey)) e.anims.play(idleKey, true);
        }
        
        e.aiState = 'chase';
        e.stuckTimer = 0;
        e.lastPos = { x: sx, y: sy };
        
        e.setAlpha(0).setScale(0.3);
        this.tweens.add({ targets: e, alpha: 1, scale: 1, duration: 400 });
        this.enemies.add(e);
        DynamicShadows.add(this, e, { offsetY: 8, scale: 0.6, alpha: 0.15 });
        
        // Boss name blurb
        Blurbs.show(this, e, bt.name.toUpperCase(), { color: '#' + bt.color.toString(16).padStart(6, '0'), fontSize: 12, duration: 1500 });
    }
    
    _spawnSimEnemy(type) {
        const WORLD = 800, margin = 40;
        const side = Math.floor(Math.random() * 4);
        let sx, sy;
        if (side === 0) { sx = margin + Math.random() * (WORLD - margin*2); sy = margin; }
        else if (side === 1) { sx = margin + Math.random() * (WORLD - margin*2); sy = WORLD - margin; }
        else if (side === 2) { sx = margin; sy = margin + Math.random() * (WORLD - margin*2); }
        else { sx = WORLD - margin; sy = margin + Math.random() * (WORLD - margin*2); }
        this.spawnEnemy(sx, sy, type);
    }
    
    _clearAllEnemies() {
        this._latchedSkitterlings = [];
        this.enemies.getChildren().forEach(e => {
            if (e.active) {
                if (e._telegraphGfx) { e._telegraphGfx.destroy(); }
                DynamicShadows.remove(this, e);
                e.destroy();
            }
        });
        this._dpsLog = [];
        this._totalDamage = 0;
        this._dpsValue = 0;
        this.lockedTarget = null;
        this.target = null;
    }
    
    _stumbleEnemy(e) { EnemyAI._stumbleEnemy(this, e); }

    
    // NOTE: _flickerAttack is no longer called — flicker is contact-damage only via enemyHitPlayer.
    // Method preserved per codebase policy (do not remove).
    // Flicker blade attack — wind up, triple slash, follow-through (CubeSimScene)
    _flickerAttack(e, cfg, angle) { EnemyAI._flickerAttack(this, e, cfg, angle); }

    
    // Flicker blade severance — shot arms off, becomes acid-trailing maimed variant (CubeSimScene)
    _flickerMaimCheck(enemy) { EnemyAI._flickerMaimCheck(this, enemy); }

    
    _limbLossToCrawler(enemy, bulletX, bulletY) { EnemyAI._limbLossToCrawler(this, enemy, bulletX, bulletY); }

    
    _createModPanel() {
        const W = CONFIG.width;
        const panelW = 76, panelX = W - panelW - 4, panelY = 50;
        const itemH = 15;
        const D = 150;
        
        if (!this._modPanelItems) this._modPanelItems = [];
        const add = (obj) => { obj.setScrollFactor(0).setDepth(D + 2); this._modPanelItems.push(obj); return obj; };
        const addBg = (obj) => { obj.setScrollFactor(0).setDepth(D); this._modPanelItems.push(obj); return obj; };
        const addBtn = (obj) => { obj.setScrollFactor(0).setDepth(D + 1); this._modPanelItems.push(obj); return obj; };
        
        // Modifiers definition
        const modSections = [
            { label: 'APPLY TO ALL', items: [
                { name: 'Shield All', color: '#4488ff', action: () => this._modApplyShieldAll() },
                { name: 'Bleed All', color: '#cc2222', action: () => this._modApplyDOT('bleed', 15, 5000) },
                { name: 'Burn All', color: '#ff6622', action: () => this._modApplyDOT('burn', 15, 5000) },
                { name: 'Poison All', color: '#44cc44', action: () => this._modApplyDOT('poison', 10, 5000) },
                { name: 'Heal All', color: '#44ffaa', action: () => this._modHealAll() },
            ]},
            { label: 'SPAWN MODS', items: [
                { name: 'Shielded', color: '#4488ff', toggle: 'shielded' },
                { name: 'HP ×1', color: '#66ccaa', cycle: 'hpMult', values: [1, 2, 3, 5], labels: ['HP ×1','HP ×2','HP ×3','HP ×5'] },
                { name: 'SPD ×1', color: '#ccaa44', cycle: 'speedMult', values: [1, 0.5, 1.5, 2, 3], labels: ['SPD ×1','SPD ½','SPD 1.5','SPD ×2','SPD ×3'] },
            ]}
        ];
        
        // Calculate total height
        let totalItems = 0;
        modSections.forEach(sec => { totalItems += 1 + sec.items.length; });
        const panelH = totalItems * itemH + 16;
        
        // Background
        addBg(this.add.rectangle(panelX + panelW/2, panelY + panelH/2, panelW, panelH, 0x0a0e14, 0.92)
            .setStrokeStyle(1, 0x22ffcc, 0.3));
        
        let curY = panelY + 8;
        
        // MODIFIERS title
        add(this.add.text(panelX + panelW/2, curY, 'MODIFIERS', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#446666', fontStyle: 'bold'
        }).setOrigin(0.5));
        curY += 12;
        
        modSections.forEach(sec => {
            // Section header
            add(this.add.rectangle(panelX + panelW/2, curY, panelW - 8, 1, 0x22ffcc, 0.15));
            curY += 6;
            add(this.add.text(panelX + panelW/2, curY, sec.label, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#335555'
            }).setOrigin(0.5));
            curY += 10;
            
            sec.items.forEach(item => {
                const btnBg = addBtn(this.add.rectangle(panelX + panelW/2, curY, panelW - 6, itemH - 2, 0x0e1820, 0.9)
                    .setStrokeStyle(0.5, 0x22ffcc, 0.15).setInteractive({ useHandCursor: true }));
                const label = add(this.add.text(panelX + panelW/2, curY, item.name, {
                    fontFamily: CONFIG.font, fontSize: uiPx(6), fill: item.color
                }).setOrigin(0.5));
                
                btnBg.on('pointerover', () => btnBg.setFillStyle(0x1a2a30));
                btnBg.on('pointerout', () => {
                    // Active state color
                    if (item.toggle && this._spawnMods[item.toggle]) btnBg.setFillStyle(0x1a2a3a);
                    else btnBg.setFillStyle(0x0e1820);
                });
                
                if (item.action) {
                    // One-shot action button
                    btnBg.on('pointerdown', () => { AudioManager.uiClick(); item.action(); });
                } else if (item.toggle) {
                    // Toggle on/off
                    btnBg.on('pointerdown', () => {
                        AudioManager.uiClick();
                        this._spawnMods[item.toggle] = !this._spawnMods[item.toggle];
                        const on = this._spawnMods[item.toggle];
                        btnBg.setFillStyle(on ? 0x1a2a3a : 0x0e1820);
                        btnBg.setStrokeStyle(0.5, on ? 0x4488ff : 0x22ffcc, on ? 0.5 : 0.15);
                        label.setColor(on ? '#88ccff' : item.color);
                    });
                } else if (item.cycle) {
                    // Cycle through values
                    let idx = 0;
                    btnBg.on('pointerdown', () => {
                        AudioManager.uiClick();
                        idx = (idx + 1) % item.values.length;
                        this._spawnMods[item.cycle] = item.values[idx];
                        label.setText(item.labels[idx]);
                        const active = idx > 0;
                        btnBg.setStrokeStyle(0.5, active ? 0xccaa44 : 0x22ffcc, active ? 0.5 : 0.15);
                    });
                }
                
                curY += itemH;
            });
        });
    }
    
    _modApplyShieldAll() {
        const sc = CONFIG.shieldConfig;
        this.enemies.getChildren().forEach(e => {
            if (!e.active || e._dying || e.hasShield) return;
            e.shieldHP = sc.baseHP + 40;
            e.shieldMaxHP = e.shieldHP;
            e.hasShield = true;
            Blurbs.show(this, e, 'SHIELDED', { color: '#4488ff', fontSize: 8, duration: 400 });
        });
    }
    
    _modApplyDOT(type, dmg, duration) {
        this.enemies.getChildren().forEach(e => {
            if (!e.active || e._dying) return;
            DOTManager.apply(this, e, type, dmg, duration, 'sim_mod');
        });
    }
    
    _modHealAll() {
        this.enemies.getChildren().forEach(e => {
            if (!e.active || e._dying) return;
            e.hp = e.maxHp;
            Blurbs.show(this, e, 'HEALED', { color: '#44ffaa', fontSize: 8, duration: 400 });
        });
    }
    
    spawnEnemy(x, y, type = 'husk') {
        const mods = this._spawnMods || { hpMult: 1, speedMult: 1, shielded: false };
        return EnemyManager.createEnemy(this, x, y, type, { hpMult: mods.hpMult, speedMult: mods.speedMult, forceShield: mods.shielded });
    }
    
    update(time, delta) {
        if (!this.player || this.state.dead || this._leaving) return;
        
        // Cache equipment stats each frame
        this._eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        
        // Consumable system (channels, AOE zones)
        ConsumableSystem.update(this, delta, this.player);
        
        // DOT system — tick player DOTs and render debuff HUD
        DOTSystem.updatePlayer(this, delta);
        DOTSystem.renderDebuffHUD(this);
        
        // Cube Metabolized: passive HP regen (mark conditional)
        const _cubeRegen = this.state.survivorMods?.conditionals;
        if (_cubeRegen && _cubeRegen.cubeRegenRate > 0) {
            this._cubeRegenTimer = (this._cubeRegenTimer || 0) + delta;
            if (this._cubeRegenTimer >= _cubeRegen.cubeRegenRate) {
                this._cubeRegenTimer -= _cubeRegen.cubeRegenRate;
                if (this.state.health < this.state.maxHealth && this.state.health > 0) {
                    this.state.health = Math.min(this.state.maxHealth, this.state.health + (_cubeRegen.cubeRegenAmount || 1));
                }
            }
        }
        
        let vx = 0, vy = 0;
        if (this.keys.a.isDown || this.keys.left.isDown) vx -= 1;
        if (this.keys.d.isDown || this.keys.right.isDown) vx += 1;
        if (this.keys.w.isDown || this.keys.up.isDown) vy -= 1;
        if (this.keys.s.isDown || this.keys.down.isDown) vy += 1;
        
        const touch = InputManager.getVelocity(this, CONFIG.player.speed);
        if (Math.abs(touch.rawX) > 0.05 || Math.abs(touch.rawY) > 0.05) { vx = touch.rawX; vy = touch.rawY; }
        
        const len = Math.sqrt(vx*vx + vy*vy);
        if (len > 1) { vx /= len; vy /= len; }
        
        if (!this.isDodging) {
            const speedMult = (this._eqStats.moveSpeed / 100) * (1 + (this._speedBoost || 0)) * (this._channelSpeedMult || 1) * (this.state.survivorMods?.speedMultiplier || 1);
            this.player.setVelocity(vx * CONFIG.player.speed * speedMult, vy * CONFIG.player.speed * speedMult);
        }
        
        this.player.x = Math.round(this.player.x);
        this.player.y = Math.round(this.player.y);
        
        SpriteManager.updatePlayerAnimation(this.player, vx, vy, this);
        this.player.setDepth(10 + this.player.y * 0.01);
        
        this.findTarget();
        this.updateAim();
        CombatSystem.updateFlairEffects(this);
        this.autoMelee();
        this.autoShoot();
        
        // === DOT + SIGNATURE SYSTEMS ===
        DOTManager.update(this, delta, (e) => this.killEnemy(e));
        DOTManager.renderEnemyDebuffs(this);
        DOTSystem.updatePlayer(this, delta);
        DOTSystem.renderDebuffHUD(this);
        
        if (this._eqStats.signatures) {
            const parasitic = this._eqStats.signatures.find(s => s.effect === 'parasiticRounds');
            if (parasitic) SignatureEffects.updateParasiticRounds(this, this.state, parasitic);
        }
        
        // PlayerStatusIcons.update(this); // disabled — HUD shows buffs
        DynamicShadows.update(this);
        
        this.updateEnemies(delta);
        this._updateDPS(time);
        
        // Auto-heal when no combat for 3s
        if (time - this._lastCombatTime > 3000 && this.state.health < this.state.maxHealth) {
            this.state.health = Math.min(this.state.maxHealth, this.state.health + delta * 0.05);
            this.hud.updateHP(this.state.health, this.state.maxHealth);
        }
        
        if (this._reloadText && this.player) {
            this._reloadText.x = this.player.x;
            this._reloadText.y = this.player.y - 30;
        }
    }
    
    findTarget() {
        const cam = this.cameras.main, margin = 30;
        const isOnScreen = (e) => {
            const sx = e.x - cam.scrollX, sy = e.y - cam.scrollY;
            return sx >= -margin && sx <= CONFIG.width + margin && sy >= -margin && sy <= CONFIG.height + margin;
        };
        
        if (this.lockedTarget && this.lockedTarget.active) {
            if (!isOnScreen(this.lockedTarget)) { this.lockedTarget = null; }
            else {
                const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, this.lockedTarget.x, this.lockedTarget.y);
                if (d > 400) this.lockedTarget = null;
                else { this.target = this.lockedTarget; return; }
            }
        }
        
        let nearest = null, nearestDist = Infinity;
        this.enemies.getChildren().forEach(e => {
            if (!e.active || e._dying) return;
            if (!isOnScreen(e)) return;
            const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, e.x, e.y);
            if (d < nearestDist) { nearestDist = d; nearest = e; }
        });
        this.target = nearest;
        if (nearest && !this.lockedTarget) this.lockedTarget = nearest;
    }
    
    updateAim() {
        if (this.target && this.target.active) {
            this.aimAngle = Phaser.Math.Angle.Between(this.player.x, this.player.y, this.target.x, this.target.y);
            const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, this.target.x, this.target.y);
            this.reticle.setPosition(this.target.x, this.target.y).setVisible(true);
            
            if (this.lockedTarget === this.target) { this.reticle.setScale(1.2).setAlpha(0.9); }
            else { this.reticle.setScale(1.0).setAlpha(0.5); }
            
            const mRange = Math.max(this._eqStats.meleeRange || 0, CONFIG.player.meleeRange);
            const weaponRange = 130 + (this._eqStats.targetRange || 1) * 30;
            
            if (dist <= mRange) { this.reticle._drawCrosshair(0xffaa44); this.player.isArmed = false; }
            else if (dist <= weaponRange) { this.reticle._drawCrosshair(0xddccbb); this.player.isArmed = true; }
            else { this.reticle._drawCrosshair(0x666666); this.reticle.setAlpha(0.3); this.player.isArmed = false; }
        } else {
            this.reticle.setVisible(false);
            this.player.isArmed = false;
            const ml = Math.sqrt(this.moveDir.x*this.moveDir.x + this.moveDir.y*this.moveDir.y);
            if (ml > 0.1) this.aimAngle = Math.atan2(this.moveDir.y, this.moveDir.x);
        }
        
        const wt = this.player.weaponType || 'pistol';
        const armedSheetKey = 'player_sheet_armed_' + wt;
        const shouldBeArmed = this.lockedTarget && this.lockedTarget.active && this.player.isArmed;
        
        if (shouldBeArmed && this.textures.exists(armedSheetKey)) {
            if (!this.player._isArmedTexture) {
                this.player._isArmedTexture = true;
                const dir = this.player.lastDir || 'down';
                const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                this.player.setTexture(armedSheetKey, frameMap[dir] || 0).setDisplaySize(40, 40);
                if (this.player.backpack) SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, dir);
            }
        } else if (this.player._isArmedTexture) {
            this.player._isArmedTexture = false;
            const dir = this.player.lastDir || 'down';
            const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
            this.player.setTexture('player_sheet', frameMap[dir] || 0).setDisplaySize(40, 40);
            if (this.player.backpack) SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, dir);
        }
    }
    
    autoShoot() {
        if (!this.canShoot || this._reloading) return;
        if (this._magazine !== undefined && this._magazine <= 0) { this._startReload(); return; }
        
        this.canShoot = false;
        const result = CombatSystem.shoot(this, {
            state: this.state,
            equipment: this.state.equipment,
            aimAngle: this.aimAngle,
            bullets: this.bullets,
            target: this.target,
            player: this.player
        });
        
        if (result) {
            if (this._magazine !== undefined) this._magazine--;
            if (this.hud) this.hud.updateResource('mag', this._magazine);
            this.time.delayedCall(result.fireRate, () => this.canShoot = true);
        } else { this.canShoot = true; }
    }
    
    autoMelee() {
        if (!this.canMelee) return;
        const result = CombatSystem.melee(this, {
            state: this.state,
            equipment: this.state.equipment,
            player: this.player,
            enemies: this.enemies,
            onDamage: (e, dmg) => this.damageEnemy(e, dmg, 'melee')
        });
        if (result) {
            this.canMelee = false;
            this.time.delayedCall(result.cooldown, () => this.canMelee = true);
        }
    }
    
    meleeSwing(baseAngle) {
        const meleeItem = this.state.equipment && this.state.equipment.melee;
        const meleeType = meleeItem ? (meleeItem.baseId || 'blade') : 'blade';
        const sheetType = (meleeType === 'blunt') ? 'blunt' : (meleeType === 'heavy') ? 'heavy' : 'blade';
        const sheetKey = 'player_sheet_melee_' + sheetType;
        
        const angleDeg = ((baseAngle * 180 / Math.PI) + 360) % 360;
        let dir;
        if (angleDeg >= 337.5 || angleDeg < 22.5) dir = 'right';
        else if (angleDeg < 67.5) dir = 'down_right';
        else if (angleDeg < 112.5) dir = 'down';
        else if (angleDeg < 157.5) dir = 'down_left';
        else if (angleDeg < 202.5) dir = 'left';
        else if (angleDeg < 247.5) dir = 'up_left';
        else if (angleDeg < 292.5) dir = 'up';
        else dir = 'up_right';
        
        const animKey = `player_melee_${sheetType}_${dir}`;
        if (this.textures.exists(sheetKey) && this.anims.exists(animKey)) {
            const wasArmed = this.player._isArmedTexture;
            const prevTexture = wasArmed ? ('player_sheet_armed_' + (this.player.weaponType || 'pistol')) : 'player_sheet';
            this.player._isMeleeSwinging = true;
            this.player.setTexture(sheetKey);
            this.player.play(animKey);
            if (this.player.backpack) SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, dir);
            this.player.once('animationcomplete', () => {
                this.player._isMeleeSwinging = false;
                const curDir = this.player.lastDir || 'down';
                const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                this.player.setTexture(prevTexture, frameMap[curDir] || 0).setDisplaySize(40, 40);
                if (this.player.backpack) SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, curDir);
            });
        }
    }
    
    _startReload() {
        if (this._reloading) return;
        this._reloading = true;
        if (AudioManager.reload) AudioManager.reload();
        const reloadTime = this._eqStats.reloadSpeed || CONFIG.player.reloadTime || 1500;
        this._reloadText = this.add.text(this.player.x, this.player.y - 30, 'RELOADING', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#ffcc44', fontStyle: 'bold',
            stroke: '#000000', strokeThickness: 2
        }).setOrigin(0.5).setDepth(100);
        this.time.delayedCall(reloadTime, () => {
            this._reloading = false;
            this._magazine = this._maxMag;
            if (this.hud) this.hud.updateResource('mag', this._magazine);
            if (this._reloadText) { this._reloadText.destroy(); this._reloadText = null; }
        });
    }
    
    damageEnemy(enemy, dmg, source = 'bullet', bullet = null) {
        if (!enemy || !enemy.active || enemy._dying) return;
        if (bullet) {
            if (bullet.didMiss) { source = 'miss'; dmg = 0; }
            else if (bullet.isRedCrit) source = 'redcrit';
            else if (bullet.isCrit) source = 'crit';
        }
        CombatSystem.damageEnemy(this, enemy, dmg, source, this.player, this.state, this.state.equipment);
        if (dmg > 0) {
            this._dpsLog.push({ time: this.time.now, damage: dmg });
            this._totalDamage += dmg;
            this._lastCombatTime = this.time.now;
        }
        if (enemy.hp <= 0 && !enemy.hasShield) this.killEnemy(enemy);
    }
    
    killEnemy(enemy) {
        EnemyManager.killEnemy(this, enemy, {
            deathTween: (scene, e) => { scene.tweens.add({ targets: e, alpha: 0, scaleX: 0, scaleY: 0, duration: 200, onComplete: () => { if (e.active) e.destroy(); } }); }
        });
    }
    
    enemyHitPlayer(enemy) {
        EnemyManager.enemyHitPlayer(this, enemy, {
            onDeath: () => { this.state.health = this.state.maxHealth; this.hud.updateHP(this.state.health, this.state.maxHealth); Blurbs.show(this, this.player, 'SIM RESET', { color: '#22ffcc', fontSize: 12, duration: 800 }); this.player.setAlpha(0.2); this.time.delayedCall(500, () => { if (this.player.active) this.player.setAlpha(1); }); }
        });
    }
    
    updateEnemies(delta) {
        this.enemies.getChildren().forEach(e => {
            if (!e.active || e._dying) return;
            e.setDepth(10 + e.y * 0.01);
            
            // DOTSystem: tick enemy DOTs + render HP bar with debuffs
            DOTSystem.updateEnemy(this, e, delta);
            DOTSystem.ensureEnemyBar(this, e);
            
            const cfg = CONFIG.enemyTypes[e.enemyType];
            if (!cfg) return;
            
            const spdM = e._speedMult || 1;
            const distToPlayer = Phaser.Math.Distance.Between(e.x, e.y, this.player.x, this.player.y);
            const angleToPlayer = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
            
            // Stumbling enemies don't act
            if (e._stumbling) {
                e.setVelocity(e.body.velocity.x * 0.9, e.body.velocity.y * 0.9);
                SpriteManager.updateEnemyAnimation(e);
                return;
            }
            
            // === BLOOD TRAIL — crawlers leave blood drops as they drag ===
            if (e._isCrawler && e.body) {
                const spd = Math.sqrt(e.body.velocity.x ** 2 + e.body.velocity.y ** 2);
                if (spd > 5) {
                    if (!e._bloodTimer) e._bloodTimer = 0;
                    if (!e._bloodDrops) e._bloodDrops = [];
                    e._bloodTimer += delta;
                    if (e._bloodTimer > 250) { // drop every 250ms
                        e._bloodTimer = 0;
                        // Cap at 20 drops per crawler
                        if (e._bloodDrops.length >= 20) {
                            const old = e._bloodDrops.shift();
                            if (old && old.active !== false) old.destroy();
                        }
                        const bSize = 1.5 + Math.random() * 1.5;
                        const ox = (Math.random() - 0.5) * 5;
                        const oy = 3 + Math.random() * 3;
                        const drop = this.add.circle(e.x + ox, e.y + oy, bSize, 0x551010, 0.18 + Math.random() * 0.08).setDepth(1);
                        this.tweens.add({ targets: drop, alpha: 0.02, duration: 8000, onComplete: () => drop.destroy() });
                        e._bloodDrops.push(drop);
                    }
                }
            }
            
            // Acid trail — maimed flickers leave a continuous toxic slick
            if (e.enemyType === 'flicker_maimed' && e.body && this.acidPuddles) {
                const aspd = Math.sqrt(e.body.velocity.x ** 2 + e.body.velocity.y ** 2);
                const mCfg = CONFIG.enemyTypes.flicker_maimed;
                const dur = mCfg.acidDuration || 8000;
                const now = this.time.now;
                
                if (!e._acidPoints) e._acidPoints = [];
                if (!e._acidTrail) e._acidTrail = [];
                if (!e._acidGfx) e._acidGfx = this.add.graphics().setDepth(1);
                if (!e._acidTimer) e._acidTimer = 0;
                if (!e._acidPuddleTimer) e._acidPuddleTimer = 0;
                
                if (aspd > 5) {
                    e._acidTimer += delta;
                    if (e._acidTimer > 50) {
                        e._acidTimer = 0;
                        const wobX = (Math.random() - 0.5) * 3;
                        const wobY = (Math.random() - 0.5) * 2;
                        e._acidPoints.push({ x: e.x + wobX, y: e.y + 5 + wobY, t: now });
                    }
                    
                    e._acidPuddleTimer += delta;
                    if (e._acidPuddleTimer > 200) {
                        e._acidPuddleTimer = 0;
                        if (e._acidTrail.length >= 25) {
                            const old = e._acidTrail.shift();
                            if (old && old.active !== false) { this.acidPuddles.remove(old); old.destroy(); }
                        }
                        const puddle = this.physics.add.sprite(e.x, e.y + 5, '__DEFAULT');
                        puddle.setVisible(false);
                        puddle.body.setSize(16, 12);
                        puddle._acidActive = true;
                        puddle._acidDmg = mCfg.acidDamage || 2;
                        puddle._tickRate = mCfg.acidTickRate || 500;
                        this.acidPuddles.add(puddle);
                        e._acidTrail.push(puddle);
                        this.time.delayedCall(dur, () => {
                            if (puddle.active !== false) {
                                puddle._acidActive = false;
                                this.acidPuddles.remove(puddle);
                                puddle.destroy();
                            }
                        });
                    }
                }
                
                while (e._acidPoints.length > 0 && now - e._acidPoints[0].t > dur) {
                    e._acidPoints.shift();
                }
                
                const pts = e._acidPoints;
                const g = e._acidGfx;
                g.clear();
                
                if (pts.length >= 2) {
                    for (let i = 0; i < pts.length - 1; i++) {
                        const p0 = pts[i], p1 = pts[i + 1];
                        const age0 = (now - p0.t) / dur;
                        const age1 = (now - p1.t) / dur;
                        const alpha0 = Math.max(0, 1 - age0 * 0.6);
                        
                        const dx = p1.x - p0.x, dy = p1.y - p0.y;
                        const len = Math.sqrt(dx * dx + dy * dy);
                        if (len < 0.5) continue;
                        const nx = -dy / len, ny = dx / len;
                        
                        const w0 = (4 + Math.sin(i * 0.7) * 1.5) * (1 - age0 * 0.3);
                        const w1 = (4 + Math.sin((i + 1) * 0.7) * 1.5) * (1 - age1 * 0.3);
                        
                        g.fillStyle(0x2a6622, 0.35 * alpha0);
                        g.beginPath();
                        g.moveTo(p0.x + nx * w0, p0.y + ny * w0);
                        g.lineTo(p1.x + nx * w1, p1.y + ny * w1);
                        g.lineTo(p1.x - nx * w1, p1.y - ny * w1);
                        g.lineTo(p0.x - nx * w0, p0.y - ny * w0);
                        g.closePath(); g.fill();
                        
                        const cw0 = w0 * 0.55, cw1 = w1 * 0.55;
                        g.fillStyle(0x44aa33, 0.45 * alpha0);
                        g.beginPath();
                        g.moveTo(p0.x + nx * cw0, p0.y + ny * cw0);
                        g.lineTo(p1.x + nx * cw1, p1.y + ny * cw1);
                        g.lineTo(p1.x - nx * cw1, p1.y - ny * cw1);
                        g.lineTo(p0.x - nx * cw0, p0.y - ny * cw0);
                        g.closePath(); g.fill();
                    }
                    
                    for (let i = 0; i < pts.length; i += 3) {
                        const p = pts[i];
                        const age = (now - p.t) / dur;
                        if (age > 0.8) continue;
                        const a = Math.max(0, 0.3 * (1 - age));
                        g.fillStyle(0x66dd44, a);
                        g.fillCircle(p.x + ((i * 7) % 5 - 2), p.y + ((i * 3) % 3 - 1), 1.2);
                        if (i % 6 === 0) {
                            g.fillStyle(0x338822, a * 0.7);
                            const side = (i % 12 === 0) ? 1 : -1;
                            g.fillEllipse(p.x + side * (3 + (i % 4)), p.y, 2, 1.5);
                        }
                    }
                }
            }
            
            // === ENEMY AI DISPATCH — centralized via EnemyAI ===
            const aiType = cfg.ai || 'melee';
            switch (aiType) {
                case 'ranged': case 'host':
                    EnemyAI.aiHost(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                case 'reaper':
                    EnemyAI.aiReaper(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                case 'deadlock':
                    EnemyAI.aiDeadlock(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                case 'flank':
                    EnemyAI.aiFlank(this, e, cfg, distToPlayer, angleToPlayer); break;
                case 'overseer': case 'spawner':
                    EnemyAI.aiOverseer(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                case 'boss':
                    e.setVelocity(Math.cos(angleToPlayer) * cfg.chaseSpeed * spdM, Math.sin(angleToPlayer) * cfg.chaseSpeed * spdM);
                    if (!e._slamTimer) e._slamTimer = 0;
                    e._slamTimer += delta;
                    if (e._slamTimer > 3000 && distToPlayer < 100) {
                        e._slamTimer = 0;
                        const ring = this.add.circle(e.x, e.y, 60, 0x8844aa, 0.3).setDepth(5);
                        this.tweens.add({ targets: ring, scaleX: 2, scaleY: 2, alpha: 0, duration: 400, onComplete: () => ring.destroy() });
                        if (distToPlayer < 60) {
                            CombatHelper.damagePlayer(this, 20, { label: 'SLAM', color: '#aa44ff', fontSize: 10 });
                        }
                    }
                    break;
                case 'erratic':
                    EnemyAI.aiErratic(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                case 'erratic_maimed':
                    EnemyAI.aiErraticMaimed(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                case 'skitter':
                    EnemyAI.aiSkitter(this, e, cfg, distToPlayer, angleToPlayer, delta); break;
                default:
                    EnemyAI.aiMelee(this, e, cfg, distToPlayer, angleToPlayer); break;
            }
            
            SpriteManager.updateEnemyAnimation(e);
        });
    }
    
    _enemyShoot(enemy, angle, cfg) {
        // Legacy — redirect to host quick attack
        EnemyAI._hostQuickAttack(this, enemy, cfg, angle);
    }
    
    _hostQuickAttack(e, cfg, angle) {
        if (!e.active || e._dying) return;
        const count = cfg.quickCount || 4;
        const speed = cfg.projectileSpeed || 140;
        const dmg = Math.round((cfg.damage || 10) * (e._dmgMult || 1));
        
        const armOffsets = [
            { side: -1, dist: 16, spread: -0.18 },
            { side:  1, dist: 16, spread:  0.18 },
            { side: -1, dist: 10, spread: -0.08 },
            { side:  1, dist: 10, spread:  0.08 },
        ];
        
        for (let i = 0; i < count; i++) {
            const arm = armOffsets[i % armOffsets.length];
            const a = angle + arm.spread;
            const perp = angle + Math.PI / 2;
            const ox = Math.cos(a) * arm.dist + Math.cos(perp) * arm.side * 8;
            const oy = Math.sin(a) * arm.dist + Math.sin(perp) * arm.side * 8;
            this.time.delayedCall(i * 180, () => {
                if (!e.active) return;
                e.setTint(i % 2 === 0 ? 0xbb7744 : 0xaa6633);
                this.time.delayedCall(100, () => { if (e.active) _restoreTint(e); });
                const projGfx = this.add.graphics().setDepth(25);
                projGfx.setPosition(e.x + ox, e.y + oy);
                projGfx.fillStyle(0x7a4422, 0.9);
                projGfx.fillRect(-4, -3, 8, 6);
                projGfx.fillStyle(0x6a3318, 0.7);
                projGfx.fillRect(-3, -4, 6, 2);
                projGfx.fillStyle(0x44aa33, 0.4);
                projGfx.fillRect(-1, 2, 3, 2);
                
                this.physics.add.existing(projGfx);
                projGfx.body.setVelocity(Math.cos(a) * speed, Math.sin(a) * speed);
                projGfx.body.setAllowGravity(false);
                projGfx.body.setSize(10, 8);
                projGfx._damage = dmg;
                
                // Acid drip trail — simple drops, no polyline (4 projectiles = must be cheap)
                const trailDur = cfg.toxicDuration || 5000;
                const scene = this;
                let trailCount = 0;
                
                const trailEvt = this.time.addEvent({ delay: 120, loop: true, callback: () => {
                    if (!projGfx.active) { trailEvt.destroy(); return; }
                    trailCount++;
                    const wobX = (Math.random() - 0.5) * 3;
                    const wobY = (Math.random() - 0.5) * 2;
                    const drip = scene.add.ellipse(projGfx.x + wobX, projGfx.y + wobY, 5 + Math.random() * 3, 3 + Math.random() * 2, 0x44aa33, 0.35).setDepth(1);
                    scene.tweens.add({ targets: drip, alpha: 0.03, scaleX: 0.4, scaleY: 0.4, duration: trailDur,
                        onComplete: () => drip.destroy() });
                    if (trailCount % 2 === 0 && scene.acidPuddles) {
                        const pb = scene.physics.add.sprite(projGfx.x, projGfx.y, '__DEFAULT');
                        pb.setVisible(false); pb.body.setSize(12, 10);
                        pb._acidActive = true; pb._acidDmg = cfg.toxicDamage || 3; pb._tickRate = cfg.toxicTickRate || 500;
                        scene.acidPuddles.add(pb);
                        scene.time.delayedCall(trailDur, () => { if (pb.active !== false) { pb._acidActive = false; scene.acidPuddles.remove(pb); pb.destroy(); } });
                    }
                    if (trailCount > 18) trailEvt.destroy();
                }});
                
                this.physics.add.overlap(projGfx, this.player, () => {
                    CombatHelper.damagePlayer(this, dmg, {
                        color: '#aa5522', fontSize: 10, dot: 'toxic',
                        shake: { duration: 80, intensity: 0.01 },
                        iFrames: 300
                    });
                    trailEvt.destroy(); projGfx.destroy();
                });
                this.time.delayedCall(2500, () => { if (projGfx.active) { trailEvt.destroy(); projGfx.destroy(); } });
            });
        }
        Blurbs.show(this, e, 'THROW', { color: '#aa6633', fontSize: 8, duration: 400 });
    }
    
    _hostPowerAttack(e, cfg) {
        if (!e.active || e._dying) return;
        const count = cfg.powerCount || 4;
        const dmg = Math.round((cfg.damage || 10) * 1.5 * (e._dmgMult || 1));
        const blastR = cfg.blastRadius || 35;
        const px = this.player.x, py = this.player.y;
        const cam = this.cameras.main;
        
        e.setTint(0xcc4444);
        this.time.delayedCall(300, () => { if (e.active) _restoreTint(e); });
        Blurbs.show(this, e, 'BARRAGE', { color: '#cc4444', fontSize: 9, duration: 600 });
        
        for (let i = 0; i < count; i++) {
            const scatter = 55 + Math.random() * 55;
            const sa = (Math.PI * 2 / count) * i + (Math.random() - 0.5) * 0.5;
            const landX = px + Math.cos(sa) * scatter;
            const landY = py + Math.sin(sa) * scatter;
            const launchDelay = i * 250;
            const flightUpTime = 450;
            const hangTime = 500 + i * 120;
            const fallTime = 800;
            
            this.time.delayedCall(launchDelay, () => {
                if (!e.active) return;
                // Launch UP
                const chunkUp = this.add.graphics().setDepth(35);
                chunkUp.setPosition(e.x, e.y - 8);
                chunkUp.fillStyle(0x7a4422, 0.9); chunkUp.fillRect(-4, -3, 8, 6);
                chunkUp.fillStyle(0x44aa33, 0.4); chunkUp.fillRect(-1, 2, 3, 2);
                this.tweens.add({ targets: chunkUp, y: cam.scrollY - 40, scaleX: 0.4, scaleY: 0.4, alpha: 0.5, duration: flightUpTime, ease: 'Cubic.easeIn', onComplete: () => chunkUp.destroy() });
                
                this.time.delayedCall(flightUpTime, () => {
                    const totalTelegraph = hangTime + fallTime;
                    const telegraph = this.add.circle(landX, landY, blastR, 0xcc2222, 0).setDepth(2).setStrokeStyle(1.5, 0xcc2222, 0.5);
                    this.tweens.add({ targets: telegraph, fillAlpha: 0.3, duration: totalTelegraph, ease: 'Cubic.easeIn' });
                    // Stroke pulse
                    const sPulse = this.time.addEvent({ delay: 100, loop: true, callback: () => {
                        const prog = Math.min(1, (this.time.now - sPulse._st) / totalTelegraph);
                        telegraph.setStrokeStyle(1.5 + prog * 1.5, 0xcc2222, 0.4 + Math.sin(prog * 20 + this.time.now * 0.008) * 0.2 * prog);
                    }}); sPulse._st = this.time.now;
                    const outerRing = this.add.circle(landX, landY, blastR * 2.5, 0xff4444, 0).setStrokeStyle(1, 0xff4444, 0.3).setDepth(2);
                    this.tweens.add({ targets: outerRing, scaleX: blastR/(blastR*2.5), scaleY: blastR/(blastR*2.5), duration: totalTelegraph, ease: 'Cubic.easeIn', onComplete: () => outerRing.destroy() });
                    const midRing = this.add.circle(landX, landY, blastR * 1.8, 0xff6644, 0).setStrokeStyle(1, 0xff6644, 0.2).setDepth(2);
                    this.tweens.add({ targets: midRing, scaleX: blastR/(blastR*1.8), scaleY: blastR/(blastR*1.8), duration: totalTelegraph*0.8, delay: totalTelegraph*0.2, ease: 'Cubic.easeIn', onComplete: () => midRing.destroy() });
                    const cross1 = this.add.rectangle(landX, landY, blastR * 1.6, 1, 0xff3333, 0.12).setDepth(2);
                    const cross2 = this.add.rectangle(landX, landY, 1, blastR * 1.6, 0xff3333, 0.12).setDepth(2);
                    this.tweens.add({ targets: [cross1, cross2], alpha: 0.35, duration: totalTelegraph, ease: 'Cubic.easeIn' });
                    const xMark = this.add.graphics().setDepth(2);
                    xMark.lineStyle(1, 0xff4444, 0.3);
                    xMark.lineBetween(landX-4,landY-4,landX+4,landY+4);
                    xMark.lineBetween(landX+4,landY-4,landX-4,landY+4);
                    
                    this.time.delayedCall(hangTime, () => {
                        const chunkDown = this.add.graphics().setDepth(35);
                        chunkDown.setPosition(landX, cam.scrollY - 20);
                        chunkDown.fillStyle(0x7a4422, 0.9); chunkDown.fillRect(-3, -2, 6, 5);
                        chunkDown.fillStyle(0x44aa33, 0.5); chunkDown.fillRect(-1, 2, 2, 2);
                        const shadow = this.add.ellipse(landX, landY, 4, 2, 0x000000, 0.15).setDepth(1);
                        this.tweens.add({ targets: shadow, scaleX: 4, scaleY: 4, alpha: 0.3, duration: fallTime, ease: 'Cubic.easeIn', onComplete: () => shadow.destroy() });
                        
                        this.tweens.add({ targets: chunkDown, y: landY, scaleX: 2, scaleY: 2, duration: fallTime, ease: 'Cubic.easeIn',
                            onComplete: () => {
                                chunkDown.destroy(); telegraph.destroy(); cross1.destroy(); cross2.destroy(); xMark.destroy(); sPulse.destroy();
                                if (midRing.active !== false) midRing.destroy();
                                this.cameras.main.shake(100, 0.004);
                                const dToP = Phaser.Math.Distance.Between(landX, landY, this.player.x, this.player.y);
                                if (dToP < blastR) {
                                    CombatHelper.damagePlayer(this, dmg, {
                                        source: e, color: '#cc4422', fontSize: 10, label: ' BLAST',
                                        dot: 'toxic', shake: { duration: 80, intensity: 0.01 }
                                    });
                                }
                                const boom = this.add.circle(landX, landY, 5, 0xaa4422, 0.8).setDepth(25);
                                this.tweens.add({ targets: boom, scaleX: 3.5, scaleY: 3.5, alpha: 0, duration: 350, onComplete: () => boom.destroy() });
                                for (let p = 0; p < 8; p++) {
                                    const pa = Math.random() * Math.PI * 2; const pd = 8 + Math.random() * 20;
                                    const bit = this.add.circle(landX, landY, 1.5 + Math.random() * 2, p < 4 ? 0x6a3a22 : 0x44aa33, 0.8).setDepth(26);
                                    this.tweens.add({ targets: bit, x: landX + Math.cos(pa) * pd, y: landY + Math.sin(pa) * pd, alpha: 0, duration: 300, onComplete: () => bit.destroy() });
                                }
                                // Toxic zone — organic acid pool
                                const toxGfx = this.add.graphics().setDepth(1);
                                const toxBody = this.physics.add.sprite(landX, landY, '__DEFAULT');
                                toxBody.setVisible(false); toxBody.body.setSize(blastR * 1.4, blastR * 1.4);
                                toxBody._acidActive = true; toxBody._acidDmg = cfg.toxicDamage || 3; toxBody._tickRate = cfg.toxicTickRate || 500;
                                if (this.acidPuddles) this.acidPuddles.add(toxBody);
                                const toxDur = cfg.blastToxicDuration || 6000;
                                const toxStart = this.time.now; const toxR = blastR * 0.9;
                                const edgePts = 12; const edgeWobble = [];
                                for (let ep = 0; ep < edgePts; ep++) edgeWobble.push(0.7 + Math.random() * 0.6);
                                const toxRender = this.time.addEvent({ delay: 140, loop: true, callback: () => {
                                    const age = (this.time.now - toxStart) / toxDur;
                                    if (age >= 1) { toxRender.destroy(); toxGfx.destroy(); if (this.acidPuddles) this.acidPuddles.remove(toxBody); toxBody.destroy(); return; }
                                    toxGfx.clear();
                                    const fade = age < 0.4 ? 1 : 1 - (age - 0.4) / 0.6;
                                    const r = toxR * (1 - age * 0.2); const t = this.time.now * 0.001;
                                    // Outer irregular blob
                                    toxGfx.fillStyle(0x2a6622, 0.25 * fade); toxGfx.beginPath();
                                    for (let ep = 0; ep < edgePts; ep++) {
                                        const ea = (Math.PI * 2 / edgePts) * ep;
                                        const er = r * 1.2 * edgeWobble[ep] * (1 + Math.sin(t * 1.5 + ep) * 0.08);
                                        const ex = landX + Math.cos(ea) * er, ey = landY + Math.sin(ea) * er * 0.7;
                                        if (ep === 0) toxGfx.moveTo(ex, ey); else toxGfx.lineTo(ex, ey);
                                    }
                                    toxGfx.closePath(); toxGfx.fill();
                                    // Inner core
                                    toxGfx.fillStyle(0x44aa33, 0.35 * fade); toxGfx.beginPath();
                                    for (let ep = 0; ep < edgePts; ep++) {
                                        const ea = (Math.PI * 2 / edgePts) * ep;
                                        const er = r * 0.7 * edgeWobble[ep] * (1 + Math.sin(t * 2 + ep * 1.3) * 0.1);
                                        const ex = landX + Math.cos(ea) * er, ey = landY + Math.sin(ea) * er * 0.7;
                                        if (ep === 0) toxGfx.moveTo(ex, ey); else toxGfx.lineTo(ex, ey);
                                    }
                                    toxGfx.closePath(); toxGfx.fill();
                                    // Center hotspot
                                    toxGfx.fillStyle(0x55cc44, 0.2 * fade);
                                    toxGfx.fillEllipse(landX + Math.sin(t * 3) * 3, landY + Math.cos(t * 2) * 2, r * 0.5, r * 0.35);
                                    // Bubbles
                                    const bCount = Math.floor(5 * fade);
                                    for (let b = 0; b < bCount; b++) {
                                        const ba = (t * 0.8 + b * 1.3) % (Math.PI * 2);
                                        const bd = r * 0.3 + Math.sin(ba * 2.5 + b) * r * 0.35;
                                        toxGfx.fillStyle(0x77ee55, 0.25 * fade);
                                        toxGfx.fillCircle(landX + Math.cos(ba) * bd, landY + Math.sin(ba) * bd * 0.7, 1 + Math.sin(t * 3 + b * 2) * 0.5);
                                    }
                                    // Edge drip tendrils
                                    for (let ep = 0; ep < edgePts; ep += 3) {
                                        if (edgeWobble[ep] > 1.0) {
                                            const ea = (Math.PI * 2 / edgePts) * ep;
                                            const er = r * 1.3 * edgeWobble[ep];
                                            const ex = landX + Math.cos(ea) * er, ey = landY + Math.sin(ea) * er * 0.7;
                                            toxGfx.fillStyle(0x338822, 0.2 * fade);
                                            toxGfx.fillEllipse(ex + Math.cos(ea) * 3, ey + Math.sin(ea) * 2, 2, 1.5);
                                        }
                                    }
                                }});
                                
                                // Skitterlings from impact
                                const skitCount = 1 + (Math.random() < 0.5 ? 1 : 0);
                                for (let sk = 0; sk < skitCount; sk++) {
                                    this.time.delayedCall(200 + sk * 300, () => {
                                        if (this.enemies.getChildren().length >= 30) return;
                                        const skA = Math.random() * Math.PI * 2;
                                        const skit = this.spawnEnemy(landX + Math.cos(skA) * 8, landY + Math.sin(skA) * 8, 'skitterling');
                                        if (skit) {
                                            this.tweens.killTweensOf(skit);
                                            skit.setAlpha(0).setScale(0.2).setTint(0x44aa33);
                                            this.tweens.add({ targets: skit, alpha: 1, scaleX: 1, scaleY: 1, duration: 250, ease: 'Back.easeOut',
                                                onComplete: () => { if (skit.active) _restoreTint(skit); }
                                            });
                                        }
                                    });
                                }
                            }
                        });
                    });
                });
            });
        }
    }
    
    
    tapTarget(px, py) {
        const worldX = px + this.cameras.main.scrollX, worldY = py + this.cameras.main.scrollY;
        if (this.lockedTarget && this.lockedTarget.active) {
            const d = Phaser.Math.Distance.Between(worldX, worldY, this.lockedTarget.x, this.lockedTarget.y);
            if (d < 30) { this.lockedTarget = null; this.target = null; return true; }
        }
        let nearest = null, nearestDist = 150;
        this.enemies.getChildren().forEach(e => {
            if (!e.active || e === this.lockedTarget) return;
            const d = Phaser.Math.Distance.Between(worldX, worldY, e.x, e.y);
            if (d < nearestDist) { nearestDist = d; nearest = e; }
        });
        if (nearest) {
            this.lockedTarget = nearest;
            this.target = nearest;
            const ring = this.add.circle(nearest.x, nearest.y, 18, 0xffffff, 0).setStrokeStyle(2, 0xff4444, 0.8).setDepth(30);
            this.tweens.add({ targets: ring, scaleX: 1.8, scaleY: 1.8, alpha: 0, duration: 200, onComplete: () => ring.destroy() });
            return true;
        }
        return false;
    }
    
    // === CS REAPER ATTACKS (simplified for CubeSim - SIM RESET on player death) ===
    _reaperSwapSprite(e, attackType, frame) {
        SpriteManager.buildEnemySheet(this, attackType);
        const atkKey = `enemy_${attackType}_sheet`;
        const walkKey = 'enemy_reaper_sheet';
        if (!this.textures.exists(atkKey)) return () => {};
        const dir = e._lastDir || 0;
        try { e.anims.stop(); } catch(x) {}
        e.setTexture(atkKey, dir * 3 + (frame || 0));
        return () => {
            if (!e.active) return;
            try { e.anims.stop(); } catch(x) {}
            e.setTexture(walkKey, 0);
            try { e.anims.play('enemy_reaper_walk_down', true); } catch(ex) {}
        };
    }
    
    _reaperLightArc(e, cfg, angle) {
        if (!e.active || e._dying) return;
        e._reaperBuilding = true; e.setVelocity(0, 0);
        const range = cfg.lightArcRange || 65, arcAngle = cfg.lightArcAngle || 1.1;
        const dmg = Math.round((cfg.lightArcDamage || 16) * (e._dmgMult || 1));
        const scene = this;
        const buildTime = TelegraphSystem.getDuration('fast');
        const revert = EnemyAI._reaperSwapSprite(this, e, 'reaper_slash', 0);
        // Telegraph
        const tel = TelegraphSystem.create(scene, {
            shape: 'cone', tier: 'fast', color: 'neutral',
            source: e, radius: range, angle: angle, arc: arcAngle * 2
        });
        e._activeTelegraph = tel;
        this.time.delayedCall(buildTime, () => {
            if (!e.active || e._dying) { e._reaperBuilding = false; revert(); return; }
            const dir = e._lastDir || 0; e.setFrame(dir * 3 + 1);
            const dToP = Phaser.Math.Distance.Between(e.x, e.y, scene.player.x, scene.player.y);
            const aToP = Math.atan2(scene.player.y - e.y, scene.player.x - e.x);
            let aDiff = Math.abs(aToP - angle); if (aDiff > Math.PI) aDiff = Math.PI * 2 - aDiff;
            if (dToP < range && aDiff < arcAngle) {
                CombatHelper.damagePlayer(scene, dmg, {
                    source: e, color: '#cc8844', fontSize: 9,
                    knockback: { angle: aToP, force: 120 },
                    vfx: { weight: 'medium', angle: angle }
                });
            }
            const arc = scene.add.graphics().setDepth(30);
            arc.fillStyle(0xcc8844, 0.35); arc.beginPath(); arc.moveTo(e.x, e.y);
            for (let s = 0; s <= 6; s++) { const a = angle - arcAngle + (arcAngle * 2 / 6) * s; arc.lineTo(e.x + Math.cos(a) * range, e.y + Math.sin(a) * range); }
            arc.closePath(); arc.fill();
            scene.tweens.add({ targets: arc, alpha: 0, duration: 200, onComplete: () => arc.destroy() });
            scene.time.delayedCall(120, () => { if (e.active) e.setFrame((e._lastDir || 0) * 3 + 2);
                scene.time.delayedCall(200, () => { revert(); e._reaperBuilding = false; });
            });
        });
    }
    
    _reaperDash(e, cfg, angle) {
        if (!e.active || e._dying) return;
        e._reaperBuilding = true; e.setVelocity(0, 0);
        const scene = this;
        const buildTime = TelegraphSystem.getDuration('standard');
        const revert = EnemyAI._reaperSwapSprite(this, e, 'reaper_dash', 0);
        // Telegraph: line toward player
        const tel = TelegraphSystem.create(scene, {
            shape: 'line', tier: 'standard', color: 'physical',
            source: e, length: 120, angle: angle, width: 8
        });
        e._activeTelegraph = tel;
        let pc = 0;
        const wEvt = scene.time.addEvent({ delay: 160, loop: true, callback: () => {
            if (!e.active || e._dying) { wEvt.destroy(); return; }
            e.setVelocity(0, 0); // LOCKED
            e.setTint(++pc % 2 === 0 ? 0xcc4422 : 0xaa6633);
            const dust = scene.add.circle(e.x + (Math.random()-0.5)*12, e.y + 20, 2, 0x998877, 0.4).setDepth(1);
            scene.tweens.add({ targets: dust, alpha: 0, scaleX: 2.5, scaleY: 1.5, y: dust.y - 6, duration: 300, onComplete: () => dust.destroy() });
        }});
        this.time.delayedCall(buildTime, () => {
            wEvt.destroy();
            if (!e.active || e._dying) { e._reaperBuilding = false; revert(); return; }
            _restoreTint(e);
            const dashAngle = Phaser.Math.Angle.Between(e.x, e.y, scene.player.x, scene.player.y);
            e._reaperDashing = true;
            e.setVelocity(Math.cos(dashAngle) * (cfg.dashSpeed || 280), Math.sin(dashAngle) * (cfg.dashSpeed || 280));
            e.setTint(0xff6644);
            e.setFrame((e._lastDir || 0) * 3 + 1);
            scene.time.delayedCall(cfg.dashDuration || 300, () => {
                if (!e.active) return;
                e.setVelocity(0, 0); _restoreTint(e); e._reaperDashing = false; e._reaperBuilding = false;
                e.setFrame((e._lastDir || 0) * 3 + 2);
                scene.time.delayedCall(250, () => revert());
                const d2 = Phaser.Math.Distance.Between(e.x, e.y, scene.player.x, scene.player.y);
                if (d2 < 50) {
                    const dmg = Math.round((cfg.dashDamage || 28) * (e._dmgMult || 1));
                    const kbA = Math.atan2(scene.player.y - e.y, scene.player.x - e.x);
                    CombatHelper.damagePlayer(scene, dmg, {
                        source: e, color: '#cc4422', fontSize: 11,
                        knockback: { angle: kbA, force: 200 },
                        vfx: { weight: 'heavy', angle: dashAngle },
                        shake: { duration: 100, intensity: 0.005 }
                    });
                }
            });
        });
    }
    
    _reaperWhirlwind(e, cfg) {
        if (!e.active || e._dying) return;
        e._reaperBuilding = true; e.setVelocity(0, 0);
        const scene = this, radius = cfg.whirlwindRadius || 55;
        const tickDmg = Math.round((cfg.whirlwindDamage || 4) * (e._dmgMult || 1));
        const spinDur = cfg.whirlwindDuration || 1200, ticks = cfg.whirlwindTicks || 3;
        const buildTime = TelegraphSystem.getDuration('fast');
        e.setTint(0xdd8833);
        // Telegraph
        const tel = TelegraphSystem.create(scene, {
            shape: 'circle', tier: 'fast', color: 'neutral',
            source: e, radius: radius
        });
        e._activeTelegraph = tel;
        this.time.delayedCall(buildTime, () => {
            if (!e.active || e._dying) { e._reaperBuilding = false; return; }
            // Swap to spin sprite
            SpriteManager.buildEnemySheet(scene, 'reaper_spin');
            const spinKey = 'enemy_reaper_spin_sheet', walkKey = 'enemy_reaper_sheet';
            if (scene.textures.exists(spinKey)) { try { e.anims.stop(); } catch(x) {} e.setTexture(spinKey, 0); }
            const spinGfx = scene.add.graphics().setDepth(25);
            let elapsed = 0, tc = 0, sf = 0; const tickInt = spinDur / ticks;
            const sEvt = scene.time.addEvent({ delay: 50, loop: true, callback: () => {
                if (!e.active || e._dying) { sEvt.destroy(); spinGfx.destroy(); e._reaperBuilding = false; return; }
                e.setVelocity(0, 0); // LOCKED during spin
                elapsed += 50; const prog = elapsed / spinDur;
                const nf = Math.floor(elapsed / 100) % 3;
                if (nf !== sf) { sf = nf; e.setFrame((e._lastDir || 0) * 3 + sf); }
                spinGfx.clear(); const ba = prog * Math.PI * 4;
                for (let i = 0; i < 3; i++) { const a = ba + (Math.PI * 2 / 3) * i;
                    spinGfx.lineStyle(2, 0xcc8844, 0.4 * (1 - prog * 0.5));
                    spinGfx.beginPath(); spinGfx.moveTo(e.x + Math.cos(a) * 8, e.y + Math.sin(a) * 8);
                    spinGfx.lineTo(e.x + Math.cos(a) * radius, e.y + Math.sin(a) * radius); spinGfx.stroke(); }
                spinGfx.lineStyle(1, 0xdd8833, 0.25); spinGfx.strokeCircle(e.x, e.y, radius);
                if (elapsed >= tickInt * (tc + 1)) { tc++;
                    const d2 = Phaser.Math.Distance.Between(e.x, e.y, scene.player.x, scene.player.y);
                    if (d2 < radius) {
                        const kbA = Math.atan2(scene.player.y - e.y, scene.player.x - e.x);
                        CombatHelper.damagePlayer(scene, tickDmg, {
                            source: e, color: '#dd8833', fontSize: 8,
                            knockback: { angle: kbA, force: 100 },
                            shake: { duration: 60, intensity: 0.003 },
                            iFrames: 200
                        });
                    }
                }
                if (elapsed >= spinDur) { sEvt.destroy(); spinGfx.destroy(); e._reaperBuilding = false; _restoreTint(e);
                    if (scene.textures.exists(walkKey)) { try { e.anims.stop(); } catch(x) {} e.setTexture(walkKey, 0); try { e.anims.play('enemy_reaper_walk_down', true); } catch(x2) {} }
                }
            }});
        });
    }
    
    _reaperDrop(e, cfg) {
        if (!e.active || e._dying) return;
        e._reaperBuilding = true; e.setVelocity(0, 0);
        const scene = this, blastR = cfg.dropBlastRadius || 45;
        const dmg = Math.round((cfg.dropDamage || 22) * (e._dmgMult || 1));
        e.setTint(0xff6622);
        Blurbs.show(this, e, 'LEAP', { color: '#ff6622', fontSize: 10, duration: 800 });
        // Crouch sprite
        SpriteManager.buildEnemySheet(scene, 'reaper_crouch');
        const crouchKey = 'enemy_reaper_crouch_sheet', walkKey = 'enemy_reaper_sheet';
        const dir = e._lastDir || 0;
        if (scene.textures.exists(crouchKey)) { try { e.anims.stop(); } catch(x) {} e.setTexture(crouchKey, dir * 3); 
            scene.time.delayedCall((cfg.dropBuildup||1800)*0.33, () => { if (e.active) e.setFrame(dir * 3 + 1); });
            scene.time.delayedCall((cfg.dropBuildup||1800)*0.66, () => { if (e.active) e.setFrame(dir * 3 + 2); });
        }
        // Telegraph: TelegraphSystem circle during crouch
        const buildTime = TelegraphSystem.getDuration('heavy');
        const tel = TelegraphSystem.create(scene, {
            shape: 'circle', tier: 'heavy', color: 'fire',
            source: e, radius: blastR
        });
        e._activeTelegraph = tel;
        this.time.delayedCall(buildTime, () => {
            if (!e.active || e._dying) { e._reaperBuilding = false; return; }
            const landX = scene.player.x, landY = scene.player.y;
            const cam = scene.cameras.main;
            if (e.body) e.body.enable = false;
            scene.tweens.add({ targets: e, y: cam.scrollY - 60, alpha: 0.3, scaleX: 0.5, scaleY: 0.5, duration: 450, ease: 'Quad.easeIn',
                onComplete: () => {
                    e.setVisible(false);
                    const tel = scene.add.circle(landX, landY, blastR, 0xff4422, 0).setDepth(2).setStrokeStyle(2, 0xff4422, 0.5);
                    scene.tweens.add({ targets: tel, fillAlpha: 0.25, duration: 1200, ease: 'Cubic.easeIn' });
                    const oRing = scene.add.circle(landX, landY, blastR * 2.5, 0xff6622, 0).setStrokeStyle(1, 0xff6622, 0.3).setDepth(2);
                    scene.tweens.add({ targets: oRing, scaleX: 0.4, scaleY: 0.4, duration: 1200, ease: 'Cubic.easeIn', onComplete: () => oRing.destroy() });
                    // Cleanup on scene shutdown (player dies mid-air)
                    const dropCleanup = () => {
                        if (tel && tel.scene) tel.destroy();
                        if (oRing && oRing.scene) oRing.destroy();
                    };
                    scene.events.once('shutdown', dropCleanup);
                    scene.time.delayedCall(1200, () => {
                        scene.events.off('shutdown', dropCleanup);
                        tel.destroy();
                        e.x = landX; e.y = landY; e.setVisible(true); e.setAlpha(1); e.setScale(1.8);
                        if (e.body) e.body.enable = true;
                        // Landing sprite
                        SpriteManager.buildEnemySheet(scene, 'reaper_land');
                        const landKey = 'enemy_reaper_land_sheet';
                        if (scene.textures.exists(landKey)) { try { e.anims.stop(); } catch(x) {} e.setTexture(landKey, 0);
                            scene.time.delayedCall(80, () => { if (e.active) e.setFrame(1); });
                            scene.time.delayedCall(300, () => { if (e.active) e.setFrame(2); });
                        }
                        scene.tweens.add({ targets: e, scaleX: 1, scaleY: 1, duration: 150, ease: 'Back.easeOut' });
                        scene.cameras.main.shake(200, 0.01); _restoreTint(e);
                        const d2 = Phaser.Math.Distance.Between(landX, landY, scene.player.x, scene.player.y);
                        if (d2 < blastR) {
                            const kbA = Math.atan2(scene.player.y - landY, scene.player.x - landX);
                            CombatHelper.damagePlayer(scene, dmg, {
                                source: e, color: '#ff4422', fontSize: 11, label: ' INFERNO',
                                knockback: { angle: kbA, force: 250 },
                                vfx: { weight: 'heavy', angle: kbA },
                                dot: 'burn'
                            });
                        }
                        const ring = scene.add.circle(landX, landY, 8, 0xff6622, 0.4).setDepth(25);
                        scene.tweens.add({ targets: ring, scaleX: blastR / 8, scaleY: blastR / 8, alpha: 0, duration: 400, onComplete: () => ring.destroy() });
                        for (let p = 0; p < 10; p++) { const pa = Math.random() * Math.PI * 2, pd = 5 + Math.random() * blastR * 0.8;
                            const dot = scene.add.circle(landX, landY, 2 + Math.random() * 2, [0xff4422, 0xff8833, 0xffcc44][p % 3], 0.6).setDepth(25);
                            scene.tweens.add({ targets: dot, x: landX + Math.cos(pa) * pd, y: landY + Math.sin(pa) * pd, alpha: 0, duration: 400, onComplete: () => dot.destroy() }); }
                        // Revert sprite
                        scene.time.delayedCall(500, () => {
                            if (e.active && scene.textures.exists(walkKey)) { try { e.anims.stop(); } catch(x) {} e.setTexture(walkKey, 0); try { e.anims.play('enemy_reaper_walk_down', true); } catch(x2) {} }
                            e._reaperBuilding = false;
                        });
                        // Fire zone
                        const fz = scene.physics.add.sprite(landX, landY, '__DEFAULT');
                        fz.setVisible(false); fz.body.setSize(blastR * 1.5, blastR * 1.5); fz._fireActive = true;
                        const fGfx = scene.add.graphics().setDepth(1);
                        const fStart = scene.time.now, fDur = cfg.dropBurnDuration || 4000;
                        const fEvt = scene.time.addEvent({ delay: 150, loop: true, callback: () => {
                            const age = (scene.time.now - fStart) / fDur;
                            if (age >= 1) { fEvt.destroy(); fGfx.destroy(); fz.destroy(); return; }
                            fGfx.clear(); const fade = age < 0.3 ? 1 : 1 - (age - 0.3) / 0.7;
                            fGfx.fillStyle(0xff4422, 0.12 * fade); fGfx.fillCircle(landX, landY, blastR * (1 - age * 0.3));
                        }});
                        scene.physics.add.overlap(scene.player, fz, () => {
                            if (scene.isInvincible || scene.state.dead || !fz._fireActive) return;
                            DOTSystem.applyToPlayer(scene, 'burn');
                        });
                        scene.time.delayedCall(fDur, () => { if (fz.active) { fz._fireActive = false; fz.destroy(); } });
                    });
                }
            });
        });
    }
    
    
    _detachSkitterling(e) {
        if (!e._latched && !e.active) return;
        e._latched = false;
        e._detaching = true; // blocks AI during fling
        if (this._latchedSkitterlings) this._latchedSkitterlings = this._latchedSkitterlings.filter(s => s !== e);
        const flingAngle = Math.random() * Math.PI * 2;
        e.setDepth(25);
        for (let p = 0; p < 4; p++) {
            const pa = flingAngle + (Math.random() - 0.5) * 2;
            const dot = this.add.circle(e.x, e.y, 1.5, 0x66aa44, 0.5).setDepth(25);
            this.tweens.add({ targets: dot, x: e.x + Math.cos(pa) * 10, y: e.y + Math.sin(pa) * 8, alpha: 0, duration: 200, onComplete: () => dot.destroy() });
        }
        Blurbs.show(this, e, 'POP', { color: '#66aa44', fontSize: 7 });
        this.tweens.add({ targets: e, x: e.x + Math.cos(flingAngle) * 15, y: e.y + Math.sin(flingAngle) * 10,
            scaleX: 0.3, scaleY: 0.3, alpha: 0, duration: 250, onComplete: () => { this.killEnemy(e); } });
    }
    
    _shakeOffLatched() {
        if (!this._latchedSkitterlings || this._latchedSkitterlings.length === 0) return;
        [...this._latchedSkitterlings].forEach(s => { if (s.active) EnemyAI._detachSkitterling(this, s); });
        this._latchedSkitterlings = [];
    }
    
    dodge(dx, dy) {
        if (!this.canDodge || this.isDodging) return;
        let len = Math.sqrt(dx*dx + dy*dy);
        if (len === 0) { dx = 0; dy = -1; len = 1; }
        this.canDodge = false;
        this.isDodging = true;
        this.isInvincible = true;
        this.player.setAlpha(0.4);
        EnemyAI._shakeOffLatched(this);
        this.player.setVelocity((dx/len) * 350, (dy/len) * 350);
        
        // Dodge-through impact: damage + stagger
        const impacted = new Set();
        for (let i = 0; i < 5; i++) {
            this.time.delayedCall(i * 40, () => {
                if (!this.isDodging) return;
                this.enemies.getChildren().forEach(e => {
                    if (!e.active || e._dying || impacted.has(e)) return;
                    const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, e.x, e.y);
                    if (d < 30) {
                        impacted.add(e);
                        this.damageEnemy(e, 10, 'dodge');
                        const ka = Math.atan2(e.y - this.player.y, e.x - this.player.x);
                        e.setVelocity(Math.cos(ka) * 250, Math.sin(ka) * 250);
                        if (!e.isBoss) {
                            e._staggered = true; e.setTint(0x8899cc);
                            this.time.delayedCall(800, () => { if (e.active) { e._staggered = false; _restoreTint(e); } });
                        }
                        const imp = this.add.circle(e.x, e.y, 15, 0xccddee, 0.6);
                        this.tweens.add({ targets: imp, alpha: 0, scaleX: 2, scaleY: 2, duration: 150, onComplete: () => imp.destroy() });
                    }
                });
            });
        }
        
        // Dodge end: power melee on terminus
        this.time.delayedCall(200, () => {
            this.isDodging = false;
            this.isInvincible = false;
            if (this.player.active) this.player.setAlpha(1);
            
            let strikeTarget = null, strikeDist = 35;
            this.enemies.getChildren().forEach(e => {
                if (!e.active || e._dying) return;
                const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, e.x, e.y);
                if (d < strikeDist) { strikeDist = d; strikeTarget = e; }
            });
            if (strikeTarget) {
                const baseMelee = (this._eqStats && this._eqStats.meleeDamage) || CONFIG.player.meleeDamage;
                this.damageEnemy(strikeTarget, Math.round(baseMelee * 2), 'melee');
                if (!strikeTarget.isBoss && strikeTarget.active) {
                    const ka = Math.atan2(strikeTarget.y - this.player.y, strikeTarget.x - this.player.x);
                    strikeTarget.setVelocity(Math.cos(ka) * 300, Math.sin(ka) * 300);
                    strikeTarget._staggered = true; strikeTarget.setTint(0x8899cc);
                    this.time.delayedCall(600, () => { if (strikeTarget.active) { strikeTarget._staggered = false; _restoreTint(strikeTarget); } });
                }
                this.cameras.main.shake(120, 0.012);
                const sf = this.add.circle(strikeTarget.x, strikeTarget.y, 20, 0xccddee, 0.7).setDepth(30);
                this.tweens.add({ targets: sf, alpha: 0, scaleX: 2.5, scaleY: 2.5, duration: 200, onComplete: () => sf.destroy() });
                Blurbs.show(this, strikeTarget, 'STRIKE', { color: '#ccddee', fontSize: 11, duration: 500 });
            }
        });
        this.time.delayedCall(600, () => { this.canDodge = true; });
    }
    
    spark(x, y, fromAngle, fx) { CombatSystem.spark(this, x, y, fromAngle, fx || null); }
    
    _updateDPS(time) {
        this._dpsLog = this._dpsLog.filter(e => time - e.time < 5000);
        const total = this._dpsLog.reduce((sum, e) => sum + e.damage, 0);
        this._dpsValue = total / 5;
        if (this._dpsText) this._dpsText.setText(this._dpsValue.toFixed(1));
        if (this._totalDmgText) this._totalDmgText.setText('Total: ' + this._totalDamage);
    }
    
    _squareTransitionIn() {
        const W = CONFIG.width, H = CONFIG.height;
        const cols = 12, rows = 10;
        const sw = Math.ceil(W / cols), sh = Math.ceil(H / rows);
        const container = this.add.container(0, 0).setScrollFactor(0).setDepth(500);
        const squares = [];
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const sq = this.add.rectangle(c * sw + sw/2, r * sh + sh/2, sw + 1, sh + 1, 0x0a0a0f);
                container.add(sq);
                squares.push({ sq, delay: (r + c) * 30 + Math.random() * 40 });
            }
        }
        let completed = 0;
        squares.forEach(({ sq, delay }) => {
            this.tweens.add({
                targets: sq, alpha: 0, scaleX: 0, scaleY: 0,
                duration: 250, delay, ease: 'Power2',
                onComplete: () => { completed++; if (completed >= squares.length) container.destroy(); }
            });
        });
    }
    
    _leaveSim() {
        if (this._leaving) return;
        this._leaving = true;
        
        // Grab safehouse ref BEFORE stopping this scene
        const returnKey = this._returnScene;
        const safehouse = this.scene.get(returnKey);
        
        const W = CONFIG.width, H = CONFIG.height;
        const cols = 12, rows = 10;
        const sw = Math.ceil(W / cols), sh = Math.ceil(H / rows);
        const container = this.add.container(0, 0).setScrollFactor(0).setDepth(500);
        const squares = [];
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const sq = this.add.rectangle(c * sw + sw/2, r * sh + sh/2, sw + 1, sh + 1, 0x0a0a0f).setAlpha(0);
                container.add(sq);
                squares.push({ sq, delay: (r + c) * 25 + Math.random() * 30 });
            }
        }
        let completed = 0;
        squares.forEach(({ sq, delay }) => {
            this.tweens.add({
                targets: sq, alpha: 1, scaleX: { from: 0, to: 1 }, scaleY: { from: 0, to: 1 },
                duration: 200, delay, ease: 'Power2',
                onComplete: () => {
                    completed++;
                    if (completed >= squares.length) {
                        this.scene.stop();
                        if (safehouse && safehouse._returnFromCubeSim) safehouse._returnFromCubeSim();
                        else this.scene.resume(returnKey);
                    }
                }
            });
        });
    }
}
