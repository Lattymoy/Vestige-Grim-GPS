// Vestige GPS — Test Scene
// Minimal playable scene to verify core↔renderer bridge wiring
// Player moves with WASD/touch, tap enemies to shoot, damage/death VFX display

import Phaser from 'phaser';
import { CONFIG } from '../../data/config.js';
import { CombatSystem } from '../../core/combatSystem.js';
import { CombatHelper } from '../../core/combatHelper.js';
import { EnemyManager } from '../../core/enemyManager.js';
import { EnemyAI } from '../../core/enemyAI.js';
import { DOTManager } from '../../core/dotManager.js';
import { DOTSystem } from '../../core/dotSystem.js';
import { ItemManager } from '../../core/itemManager.js';
import { RealtimeTOD } from '../../core/realtimeTOD.js';
import { Blurbs } from '../../core/blurbs.js';
import { PhaserBlurbs } from '../rendering/blurbs.js';

// TOD → ambient tint mapping
const TOD_TINTS = {
    dawn:   0xddaa88,
    midday: 0xffffff,
    dusk:   0xcc8866,
    night:  0x556688
};

export class TestScene extends Phaser.Scene {
    constructor() {
        super({ key: 'TestScene' });
    }

    create() {
        const w = this.cameras.main.width;
        const h = this.cameras.main.height;

        // Wire Blurbs renderer
        Blurbs.init(PhaserBlurbs);

        // Time of day
        const tod = RealtimeTOD.getFromClock();
        this._ambientTint = TOD_TINTS[tod] || 0xffffff;

        // Game state
        this.state = {
            health: CONFIG.player?.health || 100,
            maxHealth: CONFIG.player?.health || 100,
            equipment: {
                weapon: {
                    name: 'Rusty Pistol',
                    foundry: 'terracorp',
                    rarity: 'common',
                    stats: {
                        damage: 8,
                        fireRate: 40,
                        accuracy: 60,
                        crit: 10,
                        mag: 12,
                        reload: 50,
                        pierce: 1,
                        targetRange: 1
                    }
                },
                melee: {
                    name: 'Pipe Wrench',
                    foundry: 'scrap',
                    stats: {
                        meleeDamage: 15,
                        meleeRange: 30,
                        meleeSpeed: 40
                    }
                }
            },
            dead: false,
            survivorMods: null
        };

        // Ground
        this.add.rectangle(w / 2, h / 2, w, h, 0x1a1a1a).setDepth(0);
        // Grid lines for spatial reference
        const gridGfx = this.add.graphics().setDepth(0);
        gridGfx.lineStyle(1, 0x222222, 0.3);
        for (let x = 0; x < w; x += 32) gridGfx.lineBetween(x, 0, x, h);
        for (let y = 0; y < h; y += 32) gridGfx.lineBetween(0, y, w, y);

        // Player
        this.player = this.physics.add.sprite(w / 2, h / 2, 'player');
        this.player.setDisplaySize(12, 16);
        this.player.setDepth(20);
        this.player.setOrigin(0.5, 0.75);
        this.player.setCollideWorldBounds(true);
        if (this._ambientTint && this._ambientTint !== 0xffffff) {
            this.player.setTint(this._ambientTint);
        }

        // Player shadow
        this._playerShadow = this.add.ellipse(this.player.x, this.player.y + 4, 10, 4, 0x000000, 0.15).setDepth(1);

        // Enemy group
        this.enemies = this.physics.add.group();
        this.bullets = this.physics.add.group();
        this.acidPuddles = this.physics.add.group();

        // Spawn some enemies
        this._spawnWave();

        // Bullet ↔ enemy overlap
        this.physics.add.overlap(this.bullets, this.enemies, (bullet, enemy) => {
            if (!bullet.active || !enemy.active || enemy._dying) return;
            // Apply bullet damage
            CombatSystem.damageEnemy(this, enemy, bullet.damage || 5, 'bullet', this.player, this.state, this.state.equipment);
            // Destroy bullet
            if (bullet._bulletGfx) bullet._bulletGfx.destroy();
            bullet.destroy();
        });

        // Input: WASD + arrow keys
        this.cursors = this.input.keyboard.createCursorKeys();
        this.wasd = this.input.keyboard.addKeys('W,A,S,D');

        // Input: click/tap to shoot
        this.input.on('pointerdown', (pointer) => {
            this._shootAt(pointer.worldX, pointer.worldY);
        });

        // Track last shot time
        this._lastShot = 0;
        this.isInvincible = false;
        this.lockedTarget = null;
        this.target = null;

        // HUD
        this._hud = this.add.text(8, 8, '', {
            fontFamily: 'monospace', fontSize: '10px', color: '#44ff88',
            stroke: '#000000', strokeThickness: 2
        }).setDepth(200).setScrollFactor(0);

        this._instructions = this.add.text(w / 2, h - 20, 'WASD/arrows to move | Tap enemies to shoot', {
            fontFamily: 'monospace', fontSize: '8px', color: '#666666'
        }).setOrigin(0.5).setDepth(200).setScrollFactor(0);

        console.log('[Vestige] TestScene created — player, enemies, combat wired');
    }

    update(time, delta) {
        if (this.state.dead) return;

        // Player movement
        const speed = CONFIG.player?.speed || 100;
        let vx = 0, vy = 0;
        if (this.cursors.left.isDown || this.wasd.A.isDown) vx = -speed;
        if (this.cursors.right.isDown || this.wasd.D.isDown) vx = speed;
        if (this.cursors.up.isDown || this.wasd.W.isDown) vy = -speed;
        if (this.cursors.down.isDown || this.wasd.S.isDown) vy = speed;
        // Normalize diagonal
        if (vx && vy) { vx *= 0.707; vy *= 0.707; }
        this.player.setVelocity(vx, vy);

        // Update shadow
        this._playerShadow.setPosition(this.player.x, this.player.y + 4);

        // Update enemy AI
        this.enemies.getChildren().forEach(enemy => {
            if (!enemy.active || enemy._dying) return;
            // Simple chase toward player
            const dx = this.player.x - enemy.x;
            const dy = this.player.y - enemy.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            const cfg = CONFIG.enemyTypes?.[enemy.enemyType] || {};
            const espeed = cfg.speed || 30;
            if (dist > 20) {
                enemy.setVelocity((dx / dist) * espeed, (dy / dist) * espeed);
            } else {
                enemy.setVelocity(0, 0);
                // Contact damage
                if (enemy.canAttack && !this.isInvincible && !this.state.dead) {
                    CombatHelper.damagePlayer(this, cfg.damage || 5, {
                        label: 'BITE', color: '#ff4444',
                        shake: { duration: 60, intensity: 0.005 }
                    });
                    enemy.canAttack = false;
                    this.time.delayedCall(cfg.attackCooldown || 1000, () => {
                        if (enemy.active) enemy.canAttack = true;
                    });
                }
            }

            // Update enemy shadow
            if (enemy._shadow && enemy._shadow.active) {
                enemy._shadow.setPosition(enemy.x, enemy.y + 4);
            }
        });

        // Update bullet graphics
        this.bullets.getChildren().forEach(b => {
            if (b._updateGfx) b._updateGfx();
        });

        // Update DOTs
        DOTManager.update(this, delta);

        // HUD
        const alive = this.enemies.getChildren().filter(e => e.active && !e._dying).length;
        this._hud.setText(
            `HP: ${this.state.health}/${this.state.maxHealth}  Enemies: ${alive}`
        );

        // Respawn wave when clear
        if (alive === 0 && !this._respawnPending) {
            this._respawnPending = true;
            this.time.delayedCall(1500, () => {
                this._respawnPending = false;
                this._spawnWave();
            });
        }

        // Update flair effects
        CombatSystem._renderer?.updateFlairEffects(this);
    }

    _shootAt(worldX, worldY) {
        const now = this.time.now;
        // Same formula as CombatSystem: Math.max(80, 1200 - fireRate * 11)
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        const fireRate = Math.max(80, 1200 - (eqStats.fireRate || 1) * 11);
        if (now - this._lastShot < fireRate) return;
        this._lastShot = now;

        // Find closest enemy near tap
        let closest = null, closestDist = 80; // max targeting range
        this.enemies.getChildren().forEach(e => {
            if (!e.active || e._dying) return;
            const d = Phaser.Math.Distance.Between(worldX, worldY, e.x, e.y);
            if (d < closestDist) { closestDist = d; closest = e; }
        });

        if (!closest) {
            // Miss shot — fire bullet toward tap point
            const angle = Math.atan2(worldY - this.player.y, worldX - this.player.x);
            CombatSystem.shoot(this, {
                target: { active: true, x: worldX, y: worldY, hp: 999 },
                player: this.player,
                state: this.state,
                equipment: this.state.equipment,
                bullets: this.bullets,
                aimAngle: angle,
                forceMiss: true
            });
            return;
        }

        // Shoot at enemy
        const aimAngle = Math.atan2(closest.y - this.player.y, closest.x - this.player.x);
        CombatSystem.shoot(this, {
            target: closest,
            player: this.player,
            state: this.state,
            equipment: this.state.equipment,
            bullets: this.bullets,
            aimAngle
        });
    }

    _spawnWave() {
        const w = this.cameras.main.width;
        const h = this.cameras.main.height;
        const types = ['husk', 'runner', 'husk', 'brute', 'spitter'];
        const count = 4 + Math.floor(Math.random() * 3);

        for (let i = 0; i < count; i++) {
            const type = types[Math.floor(Math.random() * types.length)];
            // Spawn on edges
            let sx, sy;
            const edge = Math.floor(Math.random() * 4);
            switch (edge) {
                case 0: sx = Math.random() * w; sy = -10; break;      // top
                case 1: sx = Math.random() * w; sy = h + 10; break;   // bottom
                case 2: sx = -10; sy = Math.random() * h; break;      // left
                case 3: sx = w + 10; sy = Math.random() * h; break;   // right
            }

            const enemy = EnemyManager.createEnemy(this, sx, sy, type);
            if (enemy && this._ambientTint && this._ambientTint !== 0xffffff) {
                enemy.setTint(this._ambientTint);
            }
        }

        Blurbs.show(this, this.player, `Wave incoming! (${count})`, { color: '#ff8844', fontSize: 10 });
    }

    // Called by CombatHelper.damagePlayer when health <= 0
    die() {
        this.state.dead = true;
        this.player.setTint(0xff0000);
        this.player.setVelocity(0, 0);

        this.add.text(this.cameras.main.width / 2, this.cameras.main.height / 2, 'DEAD', {
            fontFamily: 'monospace', fontSize: '24px', color: '#ff2222',
            stroke: '#000000', strokeThickness: 4
        }).setOrigin(0.5).setDepth(300).setScrollFactor(0);

        this.add.text(this.cameras.main.width / 2, this.cameras.main.height / 2 + 30, 'Tap to restart', {
            fontFamily: 'monospace', fontSize: '10px', color: '#888888'
        }).setOrigin(0.5).setDepth(300).setScrollFactor(0);

        this.input.once('pointerdown', () => {
            this.scene.restart();
        });
    }
}
