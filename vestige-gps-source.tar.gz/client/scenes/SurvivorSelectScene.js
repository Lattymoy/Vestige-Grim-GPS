// Vestige GPS — SurvivorSelectScene
// Extracted from monolith lines 35384-35696
// Imports will be wired in integration pass

import { SaveManager } from '../../core/saveManager.js';
import { SurvivorGenerator } from '../../core/survivorGenerator.js';
import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { AudioManager } from '../audioManager.js';
import { SpriteManager } from '../spriteManager.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { SafehouseScene } from './SafehouseScene.js';


export class SurvivorSelectScene extends Phaser.Scene {
    constructor() { super('SurvivorSelectScene'); }

    create() {
        const W = CONFIG.width, H = CONFIG.height;
        this.add.rectangle(W/2, H/2, W, H, 0x08080e);

        // Title
        this.add.text(W/2, 26, 'CHOOSE YOUR SQUAD', {
            fontFamily: CONFIG.font, fontSize: uiPx(16), fill: '#cc8822', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(5);
        this.add.text(W/2, 46, 'Select 2 survivors to brave the wastes', {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#667788'
        }).setOrigin(0.5).setDepth(5);

        // Generate draft pool (4 cards) — starting selection is common only
        const poolSeed = Date.now();
        this._pool = [];
        for (let i = 0; i < 4; i++) {
            this._pool.push(SurvivorGenerator.generate(poolSeed + i * 7919, 'common'));
        }
        
        // ── DEBUG SURVIVOR — fully outfitted for testing ──
        const dbg = SurvivorGenerator.generate(99999, 'legendary');
        dbg.id = 'surv_debug';
        dbg.name = 'Debug';
        dbg.rank = 7;
        dbg.xp = 7500;
        dbg.runsCompleted = 55;
        dbg.kills = 520;
        dbg.meleeKills = 80;
        dbg.bestRunKills = 22;
        dbg.bossesKilled = 8;
        dbg.damageDealt = 12000;
        dbg.damageTaken = 6000;
        dbg.itemsLooted = 150;
        dbg.distanceTraveled = 20000;
        dbg.highestReach = 6;
        dbg.timeSurvived = 2400000;
        dbg.buildingsExplored = 40;
        dbg.bitsEarned = 3000;
        dbg.materialsEarned = 1200;
        dbg.cubesFound = 6;
        dbg.rareFinds = 5;
        dbg.fullLoadouts = 3;
        dbg.gymSessions = 4;
        dbg.reforges = 3;
        dbg.timesHealed = 55;
        dbg.injuriesRecovered = 2;
        dbg.consecutiveRuns = 8;
        dbg.zeroDamageRuns = 1;
        dbg.closeCallRuns = 2;
        dbg.marksEarned = 6;
        dbg.shedCharges = 2;
        dbg.anomalyEncounters = 2;
        dbg.auraUnlocked = true;
        // Complete all 9 achievements
        if (dbg.achievements) {
            dbg.achievements.forEach(ach => {
                const def = SurvivorGenerator.getAchievementDef(ach.id);
                if (def) {
                    ach.complete = true;
                    ach.progress = def.target;
                    ach.completedAt = Date.now() - 10000;
                }
            });
        }
        // Trigger mastery unlock — grants Lord of Raum title + Sovereign Flame aura
        SurvivorGenerator.checkMasteryUnlock(dbg);
        // Stack marks: born + earned + cube to test card display
        const _bornPool = SurvivorGenerator.MARKS_BORN;
        const _earnPool = SurvivorGenerator.MARKS_EARNED;
        const _cubePool = SurvivorGenerator.MARKS_CUBE;
        dbg.marks = [
            { id: 'thick_skinned', ..._bornPool.thick_skinned, origin: 'born' },
            { id: 'twice_born', ..._bornPool.twice_born, origin: 'born' },
            { id: 'raums_favorite', ..._bornPool.raums_favorite, origin: 'born' },
            { id: 'hollow_stomach', ..._bornPool.hollow_stomach, origin: 'born' },
            { id: 'phantom_step', ..._earnPool.phantom_step, origin: 'earned' },
            { id: 'scar_map', ..._earnPool.scar_map, origin: 'earned' },
            { id: 'phased_stride', ..._cubePool.phased_stride, origin: 'earned' },
            { id: 'claimed', ..._cubePool.claimed, origin: 'earned' }
        ];
        dbg.injury = { type: 'wounded', since: Date.now() - 300000, treatedAt: null, recoveryRuns: 2, recoveryMs: 20 * 60 * 1000 };
        this._pool.push(dbg);
        // ── END DEBUG ──
        
        this._selected = new Set();
        this._cardObjects = [];

        // Layout: 2 columns x 2 rows + 1 centered bottom
        const cardW = 155, cardH = 150, padX = 6, padY = 6;
        const startY = 62;
        const colX = [W/2 - cardW/2 - padX, W/2 + cardW/2 + padX];

        this._pool.forEach((surv, i) => {
            let cx, cy;
            if (i < 4) {
                const col = i % 2;
                const row = Math.floor(i / 2);
                cx = colX[col];
                cy = startY + row * (cardH + padY) + cardH / 2;
            } else {
                // 5th card centered below
                cx = W / 2;
                cy = startY + 2 * (cardH + padY) + cardH / 2;
            }

            const card = this._buildCard(surv, cx, cy, cardW, cardH);
            card.setAlpha(0);
            this.tweens.add({ targets: card, alpha: 1, duration: 400, delay: 100 + i * 80 });
            this._cardObjects.push({ surv, container: card, cx, cy, cardW, cardH, selected: false });
        });

        // Confirm button (hidden until 2 selected)
        const btnY = startY + 3 * (cardH + padY) + 16;
        this._confirmC = this.add.container(W/2, btnY).setDepth(10).setAlpha(0);
        const cbg = this.add.rectangle(0, 0, 160, 36, 0x1a3a2a, 0.9).setInteractive({ useHandCursor: true });
        this._confirmC.add(cbg);
        this._confirmC.add(this.add.rectangle(0, 0, 158, 34, 0x0e0e14));
        this._confirmText = this.add.text(0, 0, 'EMBRACE THE WASTES', {
            fontFamily: CONFIG.font, fontSize: uiPx(11), fontStyle: 'bold', fill: '#44aa66'
        }).setOrigin(0.5);
        this._confirmC.add(this._confirmText);
        cbg.on('pointerover', () => cbg.setFillStyle(0x2a4a3a, 1));
        cbg.on('pointerout', () => cbg.setFillStyle(0x1a3a2a, 0.9));
        cbg.on('pointerdown', () => this._confirmSquad());

        // Selection counter
        this._counterText = this.add.text(W/2, btnY - 18, '0 / 2 selected', {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#556677'
        }).setOrigin(0.5).setDepth(5);

        SceneTransition.fadeIn(this, 600);
    }

    _buildCard(surv, cx, cy, w, h) {
        const container = this.add.container(cx, cy).setDepth(3);
        const rDef = SurvivorGenerator.RARITIES[surv.rarity];
        const rarityHex = rDef.color;

        // Card bg
        const bg = this.add.rectangle(0, 0, w, h, 0x12121a, 0.95);
        container.add(bg);

        // Rarity border
        const border = this.add.graphics();
        border.lineStyle(1.5, rarityHex, 0.4);
        border.strokeRoundedRect(-w/2, -h/2, w, h, 3);
        container.add(border);
        container._border = border;
        container._bg = bg;
        container._rarityHex = rarityHex;

        // ── Portrait area (left side) ──
        const portX = -w/2 + 36, portY = -14;
        this._drawPortrait(container, surv, portX, portY);

        // ── Info (right side) ──
        const infoX = -w/2 + 72;

        // Name
        const nameColor = rDef.textColor;
        const cardNameText = this.add.text(infoX, -h/2 + 10, surv.name, {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: nameColor, fontStyle: 'bold'
        });
        const maxCardNameW = w/2 - infoX - 6;
        if (cardNameText.width > maxCardNameW) cardNameText.setScale(maxCardNameW / cardNameText.width, 1);
        container.add(cardNameText);

        // Rarity + Gender
        const genderLabel = surv.gender === 'unknown'
            ? (surv.unknownType ? surv.unknownType.charAt(0).toUpperCase() + surv.unknownType.slice(1) : 'Unknown')
            : surv.gender.charAt(0).toUpperCase() + surv.gender.slice(1);
        container.add(this.add.text(infoX, -h/2 + 24, `${rDef.label} | ${genderLabel}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#556677'
        }));

        // Personality
        container.add(this.add.text(infoX, -h/2 + 36, surv.personality.label, {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#778899', fontStyle: 'italic'
        }));

        // Rank
        const rankInfo = SurvivorGenerator.getRank(surv);
        container.add(this.add.text(infoX, -h/2 + 48, `Rank: ${rankInfo.label}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#667788'
        }));

        // ── Equipped title (below rank) ──
        let markStartY = -h/2 + 64;
        if (surv.equippedTitle) {
            const tDef = CONFIG.survivorTitles ? CONFIG.survivorTitles[surv.equippedTitle] : null;
            const tCol = tDef ? tDef.color : '#bbaa66';
            container.add(this.add.text(infoX, -h/2 + 60, surv.equippedTitle.toUpperCase(), {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: tCol,
                fontStyle: 'bold', letterSpacing: 1
            }));
            markStartY = -h/2 + 74;
        }

        // ── Marks ──
        let perkY = markStartY;
        const maxMarkY = h/2 - 14; // leave bottom padding
        const maxVisibleMarks = Math.floor((maxMarkY - markStartY) / 11);
        const visibleMarks = surv.marks.slice(0, maxVisibleMarks);
        const hiddenCount = surv.marks.length - visibleMarks.length;
        
        if (surv.marks.length === 0) {
            container.add(this.add.text(infoX, perkY, 'No marks', {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#3a3a3a'
            }));
        }
        visibleMarks.forEach(p => {
            const pColor = p.type === 'negative' ? '#aa4444' : p.type === 'mixed' ? '#aaaa44' : p.type === 'legendary' ? '#cc8822' : '#44aa44';
            container.add(this.add.text(infoX, perkY, p.name, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: pColor
            }));
            perkY += 11;
        });
        if (hiddenCount > 0) {
            container.add(this.add.text(infoX, perkY, `+${hiddenCount} more`, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#445566'
            }));
        }

        // Interaction
        bg.setInteractive({ useHandCursor: true });
        bg.on('pointerdown', () => this._toggleCard(surv.id));

        return container;
    }

    _drawPortrait(container, surv, cx, cy) {
        // Generate real sprite sheet for this survivor
        const custom = SurvivorGenerator.toCustomization(surv);
        const sheetKey = 'sel_sheet_' + surv.id;
        const canvas = SpriteManager.generatePlayerSheet(custom);
        
        if (this.textures.exists(sheetKey)) this.textures.remove(sheetKey);
        this.textures.addSpriteSheet(sheetKey, canvas, { frameWidth: 48, frameHeight: 48 });
        
        // Show front-facing idle frame (frame 0 = down)
        const portrait = this.add.sprite(cx, cy, sheetKey, 0);
        portrait.setDisplaySize(52, 52);
        container.add(portrait);
        
        // Subtle idle animation
        const animKey = `sel_idle_${surv.id}`;
        if (!this.anims.exists(animKey)) {
            this.anims.create({
                key: animKey,
                frames: this.anims.generateFrameNumbers(sheetKey, { start: 0, end: 2 }),
                frameRate: 3, repeat: -1
            });
        }
        portrait.play(animKey);
    }

    _toggleCard(survId) {
        const idx = this._cardObjects.findIndex(c => c.surv.id === survId);
        if (idx < 0) return;
        const card = this._cardObjects[idx];

        if (card.selected) {
            // Deselect
            card.selected = false;
            this._selected.delete(survId);
            card.container._bg.setFillStyle(0x12121a, 0.95);
            card.container._border.clear();
            card.container._border.lineStyle(1.5, card.container._rarityHex, 0.4);
            card.container._border.strokeRoundedRect(-card.cardW/2, -card.cardH/2, card.cardW, card.cardH, 3);
            card.container.setScale(1);
        } else {
            if (this._selected.size >= 2) return; // Max 2
            card.selected = true;
            this._selected.add(survId);
            card.container._bg.setFillStyle(0x1a2a1a, 1);
            card.container._border.clear();
            card.container._border.lineStyle(2.5, card.container._rarityHex, 0.9);
            card.container._border.strokeRoundedRect(-card.cardW/2, -card.cardH/2, card.cardW, card.cardH, 3);
            this.tweens.add({
                targets: card.container, scaleX: 1.03, scaleY: 1.03, duration: 120, yoyo: true
            });
        }

        AudioManager.uiClick();
        this._counterText.setText(`${this._selected.size} / 2 selected`);
        this._counterText.setColor(this._selected.size === 2 ? '#44aa66' : '#556677');
        this.tweens.add({
            targets: this._confirmC, alpha: this._selected.size === 2 ? 1 : 0, duration: 200
        });
    }

    _confirmSquad() {
        if (this._selected.size !== 2) return;

        const chosen = this._pool.filter(s => this._selected.has(s.id));
        // First chosen becomes the deployed operator
        chosen[0].deployed = true;
        const saveData = SaveManager.load();
        saveData.survivors = chosen;
        SaveManager.save(saveData);

        AudioManager.stopMusic(800);
        this.cameras.main.fadeOut(800, 0, 0, 0);
        this.time.delayedCall(800, () => this.scene.start('SafehouseScene'));
    }
}

// ============================================
// TITLE SCENE — Splash screen
// ============================================

