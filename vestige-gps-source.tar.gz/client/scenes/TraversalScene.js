// Vestige GPS — TraversalScene
// Extracted from monolith lines 76558-77656
// Imports will be wired in integration pass

import { Haptics } from '../../core/haptics.js';
import { ItemManager } from '../../core/itemManager.js';
import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { AudioManager } from '../audioManager.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { IsoRenderer } from '../isoRenderer.js';
import { SpriteManager } from '../spriteManager.js';
import { UIAtlas } from '../uiAtlas.js';
import { UIManager } from '../uiManager.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { GameScene } from './GameScene.js';
import { HavenScene } from './HavenScene.js';
import { SafehouseScene } from './SafehouseScene.js';


export class TraversalScene extends Phaser.Scene {
    constructor() { super({ key: 'TraversalScene' }); }
    
    init(data) {
        this.routeType = data.routeType || 'road';
        this.destination = data.destination || 'Unknown';
        this.locationType = data.locationType || null;
        this.destinationNode = data.destinationNode || null;
        this.distance = data.distance || 1000;
        this.playerState = data.playerState || { 
            health: 100, 
            powerAmmo: 0, 
            kills: 0, 
            bits: 0, 
            fuel: 100,
            materials: 0,
            vehicleHealth: 100,
            backpack: ItemManager.createInventory(CONFIG.inventory.backpackSlots),
            vehicle: ItemManager.createInventory(CONFIG.inventory.vehicleSlots)
        };
        // Ensure vehicleHealth exists
        if (this.playerState.vehicleHealth === undefined) this.playerState.vehicleHealth = 100;
        this.destinationNode = data.destinationNode || null;
        this.mapSeed = data.mapSeed || null;
        this.activeRoute = data.activeRoute || null;
        this.deployedSurvivor = data.deployedSurvivor || null;
        this.currentNodeId = data.currentNodeId || null;
        this.previousNodeId = data.previousNodeId || null;
        this.completedNodes = data.completedNodes || [];
        this.traveledRoutes = data.traveledRoutes || [];
        this.rescueMode = data.rescueMode || false;
    }
    
    
    create() {
        this.state = this.playerState;
        this.biome = CONFIG.currentBiome?.type || 'grassy';
        this.timeOfDay = CONFIG.timeOfDay || 'midday';
        
        // Start biome ambient audio
        try { AudioManager.playBiomeAmbient(this.biome); } catch(e) {}
        this.isDirt = this.routeType === 'dirt' || Math.random() < 0.2;
        this.roadY = CONFIG.height / 2 + 30;
        this.laneHeight = 50;
        this.lanePositions = [this.roadY - this.laneHeight, this.roadY, this.roadY + this.laneHeight];
        this.currentLane = 1;
        this.speed = 180;
        this.targetSpeed = 180;
        // Timer-based travel: duration in seconds, scaled by distance
        this.travelDuration = Math.max(8, Math.min(25, this.distance / 80));
        this.travelElapsed = 0;
        this.travelPaused = false;
        this.isTransitioning = false;
        this.breakdownTriggered = false;
        this.popupActive = false;
        this.createParallaxLayers();
        this.createRoad();
        this.createVehicle();
        this.createUI();
        this.setupInput();
        this.obstacles = this.physics.add.group();
        this.events = this.physics.add.group();
        this.supplyCrates = this.physics.add.group();
        this.spawnTimer = 0;
        this.eventTimer = 0;
        this.physics.add.overlap(this.vehicle, this.obstacles, this.hitObstacle, null, this);
        this.physics.add.overlap(this.vehicle, this.events, this.nearEvent, null, this);
        this.physics.add.overlap(this.vehicle, this.supplyCrates, this.pickupCrate, null, this);
        this.cameras.main.fadeIn(500);
    }
    
    createParallaxLayers() {
        const W = CONFIG.width, H = CONFIG.height, biome = this.biome, tod = this.timeOfDay;
        const skyPalette = { dawn: [0xffaa77, 0xff8855, 0x335577], midday: [0x6699cc, 0x5588bb, 0x4477aa], dusk: [0xff7755, 0xcc5533, 0x2a2244], night: [0x1a1a2a, 0x121222, 0x0a0a1a] };
        const sc = skyPalette[tod] || skyPalette.midday;
        this.add.rectangle(W/2, 20, W, 40, sc[0]).setDepth(0);
        this.add.rectangle(W/2, 55, W, 30, sc[1]||sc[0]).setDepth(0);
        this.add.rectangle(W/2, 85, W, 30, sc[2]||sc[1]).setDepth(0);
        
        // Sun / Moon
        if (tod === "night") {
            const mx = W-50, my = 32;
            this.add.circle(mx, my, 20, 0xeeeedd, 0.7).setDepth(0.1);
            this.add.circle(mx+6, my-2, 18, sc[0]).setDepth(0.1);
            this.add.circle(mx-2, my+3, 2, 0xddddcc, 0.3).setDepth(0.12);
            this.add.circle(mx-6, my-2, 1.5, 0xccccbb, 0.2).setDepth(0.12);
            this.add.ellipse(mx, my, 50, 40, 0xaaaacc, 0.06).setDepth(0.05);
            const starN = biome === "apocalyptic" ? 8 : 20;
            for (let i=0;i<starN;i++) this.add.circle(Phaser.Math.Between(10,W-10), Phaser.Math.Between(5,80), Math.random()>0.7?2:1, 0xffffff, Math.random()*0.4+0.2).setDepth(0.1);
        } else if (tod === "dawn") {
            const sx=W-55, sy=92;
            this.add.ellipse(sx,sy+15,140,45,0xffaa66,0.15).setDepth(0.02);
            this.add.ellipse(sx,sy+8,90,30,0xffcc88,0.12).setDepth(0.03);
            this.add.circle(sx,sy,28,0xffdd88,0.7).setDepth(0.1);
            this.add.circle(sx,sy,22,0xffee99,0.8).setDepth(0.1);
            this.add.circle(sx,sy,14,0xffffcc).setDepth(0.1);
        } else if (tod === "dusk") {
            const sx=50, sy=92;
            this.add.ellipse(sx,sy+15,140,45,0xff6644,0.15).setDepth(0.02);
            this.add.ellipse(sx,sy+8,90,30,0xff8855,0.12).setDepth(0.03);
            this.add.circle(sx,sy,28,0xff8855,0.7).setDepth(0.1);
            this.add.circle(sx,sy,22,0xffaa77,0.8).setDepth(0.1);
            this.add.circle(sx,sy,14,0xffccaa).setDepth(0.1);
        } else {
            const sx=W/2+40, sy=25;
            this.add.circle(sx,sy,26,0xffffcc,0.5).setDepth(0.1);
            this.add.circle(sx,sy,20,0xffffdd,0.7).setDepth(0.1);
            this.add.circle(sx,sy,14,0xffffee).setDepth(0.1);
            this.add.ellipse(sx,sy,50,30,0xffffcc,0.06).setDepth(0.05);
        }
        
        // Clouds — biome tinted, multi-shape
        this._clouds = [];
        const cTint = biome==="apocalyptic"?0x888877:biome==="barren"?0xddccbb:0xffffff;
        const cAlpha = tod==="night"?0.05:biome==="apocalyptic"?0.08:0.1;
        for (let i=0;i<3;i++) { const cx=Phaser.Math.Between(0,W),cy=Phaser.Math.Between(12,70),cw=Phaser.Math.Between(50,100),ch=Phaser.Math.Between(10,20); const cg=this.add.container(cx,cy).setDepth(0.2); cg.add(this.add.ellipse(0,0,cw,ch,cTint,cAlpha)); cg.add(this.add.ellipse(-cw*0.2,-2,cw*0.6,ch*0.7,cTint,cAlpha*0.6)); cg.add(this.add.ellipse(cw*0.15,1,cw*0.5,ch*0.8,cTint,cAlpha*0.4)); this._clouds.push({obj:cg,speed:2+Math.random()*4}); }
        
        // === FAR HORIZON (0.05x) ===
        const farY = 116;
        this._farHorizon = [];
        const todMul = tod==="night"?0.4:tod==="dusk"?0.7:1.0;
        
        if (biome === "apocalyptic") {
            // Ruined city skyline
            for (let i=0;i<10;i++) {
                const bx=i*(W/8)+Phaser.Math.Between(-15,15), b=this.add.container(bx,farY).setDepth(0.3), r=Math.random();
                if (r<0.4) { const bh=Phaser.Math.Between(20,50),bw=Phaser.Math.Between(8,16),col=IsoRenderer.darken(0x2a2525,0.1+Math.random()*0.15); b.add(this.add.rectangle(0,-bh/2,bw,bh,col)); b.add(this.add.rectangle(0,-bh,bw*0.7,3,IsoRenderer.lighten(col,0.05))); if(Math.random()>0.3) b.add(this.add.rectangle(bw*0.2,-bh+2,bw*0.3,5,col)); for(let wy=-bh+8;wy<-4;wy+=5){if(Math.random()>0.4) b.add(this.add.rectangle(0,wy,2,2,tod==="night"?0x332211:0x1a1515));} }
                else if (r<0.65) { b.add(this.add.rectangle(0,-10,3,20,IsoRenderer.darken(0x2a2525,0.15))); b.add(this.add.rectangle(0,-18,4,6,IsoRenderer.darken(0x2a2525,0.2))); }
                else { b.add(this.add.ellipse(0,2,Phaser.Math.Between(30,60),Phaser.Math.Between(6,12),IsoRenderer.darken(0x2a2525,0.05))); }
                this._farHorizon.push(b);
            }
        } else if (biome === "barren") {
            // Mountain ridge — continuous connected silhouette using graphics fill
            const ridgeCol = IsoRenderer.darken(0x5a4a3a, 0.12 * todMul);
            const ridgeLight = IsoRenderer.lighten(ridgeCol, 0.08);
            const ridgeDark = IsoRenderer.darken(ridgeCol, 0.12);
            
            // Generate ridge profile points spanning full width + overflow
            const ridgePoints = [];
            const totalW = W + 200; // overflow both sides for scrolling
            const startX = -100;
            let rx = startX;
            const maxPeaks = 30; // safety bound
            for (let pi = 0; pi < maxPeaks && rx < startX + totalW; pi++) {
                const peakH = Phaser.Math.Between(12, 48);
                ridgePoints.push({ x: rx, y: farY - peakH });
                rx += Phaser.Math.Between(25, 55);
                // Valley between peaks
                const valleyH = Phaser.Math.Between(3, 12);
                ridgePoints.push({ x: rx, y: farY - valleyH });
                rx += Phaser.Math.Between(20, 40);
            }
            ridgePoints.push({ x: rx, y: farY });
            
            // Draw rear ridge layer (slightly taller, darker — gives depth)
            const rearRidge = this.add.graphics().setDepth(0.28);
            rearRidge.fillStyle(Phaser.Display.Color.ValueToColor(ridgeDark).color, 1.0);
            rearRidge.beginPath();
            rearRidge.moveTo(startX, farY + 10);
            for (const pt of ridgePoints) {
                rearRidge.lineTo(pt.x - 8, pt.y - 6); // offset up+left for rear layer
            }
            rearRidge.lineTo(startX + totalW + 20, farY + 10);
            rearRidge.closePath();
            rearRidge.fillPath();
            this._farHorizon.push(rearRidge);
            
            // Draw main ridge (filled polygon from base to peaks)
            const mainRidge = this.add.graphics().setDepth(0.3);
            mainRidge.fillStyle(Phaser.Display.Color.ValueToColor(ridgeCol).color, 1.0);
            mainRidge.beginPath();
            mainRidge.moveTo(startX, farY + 10);
            for (const pt of ridgePoints) {
                mainRidge.lineTo(pt.x, pt.y);
            }
            mainRidge.lineTo(startX + totalW + 20, farY + 10);
            mainRidge.closePath();
            mainRidge.fillPath();
            this._farHorizon.push(mainRidge);
            
            // Snow caps on the tallest peaks
            for (const pt of ridgePoints) {
                if (pt.y < farY - 30 && Math.random() < 0.5) {
                    const snowTri = this.add.triangle(pt.x, pt.y + 2, 0, -5, -6, 4, 6, 4, 0xccccbb, 0.25).setDepth(0.295);
                    this._farHorizon.push(snowTri);
                }
            }
            
            // Mesa accents (flat-topped foreground features)
            for (let i = 0; i < 3; i++) {
                const mx = Phaser.Math.Between(0, W);
                const mw2 = Phaser.Math.Between(30, 60), mh2 = Phaser.Math.Between(8, 18);
                const mesa = this.add.container(mx, farY).setDepth(0.32);
                mesa.add(this.add.rectangle(0, -mh2/2, mw2, mh2, IsoRenderer.darken(ridgeCol, 0.06)));
                mesa.add(this.add.rectangle(0, -mh2, mw2 * 0.9, 3, ridgeLight));
                this._farHorizon.push(mesa);
            }
        } else {
            // Rolling hills — connected terrain, no disconnected elements
            for (let i=0;i<8;i++) {
                const hx=i*(W/6)+Phaser.Math.Between(-10,10), col=IsoRenderer.darken(0x4a5a3a,0.08*todMul);
                const hw = Phaser.Math.Between(60, 110), hh = Phaser.Math.Between(12, 25);
                this._farHorizon.push(this.add.ellipse(hx,farY+4,hw,hh,col).setDepth(0.3));
            }
        }
        
        // === MID-GROUND (0.25x) — sparse passing structures ===
        this._midGround = [];
        const mc = biome === "barren" ? 4 : 5;
        for (let i=0;i<mc;i++) {
            const mx=i*(W/(mc-1))+Phaser.Math.Between(-25,25), item=this.add.container(mx,130+Phaser.Math.Between(-5,5)).setDepth(0.5);
            if (biome === "grassy") {
                const r=Math.random();
                if (r<0.25) { item.add(this.add.rectangle(0,0,22,14,0x5a5548)); item.add(this.add.triangle(0,-10,-12,0,0,-8,12,0,0x6a5a4a)); item.add(this.add.rectangle(0,3,4,6,0x3a3530)); if(tod==="night") item.add(this.add.rectangle(-4,-2,3,3,0x554422,0.4)); }
                else if (r<0.45) { item.add(this.add.rectangle(0,-4,2,24,0x4a4a3a)); item.add(this.add.rectangle(0,-16,14,1,0x4a4a3a)); item.add(this.add.rectangle(22,-4,2,22,0x4a4a3a)); item.add(this.add.rectangle(11,-15,24,0.5,0x3a3a2a,0.3)); }
                else if (r<0.65) { for(let t=0;t<3;t++){const tx=t*9-9,th=10+t*3; item.add(this.add.rectangle(tx,4,3,th,0x3a2a1a)); item.add(this.add.ellipse(tx,4-th/2-4,12+t*2,10,[0x2a5a2a,0x3a6a3a,0x2a4a1a][t]));} }
                else { item.add(this.add.rectangle(0,2,26,16,0x5a3a2a)); item.add(this.add.rectangle(0,-6,24,4,0x6a4a3a)); item.add(this.add.rectangle(0,-8,20,2,0x7a5a4a,0.4)); item.add(this.add.rectangle(-6,6,6,6,0x3a2a1a)); }
            } else if (biome === "barren") {
                const r=Math.random();
                if (r<0.35) { item.add(this.add.rectangle(0,-2,3,22,0x5a5548)); item.add(this.add.rectangle(0,-12,16,1.5,0x5a5548).setAngle(Phaser.Math.Between(-20,40))); item.add(this.add.rectangle(0,-12,1.5,16,0x5a5548).setAngle(Phaser.Math.Between(-20,40))); item.add(this.add.circle(0,-12,2,0x6a6558)); }
                else if (r<0.6) { item.add(this.add.rectangle(0,2,18,12,0x5a5040)); item.add(this.add.rectangle(0,-3,16,3,0x6a6050,0.4)); item.add(this.add.rectangle(0,5,4,5,0x3a3020)); }
                else { item.add(this.add.rectangle(-4,2,4,14,0x3a5a3a)); item.add(this.add.rectangle(-6,-4,3,6,0x3a5a3a)); item.add(this.add.rectangle(6,4,3,10,0x3a5a3a)); }
            } else {
                const r=Math.random();
                if (r<0.3) { item.add(this.add.rectangle(0,2,44,5,0x2a2525)); item.add(this.add.rectangle(-18,6,4,14,0x2a2525)); item.add(this.add.rectangle(12,8,18,3,0x2a2525).setAngle(18)); }
                else if (r<0.55) { item.add(this.add.rectangle(0,0,8,18,0x1a1515)); item.add(this.add.rectangle(0,-8,6,4,0x252020)); item.add(this.add.ellipse(0,-14,6,4,0x2a2525)); }
                else if (r<0.75) { for(let t=0;t<3;t++){item.add(this.add.rectangle(t*10-10,4,3,12+t*2,0x1a1515)); item.add(this.add.rectangle(t*10-10+2,-2,2,4,0x1a1515).setAngle(20));} }
                else { item.add(this.add.rectangle(0,4,28,8,0x2a2525)); item.add(this.add.ellipse(-8,8,6,5,0x111111)); item.add(this.add.ellipse(8,9,6,5,0x111111)); }
            }
            this._midGround.push(item);
        }
        
        // Ground
        const gcs = { grassy: { dawn: 0x4a5a3a, midday: 0x3a5a2a, dusk: 0x3a4a3a, night: 0x1a2a1a }, barren: { dawn: 0x5a4a3a, midday: 0x4a3a2a, dusk: 0x4a3a30, night: 0x2a2218 }, apocalyptic: { dawn: 0x3a3535, midday: 0x2a2525, dusk: 0x302828, night: 0x181515 } };
        this.add.rectangle(W/2, H/2+80, W, H, (gcs[biome]||gcs.grassy)[tod]||0x3a5a2a).setDepth(0.4);
        
        // Near scenery (0.7x) — detailed roadside objects
        this._nearScenery = [];
        const nc = biome === 'barren' ? 5 : 8;
        for (let i = 0; i < nc; i++) {
            const above = i%2===0, x = i*(W/(nc-1)*1.2), y = above ? this.roadY-110-Math.random()*15 : this.roadY+110+Math.random()*15;
            const it = this.add.container(x, y).setDepth(3);
            const ad = (s) => { it.add(s); return s; };
            if (biome === 'grassy') {
                const r = Math.random();
                if (r < 0.3) { // Deciduous tree
                    const trunk = [0x4a3a2a,0x3a2a1a][Phaser.Math.Between(0,1)], leaf = [0x2a5a2a,0x3a6a3a,0x2a4a1a][Phaser.Math.Between(0,2)];
                    ad(this.add.ellipse(2, 18, 28, 8, 0x000000, 0.2));
                    ad(this.add.rectangle(0, 10, 6, 18, trunk));
                    ad(this.add.rectangle(0, 9, 4, 16, IsoRenderer.lighten(trunk, 0.1)));
                    ad(this.add.rectangle(-5, 2, 3, 10, IsoRenderer.darken(trunk, 0.1)).setAngle(-18));
                    ad(this.add.rectangle(4, 4, 3, 8, trunk).setAngle(12));
                    const cw = 24+Math.random()*8, ch = 16+Math.random()*4;
                    ad(this.add.ellipse(-6, -6, cw*0.6, ch*0.7, IsoRenderer.darken(leaf, 0.15)));
                    ad(this.add.ellipse(4, -8, cw*0.7, ch*0.8, leaf));
                    ad(this.add.ellipse(-2, -10, cw, ch, leaf));
                    ad(this.add.ellipse(-2, -12, cw*0.8, ch*0.6, IsoRenderer.lighten(leaf, 0.15)));
                    ad(this.add.ellipse(6, -7, cw*0.4, ch*0.5, IsoRenderer.lighten(leaf, 0.1)));
                    ad(this.add.ellipse(-8, -4, 8, 6, IsoRenderer.darken(leaf, 0.1)));
                    ad(this.add.ellipse(0, -14, 10, 4, IsoRenderer.lighten(leaf, 0.2), 0.3));
                } else if (r < 0.5) { // Metal guardrail
                    ad(this.add.rectangle(0, 4, 48, 3, 0x888878));
                    ad(this.add.rectangle(0, 3, 46, 2, 0x999988, 0.3));
                    ad(this.add.rectangle(0, 5, 46, 1, 0x666658));
                    ad(this.add.rectangle(-18, 7, 3, 10, 0x666658));
                    ad(this.add.rectangle(-18, 7, 2, 8, 0x777768));
                    ad(this.add.rectangle(0, 7, 3, 10, 0x666658));
                    ad(this.add.rectangle(0, 7, 2, 8, 0x777768));
                    ad(this.add.rectangle(18, 7, 3, 10, 0x666658));
                    ad(this.add.rectangle(18, 7, 2, 8, 0x777768));
                    ad(this.add.rectangle(0, 3, 4, 3, 0xccaa22, 0.4));
                    ad(this.add.rectangle(-8, 3, 6, 2, 0xccaa22, 0.2));
                } else if (r < 0.7) { // Road sign
                    ad(this.add.ellipse(1, 14, 10, 3, 0x000000, 0.15));
                    ad(this.add.rectangle(0, 5, 3, 20, 0x666658));
                    ad(this.add.rectangle(0, 4, 2, 18, 0x777768, 0.3));
                    ad(this.add.rectangle(0, -8, 18, 14, 0x336633));
                    ad(this.add.rectangle(0, -8, 16, 12, 0x337733));
                    ad(this.add.rectangle(0, -8, 12, 8, 0x338833, 0.4));
                    ad(this.add.rectangle(0, -9, 10, 2, 0xffffff, 0.5));
                    ad(this.add.rectangle(0, -6, 8, 2, 0xffffff, 0.3));
                    ad(this.add.rectangle(-8, -8, 1, 10, 0x225522));
                    ad(this.add.rectangle(8, -8, 1, 10, 0x225522));
                } else if (r < 0.85) { // Bush cluster
                    ad(this.add.ellipse(0, 8, 26, 6, 0x000000, 0.15));
                    ad(this.add.ellipse(-6, 3, 16, 12, 0x2a4a2a));
                    ad(this.add.ellipse(4, 2, 14, 11, 0x3a5a3a));
                    ad(this.add.ellipse(-2, 1, 18, 10, 0x3a5a3a));
                    ad(this.add.ellipse(-2, -1, 14, 7, 0x4a6a4a, 0.4));
                    ad(this.add.ellipse(6, 3, 8, 6, 0x2a4a2a));
                    ad(this.add.ellipse(-8, 4, 6, 5, 0x2a4a2a, 0.5));
                    ad(this.add.circle(-4, 0, 2, 0x5a7a5a, 0.3));
                    ad(this.add.circle(3, -1, 2, 0x5a7a5a, 0.2));
                } else { // Wooden fence section
                    for (let p = -14; p <= 14; p += 7) { ad(this.add.rectangle(p, 4, 3, 16, 0x5a4a3a)); ad(this.add.rectangle(p, 3, 2, 14, 0x6a5a4a, 0.3)); }
                    ad(this.add.rectangle(0, -1, 32, 2, 0x5a4a3a));
                    ad(this.add.rectangle(0, 6, 32, 2, 0x4a3a2a));
                }
            } else if (biome === 'barren') {
                const r = Math.random();
                if (r < 0.3) { // Dead tree
                    ad(this.add.ellipse(2, 16, 18, 5, 0x000000, 0.15));
                    ad(this.add.rectangle(0, 6, 5, 22, 0x4a3a2a));
                    ad(this.add.rectangle(0, 5, 3, 20, 0x5a4a3a));
                    ad(this.add.rectangle(-6, -4, 3, 14, 0x3a2a1a).setAngle(-22));
                    ad(this.add.rectangle(5, -2, 3, 10, 0x3a2a1a).setAngle(18));
                    ad(this.add.rectangle(-8, -10, 2, 6, 0x3a2a1a).setAngle(-30));
                    ad(this.add.rectangle(7, -8, 2, 5, 0x3a2a1a).setAngle(25));
                    ad(this.add.rectangle(0, -6, 4, 2, 0x3a2a1a));
                    ad(this.add.rectangle(-2, 14, 3, 3, 0x3a2a1a));
                } else if (r < 0.55) { // Rock formation
                    ad(this.add.ellipse(1, 10, 24, 6, 0x000000, 0.2));
                    ad(this.add.rectangle(10, 0, 3, 16, 0x3a3a30));
                    ad(this.add.rectangle(10, -1, 2, 14, 0x4a4a40));
                    ad(this.add.rectangle(-1, 5, 18, 8, 0x5a5550));
                    ad(this.add.rectangle(-1, 4, 16, 6, 0x6a6560));
                    ad(this.add.rectangle(-1, 2, 18, 3, 0x7a7570));
                    ad(this.add.rectangle(-1, -1, 16, 8, 0x6a6560));
                    ad(this.add.rectangle(-1, -3, 12, 4, 0x7a7570));
                    ad(this.add.rectangle(6, 2, 4, 3, 0x5a5550));
                    ad(this.add.ellipse(-6, 8, 6, 3, 0x4a4540));
                } else if (r < 0.75) { // Wire fence
                    for (let f = -14; f <= 14; f += 14) { ad(this.add.rectangle(f, 2, 2, 18, 0x5a5548)); ad(this.add.rectangle(f, 1, 1, 16, 0x6a6558)); }
                    ad(this.add.rectangle(0, -4, 30, 1, 0x5a5548));
                    ad(this.add.rectangle(0, 0, 30, 1, 0x5a5548));
                    ad(this.add.rectangle(0, 4, 30, 1, 0x5a5548));
                    ad(this.add.rectangle(7, -2, 4, 4, 0x4a4a3a));
                } else { // Cactus
                    ad(this.add.ellipse(0, 14, 10, 3, 0x000000, 0.15));
                    ad(this.add.rectangle(0, 4, 6, 20, 0x3a5a3a));
                    ad(this.add.rectangle(0, 3, 4, 18, 0x4a6a4a));
                    ad(this.add.rectangle(-5, -2, 4, 10, 0x3a5a3a));
                    ad(this.add.rectangle(-7, -6, 4, 6, 0x3a5a3a));
                    ad(this.add.rectangle(-7, -7, 2, 4, 0x4a6a4a));
                    ad(this.add.rectangle(5, 0, 4, 8, 0x3a5a3a));
                    ad(this.add.rectangle(7, -2, 4, 5, 0x3a5a3a));
                    ad(this.add.rectangle(0, -5, 3, 2, 0x4a6a4a));
                }
            } else { // Apocalyptic
                const r = Math.random();
                if (r < 0.25) { // Burned stump
                    ad(this.add.ellipse(0, 14, 18, 5, 0x000000, 0.25));
                    ad(this.add.rectangle(0, 6, 8, 16, 0x1a1a1a));
                    ad(this.add.rectangle(0, 5, 6, 14, 0x222222));
                    ad(this.add.rectangle(-4, 0, 3, 10, 0x151515).setAngle(-15));
                    ad(this.add.rectangle(3, 2, 3, 8, 0x151515).setAngle(10));
                    ad(this.add.rectangle(0, -2, 6, 2, 0x1a1a1a));
                    ad(this.add.ellipse(0, -2, 6, 3, 0x0a0a08));
                    ad(this.add.circle(1, 4, 1, 0x333333));
                    ad(this.add.circle(-2, 8, 1, 0x2a2a2a));
                } else if (r < 0.5) { // Collapsed structure
                    ad(this.add.ellipse(1, 10, 24, 6, 0x000000, 0.2));
                    ad(this.add.rectangle(10, 2, 3, 16, 0x252020));
                    ad(this.add.rectangle(10, 1, 2, 14, 0x302828));
                    ad(this.add.rectangle(-1, 7, 20, 5, 0x3a3535));
                    ad(this.add.rectangle(-1, 5, 18, 4, 0x454040));
                    ad(this.add.rectangle(-1, 2, 20, 8, 0x454040));
                    ad(this.add.rectangle(-1, 0, 16, 5, 0x504848));
                    ad(this.add.rectangle(-6, 4, 4, 3, 0x2a2525));
                    ad(this.add.rectangle(4, 3, 3, 4, 0x2a2525));
                    ad(this.add.rectangle(-8, 8, 6, 2, 0x353030));
                } else if (r < 0.7) { // Wrecked car shell
                    ad(this.add.ellipse(2, 12, 42, 8, 0x000000, 0.2));
                    ad(this.add.rectangle(0, 4, 36, 12, 0x2a2525));
                    ad(this.add.rectangle(0, 2, 34, 10, 0x353030));
                    ad(this.add.rectangle(-10, -2, 12, 8, 0x252020));
                    ad(this.add.rectangle(-10, -3, 8, 5, 0x0a0a0a));
                    ad(this.add.ellipse(-12, 10, 8, 6, 0x111111));
                    ad(this.add.ellipse(-12, 10, 5, 4, 0x1a1a1a));
                    ad(this.add.ellipse(10, 10, 8, 6, 0x111111));
                    ad(this.add.ellipse(10, 10, 5, 4, 0x1a1a1a));
                    ad(this.add.rectangle(16, 2, 3, 4, 0x353030));
                    ad(this.add.rectangle(-18, 2, 3, 4, 0x252020));
                } else if (r < 0.85) { // Leaning pole / sign
                    ad(this.add.ellipse(2, 14, 10, 3, 0x000000, 0.15));
                    ad(this.add.rectangle(0, 4, 3, 22, 0x4a4a3a).setAngle(8));
                    ad(this.add.rectangle(0, 3, 2, 20, 0x5a5a4a).setAngle(8));
                    ad(this.add.rectangle(0, 12, 4, 3, 0x3a3a30));
                    ad(this.add.rectangle(2, -8, 18, 12, 0x3a3535).setAngle(12));
                    ad(this.add.rectangle(2, -8, 16, 10, 0x454040).setAngle(12));
                    ad(this.add.rectangle(2, -8, 14, 8, 0x504848).setAngle(12));
                    ad(this.add.rectangle(2, -10, 10, 2, 0x555050).setAngle(12));
                    ad(this.add.rectangle(2, -6, 8, 2, 0x555050).setAngle(12));
                    ad(this.add.rectangle(-6, -8, 1, 8, 0x353030).setAngle(12));
                    ad(this.add.rectangle(10, -8, 1, 8, 0x353030).setAngle(12));
                } else { // Rubble mound
                    ad(this.add.ellipse(0, 8, 26, 6, 0x000000, 0.15));
                    ad(this.add.ellipse(0, 4, 22, 12, 0x2a2525));
                    ad(this.add.ellipse(0, 2, 18, 9, 0x353030));
                    ad(this.add.ellipse(-4, 1, 10, 6, 0x3a3535));
                    ad(this.add.rectangle(4, 3, 5, 3, 0x252020).setAngle(15));
                    ad(this.add.rectangle(-6, 5, 4, 2, 0x1a1818));
                    ad(this.add.rectangle(2, 0, 3, 4, 0x2a2525));
                    ad(this.add.ellipse(0, -1, 8, 3, 0x404040));
                }
            }
            this._nearScenery.push(it);
        }
    }
    
    createRoad() {
        const W = CONFIG.width, rc = this.isDirt ? 0x4a3a28 : 0x2a2a2a, ec = this.isDirt ? 0x5a4a38 : 0x5a5a4a;
        this.add.rectangle(W/2, this.roadY, W, 170, rc).setDepth(1);
        this.add.rectangle(W/2, this.roadY-83, W, 4, ec).setDepth(2);
        this.add.rectangle(W/2, this.roadY+83, W, 4, ec).setDepth(2);
        this.laneMarkers = [];
        for (let i = 0; i < 12; i++) {
            if (this.isDirt) { this.laneMarkers.push(this.add.rectangle(i*50, this.roadY-20, 25, 2, 0x3a2a18, 0.3).setDepth(2)); this.laneMarkers.push(this.add.rectangle(i*50, this.roadY+20, 25, 2, 0x3a2a18, 0.3).setDepth(2)); }
            else { this.laneMarkers.push(this.add.rectangle(i*50, this.roadY-25, 28, 3, 0x5a5a4a).setDepth(2)); this.laneMarkers.push(this.add.rectangle(i*50, this.roadY+25, 28, 3, 0x5a5a4a).setDepth(2)); }
        }
    }
    
    createVehicle() {
        // Use the actual player vehicle sprite with customization colors
        this.vehicle = SpriteManager.createVehicle(this, -60, this.lanePositions[1], 'side');
        this.vehicle.setDepth(20).setScale(1.2);
        DynamicShadows.add(this, this.vehicle, { offsetY: 14, scale: 1.0, alpha: 0.15 });
        
        // Wheel hubs are now part of the spritesheet, no separate children to reference
        this._wheelHubs = [];
        
        // Add animated spoke lines over wheel centers
        this._wheelSpokes = [];
        [[-16, 2], [18, 2]].forEach(([wx, wy]) => {
            const spoke = this.add.rectangle(wx, wy, 5, 1.5, 0x555555);
            this.vehicle.add(spoke);
            this._wheelSpokes.push(spoke);
        });
        
        this._exhaustTimer = 0;
        this._vehBobTimer = 0;
        this.physics.add.existing(this.vehicle);
        this.vehicle.body.setSize(40, 22).setOffset(-20, -11);
        
        // Entrance animation — drive in from left
        this._entranceActive = true;
        this.vehicle.body.moves = false;
        
        // Exhaust burst during entrance
        for (let p = 0; p < 6; p++) {
            this.time.delayedCall(100 + p * 100, () => {
                if (!this.vehicle) return;
                const puff = this.add.circle(
                    this.vehicle.x - 36,
                    this.vehicle.y + 14 + Phaser.Math.Between(-3, 3),
                    Phaser.Math.Between(3, 6), 0x666666, 0.5
                ).setDepth(19);
                this.tweens.add({
                    targets: puff,
                    x: puff.x - Phaser.Math.Between(20, 40),
                    y: puff.y - Phaser.Math.Between(3, 10),
                    alpha: 0, scaleX: 2.5, scaleY: 2,
                    duration: 600,
                    onComplete: () => puff.destroy()
                });
            });
        }
        
        // Spin wheels fast during entrance
        this._entranceWheelTimer = this.time.addEvent({
            delay: 30,
            callback: () => {
                this._wheelSpokes.forEach(s => s.setAngle((s.angle + 15) % 360));
            },
            repeat: 30
        });
        
        // Drive to position
        this.tweens.add({
            targets: this.vehicle,
            x: 70,
            duration: 900,
            ease: 'Quad.easeOut',
            onComplete: () => {
                this._entranceActive = false;
                this.vehicle.body.moves = true;
            }
        });
    }
    
    createUI() {
        const W = CONFIG.width, H = CONFIG.height;
        UIAtlas.build(this);
        const F = UIAtlas.FRAME;
        // Top: destination + filling progress bar (atlas panel)
        this.add.nineslice(W/2, 22, 'ui_panel', null, W-20, 34, F, F, F, F).setDepth(100).setAlpha(0.9);
        this.add.text(W/2, 10, this.destination, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#aaa' }).setOrigin(0.5).setDepth(100);
        // Progress bar track
        this.add.rectangle(W/2, 28, W-60, 8, 0x222222).setDepth(100);
        // Progress bar fill
        this.progressBar = this.add.rectangle(30, 28, 1, 5, 0x44aa44).setOrigin(0, 0.5).setDepth(100);
        // Progress bar endpoint marker
        this.add.circle(W-30, 28, 4, 0x88cc88, 0.3).setDepth(100);
        // "PAUSED" indicator (hidden by default)
        // (encounter pause indicator removed — no mid-drive encounters)
        // Bottom: vehicle HP (atlas panel)
        this.add.nineslice(W/2, H-16, 'ui_panel', null, W-20, 22, F, F, F, F).setDepth(100).setAlpha(0.9);
        this.add.text(12, H-20, 'VEHICLE', { fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#888' }).setDepth(101);
        this.add.rectangle(W/2 + 10, H-16, W - 100, 6, 0x222222).setDepth(100);
        this.vehHealthBar = this.add.rectangle(50, H-16, (W - 110) * (this.state.vehicleHealth / 100), 4, 0x44aacc).setOrigin(0, 0.5).setDepth(101);
        this.speedText = this.add.text(W-12, H-20, 'NORMAL', { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#88aacc' }).setOrigin(1, 0).setDepth(101);
    }
    
    setupInput() {
        this.speedState = 0; this.baseVehicleX = 70;
        this.speedSettings = { '-1': { speed: 100, xOffset: -45, label: 'SLOW', color: '#cc8888' }, '0': { speed: 180, xOffset: 0, label: 'NORMAL', color: '#88aacc' }, '1': { speed: 280, xOffset: 50, label: 'FAST', color: '#ffcc44' } };
        this.targetSpeed = 180;
        this.input.on('pointerdown', p => { if (!this.popupActive) this.swipeStart = { x: p.x, y: p.y, t: Date.now() }; });
        this.input.on('pointerup', p => {
            if (this.popupActive || !this.swipeStart) return;
            const dx = p.x - this.swipeStart.x, dy = p.y - this.swipeStart.y, dt = Date.now() - this.swipeStart.t;
            if (dt < 400 && (Math.abs(dx) > 25 || Math.abs(dy) > 25)) {
                if (Math.abs(dy) > Math.abs(dx)) { if (dy > 25 && this.currentLane < 2) this.changeLane(1); else if (dy < -25 && this.currentLane > 0) this.changeLane(-1); }
                else { if (dx > 25 && this.speedState < 1) { this.speedState++; this.applySpeedState(); } else if (dx < -25 && this.speedState > -1) { this.speedState--; this.applySpeedState(); } }
            }
            this.swipeStart = null;
        });
    }
    applySpeedState() { const s = this.speedSettings[this.speedState.toString()]; this.targetSpeed = s.speed; this.tweens.add({ targets: this.vehicle, x: this.baseVehicleX + s.xOffset, duration: 200, ease: 'Quad.easeOut' }); if (this.speedText) { this.speedText.setText(s.label); this.speedText.setColor(s.color); } }
    changeLane(d) { if (this.isTransitioning) return; const t = Phaser.Math.Clamp(this.currentLane+d, 0, 2); if (t !== this.currentLane) { this.isTransitioning = true; this.tweens.add({ targets: this.vehicle, y: this.lanePositions[t], duration: 150, ease: 'Quad.easeOut', onComplete: () => { this.currentLane = t; this.isTransitioning = false; } }); } }
    
    update(time, delta) {
        if (this.popupActive) return;
        const dt = delta / 1000;
        this.speed += (this.targetSpeed - this.speed) * 3 * dt;
        const ss = this.speed * dt;
        // Parallax
        this._clouds.forEach(c => { c.obj.x -= c.speed * dt; if (c.obj.x < -60) c.obj.x = CONFIG.width + 60; });
        this._farHorizon.forEach(h => { h.x -= ss * 0.05; if (h.x < -100) h.x += CONFIG.width + 200; });
        this._midGround.forEach(m => { m.x -= ss * 0.25; if (m.x < -60) m.x += CONFIG.width + 120; });
        this._nearScenery.forEach(s => { s.x -= ss * 0.7; if (s.x < -50) s.x += CONFIG.width + 100; });
        this.laneMarkers.forEach(m => { m.x -= ss; if (m.x < -40) m.x += 600; });
        this.obstacles.getChildren().forEach(o => { o.x -= ss; if (o.x < -50) o.destroy(); });
        this.events.getChildren().forEach(e => { e.x -= ss; if (e.x < -50) e.destroy(); });
        this.supplyCrates.getChildren().forEach(c => { c.x -= ss; if (c.x < -50) c.destroy(); });
        // Foreground dust (reduced rate)
        if (Math.random() < 0.08 + (this.speed / 800)) { const dy = this.roadY + Phaser.Math.Between(-60, 70); const dust = this.add.circle(CONFIG.width + 10, dy, Phaser.Math.Between(2, 5), this.isDirt ? 0x6a5a3a : 0x555555, 0.15).setDepth(50); this.tweens.add({ targets: dust, x: -20, duration: 600 + Math.random() * 400, onComplete: () => dust.destroy() }); }
        // Vehicle anim
        this._vehBobTimer += dt;
        const sf = this.speed / 180;
        if (this.vehicle) this.vehicle.setAngle(Math.sin(this._vehBobTimer * 8 * sf) * (this.isDirt ? 1.2 : 0.5) * sf * 0.3);
        this._wheelSpokes.forEach(s => { s.setAngle((s.angle + this.speed * dt * 2) % 360); });
        this._exhaustTimer += dt;
        if (this._exhaustTimer > 0.15 / Math.max(0.5, sf)) { this._exhaustTimer = 0; const ex = this.vehicle.x - 36, ey = this.vehicle.y + 14; const puff = this.add.circle(ex, ey, Phaser.Math.Between(2, 4), 0x555555, 0.4).setDepth(19); this.tweens.add({ targets: puff, x: ex - Phaser.Math.Between(15, 35), y: ey - Phaser.Math.Between(5, 15), alpha: 0, scaleX: 2, scaleY: 2, duration: Phaser.Math.Between(400, 700), onComplete: () => puff.destroy() }); }
        if (this.state.vehicleHealth < 35 && Math.random() < 0.08) { const sx = this.vehicle.x + Phaser.Math.Between(10, 28), sy = this.vehicle.y - 16; const smoke = this.add.circle(sx, sy, Phaser.Math.Between(3, 6), 0x444444, 0.4).setDepth(21); this.tweens.add({ targets: smoke, alpha: 0, y: sy - 25, scaleX: 2.5, scaleY: 2.5, duration: 600, onComplete: () => smoke.destroy() }); }
        // Travel timer always advances (no encounter pausing)
        this.travelElapsed += dt;
        // Vehicle breakdown on 0 HP
        if (this.state.vehicleHealth <= 0 && !this.breakdownTriggered) { this.triggerBreakdown('damage'); return; }
        // Obstacles + scenery spawns
        this.spawnTimer += dt; if (this.spawnTimer > 1.8) { this.spawnTimer = 0; if (Math.random() < 0.25) this.spawnObstacle(); }
        this.eventTimer += dt; if (this.eventTimer > 8) { this.eventTimer = 0; if (Math.random() < 0.18) this.spawnEvent(); }
        // UI
        const vhpPct = Math.max(0, this.state.vehicleHealth / 100);
        this.vehHealthBar.setDisplaySize((CONFIG.width - 110) * vhpPct, 4);
        this.vehHealthBar.setFillStyle(this.state.vehicleHealth < 30 ? 0xcc4444 : this.state.vehicleHealth < 60 ? 0xccaa44 : 0x44aacc);
        const prog = Math.min(this.travelElapsed / this.travelDuration, 1);
        const barMaxW = CONFIG.width - 60;
        this.progressBar.width = barMaxW * prog;
        this.progressBar.setDisplaySize(Math.max(1, barMaxW * prog), 5);
        this.progressBar.setFillStyle(0x44aa44);
        if (prog >= 0.92 && !this._arriving) { this._arriving = true; this.tweens.add({ targets: this, targetSpeed: 40, duration: 2000, ease: 'Quad.easeOut' }); }
        // Auto-enter on arrival
        if (this.travelElapsed >= this.travelDuration && !this._autoEntering) {
            this._autoEntering = true;
            const arriveText = this.add.text(CONFIG.width/2, CONFIG.height/2 - 30, '-- ' + this.destination + ' --', { 
                fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#88ccaa', fontStyle: 'bold' 
            }).setOrigin(0.5).setDepth(150).setAlpha(0);
            this.tweens.add({ targets: arriveText, alpha: 1, duration: 400 });
            this.time.delayedCall(800, () => this.enterDestination());
        }

        DynamicShadows.update(this);
    }
    
    spawnObstacle() {
        const lane = Phaser.Math.Between(0, 2), x = CONFIG.width + 40, y = this.lanePositions[lane], b = this.biome;
        const obs = this.add.container(x, y).setDepth(10);
        const a = (s) => { obs.add(s); return s; };
        if (b === 'barren') {
            const t = Phaser.Math.Between(0, 3);
            if (t === 0) { // Boulder cluster
                a(this.add.ellipse(2, 10, 32, 8, 0x000000, 0.2));
                a(this.add.ellipse(0, 2, 26, 16, 0x5a5540));
                a(this.add.ellipse(-1, 0, 22, 13, 0x6a6550));
                a(this.add.ellipse(-3, -3, 14, 8, 0x7a7560));
                a(this.add.ellipse(6, 4, 10, 7, 0x4a4530));
                a(this.add.rectangle(-8, 1, 3, 2, 0x3a3520, 0.3));
                a(this.add.ellipse(10, 6, 12, 8, 0x4a4530));
                a(this.add.ellipse(10, 5, 8, 5, 0x5a5540));
                a(this.add.rectangle(0, -5, 6, 2, 0x8a8570, 0.4));
                a(this.add.ellipse(-10, 8, 8, 5, 0x4a4530));
                obs.damage = 20;
            } else if (t === 1) { // Tumbleweed
                a(this.add.ellipse(1, 10, 20, 5, 0x000000, 0.1));
                a(this.add.circle(0, 0, 14, 0x5a5a3a, 0.4));
                a(this.add.circle(0, 0, 11, 0x4a4a2a, 0.3));
                a(this.add.circle(0, 0, 7, 0x5a5a3a, 0.2));
                const tg = this.add.graphics(); tg.lineStyle(1, 0x6a6a4a, 0.4);
                for (let i = 0; i < 8; i++) { const ang = i * Math.PI / 4; tg.lineBetween(0, 0, Math.cos(ang) * 12, Math.sin(ang) * 12); }
                for (let i = 0; i < 5; i++) { const ang = i * Math.PI / 2.5 + 0.3; tg.lineBetween(Math.cos(ang)*4, Math.sin(ang)*4, Math.cos(ang)*10, Math.sin(ang)*10); }
                a(tg);
                a(this.add.circle(-3, -4, 2, 0x6a6a4a, 0.3));
                a(this.add.circle(4, 2, 2, 0x5a5a3a, 0.2));
                obs.damage = 8;
            } else if (t === 2) { // Pothole/sinkhole
                a(this.add.ellipse(0, 2, 34, 18, 0x3a3528));
                a(this.add.ellipse(0, 1, 30, 15, 0x1a1815));
                a(this.add.ellipse(0, 3, 24, 11, 0x0a0a08, 0.6));
                a(this.add.ellipse(0, -1, 18, 7, 0x1a1815, 0.4));
                a(this.add.ellipse(-10, 0, 6, 3, 0x2a2518, 0.5));
                a(this.add.ellipse(8, 2, 4, 2, 0x2a2518, 0.4));
                a(this.add.ellipse(0, 6, 12, 3, 0x0a0808, 0.3));
                a(this.add.rectangle(-12, -3, 4, 2, 0x3a3528, 0.4));
                a(this.add.rectangle(11, 1, 3, 2, 0x3a3528, 0.3));
                obs.damage = 15;
            } else { // Wrecked car
                a(this.add.ellipse(2, 14, 48, 10, 0x000000, 0.25));
                a(this.add.rectangle(0, 2, 44, 16, 0x5a5040));
                a(this.add.rectangle(0, 0, 40, 13, 0x6a6050));
                a(this.add.rectangle(0, 4, 38, 2, 0x4a4030, 0.4));
                a(this.add.rectangle(-14, -4, 14, 10, 0x4a4030));
                a(this.add.rectangle(-14, -6, 10, 6, 0x2a3535, 0.5));
                a(this.add.rectangle(14, -2, 8, 5, 0x6a6050));
                a(this.add.ellipse(-16, 10, 10, 8, 0x1a1a1a));
                a(this.add.ellipse(-16, 10, 6, 5, 0x2a2a2a));
                a(this.add.ellipse(14, 11, 10, 8, 0x1a1a1a));
                a(this.add.ellipse(14, 11, 6, 5, 0x2a2a2a));
                a(this.add.rectangle(21, 2, 3, 5, 0xaa8844, 0.4));
                a(this.add.rectangle(-22, 2, 3, 4, 0xaa3333, 0.5));
                a(this.add.rectangle(22, 8, 3, 5, 0x444444));
                obs.damage = 25;
            }
        } else if (b === 'apocalyptic') {
            const t = Phaser.Math.Between(0, 4);
            if (t === 0) { // Rubble pile
                a(this.add.ellipse(1, 8, 34, 10, 0x000000, 0.2));
                a(this.add.ellipse(0, 4, 28, 14, 0x2a2525));
                for (let i = 0; i < 5; i++) { a(this.add.rectangle(Phaser.Math.Between(-12, 12), Phaser.Math.Between(-6, 6), Phaser.Math.Between(5, 10), Phaser.Math.Between(3, 7), [0x1a1818, 0x252020, 0x2a2525][Phaser.Math.Between(0,2)]).setAngle(Phaser.Math.Between(-30, 30))); }
                a(this.add.rectangle(-3, -4, 2, 10, 0x5a4a3a).setAngle(20));
                a(this.add.rectangle(5, -2, 2, 8, 0x5a4a3a).setAngle(-15));
                a(this.add.ellipse(0, 0, 8, 4, 0x353030, 0.4));
                obs.damage = 18;
            } else if (t === 1) { // Rebar tangle
                a(this.add.ellipse(0, 10, 22, 6, 0x000000, 0.15));
                a(this.add.ellipse(0, 8, 16, 7, 0x2a2020, 0.3));
                a(this.add.rectangle(0, 0, 4, 32, 0x5a4a3a).setAngle(Phaser.Math.Between(-12, 12)));
                a(this.add.rectangle(4, -4, 3, 16, 0x4a3a2a).setAngle(18));
                a(this.add.rectangle(-3, 2, 3, 14, 0x4a3a2a).setAngle(-12));
                a(this.add.rectangle(6, 3, 2, 10, 0x5a4a3a).setAngle(25));
                a(this.add.rectangle(-5, -6, 2, 8, 0x3a2a1a).setAngle(-20));
                a(this.add.rectangle(-7, 0, 2, 12, 0x4a3a2a).setAngle(-8));
                a(this.add.rectangle(2, -12, 3, 4, 0x5a4a3a));
                a(this.add.circle(-2, -8, 2, 0x5a4a3a, 0.5));
                a(this.add.rectangle(0, -14, 2, 3, 0x6a5a4a, 0.4));
                a(this.add.rectangle(4, 8, 3, 2, 0x3a2a1a, 0.3));
                obs.damage = 22;
            } else if (t === 2) { // Shambler zombie
                const zc = [0x5a7a5a, 0x6a8a6a, 0x4a6a5a][Phaser.Math.Between(0, 2)];
                a(this.add.ellipse(0, 14, 14, 4, 0x000000, 0.15));
                a(this.add.rectangle(-2, 10, 4, 8, zc)); a(this.add.rectangle(3, 10, 4, 8, zc));
                a(this.add.ellipse(-2, 14, 4, 2, IsoRenderer.darken(zc, 0.2)));
                a(this.add.ellipse(3, 14, 4, 2, IsoRenderer.darken(zc, 0.2)));
                a(this.add.rectangle(0, 3, 12, 14, zc));
                a(this.add.rectangle(0, 2, 10, 12, IsoRenderer.lighten(zc, 0.1)));
                a(this.add.rectangle(0, 0, 4, 3, IsoRenderer.darken(zc, 0.15)));
                a(this.add.circle(0, -6, 6, zc));
                a(this.add.circle(0, -6, 4, IsoRenderer.lighten(zc, 0.1)));
                a(this.add.circle(-2, -7, 1.5, 0x222222)); a(this.add.circle(2, -7, 1.5, 0x222222));
                a(this.add.rectangle(0, -4, 3, 1, 0x3a2a2a));
                a(this.add.rectangle(-8, 0, 3, 12, zc).setAngle(25));
                a(this.add.rectangle(7, 2, 3, 10, zc).setAngle(-18));
                obs.damage = 12;
            } else if (t === 3) { // Crater
                a(this.add.ellipse(0, 2, 36, 20, 0x252018));
                a(this.add.ellipse(0, 1, 30, 16, 0x151210));
                a(this.add.ellipse(0, 3, 22, 10, 0x0a0a08, 0.6));
                a(this.add.ellipse(0, -1, 14, 6, 0x151210, 0.4));
                a(this.add.ellipse(-12, 0, 5, 3, 0x252018, 0.5));
                a(this.add.ellipse(10, 2, 4, 2, 0x252018, 0.4));
                a(this.add.rectangle(-14, -4, 3, 2, 0x1a1515, 0.3));
                a(this.add.rectangle(12, -2, 4, 2, 0x1a1515, 0.3));
                a(this.add.ellipse(0, 7, 10, 3, 0x0a0808, 0.3));
                obs.damage = 20;
            } else { // Wrecked car (burned)
                a(this.add.ellipse(2, 14, 48, 10, 0x000000, 0.25));
                a(this.add.rectangle(0, 2, 44, 16, 0x2a2525));
                a(this.add.rectangle(0, 0, 40, 13, 0x353030));
                a(this.add.rectangle(0, 4, 38, 2, 0x1a1818, 0.4));
                a(this.add.rectangle(-14, -4, 14, 10, 0x1a1818));
                a(this.add.rectangle(-14, -6, 10, 6, 0x0a0a0a, 0.5));
                a(this.add.ellipse(-16, 10, 10, 8, 0x111111));
                a(this.add.ellipse(-16, 10, 6, 5, 0x1a1a1a));
                a(this.add.ellipse(14, 11, 10, 8, 0x111111));
                a(this.add.ellipse(14, 11, 6, 5, 0x1a1a1a));
                a(this.add.rectangle(22, 8, 3, 5, 0x333333));
                a(this.add.rectangle(-22, 8, 3, 5, 0x333333));
                a(this.add.rectangle(0, -6, 16, 3, 0x1a1515, 0.3));
                obs.damage = 25;
            }
        } else { // Grassy
            const t = Phaser.Math.Between(0, 3);
            if (t === 0) { // Road debris / tire + junk
                a(this.add.ellipse(1, 8, 28, 6, 0x000000, 0.15));
                a(this.add.ellipse(-6, 2, 14, 14, 0x1a1a1a));
                a(this.add.ellipse(-6, 2, 10, 10, 0x2a2a2a));
                a(this.add.ellipse(-6, 2, 5, 5, 0x1a1a1a));
                a(this.add.rectangle(6, 0, 16, 10, 0x5a5a4a));
                a(this.add.rectangle(6, -1, 14, 8, 0x6a6a5a));
                a(this.add.rectangle(6, 2, 12, 2, 0x4a4a3a, 0.4));
                a(this.add.rectangle(4, -3, 4, 2, 0x7a7a6a, 0.3));
                a(this.add.rectangle(12, 4, 3, 3, 0x4a4a3a));
                obs.damage = 12;
            } else if (t === 1) { // Wrecked car
                a(this.add.ellipse(2, 14, 48, 10, 0x000000, 0.25));
                a(this.add.rectangle(0, 2, 44, 16, 0x3a5555));
                a(this.add.rectangle(0, 0, 40, 13, 0x4a6565));
                a(this.add.rectangle(0, 4, 38, 2, 0x2a4545, 0.4));
                a(this.add.rectangle(-14, -4, 14, 10, 0x2a4545));
                a(this.add.rectangle(-14, -6, 10, 6, 0x1a3035, 0.6));
                a(this.add.rectangle(14, -2, 8, 5, 0x4a6565));
                a(this.add.ellipse(-16, 10, 10, 8, 0x1a1a1a));
                a(this.add.ellipse(-16, 10, 6, 5, 0x2a2a2a));
                a(this.add.ellipse(14, 11, 10, 8, 0x1a1a1a));
                a(this.add.ellipse(14, 11, 6, 5, 0x2a2a2a));
                a(this.add.rectangle(21, 2, 3, 5, 0xddddaa, 0.5));
                a(this.add.rectangle(-22, 2, 3, 4, 0xaa3333, 0.5));
                a(this.add.rectangle(22, 8, 3, 5, 0x444444));
                a(this.add.rectangle(-22, 8, 3, 5, 0x444444));
                a(this.add.rectangle(0, -2, 2, 10, 0x2a4545));
                obs.damage = 25;
            } else if (t === 2) { // Deer
                a(this.add.ellipse(1, 12, 22, 5, 0x000000, 0.15));
                a(this.add.rectangle(-4, 8, 3, 10, 0x5a4a3a));
                a(this.add.rectangle(2, 8, 3, 10, 0x5a4a3a));
                a(this.add.rectangle(-8, 9, 3, 8, 0x5a4a3a));
                a(this.add.rectangle(6, 9, 3, 8, 0x5a4a3a));
                a(this.add.ellipse(-1, 1, 24, 14, 0x7a6a5a));
                a(this.add.ellipse(-1, 0, 20, 12, 0x8a7a6a));
                a(this.add.ellipse(-1, -2, 12, 6, 0x9a8a7a, 0.3));
                a(this.add.circle(12, -3, 6, 0x8a7a6a));
                a(this.add.circle(12, -3, 4, 0x9a8a7a));
                a(this.add.circle(14, -4, 1.5, 0x222222));
                a(this.add.ellipse(16, -3, 3, 2, 0x6a5a4a));
                a(this.add.rectangle(10, -8, 2, 6, 0x5a4a3a).setAngle(-15));
                a(this.add.rectangle(13, -8, 2, 5, 0x5a4a3a).setAngle(15));
                a(this.add.ellipse(-12, 2, 6, 3, 0x7a6a5a));
                obs.damage = 15;
            } else { // Fallen log
                a(this.add.ellipse(2, 8, 42, 8, 0x000000, 0.15));
                a(this.add.rectangle(0, 2, 38, 10, 0x4a3a2a));
                a(this.add.rectangle(0, 0, 36, 8, 0x3a2a1a));
                a(this.add.rectangle(0, -1, 34, 6, 0x4a3a2a, 0.3));
                a(this.add.ellipse(-19, 2, 8, 10, 0x3a2a1a));
                a(this.add.ellipse(-19, 1, 6, 8, 0x5a4a3a));
                a(this.add.ellipse(19, 2, 8, 10, 0x3a2a1a));
                a(this.add.rectangle(-6, -1, 1, 6, 0x2a1a0a, 0.3));
                a(this.add.rectangle(8, 0, 1, 5, 0x2a1a0a, 0.2));
                a(this.add.rectangle(0, -3, 10, 2, 0x5a4a3a, 0.2));
                a(this.add.rectangle(-10, 5, 6, 2, 0x2a5a2a, 0.4));
                obs.damage = 15;
            }
        }
        this.physics.add.existing(obs); 
        obs.body.setSize(24, 20).setOffset(-12, -10);
        this.obstacles.add(obs);
    }
    

    

    
    spawnEvent() {
        const lane = Phaser.Math.Between(0, 2), x = CONFIG.width + 40, y = this.lanePositions[lane];
        const evt = this.add.container(x, y).setDepth(15);
        evt.add(this.add.rectangle(0, 0, 22, 22, 0x886633, 0.6).setAngle(45));
        evt.add(this.add.rectangle(0, 0, 18, 18, 0xaa8844, 0.4).setAngle(45));
        evt.add(this.add.text(0, 0, '?', { fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#ffcc66', fontStyle: 'bold' }).setOrigin(0.5));
        const pulse = this.add.rectangle(0, 0, 26, 26, 0xaa8844, 0.2).setAngle(45); evt.add(pulse);
        this.tweens.add({ targets: pulse, scaleX: 1.4, scaleY: 1.4, alpha: 0, duration: 800, yoyo: true, repeat: -1 });
        const types = ['gas_station','motel','supply_cache','survivor','ambush'];
        const names = { gas_station: 'Gas Station', motel: 'Roadside Motel', supply_cache: 'Supply Cache', survivor: 'Survivor', ambush: 'Ambush' };
        evt.eventType = types[Phaser.Math.Between(0, types.length-1)]; evt.eventName = names[evt.eventType];
        this.physics.add.existing(evt); evt.body.setSize(32, 32).setOffset(-16, -16); this.events.add(evt);
    }
    
    hitObstacle(v, o) {
        if (o.hit) return; o.hit = true;
        const sm = this.speed / 180, dmg = Math.ceil((o.damage || 15) * sm);
        this.state.vehicleHealth = Math.max(0, this.state.vehicleHealth - dmg);
        this.cameras.main.shake(120, 0.015 * sm);
        for (let i = 0; i < 5; i++) { const sp = this.add.circle(this.vehicle.x + Phaser.Math.Between(-15, 20), this.vehicle.y + Phaser.Math.Between(-10, 10), 3, Math.random() > 0.5 ? 0xffaa44 : 0x888888, 0.7).setDepth(25); this.tweens.add({ targets: sp, alpha: 0, x: sp.x - Phaser.Math.Between(10, 30), y: sp.y - Phaser.Math.Between(5, 20), duration: 400, onComplete: () => sp.destroy() }); }
        const dt2 = this.add.text(this.vehicle.x, this.vehicle.y - 20, '-' + dmg, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#ff4444', fontStyle: 'bold' }).setOrigin(0.5).setDepth(30);
        this.tweens.add({ targets: dt2, alpha: 0, y: dt2.y - 20, duration: 800, onComplete: () => dt2.destroy() });
        this.time.delayedCall(80, () => o.destroy());
    }
    
    nearEvent(v, e) { if (e.triggered || this.popupActive) return; e.triggered = true; this.currentEvent = e; this.showEventPopup(e); }
    showEventPopup(e) {
        if (this.popupActive) return; this.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        UIAtlas.build(this);
        const panel = UIManager.createPanel(this, W/2, H/2, 220, 130, {
            title: e.eventName, accent: 'barter', closable: false, depth: 200, modal: true
        });
        this.popupElements = [panel];
        const cb = panel._contentBounds;
        panel.add(this.add.text(0, cb.y + 8, 'Stop to investigate?', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#888' }).setOrigin(0.5));
        const stopBtn = UIManager.createButton(this, -50, cb.y + 45, 'STOP', {
            width: 70, height: 28, style: 'confirm', fontSize: uiPx(10), depth: 201,
            onClick: () => this.stopAtEvent()
        });
        panel.add(stopBtn);
        const passBtn = UIManager.createButton(this, 50, cb.y + 45, 'PASS', {
            width: 70, height: 28, style: 'normal', fontSize: uiPx(10), depth: 201,
            onClick: () => this.continueTravel()
        });
        panel.add(passBtn);
    }
    stopAtEvent() {
        this.closePopup();
        const evtType = this.currentEvent.eventType;
        this.currentEvent.destroy();
        this.currentEvent = null;
        
        // Transition to GameScene as a scavenge encounter
        SceneTransition.fadeTo(this, 'GameScene', {
            scavengeMode: true,
            scavengeType: evtType,
            distanceRemaining: Math.max(0, (1 - this.travelElapsed / this.travelDuration) * this.distance),
            destination: this.destination,
            playerState: this.state,
            destinationNode: this.destinationNode,
            mapSeed: this.mapSeed,
            currentNodeId: this.currentNodeId,
            previousNodeId: this.previousNodeId,
            completedNodes: this.completedNodes,
            traveledRoutes: this.traveledRoutes
        });
    }
    continueTravel() { this.closePopup(); if (this.currentEvent) { this.currentEvent.destroy(); this.currentEvent = null; } }
    closePopup() { this.popupActive = false; if (this.popupElements) { this.popupElements.forEach(e => { if (e && e.destroy) e.destroy(); }); this.popupElements = []; } }
    pickupCrate(v, c) { if (c.picked) return; c.picked = true; AudioManager.pickup(); Haptics.light(); const r = c.crateReward || 'ammo'; let msg = '+' + r; if (r === 'ammo') { const amt = Phaser.Math.Between(3, 6); this.state.powerAmmo = Math.min(99, (this.state.powerAmmo || 0) + amt); msg = '+' + amt + ' pwr ammo'; } else if (r === 'bits') { const amt = Phaser.Math.Between(10, 25); this.state.bits += amt; msg = '+' + amt + ' bits'; } else if (r === 'health') { const amt = Phaser.Math.Between(8, 15); this.state.health = Math.min(CONFIG.player.health, this.state.health + amt); msg = '+' + amt + ' hp'; } else if (r === 'materials') { const amt = Phaser.Math.Between(3, 8); this.state.materials = (this.state.materials || 0) + amt; msg = '+' + amt + ' mats'; } const t = this.add.text(c.x, c.y - 15, msg, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#ccaa44' }).setOrigin(0.5).setDepth(30); this.tweens.add({ targets: t, alpha: 0, y: t.y - 20, duration: 800, onComplete: () => t.destroy() }); if (c._shadow) c._shadow.destroy(); c.destroy(); }
    
    triggerBreakdown(reason) {
        if (this.breakdownTriggered) return; this.breakdownTriggered = true; this.popupActive = true; this.speed = 0; this.targetSpeed = 0;
        this.time.addEvent({ delay: 150, repeat: 8, callback: () => { const s = this.add.circle(this.vehicle.x + Phaser.Math.Between(-5, 20), this.vehicle.y - 10, Phaser.Math.Between(3, 6), 0x555555, 0.5).setDepth(25); this.tweens.add({ targets: s, alpha: 0, y: s.y - 30, scaleX: 2, scaleY: 2, duration: 800, onComplete: () => s.destroy() }); }});
        this.time.delayedCall(1200, () => {
            UIAtlas.build(this);
            const panel = UIManager.createPanel(this, CONFIG.width/2, CONFIG.height/2, 240, 140, {
                title: 'VEHICLE BREAKDOWN', accent: 'danger', closable: false, depth: 200, modal: true
            });
            const cb = panel._contentBounds;
            panel.add(this.add.text(0, cb.y + 15, 'Find a toolkit to repair.', { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#aaa' }).setOrigin(0.5));
            const btn = UIManager.createButton(this, 0, cb.y + 50, 'SEARCH AREA', {
                width: 120, height: 32, style: 'confirm', fontSize: uiPx(11), depth: 201,
                onClick: () => { SceneTransition.fadeTo(this, 'GameScene', { breakdownMode: true, breakdownReason: 'damage', playerState: this.state, destinationNode: this.destinationNode, mapSeed: this.mapSeed, currentNodeId: this.currentNodeId, previousNodeId: this.previousNodeId, completedNodes: this.completedNodes, traveledRoutes: this.traveledRoutes, distanceRemaining: Math.max(0, (1 - this.travelElapsed / this.travelDuration) * this.distance), destination: this.destination }); }
            });
            panel.add(btn);
        });
    }
    
    
    enterDestination() {
        if (this._drivingOff) return;
        this._drivingOff = true;
        
        // Clear popup
        if (this.popupElements) this.popupElements.forEach(e => e.destroy());
        this.popupElements = [];
        
        // Stop all active events
        this.breakdownTriggered = true;
        this.speed = 0;
        this.targetSpeed = 0;
        
        // Prepare transition data
        const passData = SceneTransition.mapReturnData(this);
        passData.destinationNode = this.destinationNode;
        passData.locationType = this.locationType;
        passData.rescueMode = this.rescueMode || false;
        const type = this.destinationNode?.type;
        const node = this.destinationNode;
        
        // Vehicle drive-off animation
        if (this.vehicle) {
            this.vehicle.body.moves = false;
            
            // Exhaust burst
            for (let p = 0; p < 8; p++) {
                this.time.delayedCall(p * 80, () => {
                    if (!this.vehicle || !this.vehicle.active) return;
                    const puff = this.add.circle(
                        this.vehicle.x - 36,
                        this.vehicle.y + 14 + Phaser.Math.Between(-3, 3),
                        Phaser.Math.Between(3, 7), 0x666666, 0.5
                    ).setDepth(19);
                    this.tweens.add({
                        targets: puff,
                        x: puff.x - Phaser.Math.Between(25, 50),
                        y: puff.y - Phaser.Math.Between(3, 10),
                        alpha: 0, scaleX: 2.5, scaleY: 2,
                        duration: 500,
                        onComplete: () => puff.destroy()
                    });
                });
            }
            
            // Spin wheels fast
            if (this._wheelSpokes) {
                const wheelSpin = this.time.addEvent({
                    delay: 25,
                    callback: () => {
                        this._wheelSpokes.forEach(s => { if (s.active) s.setAngle((s.angle + 18) % 360); });
                    },
                    repeat: 40
                });
            }
            
            // Drive off to the right
            this.tweens.add({
                targets: this.vehicle,
                x: CONFIG.width + 80,
                duration: 1000,
                ease: 'Quad.easeIn',
                onComplete: () => {
                    // Now transition
                    if (node && node.hasStoryEvent && !node.storyEventDone) {
                        this.showStoryEventOverlay(passData, node);
                    } else {
                        const target = type === 'haven' ? 'HavenScene' : 'GameScene';
                        SceneTransition.fadeTo(this, target, passData, { duration: 500 });
                    }
                }
            });
        } else {
            // Fallback if no vehicle
            if (node && node.hasStoryEvent && !node.storyEventDone) {
                this.showStoryEventOverlay(passData, node);
            } else {
                const target = type === 'haven' ? 'HavenScene' : 'GameScene';
                SceneTransition.fadeTo(this, target, passData, { duration: 500 });
            }
        }
    }
    
    showStoryEventOverlay(passData, node) {
        const W = CONFIG.width, H = CONFIG.height;
        const locType = node.locationType || 'house';
        const events = CONFIG.storyEvents[locType];
        if (!events || events.length === 0) {
            node.storyEventDone = true;
            const target = node.type === 'haven' ? 'HavenScene' : 'GameScene';
            SceneTransition.fadeTo(this, target, passData, { duration: 500 });
            return;
        }
        const evt = events[Math.floor(Math.random() * events.length)];
        if (this.popupElements) this.popupElements.forEach(e => e.destroy());
        this.popupElements = [];
        UIAtlas.build(this);
        const panelH = 130 + evt.choices.length * 40;
        const panel = UIManager.createPanel(this, W/2, H/2, W - 20, panelH, {
            title: evt.title, accent: 'barter', closable: false, depth: 200, modal: true
        });
        this.popupElements = [panel];
        const cb = panel._contentBounds;
        panel.add(this.add.text(0, cb.y + 10, evt.text, { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#cccccc', wordWrap: { width: W - 60 }, lineSpacing: 4 }).setOrigin(0.5));
        const startY = cb.y + 50;
        evt.choices.forEach((choice, idx) => {
            const by = startY + idx * 40;
            const choiceBtn = UIManager.createButton(this, 0, by, choice.label, {
                width: W - 60, height: 32, style: 'confirm', fontSize: uiPx(11), depth: 201,
                onClick: () => this.resolveStoryChoice(choice, passData, node)
            });
            panel.add(choiceBtn);
        });
    }

    
    resolveStoryChoice(choice, passData, node) {
        node.storyEventDone = true;
        const state = this.state;
        let resultText = choice.followUp || '';
        
        // Check for risk
        let risked = false;
        if (choice.risk && Math.random() < choice.risk) {
            risked = true;
            if (choice.riskCost === 'hp') {
                state.health = Math.max(1, state.health - (choice.riskValue || 20));
                resultText += ` (-${choice.riskValue} HP)`;
            } else if (choice.riskCost === 'ambush') {
                passData.ambushEnemies = choice.riskValue || 3;
                resultText += ' (Ambush!)';
            } else if (choice.riskCost === 'alarm') {
                passData.alarmTriggered = true;
                resultText += ' (Alarm triggered!)';
            }
        }
        
        // Apply outcome
        if (choice.outcome === 'fuel' || choice.outcome === 'fuel_risky') {
            const amt = risked && choice.outcome === 'fuel_risky' ? 0 : (choice.value || 3);
            if (amt > 0) { state.fuel = (state.fuel || 0) + amt; resultText += ` (+${amt} Fuel)`; }
        } else if (choice.outcome === 'hp') {
            state.health = Math.min(state.maxHealth || 100, state.health + (choice.value || 10));
            resultText += ` (+${choice.value} HP)`;
        } else if (choice.outcome === 'loot_bonus') {
            passData.lootMultiplier = choice.value || 1.5;
        } else if (choice.outcome === 'medical_bonus') {
            passData.lootMultiplier = choice.value || 2.0;
            passData.lootCategory = 'medical';
        } else if (choice.outcome === 'weapon_bonus') {
            passData.lootMultiplier = choice.value || 2.0;
            passData.lootCategory = 'weapon';
        } else if (choice.outcome === 'lore') {
            passData.loreRevealed = true;
        } else if (choice.outcome === 'safe_entry') {
            passData.reducedEnemies = true;
        } else if (choice.outcome === 'augment') {
            passData.guaranteedAugment = true;
        }
        
        // Show result then enter
        if (this.popupElements) this.popupElements.forEach(e => e.destroy());
        this.popupElements = [];
        
        const W = CONFIG.width, H = CONFIG.height;
        const overlay = this.add.rectangle(W/2, H/2, W, H, 0x000000, 0.85).setDepth(7.5);
        const result = this.add.text(W/2, H/2 - 20, resultText, {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#ccccaa',
            wordWrap: { width: W - 60 }, lineSpacing: 4
        }).setOrigin(0.5).setDepth(201);
        const cont = this.add.text(W/2, H/2 + 30, '[ Continue ]', {
            fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#88cc88', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(202).setInteractive({ useHandCursor: true });
        
        cont.on('pointerdown', () => {
            overlay.destroy(); result.destroy(); cont.destroy();
            const target = node.type === 'haven' ? 'HavenScene' : 'GameScene';
            SceneTransition.fadeTo(this, target, passData, { duration: 500 });
        });
    }
    
    playerDeath() {
        this.popupActive = true;
        
        // Process equipment loss (soulbound items survive)
        const eqResult = ItemManager.processDeathEquipment(this.state.equipment);
        
        if (this.state.backpack) ItemManager.clearInventory(this.state.backpack);
        this.state.bits = 0;
        this.state.powerAmmo = 0;
        UIAtlas.build(this);
        
        const lostNames = eqResult.lost.map(i => i.name);
        const savedNames = eqResult.soulSurvivorTriggered 
            ? ['SOUL SURVIVOR — All equipment protected!']
            : eqResult.saved.map(i => `${i.name} (${i.remaining} saves left)`);
        const lossText = lostNames.length > 0 ? `Lost: ${lostNames.join(', ')}` : 'Equipment saved';
        const saveText = savedNames.length > 0 ? (eqResult.soulSurvivorTriggered ? savedNames[0] : `Soulbound: ${savedNames.join(', ')}`) : '';
        const saveColor = eqResult.soulSurvivorTriggered ? '#ff2244' : '#ffaa22';
        const panelH = 140 + (saveText ? 20 : 0);
        
        const panel = UIManager.createPanel(this, CONFIG.width/2, CONFIG.height/2, 240, panelH, {
            title: 'CUBED', accent: 'danger', closable: false, depth: 200, modal: true
        });
        const cb = panel._contentBounds;
        panel.add(this.add.text(0, cb.y + 10, 'All run progress lost', { fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#aa4444' }).setOrigin(0.5));
        panel.add(this.add.text(0, cb.y + 28, lossText, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#886666', wordWrap: { width: 210 } }).setOrigin(0.5));
        if (saveText) {
            panel.add(this.add.text(0, cb.y + 46, saveText, { fontFamily: CONFIG.font, fontSize: uiPx(8), fill: saveColor, wordWrap: { width: 210 } }).setOrigin(0.5));
        }
        const btn = UIManager.createButton(this, 0, cb.y + cb.h - 20, 'RETURN', {
            width: 100, height: 30, style: 'danger', fontSize: uiPx(10), depth: 201,
            onClick: () => this.scene.start('SafehouseScene', SceneTransition.safehouseReturnData(this, { died: true }))
        });
        panel.add(btn);
    }

}
