// Vestige GPS — PortalDungeonScene
// Extracted from monolith lines 75111-75655
// Imports will be wired in integration pass

import { ConsumableSystem } from '../../core/consumableSystem.js';
import { DOTSystem } from '../../core/dotSystem.js';
import { ItemManager } from '../../core/itemManager.js';
import { SaveManager } from '../../core/saveManager.js';
import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { AudioManager } from '../audioManager.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { TelegraphSystem } from '../rendering/telegraphSystem.js';
import { SpriteManager } from '../spriteManager.js';
import { UIAtlas } from '../uiAtlas.js';
import { UIManager } from '../uiManager.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { InputManager } from '../rendering/inputManager.js';
import { HavenScene } from './HavenScene.js';


export class PortalDungeonScene extends Phaser.Scene {
    constructor() { super({ key: 'PortalDungeonScene' }); }

    init(data) {
        this.playerState = data.playerState || {};
        this.equipment = data.equipment || {};
        this.saveData = data.saveData || SaveManager.load();
        this.mode = data.mode || 'solo';
    }

    create() {
        this.floor = 1;
        this.enemiesAlive = 0;
        this.enemiesKilled = 0;
        this.bossesKilled = 0;
        this.itemsLooted = 0;
        this._chosenAbilities = [];
        this._dead = false;
        this.itemDrops = [];

        // Player state
        const eqStats = ItemManager.getEquipmentStats(this.equipment);
        this.state = {
            health: CONFIG.player.health + (eqStats.maxHealth || 0),
            maxHealth: CONFIG.player.health + (eqStats.maxHealth || 0),
            equipment: this.equipment,
            backpack: ItemManager.createInventory(6),
            bits: 0, dead: false
        };

        // Arena setup
        this.cameras.main.setBackgroundColor('#0a0a12');
        const W = CONFIG.width, H = CONFIG.height;
        this.arenaW = W; this.arenaH = H;

        // Floor arena
        this.add.rectangle(W/2, H/2, W, H, 0x12121a);
        // Floor pattern
        for (let x = 0; x < W; x += 40) {
            for (let y = 0; y < H; y += 40) {
                this.add.rectangle(x+20, y+20, 38, 38, 0x141420, 0.3).setStrokeStyle(1, 0x1a1a28, 0.15);
            }
        }

        // Player
        this.player = SpriteManager.createPlayerSprite(this, W/2, H/2 + 80, this.state.backpack, this.deployedSurvivor ? this.deployedSurvivor.equippedAura : null);
        this.player.setDepth(20);
        DynamicShadows.add(this, this.player, { offsetY: 10, scale: 0.6, alpha: 0.15, interior: true });
        this.physics.add.existing(this.player);
        this.player.body.setCollideWorldBounds(true);
        this.player.body.setSize(14, 10);
        this.player.body.setOffset(17, 28);
        InputManager.setup(this, { dodge: true, tapTarget: true });
        this.cameras.main.startFollow(this.player, true, 0.1, 0.1);

        // Enemy group
        this.enemies = this.physics.add.group();

        // UI
        this._buildPortalUI();

        // Audio — portal dungeon ambient
        try { AudioManager.playBiomeAmbient('anomalous'); } catch(e) {}

        // Start first floor
        this.startFloor();
    }

    _buildPortalUI() {
        const W = CONFIG.width, H = CONFIG.height;
        UIAtlas.build(this);
        this.floorText = this.add.text(W/2, 12, 'FLOOR 1', {
            fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#aa66ff', fontStyle: 'bold'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(100);
        // Player HP
        this.portalHP = UIManager.createHealthBar(this, 'player', {
            x: W/2, y: H - 20, depth: 101, scrollFactor: 0, width: 200, height: 12
        });
        this.portalHP.updateHP(this.state.health, this.state.maxHealth);
        // Bits counter (atlas icon + text)
        if (this.textures.exists('ui_icon_bits')) {
            this.add.image(10, 16, 'ui_icon_bits').setOrigin(0, 0.5).setScrollFactor(0).setDepth(100);
        }
        this.bitsText = this.add.text(26, 12, '0', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#ccaa44' }).setScrollFactor(0).setDepth(100);
        // Kill counter
        this.killText = this.add.text(W - 10, 12, '', { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#888' }).setOrigin(1, 0).setScrollFactor(0).setDepth(100);
        // Boss HP bar (hidden)
        this.portalBossHP = UIManager.createHealthBar(this, 'boss', {
            x: W/2, y: 35, depth: 100, scrollFactor: 0, width: 200, height: 16
        });
        this.portalBossHP.setVisible(false);
        this.bossNameText = null; // Name handled by boss bar
    }

    startFloor() {
        this.floorText.setText(`FLOOR ${this.floor}`);
        this.enemiesAlive = 0;
        const isBoss = this.floor % 5 === 0;

        // Show announcement
        this.showAnnouncement(
            isBoss ? `BOSS - FLOOR ${this.floor}` : `FLOOR ${this.floor}`,
            isBoss ? 'Prepare yourself.' : `${this._getEnemyCount()} hostiles incoming`
        );

        this.time.delayedCall(1500, () => {
            if (isBoss) this.spawnBoss();
            else this.spawnFloorEnemies();
        });
    }

    _getEnemyCount() {
        return Math.min(15, 3 + Math.floor(this.floor * 0.8));
    }

    _getEnemyHP() {
        return Math.round(20 + this.floor * 8);
    }

    _getEnemyDmg() {
        return Math.round(5 + this.floor * 1.5);
    }

    _getEnemySpeed() {
        return Math.min(90, 35 + this.floor * 1.2);
    }

    spawnFloorEnemies() {
        const count = this._getEnemyCount();
        const W = this.arenaW, H = this.arenaH;
        for (let i = 0; i < count; i++) {
            this.time.delayedCall(i * 300, () => {
                // Spawn from edges
                let sx, sy;
                const side = Math.floor(Math.random() * 4);
                if (side === 0) { sx = Math.random() * W; sy = -10; }
                else if (side === 1) { sx = Math.random() * W; sy = H + 10; }
                else if (side === 2) { sx = -10; sy = Math.random() * H; }
                else { sx = W + 10; sy = Math.random() * H; }
                this._spawnEnemy(sx, sy, false);
            });
        }
    }

    _spawnEnemy(x, y, isBoss) {
        const e = SpriteManager.createEnemySprite ? SpriteManager.createEnemySprite(this, x, y, isBoss ? 'boss' : 'husk') :
            this.add.circle(x, y, isBoss ? 12 : 6, isBoss ? 0x9944cc : 0xcc4444).setDepth(15);
        this.physics.add.existing(e);
        e.body.setCollideWorldBounds(false);
        e.hp = isBoss ? this._getBossHP() : this._getEnemyHP();
        e.maxHp = e.hp;
        e.dmg = isBoss ? this._getEnemyDmg() * 3 : this._getEnemyDmg();
        e.speed = isBoss ? this._getEnemySpeed() * 0.7 : this._getEnemySpeed();
        e.isBoss = isBoss;
        e.canAttack = true;
        e._attackCD = 0;
        this.enemies.add(e);
        DynamicShadows.add(this, e, { offsetY: 6, scale: isBoss ? 0.8 : 0.5, alpha: 0.12, interior: true });
        this.enemiesAlive++;
        return e;
    }

    _getBossHP() {
        return Math.round(150 + this.floor * 30);
    }

    spawnBoss() {
        const W = this.arenaW, H = this.arenaH;
        try { AudioManager.bossSpawn(); } catch(e) {}
        const bossTypes = ['warden', 'swarmQueen', 'phantom', 'ironclad', 'cubeAnomaly'];
        const bossIdx = Math.floor((this.floor / 5 - 1) % 5);
        const bossName = ['THE WARDEN', 'SWARM QUEEN', 'THE PHANTOM', 'THE IRONCLAD', 'CUBE ANOMALY'][bossIdx];

        const boss = this._spawnEnemy(W/2, 60, true);
        boss.bossType = bossTypes[bossIdx];
        this._currentBoss = boss;

        this.portalBossHP.setVisible(true);
        this.portalBossHP.setName(bossName);
        this.portalBossHP.updateHP(boss.hp, boss.maxHp);

        // Spawn a few adds
        for (let i = 0; i < 2 + Math.floor(this.floor / 10); i++) {
            this.time.delayedCall(2000 + i * 800, () => {
                this._spawnEnemy(Math.random() * W, Math.random() > 0.5 ? -10 : H + 10, false);
            });
        }
    }

    showAnnouncement(title, sub) {
        const c = this.add.container(CONFIG.width / 2, 50).setDepth(200).setAlpha(0).setScrollFactor(0);
        c.add(this.add.rectangle(0, 0, 240, 50, 0x000000, 0.75));
        c.add(this.add.text(0, -8, title, { fontFamily: CONFIG.font, fontSize: uiPx(13), fill: '#fff', fontStyle: 'bold' }).setOrigin(0.5));
        c.add(this.add.text(0, 12, sub, { fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#998877' }).setOrigin(0.5));
        this.tweens.add({ targets: c, alpha: 1, y: 55, duration: 300 });
        this.tweens.add({ targets: c, alpha: 0, y: 45, delay: 2200, duration: 400, onComplete: () => c.destroy() });
    }

    update(time, delta) {
        if (this._dead || !this.player) return;
        const dt = delta / 1000;

        // Player movement
        const _spd = this._getPlayerSpeed();
        const _touch = InputManager.getVelocity(this, _spd);
        this.player.body.setVelocity(_touch.vx, _touch.vy);
        SpriteManager.updatePlayerAnimation(this.player, _touch.vx, _touch.vy, this);

        // Auto-attack nearest enemy
        if (!this._attackCD || this._attackCD <= 0) {
            let nearest = null, nearDist = 120;
            this.enemies.getChildren().forEach(e => {
                if (!e.active) return;
                const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, e.x, e.y);
                if (d < nearDist) { nearDist = d; nearest = e; }
            });
            if (nearest) {
                this._doAttack(nearest);
                const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
                this._attackCD = 1.0 / Math.max(0.5, (eqStats.fireRate || 2));
            }
        }
        if (this._attackCD > 0) this._attackCD -= dt;

        // Enemy AI
        this.enemies.getChildren().forEach(e => {
            if (!e.active) return;
            const dist = Phaser.Math.Distance.Between(e.x, e.y, this.player.x, this.player.y);
            const angle = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
            e.body.setVelocity(Math.cos(angle) * e.speed, Math.sin(angle) * e.speed);
            e.setDepth(10 + e.y * 0.01);

            // Attack player
            if (dist < 20 && e.canAttack) {
                e.canAttack = false;
                this.state.health -= e.dmg;
                try { AudioManager.playerHit(); } catch(ex) {}
                ConsumableSystem.interruptChannel();
                this.cameras.main.shake(100, 0.01);
                this.time.delayedCall(e.isBoss ? 1500 : 800, () => { if (e.active) e.canAttack = true; });
                if (this.state.health <= 0) this._die();
            }
        });

        // Update UI
        this.portalHP.updateHP(Math.max(0, this.state.health), this.state.maxHealth);
        this.bitsText.setText(`${this.state.bits}`);
        this.killText.setText(`x${this.enemiesKilled}`);

        if (this._currentBoss && this._currentBoss.active) {
            this.portalBossHP.updateHP(this._currentBoss.hp, this._currentBoss.maxHp);
        }

        // Loot pickup
        this.itemDrops.forEach((drop, idx) => {
            if (!drop.active) return;
            const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, drop.x, drop.y);
            if (d < 25) {
                if (drop.itemData && ItemManager.addItem(this.state.backpack, drop.itemData)) {
                    this.state.bits += drop.itemData.tier * 5;
                    this.itemsLooted++;
                    try { AudioManager.pickup(); } catch(ex) {}
                }
                drop.destroy();
                this.itemDrops.splice(idx, 1);
            }
        });

        DynamicShadows.update(this);
    }

    _getPlayerSpeed() {
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        let speed = eqStats.moveSpeed || 100;
        if (this._defSpeedMult) speed *= this._defSpeedMult;
        return speed;
    }

    _doAttack(target) {
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        let dmg = Math.max(3, (eqStats.damage || 8) + (eqStats.meleeDamage || 0));
        
        // Gym damage bonus
        if (eqStats.gymDamageBonus) dmg = Math.round(dmg * (1 + eqStats.gymDamageBonus / 100));

        // Roguelike bonuses
        if (this._defCritBonus && Math.random() * 100 < (this._defCritBonus + (eqStats.crit || 0))) {
            dmg *= 1.5;
        }

        target.hp -= dmg;
        try { AudioManager.shoot(); } catch(e) {}

        // Visual feedback
        const txt = this.add.text(target.x, target.y - 15, `-${Math.round(dmg)}`, {
            fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#ff4444', fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(50);
        this.tweens.add({ targets: txt, y: txt.y - 20, alpha: 0, duration: 400, onComplete: () => txt.destroy() });

        // Bullet line
        const line = this.add.line(0, 0, this.player.x, this.player.y, target.x, target.y, 0xffaa44, 0.5).setDepth(18);
        this.time.delayedCall(80, () => line.destroy());

        if (target.hp <= 0) this._killEnemy(target);
    }

    _killEnemy(e) {
        DynamicShadows.remove(this, e);
        this.enemiesKilled++;
        try { AudioManager.enemyDeath(); } catch(ex) {}
        this.enemiesAlive--;
        this.state.bits += e.isBoss ? 50 + this.floor * 5 : 5 + Math.floor(this.floor * 0.5);

        // Loot drop
        const dropChance = e.isBoss ? 1.0 : 0.25 + this.floor * 0.005;
        if (Math.random() < dropChance) {
            const table = e.isBoss ? 'boss' : (this.floor > 20 ? 'enemy_late' : this.floor > 10 ? 'enemy_mid' : 'enemy_early');
            const killLuck = (ItemManager.getEquipmentStats(this.state.equipment).lootLuck) || 0;
            const result = ItemManager.rollLootTable(table, killLuck, Math.ceil(this.floor / 5));
            if (result) {
                let item;
                if (typeof result === 'string') item = ItemManager.createItem(result);
                else item = result;
                if (item) {
                    // Boss: tiny Bane chance
                    if (e.isBoss && Math.random() < 0.005) {
                        const baneKeys = Object.keys(CONFIG.baneWeapons);
                        const baneKey = baneKeys[Math.floor(Math.random() * baneKeys.length)];
                        const bane = CONFIG.baneWeapons[baneKey];
                        item = {
                            ...bane, id: `bane_${baneKey}_${Date.now()}`,
                            tier: 6, tierName: 'Bane', tierLabel: 'Bane',
                            tierColor: CONFIG.tiers[6].color, rarity: 'bane',
                            isBane: true, procedural: true
                        };
                    }
                    const color = ItemManager.getItemColor(item);
                    const drop = this.add.circle(e.x, e.y, 5, color, 0.9).setDepth(16);
                    drop.itemData = item;
                    this.itemDrops.push(drop);
                    // Pulse
                    this.tweens.add({ targets: drop, scaleX: 1.3, scaleY: 1.3, duration: 400, yoyo: true, repeat: -1 });
                }
            }
        }

        // Death particles
        for (let i = 0; i < 5; i++) {
            const p = this.add.circle(e.x + Phaser.Math.Between(-8, 8), e.y + Phaser.Math.Between(-8, 8), 3, 0xcc4444, 0.7).setDepth(25);
            this.tweens.add({ targets: p, alpha: 0, y: p.y - 15, duration: 400, onComplete: () => p.destroy() });
        }

        if (e.isBoss) {
            this.bossesKilled++;
            this.portalBossHP.setVisible(false);
            this._currentBoss = null;
            this.cameras.main.flash(300, 255, 200, 100);
            try { AudioManager.levelUp(); } catch(ex) {}
        }

        e.destroy();

        // Check floor clear
        if (this.enemiesAlive <= 0) {
            this.time.delayedCall(800, () => this._floorCleared());
        }
    }

    _floorCleared() {
        this.state.bits += 10 + this.floor * 2;

        // Roguelike ability every 5 floors (max 5 abilities = 25 floors)
        if (this.floor % 5 === 0 && this._chosenAbilities.length < 5) {
            this._showAbilityChoice();
        } else {
            this._nextFloor();
        }
    }

    _nextFloor() {
        this.floor++;
        // Heal between floors
        this.state.health = Math.min(this.state.maxHealth, this.state.health + Math.round(this.state.maxHealth * 0.15));
        // Clear remaining drops
        this.itemDrops.forEach(d => { if (d.active) d.destroy(); });
        this.itemDrops = [];
        this.startFloor();
    }

    _showAbilityChoice() {
        this.popupActive = true;
        const pool = this._getAbilityPool();
        const available = pool.filter(a => !this._chosenAbilities.includes(a.id));
        const choices = available.sort(() => Math.random() - 0.5).slice(0, 3);
        if (choices.length === 0) { this.popupActive = false; this._nextFloor(); return; }

        const ui = [];
        const W = CONFIG.width, H = CONFIG.height;
        const bg = this.add.rectangle(W/2, H/2, W, H, 0x000000, 0.6).setScrollFactor(0).setDepth(200).setInteractive();
        ui.push(bg);
        ui.push(this.add.text(W/2, H/2 - 85, 'CHOOSE ABILITY', { fontFamily:CONFIG.font, fontSize: uiPx(12), fill:'#cc8844', fontStyle:'bold' }).setOrigin(0.5).setScrollFactor(0).setDepth(201));
        ui.push(this.add.text(W/2, H/2 - 68, `Floor ${this.floor} bonus`, { fontFamily:CONFIG.font, fontSize: uiPx(8), fill:'#887766' }).setOrigin(0.5).setScrollFactor(0).setDepth(201));

        const cardW = 90;
        const startX = W/2 - (choices.length - 1) * (cardW + 8) / 2;
        choices.forEach((ab, i) => {
            const ax = startX + i * (cardW + 8);
            const card = this.add.rectangle(ax, H/2 + 5, cardW, 100, 0x222222, 0.9).setStrokeStyle(1, ab.color).setScrollFactor(0).setDepth(202).setInteractive({ useHandCursor: true });
            ui.push(card);
            ui.push(this.add.text(ax, H/2 - 30, ab.icon, { fontSize: uiPx(18) }).setOrigin(0.5).setScrollFactor(0).setDepth(203));
            ui.push(this.add.text(ax, H/2 - 5, ab.name, { fontFamily:CONFIG.font, fontSize: uiPx(8), fill:'#fff', fontStyle:'bold', wordWrap:{width:cardW-8}, align:'center' }).setOrigin(0.5).setScrollFactor(0).setDepth(203));
            ui.push(this.add.text(ax, H/2 + 22, ab.desc, { fontFamily:CONFIG.font, fontSize: uiPx(7), fill:'#aa9977', wordWrap:{width:cardW-10}, align:'center' }).setOrigin(0.5).setScrollFactor(0).setDepth(203));
            card.on('pointerdown', () => {
                try { AudioManager.uiClick(); } catch(ex) {}
                ab.apply(this);
                this._chosenAbilities.push(ab.id);
                ui.forEach(el => { if (el && el.active !== false) el.destroy(); });
                this.popupActive = false;
                this.showAnnouncement(ab.name, ab.desc);
                this.time.delayedCall(1500, () => this._nextFloor());
            });
        });
    }

    _getAbilityPool() {
        return [
            { id:'rapid_fire', name:'Rapid Fire', desc:'Attack speed +25%', icon:'⚡', color:0xcc4444, apply:(s)=>{ s._attackSpeedMult = (s._attackSpeedMult||1)*0.75; }},
            { id:'piercing', name:'Piercing Rounds', desc:'+15% damage', icon:'➤', color:0xcc6644, apply:(s)=>{ s._dmgBonus = (s._dmgBonus||0)+15; }},
            { id:'crit_chance', name:'Sharpshooter', desc:'Crit chance +15%', icon:'◎', color:0xdd5555, apply:(s)=>{ s._defCritBonus = (s._defCritBonus||0)+15; }},
            { id:'regen', name:'Regeneration', desc:'Heal 2 HP/sec', icon:'+', color:0x44cc44, apply:(s)=>{
                if(!s._regenTimer) s._regenTimer = s.time.addEvent({ delay:1000, loop:true, callback:()=>{ if(!s._dead) s.state.health = Math.min(s.state.maxHealth, s.state.health+2); }});
            }},
            { id:'speed', name:'Adrenaline', desc:'Move +20% faster', icon:'»', color:0xccaa44, apply:(s)=>{ s._defSpeedMult = (s._defSpeedMult||1)*1.2; }},
            { id:'armor', name:'Reinforced', desc:'+30 max HP', icon:'🛡', color:0x4488cc, apply:(s)=>{ s.state.maxHealth += 30; s.state.health += 30; }},
            { id:'lifesteal', name:'Vampiric', desc:'Heal 10% of damage dealt', icon:'🩸', color:0xcc44aa, apply:(s)=>{ s._lifesteal = (s._lifesteal||0)+10; }},
            { id:'explosive', name:'Explosive Kills', desc:'Enemies explode on death', icon:'💥', color:0xff6622, apply:(s)=>{ s._explosiveKills = true; }},
            { id:'slow_aura', name:'Concussion Field', desc:'Nearby enemies 20% slower', icon:'◉', color:0x8866cc, apply:(s)=>{ s._slowAura = (s._slowAura||0)+20; }},
            { id:'double_loot', name:'Scavenger', desc:'Double loot chance', icon:'📦', color:0xaaaa44, apply:(s)=>{ s._doubleLoot = true; }},
        ];
    }

    _die() {
        if (this._dead) return;
        this._dead = true;
        this.state.dead = true;
        try { AudioManager.playerDeath(); } catch(e) {}
        try { AudioManager.stopAmbient(); } catch(e) {}
        DOTSystem.clearPlayer();
        TelegraphSystem.cancelAll();

        this.cameras.main.shake(500, 0.03);
        this.cameras.main.fade(1500, 20, 0, 0);

        // Record results
        const sd = this.saveData || SaveManager.load();
        if (!sd.haven) sd.haven = {};
        if (!sd.haven.portal) sd.haven.portal = { highestFloor: 0, leaderboard: [] };
        if (this.floor > sd.haven.portal.highestFloor) sd.haven.portal.highestFloor = this.floor;
        sd.haven.portal.leaderboard.push({
            floor: this.floor,
            kills: this.enemiesKilled,
            date: new Date().toLocaleDateString()
        });
        // Keep top 20
        sd.haven.portal.leaderboard.sort((a,b) => b.floor - a.floor);
        sd.haven.portal.leaderboard = sd.haven.portal.leaderboard.slice(0, 20);

        // Deposit loot to stash
        for (const item of this.state.backpack) {
            if (item) ItemManager.addItem(sd.stash.inventory, item);
        }
        sd.stash.bits += this.state.bits;

        // Update challenge progress
        if (sd.haven.challenges) {
            const updateMax = (stat, val) => {
                ['daily','weekly','monthly'].forEach(t => {
                    (sd.haven.challenges[t]||[]).forEach(c => {
                        if (c.stat === stat) c.progress = Math.max(c.progress, val);
                    });
                });
            };
            const updateAdd = (stat, val) => {
                ['daily','weekly','monthly'].forEach(t => {
                    (sd.haven.challenges[t]||[]).forEach(c => {
                        if (c.stat === stat) c.progress = (c.progress || 0) + val;
                    });
                });
            };
            updateAdd('portalKills', this.enemiesKilled);
            updateMax('portalFloor', this.floor);
            updateAdd('portalBosses', this.bossesKilled);
            updateAdd('portalLoot', this.itemsLooted);
        }

        // Faction rep
        if (sd.haven.faction && sd.haven.faction.pledged) {
            const fid = sd.haven.faction.pledged;
            sd.haven.faction.reputation[fid] = (sd.haven.faction.reputation[fid] || 0) + Math.floor(this.floor * 2);
        }

        SaveManager.save(sd);

        // Show results then return to haven
        this.time.delayedCall(1800, () => {
            this._showResults();
        });
    }

    _showResults() {
        const W = CONFIG.width, H = CONFIG.height;
        const cx = this.cameras.main.scrollX + W/2, cy = this.cameras.main.scrollY + H/2;
        const panel = UIManager.createPanel(this, cx, cy, W - 30, 320, {
            title: 'PORTAL RUN COMPLETE', accent: 'portal', closable: false, depth: 300, modal: true
        });
        const cb = panel._contentBounds;
        panel.add(this.add.text(0, cb.y + 10, `Reached Floor ${this.floor}`, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(11), fill:'#ccaa44' }).setOrigin(0.5));
        const stats = [
            `Enemies killed: ${this.enemiesKilled}`,
            `Bosses defeated: ${this.bossesKilled}`,
            `Items looted: ${this.itemsLooted}`,
            `Bits earned: ${this.state.bits}`,
            `Abilities chosen: ${this._chosenAbilities.length}/5`,
        ];
        stats.forEach((s, i) => {
            panel.add(this.add.text(0, cb.y + 35 + i * 18, s, { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(9), fill:'#888' }).setOrigin(0.5));
        });
        panel.add(this.add.text(0, cb.y + 135, 'All loot deposited to stash.', { fontFamily:'Share Tech Mono, monospace', fontSize: uiPx(8), fill:'#44cc44' }).setOrigin(0.5));

        const btn = UIManager.createButton(this, 0, cb.y + 170, 'RETURN TO HAVEN', {
            width: 180, height: 36, style: 'confirm', fontSize: uiPx(10), depth: 301,
            onClick: () => {
                const sd = this.saveData || SaveManager.load();
                SceneTransition.fadeTo(this, 'HavenScene', {
                    playerState: { bits: 0, powerAmmo: sd.stash.powerAmmo, fuel: sd.stash.fuel, reach: sd.stats ? sd.stats.highestReach : 1 },
                    saveData: sd
                }, { duration: 500 });
            }
        });
        panel.add(btn);
    }
}

// ==================== STORY SCENE ====================
// Full-screen branching narrative encounters

