// Vestige GPS — InteriorScene
// Extracted from monolith lines 66370-71810
// Imports will be wired in integration pass

import { Blurbs } from '../../core/blurbs.js';
import { CombatSystem } from '../../core/combatSystem.js';
import { ConsumableSystem } from '../../core/consumableSystem.js';
import { DOTManager } from '../../core/dotManager.js';
import { DOTSystem } from '../../core/dotSystem.js';
import { EventBus } from '../../core/eventBus.js';
import { Haptics } from '../../core/haptics.js';
import { ItemManager } from '../../core/itemManager.js';
import { SaveManager } from '../../core/saveManager.js';
import { SignatureEffects } from '../../core/signatureEffects.js';
import { Utils, _restoreTint, uiPx } from '../../core/utils.js';
import { BUILDING_STATE } from '../../data/buildingState.js';
import { CONFIG } from '../../data/config.js';
import { ISO_DEFS } from '../../data/isoDefs.js';
import { AudioManager } from '../audioManager.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { InteractHighlight } from '../interactHighlight.js';
import { IsoRenderer } from '../isoRenderer.js';
import { FloorRenderer } from '../rendering/floorRenderer.js';
import { WallRenderer } from '../rendering/wallRenderer.js';
import { SpriteManager } from '../spriteManager.js';
import { GameHUD } from '../ui/gameHUD.js';
import { InventoryUI } from '../ui/inventoryUI.js';
import { PlayerStatusIcons } from '../ui/playerStatusIcons.js';
import { UIManager } from '../uiManager.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { GameScene } from './GameScene.js';


export class InteriorScene extends Phaser.Scene {
    constructor() {
        super({ key: 'InteriorScene' });
    }
    
    init(data) {
        this.archetypeName = data.archetype || 'commercial';
        this.subtype = data.subtype || null;
        this.buildingType = data.buildingType || null;
        this.archetype = CONFIG.buildingArchetypes[this.archetypeName] || CONFIG.buildingArchetypes.commercial;
        this.buildingName = data.buildingName || 'Building';
        this.playerState = data.playerState || { 
            health: 100, 
            powerAmmo: 0, 
            kills: 0, 
            bits: 0,
            fuel: 100,
            materials: 0,
            backpack: ItemManager.createInventory(CONFIG.inventory.backpackSlots),
            vehicle: ItemManager.createInventory(CONFIG.inventory.vehicleSlots),
            equipment: { weapon: null, melee: null, gear: null, consumable: null }
        };
        this.buildingWidth = data.buildingWidth || 140;
        this.buildingHeight = data.buildingHeight || 100;
        
        // Alias for compatibility — many methods reference this.state
        this.state = this.playerState;
        
        // Saved state for restoration
        this.savedPlayerPos = data.savedPlayerPos || null;
        this.savedRouteSeed = data.savedRouteSeed || null;
        
        // Map data passthrough
        this.fromMap = data.fromMap || false;
        this.destinationNode = data.destinationNode || null;
        this.currentNodeId = data.currentNodeId || null;
        this.previousNodeId = data.previousNodeId || null;
        this.completedNodes = data.completedNodes || [];
        this.activeRoute = data.activeRoute || null;
        this.deployedSurvivor = data.deployedSurvivor || null;
        this.traveledRoutes = data.traveledRoutes || [];
        this.mapSeed = data.mapSeed || null;
        this.currentRow = data.currentRow || 1;
        
        // Sub-room support — if this is a door transition from a parent room
        this.isSubRoom = data.isSubRoom || false;
        this.parentData = data.parentData || null;
        this.subRoomName = data.subRoomName || null;
        
        // Per-building interior scale (overrides archetype default when present)
        this.interiorScaleOverride = data.interiorScale || null;
        
        // Building identity for state persistence
        this.buildingId = data.buildingId || null;
        
        // Door orientation: 'north' = entered from north face, 'south' = from south
        this.doorSide = data.doorSide || 'south';
        
        // Garage interior flag
        this.isGarage = data.isGarage || false;
        
        // Breakdown mode — toolkit hidden inside this building
        this.breakdownToolkit = data.breakdownToolkit || false;
        
        // Return-from-sub-room: which door to spawn at
        this.returnToDoor = data.returnToDoor || null;
        
        // Location system data passthrough
        this.locationType = data.locationType || null;
        this.lootMultiplier = data.lootMultiplier || 1.0;
        
        // Mode passthrough — so exitBuilding can return to correct GameScene mode
        // breakdownMode removed - deprecated
        // scavengeMode removed - deprecated
        this.rescueMode = data.rescueMode || false;
        
        // Seeded RNG for deterministic interior layouts
        // Hash buildingId to a numeric seed
        let interiorSeed = 12345;
        if (this.buildingId) {
            for (let i = 0; i < this.buildingId.length; i++) {
                interiorSeed = ((interiorSeed << 5) - interiorSeed + this.buildingId.charCodeAt(i)) & 0x7fffffff;
            }
        }
        Utils.attachRNG(this, interiorSeed);
        
        // Override Phaser.Math.Between for this scene during generation
        this._origBetween = Phaser.Math.Between;
        this._origMathRandom = Math.random;
        const self = this;
        this._seededBetween = (min, max) => Math.floor(self.random() * (max - min + 1)) + min;
        Phaser.Math.Between = this._seededBetween;
        Math.random = () => self.random();
        
        // Room size — sub-rooms are smaller, otherwise use per-building scale or archetype default
        const sizeMultiplier = this.isSubRoom ? 1.6 : (this.interiorScaleOverride || this.archetype.sizeMultiplier || 2.2);
        const mainW = Math.max(250, this.buildingWidth * sizeMultiplier);
        const mainH = Math.max(200, this.buildingHeight * sizeMultiplier);
        this.interiorW = mainW;
        this.interiorH = mainH;
        
        try {
        
        // World size = room size with padding (no side room expansion needed)
        const worldW = Math.max(mainW + 40, CONFIG.width);
        const worldH = Math.max(mainH + 60, CONFIG.height);
        this.physics.world.setBounds(0, 0, worldW, worldH);
        
        this.mainCX = worldW / 2;
        this.mainCY = worldH / 2;
        
        // Floor
        this.createFloor(worldW, worldH, mainW, mainH);
        
        // Walls + floorplan
        this.walls = this.physics.add.staticGroup();
        this.interiorDoors = [];
        
        // Generate door list FIRST so we know where sub-room gaps go
        if (!this.isSubRoom && !this.isGarage) {
            this.generateDoorList(mainW, mainH);
        }
        
        // Calculate floorplan — sub-room rects + gap positions
        this.subRooms = [];
        if (!this.isSubRoom && !this.isGarage && this.interiorDoors.length > 0) {
            this.planFloorplan(mainW, mainH);
        }
        
        // Build main room walls (with gaps for sub-room connections)
        this.createWalls(worldW, worldH, mainW, mainH);
        
// Door list + floorplan generated before walls (see below)
        
        // Place doors on walls
        this.buildDoors(mainW, mainH);
        
        // Interior furniture
        this.lootObjects = [];
        // Capture first-visit state BEFORE generateInterior sets visited=true
        const bStatePreGen = this.buildingId ? BUILDING_STATE[this.buildingId] : null;
        this._isFirstVisit = !(bStatePreGen && bStatePreGen.visited);
        this.generateInterior(mainW, mainH);
        
        this.walls.refresh();
        
        // Player — spawn near entrance, or near the door we returned from
        // doorSide determines where the exit and player spawn are:
        // 'north' → exit at top, spawn at top
        // 'south' (default) → exit at bottom, spawn at bottom
        // 'left' → exit on left wall, spawn at left
        // 'right' → exit on right wall, spawn at right
        let playerStartX = this.mainCX;
        let playerStartY = this.mainCY;
        if (this.doorSide === 'north') {
            playerStartY = this.mainCY - mainH / 2 + 40;
        } else if (this.doorSide === 'left') {
            playerStartX = this.mainCX - mainW / 2 + 40;
            playerStartY = this.mainCY;
        } else if (this.doorSide === 'right') {
            playerStartX = this.mainCX + mainW / 2 - 40;
            playerStartY = this.mainCY;
        } else {
            playerStartY = this.mainCY + mainH / 2 - 40;
        }
        
        if (this.returnToDoor && this.interiorDoors.length > 0) {
            const targetDoor = this.interiorDoors.find(d => d.name === this.returnToDoor);
            if (targetDoor && targetDoor.x !== undefined) {
                // Spawn player just inside the door, offset toward room center
                const offsetX = targetDoor.wall === 'left' ? 30 : targetDoor.wall === 'right' ? -30 : 0;
                const offsetY = targetDoor.wall === 'top' ? 30 : targetDoor.wall === 'bottom' ? -30 : 0;
                playerStartX = targetDoor.x + offsetX;
                playerStartY = targetDoor.y + offsetY;
                
                // Nudge away from any furniture that ended up near the door
                if (this._placedFurniture) {
                    for (const f of this._placedFurniture) {
                        if (Math.abs(f.x - playerStartX) < 20 && Math.abs(f.y - playerStartY) < 20) {
                            // Push toward room center
                            playerStartX += (this.mainCX - playerStartX) > 0 ? 25 : -25;
                            break;
                        }
                    }
                }
            }
        }
        
        this.player = SpriteManager.createPlayerSprite(this, playerStartX, playerStartY, this.playerState.backpack, this.deployedSurvivor ? this.deployedSurvivor.equippedAura : null);
        this.player.setDepth(10 + playerStartY * 0.05).setCollideWorldBounds(true);
        this.player._isArmedTexture = false;
        this.player._isMeleeSwinging = false;
        // Apply gear outfit
        if (this.state && this.state.equipment && this.state.equipment.gear) {
            const gi = this.state.equipment.gear;
            if (gi.outfit) {
                const custom = Object.assign({}, SpriteManager.playerCustomization);
                custom.shirt = gi.outfit.shirt;
                custom.pants = gi.outfit.pants;
                custom.gearType = gi.gearClass || gi.baseId;
                SpriteManager.rebuildPlayerSheet(this, custom);
                this.player.setTexture('player_sheet', 0);
                this.player.setDisplaySize(40, 40);
            }
        }
        // Resolve weapon sprite type from equipment for armed sheet lookup
        if (this.state && this.state.equipment && this.state.equipment.weapon) {
            this.player.weaponType = SpriteManager.getWeaponSpriteType(this.state.equipment.weapon.baseId);
            this.player.weaponFlair = this.state.equipment.weapon.flair || null;
        }
        if (this.state && this.state.equipment && this.state.equipment.melee) {
            this.player.meleeFlair = this.state.equipment.melee.flair || null;
            // Rebuild melee sheet with actual weapon art
            const meleeItem = this.state.equipment.melee;
            const mt = (meleeItem.baseId === 'blunt') ? 'blunt' : (meleeItem.baseId === 'heavy') ? 'heavy' : 'blade';
            {
                SpriteManager.meleeSheets[mt] = SpriteManager.generateMeleeSheet(SpriteManager.playerCustomization, mt, meleeItem);
                const sheetKey = 'player_sheet_melee_' + mt;
                if (this.textures.exists(sheetKey)) this.textures.remove(sheetKey);
                this.textures.addSpriteSheet(sheetKey, SpriteManager.meleeSheets[mt], { frameWidth: 48, frameHeight: 48 });
                const dirs = ['down', 'down_right', 'right', 'up_right', 'up', 'up_left', 'left', 'down_left'];
                dirs.forEach((dir, i) => {
                    const animKey = `player_melee_${mt}_${dir}`;
                    if (this.anims.exists(animKey)) this.anims.remove(animKey);
                    this.anims.create({ key: animKey, frames: this.anims.generateFrameNumbers(sheetKey, { start: i*3, end: i*3+2 }), frameRate: 10, repeat: 0 });
                });
            }
        }
        DynamicShadows.add(this, this.player, { offsetY: 10, scale: 0.6, alpha: 0.15, interior: true });
        this.physics.add.collider(this.player, this.walls);
        
        // Camera
        // Expand camera and world for sub-rooms
        let finalW = worldW, finalH = worldH;
        if (this.subRooms && this.subRooms.length > 0) {
            let maxX = worldW, maxY = worldH;
            for (const sr of this.subRooms) {
                maxX = Math.max(maxX, sr.cx + sr.w/2 + 40);
                maxY = Math.max(maxY, sr.cy + sr.h/2 + 40);
            }
            finalW = Math.max(maxX, CONFIG.width);
            finalH = Math.max(maxY, CONFIG.height);
            this.physics.world.setBounds(0, 0, finalW, finalH);
        }
        this.cameras.main.setBounds(0, 0, finalW, finalH);
        this.cameras.main.startFollow(this.player, true, 1, 1);
        this.cameras.main.setBackgroundColor('#0a0a12');
        this.cameras.main.setRoundPixels(true);
        
        // Room name HUD — larger text, fades on each room transition
        this._currentRoomName = null;
        this._roomLabel = this.add.text(CONFIG.width / 2, CONFIG.height / 2 - 40, '', {
            fontFamily: CONFIG.font, fontSize: uiPx(18), fill: '#8a9aaa',
            fontStyle: 'bold'
        }).setOrigin(0.5).setDepth(1000).setScrollFactor(0).setAlpha(0);
        
        } catch (genError) {
            console.error('VESTIGE: Interior generation error:', genError);
            // Ensure player exists even if generation partially failed
            if (!this.player) {
                this.player = SpriteManager.createPlayerSprite(this, this.mainCX || CONFIG.width/2, this.mainCY || CONFIG.height/2, this.playerState.backpack, this.deployedSurvivor ? this.deployedSurvivor.equippedAura : null);
                this.player.setDepth(10 + (this.mainCY || CONFIG.height/2) * 0.05).setCollideWorldBounds(true);
                if (this.walls) this.physics.add.collider(this.player, this.walls);
            }
        } finally {
        // Restore original random — combat, UI, tweens use non-seeded random
        // MUST happen even if generation throws, or Math.random stays corrupted globally
        Phaser.Math.Between = this._origBetween;
        Math.random = this._origMathRandom;
        }
        
        this.moveDir = { x: 0, y: 0 };
        
        // Interior combat system — enemies, bullets, hazards
        if (this.player) {
            this.setupInteriorCombat();
        }
        
        // If no enemies were spawned, mark building as cleared to prevent respawn on re-entry
        const hasEnemies = (this.enemies && this.enemies.getChildren().length > 0) || 
                          (this.dormantEnemies && this.dormantEnemies.some(d => d.active));
        if (!hasEnemies && this.buildingId) {
            if (!BUILDING_STATE[this.buildingId]) BUILDING_STATE[this.buildingId] = {};
            BUILDING_STATE[this.buildingId].enemiesCleared = true;
        }
        
        this.createUI();
        this.setupInput();
        
        // Ambience lighting
        this.createAmbienceLight(this.mainCX, this.mainCY, mainW, mainH);
        
        // Breakdown toolkit — spawn inside this building if flagged
        if (this.breakdownToolkit) {
            this.spawnBreakdownToolkit(mainW, mainH);
        }
        
        this.cameras.main.fadeIn(300);
    }
    
    // spawnBreakdownToolkit removed - deprecated
    
    generateDoorList(mainW, mainH) {
        // Location-specific room layouts override archetype defaults
        let minRooms, maxRooms, names;
        
        if (this.locationType) {
            const locationRooms = {
                gas_station: { rooms: [0, 1], names: ['Storage', 'Office'] },
                pharmacy: { rooms: [1, 2], names: ['Back Room', 'Storage', 'Office'] },
                hardware_store: { rooms: [1, 2], names: ['Storeroom', 'Workshop', 'Office'] },
                grocery: { rooms: [1, 1], names: ['Walk-in Cooler', 'Storage'] },
                house: { rooms: [2, 3], names: ['Bedroom', 'Bathroom', 'Kitchen', 'Closet'] },
                apartment: { rooms: [1, 2], names: ['Bedroom', 'Bathroom', 'Closet'], stairs: ['Floor 2'] },
                warehouse: { rooms: [1, 2], names: ['Office', 'Loading Bay', 'Tool Room'] },
                auto_shop: { rooms: [1, 1], names: ['Office', 'Parts Room'] },
                motel: { rooms: [0, 1], names: ['Bathroom'] },
                diner: { rooms: [1, 1], names: ['Kitchen'] },
                police_station: { rooms: [2, 3], names: ['Evidence Room', 'Holding Cell', 'Office', 'Armory'] },
                church: { rooms: [1, 1], names: ['Vestry'] },
                school: { rooms: [1, 2], names: ['Classroom', 'Supply Room', 'Staff Room'] },
                research_lab: { rooms: [2, 3], names: ['Specimen Room', 'Server Room', 'Storage', 'Clean Room'] },
                bunker: { rooms: [1, 2], names: ['Communications', 'Armory', 'Generator Room'] }
            };
            const locRooms = locationRooms[this.locationType];
            if (locRooms) {
                [minRooms, maxRooms] = locRooms.rooms;
                names = locRooms.names;
            }
        }
        
        if (!names) {
            // Fall back to archetype defaults
            [minRooms, maxRooms] = this.archetype.roomCount || [0, 1];
            const roomNames = {
                residential: ['Bedroom', 'Bathroom', 'Closet', 'Kitchen', 'Study'],
                commercial: ['Back Room', 'Storage', 'Office', 'Break Room'],
                industrial: ['Office', 'Storage Bay', 'Tool Room', 'Loading Bay'],
                civic: ['Back Office', 'Supply Room', 'Records Room', 'Staff Room'],
                shelter: ['Back Room', 'Cellar']
            };
            names = roomNames[this.archetypeName] || roomNames.commercial;
        }
        
        const doorCount = Phaser.Math.Between(minRooms, maxRooms);
        
        // Doors only on side walls — top wall is for windows
        const walls = ['left', 'right'];
        const used = [];
        
        for (let i = 0; i < doorCount; i++) {
            const remaining = walls.filter(w => !used.includes(w));
            if (remaining.length === 0) break;
            const wall = remaining[Phaser.Math.Between(0, remaining.length - 1)];
            used.push(wall);
            
            this.interiorDoors.push({
                wall,
                name: names[i % names.length],
                opened: false
            });
        }
        
        // Multi-story: add stair doors for locations with stairs config
        if (this.locationType && !this.isSubRoom) {
            const locationRooms = {
                apartment: { stairs: ['Floor 2'] },
                research_lab: { stairs: ['Sub-Level'] }
            };
            const locStairs = locationRooms[this.locationType];
            if (locStairs?.stairs) {
                locStairs.stairs.forEach(floorName => {
                    // Prefer right wall; if taken, use top wall
                    const stairWall = used.includes('right') ? 'top' : 'right';
                    this.interiorDoors.push({
                        wall: stairWall,
                        name: floorName,
                        opened: false,
                        isStairs: true
                    });
                });
            }
        }
        // If we're on Floor 2, add Rooftop stairs
        if (this.isSubRoom && (this.subRoomName || '').toLowerCase().includes('floor 2')) {
            const stairWall = used.includes('right') ? 'top' : 'right';
            this.interiorDoors.push({
                wall: stairWall,
                name: 'Rooftop',
                opened: false,
                isStairs: true
            });
        }
    }
    
    buildDoors(mainW, mainH) {
        const cx = this.mainCX;
        const cy = this.mainCY;
        
        for (const door of this.interiorDoors) {
            let dx, dy;
            
            if (door._isFloorplan) {
                // Floorplan door — position is set by planFloorplan, skip visual door
                dx = door.wall === 'left' ? cx - mainW / 2 : cx + mainW / 2;
                dy = door._floorplanY;
                door.x = dx;
                door.y = dy;
                continue;  // No drawDoorOnWall — gap is the doorway
            }
            
            if (door.wall === 'left') {
                dx = cx - mainW / 2;
                dy = cy + Phaser.Math.Between(-mainH / 5, mainH / 5);
            } else if (door.wall === 'top') {
                dx = cx + Phaser.Math.Between(-mainW / 5, mainW / 5);
                dy = cy - mainH / 2 - 12;
            } else {
                dx = cx + mainW / 2;
                dy = cy + Phaser.Math.Between(-mainH / 5, mainH / 5);
            }
            
            this.drawDoorOnWall(door.wall, dx, dy);
            
            door.x = dx;
            door.y = dy;
        }
    }
    
    enterDoor(door) {
        if (door.opened) return;
        
        // Floorplan doors — player walks through, no scene transition
        if (door._isFloorplan) return;
        
        door.opened = true;
        AudioManager.doorOpen();
        
        SceneTransition.fadeTo(this, 'InteriorScene', {
            archetype: this.archetypeName,
            subtype: this.subtype,
            buildingType: this.buildingType,
            buildingName: door.name,
            subRoomName: door.name,
            playerState: this.state,
            buildingWidth: 80,
            buildingHeight: 60,
            buildingId: this.buildingId ? (this.buildingId + '_' + door.name) : null,
            isSubRoom: true,
            locationType: this.locationType,
            doorSide: door.wall === 'left' ? 'right' : door.wall === 'right' ? 'left' : door.wall === 'top' ? 'bottom' : door.wall, // flip: entering right door → spawn on left
            parentData: {
                archetype: this.archetypeName,
                subtype: this.subtype,
                buildingType: this.buildingType,
                buildingName: this.buildingName,
                buildingWidth: this.buildingWidth,
                buildingHeight: this.buildingHeight,
                buildingId: this.buildingId,
                interiorScale: this.interiorScaleOverride,
                doorSide: this.doorSide,
                isGarage: this.isGarage,
                returnToDoor: door.name,
                savedPlayerPos: this.savedPlayerPos,
                savedRouteSeed: this.savedRouteSeed,
                fromMap: this.fromMap,
                destinationNode: this.destinationNode,
                currentNodeId: this.currentNodeId,
                previousNodeId: this.previousNodeId,
                completedNodes: this.completedNodes,
                traveledRoutes: this.traveledRoutes,
                mapSeed: this.mapSeed,
                currentRow: this.currentRow,
                locationType: this.locationType,
                lootMultiplier: this.lootMultiplier
            }
        }, { duration: 300 });
    }
    
    createFloor(worldW, worldH, w, h) {
        const cx = this.mainCX;
        const cy = this.mainCY;
        
        // Floor config from archetype
        const config = this.archetype.floor;
        
        // === OUTDOOR BACKDROP (visible behind interior) ===
        // Dark sky — oversized to cover sub-room expansion
        const bgSize = Math.max(worldW, worldH) + 600;
        this.add.rectangle(worldW/2, worldH/2, bgSize, bgSize, 0x0a0a12).setDepth(-2);
        
        // Distant buildings silhouette
        for (let i = 0; i < 12; i++) {
            const bx = 20 + i * (worldW / 10);
            const bh = Phaser.Math.Between(30, 70);
            this.add.rectangle(bx, 25, 30, bh, 0x151520).setDepth(-1);
            for (let wy = 0; wy < 2; wy++) {
                if (Math.random() > 0.6) {
                    this.add.rectangle(bx - 6, 25 - bh/2 + 12 + wy * 15, 5, 6, 0x1a1a25).setDepth(-1);
                    this.add.rectangle(bx + 6, 25 - bh/2 + 12 + wy * 15, 5, 6, 0x1a1a25).setDepth(-1);
                }
            }
        }
        
        // Ground outside (bottom)
        this.add.rectangle(worldW/2, worldH - 15, worldW, 30, 0x1a1a18).setDepth(-1);
        
        // === INTERIOR FLOOR ===
        // Base floor
        this.add.rectangle(cx, cy, w, h, config.base).setDepth(0);
        
        // Floor pattern — delegated to shared FloorRenderer
        const floorG = this.add.graphics().setDepth(1);
        const fx = cx - w/2, fy = cy - h/2;
        const rng = () => this.random();
        if (config.pattern === 'checker') {
            FloorRenderer.linoleum(floorG, fx, fy, w, h, config.base, config.accent);
        } else if (config.pattern === 'wood') {
            FloorRenderer.hardwood(floorG, fx, fy, w, h, config.base, config.accent);
        } else if (config.pattern === 'tile') {
            FloorRenderer.institutionalTile(floorG, fx, fy, w, h, config.base, config.accent, rng);
        } else if (config.pattern === 'concrete') {
            FloorRenderer.bareConcrete(floorG, fx, fy, w, h, config.base, rng);
        }
        
        // === FLOOR FLAVOR — rugs, wear marks, stains, small debris ===
        const ambience = this.archetype.ambience || 'ransacked';
        const L = cx - w/2 + 20;
        const R = cx + w/2 - 20;
        const T = cy - h/2 + 30;
        const B = cy + h/2 - 30;
        
        // Wear marks near high-traffic areas (doorways, center)
        // Scuff trail from exit toward center
        const exitX = cx;
        const exitY = cy + h/2 - 10;
        for (let s = 0; s < 4; s++) {
            const sx = exitX + Phaser.Math.Between(-8, 8);
            const sy = exitY - 15 - s * 18;
            this.add.ellipse(sx, sy, Phaser.Math.Between(12, 22), Phaser.Math.Between(6, 10), 
                this.darkenColor(config.base, 12), 0.15).setDepth(1.2);
        }
        
        // Area rug (most room types get one)
        if (ambience === 'lived_in' || ambience === 'ransacked' || ambience === 'abandoned') {
            const rugX = cx + Phaser.Math.Between(-20, 20);
            const rugY = cy + Phaser.Math.Between(-10, 20);
            const rugW = Phaser.Math.Between(55, 85);
            const rugH = Phaser.Math.Between(35, 55);
            const rugColors = [0x3a3028, 0x2a3530, 0x3a2a2a, 0x2a2a3a, 0x383028];
            const rugColor = rugColors[Math.floor(Math.random() * rugColors.length)];
            
            // Rug body with fringe
            this.add.rectangle(rugX, rugY, rugW, rugH, rugColor, 0.2).setDepth(1.3);
            // Rug border
            this.add.rectangle(rugX, rugY, rugW - 4, rugH - 4, rugColor, 0).setStrokeStyle(1, this.lightenColor(rugColor, 20), 0.15).setDepth(1.35);
            // Inner pattern
            this.add.rectangle(rugX, rugY, rugW - 14, rugH - 14, rugColor, 0).setStrokeStyle(1, this.lightenColor(rugColor, 15), 0.12).setDepth(1.35);
            // Fringed edges (top and bottom)
            for (let f = rugX - rugW/2 + 4; f < rugX + rugW/2; f += 5) {
                this.add.rectangle(f, rugY - rugH/2 - 2, 2, 4, this.lightenColor(rugColor, 10), 0.15).setDepth(1.3);
                this.add.rectangle(f, rugY + rugH/2 + 2, 2, 4, this.lightenColor(rugColor, 10), 0.15).setDepth(1.3);
            }
            // Rug wrinkle
            if (ambience === 'ransacked') {
                const wrX = rugX + Phaser.Math.Between(-rugW/4, rugW/4);
                this.add.rectangle(wrX, rugY, 2, rugH - 8, this.darkenColor(rugColor, 15), 0.12).setDepth(1.36);
            }
        }
        
        // Stains and marks
        const stainCount = ambience === 'ransacked' ? 4 : (ambience === 'industrial' ? 3 : 1);
        for (let i = 0; i < stainCount; i++) {
            const sx = Phaser.Math.Between(L, R);
            const sy = Phaser.Math.Between(T, B);
            const stainW = Phaser.Math.Between(8, 25);
            const stainH = Phaser.Math.Between(5, 18);
            const stainColor = ambience === 'industrial' ? 0x1a1a18 : 
                               (Math.random() < 0.4 ? 0x2a1a1a : this.darkenColor(config.base, 18));
            this.add.ellipse(sx, sy, stainW, stainH, stainColor, 0.12 + Math.random() * 0.08).setDepth(1.2)
                .setAngle(Phaser.Math.Between(-20, 20));
        }
        
        // Small floor debris (papers, dust, fragments)
        const debrisCount = ambience === 'ransacked' ? 6 : (ambience === 'abandoned' ? 4 : 2);
        for (let i = 0; i < debrisCount; i++) {
            const dx = Phaser.Math.Between(L, R);
            const dy = Phaser.Math.Between(T, B);
            const debrisRoll = Math.random();
            if (debrisRoll < 0.3) {
                // Paper scrap
                const pw = Phaser.Math.Between(5, 10);
                const ph = Phaser.Math.Between(4, 8);
                this.add.rectangle(dx, dy, pw, ph, 0x6a6a60, 0.18).setDepth(1.4)
                    .setAngle(Phaser.Math.Between(-40, 40));
                // Fold line
                this.add.rectangle(dx, dy, pw - 2, 1, 0x5a5a55, 0.1).setDepth(1.41)
                    .setAngle(Phaser.Math.Between(-40, 40));
            } else if (debrisRoll < 0.55) {
                // Dust pile
                this.add.ellipse(dx, dy, Phaser.Math.Between(8, 18), Phaser.Math.Between(5, 10),
                    0x3a3530, 0.1).setDepth(1.4);
            } else if (debrisRoll < 0.7) {
                // Glass shard
                const gfx = this.add.graphics().setDepth(1.4);
                gfx.fillStyle(0x7a9a9a, 0.12);
                const gx = dx, gy = dy;
                gfx.fillTriangle(gx, gy, gx + Phaser.Math.Between(3, 8), gy + Phaser.Math.Between(-3, 3),
                    gx + Phaser.Math.Between(-2, 4), gy + Phaser.Math.Between(3, 8));
            } else if (debrisRoll < 0.85) {
                // Small rubble chunk
                this.add.rectangle(dx, dy, Phaser.Math.Between(3, 7), Phaser.Math.Between(2, 5),
                    0x4a4540, 0.2).setDepth(1.4).setAngle(Phaser.Math.Between(-30, 30));
                this.add.rectangle(dx + 3, dy + 2, Phaser.Math.Between(2, 4), Phaser.Math.Between(2, 3),
                    0x3a3530, 0.15).setDepth(1.4).setAngle(Phaser.Math.Between(-45, 45));
            } else {
                // Footprint/track mark
                this.add.ellipse(dx, dy, 4, 7, this.darkenColor(config.base, 10), 0.08).setDepth(1.4);
                this.add.ellipse(dx, dy - 5, 3, 4, this.darkenColor(config.base, 10), 0.06).setDepth(1.4);
            }
        }
        
        // === BIOME-SPECIFIC INTERIOR OVERLAYS ===
        const biomeType = CONFIG.currentBiome?.type || 'grassy';
        this._renderBiomeInteriorOverlay(biomeType, cx, cy, w, h, config);
        
        // Baseboard shadow along walls (adds depth)
        this.add.rectangle(cx, cy - h/2 + 14, w - 8, 3, 0x000000, 0.08).setDepth(1.5); // top
        this.add.rectangle(cx - w/2 + 5, cy, 3, h - 20, 0x000000, 0.06).setDepth(1.5); // left
        this.add.rectangle(cx + w/2 - 5, cy, 3, h - 20, 0x000000, 0.06).setDepth(1.5); // right
        this.add.rectangle(cx, cy + h/2 - 5, w - 8, 3, 0x000000, 0.04).setDepth(1.5); // bottom
    }
    

    // ═══════════════════════════════════════════════════════════
    // BIOME INTERIOR OVERLAYS — visual variation per biome
    // ═══════════════════════════════════════════════════════════
    
    _renderBiomeInteriorOverlay(biomeType, cx, cy, w, h, config) {
        const L = cx - w/2 + 12, R = cx + w/2 - 12;
        const T = cy - h/2 + 16, B = cy + h/2 - 16;
        
        if (biomeType === 'grassy') {
            // OVERGROWN — nature reclaiming the interior
            
            // Vine tendrils creeping along walls — north wall
            const vineColor = 0x2a5a1a;
            const vineLight = 0x3a6a2a;
            for (let v = 0; v < 3; v++) {
                const vx = cx - w/2 + 20 + v * (w - 40) / 3 + Phaser.Math.Between(-10, 10);
                const vy = cy - h/2 + 14;
                // Vine strand hanging down from wall
                const segments = 3 + Math.floor(Math.random() * 3);
                let px = vx, py = vy;
                for (let s = 0; s < segments; s++) {
                    const nx = px + Phaser.Math.Between(-6, 6);
                    const ny = py + Phaser.Math.Between(6, 14);
                    this.add.rectangle((px + nx) / 2, (py + ny) / 2, 1, 
                        Math.sqrt((nx-px)**2 + (ny-py)**2), vineColor, 0.25 + Math.random() * 0.1)
                        .setAngle(Math.atan2(nx-px, ny-py) * -180 / Math.PI).setDepth(3.5);
                    // Leaf at joint
                    if (Math.random() < 0.5) {
                        this.add.ellipse(nx, ny, 4, 3, vineLight, 0.2).setDepth(3.5);
                    }
                    px = nx; py = ny;
                }
            }
            
            // Moss patches on floor — damp corners
            for (let m = 0; m < 4; m++) {
                const mx = Phaser.Math.Between(L, R);
                const my = Phaser.Math.Between(T, B);
                this.add.ellipse(mx, my, Phaser.Math.Between(12, 30), Phaser.Math.Between(8, 18),
                    0x2a4a1a, 0.1 + Math.random() * 0.06).setDepth(1.25);
            }
            
            // Water stain on ceiling/wall — drip marks running down north wall
            const stainX = cx + Phaser.Math.Between(-w/4, w/4);
            this.add.rectangle(stainX, cy - h/2 + 18, 8, 12, 0x2a3530, 0.1).setDepth(3.2);
            // Drip trail down from stain to floor
            this.add.rectangle(stainX, cy - h/2 + 30, 2, 14, 0x2a3530, 0.07).setDepth(3.2);
            // Puddle beneath drip
            this.add.ellipse(stainX, cy - h/2 + 44, 14, 8, 0x1a2a20, 0.1).setDepth(1.3);
            
            // Cracked window letting in light — faint green-tinted light shaft
            const shaftX = cx + Phaser.Math.Between(-w/3, w/3);
            this.add.rectangle(shaftX, cy - h/4, 20, h/2, 0x4a6a3a, 0.03).setAngle(5).setDepth(1.6);
            
            // Mold on left wall corner
            this.add.ellipse(cx - w/2 + 8, cy + h/4, 10, 16, 0x1a3a1a, 0.08).setDepth(5.1);
            
        } else if (biomeType === 'barren') {
            // WASTELAND — stripped bare, sand and dust
            
            // Sand drift through doorway — bottom of room
            const driftX = cx + Phaser.Math.Between(-15, 15);
            const driftW = Phaser.Math.Between(40, 70);
            this.add.ellipse(driftX, cy + h/2 - 12, driftW, 18, 0x4a4235, 0.2).setDepth(1.25);
            this.add.ellipse(driftX - 5, cy + h/2 - 14, driftW * 0.6, 10, 0x5a5040, 0.12).setDepth(1.3);
            
            // Fine dust layer over entire floor
            this.add.rectangle(cx, cy, w - 16, h - 16, 0x3a3525, 0.05).setDepth(1.22);
            
            // Wind-blown dust trails — directional streaks on floor
            for (let d = 0; d < 5; d++) {
                const dx = Phaser.Math.Between(L, R);
                const dy = Phaser.Math.Between(T, B);
                this.add.rectangle(dx, dy, Phaser.Math.Between(20, 45), 1, 0x4a4030, 0.08)
                    .setAngle(Phaser.Math.Between(5, 20)).setDepth(1.25);
            }
            
            // Peeling wall plaster — exposed patches on north wall
            for (let p = 0; p < 2; p++) {
                const px = cx + Phaser.Math.Between(-w/3, w/3);
                const py = cy - h/2 + 14 + Phaser.Math.Between(0, 10);
                const pw = Phaser.Math.Between(10, 22);
                const ph = Phaser.Math.Between(6, 14);
                // Dark exposed surface beneath plaster
                this.add.rectangle(px, py, pw, ph, 0x2a2520, 0.15).setDepth(3.15);
                // Ragged edge of remaining plaster
                this.add.rectangle(px - pw/2, py, 2, ph, 0x4a4a40, 0.1).setDepth(3.16);
            }
            
            // Empty shelves / stripped contents visual — bare marks where things were removed
            const markX = cx - w/2 + 12 + Phaser.Math.Between(0, 20);
            for (let s = 0; s < 3; s++) {
                this.add.rectangle(markX, cy - h/4 + s * 16, 6, 1, 0x3a3a35, 0.08).setDepth(5.1);
            }
            
            // Cracked floor — prominent fissure
            const crackStartX = Phaser.Math.Between(L + 20, R - 20);
            const crackStartY = Phaser.Math.Between(T + 20, B - 20);
            let ckx = crackStartX, cky = crackStartY;
            for (let c = 0; c < 4; c++) {
                const nx = ckx + Phaser.Math.Between(-10, 10);
                const ny = cky + Phaser.Math.Between(8, 16);
                const dist = Math.sqrt((nx-ckx)**2 + (ny-cky)**2);
                const angle = Math.atan2(ny-cky, nx-ckx) * 180 / Math.PI;
                this.add.rectangle((ckx+nx)/2, (cky+ny)/2, dist, 2, 0x1a1a15, 0.12)
                    .setAngle(angle).setDepth(1.25);
                ckx = nx; cky = ny;
            }
            
            // Bleached sunlight patch from window — harsh white-yellow rectangle
            const sunX = cx + Phaser.Math.Between(-w/4, w/4);
            const sunY = cy + Phaser.Math.Between(-h/6, h/6);
            this.add.rectangle(sunX, sunY, 24, 30, 0x6a6a50, 0.06).setDepth(1.6);
            
        } else if (biomeType === 'apocalyptic') {
            // ANOMALOUS — Cube influence bleeding through
            
            // Geometric growth on north wall — angular dark patches
            for (let g = 0; g < 3; g++) {
                const gx = cx + Phaser.Math.Between(-w/3, w/3);
                const gy = cy - h/2 + 14 + Phaser.Math.Between(0, 8);
                const gw = Phaser.Math.Between(8, 18);
                const gh = Phaser.Math.Between(6, 14);
                this.add.rectangle(gx, gy, gw, gh, 0x1a1020, 0.2).setDepth(3.15);
                // Edge highlight — faint cyan
                this.add.rectangle(gx, gy - gh/2, gw, 1, 0x4a6a7a, 0.12).setDepth(3.16);
                // Interior geometric line
                this.add.rectangle(gx, gy, gw - 4, 1, 0x3a4a5a, 0.08).setDepth(3.16);
            }
            
            // Cube vein on floor — angular path
            let vx = Phaser.Math.Between(L + 20, R - 20);
            let vy = Phaser.Math.Between(T + 20, B - 20);
            for (let s = 0; s < 5; s++) {
                const angle = Math.floor(Math.random() * 6) * 60;
                const len = Phaser.Math.Between(10, 25);
                const rad = angle * Math.PI / 180;
                const nx = vx + Math.cos(rad) * len;
                const ny = vy + Math.sin(rad) * len * 0.5;
                const dist = Math.sqrt((nx-vx)**2 + (ny-vy)**2);
                const drawAngle = Math.atan2(ny-vy, nx-vx) * 180 / Math.PI;
                this.add.rectangle((vx+nx)/2, (vy+ny)/2, dist, 1, 0x4a6a7a, 0.12 + Math.random() * 0.06)
                    .setAngle(drawAngle).setDepth(1.3);
                vx = nx; vy = ny;
            }
            
            // Small fungal growth in corner
            const fCornerX = cx + (Math.random() < 0.5 ? -w/2 + 14 : w/2 - 14);
            const fCornerY = cy + h/4;
            for (let f = 0; f < 3; f++) {
                const fx = fCornerX + Phaser.Math.Between(-4, 4);
                const fy = fCornerY + Phaser.Math.Between(-3, 3);
                this.add.rectangle(fx, fy, 3, 2, 0x5a7a7a, 0.2).setDepth(1.4);
                this.add.rectangle(fx, fy - 1, 2, 1, 0x7a9a9a, 0.1).setDepth(1.45);
            }
            // Faint glow beneath fungal cluster
            this.add.ellipse(fCornerX, fCornerY + 2, 12, 6, 0x4a8a8a, 0.04).setDepth(1.2);
            
            // Corrupted floor patch — dark void area
            const cpx = cx + Phaser.Math.Between(-w/4, w/4);
            const cpy = cy + Phaser.Math.Between(-h/6, h/6);
            this.add.ellipse(cpx, cpy, Phaser.Math.Between(16, 30), Phaser.Math.Between(10, 20),
                0x0a0810, 0.15).setDepth(1.25);
            // Violet iridescent sheen
            this.add.ellipse(cpx - 2, cpy - 1, 10, 6, 0x3a2a4a, 0.06).setDepth(1.28);
            
            // Wall surface distortion — left wall
            this.add.rectangle(cx - w/2 + 6, cy - h/6, 4, 20, 0x1a1020, 0.12).setDepth(5.1);
            this.add.rectangle(cx - w/2 + 6, cy - h/6 - 10, 3, 1, 0x4a6a7a, 0.08).setDepth(5.15);
            
            // Faint ambient violet tint overlay on entire room
            this.add.rectangle(cx, cy, w, h, 0x2a1a3a, 0.02).setDepth(1.21);
        }
    }
    
    // ═══════════════════════════════════════════════════════════
    // BIOME FURNITURE OVERLAY — per-biome visual treatment on placed furniture
    // Runs AFTER room generation to layer biome effects onto existing pieces
    // ═══════════════════════════════════════════════════════════
    _applyBiomeFurnitureOverlay(cx, cy, w, h, L, R, T, B) {
        const biome = CONFIG.currentBiome?.type || 'grassy';
        const furniture = this._placedFurniture;
        if (!furniture || furniture.length === 0) return;
        
        const g = this.add.graphics().setDepth(15); // above furniture (depth ~11-14)
        
        if (biome === 'grassy') {
            // === OVERGROWN: vine tendrils, moss patches, water damage ===
            
            for (const f of furniture) {
                const roll = Math.random();
                
                // ~50% of furniture gets vine growth
                if (roll < 0.5) {
                    g.lineStyle(1, 0x2a5a1a, 0.5);
                    // Vine tendril climbing up from base
                    const vx = f.x + (Math.random() - 0.5) * 10;
                    const vy = f.y;
                    const segments = 3 + Math.floor(Math.random() * 3);
                    let px = vx, py = vy;
                    for (let s = 0; s < segments; s++) {
                        const nx = px + (Math.random() - 0.5) * 6;
                        const ny = py - 3 - Math.random() * 4;
                        g.lineBetween(px, py, nx, ny);
                        // Leaf node at joints
                        if (s > 0 && Math.random() < 0.6) {
                            g.fillStyle(0x3a7a2a, 0.4);
                            g.fillEllipse(nx, ny, 3, 2);
                        }
                        px = nx; py = ny;
                    }
                }
                
                // ~30% gets moss growth on surface
                if (roll < 0.3) {
                    g.fillStyle(0x2a4a2a, 0.25);
                    g.fillEllipse(f.x + (Math.random() - 0.5) * 8, f.y - 4, 
                        6 + Math.random() * 6, 3 + Math.random() * 3);
                }
                
                // ~20% gets water stain beneath
                if (roll < 0.2) {
                    g.fillStyle(0x2a3a3a, 0.15);
                    g.fillEllipse(f.x, f.y + 8, 10 + Math.random() * 8, 4 + Math.random() * 3);
                }
            }
            
            // Floor mold patches (not tied to furniture)
            for (let i = 0; i < 2; i++) {
                const mx = Phaser.Math.Between(L + 10, R - 10);
                const my = Phaser.Math.Between(T + 10, B - 10);
                g.fillStyle(0x2a4a2a, 0.12);
                g.fillEllipse(mx, my, 12 + Math.random() * 10, 6 + Math.random() * 5);
            }
            
        } else if (biome === 'barren') {
            // === WASTELAND: dust film, sand accumulation, stripped look ===
            
            // Overall dust film on floor
            g.fillStyle(0x5a5040, 0.06);
            g.fillRect(L, T, R - L, B - T);
            
            for (const f of furniture) {
                const roll = Math.random();
                
                // ~60% — sand/dust drift at furniture base
                if (roll < 0.6) {
                    g.fillStyle(0x6a6050, 0.2);
                    g.fillEllipse(f.x + 3, f.y + 6, 
                        8 + Math.random() * 8, 3 + Math.random() * 2);
                }
                
                // ~35% — dust marks on surface (lighter patches where items sat)
                if (roll < 0.35) {
                    g.fillStyle(0x7a7060, 0.1);
                    g.fillRect(f.x - 4, f.y - 6, 8, 3);
                }
                
                // ~20% — crack running near furniture leg
                if (roll < 0.2) {
                    g.lineStyle(1, 0x3a3025, 0.25);
                    const cx2 = f.x + (Math.random() - 0.5) * 12;
                    const cy2 = f.y + 5;
                    g.lineBetween(cx2, cy2, cx2 + (Math.random() - 0.5) * 15, cy2 + Math.random() * 8);
                }
            }
            
            // Windblown dust trails across floor
            g.lineStyle(1, 0x6a6050, 0.08);
            for (let d = 0; d < 3; d++) {
                const dy = Phaser.Math.Between(T + 10, B - 10);
                const angle = (5 + Math.random() * 15) * Math.PI / 180;
                g.lineBetween(L, dy, R, dy - Math.tan(angle) * (R - L));
            }
            
        } else if (biome === 'apocalyptic') {
            // === ANOMALOUS: crystal growths, cube veins, membrane, violet tint ===
            
            for (const f of furniture) {
                const roll = Math.random();
                
                // ~40% — small crystal growth near furniture
                if (roll < 0.4) {
                    const crx = f.x + (Math.random() < 0.5 ? -8 : 8) + (Math.random() - 0.5) * 4;
                    const cry = f.y + 2 + Math.random() * 4;
                    // Crystal spire (small)
                    g.fillStyle(0x2a2535, 0.7);
                    g.beginPath();
                    g.moveTo(crx - 2, cry);
                    g.lineTo(crx + 2, cry);
                    g.lineTo(crx, cry - 6 - Math.random() * 4);
                    g.closePath();
                    g.fillPath();
                    // Cyan edge highlight
                    g.lineStyle(1, 0x4adfdf, 0.25);
                    g.lineBetween(crx + 2, cry, crx, cry - 6);
                }
                
                // ~30% — cube vein approaching from floor
                if (roll < 0.3) {
                    g.lineStyle(1, 0x4adfdf, 0.15);
                    const vx = f.x + (Math.random() - 0.5) * 6;
                    const vy = f.y + 6;
                    // Angular segments snapping to ~60°
                    let px2 = vx, py2 = vy;
                    for (let s = 0; s < 3; s++) {
                        const ang = (Math.floor(Math.random() * 6) * 60) * Math.PI / 180;
                        const len = 5 + Math.random() * 6;
                        const nx2 = px2 + Math.cos(ang) * len;
                        const ny2 = py2 + Math.sin(ang) * len * 0.6;
                        g.lineBetween(px2, py2, nx2, ny2);
                        px2 = nx2; py2 = ny2;
                    }
                }
                
                // ~20% — membrane patch on furniture surface
                if (roll < 0.2) {
                    g.fillStyle(0x3a2a4a, 0.2);
                    g.fillEllipse(f.x + (Math.random() - 0.5) * 6, f.y - 3,
                        5 + Math.random() * 4, 3 + Math.random() * 2);
                }
            }
            
            // Faint violet ambient glow near floor corners
            g.fillStyle(0x4a2a6a, 0.04);
            g.fillEllipse(L + 10, B - 10, 25, 15);
            g.fillEllipse(R - 10, T + 15, 20, 12);
        }
    }

    // ═══════════════════════════════════════════════════════════
    // WALL MODULE SYSTEM — ¾ Isometric Walls for Interiors
    // ═══════════════════════════════════════════════════════════

    get INTERIOR_WALL() {
        const base = this.archetype.walls.color;
        return {
            frontH: 24, topH: 4, sideW: 8, sideSliver: 3,
            baseColor: base,
            darkColor: IsoRenderer.darken(base, 0.15),
            lightColor: IsoRenderer.lighten(base, 0.1),
            edgeColor: IsoRenderer.darken(base, 0.25),
            highlightColor: IsoRenderer.lighten(base, 0.2),
            frameColor: IsoRenderer.lighten(base, 0.08),
            frameDark: IsoRenderer.darken(base, 0.2),
            frameHighlight: IsoRenderer.lighten(base, 0.15)
        };
    }

    _isoWall(cx, groundY, w, facing, depth) {
        const W = this.INTERIOR_WALL;
        const d = depth || 3;
        // South walls use Y-based depth so player renders BEHIND them
        const effectiveD = (facing === 'south') ? (10 + groundY * 0.01) : d;
        const fT = groundY - W.frontH, tT = fT - W.topH;
        if (facing === 'north') {
            this.add.rectangle(cx, groundY - W.frontH/2, w, W.frontH, W.baseColor).setDepth(effectiveD);
            for (let i = 1; i <= 3; i++) this.add.rectangle(cx, groundY - W.frontH*(i/4), w, 1, W.darkColor, 0.3).setDepth(effectiveD+0.01);
            this.add.rectangle(cx, groundY - 1, w, 2, W.edgeColor).setDepth(effectiveD+0.02);
            this.add.rectangle(cx, fT - W.topH/2, w, W.topH, W.lightColor).setDepth(effectiveD+0.03);
            this.add.rectangle(cx, tT + 1, w, 1, W.highlightColor, 0.4).setDepth(effectiveD+0.04);
        } else {
            this.add.rectangle(cx, groundY - W.frontH/2, w, W.frontH, W.darkColor).setDepth(effectiveD);
            for (let i = 1; i <= 3; i++) this.add.rectangle(cx, groundY - W.frontH*(i/4), w, 1, W.edgeColor, 0.2).setDepth(effectiveD+0.01);
            this.add.rectangle(cx, fT - W.topH/2, w, W.topH, W.baseColor).setDepth(effectiveD+0.03);
            this.add.rectangle(cx, tT + 1, w, 1, W.lightColor, 0.3).setDepth(effectiveD+0.04);
        }
        // Wall texture overlay
        const ws = this.archetype.walls.style;
        if (ws && WallRenderer[ws]) {
            const fg = this.add.graphics().setDepth(effectiveD + 0.05);
            const faceBase = facing === 'north' ? W.baseColor : W.darkColor;
            WallRenderer[ws](fg, cx - w/2, groundY - W.frontH, w, W.frontH, faceBase, facing);
        }
    }

    _sideWall(cx, topY, botY, side, depth) {
        const W = this.INTERIOR_WALL;
        const d = depth || 3.5;
        const h = botY - topY, cy = topY + h/2;
        if (h <= 0) return;
        this.add.rectangle(cx, cy, W.sideW, h, W.darkColor).setDepth(d);
        if (side === 'east') {
            this.add.rectangle(cx - W.sideW/2 + W.sideSliver/2, cy, W.sideSliver, h, W.baseColor, 0.5).setDepth(d+0.01);
            this.add.rectangle(cx + W.sideW/2 - 1, cy, 1, h, W.edgeColor, 0.5).setDepth(d+0.01);
        } else {
            this.add.rectangle(cx + W.sideW/2 - W.sideSliver/2, cy, W.sideSliver, h, W.baseColor, 0.5).setDepth(d+0.01);
            this.add.rectangle(cx - W.sideW/2 + 1, cy, 1, h, W.edgeColor, 0.5).setDepth(d+0.01);
        }
        for (let i = 1; i <= 3; i++) this.add.rectangle(cx, topY + h*(i/4), W.sideW, 1, W.edgeColor, 0.15).setDepth(d+0.02);
        // Wall texture overlay
        const ws = this.archetype.walls.style;
        if (ws && WallRenderer[ws]) {
            const sg = this.add.graphics().setDepth(d + 0.05);
            const facing = side === 'east' ? 'east' : 'west';
            WallRenderer[ws](sg, cx - W.sideW/2, topY, W.sideW, h, W.darkColor, facing);
        }
    }

    // ═══ SOUTH WALL HELPER — creates visible south wall parts for occlusion fade ═══
    _makeSouthWall(cx, groundY, w) {
        const W = this.INTERIOR_WALL;
        const d = 10 + groundY * 0.01; // Y-based depth so player renders BEHIND
        const fT = groundY - W.frontH, tT = fT - W.topH;
        const parts = [];
        // Front face (darker for south — camera sees less light)
        parts.push(this.add.rectangle(cx, groundY - W.frontH/2, w, W.frontH, W.darkColor).setDepth(d));
        for (let i = 1; i <= 3; i++) parts.push(this.add.rectangle(cx, groundY - W.frontH*(i/4), w, 1, W.edgeColor, 0.2).setDepth(d+0.01));
        // Top strip
        parts.push(this.add.rectangle(cx, fT - W.topH/2, w, W.topH, W.baseColor).setDepth(d+0.03));
        parts.push(this.add.rectangle(cx, tT + 1, w, 1, W.lightColor, 0.3).setDepth(d+0.04));
        // Wall texture overlay
        const ws = this.archetype.walls.style;
        if (ws && WallRenderer[ws]) {
            const sfg = this.add.graphics().setDepth(d + 0.05);
            WallRenderer[ws](sfg, cx - w/2, groundY - W.frontH, w, W.frontH, W.darkColor, 'south');
            parts.push(sfg);
        }
        return parts;
    }

    // ═══ WALL DECORATION SYSTEM ═══
    // Adds themed decorations to north wall face + ambient room details
    addWallDecor(cx, top, w) {
        const W = this.INTERIOR_WALL;
        const faceY = top - W.frontH / 2;  // center of north wall face
        const faceTop = top - W.frontH;
        const archetype = this.archetypeName;
        const d = 3.25;  // above wall face (3), below windows (3.5)
        const rng = () => this.random ? this.random() : Math.random();
        
        // Avoid windows and exit door
        const exitOnTop = this.doorSide === 'north';
        const hasWindows = !exitOnTop && !this.isSubRoom && 
            (archetype === 'residential' || archetype === 'commercial' || archetype === 'civic');
        
        // Build exclusion zones (x positions to avoid)
        const excluded = [];
        if (exitOnTop) excluded.push({ x: cx, hw: 35 });
        if (hasWindows) {
            const wCount = w > 280 ? 2 : 1;
            const spacing = w / (wCount + 1);
            for (let i = 0; i < wCount; i++) {
                excluded.push({ x: cx - w/2 + spacing * (i + 1), hw: 22 });
            }
        }
        // Interior doors on north wall
        if (this.doorZones && this.doorZones.top) {
            this.doorZones.top.forEach(dx => excluded.push({ x: dx, hw: 30 }));
        }
        
        const isClear = (x, hw) => {
            return !excluded.some(e => Math.abs(x - e.x) < (hw + e.hw));
        };
        
        // Available wall slots (divide wall into sections)
        const left = cx - w/2 + 20;
        const right = cx + w/2 - 20;
        const slots = [];
        for (let sx = left + 15; sx < right - 15; sx += 35) {
            if (isClear(sx, 12)) slots.push(sx);
        }
        if (slots.length === 0) return;
        
        // Shuffle slots deterministically
        for (let i = slots.length - 1; i > 0; i--) {
            const j = Math.floor(rng() * (i + 1));
            [slots[i], slots[j]] = [slots[j], slots[i]];
        }
        
        // Pick decorations by archetype
        const decors = this._getWallDecorSet(archetype);
        const count = Math.min(slots.length, Math.floor(rng() * 2) + 1 + (w > 250 ? 1 : 0));
        
        for (let i = 0; i < count; i++) {
            const sx = slots[i];
            const decor = decors[Math.floor(rng() * decors.length)];
            this._placeWallDecor(sx, faceY, faceTop, top, decor, d + i * 0.01, rng);
        }
    }
    
    _getWallDecorSet(archetype) {
        switch(archetype) {
            case 'residential': return [
                'painting', 'painting', 'photo_frame', 'photo_frame',
                'clock', 'small_shelf', 'mirror', 'calendar'
            ];
            case 'commercial': return [
                'sign', 'sign', 'poster', 'poster',
                'clock', 'menu_board', 'price_list', 'neon_sign'
            ];
            case 'industrial': return [
                'safety_sign', 'safety_sign', 'pipe_run', 'fuse_box',
                'gauge', 'caution_tape', 'tool_rack', 'vent'
            ];
            case 'civic': return [
                'bulletin', 'bulletin', 'clock', 'notice',
                'whiteboard', 'flag', 'poster', 'certificate'
            ];
            case 'shelter': return [
                'graffiti', 'graffiti', 'scratch_marks', 'tarp',
                'pipe_run', 'vent', 'stain', 'crack'
            ];
            default: return ['painting', 'poster', 'clock'];
        }
    }
    
    _placeWallDecor(x, faceY, faceTop, wallBase, type, depth, rng) {
        const s = this;
        const W = this.INTERIOR_WALL;
        const accent = W.lightColor;
        const dark = W.darkColor;
        
        switch(type) {
            case 'painting': {
                const pw = 10 + Math.floor(rng() * 8);
                const ph = 8 + Math.floor(rng() * 5);
                // Frame
                s.add.rectangle(x, faceY - 1, pw + 2, ph + 2, 0x2a2018, 0.7).setDepth(depth);
                // Canvas — random muted color
                const colors = [0x4a3a2a, 0x2a3a4a, 0x3a4a3a, 0x4a3a3a, 0x3a3a4a, 0x4a4a3a];
                const col = colors[Math.floor(rng() * colors.length)];
                s.add.rectangle(x, faceY - 1, pw - 1, ph - 1, col, 0.5).setDepth(depth + 0.001);
                // Highlight brush stroke
                s.add.rectangle(x + Math.floor(rng()*4) - 2, faceY - 2, Math.floor(rng()*5)+3, 2, 
                    IsoRenderer.lighten(col, 0.15), 0.3).setDepth(depth + 0.002);
                break;
            }
            case 'photo_frame': {
                const fw = 6 + Math.floor(rng() * 4);
                const fh = 7 + Math.floor(rng() * 3);
                s.add.rectangle(x, faceY - 1, fw + 2, fh + 2, 0x3a3530, 0.6).setDepth(depth);
                s.add.rectangle(x, faceY - 1, fw, fh, 0x2a2520, 0.5).setDepth(depth + 0.001);
                // Faded photo tint
                s.add.rectangle(x, faceY - 1, fw - 1, fh - 1, 0x5a5040, 0.15).setDepth(depth + 0.002);
                break;
            }
            case 'clock': {
                s.add.circle(x, faceY - 2, 5, 0x3a3a3a, 0.6).setDepth(depth);
                s.add.circle(x, faceY - 2, 4, 0xddddd0, 0.15).setDepth(depth + 0.001);
                // Hands
                const gfx = s.add.graphics().setDepth(depth + 0.002);
                gfx.lineStyle(1, 0x2a2a2a, 0.4);
                gfx.lineBetween(x, faceY - 2, x, faceY - 5);  // 12 o'clock
                gfx.lineBetween(x, faceY - 2, x + 3, faceY - 1);  // ~3
                break;
            }
            case 'mirror': {
                const mh = 10 + Math.floor(rng() * 4);
                s.add.rectangle(x, faceY - 1, 8, mh, 0x3a3a3a, 0.5).setDepth(depth);
                s.add.rectangle(x, faceY - 1, 6, mh - 2, 0x6a7a8a, 0.2).setDepth(depth + 0.001);
                // Reflection highlight
                s.add.rectangle(x - 1, faceY - 3, 2, mh - 4, 0x8a9aaa, 0.1).setDepth(depth + 0.002);
                break;
            }
            case 'small_shelf': {
                s.add.rectangle(x, faceY + 2, 14, 2, 0x3a3028, 0.6).setDepth(depth);
                // Small items on shelf
                if (rng() < 0.6) s.add.rectangle(x - 4, faceY, 3, 4, 0x5a4a3a, 0.35).setDepth(depth + 0.001);
                if (rng() < 0.5) s.add.circle(x + 3, faceY + 1, 2, 0x4a5a4a, 0.3).setDepth(depth + 0.001);
                break;
            }
            case 'calendar': {
                s.add.rectangle(x, faceY - 1, 6, 8, 0xccccbb, 0.15).setDepth(depth);
                s.add.rectangle(x, faceY - 4, 6, 2, 0xaa3333, 0.2).setDepth(depth + 0.001);
                break;
            }
            case 'sign': {
                const sw = 14 + Math.floor(rng() * 8);
                s.add.rectangle(x, faceY - 1, sw, 6, 0x3a4a3a, 0.5).setDepth(depth);
                s.add.rectangle(x, faceY - 1, sw - 2, 4, 0x4a5a4a, 0.25).setDepth(depth + 0.001);
                break;
            }
            case 'poster': {
                const pw = 8 + Math.floor(rng() * 5);
                const ph = 10 + Math.floor(rng() * 4);
                const posterColors = [0x6a3a3a, 0x3a3a6a, 0x6a6a3a, 0x3a6a3a, 0x6a3a6a];
                const col = posterColors[Math.floor(rng() * posterColors.length)];
                s.add.rectangle(x, faceY - 1, pw, ph, col, 0.25).setDepth(depth);
                // Curling corner
                if (rng() < 0.4) {
                    s.add.triangle(x + pw/2, faceY + ph/2 - 2, 0, 0, -3, 0, 0, -3, 
                        IsoRenderer.lighten(col, 0.1), 0.15).setDepth(depth + 0.001);
                }
                break;
            }
            case 'menu_board': {
                s.add.rectangle(x, faceY - 1, 16, 10, 0x1a1a1a, 0.5).setDepth(depth);
                // Chalk text lines
                for (let ly = 0; ly < 3; ly++) {
                    s.add.rectangle(x, faceY - 4 + ly * 3, 10 + Math.floor(rng()*4), 1, 
                        0xccccaa, 0.12).setDepth(depth + 0.001);
                }
                break;
            }
            case 'price_list': {
                s.add.rectangle(x, faceY - 1, 8, 10, 0xcccc99, 0.12).setDepth(depth);
                for (let ly = 0; ly < 4; ly++) {
                    s.add.rectangle(x, faceY - 3 + ly * 2, 6, 1, 0x2a2a2a, 0.1).setDepth(depth + 0.001);
                }
                break;
            }
            case 'neon_sign': {
                const neonColors = [0xff4444, 0x44ff44, 0x4444ff, 0xffaa22];
                const nc = neonColors[Math.floor(rng() * neonColors.length)];
                s.add.rectangle(x, faceY - 2, 16, 6, 0x1a1a1a, 0.4).setDepth(depth);
                s.add.rectangle(x, faceY - 2, 12, 3, nc, 0.08).setDepth(depth + 0.001);
                break;
            }
            case 'safety_sign': {
                const bg = rng() < 0.5 ? 0xaaaa22 : 0xaa2222;
                s.add.rectangle(x, faceY - 1, 10, 8, bg, 0.3).setDepth(depth);
                s.add.rectangle(x, faceY - 1, 8, 6, 0x1a1a1a, 0.15).setDepth(depth + 0.001);
                break;
            }
            case 'pipe_run': {
                const pipeLen = 20 + Math.floor(rng() * 30);
                const py = faceTop + 3 + Math.floor(rng() * 4);
                s.add.rectangle(x, py, pipeLen, 2, 0x5a5a5a, 0.4).setDepth(depth);
                // Joint
                s.add.rectangle(x + Math.floor(rng()*10) - 5, py, 4, 3, 0x4a4a4a, 0.45).setDepth(depth + 0.001);
                break;
            }
            case 'fuse_box': {
                s.add.rectangle(x, faceY - 1, 8, 10, 0x4a4a4a, 0.55).setDepth(depth);
                s.add.rectangle(x, faceY - 1, 6, 8, 0x3a3a3a, 0.4).setDepth(depth + 0.001);
                // Handle
                s.add.rectangle(x + 2, faceY, 1, 4, 0xaa3333, 0.35).setDepth(depth + 0.002);
                break;
            }
            case 'gauge': {
                s.add.circle(x, faceY - 1, 4, 0x4a4a4a, 0.5).setDepth(depth);
                s.add.circle(x, faceY - 1, 3, 0x2a2a2a, 0.35).setDepth(depth + 0.001);
                // Needle
                const gfx = s.add.graphics().setDepth(depth + 0.002);
                gfx.lineStyle(1, 0xaa3333, 0.35);
                const angle = rng() * Math.PI;
                gfx.lineBetween(x, faceY - 1, x + Math.cos(angle)*2, faceY - 1 - Math.sin(angle)*2);
                break;
            }
            case 'tool_rack': {
                s.add.rectangle(x, faceY, 14, 2, 0x4a4a4a, 0.5).setDepth(depth);
                // Hanging tools
                for (let t = 0; t < 3; t++) {
                    const tx = x - 4 + t * 4;
                    const th = 3 + Math.floor(rng() * 4);
                    s.add.rectangle(tx, faceY + 1 + th/2, 1, th, 0x6a6a6a, 0.3).setDepth(depth + 0.001);
                }
                break;
            }
            case 'vent': {
                s.add.rectangle(x, faceTop + 4, 12, 6, 0x4a4a4a, 0.45).setDepth(depth);
                // Slats
                for (let v = 0; v < 3; v++) {
                    s.add.rectangle(x, faceTop + 2 + v * 2, 10, 1, 0x3a3a3a, 0.35).setDepth(depth + 0.001);
                }
                break;
            }
            case 'caution_tape': {
                const gfx = s.add.graphics().setDepth(depth);
                gfx.lineStyle(2, 0xccaa22, 0.2);
                gfx.lineBetween(x - 15, faceY, x + 15, faceY - 2);
                break;
            }
            case 'bulletin': {
                s.add.rectangle(x, faceY - 1, 14, 10, 0x5a4a3a, 0.45).setDepth(depth);
                // Pinned papers
                for (let p = 0; p < 3; p++) {
                    const px = x - 4 + Math.floor(rng() * 8);
                    const py = faceY - 3 + Math.floor(rng() * 4);
                    s.add.rectangle(px, py, 4, 3, 0xcccc99, 0.15 + rng() * 0.1).setDepth(depth + 0.001)
                        .setAngle(Math.floor(rng() * 20) - 10);
                }
                // Pin
                s.add.circle(x, faceY - 3, 1, 0xaa3333, 0.35).setDepth(depth + 0.002);
                break;
            }
            case 'notice': {
                s.add.rectangle(x, faceY - 1, 8, 10, 0xcccc99, 0.15).setDepth(depth);
                // Text lines
                for (let ly = 0; ly < 4; ly++) {
                    s.add.rectangle(x, faceY - 3 + ly * 2, 5 + Math.floor(rng()*2), 1, 
                        0x2a2a2a, 0.12).setDepth(depth + 0.001);
                }
                break;
            }
            case 'whiteboard': {
                s.add.rectangle(x, faceY - 1, 18, 10, 0xdddddd, 0.12).setDepth(depth);
                s.add.rectangle(x, faceY - 1, 17, 9, 0xeeeeee, 0.06).setDepth(depth + 0.001);
                // Scrawled marks
                const gfx = s.add.graphics().setDepth(depth + 0.002);
                gfx.lineStyle(1, 0x2244aa, 0.12);
                for (let m = 0; m < 3; m++) {
                    const mx = x - 6 + Math.floor(rng() * 12);
                    const my = faceY - 4 + Math.floor(rng() * 6);
                    gfx.lineBetween(mx, my, mx + Math.floor(rng()*8) - 4, my + Math.floor(rng()*4) - 2);
                }
                break;
            }
            case 'flag': {
                // Pole
                s.add.rectangle(x - 7, faceY - 1, 1, 12, 0x6a6a6a, 0.4).setDepth(depth);
                // Fabric
                s.add.rectangle(x - 2, faceY - 3, 10, 7, 0x3a3a6a, 0.25).setDepth(depth + 0.001);
                s.add.rectangle(x - 2, faceY - 5, 10, 2, 0x6a3a3a, 0.2).setDepth(depth + 0.002);
                break;
            }
            case 'certificate': {
                s.add.rectangle(x, faceY - 1, 10, 8, 0x2a2520, 0.5).setDepth(depth);
                s.add.rectangle(x, faceY - 1, 8, 6, 0xcccc99, 0.1).setDepth(depth + 0.001);
                break;
            }
            case 'graffiti': {
                const gfx = s.add.graphics().setDepth(depth);
                const gc = [0xaa3333, 0x33aa33, 0x3333aa, 0xaaaa33][Math.floor(rng()*4)];
                gfx.lineStyle(2, gc, 0.15);
                const gx = x, gy = faceY - 1;
                for (let s = 0; s < 3; s++) {
                    gfx.lineBetween(
                        gx + Math.floor(rng()*14)-7, gy + Math.floor(rng()*8)-4,
                        gx + Math.floor(rng()*14)-7, gy + Math.floor(rng()*8)-4
                    );
                }
                break;
            }
            case 'scratch_marks': {
                const gfx = s.add.graphics().setDepth(depth);
                gfx.lineStyle(1, 0x5a5a5a, 0.2);
                for (let m = 0; m < 4; m++) {
                    const sx = x - 3 + m * 2;
                    gfx.lineBetween(sx, faceY - 4, sx + 1, faceY + 3);
                }
                break;
            }
            case 'tarp': {
                s.add.rectangle(x, faceY + 1, 16, 8, 0x2a3a4a, 0.2).setDepth(depth);
                // Fold
                s.add.rectangle(x + 3, faceY - 1, 8, 2, 0x3a4a5a, 0.15).setDepth(depth + 0.001);
                break;
            }
            case 'stain': {
                s.add.ellipse(x, faceY, 8 + Math.floor(rng()*6), 6 + Math.floor(rng()*4), 
                    0x2a2018, 0.2).setDepth(depth);
                break;
            }
            case 'crack': {
                const gfx = s.add.graphics().setDepth(depth);
                gfx.lineStyle(1, 0x2a2a2a, 0.3);
                const cy = faceY;
                gfx.lineBetween(x, cy - 5, x + 2, cy);
                gfx.lineBetween(x + 2, cy, x - 1, cy + 4);
                gfx.lineBetween(x + 2, cy, x + 4, cy + 2);
                break;
            }
        }
    }
    

    // ═══ MULTI-ROOM FLOORPLAN SYSTEM ═══
    // Calculates sub-room rectangles attached to main room walls
    planFloorplan(mainW, mainH) {
        const cx = this.mainCX;
        const cy = this.mainCY;
        const gapWidth = 40;  // walkable gap between rooms
        
        // Only side-wall, non-stair doors become physical sub-rooms
        const floorplanDoors = this.interiorDoors.filter(d => 
            !d.isStairs && (d.wall === 'left' || d.wall === 'right')
        );
        
        if (floorplanDoors.length === 0) return;
        
        // Sub-room dimensions (scaled down from main)
        const subW = Math.max(130, mainW * 0.55);
        const subH = Math.max(110, mainH * 0.5);
        
        for (const door of floorplanDoors) {
            // Position door Y within main room bounds
            const doorY = cy + this._seededBetween(-Math.floor(mainH / 5), Math.floor(mainH / 5));
            door._floorplanY = doorY;
            door._isFloorplan = true;
            
            let srCX, srCY;
            if (door.wall === 'left') {
                srCX = cx - mainW/2 - subW/2;
                srCY = doorY;  // Centered on door Y
            } else {
                srCX = cx + mainW/2 + subW/2;
                srCY = doorY;
            }
            
            // Clamp sub-room so it doesn't go off-world
            srCY = Math.max(subH/2 + 20, Math.min(srCY, 800 - subH/2 - 20));
            
            this.subRooms.push({
                door: door,
                cx: srCX,
                cy: srCY,
                w: subW,
                h: subH,
                wall: door.wall,
                gapY: doorY,
                gapWidth: gapWidth,
                name: door.name
            });
            
            // Store gap info on the door for createWalls
            door._gapY = doorY;
            door._gapWidth = gapWidth;
        }
        
        // Store gap positions for createWalls to use
        this._sideGaps = {
            left: floorplanDoors.filter(d => d.wall === 'left').map(d => ({ y: d._gapY, hw: d._gapWidth / 2 })),
            right: floorplanDoors.filter(d => d.wall === 'right').map(d => ({ y: d._gapY, hw: d._gapWidth / 2 }))
        };
    }
    
    // Builds physical sub-rooms — walls, floor, furniture, roof occlusion
    buildSubRooms() {
        for (const sr of this.subRooms) {
            // Sub-room bounds
            const L = sr.cx - sr.w / 2;
            const R = sr.cx + sr.w / 2;
            const T = sr.cy - sr.h / 2;
            const B = sr.cy + sr.h / 2;
            const W = this.INTERIOR_WALL;
            const collisionThick = 6;
            
            // ═══ SUB-ROOM FLOOR ═══
            const config = this.archetype.floor;
            this.add.rectangle(sr.cx, sr.cy, sr.w, sr.h, config.base).setDepth(0);
            // Floor accent patches
            for (let i = 0; i < 6; i++) {
                const sx = sr.cx + this._seededBetween(-sr.w/2 + 15, sr.w/2 - 15);
                const sy = sr.cy + this._seededBetween(-sr.h/2 + 15, sr.h/2 - 15);
                this.add.ellipse(sx, sy, this._seededBetween(15, 35), this._seededBetween(10, 25), config.accent, 0.12).setDepth(0.5);
            }
            // Baseboard shadow
            this.add.rectangle(sr.cx, T + 2, sr.w - 4, 3, 0x000000, 0.15).setDepth(0.8);
            this.add.rectangle(sr.cx, B - 1, sr.w - 4, 2, 0x000000, 0.08).setDepth(0.8);
            this.add.rectangle(L + 1, sr.cy, 2, sr.h - 4, 0x000000, 0.12).setDepth(0.8);
            this.add.rectangle(R - 1, sr.cy, 2, sr.h - 4, 0x000000, 0.12).setDepth(0.8);
            
            // ═══ SUB-ROOM WALLS ═══
            // 3 walls + the connecting wall has a gap (no wall on connecting side)
            const sideVisTop = T - W.topH;
            const connectingSide = sr.wall === 'left' ? 'right' : 'left';
            const gapTop = sr.gapY - sr.gapWidth / 2;
            const gapBot = sr.gapY + sr.gapWidth / 2;
            
            // North wall (top) — always full
            this._isoWall(sr.cx, T, sr.w, 'north', 3.0);
            this.addWall(sr.cx, T + collisionThick/2, sr.w, collisionThick, 0x000000, true);
            
            // South wall (bottom) — collision + subtle floor-level visual
            this.addWall(sr.cx, B - collisionThick/2, sr.w, collisionThick, 0x000000, true);
            // South wall visual — thin baseboard line (camera looks down, so we see top edge)
            this.add.rectangle(sr.cx, B, sr.w, 3, W.darkColor).setDepth(3.0);
            this.add.rectangle(sr.cx, B - 1, sr.w - 2, 1, W.baseColor, 0.5).setDepth(3.1);
            
            // Far side wall (away from main room) — always full
            const farSide = sr.wall === 'left' ? 'left' : 'right';
            const farX = sr.wall === 'left' ? L : R;
            this._sideWall(farX, sideVisTop, B, farSide === 'left' ? 'west' : 'east', 3.5);
            this.addWall(
                farX + (farSide === 'left' ? collisionThick/2 : -collisionThick/2),
                sr.cy, collisionThick, sr.h, 0x000000, true
            );
            
            // Connecting wall (shared with main room) — gap where door is
            const connX = sr.wall === 'left' ? R : L;
            const connDir = sr.wall === 'left' ? 'east' : 'west';
            
            // Visual: two wall segments above and below gap
            if (gapTop > sideVisTop + 5) {
                this._sideWall(connX, sideVisTop, gapTop, connDir, 3.5);
            }
            if (B > gapBot + 5) {
                this._sideWall(connX, gapBot, B, connDir, 3.5);
            }
            
            // No collision on connecting wall — main room wall handles it via _sideGaps
            
            // ═══ DOORWAY VISUAL ═══
            // Frame around the gap on the connecting wall
            const frameCol = 0x3a3530;
            this.add.rectangle(connX, gapTop, 8, 3, 0x4a4540).setDepth(10.06);
            this.add.rectangle(connX, gapBot, 8, 3, 0x4a4540).setDepth(10.06);
            // Connecting corridor floor — bridge between rooms
            const config2 = this.archetype.floor;
            this.add.rectangle(connX, sr.gapY, 12, sr.gapWidth, config2.base).setDepth(0);
            this.add.rectangle(connX, sr.gapY, 10, sr.gapWidth - 4, config2.accent, 0.2).setDepth(0.5);
            
            // ═══ SUB-ROOM FURNITURE ═══
            const name = (sr.name || '').toLowerCase();
            if (name.includes('bed') || name.includes('closet')) {
                this.genBedroom(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            } else if (name.includes('bath')) {
                this.genBathroom(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            } else if (name.includes('kitchen') || name.includes('break')) {
                this.genKitchen(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            } else if (name.includes('office') || name.includes('study')) {
                this.genOffice(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            } else if (name.includes('storage') || name.includes('tool') || name.includes('cellar') || name.includes('loading')) {
                this.genStorage(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            } else {
                this.genBackRoom(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            }
            
            // Debris + wall decor + ambient for sub-room
            this.scatterDebris(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            this.addWallDecor(sr.cx, T, sr.w);
            this.addAmbientDetails(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            this._applyBiomeFurnitureOverlay(sr.cx, sr.cy, sr.w, sr.h, L, R, T, B);
            
            // Dormant enemy chance in sub-room
            const enemyRoll = Math.random();
            const types = this.archetype.enemyTypes || ['husk'];
            const ex = this._seededBetween(L + 20, R - 20);
            const ey = this._seededBetween(T + 20, B - 20);
            const eType = types[Math.floor(this.random() * types.length)];
            const subCleared = this.buildingId && BUILDING_STATE[this.buildingId] && BUILDING_STATE[this.buildingId].enemiesCleared;
            if (!subCleared && enemyRoll < (this.archetype.enemyChance || 0.3)) {
                this.spawnDormantEnemy(ex, ey, eType);
            }
            
            // ═══ ROOF OCCLUSION PANEL ═══
            // Clean rectangle that fits exactly over room + visible walls
            const wallH = W.frontH + W.topH;  // north wall visual height above T
            const wallSide = W.sideW;          // side wall visual width
            
            // Roof bounds: extends up to cover north wall, out to cover far side wall
            // Connecting side stays flush (no overhang into gap)
            const roofTop = T - wallH;
            const roofBot = B + 2;
            const roofLeft = sr.wall === 'left' ? L - wallSide : L;
            const roofRight = sr.wall === 'right' ? R + wallSide : R;
            
            const roof = this.add.rectangle(
                (roofLeft + roofRight) / 2,
                (roofTop + roofBot) / 2,
                roofRight - roofLeft,
                roofBot - roofTop,
                0x1e1e28, 1.0
            ).setDepth(500);
            
            sr.roof = roof;
            sr.roofVisible = true;
            sr.L = L; sr.R = R; sr.T = T; sr.B = B;
        }
    }

    // ═══ AMBIENT DETAIL SYSTEM ═══
    // Adds theme-appropriate small environment props beyond what gen methods provide
    addAmbientDetails(cx, cy, w, h, L, R, T, B) {
        const arch = this.archetypeName;
        const rng = () => this.random ? this.random() : Math.random();
        const buildType = (this.buildingType || this.subtype || '').toLowerCase();
        
        // Side wall decorations (items "leaning against" or "hanging on" side walls)
        this._addSideWallDetails(L, R, T, B, arch, rng);
        
        // Free-standing ambient props (not lootable, just visual)
        this._addFloorAmbient(cx, cy, w, h, L, R, T, B, arch, rng);
        
        // Ceiling/overhead details
        this._addOverheadDetails(cx, cy, w, h, T, arch, rng);
    }
    
    _addSideWallDetails(L, R, T, B, arch, rng) {
        const depth = 4;
        // Items along side walls — lean objects, boxes, etc.
        
        if (arch === 'residential' || arch === 'commercial') {
            // Trash can near a wall
            if (rng() < 0.6) {
                const tx = rng() < 0.5 ? L + 6 : R - 6;
                const ty = B - 15 - Math.floor(rng() * 30);
                this.add.rectangle(tx, ty, 7, 8, 0x3a3a3a, 0.4).setDepth(depth);
                this.add.rectangle(tx, ty - 4, 8, 1, 0x4a4a4a, 0.35).setDepth(depth + 0.01);
            }
            // Umbrella stand / coat rack area
            if (rng() < 0.4) {
                const ux = rng() < 0.5 ? L + 5 : R - 5;
                const uy = T + 15 + Math.floor(rng() * 20);
                this.add.rectangle(ux, uy, 2, 14, 0x4a3a2a, 0.35).setDepth(depth);
                this.add.rectangle(ux, uy - 5, 8, 2, 0x4a3a2a, 0.3).setDepth(depth + 0.01);
            }
        }
        
        if (arch === 'industrial') {
            // Stacked crates/barrels along walls
            const count = 1 + Math.floor(rng() * 2);
            for (let i = 0; i < count; i++) {
                const bx = rng() < 0.5 ? L + 8 : R - 8;
                const by = T + 25 + Math.floor(rng() * (B - T - 50));
                this.add.rectangle(bx, by, 10, 10, 0x3a3a2a, 0.4).setDepth(depth);
                this.add.rectangle(bx, by, 8, 1, 0x4a4a3a, 0.3).setDepth(depth + 0.01);
                // Stacked
                if (rng() < 0.4) {
                    this.add.rectangle(bx, by - 9, 9, 8, 0x3a3a2a, 0.35).setDepth(depth + 0.02);
                }
            }
            // Pipes along bottom of side wall
            if (rng() < 0.5) {
                const side = rng() < 0.5 ? L + 3 : R - 3;
                this.add.rectangle(side, (T + B) / 2, 2, (B - T) * 0.6, 0x5a5a5a, 0.25).setDepth(3.4);
            }
        }
        
        if (arch === 'civic') {
            // Potted plant
            if (rng() < 0.5) {
                const px = rng() < 0.5 ? L + 8 : R - 8;
                const py = T + 20 + Math.floor(rng() * 25);
                this.add.rectangle(px, py + 2, 6, 7, 0x5a3a2a, 0.4).setDepth(depth);
                this.add.ellipse(px, py - 2, 10, 8, 0x2a5a2a, 0.25).setDepth(depth + 0.01);
            }
            // Filing/storage along wall
            if (rng() < 0.4) {
                const fx = rng() < 0.5 ? L + 8 : R - 8;
                const fy = B - 20 - Math.floor(rng() * 20);
                this.add.rectangle(fx, fy, 10, 14, 0x4a4a4a, 0.35).setDepth(depth);
                this.add.rectangle(fx, fy - 2, 8, 1, 0x5a5a5a, 0.3).setDepth(depth + 0.01);
                this.add.rectangle(fx, fy + 3, 8, 1, 0x5a5a5a, 0.3).setDepth(depth + 0.01);
            }
        }
        
        if (arch === 'shelter') {
            // Makeshift bedroll / sleeping bag
            if (rng() < 0.5) {
                const bx = L + 10 + Math.floor(rng() * 20);
                const by = B - 20;
                this.add.rectangle(bx, by, 12, 22, 0x2a3a2a, 0.2).setDepth(depth);
                this.add.ellipse(bx, by - 10, 10, 6, 0x3a3a3a, 0.15).setDepth(depth + 0.01);
            }
        }
    }
    
    _addFloorAmbient(cx, cy, w, h, L, R, T, B, arch, rng) {
        const depth = 1.8;
        
        // Universal: occasional blood/rust stain  
        if (rng() < 0.25) {
            const sx = L + Math.floor(rng() * (R - L));
            const sy = T + Math.floor(rng() * (B - T));
            this.add.ellipse(sx, sy, 8 + Math.floor(rng()*12), 5 + Math.floor(rng()*8),
                0x3a1a1a, 0.08 + rng() * 0.06).setDepth(depth);
        }
        
        // Power cord / cable on floor
        if (rng() < 0.35 && arch !== 'shelter') {
            const gfx = this.add.graphics().setDepth(depth);
            gfx.lineStyle(1, 0x2a2a2a, 0.2);
            const sx = L + 10 + Math.floor(rng() * 30);
            const sy = T + 20 + Math.floor(rng() * (B - T - 40));
            gfx.lineBetween(sx, sy, sx + 15 + Math.floor(rng()*20), sy + Math.floor(rng()*20) - 10);
        }
        
        if (arch === 'residential') {
            // Shoes near entrance
            if (rng() < 0.4) {
                const ex = cx + Math.floor(rng()*20) - 10;
                const ey = B - 12;
                this.add.rectangle(ex, ey, 4, 6, 0x2a2a2a, 0.2).setDepth(depth).setAngle(15);
                this.add.rectangle(ex + 6, ey + 1, 4, 6, 0x2a2a2a, 0.18).setDepth(depth).setAngle(-10);
            }
            // Kids toys / misc
            if (rng() < 0.3) {
                const tx = cx + Math.floor(rng()*40) - 20;
                const ty = cy + Math.floor(rng()*20);
                this.add.circle(tx, ty, 3, 0x6a3a3a, 0.15).setDepth(depth);
            }
        }
        
        if (arch === 'commercial') {
            // Knocked over display / spilled items
            if (rng() < 0.45) {
                const dx = cx + Math.floor(rng()*40) - 20;
                const dy = cy + Math.floor(rng()*20) - 10;
                // Toppled display
                this.add.rectangle(dx, dy, 14, 4, 0x4a4a4a, 0.2).setDepth(depth).setAngle(Math.floor(rng()*30)-15);
                // Scattered small items
                for (let i = 0; i < 3; i++) {
                    this.add.rectangle(dx + Math.floor(rng()*16)-8, dy + Math.floor(rng()*12)-6, 
                        3, 2, 0x5a5a4a, 0.15).setDepth(depth).setAngle(Math.floor(rng()*90));
                }
            }
        }
        
        if (arch === 'industrial') {
            // Pallet on floor
            if (rng() < 0.35) {
                const px = cx + Math.floor(rng()*40) - 20;
                const py = cy + Math.floor(rng()*20);
                this.add.rectangle(px, py, 18, 14, 0x3a3028, 0.2).setDepth(depth);
                // Plank lines
                this.add.rectangle(px, py - 3, 16, 1, 0x4a3a28, 0.15).setDepth(depth + 0.01);
                this.add.rectangle(px, py + 3, 16, 1, 0x4a3a28, 0.15).setDepth(depth + 0.01);
            }
        }
        
        if (arch === 'civic') {
            // Water cooler
            if (rng() < 0.3) {
                const wx = rng() < 0.5 ? R - 12 : L + 12;
                const wy = T + 25 + Math.floor(rng() * 20);
                this.add.rectangle(wx, wy, 5, 10, 0x7a8a9a, 0.2).setDepth(depth + 2);
                this.add.rectangle(wx, wy - 5, 4, 3, 0x4a5a6a, 0.25).setDepth(depth + 2.01);
            }
        }
    }
    
    _addOverheadDetails(cx, cy, w, h, T, arch, rng) {
        // Light fixtures on ceiling (rendered as wall-face items near top)
        const W = this.INTERIOR_WALL;
        const depth = 3.2;
        
        if (arch === 'industrial') {
            // Hanging fluorescent lights
            const lightCount = w > 220 ? 2 : 1;
            const spacing = w / (lightCount + 1);
            for (let i = 0; i < lightCount; i++) {
                const lx = cx - w/2 + spacing * (i + 1);
                // Chain from ceiling (just a small detail near wall top)
                this.add.rectangle(lx, T - W.frontH - 1, 1, 3, 0x5a5a5a, 0.3).setDepth(depth);
            }
        }
        
        if (arch === 'civic') {
            // Ceiling panel edge (fluorescent light fixture detail near wall)
            if (rng() < 0.6) {
                const lx = cx + Math.floor(rng()*30) - 15;
                this.add.rectangle(lx, T - W.frontH - 1, 16, 2, 0x6a6a6a, 0.15).setDepth(depth);
            }
        }
    }

    createWalls(worldW, worldH, w, h) {
        const cx = this.mainCX;
        const cy = this.mainCY;
        const W = this.INTERIOR_WALL;
        const exitWidth = 55;
        const collisionThick = 6;
        const exitOnTop = (this.doorSide === 'north');
        const exitOnLeft = (this.doorSide === 'left');
        const exitOnRight = (this.doorSide === 'right');
        const exitOnBottom = (!exitOnTop && !exitOnLeft && !exitOnRight);

        // Room bounds
        const left = cx - w/2, right = cx + w/2;
        const top = cy - h/2, bot = cy + h/2;

        // Side wall visual span: above north face down to south ground
        const sideVisTop = top - W.frontH - W.topH;

        // ═══ NORTH (far) ISO WALL ═══
        if (exitOnTop) {
            const gL = cx - exitWidth/2, gR = cx + exitWidth/2;
            const seg1 = gL - left, seg2 = right - gR;
            if (seg1 > 0) { this._isoWall(left + seg1/2, top, seg1, 'north', 3); this.addWall(left + seg1/2, top + collisionThick/2, seg1, collisionThick, 0x000000, true); }
            if (seg2 > 0) { this._isoWall(gR + seg2/2, top, seg2, 'north', 3); this.addWall(gR + seg2/2, top + collisionThick/2, seg2, collisionThick, 0x000000, true); }
        } else {
            this._isoWall(cx, top, w, 'north', 3);
            this.addWall(cx, top + collisionThick/2, w, collisionThick, 0x000000, true);
        }

        // ═══ SOUTH ISO WALL — visible with occlusion fade for ¾ camera ═══
        if (!this._occlusionWalls) this._occlusionWalls = [];
        if (exitOnBottom) {
            const gL = cx - exitWidth/2, gR = cx + exitWidth/2;
            const seg1 = gL - left, seg2 = right - gR;
            if (seg1 > 0) {
                this.addWall(left + seg1/2, bot - collisionThick/2, seg1, collisionThick, 0x000000, true);
                const sParts1 = this._makeSouthWall(left + seg1/2, bot, seg1);
                this._occlusionWalls.push({ parts: sParts1, facing: 'south', left: left, right: gL, groundY: bot, visualTop: bot - W.frontH - W.topH, visualBot: bot });
            }
            if (seg2 > 0) {
                this.addWall(gR + seg2/2, bot - collisionThick/2, seg2, collisionThick, 0x000000, true);
                const sParts2 = this._makeSouthWall(gR + seg2/2, bot, seg2);
                this._occlusionWalls.push({ parts: sParts2, facing: 'south', left: gR, right: right, groundY: bot, visualTop: bot - W.frontH - W.topH, visualBot: bot });
            }
        } else {
            this.addWall(cx, bot - collisionThick/2, w, collisionThick, 0x000000, true);
            const sParts = this._makeSouthWall(cx, bot, w);
            this._occlusionWalls.push({ parts: sParts, facing: 'south', left: left, right: right, groundY: bot, visualTop: bot - W.frontH - W.topH, visualBot: bot });
        }

        // ═══ LEFT (west) SIDE WALL ═══
        {
            // Collect all gaps on left wall: exit + sub-room connections
            const leftGaps = [];
            if (exitOnLeft) leftGaps.push({ y: cy, hw: exitWidth / 2 });
            if (this._sideGaps && this._sideGaps.left) {
                this._sideGaps.left.forEach(g => leftGaps.push(g));
            }
            leftGaps.sort((a, b) => a.y - b.y);
            
            if (leftGaps.length > 0) {
                // Build segmented wall with all gaps
                let segStart = sideVisTop;
                let colStart = top;
                for (const gap of leftGaps) {
                    const gT = gap.y - gap.hw;
                    const gB = gap.y + gap.hw;
                    // Visual segment above gap
                    if (gT > segStart + 5) this._sideWall(left, segStart, gT, 'west', 3.5);
                    // Collision segment above gap
                    const cs = gT - colStart;
                    if (cs > 0) this.addWall(left + collisionThick/2, colStart + cs/2, collisionThick, cs, 0x000000, true);
                    segStart = gB;
                    colStart = gB;
                }
                // Final segment after last gap
                if (bot > segStart + 5) this._sideWall(left, segStart, bot, 'west', 3.5);
                const lastSeg = bot - colStart;
                if (lastSeg > 0) this.addWall(left + collisionThick/2, colStart + lastSeg/2, collisionThick, lastSeg, 0x000000, true);
            } else {
                this._sideWall(left, sideVisTop, bot, 'west', 3.5);
                this.addWall(left + collisionThick/2, cy, collisionThick, h, 0x000000, true);
            }
        }

        // ═══ RIGHT (east) SIDE WALL ═══
        {
            const rightGaps = [];
            if (exitOnRight) rightGaps.push({ y: cy, hw: exitWidth / 2 });
            if (this._sideGaps && this._sideGaps.right) {
                this._sideGaps.right.forEach(g => rightGaps.push(g));
            }
            rightGaps.sort((a, b) => a.y - b.y);
            
            if (rightGaps.length > 0) {
                let segStart = sideVisTop;
                let colStart = top;
                for (const gap of rightGaps) {
                    const gT = gap.y - gap.hw;
                    const gB = gap.y + gap.hw;
                    if (gT > segStart + 5) this._sideWall(right, segStart, gT, 'east', 3.5);
                    const cs = gT - colStart;
                    if (cs > 0) this.addWall(right - collisionThick/2, colStart + cs/2, collisionThick, cs, 0x000000, true);
                    segStart = gB;
                    colStart = gB;
                }
                if (bot > segStart + 5) this._sideWall(right, segStart, bot, 'east', 3.5);
                const lastSeg = bot - colStart;
                if (lastSeg > 0) this.addWall(right - collisionThick/2, colStart + lastSeg/2, collisionThick, lastSeg, 0x000000, true);
            } else {
                this._sideWall(right, sideVisTop, bot, 'east', 3.5);
                this.addWall(right - collisionThick/2, cy, collisionThick, h, 0x000000, true);
            }
        }

        // ═══ WINDOWS on far (north) wall ═══
        if (!exitOnTop && !this.isSubRoom && (this.archetypeName === 'residential' || this.archetypeName === 'commercial' || this.archetypeName === 'civic')) {
            const windowCount = w > 280 ? 2 : 1;
            const spacing = w / (windowCount + 1);
            for (let i = 0; i < windowCount; i++) {
                const wx = cx - w/2 + spacing * (i + 1);
                this.drawWindow(wx, top - W.frontH/2, i === 0);
            }
        }

        // ═══ EXIT DOOR ═══
        const exitFrameCol = W.frameDark;
        const exitDoorCol = 0x3a3a32;
        const exitDoorLt = 0x4a4a42;
        const exitDoorDk = 0x2a2a22;

        if (exitOnTop) {
            // North exit — front face door in iso wall gap
            const doorY = top - W.frontH/2;
            const faceH = W.frontH;
            // Doorway recess
            this.add.rectangle(cx, doorY, exitWidth + 2, faceH + 2, 0x050508).setDepth(2.9);
            // Outer frame
            this.add.rectangle(cx, doorY, exitWidth + 8, faceH, exitFrameCol).setDepth(3.0);
            // Frame side posts
            this.add.rectangle(cx - exitWidth/2 - 1, doorY, 5, faceH, this.lightenColor(exitFrameCol, 8)).setDepth(3.2);
            this.add.rectangle(cx + exitWidth/2 + 1, doorY, 5, faceH, this.darkenColor(exitFrameCol, 5)).setDepth(3.2);
            // Frame top lintel
            this.add.rectangle(cx, top - faceH + 3, exitWidth + 8, 6, exitFrameCol).setDepth(3.2);
            this.add.rectangle(cx, top - faceH + 2, exitWidth + 6, 3, this.lightenColor(exitFrameCol, 10)).setDepth(3.21);
            // Door panel
            this.exitDoor = this.add.rectangle(cx, doorY + 1, exitWidth - 4, faceH - 3, exitDoorCol).setDepth(3.1);
            // Door face detail
            this.add.rectangle(cx, doorY + 1, exitWidth - 8, faceH - 7, exitDoorLt).setDepth(3.12);
            // Upper panel
            this.add.rectangle(cx, doorY - 4, exitWidth - 12, 8, exitDoorDk).setDepth(3.13);
            // Lower panel
            this.add.rectangle(cx, doorY + 6, exitWidth - 12, 6, exitDoorDk).setDepth(3.13);
            // Reinforcement plate
            this.add.rectangle(cx, doorY + 2, exitWidth - 10, 3, this.darkenColor(exitDoorCol, 8)).setDepth(3.15);
            // Push bar
            this.add.rectangle(cx, doorY + 2, exitWidth - 14, 3, 0x5a5a4a).setDepth(3.16);
            this.add.rectangle(cx, doorY + 2, exitWidth - 16, 1, 0x6a6a5a).setDepth(3.17);
            // Handle
            this.add.rectangle(cx + exitWidth/2 - 10, doorY + 2, 4, 2, 0x6a6a5a).setDepth(3.18);
            // EXIT sign
            this.add.rectangle(cx, doorY - faceH/2 + 4, 24, 9, 0x1a1a18).setDepth(3.25);
            this.add.rectangle(cx, doorY - faceH/2 + 4, 22, 7, 0x1a2218).setDepth(3.26);
            const exitLabel = this.add.text(cx, doorY - faceH/2 + 4, this.isSubRoom ? 'BACK' : 'EXIT', {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#4a6a4a'
            }).setOrigin(0.5).setDepth(3.3);
            this.tweens.add({ targets: exitLabel, alpha: { from: 0.6, to: 0.9 }, duration: 1500, yoyo: true, repeat: -1 });
            // Threshold strip at wall base
            this.add.rectangle(cx, top + 1, exitWidth + 6, 3, this.darkenColor(W.baseColor, 25)).setDepth(3.15);
            this.add.rectangle(cx, top + 3, exitWidth + 4, 2, this.darkenColor(W.baseColor, 35)).setDepth(3.14);
            // Outside darkness
            this.add.rectangle(cx, top - faceH - 10, exitWidth - 8, 15, 0x0a0a0f).setDepth(0);
            this.addWall(cx, top - faceH - 5, exitWidth + 10, 10, 0x000000, true);

        } else if (exitOnLeft) {
            // Left exit — side profile in iso side wall gap
            const sw = W.sideW;
            this.add.rectangle(left, cy, sw + 2, exitWidth + 2, 0x0a0a08).setDepth(9.9);
            this.exitDoor = this.add.rectangle(left, cy, sw, exitWidth - 2, exitDoorCol).setDepth(10);
            this.add.rectangle(left + 2, cy, 3, exitWidth - 4, exitDoorDk).setDepth(10.1);
            this.add.rectangle(left, cy - 8, sw - 2, 1, exitDoorDk).setDepth(10.05);
            this.add.rectangle(left, cy + 8, sw - 2, 1, exitDoorDk).setDepth(10.05);
            this.add.rectangle(left + 4, cy, 3, 4, 0x5a5a4a).setDepth(10.2);
            this.add.circle(left + 5, cy, 1.5, 0x6a6a5a).setDepth(10.25);
            const exitLabel = this.add.text(left, cy - exitWidth/2 - 6, this.isSubRoom ? 'BACK' : 'EXIT', {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#4a6a4a'
            }).setOrigin(0.5).setDepth(11);
            this.tweens.add({ targets: exitLabel, alpha: { from: 0.6, to: 0.9 }, duration: 1500, yoyo: true, repeat: -1 });
            this.add.rectangle(left - 10, cy, 15, exitWidth - 5, 0x0a0a0f).setDepth(0);
            this.addWall(left - 5, cy, 10, exitWidth + 10, 0x000000, true);

        } else if (exitOnRight) {
            // Right exit — side profile mirror
            const sw = W.sideW;
            this.add.rectangle(right, cy, sw + 2, exitWidth + 2, 0x0a0a08).setDepth(9.9);
            this.exitDoor = this.add.rectangle(right, cy, sw, exitWidth - 2, exitDoorCol).setDepth(10);
            this.add.rectangle(right - 2, cy, 3, exitWidth - 4, exitDoorDk).setDepth(10.1);
            this.add.rectangle(right, cy - 8, sw - 2, 1, exitDoorDk).setDepth(10.05);
            this.add.rectangle(right, cy + 8, sw - 2, 1, exitDoorDk).setDepth(10.05);
            this.add.rectangle(right - 4, cy, 3, 4, 0x5a5a4a).setDepth(10.2);
            this.add.circle(right - 5, cy, 1.5, 0x6a6a5a).setDepth(10.25);
            const exitLabel = this.add.text(right, cy - exitWidth/2 - 6, this.isSubRoom ? 'BACK' : 'EXIT', {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#4a6a4a'
            }).setOrigin(0.5).setDepth(11);
            this.tweens.add({ targets: exitLabel, alpha: { from: 0.6, to: 0.9 }, duration: 1500, yoyo: true, repeat: -1 });
            this.add.rectangle(right + 10, cy, 15, exitWidth - 5, 0x0a0a0f).setDepth(0);
            this.addWall(right + 5, cy, 10, exitWidth + 10, 0x000000, true);

        } else {
            // South exit — player walks toward camera through south iso wall gap
            const doorY = bot - W.frontH/2;
            const faceH = W.frontH;
            // Recess
            this.add.rectangle(cx, doorY, exitWidth + 2, faceH + 2, 0x0a0a08).setDepth(2.9);
            // Frame
            this.add.rectangle(cx, doorY, exitWidth + 6, faceH, exitFrameCol).setDepth(3.0);
            // Door panel — south wall face (darker treatment)
            this.exitDoor = this.add.rectangle(cx, doorY, exitWidth - 2, faceH - 2, exitDoorCol).setDepth(3.1);
            // Top surface of door threshold (visible from ¾ angle)
            this.add.rectangle(cx, bot - faceH, exitWidth - 4, 3, exitDoorLt).setDepth(3.12);
            // Door front edge (thin strip)
            this.add.rectangle(cx, doorY + faceH/2 - 2, exitWidth - 4, 2, exitDoorDk).setDepth(3.12);
            // Worn metal plate
            this.add.rectangle(cx, doorY, exitWidth - 10, faceH - 6, 0x3a3a30).setDepth(3.05);
            // Push bar
            this.add.rectangle(cx, doorY, exitWidth - 14, 2, 0x5a5a4a).setDepth(3.15);
            // EXIT sign above door
            this.add.rectangle(cx, bot - faceH - 4, 22, 8, 0x1a1a18).setDepth(3.2);
            this.add.rectangle(cx, bot - faceH - 4, 20, 6, 0x1a2218).setDepth(3.22);
            const exitLabel = this.add.text(cx, bot - faceH - 4, this.isSubRoom ? 'BACK' : 'EXIT', {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#4a6a4a'
            }).setOrigin(0.5).setDepth(3.3);
            this.tweens.add({ targets: exitLabel, alpha: { from: 0.6, to: 0.9 }, duration: 1500, yoyo: true, repeat: -1 });
            // Outside darkness
            this.add.rectangle(cx, bot + 10, exitWidth - 5, 15, 0x0a0a0f).setDepth(0);
            this.addWall(cx, bot + 5, exitWidth + 10, 10, 0x000000, true);
        }
    }
    
    drawWindow(wx, wy, showCelestial = false) {
        const timeOfDay = CONFIG.timeOfDay || 'midday';
        const skyColors = {
            dawn: 0xffaa77,
            midday: 0x6699cc,
            dusk: 0xff7755,
            night: 0x1a1a3a
        };
        
        // Frame
        this.add.rectangle(wx, wy, 32, 18, 0x2a2520).setDepth(3.5);
        // Sky
        this.add.rectangle(wx, wy, 28, 14, skyColors[timeOfDay] || 0x6699cc).setDepth(3.6);
        // Cross pane
        this.add.rectangle(wx, wy, 28, 1.5, 0x3a3530).setDepth(3.7);
        this.add.rectangle(wx, wy, 1.5, 14, 0x3a3530).setDepth(3.7);
        
        // Only first window gets celestial detail
        if (showCelestial) {
            if (timeOfDay === 'night') {
                // Crescent moon
                this.add.circle(wx + 6, wy - 2, 3, 0xeeeedd).setDepth(3.65);
                this.add.circle(wx + 7, wy - 3, 2.5, skyColors.night).setDepth(3.65);
            } else if (timeOfDay === 'dawn' || timeOfDay === 'dusk') {
                // Horizon line + sun
                this.add.rectangle(wx, wy + 5, 28, 3, 0x4a5a4a).setDepth(3.65);
                this.add.circle(wx, wy + 4, 4, timeOfDay === 'dawn' ? 0xffdd88 : 0xff9966).setDepth(3.65);
            }
        }
    }
    
    // Draw a door shape on a side wall
    drawDoorOnWall(wall, dx, dy) {
        const d = 10;
        
        if (wall === 'left' || wall === 'right') {
            // Side wall door — player sees the SIDE PROFILE (narrow, tall)
            // Door is recessed into the wall, we see the door's depth/thickness
            const dir = wall === 'left' ? 1 : -1; // extends into room
            
            // Dark recess opening in wall
            this.add.rectangle(dx, dy, 8, 36, 0x0a0a08).setDepth(d + 0.04);
            
            // Door frame — 3 edges visible
            const frameCol = 0x3a3530;
            this.add.rectangle(dx, dy - 18, 10, 3, 0x4a4540).setDepth(d + 0.06);                 // top frame
            this.add.rectangle(dx + dir * 4, dy, 2, 36, frameCol).setDepth(d + 0.06);             // inner frame edge
            this.add.rectangle(dx - dir * 4, dy, 2, 36, IsoRenderer.darken(frameCol, 0.12)).setDepth(d + 0.06); // outer frame edge
            
            // Door panel — side profile (thin, tall)
            const panelCol = 0x5a4a35;
            this.add.rectangle(dx, dy, 6, 34, panelCol).setDepth(d + 0.1);
            
            // Door thickness / depth visible (extends into room)
            this.add.rectangle(dx + dir * 4, dy, 3, 32, IsoRenderer.darken(panelCol, 0.15)).setDepth(d + 0.12);
            
            // Panel groove lines (horizontal detail on side view)
            this.add.rectangle(dx, dy - 10, 4, 1, IsoRenderer.darken(panelCol, 0.08)).setDepth(d + 0.14);
            this.add.rectangle(dx, dy + 2, 4, 1, IsoRenderer.darken(panelCol, 0.08)).setDepth(d + 0.14);
            this.add.rectangle(dx, dy + 10, 4, 1, IsoRenderer.darken(panelCol, 0.08)).setDepth(d + 0.14);
            
            // Handle — seen from side as small protrusion
            this.add.rectangle(dx + dir * 5, dy + 2, 3, 4, 0x6a6a5a).setDepth(d + 0.2);
            this.add.circle(dx + dir * 6, dy + 2, 2, 0xbbaa88).setDepth(d + 0.22);
            this.add.circle(dx + dir * 6, dy + 2, 1, 0xccbb99).setDepth(d + 0.23);
            
            // Hinges (visible on wall-flush side)
            this.add.rectangle(dx - dir * 3, dy - 10, 3, 4, 0x5a5a4a).setDepth(d + 0.15);
            this.add.rectangle(dx - dir * 3, dy + 10, 3, 4, 0x5a5a4a).setDepth(d + 0.15);
            this.add.rectangle(dx - dir * 3, dy - 10, 2, 2, 0x6a6a5a).setDepth(d + 0.16); // hinge pin
            this.add.rectangle(dx - dir * 3, dy + 10, 2, 2, 0x6a6a5a).setDepth(d + 0.16);
            
            // Threshold
            this.add.rectangle(dx, dy + 17, 10, 2, 0x4a4a3a).setDepth(d + 0.05);
            
            // Light spill from other room
            this.add.rectangle(dx + dir * 3, dy, 4, 30, 0x2a2a1a, 0.08).setDepth(d + 0.03);
            
        } else {
            // Top/bottom wall door — player sees FRONT face (wide, short)
            const doorW = 16;
            const doorH = 34;
            
            // Dark recess
            this.add.rectangle(dx, dy, doorW + 4, doorH + 4, 0x0a0a08).setDepth(d + 0.05);
            
            // Door frame
            const frameCol = 0x3a3530;
            this.add.rectangle(dx, dy - doorH/2 - 1, doorW + 4, 3, 0x4a4540).setDepth(d + 0.08);
            this.add.rectangle(dx - doorW/2 - 1, dy, 3, doorH, frameCol).setDepth(d + 0.08);
            this.add.rectangle(dx + doorW/2 + 1, dy, 3, doorH, IsoRenderer.darken(frameCol, 0.15)).setDepth(d + 0.08);
            
            // Door panel
            const panelCol = 0x5a4a35;
            this.add.rectangle(dx, dy, doorW, doorH, panelCol).setDepth(d + 0.1);
            
            // Two raised panels
            const insetCol = IsoRenderer.darken(panelCol, 0.08);
            const insetLt = IsoRenderer.lighten(panelCol, 0.08);
            this.add.rectangle(dx, dy - 8, doorW - 5, 12, insetCol).setDepth(d + 0.15);
            this.add.rectangle(dx, dy - 9, doorW - 7, 10, insetLt).setDepth(d + 0.16);
            this.add.rectangle(dx, dy + 8, doorW - 5, 12, insetCol).setDepth(d + 0.15);
            this.add.rectangle(dx, dy + 7, doorW - 7, 10, insetLt).setDepth(d + 0.16);
            
            // Handle with plate
            const hx = dx + 4;
            this.add.rectangle(hx, dy + 1, 3, 8, 0x6a6a5a).setDepth(d + 0.2);
            this.add.circle(hx, dy + 2, 2.5, 0xbbaa88).setDepth(d + 0.25);
            this.add.circle(hx, dy + 2, 1.5, 0xccbb99).setDepth(d + 0.26);
            this.add.circle(hx, dy + 5, 1, 0x2a2a22).setDepth(d + 0.25);
            
            // Hinges
            this.add.rectangle(dx - doorW/2 + 2, dy - 10, 2, 4, 0x5a5a4a).setDepth(d + 0.2);
            this.add.rectangle(dx - doorW/2 + 2, dy + 10, 2, 4, 0x5a5a4a).setDepth(d + 0.2);
            
            // Threshold
            this.add.rectangle(dx, dy + doorH/2 + 1, doorW + 2, 2, 0x4a4a3a).setDepth(d + 0.07);
        }
    }
    
    createAmbienceLight(cx, cy, w, h) {
        const L = this.archetype.light;
        if (!L) return;
        
        // Position: center by default, offset if specified
        const lx = cx + (L.offsetX ? w * L.offsetX : 0);
        const ly = cy - h * (L.pos || 0.4) + h * 0.5;
        
        if (L.burst) {
            // BURST mode (industrial sparking) — erratic flash cycles
            const spark = this.add.ellipse(lx, ly, L.size[0], L.size[1], L.color, 0).setDepth(2);
            this.time.addEvent({
                delay: Phaser.Math.Between(1500, 4000),
                loop: true,
                callback: () => {
                    this.tweens.add({
                        targets: spark,
                        alpha: { from: L.alpha[0], to: L.alpha[1] },
                        scaleX: { from: L.scale[0], to: L.scale[1] },
                        scaleY: { from: L.scale[0], to: L.scale[1] },
                        duration: L.speed,
                        yoyo: true,
                        repeat: Phaser.Math.Between(2, 5),
                        onComplete: () => spark.setAlpha(0)
                    });
                }
            });
            return;
        }
        
        // Outer glow ellipse
        const outerTween = {
            alpha: { from: L.alpha[0], to: L.alpha[1] },
            scaleX: { from: L.scale[0], to: L.scale[1] },
            scaleY: { from: L.scale[0], to: L.scale[1] },
            duration: L.speed,
            yoyo: true, repeat: -1, ease: 'Sine.inOut'
        };
        // Broken flicker mode (commercial) — add hold + repeatDelay for intermittent on/off
        if (L.hold) outerTween.hold = Phaser.Math.Between(L.hold * 0.5, L.hold * 1.5);
        if (L.repeatDelay) outerTween.repeatDelay = Phaser.Math.Between(L.repeatDelay * 0.5, L.repeatDelay * 1.5);
        
        const outer = this.add.ellipse(lx, ly, L.size[0], L.size[1], L.color, L.alpha[0]).setDepth(2);
        outerTween.targets = outer;
        this.tweens.add(outerTween);
        
        // Inner hotspot ellipse
        const innerTween = {
            targets: null,
            alpha: { from: L.innerAlpha[0], to: L.innerAlpha[1] },
            duration: L.innerSpeed,
            yoyo: true, repeat: -1
        };
        if (L.hold) innerTween.hold = Phaser.Math.Between(L.hold * 0.4, L.hold * 1.2);
        if (L.repeatDelay) innerTween.repeatDelay = Phaser.Math.Between(L.repeatDelay * 0.4, L.repeatDelay * 1.2);
        
        const inner = this.add.ellipse(lx, ly, L.inner[0], L.inner[1], L.color, L.innerAlpha[0]).setDepth(2);
        innerTween.targets = inner;
        this.tweens.add(innerTween);
    }
    
    addWall(x, y, w, h, color, invisible = false) {
        const wall = this.add.rectangle(x, y, w, h, color, invisible ? 0 : 1).setDepth(10);
        this.physics.add.existing(wall, true);
        this.walls.add(wall);
    }
    
    lightenColor(color, amount) {
        const r = Math.min(255, ((color >> 16) & 0xff) + amount);
        const g = Math.min(255, ((color >> 8) & 0xff) + amount);
        const b = Math.min(255, (color & 0xff) + amount);
        return (r << 16) | (g << 8) | b;
    }
    
    darkenColor(color, amount) {
        const r = Math.max(0, ((color >> 16) & 0xff) - amount);
        const g = Math.max(0, ((color >> 8) & 0xff) - amount);
        const b = Math.max(0, (color & 0xff) - amount);
        return (r << 16) | (g << 8) | b;
    }
    
    generateInterior(w, h) {
        // === INTERIOR LAYOUT CONSTANTS ===
        const INTERIOR = {
            wallPad: 22,         // wall inner edge padding
            topExtra: 8,         // far wall extra for iso depth face
            doorClear: 55,       // clearance around each door
            doorHalfW: 25,       // door exclusion zone half-width
            furnitureSpacing: 30, // min distance between furniture
            enemyFurniturePad: 25, // enemy-furniture avoidance distance
            exitClearance: 35,   // extra clearance past exit door
            wallThresh: 25,      // wall proximity threshold for orientation
            depthScale: 0.05,    // Y-depth multiplier for depth sorting
            depthBase: 10        // base depth for Y-sorting formula
        };
        this._INTERIOR = INTERIOR; // expose for helper methods
        
        // Track if this building was already visited - prevent ALL enemy respawn
        const alreadyVisited = this.buildingId && BUILDING_STATE[this.buildingId] && BUILDING_STATE[this.buildingId].visited;
        if (this.buildingId) {
            if (!BUILDING_STATE[this.buildingId]) BUILDING_STATE[this.buildingId] = {};
            BUILDING_STATE[this.buildingId].visited = true;
        }
        const cx = this.mainCX;
        const cy = this.mainCY;
        // Wall edges (inner side, accounting for wall thickness + padding)
        const L = cx - w/2 + INTERIOR.wallPad;  // left wall inner edge
        const R = cx + w/2 - INTERIOR.wallPad;  // right wall inner edge
        let T = cy - h/2 + INTERIOR.wallPad + INTERIOR.topExtra; // far wall (extra for depth face)
        const B = cy + h/2 - INTERIOR.wallPad;  // bottom wall
        this._roomL = L; this._roomR = R; this._roomT = T; this._roomB = B;
        
        // When exit is on the top (north) wall, push far-wall furniture down
        // so nothing blocks the exit gap
        if (this.doorSide === 'north') {
            T = cy - h/2 + INTERIOR.wallPad + INTERIOR.exitClearance; // extra clearance past exit door
        }
        
        // Store exit exclusion zone for furniture helpers
        this._exitZone = null;
        if (this.doorSide === 'north') {
            this._exitZone = { x: cx, y: cy - h/2, halfW: 35, wall: 'top' };
        } else if (this.doorSide === 'left') {
            this._exitZone = { x: cx - w/2, y: cy, halfW: 35, wall: 'left' };
        } else if (this.doorSide === 'right') {
            this._exitZone = { x: cx + w/2, y: cy, halfW: 35, wall: 'right' };
        } else {
            this._exitZone = { x: cx, y: cy + h/2, halfW: 35, wall: 'bottom' };
        }
        
        // Collect door positions per wall for furniture avoidance
        this.doorZones = { left: [], right: [], top: [], bottom: [] };
        this.interiorDoors.forEach(door => {
            if (door.wall === 'left' || door.wall === 'right') {
                this.doorZones[door.wall].push(door.y);
            }
        });
        // Add exit door to doorZones
        if (this._exitZone) {
            const ez = this._exitZone;
            if (ez.wall === 'left' || ez.wall === 'right') {
                this.doorZones[ez.wall].push(ez.y);
            } else if (ez.wall === 'top' || ez.wall === 'bottom') {
                this.doorZones[ez.wall].push(ez.x);
            }
        }
        // Store all door rectangles for universal collision check
        this._allDoorRects = [];
        const doorClear = INTERIOR.doorClear;
        this.interiorDoors.forEach(door => {
            if (door.wall === 'left') this._allDoorRects.push({ x: cx - w/2, y: door.y, hw: 25, hh: doorClear });
            if (door.wall === 'right') this._allDoorRects.push({ x: cx + w/2, y: door.y, hw: 25, hh: doorClear });
            if (door.wall === 'top') this._allDoorRects.push({ x: door.x, y: cy - h/2, hw: doorClear, hh: 25 });
        });
        if (this._exitZone) {
            const ez = this._exitZone;
            if (ez.wall === 'left') this._allDoorRects.push({ x: ez.x, y: ez.y, hw: 25, hh: doorClear });
            if (ez.wall === 'right') this._allDoorRects.push({ x: ez.x, y: ez.y, hw: 25, hh: doorClear });
            if (ez.wall === 'top') this._allDoorRects.push({ x: ez.x, y: ez.y, hw: doorClear, hh: 25 });
            if (ez.wall === 'bottom') this._allDoorRects.push({ x: ez.x, y: ez.y, hw: doorClear, hh: 25 });
        }
        
        // Sub-rooms use their name to determine theme
        if (this.isSubRoom) {
            const name = (this.subRoomName || this.buildingName || '').toLowerCase();
            if (name.includes('rooftop') || name.includes('roof')) {
                this.genRooftop(cx, cy, w, h, L, R, T, B);
            } else if (name.includes('floor 2') || name.includes('floor 3')) {
                this.genApartmentFloor(cx, cy, w, h, L, R, T, B);
            } else if (name.includes('bed') || name.includes('closet')) {
                this.genBedroom(cx, cy, w, h, L, R, T, B);
            } else if (name.includes('bath')) {
                this.genBathroom(cx, cy, w, h, L, R, T, B);
            } else if (name.includes('kitchen') || name.includes('break')) {
                this.genKitchen(cx, cy, w, h, L, R, T, B);
            } else if (name.includes('office') || name.includes('study')) {
                this.genOffice(cx, cy, w, h, L, R, T, B);
            } else if (name.includes('storage') || name.includes('tool') || name.includes('cellar') || name.includes('loading')) {
                this.genStorage(cx, cy, w, h, L, R, T, B);
            } else {
                this.genBackRoom(cx, cy, w, h, L, R, T, B);
            }
            // Sub-room debris + dormant enemy chance
            this.scatterDebris(cx, cy, w, h, L, R, T, B);
            this.addWallDecor(cx, cy - h/2, w);
            this.addAmbientDetails(cx, cy, w, h, L, R, T, B);
            this._applyBiomeFurnitureOverlay(cx, cy, w, h, L, R, T, B);
            // Always consume the same random calls for deterministic layout
            const enemyRoll = Math.random();
            const types = this.archetype.enemyTypes || ['husk'];
            const ex = Phaser.Math.Between(L + 20, R - 20);
            const ey = Phaser.Math.Between(T + 20, B - 20);
            const eType = types[Math.floor(Math.random() * types.length)];
            // Only skip if enemies were actually cleared (killed), not just because room was visited
            const subCleared = this.buildingId && BUILDING_STATE[this.buildingId] && BUILDING_STATE[this.buildingId].enemiesCleared;
            if (!subCleared && enemyRoll < (this.archetype.enemyChance || 0.3)) {
                this.spawnDormantEnemy(ex, ey, eType);
            }
            return;
        }
        
        // Track all placed furniture to prevent overlap
        this._placedFurniture = [];
        
        // === INTERIOR LAYOUT ROUTING ===
        // Priority: buildingType (from template) > locationType (from node) > archetype fallback
        // buildingType is the template key (e.g. 'apartment', 'church', 'police_station')
        // This ensures each building gets the right interior regardless of which node it's in
        
        // Comprehensive mapping: buildingType/locationType → generator method
        const layoutMap = {
            // Residential
            house:          'genLivingRoom',
            house_large:    'genLivingRoom',
            apartment:      'genApartmentFloor',
            motel:          'genMotelRoom',
            // Commercial
            store:          'genStore',
            convenience:    'genConvenienceStore',
            pharmacy:       'genPharmacy',
            restaurant:     'genDiner',
            gas_station_main: 'genConvenienceStore',
            gas_station:    'genConvenienceStore',
            rest_stop:      'genConvenienceStore',
            grocery:        'genGrocery',
            hardware_store: 'genHardwareStore',
            diner:          'genDiner',
            // Industrial
            warehouse:      'genWarehouse',
            factory:        'genWarehouse',
            garage:         'genGarage',
            auto_shop:      'genGarage',
            storage_unit:   'genStorage',
            loading_dock:   'genWarehouse',
            // Civic
            church:         'genChurch',
            police_station: 'genPoliceStation',
            hospital_main:  'genPharmacy',
            office_building:'genOffice',
            school:         'genSchool',
            // Special
            research_lab:   'genResearchLab',
            bunker:         'genBunker',
            // Shelter
            shed:           'genStorage',
            small_shed:     'genStorage',
            ruins:          'genStorage',
            park_restroom:  'genBathroom'
        };
        
        let generated = false;
        
        // Try buildingType first (most specific — knows exactly which template)
        if (this.buildingType && layoutMap[this.buildingType]) {
            const method = layoutMap[this.buildingType];
            if (typeof this[method] === 'function') {
                this[method](cx, cy, w, h, L, R, T, B);
                generated = true;
            }
        }
        
        // Try locationType second (from node system)
        if (!generated && this.locationType && layoutMap[this.locationType]) {
            const method = layoutMap[this.locationType];
            if (typeof this[method] === 'function') {
                this[method](cx, cy, w, h, L, R, T, B);
                generated = true;
            }
        }
        
        // Archetype fallback (last resort)
        if (!generated) {
            switch(this.archetypeName) {
                case 'residential': this.genLivingRoom(cx, cy, w, h, L, R, T, B); break;
                case 'commercial': this.genStore(cx, cy, w, h, L, R, T, B); break;
                case 'industrial':
                    if (this.isGarage) this.genGarage(cx, cy, w, h, L, R, T, B);
                    else this.genWarehouse(cx, cy, w, h, L, R, T, B);
                    break;
                case 'civic': this.genOffice(cx, cy, w, h, L, R, T, B); break;
                case 'shelter': this.genShelter(cx, cy, w, h, L, R, T, B); break;
                default: this.genLivingRoom(cx, cy, w, h, L, R, T, B); break;
            }
        }
        
        // Main room debris scatter
        this.scatterDebris(cx, cy, w, h, L, R, T, B);
        
        // Wall decorations + ambient environmental details
        this.addWallDecor(cx, cy - h/2, w);
        this.addAmbientDetails(cx, cy, w, h, L, R, T, B);
        
        // Biome-specific furniture modifications (vine growth, dust, crystal growths)
        this._applyBiomeFurnitureOverlay(cx, cy, w, h, L, R, T, B);
        
        // Build physically attached sub-rooms (floorplan system)
        if (this.subRooms && this.subRooms.length > 0) {
            this.buildSubRooms();
        }
        
        // Dormant enemy in main room (lower chance than sub-rooms)
        // Always consume random calls for deterministic layout
        const mainEnemyRoll = Math.random();
        const mainTypes = this.archetype.enemyTypes || ['husk'];
        const mainEx = Phaser.Math.Between(L + 25, R - 25);
        const mainEy = Phaser.Math.Between(T + 30, B - 30);
        const mainEType = mainTypes[Math.floor(Math.random() * mainTypes.length)];
        const mainCleared = this.buildingId && BUILDING_STATE[this.buildingId] && BUILDING_STATE[this.buildingId].enemiesCleared;
        if (!mainCleared && mainEnemyRoll < (this.archetype.enemyChance || 0.3) * 0.5) {
            this.spawnDormantEnemy(mainEx, mainEy, mainEType);
        }
    }
    
    // Check if a Y position on a wall overlaps with any door (within clearance)
    wallClear(wall, y, clearance = 50) {
        const zones = this.doorZones[wall] || [];
        for (const doorY of zones) {
            if (Math.abs(y - doorY) < clearance) return false;
        }
        return true;
    }
    
    // Universal door blocking check — returns true if rect overlaps ANY door zone
    isBlockingDoor(px, py, pw, ph) {
        if (!this._allDoorRects) return false;
        const hw = (pw || 20) / 2;
        const hh = (ph || 20) / 2;
        for (const dr of this._allDoorRects) {
            if (Math.abs(px - dr.x) < (hw + dr.hw) && Math.abs(py - dr.y) < (hh + dr.hh)) {
                return true;
            }
        }
        return false;
    }
    
    // Find a safe Y on a wall that doesn't overlap doors
    safeWallY(wall, preferredY, minY, maxY, clearance = 50) {
        if (this.wallClear(wall, preferredY, clearance)) return preferredY;
        // Try shifting up
        for (let offset = 30; offset < (maxY - minY); offset += 20) {
            if (preferredY - offset >= minY && this.wallClear(wall, preferredY - offset, clearance)) return preferredY - offset;
            if (preferredY + offset <= maxY && this.wallClear(wall, preferredY + offset, clearance)) return preferredY + offset;
        }
        return preferredY; // fallback
    }
    
    // ==================== ARCHETYPE LOOT HELPERS ====================
    
    // Pick loot items from archetype pool; category = 'common', 'uncommon', 'rare'
    pickLoot(count = 1, category = 'common') {
        const pool = this.archetype.lootPool;
        if (!pool) return [];
        const items = pool[category] || pool.common || ['Cloth'];
        const result = [];
        for (let i = 0; i < count; i++) {
            result.push(items[Math.floor(Math.random() * items.length)]);
        }
        return result;
    }
    
    // Context-specific loot overrides (by room function)
    contextLoot(roomType, count = 2) {
        const pools = {
            kitchen: ['Ration', 'Ration', 'Cloth', 'Power Ammo'],
            bathroom: ['Bandage', 'Bandage', 'Cloth'],
            bedroom: ['Cloth', 'Cloth', 'Bandage', 'Power Ammo'],
            office: ['Scrap Metal', 'Wire', 'Cloth', 'Power Ammo'],
            storage: ['Power Ammo', 'Power Ammo', 'Scrap Metal', 'Wire', 'Cloth'],
            store: ['Ration', 'Bandage', 'Scrap Metal', 'Power Ammo'],
            pharmacy: ['Bandage', 'Bandage', 'Bandage', 'Ration', 'Power Ammo'],
            warehouse: ['Power Ammo', 'Power Ammo', 'Scrap Metal', 'Wire', 'Wire'],
            garage: ['Scrap Metal', 'Scrap Metal', 'Wire', 'Power Ammo', 'Power Ammo'],
            shelter: ['Cloth', 'Scrap Metal', 'Ration', 'Power Ammo'],
            armory: ['Power Ammo', 'Power Ammo', 'Power Ammo', 'Scrap Metal', 'Wire']
        };
        const pool = pools[roomType] || pools.store;
        const result = [];
        for (let i = 0; i < count; i++) {
            result.push(pool[Math.floor(Math.random() * pool.length)]);
        }
        return result;
    }
    
    // ==================== INTERIOR COMBAT SYSTEM ====================
    
    setupInteriorCombat() {
        if (!this.player || !this.player.body) {
            console.error('VESTIGE: setupInteriorCombat called without player');
            return;
        }
        
        // Combat state
        this.canShoot = true;
        this.canMelee = true;
        this.aimAngle = 0;
        this.target = null;
        this.lockedTarget = null;
        this._stunned = false;
        this.dormantEnemies = this.dormantEnemies || [];
        this.hazards = [];
        this._reloading = false;
        this._eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        
        // Magazine state — load from equipped weapon
        const eqStats = ItemManager.getEquippedStats(this.state);
        this._magazineMax = eqStats.mag || 10;
        this._magazine = (this.state._magazine !== undefined && this.state._magazine !== null) ? this.state._magazine : this._magazineMax;
        // Reload stat (1-100): 1=slow(3s), 50=medium(1.5s), 100=fast(0.5s) + survivor mark modifier
        const _baseReloadI = Math.max(500, 3000 - (eqStats.reload || 50) * 25);
        const _reloadModI = this.state.survivorMods?.reloadSpeed || 0;
        this._reloadTime = Math.max(300, Math.round(_baseReloadI * (1 - _reloadModI)));
        
        // Physics groups
        this.enemies = this.physics.add.group();
        this.bullets = this.physics.add.group();
        
        // Bullet texture generated per-foundry by CombatSystem.shoot()
        // (no generic 'bullet' texture needed)
        
        // Reticle — live graphics for clean transparency
        this.reticle = this.add.graphics().setVisible(false).setDepth(60).setAlpha(0.8);
        this.reticle._drawCrosshair = function(tintColor) {
            this.clear();
            const s = 12;
            const c = tintColor || 0xccbbaa;
            this.lineStyle(1.5, c, 0.9);
            // Corner brackets
            this.beginPath(); this.moveTo(-s, -s); this.lineTo(-s, -s + 5); this.strokePath();
            this.beginPath(); this.moveTo(-s, -s); this.lineTo(-s + 5, -s); this.strokePath();
            this.beginPath(); this.moveTo(s, -s); this.lineTo(s, -s + 5); this.strokePath();
            this.beginPath(); this.moveTo(s, -s); this.lineTo(s - 5, -s); this.strokePath();
            this.beginPath(); this.moveTo(-s, s); this.lineTo(-s, s - 5); this.strokePath();
            this.beginPath(); this.moveTo(-s, s); this.lineTo(-s + 5, s); this.strokePath();
            this.beginPath(); this.moveTo(s, s); this.lineTo(s, s - 5); this.strokePath();
            this.beginPath(); this.moveTo(s, s); this.lineTo(s - 5, s); this.strokePath();
            this.fillStyle(c, 0.5);
            this.fillCircle(0, 0, 1.5);
        };
        this.reticle._drawCrosshair();
        
        // Collisions
        this.physics.add.collider(this.enemies, this.walls);
        this.physics.add.collider(this.enemies, this.enemies);
        this.physics.add.collider(this.bullets, this.walls, (b) => { this.intBulletSpark(b.x, b.y, b.rotation, b.fx); b.destroy(); });
        this.physics.add.overlap(this.bullets, this.enemies, (b, e) => {
            if (!b.active || !e.active) return;
            this.intBulletSpark(b.x, b.y, b.rotation, b.fx);
            const dmg = b.damage || CONFIG.player.gunDamage;
            // Pierce: probability-based punch-through
            const doPierce = (b.pierceLeft && b.pierceLeft > 0) || (b.pierceChance && Math.random() < b.pierceChance);
            if (doPierce) {
                if (!b._hitEnemies) b._hitEnemies = new Set();
                if (b._hitEnemies.has(e)) return;
                b._hitEnemies.add(e);
                if (b.pierceLeft > 0) b.pierceLeft--;
            } else {
                b.destroy();
            }
            this.intDamageEnemy(e, dmg, 'bullet', b);
            
            // === T5/T6 BULLET-HIT SIGNATURE EFFECTS ===
            const bSigs = b._sigs || [];
            const ricochet = bSigs.find(s => s.effect === 'ricochet');
            if (ricochet && !b._ricochetDone) {
                b._ricochetDone = true;
                SignatureEffects.doRicochet(this, b, e, dmg, ricochet);
            }
            if (b._isFirepower && e.active) {
                DOTManager.apply(this, e, 'burn', 15, 5000, 'firepower');
            }
            if (b._isParasitic && e.active) {
                SignatureEffects.consumeParasiticRound(this, this.state, e);
            }
        });
        
        // Enemy contact damage
        this.physics.add.overlap(this.player, this.enemies, (p, e) => {
            if (e._attackCooldown || !e.active) return;
            e._attackCooldown = true;
            const cfg = CONFIG.enemyTypes[e.enemyType] || CONFIG.enemyTypes.husk;
            let dmg = Math.round((cfg.damage || 10) * (e._dmgMult || 1));
            
            // Armor + resist reduction
            const intEq = this._eqStats || ItemManager.getEquipmentStats(this.state.equipment);
            const intDodge = intEq.dodgeChance || 0;
            if (intDodge > 0 && Math.random() * 100 < intDodge) {
                this.player.setAlpha(0.3);
                this.time.delayedCall(200, () => { if (this.player.active) this.player.setAlpha(1); });
                Blurbs.show(this, this.player, 'DODGE', { color: '#66ccff', fontSize: 11, duration: 400 });
                this.time.delayedCall(cfg.attackCooldown || 800, () => { if (e.active) e._attackCooldown = false; });
                return;
            }
            // Phantom Step / Phased Stride mark dodge
            const _isPConds = this.state.survivorMods?.conditionals;
            const _isPDodge = (_isPConds?.phantomDodgeChance || 0) + (this.player.body && this.player.body.velocity.length() > 10 ? (_isPConds?.phasedDodgeChance || 0) : 0);
            if (_isPDodge > 0 && Math.random() < _isPDodge) {
                this.player.setAlpha(0.3);
                this.time.delayedCall(200, () => { if (this.player.active) this.player.setAlpha(1); });
                Blurbs.show(this, this.player, 'PHANTOM', { color: '#aa88ff', fontSize: 11, duration: 400 });
                this.time.delayedCall(cfg.attackCooldown || 800, () => { if (e.active) e._attackCooldown = false; });
                return;
            }
            // Temp armor
            if (this._tempArmor && this._tempArmor > 0) {
                const absorbed = Math.min(this._tempArmor, dmg);
                this._tempArmor -= absorbed;
                dmg -= absorbed;
            }
            if (intEq.armor > 0) dmg = Math.max(1, Math.round(dmg * (1 - intEq.armor / 100)));
            if (intEq.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - intEq.damageResist / 100)));
            // Survivor mark damage resistance
            const _isMods = this.state.survivorMods;
            if (_isMods && _isMods.damageResist > 0) dmg = Math.max(1, Math.round(dmg * (1 - _isMods.damageResist)));
            // Threshold mark: dynamic resist
            const _isConds = _isMods?.conditionals;
            if (_isConds && _isConds.thresholdHigh) {
                const _isMaxHP = CONFIG.player.health + (intEq.maxHealth || 0);
                const _isRatio = this.state.health / _isMaxHP;
                const _isThreshR = _isRatio < _isConds.thresholdHigh ? _isConds.thresholdResistBelow : _isConds.thresholdResistAbove;
                if (_isThreshR) dmg = Math.max(1, Math.round(dmg * (1 - _isThreshR)));
            }
            // Fracture Point / Resonant Break: first hit extra dmg
            if (_isConds && _isConds.firstHitMultiplier && !this._firstHitTaken) {
                this._firstHitTaken = true;
                dmg = Math.max(1, Math.round(dmg * _isConds.firstHitMultiplier));
                Blurbs.show(this, this.player, 'FRACTURE', { color: '#ff6644', fontSize: 10, duration: 500 });
            }
            
            // Blood Pact
            if (this._bloodPactResist && this._bloodPactResist > 0) {
                dmg = Math.max(1, Math.round(dmg * (1 - this._bloodPactResist / 100)));
            }
            // Hardened: post-dodge damage reduction
            if (this._hardenedActive && this._hardenedReduction) {
                dmg = Math.max(1, Math.round(dmg * (1 - this._hardenedReduction)));
            }
            // Sheltered
            if (this._shelteredActive) {
                dmg = Math.max(1, Math.round(dmg * 0.8));
            }
            
            this.state.health = Math.max(0, this.state.health - dmg);
            SignatureEffects.buildBloodPactStack(this);
            this.player.setTint(0xff0000);
            this.time.delayedCall(150, () => { if (this.player.active) _restoreTint(this.player); });
            const dt = this.add.text(this.player.x, this.player.y - 20, `-${dmg}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#ff4444', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: dt, y: dt.y - 25, alpha: 0, duration: 600, onComplete: () => dt.destroy() });
            const ka = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
            this.player.setVelocity(Math.cos(ka) * 150, Math.sin(ka) * 150);
            this.time.delayedCall(cfg.attackCooldown || 1000, () => { if (e.active) e._attackCooldown = false; });
            
            // Last Stand: survive lethal hit once
            if (this.state.health <= 0) {
                const intSigs = intEq.signatures || [];
                const lastStand = intSigs.find(s => s.effect === 'lastStand');
                if (lastStand && !this._lastStandUsed) {
                    this._lastStandUsed = true;
                    this.state.health = 1;
                    this.cameras.main.flash(300, 255, 50, 50);
                    const ls = this.add.text(this.player.x, this.player.y - 30, 'LAST STAND', {
                        fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#ff2244', fontStyle: 'bold'
                    }).setOrigin(0.5).setDepth(35);
                    this.tweens.add({ targets: ls, y: ls.y - 30, alpha: 0, duration: 1200, onComplete: () => ls.destroy() });
                    return;
                }
                this.interiorDeath();
            }
        });
        
        // Spawn active enemies & hazards ONLY on first visit — never respawn
        if (!this.isSubRoom && this._isFirstVisit) {
            this.spawnInteriorEnemies();
            this.spawnHazards();
        }
    }
    
    // ---- ENEMY SPAWNING ----
    
    spawnInteriorEnemies() {
        const biome = CONFIG.currentBiome?.type || 'grassy';
        const danger = {
            grassy:      { chance: 0.30, countMult: 0.7, hpMult: 0.8 },
            barren:      { chance: 0.50, countMult: 1.0, hpMult: 1.0 },
            apocalyptic: { chance: 0.70, countMult: 1.3, hpMult: 1.3 }
        }[biome] || { chance: 0.4, countMult: 1.0, hpMult: 1.0 };
        
        // Roll — some buildings are completely clear
        if (Math.random() > danger.chance) {
            // Safe building — show hint
            this.time.delayedCall(400, () => {
                const safe = this.add.text(CONFIG.width/2, CONFIG.height/2 - 50, '... quiet', {
                    fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#666666'
                }).setOrigin(0.5).setScrollFactor(0).setDepth(200).setAlpha(0);
                this.tweens.add({ targets: safe, alpha: 0.6, duration: 600, yoyo: true, hold: 800, onComplete: () => safe.destroy() });
            });
            return;
        }
        
        // Entry warning
        this.time.delayedCall(200, () => {
            const warn = this.add.text(CONFIG.width/2, CONFIG.height/2 - 50, 'You hear movement...', {
                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#aa6644', fontStyle: 'bold'
            }).setOrigin(0.5).setScrollFactor(0).setDepth(7.5);
            this.tweens.add({ targets: warn, alpha: 0, y: warn.y - 20, duration: 2000, onComplete: () => warn.destroy() });
        });
        
        const [minE, maxE] = this.archetype.enemyCount || [1, 2];
        const count = Math.max(1, Math.round(Phaser.Math.Between(minE, maxE) * danger.countMult));
        const types = this.archetype.enemyTypes || ['husk'];
        const cx = this.mainCX;
        const cy = this.mainCY;
        const w = this.interiorW;
        const h = this.interiorH;
        const pad = 40;
        
        for (let i = 0; i < count; i++) {
            // Spawn in upper/middle area (away from entrance at bottom)
            // Try multiple positions to avoid furniture/walls
            let ex, ey, validPos = false;
            for (let attempt = 0; attempt < 8; attempt++) {
                ex = cx + Phaser.Math.Between(-w/2 + pad, w/2 - pad);
                ey = cy + Phaser.Math.Between(-h/2 + pad, h/5);
                // Check against placed furniture
                let blocked = false;
                if (this._placedFurniture) {
                    for (const f of this._placedFurniture) {
                        if (Math.abs(f.x - ex) < 25 && Math.abs(f.y - ey) < 25) { blocked = true; break; }
                    }
                }
                // Check against door zones
                if (!blocked && this.interiorDoors) {
                    for (const d of this.interiorDoors) {
                        if (Math.abs(d.x - ex) < 30 && Math.abs(d.y - ey) < 30) { blocked = true; break; }
                    }
                }
                if (!blocked) { validPos = true; break; }
            }
            if (!validPos) {
                ex = cx + Phaser.Math.Between(-w/2 + pad, w/2 - pad);
                ey = cy + Phaser.Math.Between(-h/2 + pad, h/5);
            }
            const type = types[Math.floor(Math.random() * types.length)];
            this.spawnInteriorEnemy(ex, ey, type, danger.hpMult);
        }
    }
    
    spawnInteriorEnemy(x, y, type = 'husk', hpMult = 1.0) {
        const cfg = CONFIG.enemyTypes[type];
        if (!cfg) return;
        
        SpriteManager.buildEnemySheet(this, type);
        const sheetKey = 'enemy_' + type + '_sheet';
        const hasSheet = this.textures.exists(sheetKey);
        if (!hasSheet) SpriteManager.getTexture(this, 'enemy_' + type);
        
        const e = this.physics.add.sprite(x, y, hasSheet ? sheetKey : ('enemy_' + type));
        e.setDisplaySize(cfg.size, cfg.size).setDepth(20);
        e.enemyType = type;
        e.hasAnimSheet = hasSheet;
        e.hp = Math.floor(cfg.health * hpMult);
        e.maxHp = e.hp;
        e.setCollideWorldBounds(true);
        e._attackCooldown = false;
        
        if (hasSheet) {
            const idleKey = `enemy_${type}_idle`;
            if (this.anims.exists(idleKey)) e.anims.play(idleKey, true);
        }
        
        // Interior AI
        e.aiState = 'idle';
        e.patrolCenter = { x, y };
        e.patrolTarget = { x: x + Phaser.Math.Between(-30, 30), y: y + Phaser.Math.Between(-20, 20) };
        e.alertTimer = 0;
        
        e.setAlpha(0).setScale(0.5);
        this.tweens.add({ targets: e, alpha: 1, scale: 1, duration: 400 });
        this.enemies.add(e);
        DynamicShadows.add(this, e, { offsetY: 6, scale: 0.5, alpha: 0.12, interior: true });
        
        // Shield roll — same as GameScene
        const shieldChance = (CONFIG.shieldConfig.spawnChance[type] || 0) * (1 + (this.state?.reach || 1) * 0.1);
        if (shieldChance > 0 && Math.random() < shieldChance) {
            const sc = CONFIG.shieldConfig;
            e.shieldHP = sc.baseHP + (this.state?.reach || 1) * sc.reachScale;
            e.shieldMaxHP = e.shieldHP;
            e.hasShield = true;
        }
    }
    
    // ---- ENEMY AI ----
    
    updateInteriorEnemies() {
        if (!this.enemies) return;
        
        this.enemies.getChildren().forEach(e => {
            if (!e.active) return;
            e.setDepth(10 + e.y * 0.05);
            
            const cfg = CONFIG.enemyTypes[e.enemyType] || CONFIG.enemyTypes.husk;
            const dist = Phaser.Math.Distance.Between(e.x, e.y, this.player.x, this.player.y);
            const sightRange = 130;
            
            // Sightline delay from gear
            const intEqStats = this._intEqStats || ItemManager.getEquipmentStats(this.state.equipment);
            const slDelay = (intEqStats.sightline || 0) / 10;
            
            if (dist < sightRange) {
                if (slDelay > 0 && !e._fullyAware) {
                    e._awarenessTimer = (e._awarenessTimer || 0) + 0.016;
                    if (e._awarenessTimer < slDelay) {
                        // Not yet aware — continue idle/patrol
                        if (e.aiState !== 'chase') {
                            const pt = e.patrolTarget;
                            const pd = Phaser.Math.Distance.Between(e.x, e.y, pt.x, pt.y);
                            if (pd < 5) { e.patrolTarget = { x: e.x + Phaser.Math.Between(-40, 40), y: e.y + Phaser.Math.Between(-40, 40) }; }
                            const pa = Phaser.Math.Angle.Between(e.x, e.y, pt.x, pt.y);
                            e.setVelocity(Math.cos(pa) * 15, Math.sin(pa) * 15);
                        }
                        return;
                    }
                    e._fullyAware = true;
                }
                e.aiState = 'chase';
                e.alertTimer = 3;
            } else if (e.alertTimer > 0) {
                e.alertTimer -= 0.016;
            } else {
                e.aiState = 'idle';
                e._awarenessTimer = 0;
                e._fullyAware = false;
            }
            
            if (e.aiState === 'chase') {
                const angle = Phaser.Math.Angle.Between(e.x, e.y, this.player.x, this.player.y);
                const speed = cfg.chaseSpeed || cfg.speed || 60;
                // Slow down indoors — tight quarters
                e.setVelocity(Math.cos(angle) * speed * 0.7, Math.sin(angle) * speed * 0.7);
                if (e.hasAnimSheet) {
                    const walkKey = `enemy_${e.enemyType}_walk`;
                    if (this.anims.exists(walkKey) && e.anims.currentAnim?.key !== walkKey) e.anims.play(walkKey, true);
                }
            } else {
                // Slow patrol
                const pt = e.patrolTarget;
                const pd = Phaser.Math.Distance.Between(e.x, e.y, pt.x, pt.y);
                if (pd < 5) {
                    e.setVelocity(0, 0);
                    e.patrolTarget = {
                        x: e.patrolCenter.x + Phaser.Math.Between(-30, 30),
                        y: e.patrolCenter.y + Phaser.Math.Between(-25, 25)
                    };
                } else {
                    const a = Phaser.Math.Angle.Between(e.x, e.y, pt.x, pt.y);
                    e.setVelocity(Math.cos(a) * 18, Math.sin(a) * 18);
                }
                if (e.hasAnimSheet) {
                    const idleKey = `enemy_${e.enemyType}_idle`;
                    if (this.anims.exists(idleKey) && e.anims.currentAnim?.key !== idleKey) e.anims.play(idleKey, true);
                }
            }
        });
    }
    
    // ---- TARGETING ----
    
    interiorFindTarget() {
        if (!this.enemies) return;
        const cam = this.cameras.main;
        const margin = 30;
        const onScreen = (e) => {
            const sx = e.x - cam.scrollX, sy = e.y - cam.scrollY;
            return sx >= -margin && sx <= CONFIG.width + margin && sy >= -margin && sy <= CONFIG.height + margin;
        };
        
        if (this.lockedTarget && this.lockedTarget.active && onScreen(this.lockedTarget)) {
            this.target = this.lockedTarget;
            return;
        }
        if (this.lockedTarget && (!this.lockedTarget.active || !onScreen(this.lockedTarget))) {
            this.lockedTarget = null;
        }
        
        this.target = null;
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        const range = 130 + (eqStats.targetRange || 1) * 30;
        let closest = range + 30;
        
        this.enemies.getChildren().forEach(e => {
            if (!e.active || !onScreen(e)) return;
            const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, e.x, e.y);
            if (d < closest) { closest = d; this.target = e; }
        });
        
        if (this.target && !this.lockedTarget) this.lockedTarget = this.target;
    }
    
    interiorUpdateAim() {
        if (this.target && this.target.active) {
            this.aimAngle = Phaser.Math.Angle.Between(this.player.x, this.player.y, this.target.x, this.target.y);
            const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, this.target.x, this.target.y);
            this.reticle.setPosition(this.target.x, this.target.y).setVisible(true);
            const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
            const mRange = Math.max(eqStats.meleeRange || 0, CONFIG.player.meleeRange);
            if (dist < mRange) {
                this.reticle._drawCrosshair(0xffaa44);
            } else {
                this.reticle._drawCrosshair(0xddccbb);
            }
            this.reticle.setScale(this.lockedTarget === this.target ? 1.2 : 1.0);
            this.reticle.setAlpha(this.lockedTarget === this.target ? 0.9 : 0.5);
            
            // Armed state — swap to armed texture when locked on and in gun range
            const shouldBeArmed = this.lockedTarget && this.lockedTarget.active && dist >= mRange;
            const wt = this.player.weaponType || 'pistol';
            const armedSheetKey = 'player_sheet_armed_' + wt;
            
            if (shouldBeArmed && this.textures.exists(armedSheetKey)) {
                if (!this.player._isArmedTexture) {
                    // Create armed walk animations if needed
                    if (!this.anims.exists(`player_armed_${wt}_down`)) {
                        const dirs = ['down','down_right','right','up_right','up','up_left','left','down_left'];
                        dirs.forEach((dir, i) => {
                            const key = `player_armed_${wt}_${dir}`;
                            if (!this.anims.exists(key)) {
                                this.anims.create({ key, frames: this.anims.generateFrameNumbers(armedSheetKey, { start: i*3, end: i*3+2 }), frameRate: 8, repeat: -1 });
                            }
                        });
                    }
                    this.player._isArmedTexture = true;
                    const dir = this.player.lastDir || 'down';
                    const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                    this.player.setTexture(armedSheetKey, frameMap[dir] || 0);
                    this.player.setDisplaySize(40, 40);
                    // Weapon leaves holster
                    if (this.player.backpack) {
                        SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                    }
                }
            } else if (this.player._isArmedTexture && !this.player._isMeleeSwinging) {
                this.player._isArmedTexture = false;
                const dir = this.player.lastDir || 'down';
                const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                this.player.setTexture('player_sheet', frameMap[dir] || 0);
                this.player.setDisplaySize(40, 40);
                // Weapon returns to holster
                if (this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
            }
        } else {
            this.reticle.setVisible(false);
            // Disarm when no target
            if (this.player._isArmedTexture && !this.player._isMeleeSwinging) {
                this.player._isArmedTexture = false;
                const dir = this.player.lastDir || 'down';
                const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                this.player.setTexture('player_sheet', frameMap[dir] || 0);
                this.player.setDisplaySize(40, 40);
                if (this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
            }
        }
    }
    
    // ---- SHOOTING ----
    
    interiorAutoShoot() {
        if (!this.canShoot || this._reloading) return;
        if (ConsumableSystem.isChanneling()) return;
        
        // Magazine check — auto-reload when empty
        if (this._magazine <= 0) {
            this._startReload();
            return;
        }
        
        const result = CombatSystem.shoot(this, {
            state: this.state,
            equipment: this.state.equipment,
            aimAngle: this.aimAngle,
            bullets: this.bullets,
            target: this.target,
            player: this.player,
            alertEnemies: true,
            dormantEnemies: this.dormantEnemies
        });
        
        if (!result) return;
        this._magazine--;
        this.canShoot = false;
        this.time.delayedCall(result.fireRate, () => this.canShoot = true);
        
        // Update ammo display with magazine info
        this._updateMagazineDisplay();
    }
    
    _startReload(blurbOverride) {
        if (this._reloading) return;
        this._reloading = true;
        this.canShoot = false;
        AudioManager.reload();
        
        // Player blurb — follows player via update loop
        const blurb = blurbOverride || 'Reloading';
        if (this.player) {
            this._reloadText = this.add.text(this.player.x, this.player.y - 25, blurb, {
                fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#ffcc44', align: 'center'
            }).setOrigin(0.5).setDepth(7.5);
        }
        
        // Notify HUD
        if (this._ammoHud) this._ammoHud.setReloading(true);
        
        this.time.delayedCall(this._reloadTime, () => {
            // Infinite regular ammo — just refill mag
            this._magazine = this._magazineMax;
            this._reloading = false;
            this.canShoot = true;
            if (this._reloadText) { this._reloadText.destroy(); this._reloadText = null; }
            if (this._ammoHud) this._ammoHud.setReloading(false);
            this._updateMagazineDisplay();
        });
    }
    
    _updateMagazineDisplay() {
        if (this._ammoHud) this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
    }
    
    // ---- MELEE ----
    
    interiorAutoMelee() {
        if (!this.canMelee) return;
        if (ConsumableSystem.isChanneling()) return;
        
        const self = this;
        const result = CombatSystem.melee(this, {
            state: this.state,
            equipment: this.state.equipment,
            player: this.player,
            enemies: this.enemies,
            onDamage: (e, dmg, src) => {
                const dealt = CombatSystem.damageEnemy(self, e, dmg, src, self.player, self.state, self.state.equipment);
                if (e.hp <= 0 && !e.hasShield) self.intKillEnemy(e);
                return dealt;
            }
        });
        
        if (!result) return;
        this.canMelee = false;
        this.time.delayedCall(result.cooldown, () => this.canMelee = true);
    }
    
    meleeSwing(baseAngle) {
        // Get melee type from equipment
        const meleeItem = this.state.equipment && this.state.equipment.melee;
        const meleeType = meleeItem ? (meleeItem.baseId || 'blade') : 'blade';
        
        // Map melee baseId to sheet type
        const sheetType = (meleeType === 'blunt') ? 'blunt' : (meleeType === 'heavy') ? 'heavy' : 'blade';
        const sheetKey = 'player_sheet_melee_' + sheetType;
        
        // Determine swing direction from angle
        const angleDeg = ((baseAngle * 180 / Math.PI) + 360) % 360;
        let dir;
        if (angleDeg >= 337.5 || angleDeg < 22.5) dir = 'right';
        else if (angleDeg < 67.5) dir = 'down_right';
        else if (angleDeg < 112.5) dir = 'down';
        else if (angleDeg < 157.5) dir = 'down_left';
        else if (angleDeg < 202.5) dir = 'left';
        else if (angleDeg < 247.5) dir = 'up_left';
        else if (angleDeg < 292.5) dir = 'up';
        else dir = 'up_right';
        
        const animKey = `player_melee_${sheetType}_${dir}`;
        
        // Play swing animation on the player sprite
        if (this.textures.exists(sheetKey) && this.anims.exists(animKey)) {
            const wasArmed = this.player._isArmedTexture;
            const prevTexture = wasArmed ? ('player_sheet_armed_' + (this.player.weaponType || 'pistol')) : 'player_sheet';
            
            this.player._isMeleeSwinging = true;
            this.player._meleeSwingAngle = baseAngle;
            this.player.setTexture(sheetKey);
            this.player.play(animKey);
            
            // Melee leaves holster
            if (this.player.backpack) {
                SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
            }
            
            // On animation complete, return to previous state
            this.player.once('animationcomplete', () => {
                this.player._isMeleeSwinging = false;
                const curDir = this.player.lastDir || 'down';
                const frameMap = { down:0, down_right:3, right:6, up_right:9, up:12, up_left:15, left:18, down_left:21 };
                this.player.setTexture(prevTexture, frameMap[curDir] || 0);
                this.player.setDisplaySize(40, 40);
                // Melee returns to holster
                if (this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
                // Resume walk anim if moving
                const prefix = wasArmed ? `player_armed_${this.player.weaponType || 'pistol'}_` : 'player_walk_';
                const walkKey = prefix + curDir;
                if (this.anims.exists(walkKey)) {
                    this.player.play(walkKey, true);
                }
            });
        } else {
            // Fallback arc line for missing sheets — still set flag for holster
            this.player._isMeleeSwinging = true;
            this.player._meleeSwingAngle = baseAngle;
            if (this.player.backpack) {
                SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
            }
            const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
            const mRange = Math.max(eqStats.meleeRange || 0, CONFIG.player.meleeRange);
            const mfxId = meleeItem && meleeItem.foundry ? meleeItem.foundry : 'scrap';
            const mfx = CONFIG.foundryMeleeFX[mfxId] || CONFIG.foundryMeleeFX.scrap;
            const arc = this.add.graphics().setDepth(25);
            arc.lineStyle(mfx.swingWidth, mfx.swingColor, 0.5);
            arc.beginPath();
            arc.arc(this.player.x, this.player.y, mRange * 0.8, baseAngle - 0.6, baseAngle + 0.6, false);
            arc.strokePath();
            arc.lineStyle(1, mfx.swingCore, 0.3);
            arc.beginPath();
            arc.arc(this.player.x, this.player.y, mRange * 0.8, baseAngle - 0.4, baseAngle + 0.4, false);
            arc.strokePath();
            this.tweens.add({ targets: arc, alpha: 0, duration: 100, onComplete: () => arc.destroy() });
            // Shake handled by CombatSystem.melee
            // Clear flag after swing duration
            this.time.delayedCall(200, () => {
                this.player._isMeleeSwinging = false;
                if (this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
            });
        }
    }
    
    // ---- DAMAGE & DEATH ----
    
    intBulletSpark(x, y, fromAngle, fx) {
        CombatSystem.spark(this, x, y, fromAngle, fx || null);
    }
    
    intDamageEnemy(enemy, dmg, source = 'bullet', bullet = null) {
        // Derive source from bullet data
        if (bullet) {
            if (bullet.didMiss) { source = 'miss'; dmg = 0; }
            else if (bullet.isRedCrit) source = 'redcrit';
            else if (bullet.isCrit) source = 'crit';
        }
        const dealt = CombatSystem.damageEnemy(this, enemy, dmg, source, this.player, this.state, this.state.equipment);
        if (enemy.hp <= 0 && !enemy.hasShield) this.intKillEnemy(enemy);
        return dealt;
    }
    
    intKillEnemy(enemy) {
        if (enemy._dying) return;
        enemy._dying = true;
        // Cleanup shield visuals
        DynamicShadows.remove(this, enemy);
        this.state.kills++;
        // Track kills on the weapon/melee that landed the killing blow
        const eq = this.state.equipment;
        if (enemy._lastDamageSource === 'melee') {
            if (eq?.melee) eq.melee.kills = (eq.melee.kills || 0) + 1;
        } else {
            if (eq?.weapon) eq.weapon.kills = (eq.weapon.kills || 0) + 1;
        }
        AudioManager.enemyDeath();
        EventBus.emit('enemyKill', { scene: this, enemy });
        
        // Track run stats via GameScene reference
        const gs = this.scene.get('GameScene');
        if (gs && gs._runStats) {
            gs._runStats.kills++;
            if (enemy._lastDamageSource === 'melee') gs._runStats.meleeKills++;
            else gs._runStats.rangedKills++;
        }
        
        // Clear lock if this was the locked target
        if (this.lockedTarget === enemy) this.lockedTarget = null;
        if (this.target === enemy) this.target = null;
        
        // Shared kill effects (signatures, VFX, blood)
        CombatSystem.applyKillEffects(this, enemy, this.player, this.state, this.state.equipment);
        
        // Loot drops — bits + chance for ammo/health
        const bits = Phaser.Math.Between(3, 10);
        this.state.bits += bits;
        const bt = this.add.text(enemy.x, enemy.y - 10, `+${bits} BITS`, {
            fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#aaccff'
        }).setOrigin(0.5).setDepth(7.5);
        this.tweens.add({ targets: bt, y: bt.y - 25, alpha: 0, duration: 600, onComplete: () => bt.destroy() });
        
        if (Math.random() < 0.50) {
            const ammo = Phaser.Math.Between(2, 5);
            this.state.powerAmmo = (this.state.powerAmmo || 0) + ammo;
            const at = this.add.text(enemy.x + 15, enemy.y - 10, `+${ammo} PWR`, {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#cc88ff'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: at, y: at.y - 25, alpha: 0, duration: 600, delay: 100, onComplete: () => at.destroy() });
        }
        
        if (Math.random() < 0.2) {
            const heal = Phaser.Math.Between(3, 8);
            this.state.health = Math.min(this.state.health + heal, CONFIG.player.health);
            const ht = this.add.text(enemy.x - 15, enemy.y - 10, `+${heal} HP`, {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#44ff44'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: ht, y: ht.y - 25, alpha: 0, duration: 600, delay: 150, onComplete: () => ht.destroy() });
        }
        
        // Final fade
        this.tweens.add({ targets: enemy, alpha: 0, duration: 100, onComplete: () => enemy.destroy() });
        
        // Check if building is now clear of all enemies
        const remainingActive = this.enemies.getChildren().filter(e => e.active).length;
        const remainingDormant = (this.dormantEnemies || []).filter(d => !d.isAwake && d.active).length;
        if (remainingActive === 0 && remainingDormant === 0 && this.buildingId) {
            if (!BUILDING_STATE[this.buildingId]) BUILDING_STATE[this.buildingId] = {};
            BUILDING_STATE[this.buildingId].enemiesCleared = true;
            BUILDING_STATE[this.buildingId].hazardsCleared = true;
            
            const ct = this.add.text(CONFIG.width/2, CONFIG.height/2 - 60, 'AREA CLEAR', {
                fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#55aa55', fontStyle: 'bold'
            }).setOrigin(0.5).setScrollFactor(0).setDepth(7.5);
            this.tweens.add({ targets: ct, alpha: 0, y: ct.y - 20, duration: 2000, onComplete: () => ct.destroy() });
        }
    }
    
    interiorDeath() {
        if (this._dying) return;
        this._dying = true;
        this.cameras.main.flash(500, 200, 50, 50);
        this.cameras.main.shake(300, 0.02);
        
        const dt = this.add.text(CONFIG.width/2, CONFIG.height/2, 'BARELY ESCAPED', {
            fontFamily: CONFIG.font, fontSize: uiPx(16), fill: '#ff4444', fontStyle: 'bold'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(300);
        
        this.state.health = 1;
        this.time.delayedCall(1200, () => {
            this._dying = false;
            this.exitBuilding();
        });
    }
    
    updateInteriorHUD() {
        const eqStats = ItemManager.getEquipmentStats(this.state.equipment);
        const maxHp = CONFIG.player.health + (eqStats.maxHealth || 0);
        if (this.hud) {
            this.hud.updateHP(this.state.health, maxHp);
        } else if (this.healthBar) {
            const hp = this.state.health / maxHp;
            this.healthBar.displayWidth = 106 * hp;
            this.healthBar.setFillStyle(hp > 0.5 ? 0x44aa44 : hp > 0.25 ? 0xaaaa44 : 0xaa4444);
        }
        if (this._ammoHud) this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
        if (this.bitsText) this.bitsText.setText(`${this.state.bits || 0}`);
        if (this.magText) this.magText.setText(`${this._magazineMax || 10}`);
    }
    
    spawnHazards() {
        const cx = this.mainCX, cy = this.mainCY;
        const w = this.interiorW, h = this.interiorH;
        
        // Industrial: toxic puddles
        if (this.archetypeName === 'industrial') {
            const puddleCount = Math.random() < 0.4 ? (Math.random() < 0.3 ? 2 : 1) : 0;
            for (let i = 0; i < puddleCount; i++) {
                this.createToxicPuddle(
                    cx + Phaser.Math.Between(-w/3, w/3),
                    cy + Phaser.Math.Between(-h/4, h/4)
                );
            }
        }
        
        // Ransacked: glass shards
        if (this.archetype.ambience === 'ransacked' || this.archetypeName === 'commercial') {
            if (Math.random() < 0.35) {
                this.createGlassShards(
                    cx + Phaser.Math.Between(-w/3, w/3),
                    cy + Phaser.Math.Between(-h/4, h/4)
                );
            }
        }
        
        // Tripwires near sub-room doors
        this.interiorDoors.forEach(door => {
            if (Math.random() < 0.2) this.createTripwire(door.x, door.y, door.wall);
        });
        
        // Weak floor in harsher biomes
        const biome = CONFIG.currentBiome?.type || 'grassy';
        if (biome !== 'grassy' && Math.random() < 0.2) {
            this.createWeakFloor(
                cx + Phaser.Math.Between(-w/4, w/4),
                cy + Phaser.Math.Between(-h/4, h/4)
            );
        }
    }
    
    createToxicPuddle(x, y) {
        const pw = Phaser.Math.Between(25, 45), ph = Phaser.Math.Between(15, 25);
        this.add.ellipse(x, y, pw, ph, 0x33aa33, 0.2).setDepth(1);
        this.add.ellipse(x - 3, y - 2, pw * 0.6, ph * 0.5, 0x55cc55, 0.12).setDepth(1.1);
        // Bubbles
        this.time.addEvent({
            delay: 1500 + Math.random() * 2000, loop: true, callback: () => {
                const bx = x + Phaser.Math.Between(-pw/3, pw/3);
                const by = y + Phaser.Math.Between(-ph/3, ph/3);
                const bubble = this.add.circle(bx, by, 2, 0x55cc55, 0.35).setDepth(1.2);
                this.tweens.add({ targets: bubble, y: by - 8, alpha: 0, scale: 1.5, duration: 600, onComplete: () => bubble.destroy() });
            }
        });
        const zone = this.add.zone(x, y, pw, ph);
        this.physics.add.existing(zone, true);
        const haz = { type: 'toxic', zone, cooldown: false };
        this.hazards.push(haz);
        this.physics.add.overlap(this.player, zone, () => {
            if (haz.cooldown) return;
            haz.cooldown = true;
            this.state.health = Math.max(0, this.state.health - 3);
            this.player.setTint(0x44ff44);
            this.time.delayedCall(200, () => { if (this.player.active) _restoreTint(this.player); });
            const dt = this.add.text(this.player.x, this.player.y - 15, '-3 DMG', {
                fontFamily: CONFIG.font, fontSize: uiPx(10), fill: '#44ff44'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: dt, y: dt.y - 20, alpha: 0, duration: 500, onComplete: () => dt.destroy() });
            this.time.delayedCall(800, () => { haz.cooldown = false; });
            if (this.state.health <= 0) this.interiorDeath();
        });
    }
    
    createGlassShards(x, y) {
        for (let i = 0; i < 6; i++) {
            const sx = x + Phaser.Math.Between(-14, 14), sy = y + Phaser.Math.Between(-10, 10);
            this.add.triangle(sx, sy, 0, 0,
                Phaser.Math.Between(3, 6), 0,
                Phaser.Math.Between(1, 4), Phaser.Math.Between(3, 6),
                0x88aacc, 0.25
            ).setAngle(Phaser.Math.Between(0, 360)).setDepth(1.1);
        }
        const zone = this.add.zone(x, y, 30, 22);
        this.physics.add.existing(zone, true);
        const haz = { type: 'glass', zone, triggered: false };
        this.hazards.push(haz);
        this.physics.add.overlap(this.player, zone, () => {
            if (haz.triggered) return;
            haz.triggered = true;
            this.state.health = Math.max(0, this.state.health - 2);
            const ct = this.add.text(this.player.x, this.player.y - 15, 'CRUNCH!', {
                fontFamily: CONFIG.font, fontSize: uiPx(9), fill: '#aabbcc'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: ct, y: ct.y - 20, alpha: 0, duration: 800, onComplete: () => ct.destroy() });
            // Alert enemies
            this.enemies.getChildren().forEach(e => {
                if (e.active) { e.aiState = 'chase'; e.alertTimer = 4; }
            });
        });
    }
    
    createTripwire(x, y, wall) {
        const lineLen = 30;
        const lx = wall === 'left' ? x + 18 : x - 18;
        const line = this.add.rectangle(lx, y, lineLen, 1.5, 0xaa4444, 0.3).setDepth(2);
        this.add.rectangle(lx - lineLen/2, y, 2, 6, 0x5a5a5a, 0.4).setDepth(2);
        this.add.rectangle(lx + lineLen/2, y, 2, 6, 0x5a5a5a, 0.4).setDepth(2);
        
        const zone = this.add.zone(lx, y, lineLen, 12);
        this.physics.add.existing(zone, true);
        const haz = { type: 'tripwire', zone, triggered: false };
        this.hazards.push(haz);
        this.physics.add.overlap(this.player, zone, () => {
            if (haz.triggered) return;
            haz.triggered = true;
            this.state.health = Math.max(0, this.state.health - 5);
            this.cameras.main.shake(150, 0.008);
            line.setAlpha(0);
            this.player.setVelocity(0, 0);
            const st = this.add.text(this.player.x, this.player.y - 20, 'TRIPWIRE!', {
                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#ff6644', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: st, y: st.y - 25, alpha: 0, duration: 1200, onComplete: () => st.destroy() });
            this.enemies.getChildren().forEach(e => {
                if (e.active) { e.aiState = 'chase'; e.alertTimer = 8; }
            });
            this._stunned = true;
            this.time.delayedCall(400, () => { this._stunned = false; });
            if (this.state.health <= 0) this.interiorDeath();
        });
    }
    
    createWeakFloor(x, y) {
        const fw = Phaser.Math.Between(30, 50), fh = Phaser.Math.Between(25, 40);
        const patch = this.add.rectangle(x, y, fw, fh, 0x1a1a18, 0.25).setDepth(0.9);
        for (let i = 0; i < 3; i++) {
            const g = this.add.graphics().setDepth(1);
            g.lineStyle(1, 0x333330, 0.35);
            const cx2 = x + Phaser.Math.Between(-fw/3, fw/3);
            const cy2 = y + Phaser.Math.Between(-fh/3, fh/3);
            g.beginPath();
            g.moveTo(cx2, cy2);
            g.lineTo(cx2 + Phaser.Math.Between(-10, 10), cy2 + Phaser.Math.Between(-8, 8));
            g.strokePath();
        }
        const zone = this.add.zone(x, y, fw, fh);
        this.physics.add.existing(zone, true);
        const haz = { type: 'weakfloor', zone, triggered: false };
        this.hazards.push(haz);
        this.physics.add.overlap(this.player, zone, () => {
            if (haz.triggered) return;
            haz.triggered = true;
            this.cameras.main.shake(300, 0.015);
            patch.setFillStyle(0x0a0a08, 0.5);
            this.state.health = Math.max(0, this.state.health - 8);
            const ft = this.add.text(this.player.x, this.player.y - 20, 'FLOOR COLLAPSE!', {
                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: '#ffaa44', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: ft, y: ft.y - 25, alpha: 0, duration: 1500, onComplete: () => ft.destroy() });
            this._stunned = true;
            this.time.delayedCall(600, () => { this._stunned = false; });
            if (this.state.health <= 0) this.interiorDeath();
        });
    }
    
    // ==================== DORMANT ENEMIES (VARIETY POSES) ====================
    
    spawnDormantEnemy(x, y, type = 'husk') {
        if (!this.dormantEnemies) this.dormantEnemies = [];
        
        const poses = ['prone', 'slumped', 'crouched'];
        const pose = poses[Math.floor(Math.random() * poses.length)];
        
        const enemy = this.add.container(x, y).setDepth(10 + y * 0.05);
        
        const palette = {
            crawler: { body: 0x6a4a4a, skin: 0x8a5a5a, accent: 0x553333, cube: 0xaa4444 },
            walker:  { body: 0x5a5a4a, skin: 0x7a7a5a, accent: 0x444433, cube: 0xaaaa44 },
            sprinter:{ body: 0x4a4a6a, skin: 0x5a5a8a, accent: 0x333355, cube: 0x4488cc },
            deadlock:   { body: 0x4a5a4a, skin: 0x5a7a5a, accent: 0x334433, cube: 0x44aa44 }
        }[type] || { body: 0x5a4a4a, skin: 0x7a5a5a, accent: 0x443333, cube: 0xaa5544 };
        
        // Shadow
        enemy.add(this.add.ellipse(0, pose === 'slumped' ? 12 : 10, pose === 'prone' ? 32 : 24, 8, 0x000000, 0.1));
        
        if (pose === 'prone') {
            // Lying face down — reaching forward
            enemy.add(this.add.rectangle(0, 0, 18, 10, palette.body).setAngle(-8));
            enemy.add(this.add.rectangle(0, 2, 16, 3, palette.accent, 0.5).setAngle(-8));
            enemy.add(this.add.rectangle(12, -3, 8, 7, palette.skin));
            enemy.add(this.add.rectangle(14, -3, 3, 3, palette.accent, 0.6));
            enemy.add(this.add.rectangle(6, -7, 10, 3, palette.skin, 0.8).setAngle(-25));
            enemy.add(this.add.rectangle(-6, 5, 8, 3, palette.skin, 0.6).setAngle(15));
            enemy.add(this.add.rectangle(-10, 4, 12, 3, palette.body, 0.8).setAngle(10));
            enemy.add(this.add.rectangle(-10, -2, 11, 3, palette.body, 0.7).setAngle(-5));
        } else if (pose === 'slumped') {
            // Sitting against wall, head drooped
            enemy.add(this.add.rectangle(0, -2, 12, 16, palette.body));
            enemy.add(this.add.rectangle(0, 0, 10, 4, palette.accent, 0.4));
            enemy.add(this.add.circle(0, -12, 5, palette.skin));
            enemy.add(this.add.circle(1, -11, 3, palette.accent, 0.4));
            enemy.add(this.add.rectangle(-7, 3, 10, 3, palette.skin, 0.7).setAngle(40));
            enemy.add(this.add.rectangle(7, 3, 9, 3, palette.skin, 0.6).setAngle(-30));
            enemy.add(this.add.rectangle(-5, 10, 14, 3, palette.body, 0.7).setAngle(5));
            enemy.add(this.add.rectangle(5, 10, 14, 3, palette.body, 0.6).setAngle(-5));
        } else {
            // Crouched — hunched, knees up
            enemy.add(this.add.rectangle(0, 0, 14, 12, palette.body));
            enemy.add(this.add.circle(0, -8, 5, palette.skin));
            enemy.add(this.add.circle(0, -8, 3, palette.accent, 0.3));
            enemy.add(this.add.rectangle(-6, -2, 8, 3, palette.body, 0.7).setAngle(55));
            enemy.add(this.add.rectangle(6, -2, 8, 3, palette.body, 0.7).setAngle(-55));
            enemy.add(this.add.rectangle(0, -4, 6, 5, palette.skin, 0.4));
        }
        
        // Subtle breathing
        this.tweens.add({
            targets: enemy, scaleY: 1.02,
            duration: 1800 + Math.random() * 800,
            yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
        });
        
        enemy.isAwake = false;
        enemy.enemyType = type;
        enemy.aggroRange = pose === 'crouched' ? 35 : 45;
        enemy.palette = palette;
        enemy.pose = pose;
        
        this.dormantEnemies.push(enemy);
    }
    
    updateDormantEnemies() {
        if (!this.dormantEnemies || this.dormantEnemies.length === 0) return;
        
        for (let i = this.dormantEnemies.length - 1; i >= 0; i--) {
            const enemy = this.dormantEnemies[i];
            if (enemy.isAwake || !enemy.active) continue;
            
            const dist = Phaser.Math.Distance.Between(this.player.x, this.player.y, enemy.x, enemy.y);
            if (dist < enemy.aggroRange) {
                enemy.isAwake = true;
                this.triggerDormantEnemy(enemy, i);
            }
        }
    }
    
    triggerDormantEnemy(enemy, index) {
        this.cameras.main.shake(250, 0.01);
        
        // Ambush damage — skip if player has i-frames
        if (!this.isInvincible) {
            const dmg = Phaser.Math.Between(5, 12);
            this.state.health = Math.max(0, this.state.health - dmg);
        
            // Update health bar
            const healthPct = this.state.health / CONFIG.player.health;
            if (this.healthBar) {
                this.healthBar.displayWidth = 106 * healthPct;
                this.healthBar.setFillStyle(healthPct > 0.5 ? 0x44aa44 : healthPct > 0.25 ? 0xaaaa44 : 0xaa4444);
            }
        
            // Damage number
            const dmgText = this.add.text(enemy.x, enemy.y - 20, `-${dmg}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#ff4444', fontStyle: 'bold'
            }).setOrigin(0.5).setDepth(7.5);
            this.tweens.add({ targets: dmgText, y: dmgText.y - 30, alpha: 0, duration: 800, onComplete: () => dmgText.destroy() });
        }
        
        // Alert text
        const alertMsg = enemy.pose === 'crouched' ? 'LURKER!' :
                         enemy.pose === 'slumped' ? 'AMBUSH!' : 'AMBUSH!';
        const alertText = this.add.text(CONFIG.width/2, CONFIG.height/2 - 40, alertMsg, {
            fontFamily: CONFIG.font, fontSize: uiPx(14), fill: '#ff6644', fontStyle: 'bold'
        }).setOrigin(0.5).setScrollFactor(0).setDepth(7.5);
        this.tweens.add({ targets: alertText, alpha: 0, duration: 1500, onComplete: () => alertText.destroy() });
        
        // Cube shatter death
        const palette = enemy.palette || { cube: 0xaa4444, body: 0x5a4a4a };
        this.tweens.add({
            targets: enemy, scaleX: 1.2, scaleY: 1.3, duration: 150,
            onComplete: () => {
                const ex = enemy.x, ey = enemy.y;
                
                for (let i = 0; i < 8; i++) {
                    const cube = this.add.rectangle(
                        ex + Phaser.Math.Between(-6, 6), ey + Phaser.Math.Between(-6, 6),
                        Phaser.Math.Between(3, 6), Phaser.Math.Between(3, 6), palette.cube
                    ).setDepth(30).setAngle(Phaser.Math.Between(0, 45));
                    const a = Phaser.Math.Between(0, 360) * Math.PI / 180;
                    const spd = Phaser.Math.Between(30, 80);
                    this.tweens.add({
                        targets: cube,
                        x: cube.x + Math.cos(a) * spd, y: cube.y + Math.sin(a) * spd,
                        angle: cube.angle + Phaser.Math.Between(-180, 180),
                        alpha: 0, scale: 0.3,
                        duration: Phaser.Math.Between(250, 450), ease: 'Power2',
                        onComplete: () => cube.destroy()
                    });
                }
                
                for (let i = 0; i < 4; i++) {
                    const bl = this.add.rectangle(
                        ex + Phaser.Math.Between(-4, 4), ey + Phaser.Math.Between(-4, 4),
                        Phaser.Math.Between(2, 5), Phaser.Math.Between(2, 5), 0x880000
                    ).setDepth(29);
                    const ba = Phaser.Math.Between(0, 360) * Math.PI / 180;
                    const bd = Phaser.Math.Between(12, 30);
                    this.tweens.add({
                        targets: bl, x: bl.x + Math.cos(ba) * bd, y: bl.y + Math.sin(ba) * bd,
                        alpha: 0, duration: 500, onComplete: () => bl.destroy()
                    });
                }
                
                this.add.ellipse(ex, ey + 2, 16, 8, 0x550000, 0.25).setDepth(1);
                enemy.destroy();
            }
        });
        
        // Alert active enemies too
        if (this.enemies) {
            this.enemies.getChildren().forEach(e => {
                if (e.active) { e.aiState = 'chase'; e.alertTimer = 5; }
            });
        }
        
        this.dormantEnemies.splice(index, 1);
        if (this.state.health <= 0) this.interiorDeath();
        
        // Check if building is now clear
        const remainingActive = this.enemies ? this.enemies.getChildren().filter(e => e.active).length : 0;
        const remainingDormant = (this.dormantEnemies || []).filter(d => !d.isAwake && d.active).length;
        if (remainingActive === 0 && remainingDormant === 0 && this.buildingId) {
            if (!BUILDING_STATE[this.buildingId]) BUILDING_STATE[this.buildingId] = {};
            BUILDING_STATE[this.buildingId].enemiesCleared = true;
            BUILDING_STATE[this.buildingId].hazardsCleared = true;
            
            this.time.delayedCall(500, () => {
                const ct = this.add.text(CONFIG.width/2, CONFIG.height/2 - 60, 'AREA CLEAR', {
                    fontFamily: CONFIG.font, fontSize: uiPx(12), fill: '#55aa55', fontStyle: 'bold'
                }).setOrigin(0.5).setScrollFactor(0).setDepth(7.5);
                this.tweens.add({ targets: ct, alpha: 0, y: ct.y - 20, duration: 2000, onComplete: () => ct.destroy() });
            });
        }
    }
    
    // ==================== FLOOR AMBIENCE ====================
    
    // Scatter floor debris based on archetype ambience style
    scatterDebris(cx, cy, w, h, L, R, T, B) {
        const ambience = this.archetype.ambience || 'ransacked';
        const midX = cx;
        const midY = cy;
        
        if (ambience === 'lived_in') {
            // Scattered papers, small items
            for (let i = 0; i < 4; i++) {
                const px = Phaser.Math.Between(L + 15, R - 15);
                const py = Phaser.Math.Between(T + 15, B - 15);
                const pw = Phaser.Math.Between(4, 8);
                const ph = Phaser.Math.Between(3, 6);
                this.add.rectangle(px, py, pw, ph, 0x5a5550, 0.25).setDepth(1).setAngle(Phaser.Math.Between(-40, 40));
            }
            // Rug near center
            if (Math.random() < 0.5) {
                this.add.ellipse(midX + Phaser.Math.Between(-15, 15), midY + 10, Phaser.Math.Between(40, 60), Phaser.Math.Between(25, 35), 0x3a3530, 0.2).setDepth(1);
            }
        } else if (ambience === 'ransacked') {
            // Overturned items, broken glass, papers
            for (let i = 0; i < 6; i++) {
                const px = Phaser.Math.Between(L + 10, R - 10);
                const py = Phaser.Math.Between(T + 10, B - 10);
                const itemRoll = Math.random();
                if (itemRoll < 0.3) {
                    // Broken glass shards
                    this.add.triangle(px, py, 0, 0, Phaser.Math.Between(4, 8), 0, Phaser.Math.Between(2, 6), Phaser.Math.Between(4, 8), 0x6a8a8a, 0.2).setDepth(1).setAngle(Phaser.Math.Between(0, 360));
                } else if (itemRoll < 0.6) {
                    // Paper/debris
                    this.add.rectangle(px, py, Phaser.Math.Between(5, 10), Phaser.Math.Between(3, 7), 0x5a5a50, 0.2).setDepth(1).setAngle(Phaser.Math.Between(-45, 45));
                } else {
                    // Small debris chunk
                    this.add.rectangle(px, py, Phaser.Math.Between(3, 6), Phaser.Math.Between(2, 5), 0x3a3530, 0.3).setDepth(1).setAngle(Phaser.Math.Between(-30, 30));
                }
            }
        } else if (ambience === 'industrial') {
            // Oil stains, metal shavings
            for (let i = 0; i < 3; i++) {
                const ox = Phaser.Math.Between(L + 20, R - 20);
                const oy = Phaser.Math.Between(T + 20, B - 20);
                this.add.ellipse(ox, oy, Phaser.Math.Between(15, 30), Phaser.Math.Between(10, 20), 0x1a1a18, 0.2).setDepth(1);
            }
            // Metal shavings
            for (let i = 0; i < 5; i++) {
                const sx = Phaser.Math.Between(L + 10, R - 10);
                const sy = Phaser.Math.Between(T + 10, B - 10);
                this.add.rectangle(sx, sy, Phaser.Math.Between(2, 5), 1, 0x6a6a6a, 0.2).setDepth(1).setAngle(Phaser.Math.Between(0, 180));
            }
        } else if (ambience === 'institutional') {
            // Clean but worn — scuff marks, dust
            for (let i = 0; i < 3; i++) {
                const dx = Phaser.Math.Between(L + 15, R - 15);
                const dy = Phaser.Math.Between(T + 15, B - 15);
                this.add.ellipse(dx, dy, Phaser.Math.Between(12, 25), Phaser.Math.Between(8, 15), 0x2a2a28, 0.12).setDepth(1);
            }
        } else if (ambience === 'abandoned') {
            // Dust, cobwebs, fallen debris
            for (let i = 0; i < 4; i++) {
                const dx = Phaser.Math.Between(L + 10, R - 10);
                const dy = Phaser.Math.Between(T + 10, B - 10);
                this.add.ellipse(dx, dy, Phaser.Math.Between(10, 25), Phaser.Math.Between(6, 15), 0x3a3530, 0.15).setDepth(1);
            }
            // Corner cobweb (top-left or top-right)
            const webCorner = Math.random() < 0.5 ? L + 5 : R - 5;
            const gfx = this.add.graphics().setDepth(2);
            gfx.lineStyle(1, 0x5a5a5a, 0.15);
            for (let i = 0; i < 4; i++) {
                const ang = (Math.PI / 2) * (i / 4);
                gfx.lineBetween(webCorner, T + 5, webCorner + Math.cos(ang) * 20, T + 5 + Math.sin(ang) * 20);
            }
        }
    }
    
    // ==================== WALL-MOUNTED ISO FURNITURE ====================
    // These draw furniture flush against a wall with proper facing
    // 'wall' param: 'left', 'right', 'top' determines orientation
    
    // Shelf unit mounted on wall — proper iso side profile
    wallShelf(wall, x, y, lootItems) {
        if (this.isBlockingDoor(x, y, 40, 40)) return;
        // Redirect to createLootableFurniture with offset from wall edge
        if (wall === 'left') this.createLootableFurniture(x + 10, y, 'shelf', lootItems, 'left');
        else if (wall === 'right') this.createLootableFurniture(x - 10, y, 'shelf', lootItems, 'right');
        else this.createLootableFurniture(x, y + 12, 'shelf', lootItems, 'top');
    }
    
    wallCounter(wall, x, y, width) {
        if (this.isBlockingDoor(x, y, 50, 30)) return;
        if (wall === 'left') this.createLootableFurniture(x + 10, y, 'desk', null, 'left');
        else if (wall === 'right') this.createLootableFurniture(x - 10, y, 'desk', null, 'right');
        else this.createLootableFurniture(x, y + 10, 'desk', null, 'top');
    }
    
    wallFridge(wall, x, y, lootItems) {
        if (this.isBlockingDoor(x, y, 30, 40)) return;
        if (wall === 'left') this.createLootableFurniture(x + 10, y, 'fridge', lootItems, 'left');
        else if (wall === 'right') this.createLootableFurniture(x - 10, y, 'fridge', lootItems, 'right');
        else this.createLootableFurniture(x, y + 12, 'fridge', lootItems, 'top');
    }
    
    wallBed(wall, x, y, lootItems) {
        this.createLootableFurniture(x, y, 'bed', lootItems, wall || 'top');
    }
    
    wallTV(wall, x, y, lootItems) {
        this.createLootableFurniture(x, y, 'tv', lootItems, wall || 'top');
    }
    
    wallCouch(wall, x, y) {
        this.createLootableFurniture(x, y, 'couch', null, wall || 'top');
    }

    // Free-standing table — delegates to ISO_DEFS
    freeTable(x, y, tw, th, lootItems) {
        if (this.isBlockingDoor(x, y, tw || 30, th || 20)) return;
        if (this._placedFurniture && this._placedFurniture.some(f => Math.abs(f.x - x) < 30 && Math.abs(f.y - y) < 30)) return;
        const wallThresh = this._INTERIOR?.wallThresh || 25;
        let wall = 'top'; // default front-facing
        if (this._roomL && x - this._roomL < wallThresh) wall = 'left';
        else if (this._roomR && this._roomR - x < wallThresh) wall = 'right';
        else if (this._roomB && this._roomB - y < wallThresh) wall = 'bottom';
        this.createLootableFurniture(x, y, 'table', lootItems, wall);
    }
    
    // Free-standing crate — delegates to ISO_DEFS
    freeCrate(x, y, lootItems) {
        if (this.isBlockingDoor(x, y, 40, 40)) return;
        if (this._placedFurniture && this._placedFurniture.some(f => Math.abs(f.x - x) < 30 && Math.abs(f.y - y) < 30)) return;
        const wallThresh = this._INTERIOR?.wallThresh || 25;
        let wall = 'top'; // default front-facing
        if (this._roomL && x - this._roomL < wallThresh) wall = 'left';
        else if (this._roomR && this._roomR - x < wallThresh) wall = 'right';
        else if (this._roomB && this._roomB - y < wallThresh) wall = 'bottom';
        this.createLootableFurniture(x, y, 'crate', lootItems, wall);
    }
    
    // Free-standing barrel — delegates to ISO_DEFS
    freeBarrel(x, y, lootItems) {
        if (this.isBlockingDoor(x, y, 40, 40)) return;
        if (this._placedFurniture && this._placedFurniture.some(f => Math.abs(f.x - x) < 30 && Math.abs(f.y - y) < 30)) return;
        const wallThresh = this._INTERIOR?.wallThresh || 25;
        let wall = 'top'; // default front-facing
        if (this._roomL && x - this._roomL < wallThresh) wall = 'left';
        else if (this._roomR && this._roomR - x < wallThresh) wall = 'right';
        else if (this._roomB && this._roomB - y < wallThresh) wall = 'bottom';
        this.createLootableFurniture(x, y, 'barrel', lootItems, wall);
    }
    
    // Get a themed furniture label based on type and current location
    _getFurnitureLabel(type) {
        const locLabels = {
            pharmacy: { table: 'Counter', crate: 'Supply Box', barrel: 'Chemical Drum', bed: 'Cot', tv: 'Monitor', medicine_cabinet: 'Medicine Cabinet', exam_table: 'Exam Table', register: 'Register', shelf: 'Product Shelf', cabinet: 'Supply Cabinet' },
            police_station: { table: 'Desk', crate: 'Evidence Box', barrel: 'Drum', bed: 'Cot', tv: 'Security Monitor', gun_rack: 'Gun Rack', filing_cabinet: 'Filing Cabinet', desk: 'Officer\'s Desk', locker: 'Evidence Locker', register: 'Intake Terminal' },
            gas_station: { table: 'Counter', crate: 'Supply Crate', barrel: 'Fuel Drum', fuel_pump: 'Fuel Pump', register: 'Register', shelf: 'Product Shelf', fridge: 'Drink Cooler' },
            hardware_store: { table: 'Workbench', crate: 'Parts Crate', barrel: 'Paint Drum', workbench: 'Workbench', shelf: 'Tool Shelf', register: 'Register', toolrack: 'Tool Display' },
            grocery: { table: 'Display Table', crate: 'Produce Crate', barrel: 'Bin', display_case: 'Display Case', fridge: 'Refrigerator', register: 'Checkout', shelf: 'Aisle Shelf' },
            church: { table: 'Altar', crate: 'Donation Box', barrel: 'Font', altar: 'Altar', pew: 'Pew', shelf: 'Hymnal Shelf', cabinet: 'Vestry Cabinet' },
            school: { table: 'Teacher\'s Desk', crate: 'Supply Box', filing_cabinet: 'Supply Cabinet', vending_machine: 'Vending Machine', desk: 'Teacher\'s Desk', shelf: 'Book Shelf', chalkboard: 'Chalkboard' },
            research_lab: { table: 'Lab Bench', crate: 'Specimen Container', barrel: 'Waste Drum', tv: 'Terminal', medicine_cabinet: 'Specimen Cabinet', exam_table: 'Lab Table', register: 'Data Terminal', shelf: 'Equipment Rack' },
            bunker: { table: 'Field Table', crate: 'Ammo Crate', barrel: 'Water Barrel', tv: 'Comms Terminal', gun_rack: 'Weapons Locker', bunk_bed: 'Bunk Bed', filing_cabinet: 'Comms Panel', shelf: 'Supply Shelf' },
            motel: { table: 'Side Table', bed: 'Bed', tv: 'TV', vending_machine: 'Vending Machine', nightstand: 'Nightstand', cabinet: 'Wardrobe', dresser: 'Dresser' },
            diner: { table: 'Booth Table', crate: 'Supply Box', barrel: 'Grease Barrel', jukebox: 'Jukebox', register: 'Cash Register', shelf: 'Dish Shelf', fridge: 'Walk-in Cooler' },
            warehouse: { table: 'Work Surface', crate: 'Shipping Crate', barrel: 'Storage Drum', workbench: 'Work Station', shelf: 'Racking', toolrack: 'Tool Board' },
            auto_shop: { table: 'Workbench', crate: 'Parts Crate', barrel: 'Oil Drum', workbench: 'Mechanic\'s Bench', toolrack: 'Tool Wall', shelf: 'Parts Shelf' },
            apartment: { table: 'Coffee Table', bed: 'Bed', tv: 'TV', fridge: 'Fridge', nightstand: 'Nightstand', dresser: 'Dresser', cabinet: 'Wardrobe' },
            house: { table: 'Coffee Table', crate: 'Box', barrel: 'Rain Barrel', bed: 'Bed', tv: 'TV', fridge: 'Fridge', nightstand: 'Nightstand', desk: 'Desk' }
        };
        const defaults = {
            table: 'Table', crate: 'Crate', barrel: 'Barrel', bed: 'Bed', tv: 'TV',
            medicine_cabinet: 'Medicine Cabinet', gun_rack: 'Gun Rack', fuel_pump: 'Fuel Pump',
            jukebox: 'Jukebox', pew: 'Pew', exam_table: 'Exam Table', vending_machine: 'Vending Machine',
            filing_cabinet: 'Filing Cabinet', workbench: 'Workbench', display_case: 'Display Case',
            bunk_bed: 'Bunk Bed', altar: 'Altar', chalkboard: 'Chalkboard',
            register: 'Register', fridge: 'Fridge', shelf: 'Shelf', desk: 'Desk',
            nightstand: 'Nightstand', dresser: 'Dresser', locker: 'Locker',
            toolrack: 'Tool Rack', cabinet: 'Cabinet'
        };
        const locMap = this.locationType ? locLabels[this.locationType] : null;
        return (locMap && locMap[type]) || defaults[type] || 'Search';
    }
    
    genLivingRoom(cx, cy, w, h, L, R, T, B) {
        // Couch against left wall — shifted toward top to avoid door area
        const couchY = this.safeWallY('left', cy - 15, T + 30, B - 30);
        this.wallCouch('left', L, couchY);
        // TV on far wall center
        this.wallTV('top', cx - 20, T, Math.random() < 0.4 ? this.pickLoot(1) : null);
        // Bookshelf far right
        const shelfRY = this.safeWallY('right', T + 20, T + 15, B - 30);
        this.wallShelf('right', R, shelfRY, ['Cloth', 'Wire']);
        // Coffee table free-standing center
        this.freeTable(cx, cy + 10, 32, 20, Math.random() < 0.35 ? this.pickLoot(1) : null);
        // Kitchen cabinet right wall lower
        const fridgeY = this.safeWallY('right', cy + 25, T + 30, B - 15);
        this.wallFridge('right', R, fridgeY, this.contextLoot('kitchen', 2));
        // End table near couch
        this.createLootableFurniture(L + 28, couchY - 25, 'nightstand', this.contextLoot('bedroom', 1), 'left');
        // Rug
        this.add.ellipse(cx, cy + 5, 55, 35, 0x3a3535, 0.25).setDepth(1);
    }
    
    genStore(cx, cy, w, h, L, R, T, B) {
        // Counter along far wall
        this.wallCounter('top', cx, T, w * 0.5);
        // Register on counter
        this.createLootableFurniture(cx + 30, T + 14, 'register', this.contextLoot('store', 1), 'top');
        // Shelf aisle left wall
        const shelfLY = this.safeWallY('left', cy - 15, T + 20, B - 30);
        this.wallShelf('left', L, shelfLY, this.contextLoot('store', 2));
        // Shelf aisle right wall
        const shelfRY = this.safeWallY('right', cy - 15, T + 20, B - 30);
        this.wallShelf('right', R, shelfRY, this.contextLoot('store', 1));
        // Extra shelf on right if room is wide enough
        if (w > 180) {
            const shelfR2 = this.safeWallY('right', cy + 25, T + 20, B - 15);
            this.wallShelf('right', R, shelfR2, this.pickLoot(1, 'uncommon'));
        }
        // Floor mat at entrance
        this.add.rectangle(cx, B + 5, 40, 12, 0x3a3530, 0.35).setDepth(1);
    }
    
    genConvenienceStore(cx, cy, w, h, L, R, T, B) {
        // Counter with register (cashier's station near entrance)
        this.wallCounter('top', cx, T, w * 0.4);
        this.createLootableFurniture(cx - 15, T + 14, 'register', this.contextLoot('store', 1), 'top');
        // Cigarette/lottery display behind counter
        this.add.rectangle(cx + 10, T + 5, 14, 6, 0x3a3a3a, 0.3).setDepth(1);
        // Drink fridge on right wall (glass-front cooler)
        const fridgeY = this.safeWallY('right', cy - 10, T + 20, B - 20);
        this.createLootableFurniture(R - 12, fridgeY, 'fridge', this.contextLoot('store', 2), 'right');
        // Snack shelf left wall
        const shelfY = this.safeWallY('left', cy, T + 20, B - 20);
        this.createLootableFurniture(L + 12, shelfY, 'shelf', this.contextLoot('store', 1), 'left');
        // Magazine/candy rack near door
        this.createLootableFurniture(cx + 20, B - 15, 'shelf', this.pickLoot(1), 'bottom');
        // Floor mat at entrance (scuffed, dirty)
        this.add.rectangle(cx, B + 3, 30, 8, 0x3a3530, 0.2).setDepth(1);
        // Knocked-over chip display (post-Collapse)
        this.add.rectangle(cx - 20, cy + 15, 12, 3, 0x5a5a50, 0.2).setDepth(1.5).setAngle(15);
        this.add.rectangle(cx - 15, cy + 18, 6, 4, 0x6a5a3a, 0.12).setDepth(1.6);
        // Slurpee machine (decorative, broken)
        this.add.rectangle(cx + 25, T + 10, 10, 12, 0x4a4a5a, 0.25).setDepth(11);
        this.add.rectangle(cx + 25, T + 6, 8, 3, 0x5a5a6a, 0.2).setDepth(11.1);
    }
    
    genPharmacy(cx, cy, w, h, L, R, T, B) {
        // Behind the counter — medicine cabinet where staff accessed meds
        const cabY = this.safeWallY('right', cy - 15, T + 20, B - 20);
        this.createLootableFurniture(R - 12, cabY, 'medicine_cabinet', this.contextLoot('pharmacy', 2), 'right');
        // Counter dividing customer area from staff area
        this.freeTable(cx, cy - 5, w * 0.45, 14, null);
        // Register on counter (where customers paid)
        this.createLootableFurniture(cx + 15, cy - 18, 'register', this.contextLoot('store', 1), 'top');
        // Product shelves along far wall (what customers browsed)
        this.wallShelf('top', cx - 25, T, this.contextLoot('pharmacy', 2));
        this.wallShelf('top', cx + 25, T, this.contextLoot('store', 1));
        // Fallen shelf / scattered products (post-Collapse looting)
        this.add.rectangle(cx - 30, cy + 15, 18, 4, 0x5a4a3a, 0.3).setDepth(1.5).setAngle(12);
        this.add.rectangle(cx - 25, cy + 18, 6, 4, 0x6a5a5a, 0.25).setDepth(1.6);
        this.add.rectangle(cx - 35, cy + 20, 4, 3, 0x4a6a4a, 0.2).setDepth(1.6);
        // Waiting chairs along left wall
        const chairY = this.safeWallY('left', cy + 10, T + 20, B - 15);
        this.add.rectangle(L + 10, chairY, 10, 8, 0x4a4a5a, 0.4).setDepth(2);
        this.add.rectangle(L + 10, chairY - 5, 10, 3, 0x3a3a4a, 0.35).setDepth(2.1);
        this.add.rectangle(L + 22, chairY, 10, 8, 0x4a4a5a, 0.4).setDepth(2);
        // Floor stain (spilled pills/liquid)
        this.add.ellipse(cx + 5, cy + 10, 14, 8, 0x3a4a3a, 0.12).setDepth(1);
    }
    
    genWarehouse(cx, cy, w, h, L, R, T, B) {
        // Crate stacks against walls (organized storage, partially looted)
        this.createLootableFurniture(L + 12, T + 18, 'crate', this.contextLoot('warehouse', 2), 'left');
        this.createLootableFurniture(cx - 10, T + 12, 'crate', this.contextLoot('warehouse', 1), 'top');
        // Barrel cluster right wall (chemicals/fuel)
        this.createLootableFurniture(R - 12, cy - 5, 'barrel', this.contextLoot('warehouse', 2), 'right');
        this.createLootableFurniture(R - 28, cy + 5, 'barrel', null, 'right');
        // Shelving unit left wall
        const shelfY = this.safeWallY('left', cy + 15, T + 30, B - 20);
        this.createLootableFurniture(L + 12, shelfY, 'shelf', this.contextLoot('warehouse', 2), 'left');
        // Tool rack right wall (maintenance area)
        const toolY = this.safeWallY('right', T + 25, T + 15, B - 25);
        this.createLootableFurniture(R - 12, toolY, 'toolrack', this.contextLoot('garage', 1), 'right');
        // Pallet in center (wooden shipping pallet)
        this.add.rectangle(cx, cy + 20, 40, 30, 0x5a4a30, 0.5).setDepth(2);
        this.add.rectangle(cx, cy + 18, 38, 2, 0x4a3a20).setDepth(2.1);
        // Pallet slat lines
        for (let sl = 0; sl < 3; sl++) {
            this.add.rectangle(cx, cy + 12 + sl * 10, 36, 1, 0x4a3a20, 0.3).setDepth(2.05);
        }
        // Spilled contents from crate (someone pried it open)
        this.add.rectangle(cx + 15, cy + 30, 6, 4, 0x5a5a4a, 0.1).setDepth(1.5);
        this.add.rectangle(cx + 20, cy + 32, 4, 3, 0x4a5a4a, 0.08).setDepth(1.5).setAngle(-12);
        // Extra crate if big room
        if (w > 180) {
            this.createLootableFurniture(R - 14, T + 22, 'crate', this.pickLoot(1, 'uncommon'), 'right');
        }
        // Tire marks on floor (forklift used to be here)
        this.add.rectangle(cx - 20, cy + 15, 3, 40, 0x2a2a28, 0.05).setDepth(1);
        this.add.rectangle(cx - 15, cy + 15, 3, 40, 0x2a2a28, 0.05).setDepth(1);
    }
    
    genShelter(cx, cy, w, h, L, R, T, B) {
        // Very sparse but atmospheric
        this.freeCrate(L + 15, T + 20, this.contextLoot('shelter', 2));
        const shelfY = this.safeWallY('right', cy - 10, T + 15, B - 15);
        this.wallShelf('right', R, shelfY, this.contextLoot('shelter', 1));
        // Sleeping bag / bedroll on floor
        this.add.rectangle(cx - 15, cy + 15, 22, 40, 0x3a4a3a, 0.35).setDepth(1).setAngle(5);
        this.add.ellipse(cx - 15, cy - 3, 16, 10, 0x4a5a4a, 0.3).setDepth(1.1);
        // Floor debris
        this.add.rectangle(cx + 10, cy + 15, 10, 6, 0x3a3530, 0.25).setDepth(1);
        this.add.rectangle(cx + 20, cy + 8, 6, 4, 0x3a3530, 0.2).setDepth(1).setAngle(-15);
    }
    
    genGarage(cx, cy, w, h, L, R, T, B) {
        // Garage interior — workbench, tools, vehicle lift area, oil stains
        
        // Workbench against far wall (modular)
        this.createLootableFurniture(cx, T + 14, 'workbench', this.contextLoot('garage', 2), 'top');
        
        // Tool rack on left wall
        const toolY = this.safeWallY('left', cy - 15, T + 20, B - 20);
        this.createLootableFurniture(L + 12, toolY, 'toolrack', this.contextLoot('garage', 2), 'left');
        
        // Shelf on right wall
        const shelfY = this.safeWallY('right', T + 20, T + 15, B - 25);
        this.wallShelf('right', R, shelfY, this.contextLoot('warehouse', 2));
        
        // Oil barrel near right wall
        const barrelY = this.safeWallY('right', cy + 15, T + 30, B - 15);
        this.freeBarrel(R - 20, barrelY, this.contextLoot('garage', 1));
        
        // Crate in corner
        this.freeCrate(L + 15, T + 15, this.contextLoot('garage', 1));
        
        // Vehicle lift / work area in center — concrete pad + oil stains
        const padW = w * 0.45;
        const padH = h * 0.35;
        this.add.rectangle(cx, cy + 5, padW, padH, 0x2a2a28, 0.3).setDepth(1.1);
        this.add.rectangle(cx, cy + 5, padW - 4, padH - 4, 0x2a2a25, 0.2).setDepth(1.15);
        // Oil stain on pad
        this.add.ellipse(cx + 5, cy + 8, 20, 14, 0x1a1a15, 0.25).setDepth(1.2);
        this.add.ellipse(cx - 8, cy + 12, 12, 8, 0x1a1a15, 0.15).setDepth(1.2);
        
        // Jack stands (2 small iso objects on pad)
        this.add.rectangle(cx - 12, cy + 3, 6, 8, 0x5a5a5a).setDepth(10);
        this.add.rectangle(cx - 12, cy - 1, 6, 3, 0x6a6a6a).setDepth(10.1);
        this.add.rectangle(cx + 12, cy + 3, 6, 8, 0x5a5a5a).setDepth(10);
        this.add.rectangle(cx + 12, cy - 1, 6, 3, 0x6a6a6a).setDepth(10.1);
        
        // Tire stack against left wall (lower)
        const tireY = this.safeWallY('left', cy + 20, T + 30, B - 15);
        const tireC = this.add.container(L + 14, tireY).setDepth(10);
        for (let t = 0; t < 3; t++) {
            tireC.add(this.add.ellipse(0, -t * 5, 16, 10, 0x2a2a2a));
            tireC.add(this.add.ellipse(0, -t * 5 - 1, 14, 8, 0x3a3a3a));
            tireC.add(this.add.ellipse(0, -t * 5 - 2, 8, 4, 0x2a2a2a));
        }
        
        // Workbench items (on the counter)
        this.add.rectangle(cx - 15, T + 12, 8, 4, 0x5a4a3a).setDepth(11); // parts box
        this.add.rectangle(cx + 10, T + 10, 4, 6, 0xaa3a3a).setDepth(11); // spray can
        this.add.rectangle(cx, T + 11, 6, 5, 0x3a3a5a).setDepth(11);      // toolbox
        
        // Overhead light fixture (fluorescent tube vibe)
        this.add.rectangle(cx, cy - h * 0.3, 40, 3, 0x5a5a5a, 0.3).setDepth(2);
        this.add.rectangle(cx, cy - h * 0.3, 36, 1, 0xaaaaaa, 0.15).setDepth(2.1);
        
        // Chance of a siphon-able vehicle on the work pad
        if (Math.random() < 0.45) {
            const vehX = cx;
            const vehY = cy + 8;
            const tc = (c) => this.tintColor ? this.tintColor(c, this.lighting.ambient, this.lighting.intensity) : c;
            
            // ¾ iso REAR-FACING vehicle on lift — player sees the BACK
            // Camera above+south, vehicle faces north (away from player)
            // South face (back) is wide and dominant — tailgate, taillights, rear window
            const vc = this.add.container(vehX, vehY).setDepth(10);
            const palettes = [
                { body: 0x445566, dark: 0x2a3540, light: 0x556677 },
                { body: 0x554433, dark: 0x3a2a20, light: 0x665544 },
                { body: 0x664444, dark: 0x4a2a2a, light: 0x775555 },
                { body: 0x555555, dark: 0x353535, light: 0x666666 },
            ];
            const pal = palettes[Math.floor(Math.random() * palettes.length)];
            const bW = 52, bH = 26;
            
            // Ground shadow
            vc.add(this.add.ellipse(0, bH/2 + 4, bW * 0.85, bH * 0.35, 0x000000, 0.3));
            
            // Wheels (below body, foreshortened ellipses — rear pair visible)
            const wOff = bW * 0.3;
            const wY = bH/2 + 1;
            vc.add(this.add.ellipse(-wOff, wY, 8, 4, 0x1a1a1a));
            vc.add(this.add.ellipse(-wOff, wY, 4, 2, tc(0x2a2a2a)));
            vc.add(this.add.ellipse(wOff, wY, 8, 4, 0x1a1a1a));
            vc.add(this.add.ellipse(wOff, wY, 4, 2, tc(0x2a2a2a)));
            
            // Undercarriage
            vc.add(this.add.rectangle(0, bH/2, bW - 6, 3, tc(0x1a1a1a)));
            
            // === BACK PANEL — the dominant wide face ===
            // Lower body (bumper/tailgate area)
            vc.add(this.add.rectangle(0, bH * 0.15, bW, bH * 0.5, tc(pal.dark)));
            // Upper body panel
            vc.add(this.add.rectangle(0, -bH * 0.05, bW - 2, bH * 0.35, tc(pal.body)));
            
            // Bumper (thick bar across bottom of rear face)
            vc.add(this.add.rectangle(0, bH * 0.35, bW - 4, 4, tc(0x3a3a3a)));
            // Bumper center indent
            vc.add(this.add.rectangle(0, bH * 0.35, bW * 0.4, 2, tc(0x2a2a2a)));
            
            // Tailgate panel (recessed center)
            vc.add(this.add.rectangle(0, bH * 0.08, bW * 0.7, bH * 0.3, tc(IsoRenderer.darken(pal.body, 0.08))));
            // Tailgate handle
            vc.add(this.add.rectangle(0, bH * 0.18, 10, 2, tc(0x4a4a4a)));
            
            // Taillights (left and right on rear face, red)
            vc.add(this.add.rectangle(-bW/2 + 5, bH * 0.08, 5, 6, tc(0x882222)));
            vc.add(this.add.rectangle(-bW/2 + 5, bH * 0.08, 3, 4, tc(0xaa3333)));
            vc.add(this.add.rectangle(bW/2 - 5, bH * 0.08, 5, 6, tc(0x882222)));
            vc.add(this.add.rectangle(bW/2 - 5, bH * 0.08, 3, 4, tc(0xaa3333)));
            
            // License plate area (center bottom)
            vc.add(this.add.rectangle(0, bH * 0.25, 12, 5, tc(0xccccaa)));
            vc.add(this.add.rectangle(0, bH * 0.25, 10, 3, tc(0xddddbb)));
            
            // === CABIN/ROOF — receding away from camera (foreshortened top) ===
            const cabW = bW * 0.55;
            // Rear window (visible on back face, below roof)
            vc.add(this.add.rectangle(0, -bH * 0.15, cabW * 0.75, bH * 0.2, tc(0x1a2530)));
            // Rear window frame
            vc.add(this.add.rectangle(-cabW * 0.38 + 1, -bH * 0.15, 2, bH * 0.22, tc(pal.dark)));
            vc.add(this.add.rectangle(cabW * 0.38 - 1, -bH * 0.15, 2, bH * 0.22, tc(pal.dark)));
            
            // Roof — thin foreshortened strip receding north (away from camera)
            vc.add(this.add.rectangle(0, -bH * 0.28, cabW, bH * 0.12, tc(pal.dark)));
            vc.add(this.add.rectangle(0, -bH * 0.33, cabW - 2, bH * 0.06, tc(pal.body)));
            // Roof highlight
            vc.add(this.add.rectangle(0, -bH * 0.36, cabW - 4, 2, tc(pal.light)));
            
            // C-pillars (rear pillars flanking rear window)
            vc.add(this.add.rectangle(-cabW/2, -bH * 0.12, 3, bH * 0.3, tc(pal.dark)));
            vc.add(this.add.rectangle(cabW/2, -bH * 0.12, 3, bH * 0.3, tc(pal.dark)));
            
            // Side depth edges (east/west faces — narrow slivers, showing vehicle depth)
            vc.add(this.add.rectangle(-bW/2 - 1, 0, 3, bH * 0.55, tc(IsoRenderer.darken(pal.body, 0.18))));
            vc.add(this.add.rectangle(bW/2 + 1, 0, 3, bH * 0.55, tc(IsoRenderer.darken(pal.body, 0.18))));
            
            // Exhaust pipe (small detail under bumper)
            vc.add(this.add.ellipse(bW * 0.2, bH * 0.4, 4, 3, tc(0x3a3a3a)));
            vc.add(this.add.ellipse(bW * 0.2, bH * 0.4, 2, 2, tc(0x1a1a1a)));
            
            // Siphon zone
            const zone = this.add.zone(vehX, vehY, 50, 30);
            this.physics.add.existing(zone, true);
            zone._siphon = {
                hasFuel: Math.random() < 0.6,
                fuelAmount: Phaser.Math.Between(3, 10),
                siphoned: false,
                vehicleType: 'sedan'
            };
            if (!this.siphonVehicles) this.siphonVehicles = [];
            this.siphonVehicles.push(zone);
        }
    }
    
    // ==================== SUB-ROOM LAYOUTS ====================
    
    genBedroom(cx, cy, w, h, L, R, T, B) {
        // Bed against far wall — headboard flush to wall
        this.wallBed('top', cx, T + 5, Math.random() < 0.45 ? this.contextLoot('bedroom', 1) : null);
        // Nightstand beside bed
        this.createLootableFurniture(cx + 28, T + 15, 'nightstand', this.contextLoot('bedroom', 1), 'top');
        // Dresser on left wall — where they kept clothes
        this.createLootableFurniture(L + 14, cy + 5, 'dresser', this.contextLoot('bedroom', 2), 'left');
        // Wardrobe / cabinet on left wall near door
        const wardY = this.safeWallY('left', T + 20, T + 15, B - 25);
        this.createLootableFurniture(L + 14, wardY, 'cabinet', this.contextLoot('bedroom', 1), 'left');
        // Rug beside bed (oval, faded)
        this.add.ellipse(cx - 25, cy + 5, 30, 20, 0x3a3535, 0.2).setDepth(1);
        // Slippers by bed (someone lived here)
        this.add.rectangle(cx - 20, cy + 15, 5, 3, 0x4a3a3a, 0.15).setDepth(1.5);
        this.add.rectangle(cx - 15, cy + 16, 5, 3, 0x4a3a3a, 0.12).setDepth(1.5).setAngle(10);
        // Open book on nightstand area
        this.add.rectangle(cx + 28, T + 10, 5, 4, 0xccccaa, 0.12).setDepth(11);
    }
    
    genBathroom(cx, cy, w, h, L, R, T, B) {
        // Tub against far wall
        this.wallCounter('top', cx + 10, T, 40);
        // Shower curtain remnant (torn, hanging)
        this.add.rectangle(cx + 10, T + 3, 2, 12, 0x5a5a6a, 0.2).setDepth(11);
        this.add.rectangle(cx + 20, T + 5, 2, 8, 0x5a5a6a, 0.15).setDepth(11);
        // Sink against left wall
        this.wallCounter('left', L, cy - 5, 14);
        // Medicine cabinet above sink (most valuable loot in a bathroom)
        this.createLootableFurniture(L + 12, T + 15, 'medicine_cabinet', this.contextLoot('bathroom', 2), 'left');
        // Toilet against right wall — use safeWallY to avoid doors
        const toiletY = this.safeWallY('right', cy + 10, T + 20, B - 15);
        if (!this.isBlockingDoor(R, toiletY, 20, 20)) {
            this.createLootableFurniture(R - 12, toiletY, 'toilet', this.contextLoot('bathroom', 1), 'right');
        }
        // Water stain on floor (pipe leaked)
        this.add.ellipse(cx - 5, cy + 15, 18, 10, 0x3a4a4a, 0.08).setDepth(1);
        // Towel on floor
        this.add.rectangle(cx + 15, cy + 5, 8, 12, 0x5a6a6a, 0.12).setDepth(1.5).setAngle(15);
    }
    
    genKitchen(cx, cy, w, h, L, R, T, B) {
        // Counter along far wall (L-shaped kitchen layout)
        this.wallCounter('top', cx, T, w * 0.55);
        // Fridge right wall
        const fridgeY = this.safeWallY('right', T + 15, T + 10, B - 20);
        this.createLootableFurniture(R - 12, fridgeY, 'fridge', this.contextLoot('kitchen', 2), 'right');
        // Kitchen table in center (where the family ate)
        this.createLootableFurniture(cx, cy + 10, 'table', Math.random() < 0.3 ? this.pickLoot(1) : null, 'top');
        // Cabinet left wall (dishes, canned goods)
        const shelfY = this.safeWallY('left', cy - 5, T + 20, B - 20);
        this.createLootableFurniture(L + 12, shelfY, 'cabinet', this.contextLoot('kitchen', 2), 'left');
        // Stove on far wall (burners visible as circles)
        this.add.rectangle(cx + 30, T + 10, 18, 14, 0x2a2a2a).setDepth(11);
        this.add.circle(cx + 27, T + 8, 3, 0x3a3a3a).setDepth(11.1);
        this.add.circle(cx + 33, T + 8, 3, 0x3a3a3a).setDepth(11.1);
        // Dish on table
        this.add.ellipse(cx - 3, cy + 8, 6, 4, 0xcccccc, 0.12).setDepth(11);
        // Spilled food / opened cans (post-Collapse scavenging)
        this.add.ellipse(cx + 15, cy + 18, 4, 3, 0x5a5a5a, 0.1).setDepth(1.5);
        this.add.ellipse(cx - 10, cy + 20, 8, 5, 0x4a3a2a, 0.06).setDepth(1);
    }
    
    genOffice(cx, cy, w, h, L, R, T, B) {
        // Desk against far wall (someone's workspace)
        this.createLootableFurniture(cx, T + 14, 'desk', this.contextLoot('office', 2), 'top');
        // Computer on desk
        this.add.rectangle(cx, T + 8, 10, 8, 0x2a2a3a).setDepth(11);
        this.add.rectangle(cx, T + 3, 10, 3, 0x3a3a4a).setDepth(11.1);
        // Pen cup on desk
        this.add.rectangle(cx + 14, T + 9, 4, 5, 0x3a3a4a, 0.3).setDepth(11);
        // Locker/shelf on right wall
        const lockerY = this.safeWallY('right', cy, T + 20, B - 20);
        this.createLootableFurniture(R - 12, lockerY, 'locker', this.contextLoot('office', 2), 'right');
        // Bookshelf left wall
        const shelfY = this.safeWallY('left', cy - 5, T + 20, B - 20);
        this.createLootableFurniture(L + 12, shelfY, 'shelf', this.contextLoot('office', 1), 'left');
        // Filing cabinet near desk
        this.createLootableFurniture(cx - 28, T + 14, 'filing_cabinet', this.pickLoot(1, 'uncommon'), 'top');
        // Office chair (rolled away from desk)
        this.add.ellipse(cx + 20, cy + 5, 10, 8, 0x3a3a4a, 0.25).setDepth(2);
        this.add.rectangle(cx + 20, cy + 1, 8, 3, 0x2a2a3a, 0.2).setDepth(2.1);
        // Trash can overflowing
        this.add.ellipse(R - 15, B - 10, 8, 6, 0x3a3a3a, 0.4).setDepth(2);
        this.add.rectangle(R - 13, B - 14, 4, 3, 0xccccaa, 0.1).setDepth(2.1).setAngle(20);
        // Sticky notes on wall (remnants of organization)
        this.add.rectangle(cx + 20, T + 4, 5, 4, 0xaacc88, 0.1).setDepth(1);
        this.add.rectangle(cx + 26, T + 5, 4, 4, 0xccaa88, 0.08).setDepth(1);
    }
    
    genStorage(cx, cy, w, h, L, R, T, B) {
        // Shelves along far wall (bulk storage)
        this.wallShelf('top', cx - 20, T, this.contextLoot('storage', 2));
        // Second shelf if wide
        if (w > 160) this.wallShelf('top', cx + 25, T, this.contextLoot('storage', 1));
        // Supply crate (pushed to side)
        this.createLootableFurniture(R - 18, cy, 'crate', this.contextLoot('storage', 1), 'right');
        // Barrel in far corner
        this.createLootableFurniture(L + 14, T + 18, 'barrel', this.pickLoot(1), 'left');
        // Tool rack on right wall
        const toolY = this.safeWallY('right', cy - 5, T + 15, B - 15);
        this.createLootableFurniture(R - 12, toolY, 'toolrack', this.contextLoot('garage', 1), 'right');
        // Stacked boxes in corner (decorative, showing room was packed)
        this.add.rectangle(L + 16, T + 35, 14, 10, 0x5a4a30, 0.25).setDepth(2);
        this.add.rectangle(L + 14, T + 29, 10, 8, 0x6a5a40, 0.2).setDepth(2.1);
        // Dust/dirt patch
        this.add.ellipse(cx, cy + 10, 20, 12, 0x3a3530, 0.06).setDepth(1);
        // Extra crate if big room
        if (w > 180) {
            this.createLootableFurniture(cx + 10, cy + 15, 'crate', this.pickLoot(1, 'uncommon'), 'top');
        }
    }
    
    genBackRoom(cx, cy, w, h, L, R, T, B) {
        // Shelf on far wall (miscellaneous storage)
        this.wallShelf('top', cx, T, this.pickLoot(2));
        // Supply crate (shoved in a corner)
        this.createLootableFurniture(cx + 20, cy + 8, 'crate', this.pickLoot(1), 'top');
        // Barrel in top-left corner
        if (Math.random() < 0.6) {
            this.createLootableFurniture(L + 14, T + 18, 'barrel', this.pickLoot(1), 'left');
        }
        // Mop bucket (this is where employees went to hide)
        this.add.ellipse(R - 15, B - 12, 8, 6, 0x3a4a4a, 0.15).setDepth(2);
        this.add.rectangle(R - 14, B - 22, 1, 16, 0x5a5a5a, 0.2).setDepth(2.1);
        // Floor stain (old spill never cleaned)
        this.add.ellipse(cx - 8, cy + 15, 14, 8, 0x3a3a30, 0.06).setDepth(1);
    }
    
    // ==================== LOCATION-SPECIFIC GENERATORS ====================
    
    genHardwareStore(cx, cy, w, h, L, R, T, B) {
        // Checkout counter along far wall with register
        this.wallCounter('top', cx + 15, T, w * 0.4);
        this.createLootableFurniture(cx + 25, T + 14, 'register', this.contextLoot('store', 1), 'top');
        // Workbench display on far wall (demo/cutting area)
        this.createLootableFurniture(cx - 30, T + 14, 'workbench', this.contextLoot('garage', 2), 'top');
        // Left wall: tall tool shelving
        const shelfL1 = this.safeWallY('left', cy - 20, T + 20, B - 30);
        this.createLootableFurniture(L + 12, shelfL1, 'shelf', this.contextLoot('garage', 2), 'left');
        // Second left shelf (hardware)
        if (h > 200) {
            const shelfL2 = this.safeWallY('left', cy + 25, T + 30, B - 15);
            this.createLootableFurniture(L + 12, shelfL2, 'shelf', this.contextLoot('warehouse', 1), 'left');
        }
        // Right wall: supply shelf
        const shelfR1 = this.safeWallY('right', cy - 15, T + 20, B - 25);
        this.createLootableFurniture(R - 12, shelfR1, 'shelf', this.contextLoot('garage', 2), 'right');
        // Center aisle display rack (where you'd browse)
        this.createLootableFurniture(cx, cy + 15, 'table', this.pickLoot(1), 'top');
        // Scattered hardware on floor (post-Collapse ransacking)
        this.add.rectangle(cx + 20, cy + 25, 4, 2, 0x6a6a6a, 0.12).setDepth(1.5).setAngle(45);
        this.add.rectangle(cx - 15, cy + 20, 3, 5, 0x5a4a3a, 0.1).setDepth(1.5).setAngle(-20);
        // Paint can on floor
        this.add.circle(R - 25, cy + 10, 4, 0x5a5a7a, 0.12).setDepth(1.5);
    }
    
    genGrocery(cx, cy, w, h, L, R, T, B) {
        // Checkout counter with register near entrance
        this.wallCounter('top', cx + 25, T, w * 0.3);
        this.createLootableFurniture(cx + 35, T + 14, 'register', this.contextLoot('store', 1), 'top');
        // Refrigerator on right wall (drinks, perishables)
        const fridgeY = this.safeWallY('right', cy - 10, T + 20, B - 25);
        this.createLootableFurniture(R - 12, fridgeY, 'fridge', this.contextLoot('kitchen', 2), 'right');
        // Display case center (produce/deli — modular)
        this.createLootableFurniture(cx - 15, cy, 'display_case', this.contextLoot('store', 2), 'top');
        // Aisle shelf (canned goods)
        this.createLootableFurniture(cx + 10, cy + 5, 'shelf', this.contextLoot('store', 1), 'top');
        // Left wall shelf (produce/dry goods)
        const shelfY = this.safeWallY('left', cy, T + 20, B - 20);
        this.createLootableFurniture(L + 12, shelfY, 'shelf', this.contextLoot('store', 2), 'left');
        // Shopping basket near door (someone dropped it while fleeing)
        this.add.rectangle(cx - 15, B - 12, 12, 10, 0x888888, 0.3).setDepth(2).setAngle(8);
        // Spilled cans on floor
        this.add.ellipse(cx + 20, cy + 20, 4, 3, 0x5a5a6a, 0.1).setDepth(1.5);
        this.add.ellipse(cx + 25, cy + 22, 3, 3, 0x6a5a5a, 0.08).setDepth(1.5);
        this.add.ellipse(cx + 18, cy + 24, 4, 3, 0x5a6a5a, 0.09).setDepth(1.5);
        // Wet floor sign (knocked over)
        this.add.rectangle(cx - 8, cy + 18, 3, 8, 0xaaaa33, 0.12).setDepth(1.6).setAngle(65);
    }
    
    genApartmentFloor(cx, cy, w, h, L, R, T, B) {
        // Small studio — living, sleeping, and cooking in one space
        // Couch against left wall (main living area)
        const couchY = this.safeWallY('left', cy - 10, T + 30, B - 30);
        this.wallCouch('left', L, couchY);
        // Kitchenette on far wall
        this.wallCounter('top', cx - 20, T, w * 0.35);
        this.createLootableFurniture(cx + 30, T + 12, 'fridge', this.contextLoot('kitchen', 2), 'top');
        // Bed corner (far right) — unmade
        this.createLootableFurniture(R - 18, T + 25, 'nightstand', this.contextLoot('bedroom', 1), 'right');
        this.add.rectangle(R - 25, T + 40, 30, 40, 0x4a4050, 0.6).setDepth(2);
        this.add.rectangle(R - 25, T + 24, 30, 6, 0x5a5060, 0.5).setDepth(2.1);
        // Blanket trailing off bed
        this.add.rectangle(R - 10, T + 55, 12, 6, 0x4a4050, 0.25).setDepth(2.05).setAngle(20);
        // Shelf on right wall
        const shelfRY = this.safeWallY('right', cy + 15, T + 50, B - 15);
        this.createLootableFurniture(R - 12, shelfRY, 'shelf', this.pickLoot(1), 'right');
        // Coffee table in living area
        this.createLootableFurniture(cx - 5, cy + 10, 'table', this.pickLoot(1), 'top');
        // Mug on coffee table
        this.add.circle(cx - 8, cy + 8, 2, 0x5a4a3a, 0.15).setDepth(11);
        // Rug under table
        this.add.ellipse(cx - 5, cy + 10, 40, 25, 0x3a3535, 0.15).setDepth(1);
        // Mail/keys by door
        this.add.rectangle(cx - 15, B - 8, 8, 5, 0xccccaa, 0.08).setDepth(1.5);
        
        // Stairwell indicator
        const stairX = R - 25, stairY = B - 20;
        const stairGfx = this.add.container(stairX, stairY).setDepth(5);
        for (let step = 0; step < 4; step++) {
            const sy = -step * 4;
            stairGfx.add(this.add.rectangle(0, sy, 20, 4, 0x5a5a5a - step * 0x080808, 0.7));
            stairGfx.add(this.add.rectangle(0, sy + 2, 20, 2, 0x3a3a3a, 0.5));
        }
        stairGfx.add(this.add.triangle(0, -20, 0, -6, -4, 0, 4, 0, 0xaaccaa, 0.6));
    }
    
    genMotelRoom(cx, cy, w, h, L, R, T, B) {
        // Bed against far wall (disheveled sheets)
        this.add.rectangle(cx - 20, T + 22, 40, 35, 0x4a4050, 0.6).setDepth(2);
        this.add.rectangle(cx - 20, T + 8, 40, 6, 0x5a5060, 0.5).setDepth(2.1);
        // Rumpled pillow
        this.add.ellipse(cx - 30, T + 12, 10, 6, 0x6a6070, 0.25).setDepth(2.2);
        // Blanket half-off bed
        this.add.rectangle(cx - 5, T + 38, 15, 8, 0x4a4050, 0.3).setDepth(2.05).setAngle(15);
        // Nightstands flanking bed
        this.createLootableFurniture(cx - 42, T + 14, 'nightstand', this.contextLoot('bedroom', 1), 'top');
        this.createLootableFurniture(cx + 2, T + 14, 'nightstand', this.contextLoot('bedroom', 1), 'top');
        // TV on dresser against right wall
        this.wallTV('right', R - 5, cy - 10, this.pickLoot(1));
        this.createLootableFurniture(R - 12, cy - 10, 'dresser', this.contextLoot('bedroom', 1), 'right');
        // Bathroom area (left wall lower — tile floor section)
        this.add.rectangle(L + 20, B - 18, 30, 25, 0x354545, 0.15).setDepth(1);
        this.createLootableFurniture(L + 12, B - 18, 'medicine_cabinet', this.contextLoot('bathroom', 1), 'left');
        // Suitcase on floor (traveler left it behind)
        this.add.rectangle(cx + 10, cy + 15, 16, 10, 0x5a4a3a, 0.5).setDepth(2);
        this.add.rectangle(cx + 10, cy + 12, 14, 2, 0x4a3a2a, 0.4).setDepth(2.1); // handle
        // Bible in nightstand drawer (world-building detail)
        this.add.rectangle(cx - 42, T + 12, 5, 4, 0x2a2a3a, 0.15).setDepth(11);
        // Do-not-disturb sign on floor near door
        this.add.rectangle(cx - 5, B - 8, 8, 4, 0xaaaa55, 0.1).setDepth(1.5).setAngle(-30);
    }
    
    genDiner(cx, cy, w, h, L, R, T, B) {
        // Long service counter along far wall (where you'd sit and eat)
        this.wallCounter('top', cx, T, w * 0.7);
        // Register at one end of counter
        this.createLootableFurniture(cx - 30, T + 14, 'register', this.contextLoot('store', 1), 'top');
        // Coffee machine behind counter (decorative)
        this.add.rectangle(cx + 20, T + 8, 8, 10, 0x3a3a3a).setDepth(11);
        this.add.rectangle(cx + 20, T + 4, 6, 3, 0x4a4a4a).setDepth(11.1);
        // Stools in front of counter (some knocked over)
        for (let i = 0; i < 4; i++) {
            const sx = cx - 30 + i * 20;
            if (i === 2) {
                // Knocked over stool
                this.add.ellipse(sx + 4, T + 32, 10, 5, 0x4a4a4a, 0.3).setDepth(2);
                this.add.rectangle(sx + 2, T + 30, 2, 8, 0x3a3a3a, 0.25).setDepth(1.9).setAngle(70);
            } else {
                this.add.circle(sx, T + 28, 5, 0x4a4a4a, 0.4).setDepth(2);
                this.add.rectangle(sx, T + 32, 2, 6, 0x3a3a3a, 0.3).setDepth(1.9);
            }
        }
        // Booth along left wall (bench + table)
        const boothLY = this.safeWallY('left', cy + 5, T + 30, B - 30);
        this.wallCouch('left', L, boothLY);
        this.freeTable(L + 30, boothLY, 22, 14, this.contextLoot('kitchen', 1));
        // Napkin dispenser on table
        this.add.rectangle(L + 30, boothLY - 5, 4, 6, 0x8a8a8a, 0.3).setDepth(11);
        // Booth along right wall
        const boothRY = this.safeWallY('right', cy + 5, T + 30, B - 30);
        this.wallCouch('right', R, boothRY);
        this.freeTable(R - 30, boothRY, 22, 14, this.pickLoot(1));
        // Jukebox near entrance (modular)
        this.createLootableFurniture(cx + 20, B - 18, 'jukebox', null, 'bottom');
        // Broken plate / spilled food on floor
        this.add.ellipse(cx - 5, cy + 18, 8, 6, 0xaaaaaa, 0.12).setDepth(1);
        this.add.ellipse(cx - 3, cy + 20, 10, 4, 0x5a4a3a, 0.08).setDepth(1.1);
        // Menu board on far wall
        this.add.rectangle(cx + 5, T + 4, 16, 8, 0x2a2a2a, 0.3).setDepth(1);
    }
    
    genPoliceStation(cx, cy, w, h, L, R, T, B) {
        // Front desk — intake counter where officers processed people
        this.wallCounter('top', cx - 20, T, w * 0.45);
        // Computer terminal on desk
        this.add.rectangle(cx - 20, T + 8, 10, 8, 0x2a2a3a).setDepth(11);
        this.add.rectangle(cx - 20, T + 3, 10, 3, 0x1a1a2a).setDepth(11.1);
        // Gun rack on far wall (armory side)
        this.createLootableFurniture(cx + 30, T + 12, 'gun_rack', this.contextLoot('armory', 2), 'top');
        // Evidence/filing along right wall
        const lockerY = this.safeWallY('right', cy - 15, T + 20, B - 25);
        this.createLootableFurniture(R - 12, lockerY, 'filing_cabinet', this.contextLoot('armory', 2), 'right');
        // More filing along left wall (records)
        const cabY = this.safeWallY('left', cy - 10, T + 20, B - 25);
        this.createLootableFurniture(L + 12, cabY, 'filing_cabinet', this.contextLoot('office', 1), 'left');
        // Officer's desk in center of room (working area)
        this.createLootableFurniture(cx, cy + 8, 'desk', this.pickLoot(1, 'uncommon'), 'top');
        // Chair behind desk (knocked over)
        this.add.rectangle(cx + 18, cy + 12, 8, 8, 0x3a3a4a, 0.3).setDepth(2).setAngle(-25);
        // Coffee mug on desk
        this.add.circle(cx - 10, cy + 5, 2, 0x5a3a2a, 0.4).setDepth(11);
        // Bulletin board on far wall (between counter and gun rack)
        this.add.rectangle(cx + 5, T + 5, 14, 10, 0x5a4a3a, 0.25).setDepth(1);
        this.add.rectangle(cx + 3, T + 3, 3, 3, 0xcccc88, 0.2).setDepth(1.1);
        this.add.rectangle(cx + 8, T + 5, 3, 4, 0xccaa88, 0.15).setDepth(1.1);
        // Floor scuff marks
        this.add.rectangle(cx - 5, cy + 20, 20, 2, 0x2a2a28, 0.1).setDepth(1);
    }
    
    genChurch(cx, cy, w, h, L, R, T, B) {
        // Altar at far wall — focal point of the church
        this.createLootableFurniture(cx, T + 18, 'altar', this.pickLoot(1, 'uncommon'), 'top');
        // Stained glass suggestion on far wall
        this.add.rectangle(cx, T + 3, 18, 8, 0x6a4a8a, 0.15).setDepth(1);
        this.add.rectangle(cx - 10, T + 3, 4, 8, 0x4a6a8a, 0.1).setDepth(1);
        this.add.rectangle(cx + 10, T + 3, 4, 8, 0x8a6a4a, 0.1).setDepth(1);
        // Pew rows — the main body of the church
        const pewRows = Math.min(3, Math.floor((B - T - 50) / 35));
        for (let r = 0; r < pewRows; r++) {
            const py = T + 55 + r * 35;
            // Left pew (lootable — people hid things here)
            this.createLootableFurniture(cx - 22, py, 'pew', r === 0 ? this.pickLoot(1) : null, 'top');
            // Right pew (decorative)
            this.createLootableFurniture(cx + 22, py, 'pew', r === pewRows - 1 ? this.pickLoot(1) : null, 'top');
        }
        // Aisle runner (faded carpet)
        this.add.rectangle(cx, cy + 5, 12, h * 0.5, 0x5a3a3a, 0.08).setDepth(1);
        // Bookshelf left wall (hymnals, scripture)
        const shelfY = this.safeWallY('left', cy - 10, T + 20, B - 20);
        this.wallShelf('left', L, shelfY, this.pickLoot(1));
        // Supply cabinet right wall (vestments, candles)
        const cabY = this.safeWallY('right', cy - 5, T + 20, B - 20);
        this.createLootableFurniture(R - 12, cabY, 'cabinet', this.contextLoot('shelter', 1), 'right');
        // Overturned candelabra near altar
        this.add.rectangle(cx + 15, T + 30, 2, 12, 0x8a7a3a, 0.25).setDepth(2).setAngle(35);
        // Scattered papers/hymn books
        this.add.rectangle(cx - 8, cy + 25, 6, 4, 0xccccaa, 0.1).setDepth(1.5).setAngle(-10);
        this.add.rectangle(cx + 3, cy + 30, 5, 3, 0xccccaa, 0.08).setDepth(1.5).setAngle(20);
    }
    
    genSchool(cx, cy, w, h, L, R, T, B) {
        // Teacher's desk at front of room
        this.createLootableFurniture(cx - 15, T + 20, 'desk', this.contextLoot('office', 1), 'top');
        // Apple / coffee mug on desk
        this.add.circle(cx - 8, T + 16, 2, 0xaa3333, 0.3).setDepth(11);
        // Chalkboard on far wall (modular, decorative)
        this.createLootableFurniture(cx + 10, T + 8, 'chalkboard', null, 'top');
        // Student desks in grid — some displaced
        const cols = Math.min(3, Math.floor((R - L - 40) / 40));
        const rows = Math.min(2, Math.floor((B - T - 60) / 45));
        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const dx = L + 30 + c * 40;
                const dy = T + 55 + r * 45;
                if (r === 1 && c === 1) {
                    // Knocked over desk
                    this.add.rectangle(dx + 5, dy + 3, 20, 14, 0x5a5a50, 0.25).setDepth(2).setAngle(18);
                } else {
                    this.add.rectangle(dx, dy, 20, 14, 0x5a5a50, 0.4).setDepth(2);
                    // Attached chair
                    this.add.rectangle(dx, dy + 12, 8, 8, 0x4a4a4a, 0.3).setDepth(1.9);
                }
            }
        }
        // Supply shelf right wall
        const shelfY = this.safeWallY('right', cy, T + 20, B - 20);
        this.wallShelf('right', R, shelfY, this.contextLoot('store', 2));
        // Filing cabinet left wall (teacher's files)
        const cabY = this.safeWallY('left', cy, T + 20, B - 20);
        this.createLootableFurniture(L + 12, cabY, 'filing_cabinet', this.pickLoot(1), 'left');
        // Scattered papers on floor
        for (let p = 0; p < 4; p++) {
            const px = cx + (Math.random() - 0.5) * w * 0.5;
            const py = cy + (Math.random() - 0.5) * h * 0.3;
            this.add.rectangle(px, py, 4 + Math.random() * 3, 3, 0xccccbb, 0.06 + Math.random() * 0.06).setDepth(1).setAngle(Math.random() * 360);
        }
        // Globe on teacher's desk (decorative)
        this.add.circle(cx - 22, T + 17, 3, 0x4a6a8a, 0.25).setDepth(11);
    }
    
    genResearchLab(cx, cy, w, h, L, R, T, B) {
        // Lab bench along far wall (primary work surface)
        this.wallCounter('top', cx - 20, T, w * 0.5);
        // Second bench segment (separate station)
        this.wallCounter('top', cx + 30, T, w * 0.2);
        // Computer terminal on bench (high-value data)
        this.createLootableFurniture(cx - 10, T + 14, 'register', this.pickLoot(2, 'rare'), 'top');
        // Monitor glow
        this.add.rectangle(cx - 10, T + 8, 8, 5, 0x2a4a3a, 0.15).setDepth(11.2);
        // Specimen cabinet left wall (biological samples)
        const shelfL = this.safeWallY('left', cy - 10, T + 20, B - 25);
        this.createLootableFurniture(L + 12, shelfL, 'medicine_cabinet', this.contextLoot('pharmacy', 2), 'left');
        // Equipment rack right wall
        const shelfR = this.safeWallY('right', cy - 10, T + 20, B - 25);
        this.wallShelf('right', R, shelfR, this.pickLoot(2, 'uncommon'));
        // Exam table in center (what they were working on)
        this.createLootableFurniture(cx + 5, cy + 10, 'exam_table', this.pickLoot(1, 'uncommon'), 'top');
        // Hazard stripe on floor (biohazard zone boundary)
        this.add.rectangle(cx, B - 5, w * 0.6, 3, 0xaa8822, 0.3).setDepth(1);
        // Glowing specimen jar (decorative — something in formaldehyde)
        this.add.circle(R - 20, T + 18, 4, 0x8844aa, 0.2).setDepth(2);
        this.add.circle(R - 20, T + 18, 2, 0xaa66cc, 0.15).setDepth(2.1);
        // Spilled chemical on floor
        this.add.ellipse(cx + 20, cy + 5, 16, 10, 0x3a5a4a, 0.1).setDepth(1);
        // Broken beaker shards
        this.add.rectangle(cx + 22, cy + 2, 3, 2, 0xaaaaaa, 0.08).setDepth(1.5).setAngle(30);
        this.add.rectangle(cx + 18, cy + 6, 2, 3, 0xaaaaaa, 0.06).setDepth(1.5).setAngle(-15);
        // Whiteboard on far wall with scrawled equations (post-Collapse: "THE CUBE" written)
        this.add.rectangle(cx + 30, T + 5, 14, 10, 0xdddddd, 0.1).setDepth(1);
    }
    
    genBunker(cx, cy, w, h, L, R, T, B) {
        // Supply shelf on far wall (rations, medical, survival gear)
        this.wallShelf('top', cx - 15, T, this.contextLoot('pharmacy', 2));
        // Military crates flanking entry (ammo, equipment)
        this.createLootableFurniture(L + 14, T + 18, 'crate', this.contextLoot('armory', 2), 'left');
        this.createLootableFurniture(R - 14, T + 18, 'crate', this.contextLoot('warehouse', 2), 'right');
        // Gun rack right wall (weapons locker)
        const lockerY = this.safeWallY('right', cy, T + 25, B - 20);
        this.createLootableFurniture(R - 12, lockerY, 'gun_rack', this.contextLoot('armory', 2), 'right');
        // Bunk bed left wall (sleeping quarters)
        const bunkY = this.safeWallY('left', cy + 10, T + 30, B - 20);
        this.createLootableFurniture(L + 14, bunkY, 'bunk_bed', this.pickLoot(1), 'left');
        // Blanket draped from bunk (someone was living here)
        this.add.rectangle(L + 22, bunkY + 8, 10, 6, 0x4a5040, 0.2).setDepth(2);
        // Comms equipment on far wall
        this.createLootableFurniture(cx + 20, T + 14, 'filing_cabinet', this.pickLoot(1, 'uncommon'), 'top');
        // Radio on top of filing cabinet
        this.add.rectangle(cx + 20, T + 6, 8, 5, 0x2a2a3a, 0.4).setDepth(11);
        this.add.rectangle(cx + 18, T + 2, 1, 8, 0x5a5a5a, 0.3).setDepth(11.1); // antenna
        // Generator in corner (humming, keeping lights on)
        this.add.rectangle(R - 20, B - 15, 16, 12, 0x3a3a3a, 0.5).setDepth(2);
        this.add.rectangle(R - 20, B - 20, 14, 3, 0x4a4a4a, 0.4).setDepth(2.1);
        this.add.ellipse(R - 20, B - 10, 18, 4, 0x2a2a2a, 0.15).setDepth(1); // shadow
        // Empty ration cans on floor (bunker was occupied)
        this.add.ellipse(cx - 8, cy + 18, 4, 3, 0x5a5a5a, 0.15).setDepth(1.5);
        this.add.ellipse(cx + 5, cy + 22, 3, 2, 0x5a5a5a, 0.1).setDepth(1.5);
        // Map/planning table in center
        this.freeTable(cx, cy - 5, 26, 16, null);
        this.add.rectangle(cx, cy - 8, 20, 12, 0x5a5a4a, 0.15).setDepth(11); // map spread
    }
    
    genRooftop(cx, cy, w, h, L, R, T, B) {
        // SKYBOX — render time-of-day sky gradient above the low parapet walls
        const tod = CONFIG.timeOfDay || 'midday';
        const skyColors = {
            dawn: [0x1a1a3a, 0x3a2a4a, 0x8a5a3a, 0xcc8844],
            midday: [0x2a3a5a, 0x4a6a8a, 0x6a8aaa, 0x8aaacc],
            dusk: [0x1a1a2a, 0x4a2a3a, 0x8a4a2a, 0xcc6633],
            night: [0x0a0a1a, 0x0a0a1a, 0x1a1a2a, 0x1a1a2a]
        };
        const colors = skyColors[tod] || skyColors.midday;
        
        // Draw sky above the far wall area (top portion of room)
        const skyH = 40;
        const skyTop = T - 20;
        for (let i = 0; i < 4; i++) {
            const bandH = skyH / 4;
            this.add.rectangle(cx, skyTop + i * bandH + bandH/2, w + 10, bandH + 1, colors[i], 0.6).setDepth(0.5);
        }
        
        // Stars at night
        if (tod === 'night' || tod === 'dusk') {
            for (let s = 0; s < 8; s++) {
                const sx = L + Math.random() * (R - L);
                const sy = skyTop + Math.random() * skyH;
                this.add.circle(sx, sy, 0.8, 0xffffff, 0.3 + Math.random() * 0.3).setDepth(0.6);
            }
        }
        
        // Moon at night
        if (tod === 'night') {
            this.add.circle(cx + 30, skyTop + 10, 5, 0xddddcc, 0.4).setDepth(0.6);
        }
        
        // Low parapet walls (half height)
        // Only bottom-half walls visible — top portion is open sky
        
        // Rooftop furniture — sparse, atmospheric
        // Water tank
        this.add.rectangle(R - 20, T + 20, 18, 14, 0x4a4a4a, 0.6).setDepth(3);
        this.add.ellipse(R - 20, T + 14, 18, 6, 0x5a5a5a, 0.5).setDepth(3.1);
        // Antenna
        this.add.rectangle(L + 15, T + 10, 1.5, 25, 0x5a5a5a, 0.6).setDepth(3);
        this.add.rectangle(L + 20, T + 8, 10, 1, 0x4a4a4a, 0.4).setDepth(3);
        // HVAC unit
        this.add.rectangle(cx + 10, T + 15, 22, 14, 0x3a3a3a, 0.6).setDepth(3);
        this.add.rectangle(cx + 10, T + 9, 20, 2, 0x4a4a4a, 0.4).setDepth(3.1);
        // Lootable: supply cache someone left up here
        this.freeCrate(cx - 20, cy + 10, this.pickLoot(2, 'uncommon'));
        // Vent pipe
        this.add.rectangle(R - 35, cy, 3, 12, 0x4a4a4a, 0.5).setDepth(3);
        // Wind effect — decorative moving bits
        this.add.rectangle(cx, cy - 5, 50, 1, 0xaaaaaa, 0.08).setDepth(0.7);
    }
    
    // ==================== LOOTABLE FURNITURE (free-standing) ====================
    
    // Attach loot to a furniture piece - creates a highlight glow that shows when near
    attachLoot(furniture, items) {
        if (!furniture || !items || !items.length) return;
        furniture.lootItems = items.map(item => ({ name: item, quantity: 1 }));
        furniture.looted = false;
        
        // Assign a loot index for persistence
        if (!this._lootIndex) this._lootIndex = 0;
        furniture._lootIdx = this._lootIndex++;
        
        // Check if this loot was already collected in a previous visit
        if (this.buildingId && BUILDING_STATE[this.buildingId] && 
            BUILDING_STATE[this.buildingId].lootedIndices && 
            BUILDING_STATE[this.buildingId].lootedIndices.includes(furniture._lootIdx)) {
            furniture.looted = true;
            furniture.setAlpha(0.7);
            furniture.visible = true;
            return; // Skip highlight, already looted
        }
        
        // Create highlight glow (hidden by default, shown when player is near)
        const bounds = furniture.getBounds();
        const highlight = this.add.rectangle(
            furniture.x, furniture.y, 
            bounds.width + 8, bounds.height + 8, 
            0x88ff88, 0
        ).setDepth(furniture.depth - 0.5);
        highlight.setStrokeStyle(2, 0x88ff88, 0.7);
        highlight.setVisible(false);
        furniture.highlight = highlight;
        
        this.lootObjects.push(furniture);
    }
    
    // Create furniture with integrated loot — iso depth style
    // Universal wall-aware rendering: all cases draw FRONT-FACING at origin.
    // For left/right walls, a transform proxy compresses horizontally and adds depth.
    createLootableFurniture(x, y, type, items, wall) {
        if (this.isBlockingDoor(x, y, 40, 50)) return null;
        if (this._placedFurniture) {
            const tooClose = this._placedFurniture.some(f => 
                Math.abs(f.x - x) < 30 && Math.abs(f.y - y) < 30
            );
            if (tooClose) return null;
        }
        wall = wall || 'top';
        let furniture;
        
        // === MODULAR RENDERER — check ISO_DEFS first ===
        const modularDef = ISO_DEFS[type];
        if (modularDef) {
            const wallMap = { top: 'front', left: 'left', right: 'right', bottom: 'back' };
            // Y-based depth: furniture lower on screen renders in front
            const yDepth = 10 + y * 0.05;
            const container = IsoRenderer.render(modularDef, {
                scene: this, x, y,
                wall: wallMap[wall] || 'front',
                depth: yDepth
            });
            // Create invisible hitbox for interaction
            const hw = (modularDef.w || 16) + 4;
            const hh = (modularDef.h || 16) + 4;
            furniture = this.add.rectangle(x, y, hw, hh, 0x000000, 0).setDepth(yDepth + 0.5);
            // Add collision wall
            this.addWall(x, y, hw - 4, hh - 4, 0x000000, true);
            this.attachLoot(furniture, items);
            // Tag with themed label
            if (furniture) {
                furniture.furnitureLabel = this._getFurnitureLabel(type) || type;
            }
            if (this._placedFurniture) this._placedFurniture.push({ x, y, type });
            return furniture;
        }
        
        // Unknown type — no def found
        return null;
    }

    
    createUI() {
        const uiDepth = 100;
        
        // Flavor text selection (archetype-based, seed-deterministic)
        const flavorTexts = {
            residential: [
                'The air is stale. Someone lived here.',
                'Furniture overturned. Left in a hurry.',
                'A home. Once.',
                'Faded photos on the wall.',
                'Dust covers everything.',
                'The floorboards creak underfoot.'
            ],
            commercial: [
                'Shelves half-empty. Picked through.',
                'The register sits open and gutted.',
                'Fluorescent buzz. One bulb left.',
                'Broken glass crunches underfoot.',
                'Price tags litter the floor.',
                'The store bell will never ring again.'
            ],
            industrial: [
                'Grease and rust. Industrial silence.',
                'Machinery stands idle. Cold metal.',
                'Oil stains map forgotten labor.',
                'Chains rattle somewhere above.',
                'The concrete floor is cracked.',
                'Tools scattered. Work abandoned.'
            ],
            civic: [
                'Public service. Private despair.',
                'Forms and paperwork. All meaningless now.',
                'The waiting room waits for no one.',
                'Institutional green. Peeling paint.',
                'Emergency procedures posted. Ignored.',
                'Service counter. No one is serving.'
            ],
            shelter: [
                'Makeshift. Desperate. Temporary.',
                'Someone camped here. Recently.',
                'Scratches on the wall. Counting days.',
                'A cold corner. Better than outside.',
                'Canned goods. Empty.',
                'The smell of old blankets.'
            ]
        };
        const archFlavors = flavorTexts[this.archetypeName] || flavorTexts.commercial;
        // Use building seed for deterministic flavor
        let flavorSeed = 0;
        if (this.buildingId) {
            for (let i = 0; i < this.buildingId.length; i++) {
                flavorSeed = ((flavorSeed << 5) - flavorSeed + this.buildingId.charCodeAt(i)) & 0x7fffffff;
            }
        }
        const flavorIdx = Math.abs(flavorSeed) % archFlavors.length;
        const flavor = archFlavors[flavorIdx];
        
        // ── Shared top HUD (floating panel) ──
        this.hud = GameHUD.create(this, {
            title: this.buildingName,
            subtitle: flavor,
            resources: {
                mag: this._magazineMax || 12,
                bits: this.state.bits || 0
            },
            combat: true,
            survivor: this.deployedSurvivor || null
        });
        
        // Wire legacy refs
        this.magText = this.hud._texts.mag;
        this.bitsText = this.hud._texts.bits;
        this.healthBar = this.hud._hpBar;
        if (this.hud._hpBar) this.hud.updateHP(this.state.health, CONFIG.player.health + ((this._eqStats && this._eqStats.maxHealth) || 0));
        this._locationShown = true;
        
        // Ammo HUD (bottom-right, above action bar)
        this._ammoHud = UIManager.createAmmoHud(this, CONFIG.width - 45, CONFIG.height - 65, { depth: uiDepth + 1 });
        this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
        
        // Power ammo toggle handler
        this._togglePowerAmmo = () => {
            const wasActive = this.state._powerAmmoActive;
            if (!wasActive && (this.state.powerAmmo || 0) <= 0) {
                AudioManager.emptyClip();
                Haptics.error();
                return;
            }
            this.state._powerAmmoActive = !wasActive;
            // Immediate visual feedback BEFORE reload spinner
            if (this._ammoHud) this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
            const blurb = wasActive ? 'Loading Regular Ammo' : 'Loading Power Ammo';
            this._startReload(blurb);
        };
        
        // Inventory button (bottom-right action bar)
        this.invBtn = GameHUD.createActionButton(this, 288, CONFIG.height - 29, {
            iconKey: 'ui_icon_backpack', label: 'INV', depth: uiDepth
        });
        
        // Consumable quick-use button
        this.consBtn = GameHUD.createActionButton(this, 248, CONFIG.height - 29, {
            iconKey: 'ui_icon_heal', label: 'USE', depth: uiDepth
        });
        this.consIcon = this.consBtn._label;
        this.updateConsumableButton();
    }
    
    setupInput() {
        this.movePointer = null;
        this.moveAnchor = { x: 0, y: 0 };
        this.keys = this.input.keyboard.addKeys({ w:'W', s:'S', a:'A', d:'D' });
        
        this.input.on('pointerdown', (p) => {
            if (this.inventoryUI) return;
            
            // Check inventory button (bottom-right action bar)
            const invDist = Phaser.Math.Distance.Between(p.x, p.y, 288, CONFIG.height - 29);
            if (invDist < 22) {
                this.openInventory();
                return;
            }
            
            // Check consumable button
            const consDist = Phaser.Math.Distance.Between(p.x, p.y, 248, CONFIG.height - 29);
            if (consDist < 22) {
                this.quickUseConsumable();
                return;
            }
            
            // Tap-to-interact on highlighted world objects
            if (InteractHighlight.getTarget(this) && this.nearestInteract) {
                const cam = this.cameras.main;
                const wx = p.x + (cam.scrollX || 0);
                const wy = p.y + (cam.scrollY || 0);
                if (InteractHighlight.checkTap(this, wx, wy, 55)) {
                    AudioManager.uiClick();
                    Haptics.light();
                    if (this.nearestInteract.type === 'exit') {
                        this.exitBuilding();
                    } else if (this.nearestInteract.type === 'loot') {
                        this.collectLoot(this.nearestInteract.target);
                    } else if (this.nearestInteract.type === 'door') {
                        this.enterDoor(this.nearestInteract.target);
                    }
                    return;
                }
            }
            this.movePointer = p;
            this.moveAnchor = { x: p.x, y: p.y };
        });
        
        this.input.on('pointermove', (p) => {
            if (this.movePointer && p.id === this.movePointer.id) {
                const dx = p.x - this.moveAnchor.x;
                const dy = p.y - this.moveAnchor.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                if (dist > 3) {
                    const f = Math.min(dist / 40, 1);
                    this.moveDir = { x: (dx/dist)*f, y: (dy/dist)*f };
                    if (dist > 60) {
                        this.moveAnchor.x = p.x - (dx/dist)*40;
                        this.moveAnchor.y = p.y - (dy/dist)*40;
                    }
                } else {
                    this.moveDir = { x: 0, y: 0 };
                }
            }
        });
        
        this.input.on('pointerup', (p) => {
            if (this.movePointer && p.id === this.movePointer.id) {
                this.movePointer = null;
                this.moveDir = { x: 0, y: 0 };
            }
        });
    }
    
    update() {
        // Pause gameplay when inventory UI is open
        if (this.inventoryUI) return;
        
        // Y-based depth sorting — player renders behind furniture below them
        if (this.player) {
            this.player.setDepth(10 + this.player.y * 0.05);

        // Sub-room roof occlusion — fade when player enters
        if (this.subRooms) {
            const px = this.player.x, py = this.player.y;
            // Determine which room the player is in
            let currentRoom = null;
            for (const sr of this.subRooms) {
                const inside = px > sr.L + 5 && px < sr.R - 5 && py > sr.T + 5 && py < sr.B - 5;
                const targetAlpha = inside ? 0 : 1;
                if (inside) currentRoom = sr.name;
                if (sr.roofVisible !== !inside) {
                    sr.roofVisible = !inside;
                    this.tweens.add({ targets: sr.roof, alpha: targetAlpha, duration: 200 });
                }
            }
            // Update room name HUD — show on transition, then fade
            const roomName = currentRoom || null;
            if (roomName !== this._currentRoomName) {
                this._currentRoomName = roomName;
                if (roomName && this._roomLabel) {
                    this._roomLabel.setText(roomName);
                    this._roomLabel.setAlpha(0);
                    // Kill any existing room label tweens
                    this.tweens.killTweensOf(this._roomLabel);
                    this.tweens.add({
                        targets: this._roomLabel, alpha: 0.9, duration: 400, ease: 'Sine.easeIn',
                        onComplete: () => {
                            this.time.delayedCall(2000, () => {
                                this.tweens.add({ targets: this._roomLabel, alpha: 0, duration: 1000, ease: 'Sine.easeOut' });
                            });
                        }
                    });
                }
            }
        }
        
        // South wall occlusion fade — walls become transparent when player is behind them
        if (this._occlusionWalls) {
            const px = this.player.x, py = this.player.y;
            this._occlusionWalls.forEach(ow => {
                const inX = px > ow.left - 10 && px < ow.right + 10;
                let behindness = 0;
                if (ow.facing === 'south' && inX && py < ow.groundY && py > ow.visualTop - 20) {
                    const dist = ow.groundY - py;
                    const wallH = ow.groundY - ow.visualTop;
                    behindness = Math.min(1, dist / Math.max(1, wallH));
                }
                const targetAlpha = behindness > 0.15 ? Math.max(0.2, 1 - behindness * 0.7) : 1.0;
                ow.parts.forEach(p => { p.alpha += (targetAlpha - p.alpha) * 0.18; });
            });
        }
        }
        
        // Stun check (tripwire, weak floor)
        if (this._stunned) {
            this.player.setVelocity(0, 0);
            this.updateInteriorEnemies();
            return;
        }
        
        // Keyboard movement
        let vx = this.moveDir.x, vy = this.moveDir.y;
        if (this.keys.a.isDown) vx -= 1;
        if (this.keys.d.isDown) vx += 1;
        if (this.keys.w.isDown) vy -= 1;
        if (this.keys.s.isDown) vy += 1;
        const len = Math.sqrt(vx*vx + vy*vy);
        if (len > 1) { vx /= len; vy /= len; }
        
        const intSpeedMult = (this._eqStats && this._eqStats.moveSpeed) ? this._eqStats.moveSpeed / 100 : 1;
        const intSurvSpeed = this.state.survivorMods?.speedMultiplier || 1;
        this.player.setVelocity(vx * CONFIG.player.speed * intSpeedMult * intSurvSpeed * (this._channelSpeedMult || 1), vy * CONFIG.player.speed * intSpeedMult * intSurvSpeed * (this._channelSpeedMult || 1));
        
        // Snap player position to integer pixels every frame to eliminate sub-pixel jitter
        this.player.x = Math.round(this.player.x);
        this.player.y = Math.round(this.player.y);
        
        // Update player animation based on movement
        SpriteManager.updatePlayerAnimation(this.player, vx, vy, this);
        
        // Reload text follows player
        if (this._reloadText && this.player) {
            this._reloadText.x = this.player.x;
            this._reloadText.y = this.player.y - 25;
        }
        
        // Combat systems
        this.updateInteriorEnemies();
        this.interiorFindTarget();
        this.interiorUpdateAim();
        this.interiorAutoShoot();
        this.interiorAutoMelee();
        
        // DOT + Signature ticks (use game loop delta since InteriorScene has no delta param)
        const intDelta = this.game.loop.delta || 16;
        DOTManager.update(this, intDelta, (e) => this.intKillEnemy(e));
        DOTSystem.updatePlayer(this, intDelta);
        ConsumableSystem.update(this, intDelta, this.player);
        
        // Cube Metabolized: passive HP regen (mark conditional)
        const _intCubeRegen = this.state.survivorMods?.conditionals;
        if (_intCubeRegen && _intCubeRegen.cubeRegenRate > 0) {
            this._cubeRegenTimer = (this._cubeRegenTimer || 0) + intDelta;
            if (this._cubeRegenTimer >= _intCubeRegen.cubeRegenRate) {
                this._cubeRegenTimer -= _intCubeRegen.cubeRegenRate;
                const _intEqs = this._eqStats || ItemManager.getEquipmentStats(this.state.equipment);
                const _intCrMaxHP = CONFIG.player.health + (_intEqs.maxHealth || 0);
                if (this.state.health < _intCrMaxHP && this.state.health > 0) {
                    this.state.health = Math.min(_intCrMaxHP, this.state.health + (_intCubeRegen.cubeRegenAmount || 1));
                }
            }
        }
        DOTManager.renderEnemyDebuffs(this);
        DOTSystem.renderDebuffHUD(this);
        if (this._eqStats && this._eqStats.signatures) {
            const parasitic = this._eqStats.signatures.find(s => s.effect === 'parasiticRounds');
            if (parasitic) SignatureEffects.updateParasiticRounds(this, this.state, parasitic);
        }
        
        // Player buff/debuff status icons
        // PlayerStatusIcons.update(this); // disabled — HUD shows buffs
        
        // Gym buff timer (runs outside safehouse)
        if (!this._gymBuffChecked) {
            try { const sd = SaveManager.load(); this._gymBuffLocal = sd && sd.gymBuff && sd.gymBuff.remainingMs > 0 ? sd.gymBuff : null; } catch(e) {}
            this._gymBuffChecked = true; this._gymSyncTimer = 0;
        }
        if (this._gymBuffLocal) {
            this._gymBuffLocal.remainingMs -= intDelta;
            this._gymSyncTimer = (this._gymSyncTimer || 0) + intDelta;
            if (this._gymBuffLocal.remainingMs <= 0) {
                this._gymBuffLocal = null;
                try { const sd = SaveManager.load(); if (sd) { sd.gymBuff = null; SaveManager.save(sd); } } catch(e) {}
            } else if (this._gymSyncTimer > 5000) {
                this._gymSyncTimer = 0;
                try { const sd = SaveManager.load(); if (sd) { sd.gymBuff = this._gymBuffLocal; SaveManager.save(sd); } } catch(e) {}
            }
        }
        this.checkInteractions();
        this.updateDormantEnemies();
        this.updateInteriorHUD();
        DynamicShadows.update(this);
        CombatSystem.updateFlairEffects(this);
    }
    
    checkInteractions() {
        const exitDist = Phaser.Math.Distance.Between(this.player.x, this.player.y, this.exitDoor.x, this.exitDoor.y);
        
        // Reset all highlights first
        this.lootObjects.forEach(obj => {
            if (!obj.looted && obj.highlight) {
                obj.highlight.setVisible(false);
            }
        });
        
        // Find nearest lootable object (only from revealed rooms + main room)
        let nearLoot = null;
        let nearDist = Infinity;
        this.lootObjects.forEach(obj => {
            if (obj.looted || !obj.visible) return;
            const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, obj.x, obj.y);
            if (d < 50 && d < nearDist) {
                nearLoot = obj;
                nearDist = d;
            }
        });
        
        // Find nearest unopened interior door
        let nearDoor = null;
        let nearDoorDist = Infinity;
        this.interiorDoors.forEach(door => {
            if (door.opened) return;
            const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, door.x, door.y);
            if (d < 45 && d < nearDoorDist) {
                nearDoor = door;
                nearDoorDist = d;
            }
        });
        
        // Show highlight on nearest lootable
        if (nearLoot && nearLoot.highlight) {
            nearLoot.highlight.setVisible(true);
        }
        
        // Priority: exit > interior door > loot — highlight the target
        if (exitDist < 45) {
            InteractHighlight.show(this, this.exitDoor, 'EXIT', { padding: 5 });
            this.nearestInteract = { type: 'exit' };
        } else if (nearDoor) {
            InteractHighlight.show(this, nearDoor, nearDoor.name || 'ENTER', { padding: 5 });
            this.nearestInteract = { type: 'door', target: nearDoor };
        } else if (nearLoot) {
            InteractHighlight.show(this, nearLoot, nearLoot.furnitureLabel || 'SEARCH', { padding: 4 });
            this.nearestInteract = { type: 'loot', target: nearLoot };
        } else {
            InteractHighlight.hide(this);
            this.nearestInteract = null;
        }
    }
    
    collectLoot(obj) {
        if (obj.looted) return;
        
        // Persist loot collection
        if (this.buildingId && obj._lootIdx !== undefined) {
            if (!BUILDING_STATE[this.buildingId]) BUILDING_STATE[this.buildingId] = {};
            if (!BUILDING_STATE[this.buildingId].lootedIndices) BUILDING_STATE[this.buildingId].lootedIndices = [];
            BUILDING_STATE[this.buildingId].lootedIndices.push(obj._lootIdx);
        }
        
        // === CURRENCY DROPS (auto-pickup, always collected) ===
        if (!obj._currencyCollected) {
            obj._currencyCollected = true;
            let gainedBits = 0;
            let gainedAmmo = 0;
            let gainedHealth = 0;
            let gainedFuel = 0;
            
            obj.lootItems.forEach(item => {
                if (item.name === 'Power Ammo') {
                    const amt = Phaser.Math.Between(3, 6);
                    this.state.powerAmmo = (this.state.powerAmmo || 0) + amt;
                    gainedAmmo += amt;
                } else if (item.name === 'Bandage') {
                    const amt = Phaser.Math.Between(5, 10);
                    this.state.health = Math.min(this.state.health + amt, CONFIG.player.health);
                    gainedHealth += amt;
                } else if (item.name === 'Ration') {
                    const amt = Phaser.Math.Between(3, 6);
                    this.state.health = Math.min(this.state.health + amt, CONFIG.player.health);
                    gainedHealth += amt;
                } else {
                    const amt = Phaser.Math.Between(1, 3);
                    this.state.bits += amt;
                    gainedBits += amt;
                }
            });
            
            // Show currency gain popups
            let yOffset = 0;
            if (gainedHealth > 0) {
                this.showLootGain(obj.x, obj.y - yOffset, `+${gainedHealth} HP`, 0x44dd44);
                yOffset += 18;
            }
            if (gainedAmmo > 0) {
                this.showLootGain(obj.x, obj.y - yOffset, `+${gainedAmmo} AMMO`, 0xddaa44);
                yOffset += 18;
            }
            if (gainedBits > 0) {
                this.showLootGain(obj.x, obj.y - yOffset, `+${gainedBits} BITS`, 0xaaccee);
                yOffset += 18;
            }
            if (gainedFuel > 0) {
                this.showLootGain(obj.x, obj.y - yOffset, `+${gainedFuel} FUEL`, 0xdd8844);
            }
            
            // Update UI
            const intMaxHp = CONFIG.player.health + ((this._eqStats && this._eqStats.maxHealth) || 0);
            if (this.hud) {
                this.hud.updateHP(this.state.health, intMaxHp);
            } else if (this.healthBar) {
                const healthWidth = 106 * (this.state.health / intMaxHp);
                this.healthBar.setDisplaySize(healthWidth, 12);
                this.healthBar.setX(27 + healthWidth/2);
            }
            if (this.bitsText) this.bitsText.setText(`${this.state.bits || 0}`);
        }
        
        // === TANGIBLE ITEM DROP ===
        // Generate once, store on obj, re-open if still has items
        if (!obj._tangibleRolled) {
            obj._tangibleRolled = true;
            if (Math.random() < 0.30) {
                const locConfig = this.locationType ? CONFIG.locations[this.locationType] : null;
                const containerTable = locConfig?.lootTable || ('container_' + (this.archetypeName || 'commercial'));
                const intEqLoot = ItemManager.getEquipmentStats(this.state.equipment);
                const intLuck = intEqLoot.lootLuck || 0;
                const intReach = this.state?.reach || 1;
                const result = ItemManager.rollLootTable(containerTable, intLuck, intReach, null, locConfig?.lootModifiers);
                if (result) {
                    let item;
                    if (typeof result === 'string') {
                        item = ItemManager.createItem(result);
                    } else {
                        item = result;
                    }
                    if (item) {
                        obj._containerInv = [item];
                    }
                }
            }
        }
        
        // If there's a tangible item, open container UI
        if (obj._containerInv && obj._containerInv.some(i => i !== null)) {
            // Track container opened
            const gs = this.scene.get('GameScene');
            if (gs && gs._runStats) gs._runStats.containersOpened++;
            
            this.openContainerUI(obj._containerInv, () => {
                // After closing, check if item was taken
                if (!obj._containerInv.some(i => i !== null)) {
                    obj.looted = true;
                    obj.setAlpha(0.7);
                    if (obj.highlight) { obj.highlight.destroy(); obj.highlight = null; }
                }
            });
        } else {
            // No tangible item — fully looted
            obj.looted = true;
            obj.setAlpha(0.7);
            if (obj.highlight) { obj.highlight.destroy(); obj.highlight = null; }
        }
    }
    
    openContainerUI(containerInv, onClose) {
        if (this.inventoryUI) return;
        
        this.inventoryUI = new InventoryUI(
            this,
            containerInv,
            this.state.backpack,
            'FOUND',
            'BACKPACK',
            () => {
                this.inventoryUI = null;
                if (onClose) onClose();
            }
        );
    }
    
    openInventory() {
        if (this.inventoryUI) return;
        this.inventoryUI = new InventoryUI(
            this,
            this.state.backpack,
            this.state.equipment,
            () => {
                this.inventoryUI = null;
                // Refresh backpack + holster visual after equip changes
                if (this.player && this.player.backpack) {
                    SpriteManager.updateBackpackSprite(this, this.player.backpack, this.state.backpack, this.player.lastDir || 'down');
                }
                this.updateConsumableButton();
                // Refresh magazine/reload from potentially swapped weapon
                const eqStats = ItemManager.getEquippedStats(this.state);
                const newMag = eqStats.mag || 10;
                if (newMag !== this._magazineMax) {
                    this._magazineMax = newMag;
                    this._magazine = Math.min(this._magazine, this._magazineMax);
                }
                this._reloadTime = Math.max(500, 3000 - (eqStats.reload || 50) * 25);
                if (this._ammoHud) this._ammoHud.update(this._magazine, this.state._powerAmmoActive, this.state.powerAmmo);
            }
        );
    }
    
    quickUseConsumable() {
        if (ConsumableSystem.isChanneling()) return;
        
        let item = null;
        let fromEquipped = false;
        if (this.state.equipment && this.state.equipment.consumable) {
            item = this.state.equipment.consumable;
            fromEquipped = true;
        } else {
            const idx = ItemManager.findFirstConsumable(this.state.backpack);
            if (idx === -1) return;
            item = this.state.backpack[idx];
        }
        if (!item) return;
        
        // Grenades require lock-on
        if (item.effect === 'grenade' && (!this.lockedTarget || !this.lockedTarget.active)) {
            Blurbs.show(this, this.player, 'No target locked!', { color: '#ff4444' });
            return;
        }
        
        const used = ConsumableSystem.use(this, this.state, item, this.player);
        if (used) {
            if (fromEquipped) {
                this.state.equipment.consumable = null;
            } else {
                const idx = this.state.backpack.indexOf(item);
                if (idx >= 0) ItemManager.removeOneFromStack(this.state.backpack, idx);
            }
        }
        
        this.updateConsumableButton();
    }
    
    updateConsumableButton() {
        if (!this.consIcon) return;
        const eq = this.state.equipment;
        if (eq && eq.consumable) {
            this.consIcon.setText(eq.consumable.icon || 'USE');
        } else {
            const idx = ItemManager.findFirstConsumable(this.state.backpack);
            if (idx >= 0) {
                this.consIcon.setText(this.state.backpack[idx].icon || 'USE');
            } else {
                this.consIcon.setText('·');
            }
        }
    }
    
    showLootGain(x, y, text, color) {
        const txt = this.add.text(x, y - 10, text, { 
            fontSize: uiPx(10), 
            fill: '#' + color.toString(16).padStart(6, '0'),
            fontStyle: 'bold' 
        }).setOrigin(0.5).setDepth(7.5);
        
        this.tweens.add({
            targets: txt,
            y: y - 35,
            alpha: 0,
            duration: 600,
            onComplete: () => txt.destroy()
        });
    }
    
    exitBuilding() {
        ConsumableSystem.cleanupScene(this);
        // Persist magazine state through transition
        if (this._magazine !== undefined) this.state._magazine = this._magazine;
        
        if (this.isSubRoom && this.parentData) {
            SceneTransition.fadeTo(this, 'InteriorScene', {
                ...this.parentData,
                playerState: this.state
            }, { duration: 300 });
        } else {
            SceneTransition.fadeTo(this, 'GameScene', {
                playerState: this.state,
                savedPlayerPos: this.savedPlayerPos,
                savedRouteSeed: this.savedRouteSeed,
                fromMap: this.fromMap,
                destinationNode: this.destinationNode,
                currentNodeId: this.currentNodeId,
                previousNodeId: this.previousNodeId,
                completedNodes: this.completedNodes,
                traveledRoutes: this.traveledRoutes,
                mapSeed: this.mapSeed,
                currentRow: this.currentRow,
                locationType: this.locationType,
                lootMultiplier: this.lootMultiplier,
            }, { duration: 300 });
        }
    }
}
