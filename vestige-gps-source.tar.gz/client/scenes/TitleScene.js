// Vestige GPS — TitleScene
// Extracted from monolith lines 35697-40314
// Imports will be wired in integration pass

import { SaveManager } from '../../core/saveManager.js';
import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { AudioManager } from '../audioManager.js';
import { TutorialManager } from '../tutorialManager.js';
import { UIAtlas } from '../uiAtlas.js';
import { BiomeSelectScene } from './BiomeSelectScene.js';
import { HavenScene } from './HavenScene.js';
import { SafehouseScene } from './SafehouseScene.js';


export class TitleScene extends Phaser.Scene {
    constructor() { super('TitleScene'); }
    
    create() {
        const W = CONFIG.width, H = CONFIG.height;
        
        // Build UI textures (available to all scenes)
        UIAtlas.build(this);
        
        // Initialize core systems
        TutorialManager.loadFromSave();
        
        // Resume AudioContext on first user gesture and start menu theme
        this.input.once('pointerdown', () => { 
            AudioManager.resume(); 
            AudioManager.playMenuTheme();
        });
        // Stop any biome ambient audio
        try { AudioManager.stopAmbient(500); } catch(e) {}
        // If returning to title with AudioContext already active, start immediately
        if (AudioManager._ctx && AudioManager._ctx.state === 'running') {
            AudioManager.playMenuTheme();
        }
        
        // Check for existing save via SaveManager
        let hasSave = false;
        try {
            const data = SaveManager.load();
            hasSave = data && data.stash && (data.stash.bits > 0 || data.level > 1 || 
                (data.equipment && (data.equipment.weapon || data.equipment.melee)));
        } catch(e) {}
        
        // === BACKGROUND — layered gradient sky ===
        for (let i = 0; i < H; i++) {
            const t = i / H;
            let r, g, b;
            if (t < 0.3) { r = Math.floor(6+t*15); g = Math.floor(6+t*12); b = Math.floor(14+t*20); }
            else if (t < 0.45) { const ht=(t-0.3)/0.15; r=Math.floor(11+ht*18); g=Math.floor(10+ht*10); b=Math.floor(16+ht*-2); }
            else { const gt=(t-0.45)/0.55; r=Math.floor(22-gt*8); g=Math.floor(18-gt*6); b=Math.floor(14-gt*4); }
            this.add.rectangle(W/2, i, W, 1, Phaser.Display.Color.GetColor(r, g, b));
        }
        
        // === MOON ===
        const moonX = W*0.78, moonY = H*0.1;
        this.add.circle(moonX, moonY, 12, 0xdddcc8, 0.15).setDepth(1);
        this.add.circle(moonX+3, moonY-2, 10, 0x0a0a12, 0.9).setDepth(1);
        const moonHaze = this.add.circle(moonX, moonY, 40, 0xccccaa, 0.03).setDepth(0);
        this.tweens.add({ targets: moonHaze, alpha: 0.015, scaleX: 1.1, scaleY: 1.1, duration: 3000, yoyo: true, repeat: -1 });
        
        // === STARS ===
        for (let i = 0; i < 60; i++) {
            const sx = Phaser.Math.Between(5,W-5), sy = Phaser.Math.Between(5,H*0.38);
            const bright = Math.random()<0.1, size = bright?2:(Math.random()<0.3?1.5:1);
            const a = bright?(0.5+Math.random()*0.4):(0.15+Math.random()*0.35);
            const c = bright?0xeeeedd:(Math.random()<0.3?0xbbaaaa:0xaaaacc);
            const star = this.add.circle(sx, sy, size, c, a).setDepth(1);
            this.tweens.add({ targets: star, alpha: a*(bright?0.4:0.2), duration: 1200+Math.random()*2500, yoyo: true, repeat: -1, delay: Math.random()*3000 });
        }
        
        const horizonY = H * 0.42;
        
        // === MOUNTAINS ===
        const mp = [0,-20,40,-45,70,-30,100,-55,130,-35,155,-60,185,-25,210,-50,240,-35,270,-55,300,-30,330,-40,360,-20];
        for (let i = 0; i < mp.length-2; i+=2) {
            const g = this.add.graphics().setDepth(1);
            g.fillStyle(0x0c0c14, 0.8);
            g.fillTriangle(mp[i], horizonY+mp[i+1], mp[i+2], horizonY+mp[i+3], (mp[i]+mp[i+2])/2, horizonY+10);
        }
        
        // === CITYSCAPE (isometric silhouettes) ===
        [{x:15,w:22,h:40},{x:42,w:12,h:55},{x:60,w:28,h:35},{x:95,w:15,h:70},{x:115,w:20,h:45},
         {x:140,w:12,h:80},{x:160,w:25,h:38},{x:200,w:14,h:65},{x:222,w:30,h:42},{x:258,w:10,h:75},
         {x:278,w:22,h:48},{x:310,w:16,h:58},{x:335,w:24,h:35},{x:355,w:12,h:50}].forEach(b => {
            const by = horizonY-b.h;
            const bSideW = Math.max(2, b.w * 0.12);
            // Side face (right edge)
            this.add.rectangle(b.x + b.w/2 - bSideW/2, by+b.h/2, bSideW, b.h, 0x08080e).setDepth(2);
            // Main face
            this.add.rectangle(b.x - bSideW/2, by+b.h/2, b.w - bSideW, b.h, 0x0d0d16).setDepth(2);
            // Roof cap
            this.add.rectangle(b.x - bSideW/2, by, b.w - bSideW + 2, 2, 0x101018).setDepth(2.5);
            if (Math.random()>0.3) this.add.rectangle(b.x+(Math.random()>0.5?1:-1)*(b.w/2-4), by+5, Phaser.Math.Between(3,b.w*0.4), Phaser.Math.Between(5,18), 0x0a0a12).setDepth(3);
            for (let f=0; f<Math.floor(b.h/10); f++) {
                if (Math.random()>0.85) this.add.rectangle(b.x+Phaser.Math.Between(-b.w/3,b.w/3), by+8+f*10, 2, 2, Math.random()>0.5?0xaa8833:0x1a1a22, 0.4).setDepth(3);
            }
        });
        // Near ruins (isometric)
        [{x:-5,w:35,h:90},{x:25,w:20,h:65},{x:W+5,w:30,h:85},{x:W-20,w:22,h:70}].forEach(r => {
            const rSideW = Math.max(2, r.w * 0.12);
            this.add.rectangle(r.x + r.w/2 - rSideW/2, horizonY-r.h+20+r.h/2, rSideW, r.h, 0x0a0a10).setDepth(4);
            this.add.rectangle(r.x - rSideW/2, horizonY-r.h+20+r.h/2, r.w - rSideW, r.h, 0x111118).setDepth(4);
            for (let j=0;j<3;j++) this.add.rectangle(r.x+Phaser.Math.Between(-r.w/3,r.w/3), horizonY-r.h+20-Phaser.Math.Between(2,8), 1, Phaser.Math.Between(4,12), 0x1a1a22, 0.5).setDepth(4);
        });
        
        // === GROUND ===
        this.add.rectangle(W/2, horizonY+80, W, 160, 0x1a1814).setDepth(5);
        this.add.rectangle(W/2, horizonY+1, W, 2, 0x2a2420, 0.3).setDepth(5);
        for (let i=0;i<30;i++) this.add.rectangle(Phaser.Math.Between(5,W-5), horizonY+Phaser.Math.Between(5,80), Phaser.Math.Between(1,4), Phaser.Math.Between(1,2), 0x1e1c14, 0.3).setDepth(5);
        for (let i=0;i<8;i++) { const g=this.add.graphics().setDepth(5); g.lineStyle(1,0x22201a,0.3); const lx=Phaser.Math.Between(20,W-20),ly=horizonY+Phaser.Math.Between(15,70); g.beginPath();g.moveTo(lx,ly);g.lineTo(lx+Phaser.Math.Between(-15,15),ly+Phaser.Math.Between(5,15));g.strokePath(); }
        
        // === HORIZONTAL ROAD (left to right) ===
        const roadY = horizonY + 30;
        this.add.rectangle(W/2, roadY, W, 22, 0x1e1c16, 0.4).setDepth(5);
        this.add.rectangle(W/2, roadY-11, W, 1, 0x2a2620, 0.2).setDepth(5);
        this.add.rectangle(W/2, roadY+11, W, 1, 0x2a2620, 0.2).setDepth(5);
        for (let i=0; i<20; i++) this.add.rectangle(i*20+5, roadY, 8, 1, 0x3a3628, 0.25).setDepth(5);
        
        // === SAFEHOUSE (right side, off road) ===
        const shX = W*0.75, shY = roadY - 30;
        this.add.rectangle(shX, shY+18, 80, 6, 0x161410).setDepth(6);
        this.add.rectangle(shX, shY, 72, 42, 0x1e1a16).setDepth(6);
        for (let p=0;p<6;p++) this.add.rectangle(shX, shY-16+p*7, 68, 1, 0x242018, 0.3).setDepth(6);
        const roofG = this.add.graphics().setDepth(7);
        roofG.fillStyle(0x1a1610,1); roofG.fillTriangle(shX, shY-32, shX-44, shY-8, shX+44, shY-8);
        roofG.fillStyle(0x222018,1); roofG.fillRect(shX-44, shY-10, 88, 3);
        this.add.rectangle(shX+22, shY-38, 8, 16, 0x1a1610).setDepth(7);
        this.add.rectangle(shX+22, shY-46, 10, 3, 0x201c14).setDepth(7);
        for (let i=0;i<4;i++) { const sm=this.add.circle(shX+22,shY-50,3,0x555544,0.06).setDepth(7); this.tweens.add({targets:sm,x:shX+22+Phaser.Math.Between(-15,-5),y:shY-50-Phaser.Math.Between(20,50),alpha:0,scaleX:2.5,scaleY:2,duration:3000+Math.random()*2000,delay:i*800,repeat:-1}); }
        // Lit window
        this.add.rectangle(shX-14,shY-2,12,14,0x12100c).setDepth(7);
        this.add.rectangle(shX-14,shY-2,10,12,0xdd9944,0.6).setDepth(7);
        this.add.rectangle(shX-14,shY-2,10,1,0x14120e,0.8).setDepth(7);
        this.add.rectangle(shX-14,shY-2,1,12,0x14120e,0.8).setDepth(7);
        const gl1=this.add.circle(shX-14,shY-2,30,0xcc8833,0.06).setDepth(6);
        const gl2=this.add.circle(shX-14,shY-2,16,0xddaa44,0.04).setDepth(6);
        this.tweens.add({targets:[gl1,gl2],alpha:'-=0.02',duration:2000,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
        const spG=this.add.graphics().setDepth(5); spG.fillStyle(0xcc8833,0.04); spG.fillTriangle(shX-20,shY+10,shX-8,shY+10,shX-14,shY+35);
        // Dark window
        this.add.rectangle(shX+14,shY-2,10,12,0x12100c).setDepth(7);
        this.add.rectangle(shX+14,shY-2,8,10,0x161412,0.8).setDepth(7);
        // Door
        this.add.rectangle(shX+1,shY+10,12,20,0x14120e).setDepth(7);
        this.add.rectangle(shX+4,shY+10,1,1,0x8a7a55,0.6).setDepth(7);
        this.add.rectangle(shX,shY+20,30,2,0x1a1610).setDepth(6);
        // Driveway
        const drG=this.add.graphics().setDepth(5);drG.fillStyle(0x1e1c16,0.3);drG.fillRect(shX-10,roadY-11,20,shY+20-roadY+11);
        // Vehicle
        this.add.rectangle(shX-30,roadY,20,10,0x2a2822).setDepth(6);
        this.add.rectangle(shX-36,roadY-1,6,7,0x222018).setDepth(6);
        this.add.circle(shX-38,roadY+5,2.5,0x111110).setDepth(6);
        this.add.circle(shX-23,roadY+5,2.5,0x111110).setDepth(6);
        // Fence
        for(let i=0;i<4;i++){const fx=shX-50+i*35,fy=shY+28;this.add.rectangle(fx,fy,2,8,0x2a2620,0.5).setDepth(6);if(i<3)this.add.rectangle(fx+17,fy-1,32,1,0x2a2620,0.3).setDepth(6);}
        // Power lines
        this.add.rectangle(50,horizonY-10,2,30,0x1a1816,0.4).setDepth(4);
        this.add.rectangle(50,horizonY-24,12,1,0x1a1816,0.3).setDepth(4);
        const wG=this.add.graphics().setDepth(4);wG.lineStyle(1,0x1a1816,0.2);wG.beginPath();wG.moveTo(55,horizonY-24);wG.lineTo(75,horizonY-10);wG.lineTo(80,horizonY+5);wG.strokePath();
        this.add.rectangle(W-40,horizonY-5,2,25,0x1a1816,0.3).setDepth(4);
        
        // === WANDERING HORDE SILHOUETTES ===
        for (let h = 0; h < 3; h++) {
            const hordeY = horizonY + Phaser.Math.Between(2, 14);
            const cnt = Phaser.Math.Between(4, 7);
            const hc = this.add.container(Phaser.Math.Between(-40, -10), hordeY).setDepth(3).setAlpha(0.2 + Math.random()*0.1);
            for (let f = 0; f < cnt; f++) {
                const fx = f * Phaser.Math.Between(4, 7), fy = Phaser.Math.Between(-2, 2);
                hc.add(this.add.rectangle(fx, fy, 2, 4, 0x1a1818));
                hc.add(this.add.circle(fx, fy-3, 1.5, 0x1a1818));
            }
            this.tweens.add({
                targets: hc, x: W+40,
                duration: (W+80) / (8+Math.random()*6) * 1000,
                delay: h*8000 + Math.random()*10000, repeat: -1,
                onRepeat: () => { hc.x = Phaser.Math.Between(-40,-15); hc.y = horizonY+Phaser.Math.Between(2,14); hc.setAlpha(0.15+Math.random()*0.15); }
            });
            hc.each(child => {
                this.tweens.add({ targets: child, y: child.y+(Math.random()>0.5?-1:1), duration: 400+Math.random()*300, yoyo: true, repeat: -1, delay: Math.random()*500 });
            });
        }
        
        // === ASH PARTICLES ===
        for(let i=0;i<20;i++){const cl=Math.random()<0.3,px=Phaser.Math.Between(0,W),py=Phaser.Math.Between(H*0.15,H*0.65);const pa=cl?(0.08+Math.random()*0.08):(0.12+Math.random()*0.12);const p=this.add.circle(px,py,cl?Phaser.Math.Between(2,3):1,cl?0x776655:0x998877,pa).setDepth(cl?8:6);this.tweens.add({targets:p,x:px+Phaser.Math.Between(-80,-30),y:py+Phaser.Math.Between(-20,20),alpha:0,duration:3000+Math.random()*4000,delay:Math.random()*4000,repeat:-1,onRepeat:()=>{p.x=Phaser.Math.Between(W+5,W+50);p.y=Phaser.Math.Between(H*0.15,H*0.65);p.alpha=pa;}});}
        
        // === DISTANT FIRES ===
        [45,135,225,310].forEach(fx=>{const fy=horizonY-Phaser.Math.Between(0,12);const f=this.add.circle(fx,fy,3+Math.random()*3,0xcc4422,0.04+Math.random()*0.04).setDepth(2);this.tweens.add({targets:f,alpha:0.01,scaleX:0.6,scaleY:0.6,duration:1000+Math.random()*1500,yoyo:true,repeat:-1});});
        
        // === GUNSHOT FLASHES (distant city) ===
        this.time.addEvent({ delay: 3000, loop: true, callback: () => {
            const gx=Phaser.Math.Between(40,W-40), gy=horizonY-Phaser.Math.Between(5,60);
            const fl=this.add.circle(gx,gy,3,0xffcc44,0.4).setDepth(3);
            this.tweens.add({targets:fl,alpha:0,scaleX:0.3,scaleY:0.3,duration:100,onComplete:()=>fl.destroy()});
            if(Math.random()>0.5) this.time.delayedCall(80+Math.random()*120,()=>{
                const f2=this.add.circle(gx+Phaser.Math.Between(-3,3),gy+Phaser.Math.Between(-2,2),2,0xffaa33,0.3).setDepth(3);
                this.tweens.add({targets:f2,alpha:0,duration:80,onComplete:()=>f2.destroy()});
            });
            if(Math.random()>0.8) for(let s=0;s<3;s++) this.time.delayedCall(200+s*100,()=>{
                const f3=this.add.circle(gx+Phaser.Math.Between(-8,8),gy+Phaser.Math.Between(-3,3),2,0xffbb44,0.25).setDepth(3);
                this.tweens.add({targets:f3,alpha:0,duration:80,onComplete:()=>f3.destroy()});
            });
        }});
        
        // === RARE DISTANT EXPLOSIONS ===
        this.time.addEvent({ delay: 15000+Math.random()*20000, loop: true, callback: () => {
            const ex=Phaser.Math.Between(50,W-50), ey=horizonY-Phaser.Math.Between(0,30);
            const boom=this.add.circle(ex,ey,8,0xff8833,0.3).setDepth(3);
            this.tweens.add({targets:boom,alpha:0,scaleX:3,scaleY:2.5,duration:600,onComplete:()=>boom.destroy()});
            this.time.delayedCall(200,()=>{
                const smoke=this.add.circle(ex,ey-5,5,0x554433,0.08).setDepth(3);
                this.tweens.add({targets:smoke,y:ey-30,alpha:0,scaleX:3,scaleY:3,duration:3000,onComplete:()=>smoke.destroy()});
            });
            const sf=this.add.rectangle(W/2,H/2,W,H,0xffaa44,0.015).setDepth(50);
            this.tweens.add({targets:sf,alpha:0,duration:400,onComplete:()=>sf.destroy()});
        }});
        
        // === TITLE — Canvas-drawn grim style ===
        const titleY = H * 0.13;
        this.buildGrimTitle();
        const vestigeTex = this.add.image(W/2, titleY, 'vestige_title').setDepth(10).setAlpha(0);
        const grimTex = this.add.image(W/2, titleY+42, 'grim_title').setDepth(10).setAlpha(0);
        const tagline = this.add.text(W/2, titleY+72, 'Nothing is permanent.', { fontFamily: CONFIG.font, fontSize: uiPx(11), fontStyle: 'italic', fill: '#665e50' }).setOrigin(0.5).setDepth(10).setAlpha(0);
        this.add.rectangle(W/2-65,titleY+60,50,1,0x665e50,0).setDepth(10);
        this.add.rectangle(W/2+65,titleY+60,50,1,0x665e50,0).setDepth(10);
        const diam = this.add.rectangle(W/2,titleY+60,5,5,0xaa7744,0).setDepth(10).setAngle(45);
        
        // === MENU ===
        const mY = H * 0.62, sp = 48;
        this.menuCont = this.add.container(0,0).setDepth(10).setAlpha(0);
        const mkBtn = (y,label,fs,fc,tc,w,h) => {
            const bg=this.add.rectangle(W/2,y,w,h,fc,1).setInteractive({useHandCursor:true});
            const bd=this.add.rectangle(W/2,y,w+4,h+4,0x44403a,0.5);
            const tx=this.add.text(W/2,y,label,{fontFamily:CONFIG.font,fontSize:fs,fontStyle:'bold',fill:tc}).setOrigin(0.5);
            this.menuCont.add([bd,bg,tx]);
            bg.on('pointerover',()=>bg.setFillStyle(Phaser.Display.Color.IntegerToColor(fc).brighten(15).color));
            bg.on('pointerout',()=>bg.setFillStyle(fc));
            return {bg,tx};
        };
        let cBtn; if(hasSave) cBtn=mkBtn(mY,'Continue Run',uiPx(18),0x8a7a55,'#1a1814',200,44);
        const nY=mY+(hasSave?sp:0);
        const nBtn=mkBtn(nY,hasSave?'New Run':'Begin',uiPx(16),hasSave?0x3a3630:0x8a7a55,hasSave?'#998877':'#1a1814',hasSave?160:200,hasSave?36:44);
        const tBtn=mkBtn(nY+sp,'Tutorial',uiPx(13),0x2a2824,'#887766',140,32);
        const sBtn=mkBtn(nY+sp+40,'Settings',uiPx(13),0x1e1c18,'#665e50',130,30);
        const hBtn=mkBtn(nY+sp+74,'Haven',uiPx(11),0x121a16,'#44aa66',120,26);
        const owBtn=mkBtn(nY+sp+106,'Overworld',uiPx(11),0x1a1218,'#aa66cc',120,26);
        const ver=this.add.text(W/2,H-16,'v0.21 — Early Development',{fontFamily:CONFIG.font,fontSize: uiPx(8),fill:'#2a2620'}).setOrigin(0.5).setDepth(10).setAlpha(0);
        
        // === FADE IN ===
        this.tweens.add({targets:vestigeTex,alpha:1,duration:1200,delay:300,ease:'Power2'});
        this.tweens.add({targets:grimTex,alpha:1,duration:900,delay:700});
        this.tweens.add({targets:tagline,alpha:0.7,duration:800,delay:1100});
        this.tweens.add({targets:diam,alpha:0.6,duration:600,delay:1000});
        this.tweens.add({targets:this.menuCont,alpha:1,duration:700,delay:1400});
        this.tweens.add({targets:ver,alpha:1,duration:500,delay:1800});
        
        // === INTERACTIONS ===
        if(cBtn) cBtn.bg.on('pointerdown',()=>{AudioManager.stopMusic(800);this.cameras.main.fadeOut(800,0,0,0);this.time.delayedCall(800,()=>this.scene.start('SafehouseScene'));});
        nBtn.bg.on('pointerdown',()=>{
            if(hasSave){this.showNewRunConfirm();}
            else{AudioManager.stopMusic(800);this.cameras.main.fadeOut(800,0,0,0);this.time.delayedCall(800,()=>this.scene.start('SafehouseScene'));}
        });
        tBtn.bg.on('pointerdown',()=>this.showTutorial());
        sBtn.bg.on('pointerdown',()=>{sBtn.tx.setFill('#ccbbaa');this.time.delayedCall(200,()=>sBtn.tx.setFill('#665e50'));});
        hBtn.bg.on('pointerdown',()=>{AudioManager.stopMusic(400);this.cameras.main.fadeOut(400,0,0,0);this.time.delayedCall(400,()=>this.scene.start('HavenScene',{playerState:{health:100,maxHealth:100,vehicleHealth:100,fuel:50,maxFuel:80,scrap:200,parts:50,meds:10,backpack:[],equipment:{}}}));});
        owBtn.bg.on('pointerdown',()=>{AudioManager.stopMusic(400);this.cameras.main.fadeOut(400,0,0,0);this.time.delayedCall(400,()=>this.scene.start('OverworldScene',{lat:0,lng:0}));});
    }
    
    buildGrimTitle() {
        // === VESTIGE — weathered serif with full distress ===
        const vW=320, vH=56;
        const vc=document.createElement('canvas'); vc.width=vW; vc.height=vH;
        const vx=vc.getContext('2d');
        vx.font='bold 48px Georgia,"Times New Roman",serif';
        vx.textAlign='center'; vx.textBaseline='middle';
        
        // Deep shadow
        vx.fillStyle='rgba(0,0,0,0.9)'; vx.fillText('VESTIGE',vW/2+2,vH/2+2);
        
        // Main fill — warm bone
        vx.fillStyle='#e0d4c4'; vx.fillText('VESTIGE',vW/2,vH/2);
        
        // Weathering: diagonal scratch strokes across entire word
        vx.globalCompositeOperation='destination-out';
        for(let i=0;i<18;i++){
            const sx=Math.random()*vW, sy=Math.random()*vH;
            vx.beginPath(); vx.moveTo(sx,sy);
            vx.lineTo(sx+Math.random()*30-15, sy+Math.random()*4-2);
            vx.lineWidth=Math.random()*1.5+0.3; vx.stroke();
        }
        // Vertical crack lines
        for(let i=0;i<8;i++){
            vx.fillStyle=`rgba(0,0,0,${0.2+Math.random()*0.3})`;
            vx.fillRect(Math.random()*vW, vH*0.15+Math.random()*vH*0.4, 1, Math.random()*8+3);
        }
        // Horizontal erosion
        for(let i=0;i<20;i++){
            vx.fillStyle=`rgba(0,0,0,${0.1+Math.random()*0.2})`;
            vx.fillRect(Math.random()*vW, Math.random()*vH, Math.random()*10+2, 1);
        }
        vx.globalCompositeOperation='source-over';
        
        // Warm ambient glow layer
        vx.shadowColor='rgba(170,120,68,0.2)'; vx.shadowBlur=12;
        vx.fillStyle='rgba(200,170,120,0.06)'; vx.fillText('VESTIGE',vW/2,vH/2);
        vx.shadowBlur=0;
        
        // Edge distress — dark specks
        for(let i=0;i<25;i++){
            vx.fillStyle=`rgba(10,10,10,${Math.random()*0.35})`;
            vx.fillRect(Math.random()*vW, Math.random()*vH, Math.random()*3+0.5, Math.random()*2+0.5);
        }
        
        if(this.textures.exists('vestige_title'))this.textures.remove('vestige_title');
        this.textures.addCanvas('vestige_title',vc);
        
        // === GRIM — rust to dried blood gradient, heavy distress ===
        const gW=180, gH=44;
        const gc=document.createElement('canvas'); gc.width=gW; gc.height=gH;
        const gx=gc.getContext('2d');
        gx.font='bold 36px Georgia,"Times New Roman",serif';
        gx.textAlign='center'; gx.textBaseline='middle';
        
        // Deep shadow
        gx.fillStyle='rgba(0,0,0,0.9)'; gx.fillText('GRIM',gW/2+2,gH/2+2);
        
        // 4-stop rust gradient
        const gr=gx.createLinearGradient(gW/2-50, 0, gW/2+50, gH);
        gr.addColorStop(0,'#cc8844');
        gr.addColorStop(0.4,'#bb6633');
        gr.addColorStop(0.7,'#994422');
        gr.addColorStop(1,'#773320');
        gx.fillStyle=gr; gx.fillText('GRIM',gW/2,gH/2);
        
        // Heavy diagonal scratches
        gx.globalCompositeOperation='destination-out';
        for(let i=0;i<12;i++){
            const sx=gW*0.1+Math.random()*gW*0.8, sy=Math.random()*gH;
            gx.beginPath(); gx.moveTo(sx,sy);
            gx.lineTo(sx+Math.random()*20-10, sy+Math.random()*6-3);
            gx.lineWidth=Math.random()*2+0.5; gx.stroke();
        }
        // Horizontal erosion
        for(let i=0;i<12;i++){
            gx.fillStyle=`rgba(0,0,0,${0.15+Math.random()*0.2})`;
            gx.fillRect(Math.random()*gW, Math.random()*gH, Math.random()*8+1, 1);
        }
        gx.globalCompositeOperation='source-over';
        
        // Drip marks under letters
        for(let i=0;i<6;i++){
            const dx=gW/2-40+i*16+Math.random()*8;
            const dLen=3+Math.random()*8;
            gx.fillStyle=`rgba(${120+Math.floor(Math.random()*40)},${50+Math.floor(Math.random()*20)},${20+Math.floor(Math.random()*15)},${0.2+Math.random()*0.2})`;
            gx.fillRect(dx, gH/2+12, 1, dLen);
        }
        
        // Edge distress
        for(let i=0;i<15;i++){
            gx.fillStyle=`rgba(10,10,10,${Math.random()*0.3})`;
            gx.fillRect(Math.random()*gW, Math.random()*gH, Math.random()*2.5+0.5, Math.random()*1.5+0.5);
        }
        
        if(this.textures.exists('grim_title'))this.textures.remove('grim_title');
        this.textures.addCanvas('grim_title',gc);
    }
    
    showNewRunConfirm() {
        const W=CONFIG.width,H=CONFIG.height;
        if(this.cPanel) this.cPanel.destroy();
        this.cPanel=this.add.container(0,0).setDepth(50);
        const ov=this.add.rectangle(W/2,H/2,W,H,0x000000,0.7).setInteractive();
        this.cPanel.add(ov);
        const pY=H*0.42;
        this.cPanel.add(this.add.rectangle(W/2,pY,284,210,0x44403a,0.6));
        this.cPanel.add(this.add.rectangle(W/2,pY,280,206,0x1a1816,1));
        this.cPanel.add(this.add.text(W/2,pY-75,'WARNING',{fontFamily:CONFIG.font,fontSize: uiPx(16),fontStyle:'bold',fill:'#cc6644'}).setOrigin(0.5));
        this.cPanel.add(this.add.text(W/2,pY-42,'Starting a new run will\noverwrite your existing save.\nThis cannot be undone.',{fontFamily:CONFIG.font,fontSize: uiPx(11),fill:'#aa9977',align:'center',lineSpacing:4}).setOrigin(0.5));
        this.cPanel.add(this.add.text(W/2,pY+5,'Type  NEW  to confirm:',{fontFamily:CONFIG.font,fontSize: uiPx(12),fill:'#887766'}).setOrigin(0.5));
        this.cPanel.add(this.add.rectangle(W/2,pY+35,124,34,0x44403a,0.8));
        this.cPanel.add(this.add.rectangle(W/2,pY+35,120,30,0x0e0e0e,1));
        let inp='';
        const disp=this.add.text(W/2,pY+35,'|',{fontFamily:CONFIG.font,fontSize: uiPx(16),fontStyle:'bold',fill:'#e8ddd0'}).setOrigin(0.5);
        this.cPanel.add(disp);
        this._confirmCursor=this.time.addEvent({delay:500,loop:true,callback:()=>{if(inp.length<3)disp.setText(inp+(disp.text.endsWith('|')?' ':'|'));}});
        const confirm=()=>{disp.setFill('#44cc44');this._confirmCursor.remove();this._confirmCursor=null;this.time.delayedCall(400,()=>{try{SaveManager.reset();}catch(e){}this.closeConfirm();AudioManager.stopMusic(800);this.cameras.main.fadeOut(800,0,0,0);this.time.delayedCall(800,()=>this.scene.start('BiomeSelectScene'));});};
        const reject=()=>{disp.setFill('#cc4444');this.time.delayedCall(500,()=>{inp='';disp.setText('|').setFill('#e8ddd0');});};
        const addCh=(c)=>{if(inp.length>=3)return;inp+=c;disp.setText(inp);if(inp==='NEW')confirm();else if(inp.length===3)reject();};
        this._ckh=(e)=>{if(e.key==='Escape'){this.closeConfirm();return;}if(e.key==='Backspace'){inp=inp.slice(0,-1);disp.setText(inp+'|').setFill('#e8ddd0');return;}if(e.key.length===1&&inp.length<3)addCh(e.key.toUpperCase());};
        this.input.keyboard.on('keydown',this._ckh);
        const kY=pY+72;
        ['N','E','W'].forEach((k,i)=>{const kx=W/2-50+i*50;const kb=this.add.rectangle(kx,kY,36,30,0x2a2824,1).setInteractive({useHandCursor:true});this.cPanel.add([kb,this.add.text(kx,kY,k,{fontFamily:CONFIG.font,fontSize: uiPx(14),fontStyle:'bold',fill:'#aa9977'}).setOrigin(0.5)]);kb.on('pointerdown',()=>{kb.setFillStyle(0x4a4840);this.time.delayedCall(100,()=>kb.setFillStyle(0x2a2824));addCh(k);});});
        const bs=this.add.rectangle(W/2+90,kY,36,30,0x2a2824,1).setInteractive({useHandCursor:true});
        this.cPanel.add([bs,this.add.text(W/2+90,kY,'⌫',{fontFamily:CONFIG.font,fontSize: uiPx(14),fill:'#aa9977'}).setOrigin(0.5)]);
        bs.on('pointerdown',()=>{inp=inp.slice(0,-1);disp.setText(inp||'|').setFill('#e8ddd0');});
        const cb=this.add.rectangle(W/2,pY+105,80,24,0x1a1816,1).setInteractive({useHandCursor:true});
        this.cPanel.add([cb,this.add.text(W/2,pY+105,'Cancel',{fontFamily:CONFIG.font,fontSize: uiPx(11),fill:'#665e50'}).setOrigin(0.5)]);
        cb.on('pointerdown',()=>this.closeConfirm());
        ov.on('pointerdown',(p)=>{if(!this.cPanel)return;if(Math.abs(p.x-W/2)>145||Math.abs(p.y-pY)>108)this.closeConfirm();});
    }
    
    closeConfirm() {
        if(this._confirmCursor){this._confirmCursor.remove();this._confirmCursor=null;}
        if(this._ckh){this.input.keyboard.off('keydown',this._ckh);this._ckh=null;}
        if(this.cPanel){this.cPanel.destroy();this.cPanel=null;}
    }
    
    showTutorial() {
        const W=CONFIG.width,H=CONFIG.height;
        if(this.tPanel) this.tPanel.destroy();
        this.tPanel=this.add.container(0,0).setDepth(50);
        const ov=this.add.rectangle(W/2,H/2,W,H,0x000000,0.85).setInteractive();
        this.tPanel.add(ov);
        
        // Scrollable panel
        const pY=H*0.48, pW=314, pH=420;
        this.tPanel.add(this.add.rectangle(W/2,pY,pW+4,pH+4,0x44403a,0.5));
        this.tPanel.add(this.add.rectangle(W/2,pY,pW,pH,0x1a1816,1));
        this.tPanel.add(this.add.text(W/2,pY-pH/2+18,'GUIDE',{fontFamily:CONFIG.font,fontSize:uiPx(16),fontStyle:'bold',fill:'#aa7744'}).setOrigin(0.5));
        
        // Section buttons — each opens a dropdown
        const sections = [
            { title: 'Basics', items: [
                { t: 'MOVEMENT', d: 'Touch & drag to move.\nSwipe to dodge (brief invincibility).' },
                { t: 'COMBAT', d: 'Auto-aim fires at range.\nWalk close to melee swing.\nDodge through attacks for a damage boost.' },
                { t: 'LOOT', d: 'Walk over drops to collect.\nManage gear at your safehouse.\nHigher reaches = better loot.' },
                { t: 'EXTRACTION', d: 'Return to vehicle to extract.\nKeep items only if you survive.\nDeath = lose run progress.' },
                { t: 'FUEL', d: 'Each trip costs fuel.\nLow fuel risks breakdowns.\nPlan routes carefully.' }
            ]},
            { title: 'Stats & Mods', items: [
                { t: 'GUN STATS', d: 'Damage: Hit power (1-100)\nFire Rate: Shot speed (1-100)\nAccuracy: Hit chance (1-100)\nReload: Reload speed (1-100)\nCrit: Critical hit chance (1-200)\nMag: Ammo capacity (1-100)\nPierce: Punch-through (1-5)\nTarget Range: Lock-on range (1-5)' },
                { t: 'MELEE STATS', d: 'Damage: Hit power (1-100)\nAttack Speed: Swing speed (1-100)\nReach: Melee range (1-100)\nStagger: Interrupt chance (1-100)\nShield Attack: Shield break (1-5)\nMass Attack: Multi-hit (1-5)\nLifesteal: HP per damage (1-15)' },
                { t: 'CRITS', d: 'Crit 1-100: Yellow numbers (1.5x)\nCrit 101-200: RED numbers (2.5x)\nHigher crit = more frequent crits.' },
                { t: 'SHIELDS', d: 'Some enemies have blue shields.\nNormal bullets cannot break shields.\nMelee weapons break shields.\nPower Ammo damages shields (reduced).\nBosses regenerate shields each phase.' },
                { t: 'SOULBOUND', d: 'Protects a weapon from loss on death.\nEach death reduces Soulbound by 1.\nAt 0, the weapon is lost normally.' },
                { t: 'MODS', d: 'Weapons gain mod slots at higher tiers.\nAll mod values are flat bonuses.\nHigher tier mods = bigger numbers.\nBlood Forged items get signature perks.' }
            ]},
        ];
        
        let contentY = pY - pH/2 + 44;
        const _openSection = [null]; // Track open section
        
        const renderSections = () => {
            // Clear previous content
            if (this._tutContent) this._tutContent.forEach(c => c.destroy());
            this._tutContent = [];
            let cy = contentY;
            
            sections.forEach((sec, si) => {
                const isOpen = _openSection[0] === si;
                // Section button
                const btnBg = this.add.rectangle(W/2, cy, pW - 20, 26, isOpen ? 0x3a3828 : 0x2a2824, 1)
                    .setInteractive({ useHandCursor: true }).setStrokeStyle(1, isOpen ? 0x665e50 : 0x44403a, 0.6);
                const btnTx = this.add.text(W/2 - pW/2 + 20, cy, `${isOpen ? '▼' : '▶'} ${sec.title}`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(11), fontStyle: 'bold', fill: isOpen ? '#ccbbaa' : '#887766'
                }).setOrigin(0, 0.5);
                this.tPanel.add([btnBg, btnTx]);
                this._tutContent.push(btnBg, btnTx);
                
                btnBg.on('pointerdown', () => {
                    _openSection[0] = isOpen ? null : si;
                    renderSections();
                });
                
                cy += 18;
                
                if (isOpen) {
                    sec.items.forEach(item => {
                        const tt = this.add.text(W/2 - pW/2 + 24, cy, item.t, {
                            fontFamily: CONFIG.font, fontSize: uiPx(9), fontStyle: 'bold', fill: '#ccbbaa'
                        });
                        cy += 14;
                        const td = this.add.text(W/2 - pW/2 + 24, cy, item.d, {
                            fontFamily: CONFIG.font, fontSize: uiPx(8), fill: '#887766', lineSpacing: 2,
                            wordWrap: { width: pW - 48 }
                        });
                        const dh = td.height;
                        cy += dh + 8;
                        this.tPanel.add([tt, td]);
                        this._tutContent.push(tt, td);
                    });
                    cy += 4;
                }
            });
        };
        renderSections();
        
        const cl=this.add.rectangle(W/2,pY+pH/2-16,90,28,0x8a7a55,1).setInteractive({useHandCursor:true});
        this.tPanel.add([cl,this.add.text(W/2,pY+pH/2-16,'Close',{fontFamily:CONFIG.font,fontSize:uiPx(12),fontStyle:'bold',fill:'#1a1814'}).setOrigin(0.5)]);
        cl.on('pointerdown',()=>{if(this._tutContent)this._tutContent.forEach(c=>c.destroy());this._tutContent=null;this.tPanel.destroy();this.tPanel=null;});
        ov.on('pointerdown',(p)=>{if(!this.tPanel)return;if(Math.abs(p.x-W/2)>pW/2+5||Math.abs(p.y-pY)>pH/2+5){if(this._tutContent)this._tutContent.forEach(c=>c.destroy());this._tutContent=null;this.tPanel.destroy();this.tPanel=null;}});
    }
}
