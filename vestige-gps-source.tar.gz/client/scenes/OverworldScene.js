// Vestige GPS — OverworldScene (Top-Down)
// Primary navigation view. Top-down camera, isometric sprites.
// GPS position drives world scroll. Biome grid tiles render as ground plane.
// Vehicle stays at screen center, world moves around it.
//
// Flow:
//   TitleScene → OverworldScene
//   OverworldScene → SafehouseScene / GameScene / HavenScene
//   *Scene → OverworldScene (return)

import { BiomeGrid } from '../../core/biomeGrid.js';
import { uiPx } from '../../core/utils.js';
import { CONFIG } from '../../data/config.js';
import { AudioManager } from '../audioManager.js';
import { SpriteManager } from '../spriteManager.js';
import { UIManager } from '../uiManager.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { RealtimeTOD } from '../../core/realtimeTOD.js';
import { WeatherSystem } from '../../core/weatherSystem.js';
import { VehicleFleet } from '../vehicleFleet.js';

// ============================================
// BIOME VISUAL CONFIG
// ============================================
const BIOME_VIS = {
    ironfield: {
        ground: 0x2e2920, groundAlt: 0x3a3428, fog: 0x3a3228,
        tint: 0xccbbaa, propTint: 0x5a5040,
        groundPattern: 'hash',   // cross-hatch rust pattern
        particles: 'sparks',
    },
    mirelands: {
        ground: 0x1e2e1a, groundAlt: 0x263822, fog: 0x20301e,
        tint: 0xaaccaa, propTint: 0x3a5a30,
        groundPattern: 'dots',   // spore dots
        particles: 'spores',
    },
    scorchflats: {
        ground: 0x3e3422, groundAlt: 0x484030, fog: 0x484030,
        tint: 0xddccaa, propTint: 0x6a5a40,
        groundPattern: 'cracks', // dry cracked earth
        particles: 'dust',
    },
    hollows: {
        ground: 0x181824, groundAlt: 0x24243a, fog: 0x161620,
        tint: 0x9999bb, propTint: 0x40406a,
        groundPattern: 'veins',  // mineral veins
        particles: 'drip',
    },
    tidemarsh: {
        ground: 0x1e2a30, groundAlt: 0x283840, fog: 0x283848,
        tint: 0xaabbcc, propTint: 0x35556a,
        groundPattern: 'ripple', // water ripple
        particles: 'mist',
    },
    ashveil: {
        ground: 0x201820, groundAlt: 0x2e222e, fog: 0x281828,
        tint: 0xbb99bb, propTint: 0x5a3a5a,
        groundPattern: 'static', // glitch static
        particles: 'ash',
    },
};

// Meters per degree latitude (constant)
const M_PER_DEG = 111320;

// How many pixels represent 1 meter on the overworld
const PX_PER_METER = 1.5;

// Grid cell visual size in pixels
const CELL_PX = BiomeGrid.getCellSize() * PX_PER_METER;

export class OverworldScene extends Phaser.Scene {
    constructor() {
        super({ key: 'OverworldScene' });
    }

    init(data) {
        this.playerState = data.playerState || { health: 100, fuel: 100, bits: 0, level: 1 };

        // GPS
        this.gpsEnabled = false;
        this.gpsWatchId = null;
        this.playerLat = data.lat || 0;
        this.playerLng = data.lng || 0;
        this.targetLat = this.playerLat;
        this.targetLng = this.playerLng;
        this.prevLat = this.playerLat;
        this.prevLng = this.playerLng;

        // Safehouse anchor
        this.safehouseLat = data.safehouseLat || this.playerLat;
        this.safehouseLng = data.safehouseLng || this.playerLng;

        // Biome state
        this.currentBiome = null;
        this.currentReachId = null;

        // World container offset (pixels)
        this.worldX = 0;
        this.worldY = 0;

        // Vehicle facing direction
        this.facingDir = 'down';

        // Touch drag for manual movement (dev/fallback)
        this.dragActive = false;
        this.dragStartX = 0;
        this.dragStartY = 0;
        this.dragStartLat = 0;
        this.dragStartLng = 0;

        // Ground tile cache
        this.groundTiles = new Map(); // 'cx:cy' → graphics object
        this.propSprites = new Map(); // 'cx:cy' → container

        // Particles
        this.particleEmitter = null;
    }

    create() {
        const { width, height } = this.cameras.main;

        BiomeGrid.init(CONFIG.biomeSeed || 42);

        // ── World container — everything that scrolls ──
        this.worldContainer = this.add.container(0, 0);
        this.worldContainer.setDepth(0);

        // ── Ground layer (within world container) ──
        this.groundLayer = this.add.container(0, 0);
        this.worldContainer.add(this.groundLayer);

        // ── Prop layer ──
        this.propLayer = this.add.container(0, 0);
        this.worldContainer.add(this.propLayer);

        // ── Entity layer (vehicle, buildings, nodes — depth sorted) ──
        this.entityLayer = this.add.container(0, 0);
        this.worldContainer.add(this.entityLayer);

        // ── Create vehicle ──
        this._createVehicle();

        // ── Overlay layer (fog, vignette — screen space) ──
        this._createOverlays();

        // ── HUD ──
        this._createHUD();

        // ── GPS ──
        this._initGPS();

        // ── Classify starting biome ──
        this._updateBiome();

        // ── Render initial ground tiles ──
        this._updateGroundTiles();

        // ── Touch/drag input for manual movement ──
        this.input.on('pointerdown', (ptr) => {
            this.dragActive = true;
            this.dragStartX = ptr.x;
            this.dragStartY = ptr.y;
            this.dragStartLat = this.targetLat;
            this.dragStartLng = this.targetLng;
        });
        this.input.on('pointermove', (ptr) => {
            if (!this.dragActive) return;
            const dx = ptr.x - this.dragStartX;
            const dy = ptr.y - this.dragStartY;
            const mPerLng = M_PER_DEG * Math.cos(this.playerLat * Math.PI / 180);
            // Drag sensitivity: pixels → degrees
            const sens = 1 / (PX_PER_METER * mPerLng);
            this.targetLng = this.dragStartLng - dx * sens * 0.5;
            this.targetLat = this.dragStartLat + dy * sens * 0.5;
        });
        this.input.on('pointerup', () => { this.dragActive = false; });
    }

    update(time, delta) {
        const dt = delta / 1000;

        // ── Lerp position toward GPS/drag target ──
        this.prevLat = this.playerLat;
        this.prevLng = this.playerLng;
        const lerpRate = 1 - Math.pow(0.05, dt); // smooth ~95% per second
        this.playerLat += (this.targetLat - this.playerLat) * lerpRate;
        this.playerLng += (this.targetLng - this.playerLng) * lerpRate;

        // ── Convert GPS to world pixel position ──
        this._updateWorldOffset();

        // ── Position world container (inverse of player pos = world scrolls) ──
        const { width, height } = this.cameras.main;
        this.worldContainer.x = width / 2 - this.worldX;
        this.worldContainer.y = height / 2 - this.worldY;

        // ── Update vehicle facing ──
        this._updateVehicleFacing();

        // ── Check biome transition ──
        this._checkBiomeTransition();

        // ── Update visible ground tiles ──
        this._updateGroundTiles();

        // ── Update particles ──
        this._updateParticles(dt);

        // ── Update HUD ──
        this._updateHUD();
    }

    // ============================================
    // GPS
    // ============================================

    _initGPS() {
        if (!navigator.geolocation) {
            this._useFallback();
            return;
        }
        this.gpsWatchId = navigator.geolocation.watchPosition(
            (pos) => this._onGPS(pos),
            (err) => { console.warn('GPS error:', err.message); this._useFallback(); },
            { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
        );
        this.gpsEnabled = true;
    }

    _onGPS(pos) {
        this.targetLat = pos.coords.latitude;
        this.targetLng = pos.coords.longitude;
        // First fix — snap
        if (this.playerLat === 0 && this.playerLng === 0) {
            this.playerLat = this.targetLat;
            this.playerLng = this.targetLng;
            this.safehouseLat = this.targetLat;
            this.safehouseLng = this.targetLng;
            this._updateBiome();
            this._updateGroundTiles();
        }
    }

    _useFallback() {
        this.gpsEnabled = false;
        if (this.playerLat === 0 && this.playerLng === 0) {
            // Default: Times Square, NYC
            this.playerLat = 40.7580;
            this.playerLng = -73.9855;
            this.targetLat = this.playerLat;
            this.targetLng = this.playerLng;
            this.safehouseLat = this.playerLat;
            this.safehouseLng = this.playerLng;
            this._updateBiome();
        }
    }

    // ============================================
    // WORLD POSITION
    // ============================================

    _updateWorldOffset() {
        // Convert player GPS to pixel coordinates
        // Origin (0,0) is at lat=0, lng=0 — arbitrary but consistent
        const mPerLng = M_PER_DEG * Math.cos(this.playerLat * Math.PI / 180);
        this.worldX = this.playerLng * mPerLng * PX_PER_METER;
        this.worldY = -this.playerLat * M_PER_DEG * PX_PER_METER; // negative because Y increases downward
    }

    _gpsToWorld(lat, lng) {
        const mPerLng = M_PER_DEG * Math.cos(lat * Math.PI / 180);
        return {
            x: lng * mPerLng * PX_PER_METER,
            y: -lat * M_PER_DEG * PX_PER_METER,
        };
    }

    // ============================================
    // VEHICLE
    // ============================================

    _createVehicle() {
        try {
            VehicleFleet.registerTextures(this);
            this.vehicleSprite = VehicleFleet.createSprite(this, 0, 0, 'pickup', 'down', false);
            this.vehicleSprite.setScale(2); // bigger on overworld
        } catch (e) {
            // Fallback if VehicleFleet not ready
            this.vehicleSprite = this.add.rectangle(0, 0, 24, 32, 0xccaa44);
        }
        this.vehicleSprite.setDepth(100);

        // Shadow under vehicle
        this.vehicleShadow = this.add.ellipse(0, 8, 36, 12, 0x000000, 0.3);
        this.vehicleShadow.setDepth(99);

        // Add to entity layer at world position
        this.entityLayer.add(this.vehicleShadow);
        this.entityLayer.add(this.vehicleSprite);
    }

    _updateVehicleFacing() {
        const dLat = this.playerLat - this.prevLat;
        const dLng = this.playerLng - this.prevLng;
        const threshold = 0.000001;

        let newDir = this.facingDir;
        if (Math.abs(dLat) > threshold || Math.abs(dLng) > threshold) {
            // Determine dominant direction
            if (Math.abs(dLat) > Math.abs(dLng)) {
                newDir = dLat > 0 ? 'up' : 'down';
            } else {
                newDir = dLng > 0 ? 'right' : 'left';
            }
        }

        if (newDir !== this.facingDir) {
            this.facingDir = newDir;
            try {
                const frame = VehicleFleet.getFrame('pickup', this.facingDir, false);
                this.vehicleSprite.setFrame(frame);
            } catch (e) {
                // Fallback — no frame change needed for rectangle
            }
        }

        // Position vehicle at player's world coordinates
        this.vehicleSprite.x = this.worldX;
        this.vehicleSprite.y = this.worldY;
        this.vehicleShadow.x = this.worldX;
        this.vehicleShadow.y = this.worldY + 8;

        // Idle bob
        const bob = Math.sin(this.time.now / 600) * 1;
        this.vehicleSprite.y += bob;
    }

    // ============================================
    // GROUND TILES (biome grid visualization)
    // ============================================

    _updateGroundTiles() {
        const { width, height } = this.cameras.main;

        // How many cells visible on screen (plus buffer)
        const viewRadiusX = Math.ceil(width / CELL_PX / 2) + 2;
        const viewRadiusY = Math.ceil(height / CELL_PX / 2) + 2;

        // Current cell
        const center = BiomeGrid.getBiome(this.playerLat, this.playerLng);
        const cx = center.cellX;
        const cy = center.cellY;

        // Track which tiles should exist
        const needed = new Set();

        for (let dy = -viewRadiusY; dy <= viewRadiusY; dy++) {
            for (let dx = -viewRadiusX; dx <= viewRadiusX; dx++) {
                const tcx = cx + dx;
                const tcy = cy + dy;
                const key = `${tcx}:${tcy}`;
                needed.add(key);

                if (!this.groundTiles.has(key)) {
                    this._createGroundTile(tcx, tcy, key);
                }
            }
        }

        // Remove tiles that are too far away
        for (const [key, tile] of this.groundTiles) {
            if (!needed.has(key)) {
                tile.destroy();
                this.groundTiles.delete(key);
                // Also remove props
                const propC = this.propSprites.get(key);
                if (propC) { propC.destroy(); this.propSprites.delete(key); }
            }
        }
    }

    _createGroundTile(cellX, cellY, key) {
        const biome = BiomeGrid.getBiomeAtCell(cellX, cellY);
        const vis = BIOME_VIS[biome.biome] || BIOME_VIS.scorchflats;

        // World position of this cell's top-left
        // Cell center GPS → world coords
        const cellCenterLat = (cellY * BiomeGrid.getCellSize() + BiomeGrid.getCellSize() / 2) / M_PER_DEG;
        const mPerLng = M_PER_DEG * Math.cos(cellCenterLat * Math.PI / 180);
        const cellCenterLng = (cellX * BiomeGrid.getCellSize() + BiomeGrid.getCellSize() / 2) / mPerLng;
        const wp = this._gpsToWorld(cellCenterLat, cellCenterLng);

        // Draw tile
        const g = this.add.graphics();
        g.fillStyle(vis.ground, 1);
        g.fillRect(wp.x - CELL_PX / 2, wp.y - CELL_PX / 2, CELL_PX, CELL_PX);

        // Ground pattern overlay
        this._drawGroundPattern(g, wp.x - CELL_PX / 2, wp.y - CELL_PX / 2, CELL_PX, CELL_PX, vis, cellX, cellY);

        // Cell border (subtle)
        g.lineStyle(1, vis.groundAlt, 0.15);
        g.strokeRect(wp.x - CELL_PX / 2, wp.y - CELL_PX / 2, CELL_PX, CELL_PX);

        g.setDepth(-10);
        this.groundLayer.add(g);
        this.groundTiles.set(key, g);

        // Generate props for this cell
        this._createCellProps(cellX, cellY, key, biome.biome, wp);
    }

    _drawGroundPattern(g, x, y, w, h, vis, cx, cy) {
        // Deterministic pattern based on cell position
        let rng = Math.abs(((cx * 374761 + cy * 668265) | 0)) >>> 0;
        const next = () => { rng = ((rng * 1664525 + 1013904223) >>> 0); return rng; };

        g.fillStyle(vis.groundAlt, 0.3);

        switch (vis.groundPattern) {
            case 'hash': // Ironfield — rust scratches
                for (let i = 0; i < 12; i++) {
                    const lx = x + (next() % (w | 0));
                    const ly = y + (next() % (h | 0));
                    const len = 8 + (next() % 20);
                    const horiz = next() % 2;
                    g.fillRect(lx, ly, horiz ? len : 2, horiz ? 2 : len);
                }
                break;

            case 'dots': // Mirelands — spore dots
                for (let i = 0; i < 20; i++) {
                    const dx = x + (next() % (w | 0));
                    const dy = y + (next() % (h | 0));
                    const r = 2 + (next() % 4);
                    g.fillCircle(dx, dy, r);
                }
                break;

            case 'cracks': // Scorchflats — cracked earth lines
                for (let i = 0; i < 8; i++) {
                    const sx = x + (next() % (w | 0));
                    const sy = y + (next() % (h | 0));
                    g.lineStyle(1, vis.groundAlt, 0.4);
                    g.beginPath();
                    g.moveTo(sx, sy);
                    for (let j = 0; j < 3; j++) {
                        const nx = sx + (next() % 40) - 20;
                        const ny = sy + (next() % 40) - 20;
                        g.lineTo(nx, ny);
                    }
                    g.strokePath();
                }
                break;

            case 'veins': // Hollows — glowing mineral veins
                g.lineStyle(2, 0x4444aa, 0.15);
                for (let i = 0; i < 5; i++) {
                    const sx = x + (next() % (w | 0));
                    const sy = y + (next() % (h | 0));
                    g.beginPath();
                    g.moveTo(sx, sy);
                    for (let j = 0; j < 4; j++) {
                        g.lineTo(sx + (next() % 60) - 30, sy + (next() % 60) - 30);
                    }
                    g.strokePath();
                }
                break;

            case 'ripple': // Tidemarsh — concentric water rings
                for (let i = 0; i < 6; i++) {
                    const rx = x + (next() % (w | 0));
                    const ry = y + (next() % (h | 0));
                    const rr = 8 + (next() % 15);
                    g.lineStyle(1, vis.groundAlt, 0.2);
                    g.strokeCircle(rx, ry, rr);
                    g.strokeCircle(rx, ry, rr * 0.6);
                }
                break;

            case 'static': // Ashveil — digital static
                for (let i = 0; i < 30; i++) {
                    const sx = x + (next() % (w | 0));
                    const sy = y + (next() % (h | 0));
                    const sw = 2 + (next() % 6);
                    g.fillStyle(next() % 2 ? 0x3a2a3a : 0x2a1a2a, 0.4);
                    g.fillRect(sx, sy, sw, 2);
                }
                break;
        }
    }

    _createCellProps(cellX, cellY, key, biomeId, worldPos) {
        const vis = BIOME_VIS[biomeId] || BIOME_VIS.scorchflats;
        const container = this.add.container(0, 0);

        let rng = Math.abs(((cellX * 892451 + cellY * 237893) | 0)) >>> 0;
        const next = () => { rng = ((rng * 1664525 + 1013904223) >>> 0); return rng; };

        // Number of props per cell (3-8)
        const numProps = 3 + (next() % 6);
        const halfCell = CELL_PX / 2;

        for (let i = 0; i < numProps; i++) {
            const px = worldPos.x - halfCell + (next() % (CELL_PX | 0));
            const py = worldPos.y - halfCell + (next() % (CELL_PX | 0));
            const size = next() % 100;

            if (size > 85) {
                // Large prop — iso building shape
                const bw = 20 + (next() % 24);
                const bh = 30 + (next() % 50);
                const prop = this._drawIsoBuilding(px, py, bw, bh, vis);
                container.add(prop);
            } else if (size > 50) {
                // Medium prop — debris/rock
                const pw = 8 + (next() % 12);
                const ph = 6 + (next() % 8);
                const rect = this.add.rectangle(px, py, pw, ph, vis.propTint, 0.6);
                container.add(rect);
            } else {
                // Small prop — scatter detail
                const sw = 3 + (next() % 5);
                const rect = this.add.rectangle(px, py, sw, sw, vis.groundAlt, 0.5);
                container.add(rect);
            }
        }

        container.setDepth(10);
        this.propLayer.add(container);
        this.propSprites.set(key, container);
    }

    _drawIsoBuilding(x, y, w, h, vis) {
        const g = this.add.graphics();
        const topOff = 6; // isometric top face offset

        // Shadow
        g.fillStyle(0x000000, 0.2);
        g.fillRect(x - w / 2 + 4, y + 3, w + 6, 5);

        // Front face
        g.fillStyle(vis.propTint, 0.8);
        g.fillRect(x - w / 2, y - h, w, h);

        // Top face (parallelogram)
        const topColor = Phaser.Display.Color.IntegerToColor(vis.propTint);
        const lighter = Phaser.Display.Color.GetColor(
            Math.min(255, topColor.red + 30),
            Math.min(255, topColor.green + 30),
            Math.min(255, topColor.blue + 30)
        );
        g.fillStyle(lighter, 0.8);
        g.beginPath();
        g.moveTo(x - w / 2, y - h);
        g.lineTo(x - w / 2 + topOff, y - h - topOff);
        g.lineTo(x + w / 2 + topOff, y - h - topOff);
        g.lineTo(x + w / 2, y - h);
        g.closePath();
        g.fillPath();

        // Side face
        const darker = Phaser.Display.Color.GetColor(
            Math.max(0, topColor.red - 25),
            Math.max(0, topColor.green - 25),
            Math.max(0, topColor.blue - 25)
        );
        g.fillStyle(darker, 0.8);
        g.beginPath();
        g.moveTo(x + w / 2, y - h);
        g.lineTo(x + w / 2 + topOff, y - h - topOff);
        g.lineTo(x + w / 2 + topOff, y - topOff);
        g.lineTo(x + w / 2, y);
        g.closePath();
        g.fillPath();

        // Window details on front face
        g.fillStyle(0x111122, 0.5);
        const winW = Math.max(3, w * 0.3);
        const winH = Math.max(3, h * 0.15);
        const rows = Math.min(3, Math.floor(h / 20));
        for (let r = 0; r < rows; r++) {
            const wy = y - h + 8 + r * (winH + 6);
            g.fillRect(x - winW / 2 - winW * 0.4, wy, winW, winH);
            g.fillRect(x - winW / 2 + winW * 0.6, wy, winW, winH);
        }

        return g;
    }

    // ============================================
    // BIOME
    // ============================================

    _updateBiome() {
        const info = BiomeGrid.getReachInfo(this.playerLat, this.playerLng);
        this.currentBiome = info;
        this.currentReachId = info.reachId;
        this._updateOverlayColors();
    }

    _checkBiomeTransition() {
        const newReach = BiomeGrid.getBiome(this.playerLat, this.playerLng);
        if (newReach.reachId !== this.currentReachId) {
            const old = this.currentBiome;
            this._updateBiome();
            // Brief flash on transition
            this.cameras.main.flash(200, 0, 0, 0, true);
        }
    }

    // ============================================
    // OVERLAYS (fog, vignette)
    // ============================================

    _createOverlays() {
        const { width, height } = this.cameras.main;

        // Vignette — darkens edges
        this.vignette = this.add.graphics();
        this.vignette.setDepth(900);
        this.vignette.setScrollFactor(0);
        this._drawVignette();

        // Fog overlay — biome-colored
        this.fogOverlay = this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0);
        this.fogOverlay.setDepth(800);
        this.fogOverlay.setScrollFactor(0);

        // Scanlines (CRT feel)
        this.scanlines = this.add.graphics();
        this.scanlines.setDepth(950);
        this.scanlines.setScrollFactor(0);
        for (let y = 0; y < height; y += 3) {
            this.scanlines.fillStyle(0x000000, 0.06);
            this.scanlines.fillRect(0, y, width, 1);
        }
    }

    _drawVignette() {
        const { width, height } = this.cameras.main;
        const cx = width / 2, cy = height / 2;
        const maxR = Math.sqrt(cx * cx + cy * cy);

        // Radial vignette via concentric rectangles with increasing opacity
        for (let i = 0; i < 20; i++) {
            const t = i / 20;
            const alpha = t * t * 0.5;
            const inset = (1 - t) * maxR * 0.7;
            this.vignette.fillStyle(0x000000, alpha);
            this.vignette.fillRect(
                cx - inset, cy - inset * (height / width),
                inset * 2, inset * 2 * (height / width)
            );
        }
    }

    _updateOverlayColors() {
        if (!this.currentBiome) return;
        const vis = BIOME_VIS[this.currentBiome.biome] || BIOME_VIS.scorchflats;
        if (this.fogOverlay) {
            this.fogOverlay.setFillStyle(vis.fog, 0.08);
        }
    }

    // ============================================
    // PARTICLES
    // ============================================

    _updateParticles(dt) {
        // TODO: biome-specific particle systems
        // For now handled by ground patterns
    }

    // ============================================
    // HUD
    // ============================================

    _createHUD() {
        const pad = uiPx(3);

        this.hudBiome = this.add.text(pad, pad, '', {
            fontFamily: 'monospace', fontSize: uiPx(6) + 'px',
            color: '#88ff88', fontStyle: 'bold',
        }).setDepth(1000).setScrollFactor(0);

        this.hudCoords = this.add.text(pad, pad + uiPx(8), '', {
            fontFamily: 'monospace', fontSize: uiPx(3.5) + 'px',
            color: '#556655',
        }).setDepth(1000).setScrollFactor(0);

        this.hudReach = this.add.text(pad, pad + uiPx(12), '', {
            fontFamily: 'monospace', fontSize: uiPx(3.5) + 'px',
            color: '#445544',
        }).setDepth(1000).setScrollFactor(0);

        this.hudFuel = this.add.text(pad, pad + uiPx(17), '', {
            fontFamily: 'monospace', fontSize: uiPx(4) + 'px',
            color: '#ccaa44',
        }).setDepth(1000).setScrollFactor(0);

        // GPS status indicator
        this.hudGPS = this.add.text(this.cameras.main.width - pad, pad, '', {
            fontFamily: 'monospace', fontSize: uiPx(3.5) + 'px',
            color: '#444444', align: 'right',
        }).setOrigin(1, 0).setDepth(1000).setScrollFactor(0);
    }

    _updateHUD() {
        if (this.hudBiome && this.currentBiome) {
            const vis = BIOME_VIS[this.currentBiome.biome];
            const tintHex = '#' + (vis?.tint || 0x88ff88).toString(16).padStart(6, '0');
            this.hudBiome.setText(this.currentBiome.biomeName);
            this.hudBiome.setColor(tintHex);
            this.hudBiome.setShadow(0, 0, tintHex + '66', 6);
        }

        if (this.hudCoords) {
            this.hudCoords.setText(`${this.playerLat.toFixed(4)}, ${this.playerLng.toFixed(4)}`);
        }

        if (this.hudReach) {
            this.hudReach.setText(`Reach ${this.currentReachId || '?'}`);
        }

        if (this.hudFuel) {
            const fuel = this.playerState.fuel || 100;
            const bars = Math.round(fuel / 100 * 16);
            this.hudFuel.setText(`FUEL ${'█'.repeat(bars)}${'░'.repeat(16 - bars)} ${Math.round(fuel)}%`);
        }

        if (this.hudGPS) {
            this.hudGPS.setText(this.gpsEnabled ? 'GPS ACTIVE' : 'GPS OFF — DRAG TO MOVE');
            this.hudGPS.setColor(this.gpsEnabled ? '#44aa44' : '#664444');
        }
    }

    // ============================================
    // CLEANUP
    // ============================================

    shutdown() {
        if (this.gpsWatchId !== null) {
            navigator.geolocation.clearWatch(this.gpsWatchId);
            this.gpsWatchId = null;
        }
        // Clean tile caches
        this.groundTiles.clear();
        this.propSprites.clear();
    }
}
