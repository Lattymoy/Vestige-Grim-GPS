// Vestige GPS — IsoRenderer
// Extracted from monolith lines 3274-3597
// TODO: convert internal global refs to imports

import { CONFIG } from '../data/config.js';
import { ISO_DEFS } from '../data/isoDefs.js';


export const IsoRenderer = {
    // Color utilities
    lighten(color, amount = 0.2) {
        const c = Phaser.Display.Color.ValueToColor(color);
        const r = Math.min(255, Math.floor(c.red + (255 - c.red) * amount));
        const g = Math.min(255, Math.floor(c.green + (255 - c.green) * amount));
        const b = Math.min(255, Math.floor(c.blue + (255 - c.blue) * amount));
        return Phaser.Display.Color.GetColor(r, g, b);
    },
    
    darken(color, amount = 0.25) {
        const c = Phaser.Display.Color.ValueToColor(color);
        const r = Math.max(0, Math.floor(c.red * (1 - amount)));
        const g = Math.max(0, Math.floor(c.green * (1 - amount)));
        const b = Math.max(0, Math.floor(c.blue * (1 - amount)));
        return Phaser.Display.Color.GetColor(r, g, b);
    },

    // Tint a color using scene lighting (standalone version)
    tint(scene, color) {
        if (scene.tintColor) return scene.tintColor(color, scene.lighting.ambient, scene.lighting.intensity);
        return color;
    },

    // Drop shadow on the floor beneath an object
    // w, h = footprint of the object on the ground
    shadow(scene, x, y, w, h, depth = 3) {
        let offX = 0, offY = 0, alpha = 0.35;
        if (scene.lighting) {
            offX = Math.cos(scene.lighting.shadowAngle) * 8 * scene.lighting.shadowLength;
            offY = Math.sin(scene.lighting.shadowAngle) * 4 * scene.lighting.shadowLength;
        }
        if (CONFIG.timeOfDay === 'night') alpha = 0.2;
        scene.add.ellipse(x + offX, y + h / 2 + Math.abs(offY), w * 0.9, h * 0.5, 0x000000, alpha).setDepth(depth);
    },

    // -------------------------------------------------------
    // CORE PRIMITIVE: Isometric Box / Cube
    // Draws a 3D box viewed from above-front.
    //   x, y      = center of the object footprint on the ground
    //   w         = width  (left-right)
    //   h         = depth  (front-back on screen, i.e. "height" of the rectangle in 2D)
    //   elevation = how tall the box rises above the ground (the 3D part)
    //   color     = base color for the front face
    //   opts      = { depth, noShadow, topColor, frontColor, sideColor, outline }
    // Returns an object { top, front, side } with the created game objects.
    // -------------------------------------------------------
    cube(scene, x, y, w, h, elevation, color, opts = {}) {
        const d = opts.depth ?? (10 + y * 0.01);
        const tint = (c) => this.tint(scene, c);

        const topColor    = tint(opts.topColor   ?? this.lighten(color, 0.22));
        const frontColor  = tint(opts.frontColor ?? color);
        const sideColor   = tint(opts.sideColor  ?? this.darken(color, 0.22));
        const outlineColor = opts.outline ?? null;

        if (!opts.noShadow) this.shadow(scene, x, y, w, h);

        // Side face (visible on the right edge — shows depth)
        // Drawn as a parallelogram-ish strip on the right
        const sideW = Math.max(3, Math.min(elevation * 0.45, w * 0.18));
        const side = scene.add.rectangle(
            x + w / 2 - sideW / 2, y - elevation / 2,
            sideW, h + elevation, sideColor
        ).setDepth(d + 0.001);

        // Front face (the main visible rectangle)
        const front = scene.add.rectangle(
            x - sideW / 2, y + h / 2 - elevation / 2 + elevation / 2,
            w - sideW, elevation, frontColor
        ).setDepth(d + 0.002);

        // Top surface
        const top = scene.add.rectangle(
            x - sideW / 2, y - elevation / 2,
            w - sideW, h, topColor
        ).setDepth(d + 0.003);

        if (outlineColor) {
            top.setStrokeStyle(1, outlineColor);
            front.setStrokeStyle(1, outlineColor);
            side.setStrokeStyle(1, outlineColor);
        }

        return { top, front, side };
    },

    // -------------------------------------------------------
    // Isometric Cylinder (barrel, trash can, hydrant)
    //   x, y      = center on ground
    //   radius    = radius of the cylinder
    //   elevation = height of the cylinder
    //   color     = base color
    // -------------------------------------------------------
    // -------------------------------------------------------
    // Tall object (pole-like: lamp post, sign post, flagpole)
    //   x, y      = base position
    //   poleW     = pole width
    //   poleH     = pole height (how tall it is on screen)
    //   color     = pole color
    //   topPiece  = optional { w, h, color } for something on top (sign, lamp, etc.)
    // -------------------------------------------------------
    pole(scene, x, y, poleW, poleH, color, opts = {}) {
        const d = opts.depth ?? (10 + y * 0.01);
        const tint = (c) => this.tint(scene, c);

        const mainColor  = tint(color);
        const shadeColor = tint(this.darken(color, 0.3));
        const lightColor = tint(this.lighten(color, 0.15));

        if (!opts.noShadow) this.shadow(scene, x, y, poleW + 4, poleW + 4);

        // Pole body
        scene.add.rectangle(x, y - poleH / 2 + poleW, poleW, poleH, mainColor).setDepth(d + 0.001);
        // Light edge on left
        scene.add.rectangle(x - poleW / 4, y - poleH / 2 + poleW, Math.max(1, poleW / 3), poleH, lightColor).setDepth(d + 0.002);
        // Dark edge on right
        scene.add.rectangle(x + poleW / 4, y - poleH / 2 + poleW, Math.max(1, poleW / 3), poleH, shadeColor).setDepth(d + 0.002);

        // Top cap (small ellipse)
        scene.add.ellipse(x, y - poleH + poleW, poleW + 2, poleW * 0.6, tint(this.lighten(color, 0.3))).setDepth(d + 0.003);
    },

    // =================================================================
    // UNIFIED MODULAR ¾ ISO RENDERER
    // Renders any object (furniture, building, vehicle) from data defs
    // =================================================================
    
    // Biome color tint offsets
    biomeTints: {
        grassy:      { r: 3, g: 6, b: 3 },
        barren:      { r: 6, g: 4, b: 0 },
        apocalyptic: { r: 3, g: 0, b: 6 },
        none:        { r: 0, g: 0, b: 0 }
    },
    
    // Apply biome tint to a color
    biomeTint(color, biome) {
        if (!biome || biome === 'none') return color;
        const t = this.biomeTints[biome] || this.biomeTints.none;
        const c = Phaser.Display.Color.ValueToColor(color);
        return Phaser.Display.Color.GetColor(
            Math.min(255, c.red + t.r), Math.min(255, c.green + t.g), Math.min(255, c.blue + t.b)
        );
    },
    
    // Core render method — draws a defined object at any scale
    // def: object definition from ISO_DEFS
    // opts: { x, y, scene, wall, scale, biome, damage, depth, alpha, variant, container }
    render(def, opts) {
        const scene = opts.scene;
        const x = opts.x || 0;
        const y = opts.y || 0;
        const s = opts.scale || 1;
        const wall = opts.wall || 'front'; // 'front','left','right','back'
        const biome = opts.biome || 'none';
        const damage = Math.min(1, Math.max(0, opts.damage || 0));
        const baseDepth = opts.depth || 15;
        const alpha = opts.alpha !== undefined ? opts.alpha : 1;
        const variant = opts.variant || null;
        
        // Resolve variant
        let parts = def.parts;
        let colors = { ...def.colors };
        if (variant && def.variants && def.variants[variant]) {
            const v = def.variants[variant];
            if (v.recolor) Object.assign(colors, v.recolor);
            if (v.addParts) parts = [...parts, ...v.addParts];
            if (v.removeParts) parts = parts.filter(p => !v.removeParts.includes(p.id));
        }
        
        // Container for all parts
        const container = opts.container || scene.add.container(x, y);
        if (!opts.container) container.setDepth(baseDepth);
        
        // Orientation transform params
        const isBack = (wall === 'back');
        const isSide = (wall === 'left' || wall === 'right');
        const sideDir = wall === 'left' ? -1 : 1;
        const frontCompress = isSide ? 0.2 : 1;    // front face compressed to 20% on side walls
        const sideCompress = isSide ? 1 : 0;        // side face hidden on front walls
        const sideWidth = def.sideW || Math.max(3, (def.w || 16) * 0.25); // depth face width
        
        // Draw shadow
        if (!opts.noShadow) {
            const sw = (isSide ? sideWidth + def.w * 0.2 : def.w) * s;
            const sh = 5 * s;
            container.add(scene.add.ellipse(2 * s, (def.h || 20) / 2 * s + 3 * s, sw + 4, sh, 0x000000, 0.12 * alpha));
        }
        
        // Sort parts by depth layer
        const sorted = [...parts].sort((a, b) => (a.z || 0) - (b.z || 0));
        
        for (const part of sorted) {
            // Skip damaged parts
            if (part.breakAt !== undefined && damage >= part.breakAt) continue;
            // Skip parts only shown at certain damage
            if (part.showAt !== undefined && damage < part.showAt) continue;
            
            // Resolve face visibility
            const face = part.face || 'front';
            let visible = true;
            let px = (part.x || 0) * s;
            let py = (part.y || 0) * s;
            let pw = (part.w || 4) * s;
            let ph = (part.h || 4) * s;
            
            if (face === 'front') {
                if (isBack) {
                    visible = false; // front face hidden on back/south wall
                } else if (isSide) {
                    // Compress front to thin sliver receding toward wall
                    pw = Math.max(2, pw * frontCompress);
                    px = sideDir * (sideWidth * s * 0.5 + pw * 0.3);
                }
            } else if (face === 'back') {
                if (!isBack) {
                    visible = false; // back face only visible on south wall
                }
                // When visible, back face draws at full width (same as front on north wall)
            } else if (face === 'side') {
                if (!isSide) {
                    visible = false; // side face hidden on north and back walls
                } else {
                    // Side face becomes dominant
                    pw = sideWidth * s;
                    px = -sideDir * (def.w * s * frontCompress * 0.3);
                }
            } else if (face === 'top') {
                // Top strip — foreshortened thin cap sitting flush on top of front face
                // Part y already positions this at the object's top edge in def space
                // Back wall: camera sees slightly more top since object is closer
                ph = Math.max(2, ph * (isBack ? 0.55 : 0.4));
            }
            // face === 'any' or 'detail' — draw as-is
            
            if (!visible) continue;
            
            // Resolve color
            let color = part.color;
            if (typeof color === 'string' && colors[color] !== undefined) {
                color = colors[color];
            }
            color = this.biomeTint(color, biome);
            
            // Shade adjustments
            if (part.shade === 'dark') color = this.darken(color, 0.18);
            if (part.shade === 'light') color = this.lighten(color, 0.15);
            if (part.shade === 'darker') color = this.darken(color, 0.3);
            if (part.shade === 'lighter') color = this.lighten(color, 0.25);
            
            const partAlpha = (part.alpha !== undefined ? part.alpha : 1) * alpha;
            const partDepth = (part.z || 0) * 0.01;
            
            // Draw based on shape type
            let obj;
            switch (part.type || 'rect') {
                case 'rect':
                    obj = scene.add.rectangle(px, py, pw, ph, color, partAlpha);
                    break;
                case 'ellipse':
                    obj = scene.add.ellipse(px, py, pw, ph, color, partAlpha);
                    break;
                case 'circle':
                    obj = scene.add.circle(px, py, (part.r || 2) * s, color, partAlpha);
                    break;
                case 'triangle':
                    obj = scene.add.triangle(px, py, 
                        0, -(part.th || 6) * s, 
                        -(part.tw || 4) * s, (part.th || 6) * s * 0.5,
                        (part.tw || 4) * s, (part.th || 6) * s * 0.5,
                        color, partAlpha);
                    break;
                case 'line':
                    obj = scene.add.rectangle(px, py, pw, Math.max(1, 1 * s), color, partAlpha);
                    break;
                default:
                    obj = scene.add.rectangle(px, py, pw, ph, color, partAlpha);
            }
            
            if (obj) {
                obj.setDepth(partDepth);
                if (part.angle) obj.setAngle(part.angle);
                container.add(obj);
            }
        }
        
        // Damage overlays
        if (damage > 0.1) {
            const numCracks = Math.floor(damage * 4);
            for (let i = 0; i < numCracks; i++) {
                const cx = (Math.random() - 0.5) * def.w * s * 0.6;
                const cy = (Math.random() - 0.5) * def.h * s * 0.4;
                const cw = (2 + Math.random() * 4) * s;
                const ch = 1 * s;
                const crack = scene.add.rectangle(cx, cy, cw, ch, 0x1a1a1a, 0.3 * damage * alpha);
                crack.setAngle(Math.random() * 40 - 20);
                crack.setDepth(0.5);
                container.add(crack);
            }
        }
        
        // Scatter items (random detail objects on shelves etc.)
        if (def.scatter && !isSide) {
            const pool = def.scatter;
            const count = Math.min(pool.length, Math.floor(3 + Math.random() * 3));
            for (let i = 0; i < count; i++) {
                const item = pool[i % pool.length];
                const sx = (item.x || 0) * s + (Math.random() - 0.5) * 3 * s;
                const sy = (item.y || 0) * s;
                const sw = (item.w || 2) * s;
                const sh = (item.h || 3) * s;
                const sObj = scene.add.rectangle(sx, sy, sw, sh, item.color, (item.alpha || 0.7) * alpha);
                sObj.setDepth(0.4);
                container.add(sObj);
            }
        }
        
        container.setAlpha(alpha);
        return container;
    },
    

};
