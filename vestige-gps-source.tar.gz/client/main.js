// Vestige GPS — Client Entry Point
// Creates Phaser game instance, wires core↔renderer bridges, registers scenes

import Phaser from 'phaser';

// === Core imports ===
import { BossAI } from '../core/bossAI.js';
import { CombatSystem } from '../core/combatSystem.js';
import { CombatHelper } from '../core/combatHelper.js';
import { ConsumableSystem } from '../core/consumableSystem.js';
import { DOTManager } from '../core/dotManager.js';
import { DOTSystem } from '../core/dotSystem.js';
import { EnemyAI } from '../core/enemyAI.js';
import { EnemyManager } from '../core/enemyManager.js';
import { NPCManager } from '../core/npcManager.js';
import { SignatureEffects } from '../core/signatureEffects.js';
import { SceneTransition } from '../core/sceneTransition.js';
import { WeatherSystem } from '../core/weatherSystem.js';

// === Renderer imports ===
import { BossRenderer } from './rendering/bossRenderer.js';
import { CombatRenderer } from './rendering/combatRenderer.js';
import { CombatHitRenderer } from './rendering/combatHitRenderer.js';
import { ConsumableRenderer } from './rendering/consumableRenderer.js';
import { DOTManagerRenderer } from './rendering/dotManagerRenderer.js';
import { DOTRenderer } from './rendering/dotRenderer.js';
import { EnemyAIRenderer } from './rendering/enemyAIRenderer.js';
import { EnemyManagerRenderer } from './rendering/enemyManagerRenderer.js';
import { NPCRenderer } from './rendering/npcRenderer.js';
import { SignatureRenderer } from './rendering/signatureRenderer.js';
import { SceneTransitionRenderer } from './rendering/sceneTransition.js';
import { WeatherRenderer } from './rendering/weatherRenderer.js';

// === Scene imports ===
import { BootScene } from './scenes/BootScene.js';
import { TestScene } from './scenes/TestScene.js';
import { TitleScene } from './scenes/TitleScene.js';
import { BiomeSelectScene } from './scenes/BiomeSelectScene.js';
import { SurvivorSelectScene } from './scenes/SurvivorSelectScene.js';
import { SafehouseScene } from './scenes/SafehouseScene.js';
import { MapScene } from './scenes/MapScene.js';
import { GameScene } from './scenes/GameScene.js';
import { InteriorScene } from './scenes/InteriorScene.js';
import { HavenScene } from './scenes/HavenScene.js';
import { PortalDungeonScene } from './scenes/PortalDungeonScene.js';
import { StoryScene } from './scenes/StoryScene.js';
import { TraversalScene } from './scenes/TraversalScene.js';
import { CubeSimScene } from './scenes/CubeSimScene.js';
import { OverworldScene } from './scenes/OverworldScene.js';

// Wire all core↔renderer bridges
function wireBridges() {
    BossAI.init(BossRenderer);
    CombatSystem.init(CombatRenderer);
    CombatHelper.init(CombatHitRenderer);
    ConsumableSystem.init(ConsumableRenderer);
    DOTManager.init(DOTManagerRenderer);
    DOTSystem.init(DOTRenderer);
    EnemyAI.init(EnemyAIRenderer);
    EnemyManager.init(EnemyManagerRenderer);
    NPCManager.init(NPCRenderer);
    SignatureEffects.init(SignatureRenderer);
    SceneTransition.init(SceneTransitionRenderer);
    WeatherSystem.init(WeatherRenderer);
    console.log('[Vestige] 12 core↔renderer bridges wired');
}

// Detect mobile
const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
const dpr = Math.min(window.devicePixelRatio || 1, 2);

// Game dimensions — mobile-first, letterboxed on desktop
const BASE_W = 375;
const BASE_H = 667;

// Create Phaser game
const config = {
    type: Phaser.AUTO,
    parent: 'game-container',
    width: BASE_W,
    height: BASE_H,
    pixelArt: true,
    roundPixels: true,
    antialias: false,
    backgroundColor: '#0a0a0a',
    scale: {
        mode: Phaser.Scale.FIT,
        autoCenter: Phaser.Scale.CENTER_BOTH,
        min: { width: 320, height: 480 },
        max: { width: 500, height: 900 }
    },
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0 },
            debug: false
        }
    },
    scene: [BootScene, TestScene, TitleScene, BiomeSelectScene, SurvivorSelectScene,
            SafehouseScene, MapScene, GameScene, InteriorScene, HavenScene,
            PortalDungeonScene, StoryScene, TraversalScene, CubeSimScene, OverworldScene],
    input: {
        activePointers: isMobile ? 3 : 1
    },
    fps: {
        target: 60,
        forceSetTimeOut: false
    },
    callbacks: {
        preBoot: () => {
            wireBridges();
        }
    }
};

const game = new Phaser.Game(config);

// Handle resize
window.addEventListener('resize', () => {
    game.scale.refresh();
});

// Expose for debug
if (typeof window !== 'undefined') {
    window.__vestige = { game, BossAI, CombatSystem, EnemyAI, EnemyManager, DOTManager };
}

export default game;
