// Vestige GPS — CRTTerminal
// Extracted from monolith lines 36183-38958
// TODO: convert internal global refs to imports

import { Haptics } from '../core/haptics.js';
import { RealtimeTOD } from '../core/realtimeTOD.js';
import { RouteGenerator } from '../core/routeGenerator.js';
import { SaveManager } from '../core/saveManager.js';
import { SurvivorGenerator } from '../core/survivorGenerator.js';
import { Utils, uiPx } from '../core/utils.js';
import { WeatherSystem } from '../core/weatherSystem.js';
import { CONFIG } from '../data/config.js';
import { AudioManager } from './audioManager.js';
import { IsoRenderer } from './isoRenderer.js';
import { SpriteManager } from './spriteManager.js';
import { UIManager } from './uiManager.js';
import { CRTTypewriter } from './crtTypewriter.js';
import { MapScene } from './scenes/MapScene.js';


export const CRTTerminal = {
    showTerminal(scene) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        const pW = Math.min(W - 20, 340), pH = H - 100;
        const cam = scene.cameras.main;
        const cx = (cam.scrollX || 0) + W/2;
        const cy = (cam.scrollY || 0) + H/2;
        
        // Biome-aware CRT phosphor palette
        const biomeId = (scene.saveData && scene.saveData.biome) || 'grassy';
        const crtPalettes = {
            grassy: {
                screenBg1: 0x040804, screenBg2: 0x080e08,
                scanline: 0x0a1a0a, reflection: 0x1a3a1a,
                led: 0x22aa22, ledAlpha: 0.6,
                tabBg: 0x0a1a0a, tabStroke: 0x2a4a2a,
                tabText: '#3a6a3a', tabHover: 0x1a2a1a,
                tabActive: 0x1a3a1a,
                label: '#2a6a2a', labelHi: '#44aa44',
                reachColor: '#4a9a4a',
                glow: 0x22aa22, glowMid: 0x33bb33, glowBright: 0x44cc44,
                textDim: '#3a6a3a', textMid: '#4a9a4a', textHi: '#44cc44',
                lineDim: 0x1a3a1a, lineMid: 0x2a4a2a
            },
            barren: {
                screenBg1: 0x080604, screenBg2: 0x0e0c08,
                scanline: 0x1a160a, reflection: 0x3a2e1a,
                led: 0xaa8822, ledAlpha: 0.6,
                tabBg: 0x1a140a, tabStroke: 0x4a3e2a,
                tabText: '#6a5a3a', tabHover: 0x2a2418,
                tabActive: 0x3a2e1a,
                label: '#6a5a2a', labelHi: '#aa9944',
                reachColor: '#9a8a4a',
                glow: 0xaa8822, glowMid: 0xbb9933, glowBright: 0xccaa44,
                textDim: '#6a5a3a', textMid: '#9a8a4a', textHi: '#ccaa44',
                lineDim: 0x3a2e1a, lineMid: 0x4a3e2a
            },
            apocalyptic: {
                screenBg1: 0x060408, screenBg2: 0x0a080e,
                scanline: 0x120a1a, reflection: 0x2a1a3a,
                led: 0x8844aa, ledAlpha: 0.7,
                tabBg: 0x0e0818, tabStroke: 0x3a2a5a,
                tabText: '#5a3a7a', tabHover: 0x1a1028,
                tabActive: 0x2a1a3a,
                label: '#5a3a6a', labelHi: '#aa66cc',
                reachColor: '#7a5a9a',
                glow: 0x8844aa, glowMid: 0x9955bb, glowBright: 0xaa66cc,
                textDim: '#5a3a7a', textMid: '#7a5a9a', textHi: '#aa66cc',
                lineDim: 0x2a1a3a, lineMid: 0x3a2a5a
            }
        };
        const crt = crtPalettes[biomeId] || crtPalettes.grassy;
        scene._crtPalette = crt; // Store for tab rendering
        
        // Build CRT terminal as a raw container (custom frame, not createPanel)
        const container = scene.add.container(cx, cy).setDepth(200);
        scene.currentPopup = container;
        
        // Modal backdrop — tap outside terminal to dismiss
        const backdrop = scene.add.rectangle(0, 0, W + 40, H + 40, 0x000000, 0.75);
        backdrop.setInteractive();
        backdrop.on('pointerdown', () => {
            if (scene._mapMaskShape) { scene._mapMaskShape.destroy(); scene._mapMaskShape = null; }
            if (scene._mapPulseTweens) { scene._mapPulseTweens.forEach(t => t.remove()); scene._mapPulseTweens = null; }
            if (scene._mapThreatTweens) { scene._mapThreatTweens.forEach(t => t.remove()); scene._mapThreatTweens = null; }
            if (scene._mapDetailCard) { scene._mapDetailCard.destroy(); scene._mapDetailCard = null; }
            if (scene._mapCleanupInput) CRTTerminal._mapCleanupInput(scene);
            scene._termContent = null; scene._termTabs = null;
            scene.popupActive = false; container.destroy();
        });
        container.add(backdrop);
        
        // === CRT MONITOR BEZEL ===
        // Outer housing (dark grey plastic) — interactive to absorb taps (prevent backdrop dismiss)
        const bezelOuter = scene.add.rectangle(0, 0, pW + 14, pH + 14, 0x1a1a1a);
        bezelOuter.setInteractive();
        container.add(bezelOuter);
        container.add(scene.add.rectangle(0, 0, pW + 12, pH + 12, 0x222222));
        // Bevel highlight (top-left lighter, bottom-right darker)
        container.add(scene.add.rectangle(0, -(pH + 12)/2, pW + 12, 2, 0x333333));
        container.add(scene.add.rectangle(-(pW + 12)/2, 0, 2, pH + 12, 0x2e2e2e));
        container.add(scene.add.rectangle(0, (pH + 12)/2, pW + 12, 2, 0x111111));
        container.add(scene.add.rectangle((pW + 12)/2, 0, 2, pH + 12, 0x141414));
        // Inner bezel (recessed frame around screen)
        container.add(scene.add.rectangle(0, 0, pW + 4, pH + 4, 0x0a0a0a));
        
        // === CRT SCREEN AREA ===
        const scrW = pW - 8, scrH = pH - 48;
        const scrY = -16;
        container.add(scene.add.rectangle(0, scrY, scrW + 2, scrH + 2, crt.screenBg1));
        container.add(scene.add.rectangle(0, scrY, scrW, scrH, crt.screenBg2));
        // Scanlines
        for (let sl = 0; sl < Math.floor(scrH / 4); sl++) {
            container.add(scene.add.rectangle(0, scrY - scrH/2 + sl * 4, scrW, 1, crt.scanline, 0.2));
        }
        // Screen edge vignette (inner shadow)
        container.add(scene.add.rectangle(0, scrY - scrH/2, scrW, 3, 0x000000, 0.4));
        container.add(scene.add.rectangle(0, scrY + scrH/2, scrW, 3, 0x000000, 0.3));
        container.add(scene.add.rectangle(-scrW/2, scrY, 3, scrH, 0x000000, 0.3));
        container.add(scene.add.rectangle(scrW/2, scrY, 3, scrH, 0x000000, 0.3));
        // Screen reflection (subtle diagonal highlight)
        container.add(scene.add.rectangle(-scrW/4, scrY - scrH/4, scrW * 0.4, 2, crt.reflection, 0.08).setAngle(-15));
        
        // === POWER LED ===
        container.add(scene.add.circle(-pW/2 + 12, pH/2 + 2, 2, crt.led, crt.ledAlpha));
        
        // === STATUS BAR (bottom of screen — time, celestial icon, weather) ===
        const statusY = scrY + scrH/2 - 10;
        const statusG = scene.add.graphics();
        // Divider line above status
        statusG.lineStyle(1, crt.lineDim || 0x1a3a1a, 0.4);
        statusG.beginPath(); statusG.moveTo(-scrW/2 + 6, statusY - 6); statusG.lineTo(scrW/2 - 6, statusY - 6); statusG.stroke();
        container.add(statusG);
        
        // Celestial icon (sun/moon)
        RealtimeTOD.drawCelestialIcon(statusG, -scrW/2 + 18, statusY + 2, crt);
        
        // Time text
        const now = new Date();
        const timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
        const todLabel = RealtimeTOD.getFromClock().toUpperCase();
        container.add(scene.add.text(-scrW/2 + 34, statusY + 2, timeStr, {
            fontFamily: 'monospace', fontSize: uiPx(8), fill: crt.textMid || '#4a9a4a'
        }).setOrigin(0, 0.5));
        container.add(scene.add.text(-scrW/2 + 72, statusY + 2, todLabel, {
            fontFamily: 'monospace', fontSize: uiPx(7), fill: crt.textDim || '#3a6a3a'
        }).setOrigin(0, 0.5));
        
        // Weather label (right-aligned)
        const weatherName = scene._weatherEffect ? scene._weatherEffect.name : 'clear';
        const weatherLabel = WeatherSystem.getLabel(weatherName);
        container.add(scene.add.text(scrW/2 - 8, statusY + 2, weatherLabel, {
            fontFamily: 'monospace', fontSize: uiPx(7), fill: crt.textDim || '#3a6a3a'
        }).setOrigin(1, 0.5));
        
        // === TABS (inside screen area, top) ===
        const tabNames = ['MAP', 'SQUAD', 'QUESTS', 'FACTIONS'];
        const tabW = (scrW - 8) / tabNames.length;
        scene._termTabs = [];
        scene._termContent = scene.add.container(0, 0);
        container.add(scene._termContent);
        tabNames.forEach((label, i) => {
            const tx = -scrW/2 + 4 + tabW * i + tabW/2;
            const tabBg = scene.add.rectangle(tx, scrY - scrH/2 + 13, tabW - 2, 20, crt.tabBg).setStrokeStyle(1, crt.tabStroke);
            const tabText = scene.add.text(tx, scrY - scrH/2 + 13, label, { fontFamily: 'monospace', fontSize: uiPx(9), fill: crt.tabText }).setOrigin(0.5);
            container.add(tabBg); container.add(tabText);
            tabBg.setInteractive({ useHandCursor: true })
                .on('pointerdown', () => CRTTerminal.showTerminalTab(scene, i))
                .on('pointerover', () => { if (scene._activeTab !== i) tabBg.setFillStyle(crt.tabHover); })
                .on('pointerout', () => { if (scene._activeTab !== i) tabBg.setFillStyle(crt.tabBg); });
            scene._termTabs.push({ bg: tabBg, text: tabText });
        });
        
        scene._activeTab = -1;
        scene._termPanelW = pW;
        scene._termPanelH = pH;
        scene._termScrY = scrY;
        scene._termScrH = scrH;
        scene._termScrW = scrW;
        
        // === SCREEN FLICKER (#1) — subtle alpha oscillation on screen ===
        const screenRect = container.list.find(c => c.fillColor === crt.screenBg2);
        if (screenRect) {
            scene.tweens.add({
                targets: screenRect, alpha: { from: 1.0, to: 0.96 },
                duration: 125, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
            });
        }
        
        // === CRT BOOT SEQUENCE (#4) ===
        try { AudioManager.crtBoot(); } catch(e) {}
        
        if (!scene._crtBooted) {
            scene._crtBooted = true;
            
            // Hide tabs during boot
            scene._termTabs.forEach(t => { t.bg.setAlpha(0); t.text.setAlpha(0); });
            
            const bootLines = ['INITIALIZING...', 'ROUTE PLANNER v2.1', 'SIGNAL ACQUIRED'];
            const bootTexts = [];
            const bootStartY = scrY - 20;
            
            bootLines.forEach((line, i) => {
                const bt = scene.add.text(0, bootStartY + i * 18, '', {
                    fontFamily: 'monospace', fontSize: uiPx(10),
                    fill: crt.textMid || '#4a9a4a'
                }).setOrigin(0.5).setAlpha(0);
                container.add(bt);
                bootTexts.push(bt);
            });
            
            // Simple staggered reveal — no chained callbacks
            const lineDelay = [100, 700, 1200]; // when each line starts typing
            const bootEndTime = 1800; // hard cutoff — show content at this time regardless
            
            bootLines.forEach((line, i) => {
                scene.time.delayedCall(lineDelay[i], () => {
                    if (!bootTexts[i] || !bootTexts[i].active) return;
                    bootTexts[i].setAlpha(1);
                    bootTexts[i].setText(line);
                    CRTTypewriter.type(scene, bootTexts[i], { speed: 35, sound: true });
                });
            });
            
            // Hard fallback — show tabs + content after boot time
            scene.time.delayedCall(bootEndTime, () => {
                bootTexts.forEach(bt => {
                    if (bt && bt.active) {
                        scene.tweens.add({ targets: bt, alpha: 0, duration: 200, onComplete: () => { if (bt.active) bt.destroy(); } });
                    }
                });
                if (scene._termTabs) {
                    scene._termTabs.forEach(t => {
                        if (t.bg && t.bg.active) t.bg.setAlpha(1);
                        if (t.text && t.text.active) t.text.setAlpha(1);
                    });
                }
                if (scene._termContent && scene._activeTab < 0) CRTTerminal.showTerminalTab(scene, 0);
            });
        } else {
            CRTTerminal.showTerminalTab(scene, 0);
        }
    },

    showTerminalTab(scene, idx) {
        if (scene._activeTab === idx) return;
        if (!scene._termContent) return;
        scene._activeTab = idx;
        try { AudioManager.crtBeep(); } catch(e) {}
        
        // Update tab styling
        const crt = scene._crtPalette || { tabActive: 0x1a3a1a, tabBg: 0x0a1a0a, tabStroke: 0x2a4a2a, tabText: '#3a6a3a', labelHi: '#44aa44' };
        scene._termTabs.forEach((t, i) => {
            t.bg.setFillStyle(i === idx ? crt.tabActive : crt.tabBg);
            t.bg.setStrokeStyle(1, i === idx ? IsoRenderer.lighten(crt.tabStroke, 0.3) : crt.tabStroke);
            t.text.setColor(i === idx ? crt.labelHi : crt.tabText);
        });
        
        // Clear content (cleanup map mask if present)
        if (scene._mapMaskShape) { scene._mapMaskShape.destroy(); scene._mapMaskShape = null; }
        if (scene._mapFuelLabels) { scene._mapFuelLabels.forEach(l => { if (l.scene) l.destroy(); }); scene._mapFuelLabels = null; }
        if (scene._mapPulseTweens) { scene._mapPulseTweens.forEach(t => t.remove()); scene._mapPulseTweens = null; }
        if (scene._mapThreatTweens) { scene._mapThreatTweens.forEach(t => t.remove()); scene._mapThreatTweens = null; }
        if (scene._mapDetailCard) { scene._mapDetailCard.destroy(); scene._mapDetailCard = null; }
        if (scene._crtCardOverlay) { scene._crtCardOverlay.destroy(); scene._crtCardOverlay = null; }
        if (scene._crtDismissHandler) { scene.input.off('pointerdown', scene._crtDismissHandler); scene._crtDismissHandler = null; }
        if (scene._mapCleanupInput) CRTTerminal._mapCleanupInput(scene);
        scene._mapNodeObjects = null;
        scene._mapReachData = null;
        scene._mapContent = null;
        scene._termContent.removeAll(true);
        
        const scrW = scene._termScrW || 260;
        const scrH = scene._termScrH || 280;
        const scrY = scene._termScrY || -16;
        const contentY = scrY - scrH/2 + 38;
        const contentH = scrH - 70; // 50 for tabs + 20 for status bar
        const cw = scrW - 20;
        
        if (idx === 0) { try { CRTTerminal.terminalMapTab(scene, contentY, contentH, cw); } catch(e) { console.error('CRT map tab error:', e); } }
        else if (idx === 1) { try { CRTTerminal.terminalSquadTab(scene, contentY, contentH, cw); } catch(e) { console.error('CRT squad tab error:', e); } }
        else if (idx === 2) { try { CRTTerminal.terminalQuestsTab(scene, contentY, contentH, cw); } catch(e) { console.error('CRT quests tab error:', e); } }
        else if (idx === 3) { try { CRTTerminal.terminalFactionsTab(scene, contentY, contentH, cw); } catch(e) { console.error('CRT factions tab error:', e); } }
    },

    _tAdd(scene, obj) { scene._termContent.add(obj); return obj; },

    terminalMapTab(scene, startY, h, w) {
        const biomeId = scene.saveData.biome || 'grassy';
        const reach = scene.saveData.currentReach || 1;
        
        if (!scene.saveData.routeSeed) {
            scene.saveData.routeSeed = Date.now();
            SaveManager.save(scene.saveData);
        }
        
        if (scene.saveData.activeRoute && scene.saveData.activeRoute.status === 'locked') {
            CRTTerminal._termMapShowLocked(scene, startY, h, w);
            return;
        }
        
        const reachData = RouteGenerator.generateReach(scene.saveData.routeSeed, reach, biomeId);
        scene._mapReachData = reachData;
        scene._mapRoute = [reachData.meta.anchorId];
        scene._mapScrollX = 0;
        scene._mapPreviewNode = null;
        scene._mapDetailCard = null;
        scene._mapScrollVel = 0;
        
        // Determine current time-of-day from first route node
        const anchorNode = reachData.nodes[reachData.meta.anchorId];
        const currentTod = anchorNode ? anchorNode.timeOfDay || 'midday' : 'midday';
        
        // Compact header with time-of-day icon
        const crt = scene._crtPalette || { label: '#2a6a2a', labelHi: '#44aa44', reachColor: '#4a9a4a' };
        const biomeDef = CONFIG.biomes ? CONFIG.biomes[biomeId] : null;
        const biomeLabel = biomeDef ? biomeDef.name : biomeId;
        const todColors = { dawn: '#aa8844', midday: crt.reachColor, dusk: '#8a4a2a', night: '#4444aa' };
        const todLabels = { dawn: 'DAWN', midday: 'DAY', dusk: 'DUSK', night: 'NIGHT' };
        CRTTerminal._tAdd(scene, scene.add.text(-w/2, startY, `REACH ${reach}`, {
            fontFamily: 'monospace', fontSize: uiPx(12), fill: todColors[currentTod] || crt.reachColor, fontStyle: 'bold'
        }));
        CRTTerminal._tAdd(scene, scene.add.text(w/2, startY, biomeLabel.toUpperCase(), {
            fontFamily: 'monospace', fontSize: uiPx(10), fill: crt.label
        }).setOrigin(1, 0));
        
        // HUD bar height
        const hudH = 28;
        const mapTop = startY + 18;
        const mapH = h - 18 - hudH - 4;
        const mapW = w;
        
        // Dark background + scanlines
        const bg = scene.add.graphics();
        CRTTerminal._tAdd(scene, bg);
        bg.fillStyle(crt.screenBg1, 0.95);
        bg.fillRect(-mapW/2, mapTop, mapW, mapH);
        bg.lineStyle(0.5, crt.scanline, 0.2);
        for (let gy = mapTop + 3; gy < mapTop + mapH; gy += 3) {
            bg.lineBetween(-mapW/2 + 1, gy, mapW/2 - 1, gy);
        }
        bg.lineStyle(1, crt.reflection, 0.6);
        bg.strokeRect(-mapW/2, mapTop, mapW, mapH);
        
        // === TOUCH SCROLL via scene-level input (no blocking dragZone) ===
        scene._mapDragActive = false;
        scene._mapIsDragging = false;
        scene._mapDragStartX = 0;
        scene._mapDragTotalDist = 0;
        scene._mapLastDragTime = 0;
        
        // Store map bounds in SCREEN coords for pointer hit testing
        scene._mapWorldBounds = {
            x: CONFIG.width / 2 - mapW/2,
            y: CONFIG.height / 2 + mapTop,
            w: mapW,
            h: mapH
        };
        
        // Scene-level pointer handlers
        scene._mapPtrDown = (pointer) => {
            const mb = scene._mapWorldBounds;
            if (!mb) return;
            if (pointer.x >= mb.x && pointer.x <= mb.x + mb.w &&
                pointer.y >= mb.y && pointer.y <= mb.y + mb.h) {
                scene._mapDragActive = true;
                scene._mapIsDragging = false;
                scene._mapDragStartX = pointer.x;
                scene._mapDragTotalDist = 0;
                scene._mapScrollVel = 0;
            }
        };
        scene._mapPtrMove = (pointer) => {
            if (!scene._mapDragActive || !pointer.isDown) return;
            const dx = pointer.x - scene._mapDragStartX;
            scene._mapDragStartX = pointer.x;
            scene._mapDragTotalDist += Math.abs(dx);
            if (scene._mapDragTotalDist > 5) scene._mapIsDragging = true;
            if (scene._mapIsDragging) {
                scene._mapScrollVel = dx;
                scene._mapLastDragTime = Date.now();
                CRTTerminal._mapApplyScroll(scene, dx);
            }
        };
        scene._mapPtrUp = () => {
            if (scene._mapDragActive && scene._mapIsDragging) {
                // Inertia
                if (Math.abs(scene._mapScrollVel) > 2 && Date.now() - scene._mapLastDragTime < 80) {
                    const vel = scene._mapScrollVel;
                    let frame = 0;
                    const decay = () => {
                        frame++;
                        const d = vel * Math.pow(0.88, frame);
                        if (Math.abs(d) < 0.3 || frame > 35) return;
                        CRTTerminal._mapApplyScroll(scene, d);
                        if (scene.time) scene.time.delayedCall(16, decay);
                    };
                    decay();
                }
            }
            scene._mapDragActive = false;
            // Reset isDragging after a tick so node pointerdown can check it
            if (scene.time) scene.time.delayedCall(30, () => { scene._mapIsDragging = false; });
        };
        
        scene.input.on('pointerdown', scene._mapPtrDown);
        scene.input.on('pointermove', scene._mapPtrMove);
        scene.input.on('pointerup', scene._mapPtrUp);
        
        // Scrollable map content
        const mapContent = scene.add.container(0, 0);
        CRTTerminal._tAdd(scene, mapContent);
        scene._mapContent = mapContent;
        
        // Geometry mask (needs world coords)
        const maskShape = scene.make.graphics({ x: 0, y: 0 });
        const cam = scene.cameras.main;
        const worldCx = (cam.scrollX || 0) + CONFIG.width / 2;
        const worldCy = (cam.scrollY || 0) + CONFIG.height / 2;
        maskShape.fillStyle(0xffffff);
        maskShape.fillRect(worldCx - mapW/2, worldCy + mapTop, mapW, mapH);
        mapContent.setMask(maskShape.createGeometryMask());
        scene._mapMaskShape = maskShape;
        
        // Layout
        const allNodes = Object.values(reachData.nodes);
        const minY = Math.min(...allNodes.map(n => n.y));
        const maxY = Math.max(...allNodes.map(n => n.y));
        const yRange = Math.max(1, maxY - minY);
        const yPad = 30;
        const yScale = (mapH - yPad * 2) / yRange;
        const yOff = mapTop + yPad - minY * yScale;
        
        const minX = Math.min(...allNodes.map(n => n.x));
        const maxX = Math.max(...allNodes.map(n => n.x));
        const xRange = Math.max(1, maxX - minX);
        const colSpacing = 100;
        const totalCols = reachData.meta.colCount + 2;
        const desiredWidth = totalCols * colSpacing;
        const xScale = desiredWidth / xRange;
        const xOff = 40 - minX * xScale;
        
        const mapToScreen = (nx, ny) => ({ sx: nx * xScale + xOff, sy: ny * yScale + yOff });
        
        // Compute actual node screen bounds for scroll clamping
        const allScreenX = allNodes.map(n => mapToScreen(n.x, n.y).sx);
        const maxScreenX = Math.max(...allScreenX);
        const minScreenX = Math.min(...allScreenX);
        
        scene._mapViewW = mapW;
        scene._mapViewTop = mapTop;
        scene._mapViewH = mapH;
        // Store node bounds for scroll clamping
        scene._mapMaxNodeX = maxScreenX;
        scene._mapMinNodeX = minScreenX;
        
        // === BIOME DECORATIONS — CRT pixel props ===
        const decorG = scene.add.graphics();
        mapContent.add(decorG);
        const rng = Utils.createRNG(scene.saveData.routeSeed + 999);
        const rr = () => rng();
        for (let dx = 10; dx < maxScreenX + 40; dx += 50 + Math.floor(rr() * 50)) {
            const dy = mapTop + 15 + rr() * (mapH - 30);
            const tooClose = allNodes.some(n => {
                const sp = mapToScreen(n.x, n.y);
                return Math.abs(sp.sx - dx) < 24 && Math.abs(sp.sy - dy) < 24;
            });
            if (tooClose) continue;
            
            const da = 0.5 + rr() * 0.3;
            const roll = rr();
            
            if (biomeId === 'grassy') {
                // ── OVERGROWN: Green phosphor ──
                if (roll < 0.3) {
                    // Full tree
                    const th = 10 + rr() * 6;
                    decorG.lineStyle(2, 0x338833, da * 0.9);
                    decorG.lineBetween(dx, dy, dx, dy - th);
                    const cw = 6 + rr() * 4;
                    decorG.fillStyle(0x227722, da * 0.7);
                    decorG.fillCircle(dx, dy - th, cw);
                    decorG.fillStyle(0x33aa33, da * 0.5);
                    decorG.fillCircle(dx - 2, dy - th + 2, cw * 0.7);
                    decorG.fillCircle(dx + 3, dy - th - 1, cw * 0.6);
                    decorG.fillStyle(0x44bb44, da * 0.3);
                    decorG.fillCircle(dx + 1, dy - th - 2, cw * 0.35);
                } else if (roll < 0.5) {
                    // Dense bush cluster
                    decorG.fillStyle(0x226622, da * 0.8);
                    decorG.fillCircle(dx, dy - 3, 4 + rr() * 2);
                    decorG.fillCircle(dx + 4, dy - 2, 3 + rr() * 2);
                    decorG.fillCircle(dx - 3, dy - 4, 3);
                    decorG.fillStyle(0x33aa33, da * 0.4);
                    decorG.fillCircle(dx + 1, dy - 5, 2);
                } else if (roll < 0.7) {
                    // Tall grass
                    decorG.lineStyle(1, 0x33aa33, da * 0.7);
                    for (let b = 0; b < 5; b++) {
                        const bx = dx - 4 + b * 2;
                        const bh = 5 + rr() * 5;
                        const lean = (rr() - 0.5) * 3;
                        decorG.lineBetween(bx, dy, bx + lean, dy - bh);
                    }
                    decorG.fillStyle(0x44cc44, da * 0.5);
                    decorG.fillRect(dx - 3, dy - 9 - rr() * 2, 1, 2);
                    decorG.fillRect(dx + 2, dy - 8 - rr() * 2, 1, 2);
                } else if (roll < 0.85) {
                    // Pine/conifer
                    const ph = 12 + rr() * 5;
                    decorG.lineStyle(1.5, 0x336633, da * 0.8);
                    decorG.lineBetween(dx, dy, dx, dy - ph);
                    decorG.fillStyle(0x227722, da * 0.8);
                    decorG.fillTriangle(dx - 5, dy - ph * 0.3, dx, dy - ph, dx + 5, dy - ph * 0.3);
                    decorG.fillTriangle(dx - 4, dy - ph * 0.55, dx, dy - ph + 2, dx + 4, dy - ph * 0.55);
                    decorG.fillStyle(0x33aa33, da * 0.3);
                    decorG.fillTriangle(dx - 3, dy - ph * 0.45, dx, dy - ph + 3, dx + 3, dy - ph * 0.45);
                } else {
                    // Fallen log
                    decorG.fillStyle(0x335533, da * 0.7);
                    decorG.fillRect(dx - 6, dy - 1, 12, 3);
                    decorG.fillStyle(0x447744, da * 0.5);
                    decorG.fillCircle(dx - 6, dy, 2);
                    decorG.fillStyle(0x228822, da * 0.3);
                    decorG.fillRect(dx - 3, dy - 2, 4, 1);
                }
            } else if (biomeId === 'barren') {
                // ── WASTELAND: Amber phosphor ──
                if (roll < 0.3) {
                    // Dead tree — stark bare branches
                    const th = 12 + rr() * 8;
                    decorG.lineStyle(2.5, 0x886644, da * 0.8);
                    decorG.lineBetween(dx, dy, dx + 1, dy - th);
                    decorG.lineStyle(1.5, 0x775533, da * 0.7);
                    const b1y = dy - th * 0.6;
                    decorG.lineBetween(dx, b1y, dx - 5 - rr() * 3, b1y - 4);
                    decorG.lineBetween(dx, b1y + 3, dx + 4 + rr() * 3, b1y);
                    decorG.lineStyle(1, 0x775533, da * 0.5);
                    decorG.lineBetween(dx + 1, dy - th, dx - 2, dy - th - 2);
                    decorG.lineBetween(dx + 1, dy - th, dx + 3, dy - th - 3);
                } else if (roll < 0.5) {
                    // Boulder cluster
                    const bw = 5 + rr() * 4;
                    const bh = 3 + rr() * 3;
                    decorG.fillStyle(0x665544, da * 0.7);
                    decorG.fillRect(dx - bw/2, dy - bh, bw, bh);
                    decorG.fillStyle(0x887755, da * 0.4);
                    decorG.fillRect(dx - bw/2 + 1, dy - bh, bw - 2, 1);
                    decorG.fillStyle(0x554433, da * 0.6);
                    decorG.fillRect(dx + bw/2 + 1, dy - 2, 3, 2);
                    decorG.fillStyle(0x443322, da * 0.3);
                    decorG.fillRect(dx - bw/2 + 1, dy, bw - 1, 1);
                } else if (roll < 0.7) {
                    // Cactus skeleton
                    decorG.lineStyle(2, 0x887744, da * 0.7);
                    decorG.lineBetween(dx, dy, dx, dy - 10 - rr() * 4);
                    const armY = dy - 6;
                    decorG.lineStyle(1.5, 0x887744, da * 0.6);
                    decorG.lineBetween(dx, armY, dx - 3, armY - 1);
                    decorG.lineBetween(dx - 3, armY - 1, dx - 3, armY - 4);
                    decorG.lineBetween(dx, armY + 2, dx + 3, armY + 1);
                    decorG.lineBetween(dx + 3, armY + 1, dx + 3, armY - 2);
                } else if (roll < 0.85) {
                    // Cracked earth
                    decorG.lineStyle(1, 0x886644, da * 0.6);
                    decorG.lineBetween(dx - 4, dy, dx + 5, dy - 1);
                    decorG.lineBetween(dx, dy, dx + 2, dy - 5);
                    decorG.lineBetween(dx + 1, dy - 2, dx - 3, dy - 4);
                    decorG.lineBetween(dx + 3, dy - 1, dx + 6, dy - 3);
                } else {
                    // Skull + bones
                    decorG.fillStyle(0xaa9966, da * 0.6);
                    decorG.fillCircle(dx, dy - 2, 3);
                    decorG.fillStyle(0x443322, da * 0.8);
                    decorG.fillRect(dx - 2, dy - 3, 1, 1);
                    decorG.fillRect(dx + 1, dy - 3, 1, 1);
                    decorG.lineStyle(1, 0x997755, da * 0.4);
                    decorG.lineBetween(dx - 4, dy + 1, dx + 4, dy + 4);
                    decorG.lineBetween(dx + 4, dy + 1, dx - 4, dy + 4);
                }
            } else {
                // ── ANOMALOUS: Purple/Cyan phosphor — cosmic horror ──
                if (roll < 0.2) {
                    // Crystal spire — jagged vertical formation
                    const sh = 12 + rr() * 8;
                    decorG.fillStyle(0x6644aa, da * 0.7);
                    decorG.fillTriangle(dx - 3, dy, dx, dy - sh, dx + 2, dy);
                    decorG.fillStyle(0x8866cc, da * 0.4);
                    decorG.fillTriangle(dx, dy - sh, dx + 2, dy, dx + 4, dy - sh * 0.4);
                    // Glow at tip
                    decorG.fillStyle(0x44dddd, da * 0.5);
                    decorG.fillRect(dx - 1, dy - sh, 2, 2);
                    decorG.fillStyle(0x44dddd, da * 0.15);
                    decorG.fillCircle(dx, dy - sh, 3);
                } else if (roll < 0.4) {
                    // Cube fragment — geometric debris
                    const cs = 4 + rr() * 3;
                    decorG.fillStyle(0x553388, da * 0.6);
                    decorG.fillRect(dx - cs, dy - cs, cs * 2, cs * 2);
                    // Inner void
                    decorG.fillStyle(0x220044, da * 0.9);
                    decorG.fillRect(dx - cs + 2, dy - cs + 2, cs * 2 - 4, cs * 2 - 4);
                    // Cyan edge highlights
                    decorG.lineStyle(1, 0x44aacc, da * 0.7);
                    decorG.strokeRect(dx - cs, dy - cs, cs * 2, cs * 2);
                    // Small orbiting shard
                    decorG.fillStyle(0x7744bb, da * 0.5);
                    decorG.fillRect(dx + cs + 2, dy - 2, 2, 3);
                } else if (roll < 0.55) {
                    // Fungal cluster — organic growths
                    decorG.fillStyle(0x553366, da * 0.7);
                    decorG.fillCircle(dx, dy - 3, 4);
                    decorG.fillCircle(dx + 4, dy - 1, 3);
                    decorG.fillCircle(dx - 3, dy - 5, 2.5);
                    // Spore dots
                    decorG.fillStyle(0x44ccaa, da * 0.6);
                    decorG.fillRect(dx - 1, dy - 5, 1, 1);
                    decorG.fillRect(dx + 3, dy - 3, 1, 1);
                    decorG.fillRect(dx - 2, dy - 7, 1, 1);
                    // Stalk
                    decorG.lineStyle(1, 0x443355, da * 0.5);
                    decorG.lineBetween(dx, dy, dx, dy - 3);
                } else if (roll < 0.7) {
                    // Organ pillar — fleshy vertical structure
                    const oh = 14 + rr() * 6;
                    decorG.lineStyle(3, 0x664477, da * 0.8);
                    decorG.lineBetween(dx, dy, dx, dy - oh);
                    // Ribbed segments
                    decorG.lineStyle(1, 0x885599, da * 0.5);
                    for (let seg = 0; seg < 4; seg++) {
                        const sy = dy - oh * 0.2 - seg * (oh * 0.2);
                        decorG.lineBetween(dx - 3, sy, dx + 3, sy);
                    }
                    // Pulsing tip
                    decorG.fillStyle(0xcc66aa, da * 0.6);
                    decorG.fillCircle(dx, dy - oh, 2.5);
                } else if (roll < 0.85) {
                    // Geometric crater — hexagonal depression
                    const cr = 5 + rr() * 3;
                    decorG.fillStyle(0x1a0a2a, da * 0.7);
                    decorG.fillCircle(dx, dy, cr);
                    decorG.lineStyle(1, 0x6644aa, da * 0.6);
                    // Hex outline
                    decorG.beginPath();
                    for (let a = 0; a < 6; a++) {
                        const angle = a * Math.PI / 3 - Math.PI / 6;
                        const hx = dx + Math.cos(angle) * cr;
                        const hy = dy + Math.sin(angle) * cr;
                        if (a === 0) decorG.moveTo(hx, hy);
                        else decorG.lineTo(hx, hy);
                    }
                    decorG.closePath(); decorG.stroke();
                    // Center crystal
                    decorG.fillStyle(0x44dddd, da * 0.5);
                    decorG.fillRect(dx - 1, dy - 1, 2, 2);
                } else {
                    // Converted wreckage — machine overgrown with crystalline growth
                    decorG.fillStyle(0x3a2a44, da * 0.6);
                    decorG.fillRect(dx - 5, dy - 2, 10, 4);
                    // Crystal eruptions from surface
                    decorG.fillStyle(0x7744bb, da * 0.7);
                    decorG.fillTriangle(dx - 3, dy - 2, dx - 1, dy - 8, dx + 1, dy - 2);
                    decorG.fillTriangle(dx + 2, dy - 2, dx + 3, dy - 6, dx + 5, dy - 2);
                    decorG.fillStyle(0x44aacc, da * 0.4);
                    decorG.fillRect(dx - 2, dy - 7, 1, 1);
                    decorG.fillRect(dx + 3, dy - 5, 1, 1);
                }
            }
        }
        
        // Glow + edge layers
        const glowG = scene.add.graphics();
        mapContent.add(glowG);
        scene._mapGlowG = glowG;
        const edgeG = scene.add.graphics();
        mapContent.add(edgeG);
        scene._mapEdgeG = edgeG;
        
        // === BUILD REACHABLE SET (BFS from safehouse) ===
        const reachableNodes = new Set([reachData.meta.anchorId]);
        let changed = true;
        while (changed) {
            changed = false;
            reachData.edges.forEach(e => {
                if (reachableNodes.has(e.from) && !reachableNodes.has(e.to)) {
                    reachableNodes.add(e.to);
                    changed = true;
                }
            });
        }
        scene._mapReachableNodes = reachableNodes;
        
        // Node sizes (for hit zones and edge attachment — no visible frames)
        const nodeFrameW = 30, nodeFrameH = 28;
        const bossFrameW = 44, bossFrameH = 40;
        
        // Draw nodes
        scene._mapNodeObjects = {};
        scene._mapFuelLabels = [];
        scene._mapPulseTweens = [];
        allNodes.forEach(n => {
            if (!reachableNodes.has(n.id)) return;
            const pos = mapToScreen(n.x, n.y);
            const nodeC = scene.add.container(pos.sx, pos.sy);
            mapContent.add(nodeC);
            
            const isBoss = n.type === 'boss';
            const fw = isBoss ? bossFrameW : nodeFrameW;
            const fh = isBoss ? bossFrameH : nodeFrameH;
            const alpha = (n.discovered || n.col <= 1) ? 0.9 : 0.55;
            
            // Boss gets radial glow
            if (isBoss) {
                const glowRing = scene.add.graphics();
                glowRing.fillStyle(0xaa2222, 0.06);
                glowRing.fillCircle(0, 0, 28);
                glowRing.fillStyle(0xcc3333, 0.04);
                glowRing.fillCircle(0, 0, 22);
                glowRing.lineStyle(1, 0xaa3333, 0.25);
                glowRing.strokeCircle(0, 0, 24);
                nodeC.add(glowRing);
            }
            
            // Ground shadow (layered for smooth blending)
            const shadowG = scene.add.graphics();
            const sr = isBoss ? 16 : 10;
            const sy = isBoss ? 6 : 4;
            shadowG.fillStyle(0x0a0a0a, 0.06);
            shadowG.fillEllipse(0, sy, sr * 2.4, sr * 1.0);
            shadowG.fillStyle(0x0a0a0a, 0.1);
            shadowG.fillEllipse(0, sy, sr * 1.8, sr * 0.7);
            shadowG.fillStyle(0x0a0a0a, 0.12);
            shadowG.fillEllipse(0, sy, sr * 1.2, sr * 0.5);
            nodeC.add(shadowG);
            
            // Building sprite — scaled up
            const bldg = scene.add.graphics();
            CRTTerminal._mapDrawNodeIcon(scene, bldg, n, alpha);
            bldg.setScale(isBoss ? 2.0 : 1.5);
            nodeC.add(bldg);
            
            // Label below sprite
            let label = n.type === 'safehouse' ? 'BASE' : n.type === 'haven' ? 'HAVEN' : isBoss ? 'BOSS' : '';
            if (n.type === 'exploration' && n.name) label = n.name.split(' ')[0].substring(0, 8);
            const labelCol = isBoss ? '#cc4444' : '#2a5a2a';
            const labelSize = isBoss ? uiPx(9) : uiPx(6);
            if (label) {
                nodeC.add(scene.add.text(0, fh/2 + 4, label, {
                    fontFamily: 'monospace', fontSize: labelSize, fill: labelCol,
                    fontStyle: isBoss ? 'bold' : ''
                }).setOrigin(0.5, 0).setAlpha(isBoss ? 0.9 : alpha * 0.8));
            }
            
            // Per-boss-type animations
            if (isBoss) {
                const bType = n.bossEntityType || 'warden';
                if (bType === 'warden') {
                    // Slow, heavy pulse — shield bash rhythm
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: nodeC, alpha: { from: 0.7, to: 1.0 },
                        duration: 1800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: bldg, scaleX: { from: 1.0, to: 1.05 }, scaleY: { from: 1.0, to: 1.05 },
                        duration: 1800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                } else if (bType === 'swarmQueen') {
                    // Fast flickering pulse — buzzing insects
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: nodeC, alpha: { from: 0.65, to: 1.0 },
                        duration: 400, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                    // Subtle jitter
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: bldg, x: { from: -0.5, to: 0.5 }, y: { from: -0.3, to: 0.3 },
                        duration: 150, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                } else if (bType === 'phantom') {
                    // Slow fade in/out — ethereal phasing
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: nodeC, alpha: { from: 0.35, to: 0.95 },
                        duration: 2500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                    // Gentle float
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: bldg, y: { from: -2, to: 2 },
                        duration: 3000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                } else if (bType === 'ironclad') {
                    // Mechanical stomp — sharp pulse
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: nodeC, alpha: { from: 0.8, to: 1.0 },
                        duration: 600, yoyo: true, repeat: -1, ease: 'Stepped', hold: 400
                    }));
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: bldg, scaleX: { from: 1.0, to: 1.03 },
                        duration: 600, yoyo: true, repeat: -1, ease: 'Stepped', hold: 400
                    }));
                } else {
                    // cubeAnomaly — reality distortion rotation + scale
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: nodeC, alpha: { from: 0.5, to: 1.0 },
                        duration: 1500, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: bldg, angle: { from: -3, to: 3 },
                        duration: 2000, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                    scene._mapPulseTweens.push(scene.tweens.add({
                        targets: bldg, scaleX: { from: 0.95, to: 1.08 }, scaleY: { from: 0.95, to: 1.08 },
                        duration: 1200, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                    }));
                }
            }
            
            // Hit zone
            const hitZone = scene.add.rectangle(0, 0, fw + 10, fh + 10, 0x000000, 0.001);
            hitZone.setInteractive({ useHandCursor: true });
            hitZone.on('pointerdown', () => {
                if (!scene._mapIsDragging) CRTTerminal._mapTapNode(scene, n.id);
            });
            nodeC.add(hitZone);
            
            // === THREAT INDICATOR RINGS (#3) ===
            if (n.difficulty === 'hard' || n.difficulty === 'deadly') {
                const threatCol = n.difficulty === 'deadly' ? 0xaa3333 : 0xaa8833;
                const threatSpeed = n.difficulty === 'deadly' ? 800 : 1400;
                const ring = scene.add.circle(0, 0, Math.max(fw, fh) * 0.6 + 4, threatCol, 0).setStrokeStyle(1.5, threatCol, 0.5);
                nodeC.addAt(ring, 0); // behind building
                if (!scene._mapThreatTweens) scene._mapThreatTweens = [];
                scene._mapThreatTweens.push(scene.tweens.add({
                    targets: ring, alpha: { from: 0.0, to: 0.6 },
                    scaleX: { from: 0.8, to: 1.3 }, scaleY: { from: 0.8, to: 1.3 },
                    duration: threatSpeed, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                }));
            }
            
            scene._mapNodeObjects[n.id] = { pos, node: n, container: nodeC, bldg, highlightG: null, frameW: fw, frameH: fh };
        });
        
        // === CRT SCANLINES over map area ===
        const scanG = scene.add.graphics();
        scanG.lineStyle(1, 0x000000, 0.07);
        for (let sy = mapTop; sy < mapTop + mapH; sy += 3) {
            scanG.lineBetween(-mapW/2, sy, mapW/2, sy);
        }
        CRTTerminal._tAdd(scene, scanG);
        
        // === HUD BAR ===
        const hudY = mapTop + mapH + 2;
        const hudG = scene.add.graphics();
        CRTTerminal._tAdd(scene, hudG);
        hudG.fillStyle(crt.screenBg1, 0.9);
        hudG.fillRect(-mapW/2, hudY, mapW, hudH);
        hudG.lineStyle(0.5, crt.reflection, 0.5);
        hudG.strokeRect(-mapW/2, hudY, mapW, hudH);
        
        // Fuel canister
        scene._mapHudFuelG = scene.add.graphics();
        CRTTerminal._tAdd(scene, scene._mapHudFuelG);
        scene._mapHudFuelY = hudY;
        scene._mapHudFuelX = -mapW/2 + 6;
        scene._mapFuelText = CRTTerminal._tAdd(scene, scene.add.text(-mapW/2 + 26, hudY + hudH/2, '0/100', {
            fontFamily: 'monospace', fontSize: uiPx(10), fill: '#3a8a3a'
        }).setOrigin(0, 0.5));
        
        // Time-of-day icon (next to fuel)
        const todHudG = scene.add.graphics();
        CRTTerminal._tAdd(scene, todHudG);
        const thx = -mapW/2 + 66, thy = hudY + 4;
        if (currentTod === 'dawn' || currentTod === 'midday') {
            const sc = currentTod === 'dawn' ? 0xaa8833 : 0x6a8a3a;
            todHudG.fillStyle(sc, 0.8);
            todHudG.fillCircle(thx + 6, thy + 8, 5);
            todHudG.lineStyle(1, sc, 0.5);
            for (let a = 0; a < 8; a++) {
                const angle = (a / 8) * Math.PI * 2;
                todHudG.lineBetween(thx + 6 + Math.cos(angle) * 6, thy + 8 + Math.sin(angle) * 6,
                                    thx + 6 + Math.cos(angle) * 9, thy + 8 + Math.sin(angle) * 9);
            }
        } else if (currentTod === 'dusk') {
            todHudG.fillStyle(0x8a4a1a, 0.8);
            todHudG.fillCircle(thx + 6, thy + 14, 6);
            todHudG.fillStyle(0x0a1a0a, 0.95);
            todHudG.fillRect(thx - 2, thy + 14, 18, 8);
            todHudG.lineStyle(0.5, 0x6a3a1a, 0.5);
            todHudG.lineBetween(thx - 1, thy + 14, thx + 14, thy + 14);
        } else {
            todHudG.fillStyle(0x4455aa, 0.7);
            todHudG.fillCircle(thx + 6, thy + 8, 5);
            todHudG.fillStyle(0x0a1a0a, 0.95);
            todHudG.fillCircle(thx + 9, thy + 6, 4);
            todHudG.fillStyle(0x6677bb, 0.5);
            todHudG.fillRect(thx - 2, thy + 2, 1, 1);
            todHudG.fillRect(thx + 14, thy + 5, 1, 1);
            todHudG.fillRect(thx + 12, thy + 14, 1, 1);
        }
        CRTTerminal._tAdd(scene, scene.add.text(thx + 15, thy + 8, todLabels[currentTod] || 'DAY', {
            fontFamily: 'monospace', fontSize: uiPx(8), fill: todColors[currentTod] || '#4a8a4a'
        }).setOrigin(0, 0.5));
        
        // Threat skull (centered)
        scene._mapHudDangerG = scene.add.graphics();
        CRTTerminal._tAdd(scene, scene._mapHudDangerG);
        scene._mapHudDangerX = -6;
        scene._mapHudDangerY = hudY;
        
        // Status text
        scene._mapStatusText = CRTTerminal._tAdd(scene, scene.add.text(mapW/2 - 6, hudY + hudH/2, 'SELECT ROUTE', {
            fontFamily: 'monospace', fontSize: uiPx(10), fill: '#2a5a2a'
        }).setOrigin(1, 0.5));
        
        scene._mapLockBtn = null;
        scene._mapHudH = hudH;
        
        CRTTerminal._mapRedrawEdges(scene);
        CRTTerminal._mapUpdateFuel(scene);
        CRTTerminal._mapCenterOnNode(scene, reachData.meta.anchorId);
    },

    _mapCleanupInput(scene) {
        if (scene._mapPtrDown) {
            scene.input.off('pointerdown', scene._mapPtrDown);
            scene.input.off('pointermove', scene._mapPtrMove);
            scene.input.off('pointerup', scene._mapPtrUp);
            scene._mapPtrDown = null; scene._mapPtrMove = null; scene._mapPtrUp = null;
        }
    },

    _mapDrawFuelIcon(scene, ratio, over) {
        const g = scene._mapHudFuelG;
        if (!g) return;
        g.clear();
        const x = scene._mapHudFuelX, y = scene._mapHudFuelY + 4;
        g.lineStyle(1, over ? 0xaa3333 : 0x3a8a3a, 0.9);
        g.strokeRect(x, y + 3, 14, 18);
        g.fillStyle(over ? 0xaa3333 : 0x3a8a3a, 0.8);
        g.fillRect(x + 3, y, 8, 4);
        g.lineStyle(1, over ? 0xaa3333 : 0x3a8a3a, 0.6);
        g.lineBetween(x + 11, y + 2, x + 16, y + 2);
        g.lineBetween(x + 16, y + 2, x + 16, y + 6);
        const fillH = Math.max(1, Math.min(16, 16 * ratio));
        const fillColor = ratio > 0.6 ? 0x3a8a3a : ratio > 0.3 ? 0x8a8a2a : 0xaa3333;
        g.fillStyle(fillColor, 0.6);
        g.fillRect(x + 1, y + 4 + (16 - fillH), 12, fillH);
    },

    _mapDrawDangerIcon(scene, dangerLevel) {
        const g = scene._mapHudDangerG;
        if (!g) return;
        g.clear();
        const x = scene._mapHudDangerX, y = scene._mapHudDangerY + 4;
        const sc = dangerLevel >= 2 ? 0xaa3333 : dangerLevel >= 1 ? 0x8a8a2a : 0x2a5a2a;
        g.fillStyle(sc, 0.7);
        g.fillRoundedRect(x, y + 1, 12, 10, 3);
        g.fillStyle(0x040a04, 0.9);
        g.fillRect(x + 2, y + 4, 3, 3); g.fillRect(x + 7, y + 4, 3, 3);
        g.fillStyle(sc, 0.5);
        g.fillRect(x + 2, y + 11, 8, 4);
        g.fillStyle(0x040a04, 0.9);
        g.fillRect(x + 3, y + 12, 2, 2); g.fillRect(x + 7, y + 12, 2, 2);
        const barX = x + 16, barW = 30;
        g.lineStyle(0.5, 0x2a4a2a, 0.5);
        g.strokeRect(barX, y + 5, barW, 8);
        const fillW = Math.min(barW - 2, (barW - 2) * (dangerLevel / 3));
        const bc = dangerLevel >= 2.5 ? 0xcc3333 : dangerLevel >= 1.5 ? 0xaa8833 : 0x3a6a3a;
        g.fillStyle(bc, 0.6);
        g.fillRect(barX + 1, y + 6, fillW, 6);
    },

    _mapDrawNodeIcon(scene, g, node, alpha) {
        // CRT phosphor palette — 4 shading levels + accents (biome-aware)
        const crt = scene._crtPalette || {};
        const pGreen = { hi: 0x55cc55, mid: 0x3a8a3a, dim: 0x2a6a2a, lo: 0x1a4a1a,
            bg: 0x0a2a0a, win: 0x2a5a6a, door: 0x0a1a0a, roof: 0x2a5a2a,
            acc: 0x44aa44, warn: 0xaa8844, red: 0xaa4444 };
        const pAmber = { hi: 0xccaa55, mid: 0x8a7a3a, dim: 0x6a5a2a, lo: 0x4a3a1a,
            bg: 0x2a1a0a, win: 0x6a5a2a, door: 0x1a0e0a, roof: 0x5a4a2a,
            acc: 0xaa9944, warn: 0xaa8844, red: 0xaa4444 };
        const pPurple = { hi: 0xaa66cc, mid: 0x7a4a8a, dim: 0x5a3a6a, lo: 0x3a2a4a,
            bg: 0x1a0a2a, win: 0x4a4a8a, door: 0x0a0a1a, roof: 0x4a2a5a,
            acc: 0x8866aa, warn: 0xaa8844, red: 0xaa4444 };
        const biomeId = (scene.saveData && scene.saveData.biome) || 'grassy';
        const P = biomeId === 'barren' ? pAmber : biomeId === 'apocalyptic' ? pPurple : pGreen;
        
        if (node.type === 'safehouse' || node.type === 'haven') {
            // Fortified base — iso cube with antenna, sandbags
            g.fillStyle(P.dim, alpha); g.fillRect(0, -8, 8, 14); // right/south wall
            g.fillStyle(P.mid, alpha); g.fillRect(-8, -8, 8, 14); // front face
            g.fillStyle(P.roof, alpha); g.fillRect(-8, -10, 16, 2); // roof
            g.fillStyle(P.door, alpha); g.fillRect(-5, -1, 4, 7); // door
            g.fillStyle(P.acc, alpha * 0.4); g.fillRect(-4, 1, 2, 1); // handle
            g.fillStyle(P.win, alpha * 0.6); g.fillRect(-7, -6, 3, 3); // window L
            g.fillStyle(P.mid, alpha * 0.5); g.fillRect(-6, -6, 1, 3); // bar
            g.fillStyle(P.win, alpha * 0.6); g.fillRect(-3, -6, 3, 3); // window R
            g.fillStyle(P.dim, alpha * 0.7); g.fillRect(4, -16, 1, 6); // antenna
            g.fillStyle(P.red, alpha * 0.6); g.fillRect(3, -17, 3, 1); // beacon
            g.fillStyle(P.lo, alpha * 0.6); g.fillRect(-9, 4, 4, 2); g.fillRect(-6, 3, 4, 2);
            return;
        }
        if (node.type === 'boss') { CRTTerminal._mapDrawBossSprite(scene, g, node, alpha); return; }
        const lt = node.locationType || 'house';
        const tpl = CONFIG.locations[lt] ? CONFIG.locations[lt].buildingTemplate : 'house';
        switch(tpl) {
            case 'gas_station_main':
                g.fillStyle(P.dim, alpha); g.fillRect(2, -4, 6, 8);
                g.fillStyle(P.mid, alpha); g.fillRect(-4, -4, 6, 8);
                g.fillStyle(P.roof, alpha); g.fillRect(-4, -6, 12, 2);
                g.fillStyle(P.win, alpha * 0.5); g.fillRect(-3, -3, 4, 3);
                g.fillStyle(P.lo, alpha * 0.7); g.fillRect(-10, -8, 12, 1);
                g.fillStyle(P.dim, alpha * 0.5); g.fillRect(-10, -8, 1, 8); g.fillRect(0, -8, 1, 8);
                g.fillStyle(P.red, alpha * 0.7); g.fillRect(-8, -3, 2, 4); g.fillRect(-5, -3, 2, 4);
                g.fillStyle(P.bg, alpha * 0.6); g.fillRect(-9, -4, 1, 2); g.fillRect(-4, -4, 1, 2);
                g.fillStyle(P.dim, alpha * 0.6); g.fillRect(-1, -12, 2, 5);
                g.fillStyle(P.warn, alpha * 0.5); g.fillRect(-2, -12, 4, 2);
                break;
            case 'pharmacy': case 'store':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -6, 8, 10);
                g.fillStyle(P.mid, alpha); g.fillRect(-8, -6, 8, 10);
                g.fillStyle(P.roof, alpha); g.fillRect(-8, -8, 16, 2);
                g.fillStyle(P.win, alpha * 0.5); g.fillRect(-7, -4, 5, 5);
                g.fillStyle(P.win, alpha * 0.3); g.fillRect(-6, -3, 3, 3);
                g.fillStyle(P.door, alpha * 0.7); g.fillRect(-2, -1, 3, 5);
                g.fillStyle(P.acc, alpha * 0.6); g.fillRect(3, -5, 1, 4); g.fillRect(2, -4, 3, 1);
                g.fillStyle(P.lo, alpha * 0.5); g.fillRect(-8, -8, 12, 1);
                break;
            case 'house':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -4, 6, 8);
                g.fillStyle(P.mid, alpha); g.fillRect(-6, -4, 6, 8);
                g.fillStyle(P.roof, alpha); g.fillRect(-7, -6, 13, 2);
                g.fillStyle(P.lo, alpha * 0.8); g.fillRect(-4, -9, 8, 3);
                g.fillStyle(P.dim, alpha * 0.7); g.fillRect(3, -12, 2, 4);
                g.fillStyle(P.win, alpha * 0.5); g.fillRect(-5, -3, 2, 2); g.fillRect(-2, -3, 2, 2);
                g.fillStyle(P.door, alpha * 0.7); g.fillRect(-4, 0, 3, 4);
                g.fillStyle(P.dim, alpha * 0.3); g.fillRect(-5, 3, 5, 1);
                break;
            case 'apartment': case 'office_building':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -12, 7, 16);
                g.fillStyle(P.mid, alpha); g.fillRect(-7, -12, 7, 16);
                g.fillStyle(P.roof, alpha); g.fillRect(-7, -14, 14, 2);
                for (let fy = 0; fy < 3; fy++) {
                    const wy = -10 + fy * 4;
                    g.fillStyle(P.win, alpha * 0.5);
                    g.fillRect(-5, wy, 2, 2); g.fillRect(-2, wy, 2, 2);
                }
                g.fillStyle(P.door, alpha * 0.6); g.fillRect(-4, 0, 3, 4);
                g.fillStyle(P.lo, alpha * 0.5); g.fillRect(6, -8, 2, 1); g.fillRect(6, -4, 2, 1);
                g.fillStyle(P.lo, alpha * 0.4); g.fillRect(7, -9, 1, 6);
                g.fillStyle(P.dim, alpha * 0.4); g.fillRect(2, -17, 1, 3);
                break;
            case 'warehouse': case 'factory':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -4, 10, 8);
                g.fillStyle(P.mid, alpha); g.fillRect(-10, -4, 10, 8);
                g.fillStyle(P.roof, alpha); g.fillRect(-10, -6, 20, 2);
                g.fillStyle(P.lo, alpha * 0.7); g.fillRect(-8, -9, 6, 3); g.fillRect(0, -9, 6, 3);
                g.fillStyle(P.bg, alpha * 0.7); g.fillRect(-7, -2, 6, 6);
                g.fillStyle(P.dim, alpha * 0.4); g.fillRect(-7, -1, 5, 1); g.fillRect(-7, 1, 5, 1);
                g.fillStyle(P.dim, alpha * 0.6); g.fillRect(7, -14, 2, 6);
                g.fillStyle(P.lo, alpha * 0.4); g.fillRect(-8, 3, 8, 1);
                break;
            case 'garage':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -4, 8, 8);
                g.fillStyle(P.mid, alpha); g.fillRect(-8, -4, 8, 8);
                g.fillStyle(P.roof, alpha); g.fillRect(-8, -6, 16, 2);
                g.fillStyle(P.bg, alpha * 0.7); g.fillRect(-7, -2, 4, 6); g.fillRect(-2, -2, 4, 6);
                g.fillStyle(P.dim, alpha * 0.3);
                g.fillRect(-7, -1, 3, 1); g.fillRect(-7, 1, 3, 1);
                g.fillRect(-2, -1, 3, 1); g.fillRect(-2, 1, 3, 1);
                g.fillStyle(P.bg, alpha * 0.5); g.fillRect(-11, 0, 2, 2); g.fillRect(-11, -2, 2, 2); g.fillRect(-11, -4, 2, 2);
                g.fillStyle(P.win, alpha * 0.4); g.fillRect(-6, -8, 8, 2);
                break;
            case 'motel':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -3, 10, 7);
                g.fillStyle(P.mid, alpha); g.fillRect(-10, -3, 10, 7);
                g.fillStyle(P.roof, alpha); g.fillRect(-10, -5, 20, 2);
                for (let d = 0; d < 4; d++) {
                    g.fillStyle(P.door, alpha * 0.6); g.fillRect(-8 + d * 4, -1, 2, 5);
                    g.fillStyle(P.win, alpha * 0.3); g.fillRect(-8 + d * 4, -3, 2, 1);
                }
                g.fillStyle(P.lo, alpha * 0.5); g.fillRect(-10, -5, 16, 1);
                g.fillStyle(P.dim, alpha * 0.5); g.fillRect(9, -10, 1, 7);
                g.fillStyle(P.red, alpha * 0.5); g.fillRect(8, -11, 3, 2);
                g.fillStyle(P.warn, alpha * 0.3); g.fillRect(8, -12, 3, 1);
                break;
            case 'restaurant':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -5, 8, 9);
                g.fillStyle(P.mid, alpha); g.fillRect(-8, -5, 8, 9);
                g.fillStyle(P.roof, alpha); g.fillRect(-8, -7, 16, 2);
                g.fillStyle(P.win, alpha * 0.5); g.fillRect(-7, -4, 5, 4);
                g.fillStyle(P.win, alpha * 0.3); g.fillRect(-6, -3, 3, 2);
                g.fillStyle(P.lo, alpha * 0.4); g.fillRect(-6, -2, 4, 1);
                g.fillStyle(P.door, alpha * 0.6); g.fillRect(-2, -1, 3, 5);
                g.fillStyle(P.lo, alpha * 0.5); g.fillRect(5, -10, 2, 3);
                g.fillStyle(P.warn, alpha * 0.5); g.fillRect(-5, -9, 8, 2);
                break;
            case 'police_station':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -7, 9, 11);
                g.fillStyle(P.mid, alpha); g.fillRect(-9, -7, 9, 11);
                g.fillStyle(P.roof, alpha); g.fillRect(-9, -9, 18, 2);
                g.fillStyle(P.win, alpha * 0.4); g.fillRect(-7, -5, 3, 3); g.fillRect(-3, -5, 3, 3);
                g.fillStyle(P.dim, alpha * 0.4); g.fillRect(-6, -5, 1, 3); g.fillRect(-2, -5, 1, 3);
                g.fillStyle(P.bg, alpha * 0.6); g.fillRect(-5, -1, 5, 5);
                g.fillStyle(P.dim, alpha * 0.4); g.fillRect(-3, -1, 1, 5);
                g.fillStyle(P.win, alpha * 0.6); g.fillRect(-3, -8, 2, 2);
                g.fillStyle(P.win, alpha * 0.3); g.fillRect(-3, -8, 1, 1);
                break;
            case 'church':
                g.fillStyle(P.dim, alpha); g.fillRect(0, -7, 8, 11);
                g.fillStyle(P.mid, alpha); g.fillRect(-8, -7, 8, 11);
                g.fillStyle(P.lo, alpha * 0.8); g.fillRect(-8, -10, 16, 3);
                g.fillStyle(P.dim, alpha * 0.8); g.fillRect(-2, -16, 4, 6);
                g.fillStyle(P.acc, alpha * 0.7); g.fillRect(-1, -20, 2, 5); g.fillRect(-2, -18, 4, 1);
                g.fillStyle(P.door, alpha * 0.6); g.fillRect(-4, -2, 4, 6);
                g.fillStyle(P.door, alpha * 0.7); g.fillCircle(-2, -2, 2);
                g.fillStyle(0x3a2a5a, alpha * 0.5); g.fillRect(-6, -6, 2, 3);
                g.fillStyle(0x3a2a5a, alpha * 0.3); g.fillCircle(-5, -6, 1);
                break;
            case 'bunker':
                g.fillStyle(P.dim, alpha * 0.7); g.fillRect(-8, 0, 16, 4);
                g.fillStyle(P.mid, alpha * 0.6); g.fillRect(-7, -3, 14, 5);
                g.fillStyle(P.lo, alpha * 0.5); g.fillRect(-6, -2, 12, 3);
                g.fillStyle(P.bg, alpha * 0.6); g.fillRect(-3, -2, 6, 2);
                g.fillStyle(P.dim, alpha * 0.3); g.fillRect(-2, -1, 4, 1);
                g.fillStyle(P.acc, alpha * 0.4); g.fillCircle(0, -1, 1);
                g.fillStyle(P.dim, alpha * 0.5); g.fillRect(5, -8, 1, 5);
                g.fillStyle(P.dim, alpha * 0.3); g.fillRect(4, -7, 3, 1);
                g.fillStyle(P.dim, alpha * 0.4); g.fillRect(-5, -6, 1, 3);
                g.fillStyle(P.win, alpha * 0.3); g.fillRect(-5, -6, 1, 1);
                break;
            default:
                g.fillStyle(P.dim, alpha); g.fillRect(0, -5, 6, 9);
                g.fillStyle(P.mid, alpha); g.fillRect(-6, -5, 6, 9);
                g.fillStyle(P.roof, alpha); g.fillRect(-6, -7, 12, 2);
                g.fillStyle(P.lo, alpha * 0.7); g.fillRect(-4, -10, 8, 3);
                g.fillStyle(P.win, alpha * 0.4); g.fillRect(-5, -4, 2, 2); g.fillRect(-2, -4, 2, 2);
                g.fillStyle(P.door, alpha * 0.6); g.fillRect(-4, 0, 3, 4);
                break;
        }
    },

    _mapDrawBossSprite(scene, g, node, alpha) {
        const bet = node.bossEntityType || 'warden';
        // Exact color palettes from MapScene
        const bc = {
            warden:     { main: 0x884422, light: 0xaa6644, dark: 0x663311, eye: 0xff2222, armor: 0x555544 },
            swarmQueen: { main: 0x448844, light: 0x66aa66, dark: 0x224422, eye: 0xaaff44, armor: 0x88aa44 },
            phantom:    { main: 0x664488, light: 0x8866aa, dark: 0x442266, eye: 0xcc88ff, armor: 0x886aaa },
            ironclad:   { main: 0x666677, light: 0x888899, dark: 0x444455, eye: 0xff4422, armor: 0x555566 },
            cubeAnomaly:{ main: 0x8844aa, light: 0xaa66cc, dark: 0x662288, eye: 0xff00ff, armor: 0x6622aa }
        }[bet] || { main: 0x884422, light: 0xaa6644, dark: 0x663311, eye: 0xff2222, armor: 0x555544 };
        
        // Arena glow
        g.fillStyle(bc.eye, alpha * 0.06); g.fillCircle(0, 2, 14);
        
        if (bet === 'warden') {
            // Hulking armored brute — ¾ front facing, from MapScene
            g.fillStyle(bc.dark, alpha * 0.9);
            g.fillRect(-4, 2, 4, 6); g.fillRect(1, 2, 4, 6); // legs
            g.fillStyle(bc.armor, alpha * 0.7);
            g.fillRect(-4, 0, 5, 2); g.fillRect(1, 0, 5, 2); // knee guards
            g.fillStyle(bc.main, alpha); g.fillRect(-7, -7, 14, 9); // torso
            g.fillStyle(bc.armor, alpha * 0.8); g.fillRect(-6, -9, 12, 3); // chest plate
            g.fillStyle(bc.dark, alpha * 0.5); g.fillRect(-5, -7, 10, 1); // belt
            g.fillStyle(bc.dark, alpha * 0.8);
            g.fillRect(-9, -6, 3, 8); g.fillRect(7, -6, 3, 8); // arms
            g.fillStyle(bc.armor, alpha * 0.7);
            g.fillRect(-10, -9, 4, 3); g.fillRect(7, -9, 4, 3); // shoulders
            g.fillStyle(bc.light, alpha); g.fillRect(-4, -13, 8, 5); // head
            g.fillStyle(bc.eye, alpha * 0.9);
            g.fillRect(-3, -12, 2, 2); g.fillRect(2, -12, 2, 2); // eyes
            g.fillStyle(0xaa0000, alpha * 0.7); g.fillRect(-2, -9, 4, 1); // mouth
            g.fillStyle(0x888877, alpha * 0.5);
            g.fillRect(-6, -4, 1, 3); g.fillRect(-5, -3, 1, 2); // chains
        } else if (bet === 'swarmQueen') {
            // Insectoid queen — wide, from MapScene
            g.fillStyle(bc.dark, alpha * 0.7);
            for (let i = 0; i < 3; i++) {
                g.fillRect(-8 + i * 3, 3, 1, 4); g.fillRect(3 + i * 3, 3, 1, 4); // 6 legs
            }
            g.fillStyle(bc.dark, alpha * 0.8); g.fillCircle(0, 2, 7); // abdomen
            g.fillStyle(bc.main, alpha * 0.7); g.fillCircle(0, 1, 5);
            g.fillStyle(bc.armor, alpha * 0.6);
            g.fillCircle(-3, 3, 2); g.fillCircle(3, 3, 2); // egg sacs
            g.fillStyle(bc.dark, alpha * 0.8); g.fillCircle(0, -5, 5); // thorax
            g.fillStyle(bc.main, alpha * 0.7); g.fillCircle(0, -6, 4);
            g.fillStyle(bc.dark, alpha * 0.9); g.fillCircle(0, -11, 3); // head
            g.fillStyle(bc.main, alpha * 0.8); g.fillCircle(0, -11, 2);
            g.fillStyle(bc.eye, alpha * 0.9);
            g.fillCircle(-2, -12, 1); g.fillCircle(2, -12, 1); // eyes
            g.fillStyle(0x886633, alpha * 0.7);
            g.fillRect(-4, -9, 2, 2); g.fillRect(3, -9, 2, 2); // mandibles
        } else if (bet === 'phantom') {
            // Ethereal wraith — translucent layers, from MapScene
            g.fillStyle(bc.dark, alpha * 0.3);
            g.fillRect(-7, -2, 14, 8); g.fillRect(-5, 4, 10, 3); // cloak trail
            g.fillStyle(bc.main, alpha * 0.4); g.fillCircle(0, -4, 8); // body
            g.fillStyle(bc.light, alpha * 0.25); g.fillCircle(0, -5, 6);
            g.fillStyle(0x110022, alpha * 0.5); g.fillCircle(0, -4, 4); // void
            g.fillStyle(bc.main, alpha * 0.6); g.fillCircle(0, -12, 4); // head
            g.fillStyle(bc.light, alpha * 0.4); g.fillCircle(0, -12, 3);
            g.fillStyle(bc.eye, alpha * 0.9);
            g.fillRect(-2, -13, 2, 2); g.fillRect(1, -13, 2, 2); // eyes
            g.fillStyle(bc.armor, alpha * 0.6);
            g.fillRect(-4, -16, 2, 4); g.fillRect(3, -16, 2, 4); // horns
            g.fillStyle(bc.dark, alpha * 0.15);
            g.fillRect(-8, -6, 2, 5); g.fillRect(7, -6, 2, 5); // wisps
        } else if (bet === 'ironclad') {
            // Mechanical tank-mech — boxy, from MapScene
            g.fillStyle(0x333333, alpha * 0.8);
            g.fillRect(-8, 3, 6, 3); g.fillRect(3, 3, 6, 3); // treads
            g.fillStyle(bc.armor, alpha * 0.8);
            g.fillRect(-6, -3, 4, 7); g.fillRect(3, -3, 4, 7); // piston legs
            g.fillStyle(0x777788, alpha * 0.6);
            g.fillRect(-6, -1, 3, 1); g.fillRect(3, -1, 3, 1); // pistons
            g.fillStyle(bc.main, alpha); g.fillRect(-8, -10, 16, 8); // core body
            g.fillStyle(bc.light, alpha * 0.8); g.fillRect(-7, -12, 14, 2); // upper plate
            g.fillStyle(0x999999, alpha * 0.5);
            for (let r = -5; r <= 5; r += 3) g.fillRect(r, -12, 1, 1); // rivets
            g.fillStyle(0x222233, alpha * 0.8); g.fillRect(-6, -15, 12, 3); // visor
            g.fillStyle(bc.eye, alpha * 0.9); g.fillRect(-5, -14, 10, 1); // eye slit
            g.fillStyle(0x555555, alpha * 0.7); g.fillRect(7, -14, 3, 3); // turret
            g.fillStyle(0x777777, alpha * 0.6); g.fillRect(9, -13, 4, 1); // barrel
            g.fillStyle(bc.armor, alpha * 0.7);
            g.fillRect(-10, -8, 3, 6); g.fillRect(8, -8, 3, 6); // arms
        } else {
            // Cube anomaly — geometric alien, from MapScene
            g.fillStyle(0x220044, alpha * 0.5); g.fillRect(-8, -12, 16, 16); // outer shell
            g.fillStyle(bc.main, alpha * 0.7); g.fillRect(-6, -10, 12, 12); // inner
            g.fillStyle(bc.armor, alpha * 0.25);
            for (let gx = -4; gx <= 4; gx += 3) {
                g.fillRect(gx, -10, 1, 12); g.fillRect(-6, -10 + (gx + 4), 12, 1); // grid
            }
            g.fillStyle(0xdd44ff, alpha * 0.8); g.fillRect(-2, -6, 4, 4); // core
            g.fillStyle(0xff88ff, alpha * 0.6); g.fillRect(-1, -5, 2, 2);
            g.fillStyle(0xaa44dd, alpha * 0.6);
            g.fillRect(-7, -11, 3, 3); g.fillRect(5, -11, 3, 3); // corner crystals
            g.fillRect(-7, 0, 3, 3); g.fillRect(5, 0, 3, 3);
            g.fillStyle(bc.eye, alpha * 0.9);
            g.fillRect(-3, -10, 2, 1); g.fillRect(2, -10, 2, 1); // eyes
        }
    },

    _mapDrawConvoyIcon(scene, g, cx, cy) {
        // Dashed circle border
        g.lineStyle(1, 0xaa6622, 0.5);
        const r = 10;
        const segs = 16;
        for (let i = 0; i < segs; i += 2) {
            const a1 = (i / segs) * Math.PI * 2;
            const a2 = ((i + 1) / segs) * Math.PI * 2;
            g.lineBetween(cx + Math.cos(a1) * r, cy + Math.sin(a1) * r,
                          cx + Math.cos(a2) * r, cy + Math.sin(a2) * r);
        }
        // Truck cab
        g.fillStyle(0x7a5522, 0.8);
        g.fillRect(cx - 8, cy - 4, 6, 7);
        // Windshield
        g.fillStyle(0x4a3311, 0.6);
        g.fillRect(cx - 7, cy - 3, 4, 3);
        // Cargo bed (flatbed with cover)
        g.fillStyle(0x5a4422, 0.9);
        g.fillRect(cx - 2, cy - 5, 10, 8);
        // Canvas cover arch
        g.lineStyle(1, 0x6a5533, 0.7);
        g.lineBetween(cx - 1, cy - 5, cx - 1, cy - 7);
        g.lineBetween(cx + 8, cy - 5, cx + 8, cy - 7);
        g.lineBetween(cx - 1, cy - 7, cx + 8, cy - 7);
        // Wheels
        g.fillStyle(0x2a1a0a, 0.9);
        g.fillCircle(cx - 5, cy + 4, 2.5);
        g.fillCircle(cx + 3, cy + 4, 2.5);
        g.fillCircle(cx + 7, cy + 4, 2.5);
        // Wheel hubs
        g.fillStyle(0x5a4a3a, 0.5);
        g.fillCircle(cx - 5, cy + 4, 1);
        g.fillCircle(cx + 3, cy + 4, 1);
        g.fillCircle(cx + 7, cy + 4, 1);
    },

    _mapApplyScroll(scene, dx) {
        if (!scene._mapContent) return;
        scene._mapScrollX += dx;
        // maxScroll: safehouse at left edge with padding
        // minScroll: boss fully visible (center + extra margin for sprite/label)
        const maxScroll = -(scene._mapMinNodeX || 0) + 30;
        const minScroll = -(scene._mapMaxNodeX || 600) + scene._mapViewW * 0.35;
        scene._mapScrollX = Math.max(minScroll, Math.min(maxScroll, scene._mapScrollX));
        scene._mapContent.x = scene._mapScrollX;
    },

    _mapCenterOnNode(scene, nodeId) {
        const obj = scene._mapNodeObjects[nodeId];
        if (!obj) return;
        scene._mapScrollX = -obj.pos.sx + scene._mapViewW * 0.5;
        const maxScroll = -(scene._mapMinNodeX || 0) + 30;
        const minScroll = -(scene._mapMaxNodeX || 600) + scene._mapViewW * 0.35;
        scene._mapScrollX = Math.max(minScroll, Math.min(maxScroll, scene._mapScrollX));
        scene._mapContent.x = scene._mapScrollX;
    },

    _mapTapNode(scene, nodeId) {
        if (!scene._mapReachData || !scene._mapRoute) return;
        const route = scene._mapRoute;
        const edges = scene._mapReachData.edges;
        const nodes = scene._mapReachData.nodes;
        
        if (scene._mapDetailCard) {
            scene._mapDetailCard.destroy(); scene._mapDetailCard = null;
            if (scene._mapPreviewNode === nodeId) {
                scene._mapPreviewNode = null; CRTTerminal._mapRedrawEdges(scene); return;
            }
        }
        
        // Undo: tap the last confirmed route node (not the anchor) to pop it off
        const existingIdx = route.indexOf(nodeId);
        if (existingIdx === route.length - 1 && route.length > 1 && !scene._mapPreviewNode) {
            scene._mapRoute = route.slice(0, -1);
            scene._mapPreviewNode = null;
            AudioManager.uiClick();
            CRTTerminal._mapRedrawEdges(scene); CRTTerminal._mapUpdateFuel(scene); CRTTerminal._mapRemoveLockBtn(scene);
            return;
        }
        
        // Truncate: tap a mid-route node to rewind to it
        if (existingIdx >= 0 && existingIdx < route.length - 1) {
            scene._mapRoute = route.slice(0, existingIdx + 1);
            scene._mapPreviewNode = null;
            AudioManager.uiClick();
            CRTTerminal._mapRedrawEdges(scene); CRTTerminal._mapUpdateFuel(scene); CRTTerminal._mapRemoveLockBtn(scene);
            return;
        }
        
        const currentEnd = route[route.length - 1];
        const validNext = RouteGenerator.getNextNodes(currentEnd, edges);
        if (!validNext.includes(nodeId)) return;
        
        const edge = edges.find(e => e.from === currentEnd && e.to === nodeId);
        const node = nodes[nodeId];
        if (!edge || !node) return;
        
        scene._mapPreviewNode = nodeId;
        CRTTerminal._mapRedrawEdges(scene);
        AudioManager.uiClick();
        CRTTerminal._mapShowDetailCard(scene, node, edge);
    },

    _mapShowDetailCard(scene, node, edge) {
        const cardW = 220;
        const isBoss = node.type === 'boss';
        const card = scene.add.container(0, scene._mapViewTop + scene._mapViewH / 2);
        CRTTerminal._tAdd(scene, card);
        scene._mapDetailCard = card;
        
        const crt = scene._crtPalette || {};
        const borderCol = isBoss ? 0xaa3333 : (crt.glow || 0x3a8a3a);
        const bgCol = isBoss ? 0x0e0404 : (crt.screenBg2 || 0x0a1a0a);
        const hiCol = isBoss ? '#cc4444' : (crt.textHi || '#44cc44');
        const midCol = isBoss ? '#aa4444' : (crt.textMid || '#4a9a4a');
        const dimCol = isBoss ? '#663333' : (crt.textDim || '#3a6a3a');
        const lineCol = crt.lineDim || 0x1a3a1a;
        
        // Content elements collected first — bg drawn after to fit dynamically
        const _contentItems = [];
        const _c = (obj) => { _contentItems.push(obj); return obj; };
        
        // Build content from y=10 — will center-shift after measuring total height
        let y = 10;
        const lx = -cardW/2 + 10;
        const rx = cardW/2 - 10;
        
        // ── SIGNAL INTERCEPT header ──
        const headerText = scene.add.text(0, y, isBoss ? '── THREAT DETECTED ──' : '── SIGNAL INTERCEPT ──', {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: dimCol
        }).setOrigin(0.5);
        _c(headerText);
        y += 16;
        
        // ── Location name ──
        let displayName = node.name || 'Unknown';
        if (displayName.length > 22) displayName = displayName.substring(0, 20) + '..';
        _c(scene.add.text(0, y, displayName.toUpperCase(), {
            fontFamily: 'monospace', fontSize: uiPx(12), fill: hiCol, fontStyle: 'bold'
        }).setOrigin(0.5));
        y += 18;
        
        // Divider
        const dg = scene.add.graphics();
        dg.lineStyle(0.5, lineCol, 0.6);
        dg.lineBetween(lx, y, rx, y);
        _c(dg);
        y += 6;
        
        if (isBoss) {
            const bTypeNames = { warden: 'ARMORED WARDEN', swarmQueen: 'SWARM QUEEN',
                phantom: 'CUBE PHANTOM', ironclad: 'IRON REVENANT', cubeAnomaly: 'CUBE ANOMALY' };
            _c(scene.add.text(lx, y, `TYPE: ${bTypeNames[node.bossEntityType] || 'UNKNOWN'}`, {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: midCol
            }));
            y += 14;
            _c(scene.add.text(lx, y, 'CLASS: REACH FINAL', {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: dimCol
            }));
            y += 14;
        } else {
            // STRUCT field
            const locDef = CONFIG.locations[node.locationType];
            const typeName = locDef ? node.locationType.replace(/_/g, ' ').toUpperCase() : 'EXPLORE';
            _c(scene.add.text(lx, y, `STRUCT: ${typeName}`, {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: midCol
            }));
            y += 13;
        }
        
        // WINDOW (time of day)
        const todNames = { dawn: '0600 — DAWN', midday: '1200 — MIDDAY', dusk: '1800 — DUSK', night: '0000 — NIGHT' };
        const todCols = { dawn: '#aa8844', midday: midCol, dusk: '#8a4a2a', night: '#4444aa' };
        _c(scene.add.text(lx, y, `WINDOW: ${todNames[node.timeOfDay] || 'UNKNOWN'}`, {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: todCols[node.timeOfDay] || midCol
        }));
        y += 13;
        
        // THREAT bar — 5-segment bar from difficulty
        const threatLevels = { normal: 1, hard: 3, deadly: 5 };
        const threatNum = threatLevels[node.difficulty] || 1;
        const threatLabel = node.difficulty === 'deadly' ? 'CRITICAL' : node.difficulty === 'hard' ? 'ELEVATED' : 'LOW';
        const threatBarCol = node.difficulty === 'deadly' ? 0xaa3333 : node.difficulty === 'hard' ? 0xaa8833 : (crt.glow || 0x3a8a3a);
        const tg = scene.add.graphics();
        _c(scene.add.text(lx, y, 'THREAT:', { fontFamily: 'monospace', fontSize: uiPx(9), fill: dimCol }));
        for (let seg = 0; seg < 5; seg++) {
            const sx = lx + 52 + seg * 10;
            const filled = seg < threatNum;
            tg.fillStyle(filled ? threatBarCol : 0x111111, filled ? 0.8 : 0.3);
            tg.fillRect(sx, y + 1, 8, 8);
            if (filled) { tg.lineStyle(0.5, threatBarCol, 0.4); tg.strokeRect(sx, y + 1, 8, 8); }
        }
        _c(tg);
        _c(scene.add.text(lx + 106, y, threatLabel, {
            fontFamily: 'monospace', fontSize: uiPx(9),
            fill: node.difficulty === 'deadly' ? '#cc4444' : node.difficulty === 'hard' ? '#cc8844' : dimCol
        }));
        y += 14;
        
        // FUEL REQ with mini canister
        const fg = scene.add.graphics();
        const fx = lx, fy = y;
        fg.lineStyle(0.8, crt.glow || 0x3a8a3a, 0.7); fg.strokeRect(fx, fy, 7, 9);
        fg.fillStyle(crt.glow || 0x3a8a3a, 0.4); fg.fillRect(fx + 2, fy - 2, 3, 3);
        fg.fillStyle(crt.glow || 0x3a8a3a, 0.3); fg.fillRect(fx + 1, fy + 4, 5, 4);
        _c(fg);
        _c(scene.add.text(fx + 12, fy, `FUEL REQ: ${edge.fuel}`, {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: midCol
        }));
        y += 15;
        
        // Divider
        const dg2 = scene.add.graphics();
        dg2.lineStyle(0.5, lineCol, 0.4);
        dg2.lineBetween(lx, y, rx, y);
        _c(dg2);
        y += 6;
        
        // ── SCAN RESULTS section ──
        _c(scene.add.text(0, y, '── SCAN RESULTS ──', {
            fontFamily: 'monospace', fontSize: uiPx(8), fill: dimCol
        }).setOrigin(0.5));
        y += 12;
        
        const allEnc = edge.encounters || [];
        const hasDefense = allEnc.some(enc => enc.type === 'defense');
        const hostileEnc = allEnc.filter(e => e.type === 'defense' || e.type === 'defense');
        const friendlyEnc = allEnc.filter(e => e.type === 'rescue');
        const anomalyEnc = allEnc.filter(e => e.type === 'anomaly');
        
        if (hostileEnc.length > 0) {
            const maxChance = Math.max(...hostileEnc.map(e => e.chance));
            const pct = Math.round(maxChance * 100);
            const sigLabel = hasDefense ? 'CONVOY SIG' : 'THERMAL SIG';
            _c(scene.add.text(lx, y, `${sigLabel}: ${pct}% HOSTILE`, {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: hasDefense ? '#cc8844' : '#aa6644'
            }));
            y += 13;
        }
        if (friendlyEnc.length > 0) {
            _c(scene.add.text(lx, y, 'DISTRESS BEACON: ACTIVE', {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: '#44cc66'
            }));
            y += 13;
        }
        if (anomalyEnc.length > 0) {
            _c(scene.add.text(lx, y, 'ANOMALOUS READING: DETECTED', {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: '#44aaaa'
            }));
            y += 13;
        }
        if (allEnc.length === 0) {
            _c(scene.add.text(lx, y, 'NO SIGNAL DETECTED', {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: dimCol
            }));
            y += 13;
        }
        
        // Supply cache estimate based on location type
        if (!isBoss && node.locationType) {
            const richLocs = ['warehouse', 'gas_station', 'military_outpost', 'lab'];
            const hasRich = richLocs.includes(node.locationType);
            _c(scene.add.text(lx, y, `SUPPLY CACHE: ${hasRich ? 'PROBABLE' : 'POSSIBLE'}`, {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: hasRich ? midCol : dimCol
            }));
            y += 13;
        }
        
        if (node.hasStoryEvent) {
            _c(scene.add.text(lx, y, 'ENCRYPTED SIGNAL: STORY', {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: '#aa44aa'
            }));
            y += 13;
        }
        
        // ── Dynamic card sizing — measure content, then draw bg to fit ──
        const btnH = 24;
        const bottomPad = 12;
        const cardH = y + btnH + bottomPad;
        const halfH = cardH / 2;
        const shiftY = -halfH; // shift content so card is vertically centered
        
        // Draw background FIRST (will be behind content)
        const cbg = scene.add.graphics();
        cbg.fillStyle(bgCol, 0.95);
        cbg.fillRoundedRect(-cardW/2, -halfH, cardW, cardH, 2);
        cbg.lineStyle(1.5, borderCol, 0.7);
        cbg.strokeRoundedRect(-cardW/2, -halfH, cardW, cardH, 2);
        cbg.lineStyle(1, borderCol, 0.1);
        cbg.strokeRoundedRect(-cardW/2 + 2, -halfH + 2, cardW - 4, cardH - 4, 1);
        card.add(cbg);
        
        // Add all content items, shifted to center
        _contentItems.forEach(item => {
            item.y += shiftY;
            card.add(item);
        });
        
        // CONFIRM button pinned to bottom
        const confirmBtn = scene.add.text(0, halfH - bottomPad - btnH/2 + 2, '[ CONFIRM ]', {
            fontFamily: 'monospace', fontSize: uiPx(12), fill: hiCol,
            backgroundColor: isBoss ? '#1a0808' : '#0a1a0a', padding: { x: 12, y: 4 }
        }).setOrigin(0.5).setInteractive({ useHandCursor: true });
        confirmBtn.on('pointerover', () => confirmBtn.setColor('#66ff66'));
        confirmBtn.on('pointerout', () => confirmBtn.setColor(hiCol));
        confirmBtn.on('pointerdown', () => CRTTerminal._mapConfirmNode(scene));
        card.add(confirmBtn);
        
        // Typewriter on header after positioning
        CRTTypewriter.type(scene, headerText, { speed: 25 });
        
        try { AudioManager.crtBeep(); } catch(e) {}
    },

    _mapShowConvoyCard(scene, edge, defEnc) {
        if (scene._mapDetailCard) { scene._mapDetailCard.destroy(); scene._mapDetailCard = null; }
        
        const cardW = 200, cardH = 140;
        const card = scene.add.container(0, scene._mapViewTop + scene._mapViewH / 2);
        CRTTerminal._tAdd(scene, card);
        scene._mapDetailCard = card;
        
        const cbg = scene.add.graphics();
        cbg.fillStyle(0x0a1a0a, 0.95);
        cbg.fillRoundedRect(-cardW/2, -cardH/2, cardW, cardH, 4);
        cbg.lineStyle(1.5, 0xaa6622, 0.8);
        cbg.strokeRoundedRect(-cardW/2, -cardH/2, cardW, cardH, 4);
        cbg.lineStyle(3, 0x4a3311, 0.15);
        cbg.strokeRoundedRect(-cardW/2 + 2, -cardH/2 + 2, cardW - 4, cardH - 4, 3);
        card.add(cbg);
        
        // Convoy truck icon inside card
        const truckG = scene.add.graphics();
        CRTTerminal._mapDrawConvoyIcon(scene, truckG, -cardW/2 + 30, -cardH/2 + 28);
        card.add(truckG);
        
        card.add(scene.add.text(0, -cardH/2 + 14, 'DEFENSE CONVOY', {
            fontFamily: 'monospace', fontSize: uiPx(14), fill: '#cc8833', fontStyle: 'bold'
        }).setOrigin(0.5));
        card.add(scene.add.text(-cardW/2 + 52, -cardH/2 + 32, 'Armed military escort', {
            fontFamily: 'monospace', fontSize: uiPx(10), fill: '#886633'
        }));
        
        const dg = scene.add.graphics();
        dg.lineStyle(0.5, 0x6a4422, 0.5);
        dg.lineBetween(-cardW/2 + 10, -cardH/2 + 48, cardW/2 - 10, -cardH/2 + 48);
        card.add(dg);
        
        const pct = defEnc ? Math.round(defEnc.chance * 100) : 0;
        card.add(scene.add.text(-cardW/2 + 12, -cardH/2 + 56, `ENCOUNTER CHANCE: ${pct}%`, {
            fontFamily: 'monospace', fontSize: uiPx(11), fill: '#aa8844'
        }));
        card.add(scene.add.text(-cardW/2 + 12, -cardH/2 + 74, `ROUTE DANGER: ${edge.danger}/3`, {
            fontFamily: 'monospace', fontSize: uiPx(10), fill: edge.danger >= 2 ? '#cc4444' : '#6a8a3a'
        }));
        card.add(scene.add.text(-cardW/2 + 12, -cardH/2 + 90, `FUEL COST: ${edge.fuel}`, {
            fontFamily: 'monospace', fontSize: uiPx(10), fill: '#3a8a3a'
        }));
        card.add(scene.add.text(-cardW/2 + 12, -cardH/2 + 106, 'Heavily armed. Avoid or engage.', {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: '#665533'
        }));
        
        // Tap anywhere on card to dismiss
        cbg.setInteractive();
        cbg.on('pointerdown', () => {
            if (scene._mapDetailCard) { scene._mapDetailCard.destroy(); scene._mapDetailCard = null; }
        });
    },

    _mapConfirmNode(scene) {
        if (!scene._mapPreviewNode || !scene._mapReachData) return;
        const nodeId = scene._mapPreviewNode;
        scene._mapPreviewNode = null;
        AudioManager.uiClick();
        
        // Delay destruction — we're inside the card's child event handler
        scene.time.delayedCall(1, () => {
            if (scene._mapDetailCard) { scene._mapDetailCard.destroy(); scene._mapDetailCard = null; }
            scene._mapRoute.push(nodeId);
            // Don't auto-scroll — user is already looking at this node
            CRTTerminal._mapRedrawEdges(scene); CRTTerminal._mapUpdateFuel(scene);
            if (nodeId === scene._mapReachData.meta.bossId) CRTTerminal._mapShowLockBtn(scene);
            else CRTTerminal._mapRemoveLockBtn(scene);
        });
    },

    _mapRedrawEdges(scene) {
        const g = scene._mapEdgeG;
        const glow = scene._mapGlowG;
        if (!g) return;
        g.clear();
        if (glow) glow.clear();
        
        if (scene._mapPulseTweens) {
            scene._mapPulseTweens.forEach(t => t.remove());
            scene._mapPulseTweens = [];
        }
        
        const edges = scene._mapReachData.edges;
        const route = scene._mapRoute;
        const preview = scene._mapPreviewNode;
        const reachable = scene._mapReachableNodes || new Set();
        const crt = scene._crtPalette || { glow: 0x22aa22, glowMid: 0x33bb33, glowBright: 0x44cc44, lineDim: 0x1a3a1a };
        const dangerColors = [crt.lineDim, 0x3a6a2a, 0x6a6a2a, 0x8a3a2a];
        
        const edgeAttach = (fromObj, toObj) => {
            const from = fromObj.pos, to = toObj.pos;
            const halfW = fromObj.frameW / 2, halfH = fromObj.frameH / 2;
            const dx = to.sx - from.sx, dy = to.sy - from.sy;
            const len = Math.sqrt(dx * dx + dy * dy) || 1;
            const nx = dx / len, ny = dy / len;
            const sx = Math.abs(nx) > 0.01 ? halfW / Math.abs(nx) : 99999;
            const sy = Math.abs(ny) > 0.01 ? halfH / Math.abs(ny) : 99999;
            const s = Math.min(sx, sy);
            return { x: from.sx + nx * s, y: from.sy + ny * s };
        };
        
        // Only edges with both nodes present
        const drawableEdges = edges.filter(e =>
            scene._mapNodeObjects[e.from] && scene._mapNodeObjects[e.to]
        );
        
        // ONLY draw valid-next edges from current endpoint (no background lines)
        if (route.length > 0) {
            const lastNode = route[route.length - 1];
            drawableEdges.filter(e => e.from === lastNode).forEach(e => {
                const f = scene._mapNodeObjects[e.from], t = scene._mapNodeObjects[e.to];
                const fp = edgeAttach(f, t);
                const tp = edgeAttach(t, f);
                g.lineStyle(2, dangerColors[e.danger] || 0x2a5a2a, 0.4);
                g.lineBetween(fp.x, fp.y, tp.x, tp.y);
            });
        }
        
        // Selected route — CRT glow
        for (let i = 0; i < route.length - 1; i++) {
            const f = scene._mapNodeObjects[route[i]], t = scene._mapNodeObjects[route[i + 1]];
            if (!f || !t) continue;
            const fp = edgeAttach(f, t);
            const tp = edgeAttach(t, f);
            
            if (glow) {
                glow.lineStyle(10, crt.glow, 0.1);
                glow.lineBetween(fp.x, fp.y, tp.x, tp.y);
                glow.lineStyle(5, crt.glowMid, 0.18);
                glow.lineBetween(fp.x, fp.y, tp.x, tp.y);
            }
            g.lineStyle(2.5, crt.glowBright, 0.9);
            g.lineBetween(fp.x, fp.y, tp.x, tp.y);
        }
        
        // Preview dashed glow
        if (preview && route.length > 0) {
            const lastNode = route[route.length - 1];
            const f = scene._mapNodeObjects[lastNode], t = scene._mapNodeObjects[preview];
            if (f && t) {
                const fp = edgeAttach(f, t);
                const tp = edgeAttach(t, f);
                if (glow) {
                    glow.lineStyle(8, crt.glow, 0.06);
                    glow.lineBetween(fp.x, fp.y, tp.x, tp.y);
                    glow.lineStyle(4, crt.glowMid, 0.12);
                    glow.lineBetween(fp.x, fp.y, tp.x, tp.y);
                }
                const dx = tp.x - fp.x, dy = tp.y - fp.y;
                g.lineStyle(2, crt.glowBright, 0.5);
                for (let s = 0; s < 10; s += 2) {
                    const t1 = s / 10, t2 = (s + 1) / 10;
                    g.lineBetween(fp.x + dx * t1, fp.y + dy * t1, fp.x + dx * t2, fp.y + dy * t2);
                }
            }
        }
        
        // === FOG OF WAR — depth fade based on column distance from route head ===
        const routeEndCol = route.length > 0
            ? (scene._mapReachData.nodes[route[route.length - 1]] || {}).col || 0
            : 0;
        
        // Node visibility — highlight rings, fog of war
        Object.values(scene._mapNodeObjects).forEach(obj => {
            const nodeCol = obj.node.col || 0;
            const colDist = Math.abs(nodeCol - routeEndCol);
            // Fade: nearby = 0.55, far = 0.2
            const fogAlpha = Math.max(0.2, 0.6 - colDist * 0.08);
            obj.container.setAlpha(fogAlpha);
            if (obj.highlightG) { obj.highlightG.destroy(); obj.highlightG = null; }
        });
        route.forEach(nId => {
            const obj = scene._mapNodeObjects[nId];
            if (!obj) return;
            obj.container.setAlpha(1.0);
            const hg = scene.add.graphics();
            hg.fillStyle(crt.glow, 0.1);
            hg.fillCircle(0, 2, 18);
            hg.lineStyle(1, crt.glowBright, 0.45);
            hg.strokeCircle(0, 2, 17);
            obj.container.addAt(hg, 0);
            obj.highlightG = hg;
        });
        if (route.length > 0) {
            const lastNode = route[route.length - 1];
            
            RouteGenerator.getNextNodes(lastNode, edges).forEach(nId => {
                const obj = scene._mapNodeObjects[nId];
                if (!obj || route.includes(nId)) return;
                obj.container.setAlpha(0.85);
                const hg = scene.add.graphics();
                const hc = obj.node.type === 'boss' ? 0xaa3333 : crt.glowMid;
                hg.lineStyle(1.2, hc, 0.5);
                hg.strokeCircle(0, 0, 19);
                hg.fillStyle(hc, 0.05);
                hg.fillCircle(0, 0, 18);
                obj.container.addAt(hg, 0);
                obj.highlightG = hg;
                const tw = scene.tweens.add({
                    targets: obj.container, alpha: { from: 0.7, to: 1.0 },
                    duration: 800, yoyo: true, repeat: -1, ease: 'Sine.easeInOut'
                });
                scene._mapPulseTweens.push(tw);
            });
        }
        if (preview) {
            const obj = scene._mapNodeObjects[preview];
            if (obj) obj.container.setAlpha(1.0);
        }
        
        // Fuel labels + convoy icons + encounter previews + running fuel totals
        if (scene._mapFuelLabels) scene._mapFuelLabels.forEach(l => l.destroy());
        scene._mapFuelLabels = [];
        
        // Undo hint on last route node (if more than anchor)
        if (route.length > 1) {
            const lastNode = route[route.length - 1];
            const lastObj = scene._mapNodeObjects[lastNode];
            if (lastObj) {
                const undoHint = scene.add.text(lastObj.pos.sx, lastObj.pos.sy - lastObj.frameH/2 - 10, 'TAP TO UNDO', {
                    fontFamily: 'monospace', fontSize: uiPx(7), fill: '#446644'
                }).setOrigin(0.5).setAlpha(0.5);
                scene._mapContent.add(undoHint);
                scene._mapFuelLabels.push(undoHint);
            }
        }
        
        const showEdges = [];
        let cumulativeFuel = 0;
        for (let i = 0; i < route.length - 1; i++) {
            const e = drawableEdges.find(ed => ed.from === route[i] && ed.to === route[i + 1]);
            if (e) {
                cumulativeFuel += e.fuel;
                showEdges.push({ edge: e, selected: true, cumFuel: cumulativeFuel, routeIdx: i });
            }
        }
        if (route.length > 0) {
            const lastNode = route[route.length - 1];
            drawableEdges.filter(e => e.from === lastNode).forEach(e => {
                if (!showEdges.find(s => s.edge === e)) {
                    showEdges.push({ edge: e, selected: false, cumFuel: cumulativeFuel + e.fuel, routeIdx: -1 });
                }
            });
        }
        
        showEdges.forEach(({ edge: e, selected, cumFuel, routeIdx }) => {
            const f = scene._mapNodeObjects[e.from], t = scene._mapNodeObjects[e.to];
            if (!f || !t) return;
            const mx = (f.pos.sx + t.pos.sx) / 2, my = (f.pos.sy + t.pos.sy) / 2;
            
            // Fuel label
            const col = selected ? '#44cc44' : '#3a6a3a';
            const ft = scene.add.text(mx, my - 14, `${e.fuel}`, {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: col
            }).setOrigin(0.5).setAlpha(selected ? 0.85 : 0.45);
            scene._mapContent.add(ft);
            scene._mapFuelLabels.push(ft);
            
            // === RUNNING FUEL TOTAL at destination node (confirmed route only) ===
            if (selected && cumFuel > 0) {
                const destObj = scene._mapNodeObjects[e.to];
                if (destObj) {
                    const maxFuel = scene.saveData.fuel || 100;
                    const fuelPct = cumFuel / maxFuel;
                    const fuelCol = fuelPct > 0.75 ? '#cc4444' : fuelPct > 0.5 ? '#aa8844' : '#3a8a3a';
                    const fuelLabel = scene.add.text(
                        destObj.pos.sx + destObj.frameW/2 + 4, destObj.pos.sy - 2,
                        `${cumFuel}`, {
                        fontFamily: 'monospace', fontSize: uiPx(8), fill: fuelCol
                    }).setAlpha(0.7);
                    scene._mapContent.add(fuelLabel);
                    scene._mapFuelLabels.push(fuelLabel);
                }
            }
            
            
            // Edge encounter icons removed — encounters reserved for future traversal system
            if (e.danger >= 2) {
                const dt = scene.add.text(mx + 14, my - 12, e.danger >= 3 ? '!!' : '!', {
                    fontFamily: 'monospace', fontSize: uiPx(9), fill: e.danger >= 3 ? '#cc4444' : '#aa8844'
                }).setOrigin(0.5).setAlpha(0.65);
                scene._mapContent.add(dt);
                scene._mapFuelLabels.push(dt);
            }
        });
    },

    _mapUpdateFuel(scene) {
        if (!scene._mapFuelText) return;
        const route = scene._mapRoute || [];
        const edges = scene._mapReachData ? scene._mapReachData.edges : [];
        const routeFuel = RouteGenerator.calculateRouteFuel(route, edges);
        const availFuel = scene.saveData.stash ? scene.saveData.stash.fuel : 100;
        const over = routeFuel > availFuel;
        scene._mapFuelText.setText(`${routeFuel}/${availFuel}`);
        scene._mapFuelText.setColor(over ? '#cc4444' : '#3a8a3a');
        const ratio = availFuel > 0 ? Math.max(0, (availFuel - routeFuel) / availFuel) : 0;
        CRTTerminal._mapDrawFuelIcon(scene, ratio, over);
        let totalDanger = 0, dangerCount = 0;
        for (let i = 0; i < route.length - 1; i++) {
            const e = edges.find(ed => ed.from === route[i] && ed.to === route[i + 1]);
            if (e) { totalDanger += e.danger; dangerCount++; }
        }
        CRTTerminal._mapDrawDangerIcon(scene, dangerCount > 0 ? totalDanger / dangerCount : 0);
        if (scene._mapStatusText) {
            const bossReached = route[route.length - 1] === (scene._mapReachData ? scene._mapReachData.meta.bossId : '');
            if (bossReached) {
                scene._mapStatusText.setText(over ? 'LOW FUEL' : 'ROUTE READY');
                scene._mapStatusText.setColor(over ? '#cc4444' : '#44cc44');
            } else {
                const ct = route.length - 1;
                scene._mapStatusText.setText(`${ct} NODE${ct !== 1 ? 'S' : ''}`);
                scene._mapStatusText.setColor('#2a5a2a');
            }
        }
    },

    _mapShowLockBtn(scene) {
        if (scene._mapLockBtn) return;
        const routeFuel = RouteGenerator.calculateRouteFuel(scene._mapRoute, scene._mapReachData.edges);
        const availFuel = scene.saveData.stash ? scene.saveData.stash.fuel : 100;
        if (routeFuel > availFuel) return;
        const footY = scene._mapViewTop + scene._mapViewH + scene._mapHudH + 4;
        const btn = CRTTerminal._tAdd(scene, scene.add.text(0, footY, '[ LOCK ROUTE ]', {
            fontFamily: 'monospace', fontSize: uiPx(13), fill: '#44cc44',
            backgroundColor: '#0a2a0a', padding: { x: 12, y: 4 }
        }).setOrigin(0.5).setInteractive({ useHandCursor: true }));
        btn.on('pointerover', () => btn.setColor('#66ff66'));
        btn.on('pointerout', () => btn.setColor('#44cc44'));
        btn.on('pointerdown', () => CRTTerminal._mapLockRoute(scene));
        scene._mapLockBtn = btn;
    },

    _mapRemoveLockBtn(scene) {
        if (scene._mapLockBtn) { scene._mapLockBtn.destroy(); scene._mapLockBtn = null; }
    },

    _mapLockRoute(scene) {
        if (!scene._mapReachData || !scene._mapRoute) return;
        scene.saveData.activeRoute = RouteGenerator.createActiveRoute(
            scene.saveData.routeSeed, scene.saveData.currentReach || 1, scene.saveData.biome || 'grassy',
            scene._mapRoute, scene._mapReachData
        );
        SaveManager.save(scene.saveData);
        AudioManager.uiClick(); Haptics.medium();
        
        if (scene._mapMaskShape) scene._mapMaskShape.destroy();
        if (scene._mapDetailCard) { scene._mapDetailCard.destroy(); scene._mapDetailCard = null; }
        if (scene._mapPulseTweens) scene._mapPulseTweens.forEach(t => t.remove());
        CRTTerminal._mapCleanupInput(scene);
        scene._mapFuelLabels = null; scene._mapNodeObjects = null;
        scene._mapReachData = null; scene._mapContent = null; scene._mapPreviewNode = null;
        
        scene._termContent.removeAll(true);
        const scrW = scene._termScrW || 310, scrH = scene._termScrH || 370, scrY = scene._termScrY || -16;
        CRTTerminal._termMapShowLocked(scene, scrY - scrH/2 + 36, scrH - 50, scrW - 20);
    },

    _termMapShowLocked(scene, startY, h, w) {
        const ar = scene.saveData.activeRoute;
        if (!ar) return;
        CRTTerminal._tAdd(scene, scene.add.text(0, startY, '[ ROUTE LOCKED ]', {
            fontFamily: 'monospace', fontSize: uiPx(14), fill: '#44cc44'
        }).setOrigin(0.5));
        CRTTerminal._tAdd(scene, scene.add.text(0, startY + 18, `REACH ${ar.reach}`, {
            fontFamily: 'monospace', fontSize: uiPx(11), fill: '#3a8a3a'
        }).setOrigin(0.5));
        let yOff = startY + 40;
        const reachData = RouteGenerator.generateReach(ar.seed, ar.reach, ar.biome);
        ar.nodes.forEach((nId, i) => {
            if (yOff > startY + h - 16) return;
            const node = reachData.nodes[nId];
            if (!node) return;
            const isFirst = i === 0, isLast = i === ar.nodes.length - 1;
            const prefix = isFirst ? '>' : isLast ? 'X' : '-';
            const col = isFirst ? '#44aa44' : isLast ? '#cc4444' : '#4a8a4a';
            CRTTerminal._tAdd(scene, scene.add.text(-w/2, yOff, `${prefix} ${node.name}`, {
                fontFamily: 'monospace', fontSize: uiPx(11), fill: col
            }));
            if (i < ar.edges.length) {
                CRTTerminal._tAdd(scene, scene.add.text(w/2, yOff, `${ar.edges[i].fuel}F`, {
                    fontFamily: 'monospace', fontSize: uiPx(10), fill: '#3a6a3a'
                }).setOrigin(1, 0));
            }
            yOff += 16;
        });
        yOff += 8;
        CRTTerminal._tAdd(scene, scene.add.text(0, yOff, `TOTAL FUEL: ${ar.totalFuel}`, {
            fontFamily: 'monospace', fontSize: uiPx(12), fill: '#44cc44'
        }).setOrigin(0.5));
        yOff += 24;
        CRTTerminal._tAdd(scene, scene.add.text(0, yOff, 'ROUTE LOCKED — VEHICLE READY', {
            fontFamily: 'monospace', fontSize: uiPx(10), fill: '#2a6a2a'
        }).setOrigin(0.5));
        yOff += 14;
        CRTTerminal._tAdd(scene, scene.add.text(0, yOff, 'Board vehicle to depart', {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: '#1a4a1a'
        }).setOrigin(0.5));
        
        // Trigger vehicle ignition rumble in garage
        CRTTerminal._vehicleIgnitionRumble(scene);
    },

    _vehicleIgnitionRumble(scene) {
        // Find the vehicle station sprite in the garage and add idle rumble
        const veh = scene.vehicleStation;
        if (!veh) return;
        
        // Kill any existing rumble
        if (scene._vehRumbleTween) { scene._vehRumbleTween.remove(); scene._vehRumbleTween = null; }
        
        const baseX = veh.x, baseY = veh.y;
        
        // Subtle shake loop — engine idling
        scene._vehRumbleTween = scene.tweens.add({
            targets: veh,
            x: { from: baseX - 0.6, to: baseX + 0.6 },
            y: { from: baseY - 0.3, to: baseY + 0.3 },
            duration: 80,
            yoyo: true,
            repeat: -1,
            ease: 'Sine.easeInOut'
        });
        
        // Exhaust puffs
        if (scene._vehExhaustTimer) scene._vehExhaustTimer.destroy();
        scene._vehExhaustTimer = scene.time.addEvent({
            delay: 600,
            loop: true,
            callback: () => {
                if (!veh || !veh.active) return;
                const puff = scene.add.circle(
                    veh.x - 18 + Math.random() * 4,
                    veh.y + 10,
                    2 + Math.random() * 2,
                    0x555555, 0.25
                ).setDepth(veh.depth - 1);
                scene.tweens.add({
                    targets: puff,
                    x: puff.x - 8 - Math.random() * 6,
                    y: puff.y - 4 - Math.random() * 6,
                    alpha: 0,
                    scaleX: 2.5,
                    scaleY: 2,
                    duration: 800,
                    onComplete: () => puff.destroy()
                });
            }
        });
    },

    _stopVehicleRumble(scene) {
        if (scene._vehRumbleTween) { scene._vehRumbleTween.remove(); scene._vehRumbleTween = null; }
        if (scene._vehExhaustTimer) { scene._vehExhaustTimer.destroy(); scene._vehExhaustTimer = null; }
    },

    terminalSquadTab(scene, startY, h, w) {
        CRTTerminal._tAdd(scene, scene.add.text(0, startY, '[ SQUAD ROSTER ]', {
            fontFamily: 'monospace', fontSize: uiPx(12), fill: '#4a9a4a'
        }).setOrigin(0.5));
        
        const survivors = scene.saveData.survivors || [];
        const alive = survivors.filter(s => s.alive);
        const dead = survivors.filter(s => !s.alive);
        
        // Roster count + barracks capacity
        const bLevel = scene.saveData.upgrades.barracks || 1;
        const bDef = CONFIG.barracks.levels[bLevel];
        const maxSurv = bDef ? bDef.maxSurvivors : 2;
        CRTTerminal._tAdd(scene, scene.add.text(-w/2, startY + 18, `${alive.length}/${maxSurv} alive | ${dead.length} fallen`, {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: '#3a6a3a'
        }));
        CRTTerminal._tAdd(scene, scene.add.text(w/2, startY + 18, `${bDef.label} Lv${bLevel}`, {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: '#4a6a6a'
        }).setOrigin(1, 0));
        
        const dg = scene.add.graphics();
        CRTTerminal._tAdd(scene, dg);
        dg.lineStyle(1, 0x2a4a2a, 0.4);
        dg.lineBetween(-w/2, startY + 32, w/2, startY + 32);
        
        if (survivors.length === 0) {
            CRTTerminal._tAdd(scene, scene.add.text(0, startY + 50, 'No survivors recruited.', {
                fontFamily: 'monospace', fontSize: uiPx(10), fill: '#2a4a2a'
            }).setOrigin(0.5));
            return;
        }
        
        let yOff = startY + 38;
        const iconSize = 28;
        const iconPad = 6;
        const lineGap = 2; // minimum gap between text lines
        
        alive.forEach(s => {
            if (yOff > startY + h - 55) return;
            const rDef = SurvivorGenerator.RARITIES[s.rarity];
            const rank = SurvivorGenerator.getRank(s);
            
            // CRT portrait icon
            const iconX = -w/2 + iconSize/2 + 2;
            CRTTerminal._drawCRTPortrait(scene, s, iconX, yOff + iconSize/2 + 1, iconSize);
            
            // Rarity frame around icon
            const ig = scene.add.graphics();
            CRTTerminal._tAdd(scene, ig);
            ig.lineStyle(1, rDef.color, 0.5);
            ig.strokeRect(iconX - iconSize/2 - 1, yOff - 1, iconSize + 2, iconSize + 2);
            
            // ── Tap portrait → show card overlay ──
            const portHit = scene.add.rectangle(iconX, yOff + iconSize/2, iconSize + 4, iconSize + 4, 0x000000, 0.001)
                .setInteractive({ useHandCursor: true });
            CRTTerminal._tAdd(scene, portHit);
            const _surv = s; // closure capture
            portHit.on('pointerdown', () => {
                CRTTerminal._showCRTSurvivorCard(scene, _surv);
            });
            
            // Info text — offset right of icon, accumulate Y from measurements
            const infoX = -w/2 + iconSize + iconPad + 4;
            let textY = yOff;
            
            // Name
            const nameObj = scene.add.text(infoX, textY, s.name, {
                fontFamily: 'monospace', fontSize: uiPx(11), fill: rDef.textColor, fontStyle: 'bold'
            });
            CRTTerminal._tAdd(scene, nameObj);
            if (s.deployed) {
                CRTTerminal._tAdd(scene, scene.add.text(w/2, textY, 'DEPLOYED', {
                    fontFamily: 'monospace', fontSize: uiPx(9), fill: '#44cc44'
                }).setOrigin(1, 0));
            }
            textY += nameObj.height + lineGap;
            
            // Equipped title (optional)
            if (s.equippedTitle) {
                const tDef = CONFIG.survivorTitles ? CONFIG.survivorTitles[s.equippedTitle] : null;
                const tCol = tDef && tDef.tier === 'mastery' ? '#aadd66' : '#5aaa5a';
                const titleObj = scene.add.text(infoX, textY, s.equippedTitle.toUpperCase(), {
                    fontFamily: 'monospace', fontSize: uiPx(7), fill: tCol,
                    fontStyle: 'bold', letterSpacing: 1
                });
                CRTTerminal._tAdd(scene, titleObj);
                textY += titleObj.height + lineGap;
            }
            
            // Rank | Gender | Personality
            const gLabel = s.gender === 'unknown'
                ? (s.unknownType ? s.unknownType.charAt(0).toUpperCase() + s.unknownType.slice(1) : 'Unknown')
                : s.gender.charAt(0).toUpperCase() + s.gender.slice(1);
            const rankObj = scene.add.text(infoX, textY, `${rank.label} | ${gLabel} | ${s.personality.label}`, {
                fontFamily: 'monospace', fontSize: uiPx(8), fill: '#3a6a3a'
            });
            CRTTerminal._tAdd(scene, rankObj);
            textY += rankObj.height + lineGap;
            
            // Marks icons
            if (s.marks && s.marks.length > 0) {
                const iconSize2 = 12;
                const iconPad2 = 2;
                s.marks.forEach((m, mi) => {
                    const mx = infoX + mi * (iconSize2 + iconPad2);
                    const iconKey = SurvivorGenerator.generateMarkIcon(scene, m.id);
                    if (scene.textures.exists(iconKey)) {
                        const img = scene.add.image(mx + iconSize2/2, textY + iconSize2/2, iconKey)
                            .setDisplaySize(iconSize2, iconSize2);
                        CRTTerminal._tAdd(scene, img);
                    }
                });
                textY += 12 + lineGap;
            }
            
            // Injury display
            if (s.injury) {
                const injDef = SurvivorGenerator.INJURY_TYPES[s.injury.type];
                const injLabel = injDef ? injDef.label : s.injury.type;
                const treated = s.injury.treatedAt;
                let cureStr = '';
                if (treated) {
                    cureStr = ` — recovering (${injDef.recoveryRuns} runs)`;
                } else if (injDef) {
                    const treatName = injDef.treatment.replace(/_/g, ' ');
                    cureStr = ` — cure: ${treatName}`;
                }
                CRTTerminal._tAdd(scene, scene.add.text(infoX, textY, '+', {
                    fontFamily: 'monospace', fontSize: uiPx(9), fill: '#cc8833', fontStyle: 'bold'
                }));
                const injObj = scene.add.text(infoX + 10, textY, `${injLabel}${cureStr}`, {
                    fontFamily: 'monospace', fontSize: uiPx(7.5), fill: '#cc8833'
                });
                CRTTerminal._tAdd(scene, injObj);
                textY += injObj.height + lineGap;
            }
            
            // Row height = max(icon height, text column height) + padding
            const textColH = textY - yOff;
            yOff += Math.max(iconSize, textColH) + iconPad;
            const sg = scene.add.graphics();
            CRTTerminal._tAdd(scene, sg);
            sg.lineStyle(1, 0x1a3a1a, 0.3);
            sg.lineBetween(-w/2 + 4, yOff - 2, w/2 - 4, yOff - 2);
        });
        
        // ── FALLEN SECTION ──
        if (dead.length > 0 && yOff < startY + h - 30) {
            yOff += 6;
            CRTTerminal._tAdd(scene, scene.add.text(-w/2, yOff, `FALLEN  (${dead.length})`, {
                fontFamily: 'monospace', fontSize: uiPx(10), fill: '#6a3a3a'
            }));
            
            // MEMORIAL button
            const memBtn = scene.add.rectangle(w/2 - 40, yOff + 6, 70, 16, 0x2a1a1a, 0.8)
                .setStrokeStyle(1, 0x6a3a3a, 0.5).setInteractive({ useHandCursor: true });
            CRTTerminal._tAdd(scene, memBtn);
            CRTTerminal._tAdd(scene, scene.add.text(w/2 - 40, yOff + 6, 'MEMORIAL', {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: '#aa6666'
            }).setOrigin(0.5));
            memBtn.on('pointerover', () => memBtn.setFillStyle(0x3a2a2a));
            memBtn.on('pointerout', () => memBtn.setFillStyle(0x2a1a1a));
            memBtn.on('pointerdown', () => {
                AudioManager.uiClick();
                CRTTerminal._showFallenMemorial(scene, dead);
            });
            
            yOff += 20;
            
            // Brief fallen list (icons only in compact row)
            const maxShow = Math.min(dead.length, Math.floor(w / (iconSize + 4)));
            const rowStart = -w/2 + iconSize/2 + 2;
            dead.slice(0, maxShow).forEach((s, i) => {
                const ix = rowStart + i * (iconSize + 4);
                CRTTerminal._drawCRTPortrait(scene, s, ix, yOff + iconSize/2, iconSize, true); // dimmed for fallen
                // Red X overlay
                const xg = scene.add.graphics();
                CRTTerminal._tAdd(scene, xg);
                xg.lineStyle(2, 0xaa3333, 0.6);
                xg.lineBetween(ix - iconSize/2 + 2, yOff + 2, ix + iconSize/2 - 2, yOff + iconSize - 2);
                xg.lineBetween(ix + iconSize/2 - 2, yOff + 2, ix - iconSize/2 + 2, yOff + iconSize - 2);
            });
        }
    },

    _drawCRTPortrait(scene, surv, x, y, size, dimmed) {
        const texKey = 'crt_face_' + surv.id;
        
        if (!scene.textures.exists(texKey)) {
            try {
                const custom = SurvivorGenerator.toCustomization(surv);
                const srcCanvas = SpriteManager.generatePlayerSheet(custom);
                
                // Extract frame 0 (front-facing idle) — head/bust area
                const fw = 48, fh = 48;
                const cropY = 0, cropH = 30; // head + upper torso
                
                const out = document.createElement('canvas');
                out.width = fw;
                out.height = cropH;
                const octx = out.getContext('2d');
                octx.drawImage(srcCanvas, 0, cropY, fw, cropH, 0, 0, fw, cropH);
                
                // Read pixels and remap to CRT phosphor green
                const imgData = octx.getImageData(0, 0, fw, cropH);
                const px = imgData.data;
                for (let i = 0; i < px.length; i += 4) {
                    const a = px[i + 3];
                    if (a < 10) { px[i] = px[i+1] = px[i+2] = 0; px[i+3] = 0; continue; }
                    // Brightness from RGB
                    const bright = (px[i] * 0.299 + px[i+1] * 0.587 + px[i+2] * 0.114) / 255;
                    // Map to green phosphor levels
                    // hi=0x55cc55, mid=0x3a8a3a, dim=0x2a6a2a, lo=0x1a4a1a
                    let r, g, b;
                    if (bright > 0.7) {
                        r = 0x55 + Math.floor((bright - 0.7) * 100); g = 0xcc; b = 0x55 + Math.floor((bright - 0.7) * 100);
                    } else if (bright > 0.4) {
                        const t = (bright - 0.4) / 0.3;
                        r = Math.floor(0x3a + t * (0x55 - 0x3a)); g = Math.floor(0x8a + t * (0xcc - 0x8a)); b = Math.floor(0x3a + t * (0x55 - 0x3a));
                    } else if (bright > 0.15) {
                        const t = (bright - 0.15) / 0.25;
                        r = Math.floor(0x1a + t * (0x3a - 0x1a)); g = Math.floor(0x4a + t * (0x8a - 0x4a)); b = Math.floor(0x1a + t * (0x3a - 0x1a));
                    } else {
                        r = 0x0a; g = 0x2a; b = 0x0a;
                    }
                    px[i] = Math.min(r, 255); px[i+1] = Math.min(g, 255); px[i+2] = Math.min(b, 255);
                    px[i+3] = a;
                }
                octx.putImageData(imgData, 0, 0);
                
                // Add scanline effect
                octx.fillStyle = 'rgba(0,0,0,0.15)';
                for (let sy = 0; sy < cropH; sy += 2) {
                    octx.fillRect(0, sy, fw, 1);
                }
                
                scene.textures.addCanvas(texKey, out);
            } catch(e) {
                // Fallback: green square placeholder
                const fb = document.createElement('canvas');
                fb.width = fb.height = 24;
                const fctx = fb.getContext('2d');
                fctx.fillStyle = '#1a4a1a';
                fctx.fillRect(0, 0, 24, 24);
                fctx.fillStyle = '#3a8a3a';
                fctx.fillRect(6, 4, 12, 10);
                fctx.fillRect(8, 14, 8, 6);
                scene.textures.addCanvas(texKey, fb);
            }
        }
        
        if (!scene.textures.exists(texKey)) {
            // Texture creation failed entirely — use inline fallback
            const fb = document.createElement('canvas');
            fb.width = fb.height = 24;
            const fctx = fb.getContext('2d');
            fctx.fillStyle = '#1a4a1a';
            fctx.fillRect(0, 0, 24, 24);
            scene.textures.addCanvas(texKey, fb);
        }
        
        const spr = scene.add.image(x, y, texKey);
        spr.setDisplaySize(size, size * (30/48));
        if (dimmed) spr.setAlpha(0.4);
        CRTTerminal._tAdd(scene, spr);
        return spr;
    },

    _showCRTSurvivorCard(scene, surv) {
        if (scene._crtCardOverlay) { scene._crtCardOverlay.destroy(); scene._crtCardOverlay = null; }
        if (scene._crtDismissHandler) { scene.input.off('pointerdown', scene._crtDismissHandler); scene._crtDismissHandler = null; }
        AudioManager.uiClick();
        
        const W = CONFIG.width, H = CONFIG.height;
        const cW = 240;
        
        // Calculate needed height based on content
        const marks = surv.marks || [];
        let needH = 170; // base: portrait + rank + stats + separators (with measured text spacing)
        if (surv.equippedTitle) needH += 18; // title line under name
        if (surv.injury) needH += 40;
        needH += 24; // marks header
        marks.forEach(m => {
            if (m.desc) {
                const lines = Math.ceil((m.desc.length || 20) / 32);
                needH += 18 + lines * 14 + 6;
            } else {
                needH += 20;
            }
        });
        if ((surv.achievements || []).length > 0) needH += 56;
        needH += 24; // bottom padding
        const cH = Math.max(200, Math.min(needH, H - 40)); // clamp to screen
        
        // Container at depth 600
        const overlay = scene.add.container(0, 0).setDepth(600).setScrollFactor(0);
        scene._crtCardOverlay = overlay;
        
        // Dimmed backdrop (visual only, not interactive)
        overlay.add(scene.add.rectangle(W/2, H/2, W + 100, H + 100, 0x000000, 0.65));
        
        // Card bg (visual only)
        overlay.add(scene.add.rectangle(W/2, H/2, cW, cH, 0x0a1a0a, 0.97));
        
        // Card border + scanlines
        const border = scene.add.graphics();
        border.lineStyle(2, 0x4a8a4a, 0.8);
        border.strokeRoundedRect(W/2 - cW/2, H/2 - cH/2, cW, cH, 4);
        border.fillStyle(0x000000, 0.06);
        for (let sy = H/2 - cH/2; sy < H/2 + cH/2; sy += 3) border.fillRect(W/2 - cW/2, sy, cW, 1);
        overlay.add(border);
        
        // SCENE-LEVEL dismiss: any tap anywhere dismisses after a short delay
        // (delay prevents the opening tap from immediately closing it)
        let armed = false;
        scene.time.delayedCall(150, () => { armed = true; });
        scene._crtDismissHandler = () => {
            if (!armed) return;
            if (scene._crtCardOverlay) { scene._crtCardOverlay.destroy(); scene._crtCardOverlay = null; }
            if (scene._crtDismissHandler) { scene.input.off('pointerdown', scene._crtDismissHandler); scene._crtDismissHandler = null; }
        };
        scene.input.on('pointerdown', scene._crtDismissHandler);
        
        const rDef = SurvivorGenerator.RARITIES[surv.rarity];
        const rank = SurvivorGenerator.getRank(surv);
        const crtBright = '#77ee77';
        const crtMid = '#5acc5a';
        const crtDim = '#3a7a3a';
        const gap = 2; // minimum gap between lines
        
        const ox = W/2;
        const lx = ox - cW/2 + 14;
        const rx = ox + cW/2 - 14;
        let py = H/2 - cH/2 + 14;
        
        // ── Portrait + Identity ──
        const portKey = 'crt_face_' + surv.id;
        const portH = 32;
        if (scene.textures.exists(portKey)) {
            overlay.add(scene.add.image(lx + 22, py + portH/2 + 4, portKey).setDisplaySize(48, portH));
        }
        
        // Name (right of portrait)
        const nameObj = scene.add.text(lx + 52, py, surv.name, {
            fontFamily: 'monospace', fontSize: uiPx(13), fill: crtBright, fontStyle: 'bold'
        });
        overlay.add(nameObj);
        let textY = py + nameObj.height + gap;
        
        // ── Equipped title (under name) ──
        const crtTitle = surv.equippedTitle || null;
        if (crtTitle) {
            const titleDef = CONFIG.survivorTitles ? CONFIG.survivorTitles[crtTitle] : null;
            const titleCol = titleDef && titleDef.tier === 'mastery' ? '#aadd66' : '#5aaa5a';
            const titleTxt = scene.add.text(lx + 52, textY, crtTitle.toUpperCase(), {
                fontFamily: 'monospace', fontSize: uiPx(8), fill: titleCol,
                fontStyle: 'bold', letterSpacing: 2
            });
            const maxTW = rx - (lx + 52) - 4;
            if (titleTxt.width > maxTW) titleTxt.setScale(maxTW / titleTxt.width, 1);
            overlay.add(titleTxt);
            textY += titleTxt.height + gap;
        }
        // Rarity · Gender
        const gLabel = surv.gender === 'unknown'
            ? (surv.unknownType ? surv.unknownType.charAt(0).toUpperCase() + surv.unknownType.slice(1) : 'Unknown')
            : surv.gender.charAt(0).toUpperCase() + surv.gender.slice(1);
        const rarGObj = scene.add.text(lx + 52, textY, `${rDef.label} · ${gLabel}`, {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: crtDim
        });
        overlay.add(rarGObj);
        textY += rarGObj.height + gap;
        // Personality
        const persObj = scene.add.text(lx + 52, textY, surv.personality.label, {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: crtDim, fontStyle: 'italic'
        });
        overlay.add(persObj);
        textY += persObj.height + gap;
        
        // Advance py to whichever is taller: portrait or text column
        py = Math.max(py + portH + 10, textY + 4);
        
        // Separator
        const sg = scene.add.graphics();
        sg.lineStyle(1, 0x3a6a3a, 0.5); sg.lineBetween(lx, py, rx, py);
        overlay.add(sg);
        py += 8;
        
        // ── Rank + XP ──
        const rankIconKey = SurvivorGenerator.generateRankIcon(scene, rank.level);
        const rankLabelObj = scene.add.text(lx + 24, py, rank.label.toUpperCase(), {
            fontFamily: 'monospace', fontSize: uiPx(11), fill: crtBright, fontStyle: 'bold'
        });
        overlay.add(scene.add.image(lx + 10, py + rankLabelObj.height/2, rankIconKey).setDisplaySize(20, 20));
        overlay.add(rankLabelObj);
        py += rankLabelObj.height + gap + 4;
        
        const xpToNext = SurvivorGenerator.getXPForNextRank(surv);
        const xpBarX = lx + 24, xpBarY = py, xpBarW = rx - xpBarX - 40;
        const xpBarG = scene.add.graphics();
        xpBarG.fillStyle(0x1a3a1a, 1); xpBarG.fillRect(xpBarX, xpBarY, xpBarW, 3);
        if (xpToNext !== null) {
            const nextRank = SurvivorGenerator.RANKS.find(r => r.level === rank.level + 1);
            const prevXP = rank.xpNeeded;
            const nextXP = nextRank ? nextRank.xpNeeded : prevXP;
            const progress = nextXP > prevXP ? Math.min(1, (surv.xp - prevXP) / (nextXP - prevXP)) : 1;
            xpBarG.fillStyle(0x4aba4a, 0.6); xpBarG.fillRect(xpBarX, xpBarY, Math.round(xpBarW * progress), 3);
        } else {
            xpBarG.fillStyle(0x4aba4a, 0.6); xpBarG.fillRect(xpBarX, xpBarY, xpBarW, 3);
        }
        overlay.add(xpBarG);
        const xpLabelObj = scene.add.text(xpBarX + xpBarW + 4, xpBarY - 2, xpToNext ? `${xpToNext} XP` : 'MAX', {
            fontFamily: 'monospace', fontSize: uiPx(7), fill: crtDim
        });
        overlay.add(xpLabelObj);
        py += Math.max(4, xpLabelObj.height) + gap + 4;
        
        // ── Stats ──
        const runs = surv.runsCompleted || 0;
        const kills = surv.kills || 0;
        const bosses = surv.bossesKilled || 0;
        const statsObj = scene.add.text(ox, py, `${runs} Runs  ·  ${kills} Kills  ·  ${bosses} Bosses`, {
            fontFamily: 'monospace', fontSize: uiPx(9), fill: crtMid
        }).setOrigin(0.5, 0);
        overlay.add(statsObj);
        py += statsObj.height + gap + 4;
        
        // Separator
        const sg2 = scene.add.graphics();
        sg2.lineStyle(1, 0x3a6a3a, 0.5); sg2.lineBetween(lx, py, rx, py);
        overlay.add(sg2);
        py += 8;
        
        // ── Injury ──
        if (surv.injury) {
            const injDef = SurvivorGenerator.INJURY_TYPES[surv.injury.type];
            const injLabel = injDef ? injDef.label : surv.injury.type;
            const injCol = '#ccaa44';
            overlay.add(scene.add.text(lx, py, '+', {
                fontFamily: 'monospace', fontSize: uiPx(11), fill: injCol, fontStyle: 'bold'
            }));
            const injStatus = surv.injury.treatedAt ? '(Treated)' : '(Untreated)';
            const injObj = scene.add.text(lx + 14, py, `${injLabel} ${injStatus}`, {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: injCol, fontStyle: 'bold'
            });
            overlay.add(injObj);
            py += injObj.height + gap;
            if (injDef) {
                const cureText = surv.injury.treatedAt
                    ? `Recovering — ${injDef.recoveryRuns} runs`
                    : `Cure: ${injDef.treatment.replace(/_/g, ' ')}`;
                const cureObj = scene.add.text(lx + 14, py, cureText, {
                    fontFamily: 'monospace', fontSize: uiPx(7), fill: '#aa9944'
                });
                overlay.add(cureObj);
                py += cureObj.height + gap;
            }
            py += 4;
        }
        
        // ── Marks ──
        if (marks.length > 0) {
            const marksHeaderObj = scene.add.text(lx, py, `MARKS ${marks.length}/8`, {
                fontFamily: 'monospace', fontSize: uiPx(10), fill: crtBright, fontStyle: 'bold'
            });
            overlay.add(marksHeaderObj);
            py += marksHeaderObj.height + gap + 4;
            
            const sorted = [...marks].sort((a, b) => {
                const order = { positive: 0, mixed: 1, negative: 2 };
                return (order[a.type] || 1) - (order[b.type] || 1);
            });
            sorted.forEach(m => {
                const iconKey = SurvivorGenerator.generateMarkIcon(scene, m.id);
                const tCol = m.type === 'positive' ? '#5acc5a' : m.type === 'negative' ? '#cc8855' : '#aaa855';
                const markNameObj = scene.add.text(lx + 20, py, m.name, {
                    fontFamily: 'monospace', fontSize: uiPx(9), fill: tCol, fontStyle: 'bold'
                });
                overlay.add(markNameObj);
                if (scene.textures.exists(iconKey)) {
                    overlay.add(scene.add.image(lx + 8, py + markNameObj.height/2, iconKey).setDisplaySize(14, 14));
                }
                py += markNameObj.height + gap;
                if (m.desc) {
                    const descObj = scene.add.text(lx + 20, py, m.desc, {
                        fontFamily: 'monospace', fontSize: uiPx(7), fill: crtDim,
                        wordWrap: { width: cW - 48 }
                    });
                    overlay.add(descObj);
                    py += descObj.height + gap + 2;
                }
            });
        } else {
            const noMarksObj = scene.add.text(lx, py, 'No marks', {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: crtDim
            });
            overlay.add(noMarksObj);
            py += noMarksObj.height + gap;
        }
        
        // ── Achievements ──
        const survAchs = surv.achievements || [];
        if (survAchs.length > 0) {
            py += 4;
            const sg3 = scene.add.graphics();
            sg3.lineStyle(1, 0x3a6a3a, 0.5); sg3.lineBetween(lx, py, rx, py);
            overlay.add(sg3);
            py += 8;
            
            const achComplete = survAchs.filter(a => a.complete).length;
            const achHeaderObj = scene.add.text(ox, py, `ACHIEVEMENTS ${achComplete}/${survAchs.length}`, {
                fontFamily: 'monospace', fontSize: uiPx(10), fill: crtBright, fontStyle: 'bold'
            }).setOrigin(0.5, 0);
            overlay.add(achHeaderObj);
            py += achHeaderObj.height + gap + 4;
            
            // Icon grid: 9 icons in a row
            const achRowW = rx - lx;
            const achGap = achRowW / survAchs.length;
            survAchs.forEach((ach, i) => {
                const def = SurvivorGenerator.getAchievementDef(ach.id);
                if (!def) return;
                const iconKey = SurvivorGenerator.generateAchievementIcon(scene, ach.id);
                const ax = lx + achGap / 2 + i * achGap;
                const alpha = ach.complete ? 1.0 : 0.2;
                overlay.add(scene.add.image(ax, py + 6, iconKey).setDisplaySize(16, 16).setAlpha(alpha));
                if (ach.complete) {
                    overlay.add(scene.add.circle(ax, py + 6, 9, Phaser.Display.Color.HexStringToColor(def.color).color, 0.12));
                }
            });
            py += 20;
        }
    },

    _showFallenMemorial(scene, dead) {
        if (scene.popupActive) return;
        scene.popupActive = true;
        const W = CONFIG.width, H = CONFIG.height;
        
        const panel = UIManager.createPanel(scene, W/2, H/2, W - 20, H - 60, {
            title: 'MEMORIAL', accent: 0x6a3333, closable: true,
            onClose: () => { scene.popupActive = false; }, depth: 250
        });
        scene.currentPopup = panel;
        const cb = panel._contentBounds;
        
        panel.add(scene.add.text(0, cb.y - 2, 'Those who gave everything.', {
            fontFamily: CONFIG.font, fontSize: uiPx(7), fill: '#665555', fontStyle: 'italic'
        }).setOrigin(0.5));
        
        let yOff = cb.y + 16;
        const iconSize = 32;
        
        dead.forEach((s, idx) => {
            if (yOff > cb.y + cb.h - 20) return;
            
            const rDef = SurvivorGenerator.RARITIES[s.rarity];
            const rank = SurvivorGenerator.getRank(s);
            const rHex = '#' + rDef.color.toString(16).padStart(6, '0');
            
            // Row bg
            panel.add(scene.add.rectangle(0, yOff + iconSize/2 + 2, cb.w, iconSize + 16, 0x0e0a0a, 0.5));
            
            // CRT portrait (reuses cached texture)
            const texKey = 'crt_face_' + s.id;
            if (scene.textures.exists(texKey)) {
                const port = scene.add.image(-cb.w/2 + iconSize/2 + 6, yOff + iconSize/2 + 2, texKey)
                    .setDisplaySize(iconSize, iconSize * (30/48)).setAlpha(0.6).setTint(0xaa6666);
                panel.add(port);
            }
            
            // Red frame
            const fg = scene.add.graphics();
            panel.add(fg);
            fg.lineStyle(1, 0x663333, 0.6);
            fg.strokeRect(-cb.w/2 + 5, yOff - 1, iconSize + 2, iconSize + 6);
            
            // Name + rarity
            const infoX = -cb.w/2 + iconSize + 14;
            panel.add(scene.add.text(infoX, yOff, s.name, {
                fontFamily: CONFIG.font, fontSize: uiPx(11), fill: rHex, fontStyle: 'bold'
            }));
            
            // Title (if had one)
            let memInfoY = yOff + 14;
            if (s.equippedTitle) {
                const tDef = CONFIG.survivorTitles ? CONFIG.survivorTitles[s.equippedTitle] : null;
                const tCol = tDef ? tDef.color : '#bbaa66';
                panel.add(scene.add.text(infoX, yOff + 14, s.equippedTitle.toUpperCase(), {
                    fontFamily: CONFIG.font, fontSize: uiPx(5.5), fill: tCol,
                    fontStyle: 'bold', letterSpacing: 1, alpha: 0.7
                }));
                memInfoY = yOff + 24;
            }
            
            panel.add(scene.add.text(infoX, memInfoY, `${rDef.label} ${rank.label}  ·  ${s.personality.label}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#776666'
            }));
            
            // Accolade stats
            const runs = s.runsCompleted || 0;
            const kills = s.kills || 0;
            const bosses = s.bossesKilled || 0;
            const xp = s.xp || 0;
            const timeSurv = s.timeSurvived || 0;
            const timeMins = Math.floor(timeSurv / 60000);
            const reach = s.highestReach || 0;
            const looted = s.itemsLooted || 0;
            
            // Recruited / died dates
            const recruited = s.recruitedAt ? new Date(s.recruitedAt).toLocaleDateString() : '???';
            const died = s.diedAt ? new Date(s.diedAt).toLocaleDateString() : '???';
            
            // Primary stats row
            panel.add(scene.add.text(infoX, yOff + 27, `Runs: ${runs}   Kills: ${kills}   Bosses: ${bosses}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#998888'
            }));
            
            // Secondary stats row
            panel.add(scene.add.text(infoX, yOff + 39, `Reach: ${reach}   Loot: ${looted}   Time: ${timeMins}m   XP: ${xp}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(6), fill: '#887777'
            }));
            
            panel.add(scene.add.text(infoX, yOff + 51, `Recruited ${recruited}  ·  Fell ${died}`, {
                fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#665555'
            }));
            
            // Death cause
            if (s.deathCause || s.deathBiome) {
                const causeLabel = s.deathCause === 'boss' ? 'Killed in boss fight' :
                    s.deathCause === 'defense' ? 'Fell defending position' : 'Lost in combat';
                const biomeLabel = s.deathBiome ? ` — ${s.deathBiome}` : '';
                const reachLabel = s.deathReach ? ` (Reach ${s.deathReach})` : '';
                panel.add(scene.add.text(infoX, yOff + 61, `${causeLabel}${biomeLabel}${reachLabel}`, {
                    fontFamily: CONFIG.font, fontSize: uiPx(5), fill: '#884444', fontStyle: 'italic'
                }));
            }
            
            // Marks they had — icon row
            if (s.marks && s.marks.length > 0) {
                const mIconY = yOff + 63;
                const mIconSz = 10;
                s.marks.forEach((m, mi) => {
                    const mx = infoX + mi * (mIconSz + 2);
                    const iconKey = SurvivorGenerator.generateMarkIcon(scene, m.id);
                    if (scene.textures.exists(iconKey)) {
                        panel.add(scene.add.image(mx + mIconSz/2, mIconY + mIconSz/2, iconKey)
                            .setDisplaySize(mIconSz, mIconSz));
                    }
                });
            }
            
            // Divider
            panel.add(scene.add.rectangle(0, yOff + iconSize + 52, cb.w - 16, 1, 0x332222, 0.4));
            
            yOff += iconSize + 60;
        });
    },

    terminalFactionsTab(scene, startY, h, w) {
        CRTTerminal._tAdd(scene, scene.add.text(0, startY, '[ FOUNDRY RELATIONS ]', {
            fontFamily: 'monospace', fontSize: uiPx(12), fill: '#4a9a4a'
        }).setOrigin(0.5));
        
        const factions = CONFIG.factions || {};
        const repData = scene.saveData.factionRep || {};
        
        let yOff = startY + 20;
        Object.entries(factions).forEach(([id, f]) => {
            if (yOff > startY + h - 20) return;
            const foundry = CONFIG.foundries[id];
            const rep = repData[id] || 0;
            const accentHex = foundry ? foundry.palette.accent : '#3a6a3a';
            
            // Faction name
            const fNameObj = scene.add.text(-w/2, yOff, (foundry ? foundry.tag + ' ' : '') + f.name.toUpperCase(), {
                fontFamily: 'monospace', fontSize: uiPx(10), fill: accentHex, fontStyle: 'bold'
            });
            CRTTerminal._tAdd(scene, fNameObj);
            
            // Rep level
            const repLabel = rep === 0 ? 'UNKNOWN' : rep > 0 ? 'ALLIED' : 'HOSTILE';
            const repCol = rep === 0 ? '#3a5a3a' : rep > 0 ? '#4a9a4a' : '#9a4a4a';
            CRTTerminal._tAdd(scene, scene.add.text(w/2, yOff, repLabel, {
                fontFamily: 'monospace', fontSize: uiPx(9), fill: repCol
            }).setOrigin(1, 0));
            yOff += fNameObj.height + 2;
            
            // Status line
            const statusObj = scene.add.text(-w/2 + 8, yOff, f.status, {
                fontFamily: 'monospace', fontSize: uiPx(8), fill: '#2a4a2a'
            });
            CRTTerminal._tAdd(scene, statusObj);
            yOff += statusObj.height + 2;
            
            // Rep bar
            const bg = scene.add.graphics();
            CRTTerminal._tAdd(scene, bg);
            const barX = -w/2 + 8, barY = yOff, barW = w - 16, barH = 4;
            bg.fillStyle(0x0a1a0a, 0.6);
            bg.fillRect(barX, barY, barW, barH);
            // Center notch (neutral)
            bg.fillStyle(0x2a4a2a, 0.6);
            bg.fillRect(barX + barW/2 - 1, barY - 1, 2, barH + 2);
            // Rep fill
            if (rep !== 0) {
                const fillW = Math.abs(rep) / 100 * (barW / 2);
                const fillX = rep > 0 ? barX + barW/2 : barX + barW/2 - fillW;
                bg.fillStyle(rep > 0 ? 0x3a8a3a : 0x8a3a3a, 0.7);
                bg.fillRect(fillX, barY, fillW, barH);
            }
            
            yOff += barH + 10;
        });
    },

    terminalQuestsTab(scene, startY, h, w) {
        const qData = scene.saveData.quests || { active: [], completed: [] };
        const stats = scene.saveData.stats || {};
        const allQuests = CONFIG.quests;
        
        CRTTerminal._tAdd(scene, scene.add.text(0, startY, '[ OBJECTIVES ]', {
            fontFamily: 'monospace', fontSize: uiPx(12), fill: '#4a9a4a'
        }).setOrigin(0.5));
        
        let yOff = startY + 18;
        const typeLabels = { main: 'MAIN', combat: 'COMBAT', explore: 'EXPLORE', survive: 'SURVIVE' };
        const typeColors = { main: '#ffaa44', combat: '#ff6644', explore: '#44aaff', survive: '#44ff88' };
        
        // Group quests by type
        Object.entries(typeLabels).forEach(([type, label]) => {
            const quests = Object.values(allQuests).filter(q => q.type === type);
            if (quests.length === 0) return;
            
            CRTTerminal._tAdd(scene, scene.add.text(-w/2, yOff, `─── ${label} ───`, {
                fontFamily: 'monospace', fontSize: uiPx(10), fill: typeColors[type] || '#888'
            }));
            yOff += 18;
            
            quests.forEach(q => {
                const isComplete = qData.completed.includes(q.id);
                const progress = (q.stat && q.stat !== 'custom') ? (stats[q.stat] || 0) : 0;
                const pct = Math.min(progress / q.target, 1);
                
                // Quest title
                const statusIcon = isComplete ? 'OK' : '--';
                const titleColor = isComplete ? '#2a4a2a' : '#4a8a4a';
                const qTitleObj = scene.add.text(-w/2, yOff, `${statusIcon} ${q.title}`, {
                    fontFamily: 'monospace', fontSize: uiPx(10), fill: titleColor
                });
                CRTTerminal._tAdd(scene, qTitleObj);
                
                if (!isComplete) {
                    // Progress bar
                    const barW = 60;
                    const barX = w/2 - barW;
                    CRTTerminal._tAdd(scene, scene.add.rectangle(barX + barW/2, yOff + 4, barW, 6, 0x1a2a1a).setStrokeStyle(1, 0x2a4a2a));
                    CRTTerminal._tAdd(scene, scene.add.rectangle(barX + (barW * pct)/2, yOff + 4, barW * pct, 4, 0x3a8a3a));
                    CRTTerminal._tAdd(scene, scene.add.text(w/2, yOff, `${Math.min(progress, q.target)}/${q.target}`, {
                        fontFamily: 'monospace', fontSize: uiPx(9), fill: '#3a6a3a'
                    }).setOrigin(1, 0));
                } else {
                    CRTTerminal._tAdd(scene, scene.add.text(w/2, yOff, 'DONE', {
                        fontFamily: 'monospace', fontSize: uiPx(9), fill: '#2a4a2a'
                    }).setOrigin(1, 0));
                }
                
                // Description
                yOff += qTitleObj.height + 2;
                const qDescObj = scene.add.text(-w/2 + 12, yOff, q.desc, {
                    fontFamily: 'monospace', fontSize: uiPx(9), fill: '#2a4a2a'
                });
                CRTTerminal._tAdd(scene, qDescObj);
                yOff += qDescObj.height + 4;
            });
            yOff += 4;
        });
    }
};
