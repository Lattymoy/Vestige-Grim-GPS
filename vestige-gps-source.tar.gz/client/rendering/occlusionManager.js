// Vestige GPS — OcclusionManager
// Extracted from monolith L31029-31073

export const OcclusionManager = {
    _scenes: new Map(),

    register(scene, container, x, y, w, h, opts = {}) {
        const key = scene.scene.key;
        if (!this._scenes.has(key)) this._scenes.set(key, []);
        this._scenes.get(key).push({
            target: container,
            x, y, w, h,
            fullAlpha: opts.fullAlpha !== undefined ? opts.fullAlpha : 1,
            fadeAlpha: opts.fadeAlpha !== undefined ? opts.fadeAlpha : 0.25,
            fadeSpeed: opts.fadeSpeed || 0.12,
            _currentAlpha: opts.fullAlpha !== undefined ? opts.fullAlpha : 1
        });
    },

    update(scene, px, py) {
        const key = scene.scene.key;
        const list = this._scenes.get(key);
        if (!list) return;
        const pw = 10, ph = 10;
        for (const occ of list) {
            if (!occ.target || !occ.target.active) continue;
            const hw = occ.w / 2, hh = occ.h / 2;
            // In ¾ iso, player is "behind" tall objects when overlapping horizontally
            // and within the upper portion of the bounding area (north of object base)
            const overlapX = px + pw > occ.x - hw && px - pw < occ.x + hw;
            const overlapY = py + ph > occ.y - hh && py - ph < occ.y + hh;
            const shouldFade = overlapX && overlapY;
            const targetAlpha = shouldFade ? occ.fadeAlpha : occ.fullAlpha;
            const diff = targetAlpha - occ._currentAlpha;
            if (Math.abs(diff) > 0.01) {
                occ._currentAlpha += diff * occ.fadeSpeed;
            } else {
                occ._currentAlpha = targetAlpha;
            }
            occ.target.setAlpha(occ._currentAlpha);
        }
    },

    destroy(scene) {
        const key = scene.scene.key;
        this._scenes.delete(key);
    }
};

