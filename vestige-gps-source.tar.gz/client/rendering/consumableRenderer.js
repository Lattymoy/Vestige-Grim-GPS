// Vestige GPS — ConsumableRenderer (Phaser)
// VFX for consumable items: healing, grenades, zone effects
// Wire to core: ConsumableSystem.init(ConsumableRenderer)
import { ConsumableSystem } from '../../core/consumableSystem.js';
import { AudioManager } from '../audioManager.js';

export const ConsumableRenderer = {
    /**
     * Instant heal flash + floating text.
     */
    instantHealVFX(scene, player, heal) {
        if (!player || !player.active) return;

        // Green flash
        player.setTint(0x44ff88);
        scene.time.delayedCall(120, () => {
            if (player.active) {
                if (scene._ambientTint && scene._ambientTint !== 0xffffff) {
                    player.setTint(scene._ambientTint);
                } else {
                    player.clearTint();
                }
            }
        });

        // Floating heal number
        const t = scene.add.text(player.x, player.y - 20, `+${heal}`, {
            fontFamily: 'monospace', fontSize: '11px',
            color: '#44ff88', stroke: '#000000', strokeThickness: 2
        }).setOrigin(0.5, 1).setDepth(100);

        scene.tweens.add({
            targets: t,
            y: player.y - 35, alpha: 0,
            duration: 600, ease: 'Power2',
            onComplete: () => t.destroy()
        });

        // Green particles rising
        for (let i = 0; i < 5; i++) {
            const p = scene.add.circle(
                player.x + (Math.random() - 0.5) * 12,
                player.y + (Math.random() - 0.5) * 8,
                1.5, 0x44ff88, 0.6
            ).setDepth(99);
            scene.tweens.add({
                targets: p,
                y: p.y - 15 - Math.random() * 10,
                alpha: 0, duration: 400 + Math.random() * 200,
                onComplete: () => p.destroy()
            });
        }
    },

    /**
     * Create a channeling progress bar above player.
     * Returns { update(x, y, pct), destroy() }
     */
    createChannelBar(scene, player, color) {
        const barW = 24, barH = 3;
        const gfx = scene.add.graphics().setDepth(100);
        const hexColor = typeof color === 'string'
            ? parseInt(color.replace('#', ''), 16)
            : (color || 0x44ff88);

        const bar = {
            update(x, y, pct) {
                gfx.clear();
                // Background
                gfx.fillStyle(0x000000, 0.5);
                gfx.fillRect(x - barW / 2, y - 22, barW, barH);
                // Fill
                gfx.fillStyle(hexColor, 0.8);
                gfx.fillRect(x - barW / 2, y - 22, barW * Math.min(1, pct), barH);
                // Border
                gfx.lineStyle(1, hexColor, 0.4);
                gfx.strokeRect(x - barW / 2, y - 22, barW, barH);
            },
            destroy() {
                gfx.destroy();
            }
        };
        return bar;
    },

    /**
     * Single particle during channeling.
     */
    channelParticle(scene, x, y, color) {
        const hexColor = typeof color === 'string'
            ? parseInt(color.replace('#', ''), 16) : (color || 0x44ff88);
        const angle = Math.random() * Math.PI * 2;
        const dist = 10 + Math.random() * 8;
        const p = scene.add.circle(
            x + Math.cos(angle) * dist,
            y + Math.sin(angle) * dist,
            1, hexColor, 0.5
        ).setDepth(99);

        scene.tweens.add({
            targets: p, x, y,
            alpha: 0, duration: 300,
            onComplete: () => p.destroy()
        });
    },

    /**
     * Channel complete burst effect.
     */
    channelComplete(scene, x, y, color) {
        const hexColor = typeof color === 'string'
            ? parseInt(color.replace('#', ''), 16) : (color || 0x44ff88);
        const burst = scene.add.circle(x, y, 4, hexColor, 0.6).setDepth(100);
        scene.tweens.add({
            targets: burst,
            scaleX: 4, scaleY: 4, alpha: 0,
            duration: 300,
            onComplete: () => burst.destroy()
        });
    },

    /**
     * Channel interrupted feedback.
     */
    channelInterrupt(scene, x, y) {
        const t = scene.add.text(x, y - 20, 'INTERRUPTED', {
            fontFamily: 'monospace', fontSize: '8px',
            color: '#ff4444', stroke: '#000000', strokeThickness: 2
        }).setOrigin(0.5, 1).setDepth(100);

        scene.tweens.add({
            targets: t, y: y - 32, alpha: 0,
            duration: 500,
            onComplete: () => t.destroy()
        });
    },

    /**
     * Regen over time VFX handle.
     * Returns { tickPulse(x, y), destroy() }
     */
    regenVFX(scene, player, duration) {
        const gfx = scene.add.graphics().setDepth(98);
        let active = true;

        return {
            tickPulse(x, y) {
                if (!active) return;
                // Brief green ring pulse
                const ring = scene.add.circle(x, y, 8, 0x44ff88, 0.15).setDepth(98);
                scene.tweens.add({
                    targets: ring,
                    scaleX: 2, scaleY: 2, alpha: 0,
                    duration: 400,
                    onComplete: () => ring.destroy()
                });
            },
            destroy() {
                active = false;
                gfx.destroy();
            }
        };
    },

    /**
     * Single regen sparkle particle.
     */
    regenSparkle(scene, x, y) {
        const sparkle = scene.add.circle(
            x + (Math.random() - 0.5) * 10,
            y + (Math.random() - 0.5) * 8,
            1, 0x44ff88, 0.5
        ).setDepth(99);
        scene.tweens.add({
            targets: sparkle,
            y: sparkle.y - 10, alpha: 0,
            duration: 300,
            onComplete: () => sparkle.destroy()
        });
    },

    /**
     * Grenade throw arc + explosion.
     * onLand(x, y) called at landing, onDetonate(x, y) called at explosion.
     */
    grenadeVFX(scene, player, target, item, onLand, onDetonate) {
        const sx = player.x, sy = player.y;
        const tx = target.x, ty = target.y;
        const arcHeight = 30;

        // Grenade projectile
        const gren = scene.add.circle(sx, sy, 3, 0x888888, 0.9).setDepth(50);

        // Arc tween
        scene.tweens.add({
            targets: gren,
            x: tx, duration: 500, ease: 'Linear'
        });
        scene.tweens.add({
            targets: gren,
            y: { value: ty, duration: 500, ease: 'Bounce.easeOut' },
            onUpdate: (tween) => {
                const progress = tween.progress;
                const arc = Math.sin(progress * Math.PI) * arcHeight;
                gren.y = sy + (ty - sy) * progress - arc;
            },
            onComplete: () => {
                gren.destroy();
                if (onLand) onLand(tx, ty);

                // Fuse delay then detonate
                scene.time.delayedCall(item.fuseTime || 500, () => {
                    if (onDetonate) onDetonate(tx, ty);
                });
            }
        });
    },

    /**
     * Explosion/detonation VFX at a point.
     * type: 'frag', 'incendiary', 'flashbang', 'toxic'
     */
    detonateVFX(scene, x, y, type, radius) {
        const colors = {
            frag: 0xff6622, incendiary: 0xff4400,
            flashbang: 0xffffcc, toxic: 0x44aa33
        };
        const color = colors[type] || 0xff6622;

        // Flash
        const flash = scene.add.circle(x, y, radius * 0.3, 0xffffff, 0.8).setDepth(100);
        scene.tweens.add({
            targets: flash,
            scaleX: 3, scaleY: 3, alpha: 0,
            duration: 150,
            onComplete: () => flash.destroy()
        });

        // Expanding ring
        const ring = scene.add.circle(x, y, 4, color, 0).setDepth(99)
            .setStrokeStyle(2, color, 0.6);
        scene.tweens.add({
            targets: ring,
            scaleX: radius / 4, scaleY: radius / 4,
            alpha: 0, duration: 300,
            onComplete: () => ring.destroy()
        });

        // Debris particles
        for (let i = 0; i < 8; i++) {
            const a = Math.random() * Math.PI * 2;
            const d = radius * 0.3 + Math.random() * radius * 0.5;
            const bit = scene.add.circle(x, y, 1.5, color, 0.7).setDepth(50);
            scene.tweens.add({
                targets: bit,
                x: x + Math.cos(a) * d,
                y: y + Math.sin(a) * d,
                alpha: 0, duration: 250 + Math.random() * 150,
                onComplete: () => bit.destroy()
            });
        }

        // Camera shake
        if (scene.cameras && scene.cameras.main) {
            scene.cameras.main.shake(100, 0.01);
        }
    },

    /**
     * Zone effect visuals (damage zone, heal zone, slow zone).
     * Returns { fade(pct), destroy() }
     */
    createZoneVisuals(scene, x, y, radius, type, duration) {
        const colors = {
            damage: 0xff4444, heal: 0x44ff88,
            slow: 0x4488ff, buff: 0xffcc44
        };
        const color = colors[type] || 0xffffff;

        const zone = scene.add.circle(x, y, radius, color, 0.08).setDepth(2)
            .setStrokeStyle(1, color, 0.3);

        // Pulse animation
        const pulse = scene.tweens.add({
            targets: zone,
            fillAlpha: 0.15,
            duration: 800,
            yoyo: true, repeat: -1,
            ease: 'Sine.easeInOut'
        });

        return {
            fade(pct) {
                zone.setAlpha(1 - pct);
            },
            destroy() {
                pulse.stop();
                zone.destroy();
            }
        };
    },

    /**
     * Pylon burst — expanding ring.
     */
    pylonBurst(scene, x, y, color, radius) {
        const hexColor = typeof color === 'string'
            ? parseInt(color.replace('#', ''), 16) : (color || 0xffcc44);
        const ring = scene.add.circle(x, y, 4, hexColor, 0.5).setDepth(50);
        scene.tweens.add({
            targets: ring,
            scaleX: radius / 4, scaleY: radius / 4,
            alpha: 0, duration: 400,
            onComplete: () => ring.destroy()
        });
    },

    /**
     * Delayed function call.
     */
    delayedCall(scene, ms, fn) {
        return scene.time.delayedCall(ms, fn);
    },

    /**
     * Repeating timed event.
     * Returns { remove() }
     */
    timedEvent(scene, delay, repeat, fn) {
        const evt = scene.time.addEvent({
            delay, repeat, callback: fn
        });
        return { remove() { evt.destroy(); } };
    },

    /**
     * Audio: heal sound.
     */
    audioHeal() {
        if (typeof AudioManager !== 'undefined' && AudioManager.play) {
            AudioManager.play('heal');
        }
    }
};
