// Vestige GPS — Text Sharpness Patch
// Patches Phaser.Text to render at higher resolution for crisp text
// Client-side only — import once at app startup before any text creation

const _TEXT_RES = 4;
const _OrigText = Phaser.GameObjects.Text;
Phaser.GameObjects.Text = function(scene, x, y, text, style) {
    const s = style || {};
    if (!s.resolution) s.resolution = _TEXT_RES;
    if (!s.fontStyle) s.fontStyle = 'bold';
    _OrigText.call(this, scene, x, y, text, s);
};
Phaser.GameObjects.Text.prototype = _OrigText.prototype;
Phaser.GameObjects.Text.prototype.constructor = Phaser.GameObjects.Text;
