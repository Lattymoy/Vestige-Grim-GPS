// Vestige GPS — CombatRenderer (Phaser)
// All combat visual effects: bullets, muzzle flash, damage numbers, melee swings,
// shield effects, death effects, flair particles
// Wire to core: CombatSystem.init(CombatRenderer)

import { CONFIG } from '../../data/config.js';
import { CombatSystem } from '../../core/combatSystem.js';
import { AudioManager } from '../audioManager.js';
import { GameScene } from '../scenes/GameScene.js';

export const CombatRenderer = {
    // === AUDIO ===
    audioShoot() {
        if (typeof AudioManager !== 'undefined') AudioManager.play('shoot');
    },
    audioMelee() {
        if (typeof AudioManager !== 'undefined') AudioManager.play('melee');
    },
    audioUiClick() {
        if (typeof AudioManager !== 'undefined') AudioManager.play('uiClick');
    },

    // === BULLET CREATION ===
    /**
     * Create a physics-enabled bullet sprite.
     * Returns sprite with custom damage/effect properties.
     */
    createBullet(scene, group, x, y, fxId, fx, angle, speed, opts) {
        if (!group) return null;
        const bullet = scene.physics.add.sprite(x, y, '__DEFAULT');
        bullet.setDisplaySize(3, 3);
        bullet.setDepth(30);

        // Set velocity from angle + speed
        bullet.setVelocity(
            Math.cos(angle) * speed,
            Math.sin(angle) * speed
        );

        // Attach combat properties
        bullet.damage = opts.damage || 0;
        bullet.isCrit = opts.isCrit || false;
        bullet.isRedCrit = opts.isRedCrit || false;
        bullet.didMiss = opts.didMiss || false;
        bullet._fx = opts.fx;
        bullet._sigs = opts.sigs || [];
        bullet._isFirepower = opts.isFirepower || false;
        bullet._isParasitic = opts.isParasitic || false;
        bullet.pierceChance = opts.pierceChance || 0;
        bullet._isDabloonClone = opts.isDabloonClone || false;

        // Visual: colored rectangle matching foundry
        const color = fx ? (fx.bulletColor || fx.primary || 0xffcc44) : 0xffcc44;
        const gfx = scene.add.graphics().setDepth(30);
        const bLen = opts.isCrit ? 5 : 3;
        const bWid = opts.isCrit ? 2 : 1.5;
        gfx.fillStyle(color, opts.isFirepower ? 1 : 0.9);
        gfx.fillRect(-bLen / 2, -bWid / 2, bLen, bWid);
        // Rotate to travel angle
        gfx.setPosition(x, y);
        gfx.setRotation(angle);
        bullet._bulletGfx = gfx;

        // Update gfx position each frame
        bullet._updateGfx = () => {
            if (gfx.active && bullet.active) {
                gfx.setPosition(bullet.x, bullet.y);
            }
        };

        // Auto-destroy after 1.5 seconds
        scene.time.delayedCall(1500, () => {
            if (bullet.active) { bullet.destroy(); gfx.destroy(); }
        });

        // Add to group
        group.add(bullet);

        return bullet;
    },

    // === MUZZLE FLASH ===
    muzzleFlash(scene, x, y, angle, fx, isCrit) {
        const color = fx ? (fx.muzzleColor || fx.primary || 0xffcc44) : 0xffcc44;
        const size = isCrit ? 6 : 4;
        const flash = scene.add.circle(x, y, size, color, 0.7).setDepth(35);
        scene.tweens.add({
            targets: flash,
            scaleX: 0.2, scaleY: 0.2, alpha: 0,
            duration: 80,
            onComplete: () => flash.destroy()
        });

        // Directional muzzle line
        const mx = x + Math.cos(angle) * 6;
        const my = y + Math.sin(angle) * 6;
        const line = scene.add.circle(mx, my, 2, 0xffffff, 0.5).setDepth(35);
        scene.tweens.add({
            targets: line,
            alpha: 0, duration: 60,
            onComplete: () => line.destroy()
        });
    },

    burstMuzzleFlash(scene, x, y, fx) {
        const color = fx ? (fx.primary || 0xffcc44) : 0xffcc44;
        const flash = scene.add.circle(x, y, 3, color, 0.5).setDepth(35);
        scene.tweens.add({
            targets: flash, alpha: 0, scaleX: 0.3, scaleY: 0.3,
            duration: 60,
            onComplete: () => flash.destroy()
        });
    },

    // === PLAYER RECOIL ===
    playerRecoil(scene, player, angle, isCrit) {
        if (!player) return;
        const dist = isCrit ? 3 : 1.5;
        const ox = player.x, oy = player.y;
        scene.tweens.add({
            targets: player,
            x: ox - Math.cos(angle) * dist,
            y: oy - Math.sin(angle) * dist,
            duration: 30, yoyo: true, ease: 'Power1'
        });
    },

    // === CAMERA ===
    cameraShake(scene, duration, intensity) {
        if (scene.cameras && scene.cameras.main) {
            scene.cameras.main.shake(duration, intensity);
        }
    },

    // === TRACER ===
    createTracer(scene, x, y, angle, fx) {
        const color = fx ? (fx.tracerColor || fx.primary || 0xffcc44) : 0xffcc44;
        const len = 12;
        const ex = x + Math.cos(angle) * len;
        const ey = y + Math.sin(angle) * len;
        const gfx = scene.add.graphics().setDepth(29);
        gfx.lineStyle(1, color, 0.4);
        gfx.lineBetween(x, y, ex, ey);
        scene.tweens.add({
            targets: gfx, alpha: 0,
            duration: 120,
            onComplete: () => gfx.destroy()
        });
    },

    // === SPARK ===
    spark(scene, x, y, fromAngle, fx) {
        const color = fx ? (fx.sparkColor || fx.primary || 0xffcc44) : 0xffcc44;
        for (let i = 0; i < 3; i++) {
            const a = fromAngle + (Math.random() - 0.5) * 1.5;
            const d = 4 + Math.random() * 6;
            const s = scene.add.circle(x, y, 1, color, 0.6).setDepth(35);
            scene.tweens.add({
                targets: s,
                x: x + Math.cos(a) * d, y: y + Math.sin(a) * d,
                alpha: 0, duration: 100 + Math.random() * 80,
                onComplete: () => s.destroy()
            });
        }
    },

    // === PERFECT DODGE FLASH ===
    perfectDodgeFlash(scene, x, y) {
        const flash = scene.add.circle(x, y, 6, 0xccddee, 0.6).setDepth(50);
        scene.tweens.add({
            targets: flash,
            scaleX: 2.5, scaleY: 2.5, alpha: 0,
            duration: 200,
            onComplete: () => flash.destroy()
        });
    },

    // === DAMAGE NUMBERS ===
    damageNumber(scene, x, y, text, opts = {}) {
        const t = scene.add.text(x + (Math.random() - 0.5) * 8, y, String(text), {
            fontFamily: 'monospace',
            fontSize: (opts.fontSize || 12) + 'px',
            color: opts.color || '#ff4444',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5, 1).setDepth(100);

        scene.tweens.add({
            targets: t,
            y: y - 16, alpha: 0,
            duration: opts.duration || 400,
            ease: 'Power2',
            onComplete: () => t.destroy()
        });
    },

    // === HIT FEEDBACK ===
    hitFlash(scene, target, color, durationMs) {
        if (!target || !target.active || !target.setTint) return;
        target.setTint(color);
        scene.time.delayedCall(durationMs || 80, () => {
            if (target.active) {
                if (scene._ambientTint && scene._ambientTint !== 0xffffff) {
                    target.setTint(scene._ambientTint);
                } else {
                    target.clearTint();
                }
            }
        });
    },

    impactRing(scene, x, y, source) {
        const color = source === 'redcrit' ? 0xff2222 : source === 'crit' ? 0xffcc00 : 0xffffff;
        const ring = scene.add.circle(x, y, 3, color, 0.4).setDepth(40);
        scene.tweens.add({
            targets: ring,
            scaleX: 3, scaleY: 3, alpha: 0,
            duration: 150,
            onComplete: () => ring.destroy()
        });
    },

    hitStop(scene, enemy, durationMs) {
        if (!enemy || !enemy.active) return;
        const vx = enemy.body ? enemy.body.velocity.x : 0;
        const vy = enemy.body ? enemy.body.velocity.y : 0;
        if (enemy.body) enemy.setVelocity(0, 0);
        scene.time.delayedCall(durationMs, () => {
            if (enemy.active && enemy.body) {
                enemy.setVelocity(vx * 0.5, vy * 0.5);
            }
        });
    },

    // === SHIELD VFX ===
    shieldBlockVFX(scene, enemy) {
        if (!enemy || !enemy.active) return;
        const shield = scene.add.circle(enemy.x, enemy.y, enemy.displayWidth * 0.6, 0x4488ff, 0.2)
            .setDepth(enemy.depth + 1);
        scene.tweens.add({
            targets: shield,
            scaleX: 1.4, scaleY: 1.4, alpha: 0,
            duration: 150,
            onComplete: () => shield.destroy()
        });
    },

    shieldBreakVFX(scene, enemy) {
        if (!enemy || !enemy.active) return;
        // Shatter ring
        const ring = scene.add.circle(enemy.x, enemy.y, 6, 0x4488ff, 0.5)
            .setDepth(enemy.depth + 1);
        scene.tweens.add({
            targets: ring,
            scaleX: 4, scaleY: 4, alpha: 0,
            duration: 250,
            onComplete: () => ring.destroy()
        });
        // Fragments
        for (let i = 0; i < 6; i++) {
            const a = Math.random() * Math.PI * 2;
            const frag = scene.add.rectangle(
                enemy.x, enemy.y, 3, 2, 0x4488ff, 0.6
            ).setDepth(50);
            scene.tweens.add({
                targets: frag,
                x: enemy.x + Math.cos(a) * 15,
                y: enemy.y + Math.sin(a) * 15,
                alpha: 0, angle: Math.random() * 360,
                duration: 300,
                onComplete: () => frag.destroy()
            });
        }
    },

    // === MELEE VFX ===
    meleeSwingVFX(scene, player, angle, mfx, meleeType, mRange) {
        const color = mfx ? (mfx.swingColor || mfx.primary || 0xffcc44) : 0xffcc44;
        const arc = scene.add.graphics().setDepth(35);
        const arcAngle = Math.PI / 3; // 60° swing
        const startA = angle - arcAngle / 2;

        arc.lineStyle(2, color, 0.6);
        arc.beginPath();
        arc.arc(player.x, player.y, mRange * 0.8, startA, startA + arcAngle);
        arc.strokePath();

        scene.tweens.add({
            targets: arc, alpha: 0,
            duration: 120,
            onComplete: () => arc.destroy()
        });
    },

    meleeImpactSparks(scene, player, angle, mfx) {
        const color = mfx ? (mfx.sparkColor || mfx.primary || 0xffaa44) : 0xffaa44;
        const hx = player.x + Math.cos(angle) * 18;
        const hy = player.y + Math.sin(angle) * 18;
        for (let i = 0; i < 4; i++) {
            const sa = angle + (Math.random() - 0.5) * 1.2;
            const sd = 4 + Math.random() * 8;
            const sp = scene.add.circle(hx, hy, 1.5, color, 0.7).setDepth(36);
            scene.tweens.add({
                targets: sp,
                x: hx + Math.cos(sa) * sd, y: hy + Math.sin(sa) * sd,
                alpha: 0, duration: 100 + Math.random() * 60,
                onComplete: () => sp.destroy()
            });
        }
    },

    finisherText(scene, x, y) {
        const t = scene.add.text(x, y - 15, 'FINISH', {
            fontFamily: 'monospace', fontSize: '12px',
            color: '#ff2222', fontStyle: 'bold',
            stroke: '#000000', strokeThickness: 3
        }).setOrigin(0.5, 1).setDepth(100);
        scene.tweens.add({
            targets: t, y: y - 30, alpha: 0, scaleX: 1.3, scaleY: 1.3,
            duration: 500,
            onComplete: () => t.destroy()
        });
    },

    staggerVFX(scene, enemy, durationMs) {
        if (!enemy || !enemy.active) return;
        enemy._staggered = true;
        enemy.setTint(0xffcc44);
        scene.time.delayedCall(durationMs, () => {
            if (enemy.active) {
                enemy._staggered = false;
                if (scene._ambientTint && scene._ambientTint !== 0xffffff) {
                    enemy.setTint(scene._ambientTint);
                } else {
                    enemy.clearTint();
                }
            }
        });
    },

    whirlwindVFX(scene, player, range) {
        if (!player) return;
        const ring = scene.add.circle(player.x, player.y, range, 0xffffff, 0.08)
            .setDepth(34).setStrokeStyle(1.5, 0xffffff, 0.3);
        scene.tweens.add({
            targets: ring,
            scaleX: 1.3, scaleY: 1.3, alpha: 0,
            duration: 250,
            onComplete: () => ring.destroy()
        });
    },

    // === DEATH VFX ===
    cubeShatterVFX(scene, x, y, cfg) {
        const color = cfg ? (cfg.deathColor || 0x884422) : 0x884422;
        const count = 6 + Math.floor(Math.random() * 4);
        for (let i = 0; i < count; i++) {
            const a = Math.random() * Math.PI * 2;
            const d = 5 + Math.random() * 15;
            const size = 1.5 + Math.random() * 2;
            const bit = scene.add.rectangle(x, y, size, size, color, 0.7)
                .setDepth(25).setAngle(Math.random() * 360);
            scene.tweens.add({
                targets: bit,
                x: x + Math.cos(a) * d,
                y: y + Math.sin(a) * d - 4,
                alpha: 0, angle: bit.angle + 180,
                duration: 250 + Math.random() * 150,
                onComplete: () => bit.destroy()
            });
        }
    },

    bloodSquaresVFX(scene, x, y) {
        for (let i = 0; i < 4; i++) {
            const a = Math.random() * Math.PI * 2;
            const d = 3 + Math.random() * 8;
            const sq = scene.add.rectangle(x, y, 2, 2, 0x551010, 0.5).setDepth(25);
            scene.tweens.add({
                targets: sq,
                x: x + Math.cos(a) * d, y: y + Math.sin(a) * d,
                alpha: 0, duration: 200 + Math.random() * 100,
                onComplete: () => sq.destroy()
            });
        }
    },

    bloodStainVFX(scene, x, y) {
        const stain = scene.add.ellipse(
            x + (Math.random() - 0.5) * 4, y + 2,
            6 + Math.random() * 4, 3 + Math.random() * 2,
            0x330808, 0.25
        ).setDepth(1);
        scene.tweens.add({
            targets: stain, alpha: 0,
            duration: 12000, delay: 5000,
            onComplete: () => stain.destroy()
        });
    },

    // === FLOATING TEXT ===
    floatingText(scene, x, y, text, opts = {}) {
        const t = scene.add.text(x, y, text, {
            fontFamily: 'monospace',
            fontSize: (opts.fontSize || 10) + 'px',
            color: opts.color || '#ffffff',
            fontStyle: opts.bold ? 'bold' : '',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5, 1).setDepth(100);
        scene.tweens.add({
            targets: t, y: y - 16, alpha: 0,
            duration: opts.duration || 600, ease: 'Power2',
            onComplete: () => t.destroy()
        });
    },

    // === FLAIR EFFECTS ===
    /**
     * Update foundry flair particle system.
     * Called every frame from GameScene update.
     * Creates ambient particles around equipped weapon.
     */
    updateFlairEffects(scene) {
        if (!scene.player || !scene.player.active) return;
        if (!scene.state || !scene.state.equipment) return;
        const weapon = scene.state.equipment.weapon;
        if (!weapon || !weapon.foundry) return;

        const fx = CONFIG.foundryFX[weapon.foundry];
        if (!fx || !fx.flairColor) return;

        // Throttle: 1 particle per ~6 frames
        if (!scene._flairCounter) scene._flairCounter = 0;
        scene._flairCounter++;
        if (scene._flairCounter % 6 !== 0) return;

        const color = fx.flairColor || fx.primary;
        const px = scene.player.x + (Math.random() - 0.5) * 12;
        const py = scene.player.y + (Math.random() - 0.5) * 8;
        const p = scene.add.circle(px, py, 1, color, 0.3).setDepth(28);
        scene.tweens.add({
            targets: p,
            y: py - 8 - Math.random() * 6,
            alpha: 0, scaleX: 0.3, scaleY: 0.3,
            duration: 400 + Math.random() * 200,
            onComplete: () => p.destroy()
        });
    },

    // === UTILITY ===
    delayedCall(scene, ms, callback) {
        return scene.time.delayedCall(ms, callback);
    },

    lungeTween(scene, player, angle, dist) {
        if (!player) return;
        scene.tweens.add({
            targets: player,
            x: player.x + Math.cos(angle) * dist,
            y: player.y + Math.sin(angle) * dist,
            duration: 60, ease: 'Power2'
        });
    }
};
