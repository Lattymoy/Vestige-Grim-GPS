// Vestige GPS — WallRenderer
// Extracted from monolith L3942-4287

import { IsoRenderer } from '../isoRenderer.js';


export const WallRenderer = {
    
    // ── Steel panels — welded seams, rivet rows, conduit bracket ──
    // Used by: Hub, industrial ops rooms
    steel(g, fx, fy, fw, fh, base, facing) {
        const dk = IsoRenderer.darken(base, 0.20);
        const lt = IsoRenderer.lighten(base, 0.12);
        const isSide = (facing === 'east' || facing === 'west');
        
        if (isSide) {
            // Side walls are narrow — just a vertical seam + 2 rivets
            g.lineStyle(1, dk, 0.4);
            g.beginPath(); g.moveTo(fx + fw/2, fy); g.lineTo(fx + fw/2, fy + fh); g.stroke();
            for (let ry = fy + 30; ry < fy + fh - 20; ry += 60) {
                g.fillStyle(lt, 0.35);
                g.fillCircle(fx + fw/2, ry, 1.5);
            }
            return;
        }
        
        // Front face — vertical panel seams at irregular intervals
        const seams = [0.22, 0.48, 0.73];
        seams.forEach(pct => {
            const sx = fx + fw * pct;
            g.lineStyle(2, dk, 0.45);
            g.beginPath(); g.moveTo(sx, fy); g.lineTo(sx, fy + fh); g.stroke();
            g.lineStyle(1, lt, 0.2);
            g.beginPath(); g.moveTo(sx + 1, fy); g.lineTo(sx + 1, fy + fh); g.stroke();
        });
        
        // Rivet row along top edge
        for (let rx = fx + 8; rx < fx + fw - 5; rx += 18) {
            g.fillStyle(lt, 0.3);
            g.fillCircle(rx, fy + 4, 1.5);
        }
        // Rivet row along bottom edge
        for (let rx = fx + 12; rx < fx + fw - 5; rx += 18) {
            g.fillStyle(dk, 0.25);
            g.fillCircle(rx, fy + fh - 4, 1.5);
        }
        
        // Weld scar between panels
        g.lineStyle(2, lt, 0.15);
        g.beginPath();
        g.moveTo(fx + fw * 0.48, fy + fh * 0.3);
        g.lineTo(fx + fw * 0.48 + 12, fy + fh * 0.32);
        g.stroke();
        
        // Conduit bracket — small rect mounted on wall
        const cbx = fx + fw * 0.85;
        g.fillStyle(dk, 0.3);
        g.fillRect(cbx, fy + fh * 0.2, 8, 4);
        g.lineStyle(1, lt, 0.2);
        g.strokeRect(cbx, fy + fh * 0.2, 8, 4);
    },
    
    // ── Reinforced — heavy joints, blast patches, rebar hints ──
    // Used by: Containment, secure rooms
    reinforced(g, fx, fy, fw, fh, base, facing) {
        const dk = IsoRenderer.darken(base, 0.22);
        const lt = IsoRenderer.lighten(base, 0.10);
        const isSide = (facing === 'east' || facing === 'west');
        
        if (isSide) {
            // Heavy horizontal joint mid-height
            g.lineStyle(2, dk, 0.5);
            g.beginPath(); g.moveTo(fx, fy + fh * 0.5); g.lineTo(fx + fw, fy + fh * 0.5); g.stroke();
            return;
        }
        
        // Horizontal construction joints — heavy dark lines
        g.lineStyle(2, dk, 0.5);
        g.beginPath(); g.moveTo(fx, fy + fh * 0.4); g.lineTo(fx + fw, fy + fh * 0.4); g.stroke();
        g.lineStyle(1, lt, 0.15);
        g.beginPath(); g.moveTo(fx, fy + fh * 0.4 - 1); g.lineTo(fx + fw, fy + fh * 0.4 - 1); g.stroke();
        
        // Blast/repair patch — darker rectangle with bolt corners
        const px = fx + fw * 0.15, py = fy + fh * 0.08;
        const ppw = fw * 0.25, pph = fh * 0.55;
        g.fillStyle(dk, 0.25);
        g.fillRect(px, py, ppw, pph);
        g.lineStyle(1, dk, 0.35);
        g.strokeRect(px, py, ppw, pph);
        // Corner bolts
        [[px + 3, py + 3], [px + ppw - 3, py + 3], [px + 3, py + pph - 3], [px + ppw - 3, py + pph - 3]].forEach(([bx, by]) => {
            g.fillStyle(lt, 0.35);
            g.fillCircle(bx, by, 1.5);
        });
        
        // Rebar shadow hints — short dark dashes where concrete is thin
        for (let i = 0; i < 3; i++) {
            const rx = fx + fw * (0.55 + i * 0.12);
            const ry = fy + fh * 0.65;
            g.lineStyle(2, IsoRenderer.darken(base, 0.12), 0.2);
            g.beginPath(); g.moveTo(rx, ry); g.lineTo(rx, ry + 8); g.stroke();
        }
        
        // Hazard stripe at bottom edge
        g.lineStyle(2, 0xaaaa44, 0.12);
        for (let hx = fx; hx < fx + fw; hx += 12) {
            g.beginPath(); g.moveTo(hx, fy + fh - 2); g.lineTo(hx + 6, fy + fh - 2); g.stroke();
        }
    },
    
    // ── Plaster — smooth with cracks, water stain, baseboard ──
    // Used by: Quarters, residential rooms
    plaster(g, fx, fy, fw, fh, base, facing) {
        const dk = IsoRenderer.darken(base, 0.15);
        const lt = IsoRenderer.lighten(base, 0.08);
        const isSide = (facing === 'east' || facing === 'west');
        
        if (isSide) {
            // Baseboard strip at bottom
            g.fillStyle(dk, 0.35);
            g.fillRect(fx, fy + fh - 4, fw, 4);
            return;
        }
        
        // Baseboard — dark strip along bottom
        g.fillStyle(IsoRenderer.darken(base, 0.20), 0.45);
        g.fillRect(fx, fy + fh - 5, fw, 5);
        g.lineStyle(1, lt, 0.2);
        g.beginPath(); g.moveTo(fx, fy + fh - 5); g.lineTo(fx + fw, fy + fh - 5); g.stroke();
        
        // Hairline cracks — jagged thin lines
        g.lineStyle(1, dk, 0.3);
        const cx1 = fx + fw * 0.35;
        g.beginPath();
        g.moveTo(cx1, fy);
        g.lineTo(cx1 + 3, fy + fh * 0.25);
        g.lineTo(cx1 - 2, fy + fh * 0.45);
        g.lineTo(cx1 + 1, fy + fh * 0.6);
        g.stroke();
        
        // Water damage stain — faint discoloration from above
        g.fillStyle(IsoRenderer.darken(base, 0.08), 0.15);
        g.fillEllipse(fx + fw * 0.7, fy + 4, 30, 10);
        
        // Peeling paint patch
        g.fillStyle(lt, 0.12);
        g.fillRect(fx + fw * 0.55, fy + fh * 0.3, 14, 8);
        g.lineStyle(1, dk, 0.15);
        g.beginPath();
        g.moveTo(fx + fw * 0.55, fy + fh * 0.3 + 8);
        g.lineTo(fx + fw * 0.55 + 7, fy + fh * 0.3 + 10);
        g.stroke();
    },
    
    // ── Concrete — form tie holes, cold joint, aggregate texture ──
    // Used by: Barracks, utility rooms, bunkers
    concrete(g, fx, fy, fw, fh, base, facing) {
        const dk = IsoRenderer.darken(base, 0.18);
        const lt = IsoRenderer.lighten(base, 0.08);
        const isSide = (facing === 'east' || facing === 'west');
        
        if (isSide) {
            // Form tie hole
            g.fillStyle(dk, 0.4);
            g.fillCircle(fx + fw/2, fy + fh * 0.3, 2);
            g.fillCircle(fx + fw/2, fy + fh * 0.7, 2);
            return;
        }
        
        // Cold joint — horizontal line where pours met
        g.lineStyle(2, dk, 0.4);
        g.beginPath(); g.moveTo(fx, fy + fh * 0.55); g.lineTo(fx + fw, fy + fh * 0.55); g.stroke();
        
        // Form tie holes — circular indents in a row
        for (let tx = fx + 20; tx < fx + fw - 10; tx += 40) {
            g.fillStyle(dk, 0.4);
            g.fillCircle(tx, fy + fh * 0.25, 2.5);
            g.lineStyle(1, lt, 0.15);
            g.strokeCircle(tx, fy + fh * 0.25, 2.5);
        }
        // Second row below cold joint
        for (let tx = fx + 35; tx < fx + fw - 10; tx += 40) {
            g.fillStyle(dk, 0.35);
            g.fillCircle(tx, fy + fh * 0.75, 2.5);
        }
        
        // Aggregate speckling — tiny dots
        for (let i = 0; i < 8; i++) {
            const ax = fx + 10 + Math.random() * (fw - 20);
            const ay = fy + 3 + Math.random() * (fh - 6);
            g.fillStyle(lt, 0.12);
            g.fillCircle(ax, ay, 0.8);
        }
        
        // Stain drip from top
        g.lineStyle(1, dk, 0.15);
        g.beginPath();
        g.moveTo(fx + fw * 0.8, fy);
        g.lineTo(fx + fw * 0.8 + 2, fy + fh * 0.35);
        g.stroke();
    },
    
    // ── Cinderblock — visible block grid with mortar lines ──
    // Used by: Garage, storage, industrial
    cinderblock(g, fx, fy, fw, fh, base, facing) {
        const dk = IsoRenderer.darken(base, 0.16);
        const lt = IsoRenderer.lighten(base, 0.06);
        const isSide = (facing === 'east' || facing === 'west');
        
        const blockH = 8;
        const blockW = isSide ? fw : 16;
        
        if (isSide) {
            // Side view — just horizontal mortar lines
            g.lineStyle(1, dk, 0.3);
            for (let by = fy + blockH; by < fy + fh; by += blockH) {
                g.beginPath(); g.moveTo(fx, by); g.lineTo(fx + fw, by); g.stroke();
            }
            return;
        }
        
        // Horizontal mortar lines
        g.lineStyle(1, dk, 0.35);
        for (let by = fy + blockH; by < fy + fh; by += blockH) {
            g.beginPath(); g.moveTo(fx, by); g.lineTo(fx + fw, by); g.stroke();
        }
        
        // Vertical mortar — staggered per row (real brick pattern)
        let row = 0;
        for (let by = fy; by < fy + fh; by += blockH) {
            const offset = (row % 2 === 0) ? 0 : blockW / 2;
            g.lineStyle(1, dk, 0.3);
            for (let bx = fx + offset + blockW; bx < fx + fw; bx += blockW) {
                g.beginPath(); g.moveTo(bx, by); g.lineTo(bx, by + blockH); g.stroke();
            }
            row++;
        }
        
        // A couple blocks with different shade (replaced/patched blocks)
        g.fillStyle(lt, 0.12);
        g.fillRect(fx + blockW * 2, fy + blockH, blockW - 1, blockH - 1);
        g.fillStyle(dk, 0.1);
        g.fillRect(fx + blockW * 4 + blockW/2, fy + blockH * 2, blockW - 1, blockH - 1);
        
        // Mortar smear
        g.fillStyle(lt, 0.08);
        g.fillEllipse(fx + fw * 0.6, fy + fh * 0.7, 12, 4);
    },
    
    // ── Bare/stripped — exposed studs, wire stubs, mounting holes ──
    // Used by: Armory, stripped/gutted rooms
    bare(g, fx, fy, fw, fh, base, facing) {
        const dk = IsoRenderer.darken(base, 0.18);
        const lt = IsoRenderer.lighten(base, 0.10);
        const isSide = (facing === 'east' || facing === 'west');
        
        if (isSide) {
            // Exposed stud line
            g.lineStyle(1, dk, 0.35);
            g.beginPath(); g.moveTo(fx + fw/2, fy); g.lineTo(fx + fw/2, fy + fh); g.stroke();
            return;
        }
        
        // Stud marks — vertical lines at regular intervals (framing behind)
        g.lineStyle(1, dk, 0.2);
        for (let sx = fx + 24; sx < fx + fw - 10; sx += 28) {
            g.beginPath(); g.moveTo(sx, fy); g.lineTo(sx, fy + fh); g.stroke();
        }
        
        // Mounting holes — where things used to hang
        const holes = [[0.2, 0.3], [0.45, 0.25], [0.7, 0.35], [0.85, 0.5]];
        holes.forEach(([hx, hy]) => {
            g.fillStyle(dk, 0.5);
            g.fillCircle(fx + fw * hx, fy + fh * hy, 2);
            // Shadow below hole
            g.fillStyle(dk, 0.15);
            g.fillRect(fx + fw * hx - 1, fy + fh * hy + 2, 2, 3);
        });
        
        // Wire stubs — short horizontal lines poking out
        g.lineStyle(2, IsoRenderer.darken(base, 0.10), 0.25);
        g.beginPath(); g.moveTo(fx + fw * 0.3, fy + fh * 0.6); g.lineTo(fx + fw * 0.3 + 8, fy + fh * 0.62); g.stroke();
        g.lineStyle(1, 0x884422, 0.15);
        g.beginPath(); g.moveTo(fx + fw * 0.3 + 8, fy + fh * 0.62); g.lineTo(fx + fw * 0.3 + 12, fy + fh * 0.65); g.stroke();
        
        // Scrape marks where equipment was removed
        g.lineStyle(1, lt, 0.15);
        g.beginPath(); g.moveTo(fx + fw * 0.5, fy + fh * 0.7); g.lineTo(fx + fw * 0.65, fy + fh * 0.68); g.stroke();
        g.beginPath(); g.moveTo(fx + fw * 0.52, fy + fh * 0.75); g.lineTo(fx + fw * 0.62, fy + fh * 0.73); g.stroke();
    },
    
    // ── Cubesim — dark panels with circuit traces, data lines, cyan accents ──
    // Used by: Neural interface / simulation chamber
    cubesim(g, fx, fy, fw, fh, base, facing) {
        const dk = IsoRenderer.darken(base, 0.25);
        const lt = IsoRenderer.lighten(base, 0.15);
        const cyan = 0x44aacc;
        const isSide = (facing === 'east' || facing === 'west');
        
        if (isSide) {
            // Vertical data trace — thin glowing line
            g.lineStyle(1, cyan, 0.12);
            g.beginPath(); g.moveTo(fx + fw/2, fy + 4); g.lineTo(fx + fw/2, fy + fh - 4); g.stroke();
            // Node dots along trace
            for (let ny = fy + 12; ny < fy + fh - 8; ny += 20) {
                g.fillStyle(cyan, 0.18);
                g.fillCircle(fx + fw/2, ny, 1);
            }
            return;
        }
        
        // Dark panel border lines (recessed panels)
        g.lineStyle(1, dk, 0.5);
        g.strokeRect(fx + 3, fy + 3, fw - 6, fh - 6);
        
        // Circuit traces — thin horizontal/vertical lines with right angles
        g.lineStyle(1, cyan, 0.08);
        // Trace 1: left side
        g.beginPath();
        g.moveTo(fx + 6, fy + fh * 0.3);
        g.lineTo(fx + fw * 0.3, fy + fh * 0.3);
        g.lineTo(fx + fw * 0.3, fy + fh * 0.6);
        g.lineTo(fx + fw * 0.15, fy + fh * 0.6);
        g.stroke();
        // Trace 2: right side
        g.beginPath();
        g.moveTo(fx + fw - 6, fy + fh * 0.2);
        g.lineTo(fx + fw * 0.65, fy + fh * 0.2);
        g.lineTo(fx + fw * 0.65, fy + fh * 0.5);
        g.lineTo(fx + fw * 0.8, fy + fh * 0.5);
        g.lineTo(fx + fw * 0.8, fy + fh * 0.8);
        g.stroke();
        
        // Node dots at trace junctions
        [[fw*0.3, fh*0.3], [fw*0.3, fh*0.6], [fw*0.65, fh*0.2], [fw*0.65, fh*0.5], [fw*0.8, fh*0.5]].forEach(([nx, ny]) => {
            g.fillStyle(cyan, 0.2);
            g.fillCircle(fx + nx, fy + ny, 1.5);
        });
        
        // Data hash marks — short dashes along bottom
        g.lineStyle(1, lt, 0.15);
        for (let hx = fx + 8; hx < fx + fw - 8; hx += 6) {
            g.beginPath(); g.moveTo(hx, fy + fh - 5); g.lineTo(hx + 3, fy + fh - 5); g.stroke();
        }
        
        // Recessed display window (dark inset rectangle)
        g.fillStyle(0x060610, 0.5);
        g.fillRect(fx + fw * 0.1, fy + fh * 0.15, fw * 0.35, fh * 0.3);
        g.lineStyle(1, cyan, 0.1);
        g.strokeRect(fx + fw * 0.1, fy + fh * 0.15, fw * 0.35, fh * 0.3);
    },
};

