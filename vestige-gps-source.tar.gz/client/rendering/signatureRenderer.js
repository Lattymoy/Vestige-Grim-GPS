// Vestige GPS — SignatureRenderer (Phaser)
// VFX for weapon signature abilities
// Wire to core: SignatureEffects.init(SignatureRenderer)
import { SignatureEffects } from '../../core/signatureEffects.js';

export const SignatureRenderer = {
    /**
     * Floating text above a position.
     */
    floatingText(scene, x, y, text, opts = {}) {
        const t = scene.add.text(x, y, text, {
            fontFamily: 'monospace',
            fontSize: (opts.fontSize || 10) + 'px',
            color: opts.color || '#ffffff',
            fontStyle: opts.bold ? 'bold' : '',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5, 1).setDepth(100);

        scene.tweens.add({
            targets: t,
            y: y - 18,
            alpha: 0,
            duration: opts.duration || 600,
            ease: 'Power2',
            onComplete: () => t.destroy()
        });
    },

    /**
     * Delayed function call via scene timer.
     */
    delayedCall(scene, ms, callback) {
        return scene.time.delayedCall(ms, callback);
    },

    /**
     * Ricochet tracer line between two points.
     */
    ricochetTracer(scene, x1, y1, x2, y2) {
        const gfx = scene.add.graphics().setDepth(50);
        gfx.lineStyle(1.5, 0xffcc44, 0.7);
        gfx.lineBetween(x1, y1, x2, y2);

        // Spark at impact
        const spark = scene.add.circle(x2, y2, 3, 0xffdd66, 0.8).setDepth(50);

        scene.tweens.add({
            targets: [gfx, spark],
            alpha: 0,
            duration: 200,
            onComplete: () => { gfx.destroy(); spark.destroy(); }
        });
    },

    /**
     * Shackle chain VFX — chains radiate from center, enemies get tinted.
     * affected: array of enemy sprites that are staggered
     */
    shackleVFX(scene, cx, cy, radius, affected, duration) {
        // Central pulse
        const pulse = scene.add.circle(cx, cy, 4, 0xffaa22, 0.8).setDepth(50);
        scene.tweens.add({
            targets: pulse,
            scaleX: radius / 4, scaleY: radius / 4,
            alpha: 0,
            duration: 300,
            onComplete: () => pulse.destroy()
        });

        // Chain lines to each affected enemy
        affected.forEach(enemy => {
            if (!enemy.active) return;
            const chain = scene.add.graphics().setDepth(49);
            chain.lineStyle(1, 0xffaa22, 0.6);
            chain.lineBetween(cx, cy, enemy.x, enemy.y);

            // Tint enemy
            enemy.setTint(0xffaa22);

            scene.tweens.add({
                targets: chain,
                alpha: 0,
                duration: duration * 0.8,
                onComplete: () => chain.destroy()
            });
        });

        // Clear stagger + tint after duration
        scene.time.delayedCall(duration, () => {
            affected.forEach(e => {
                if (e.active) {
                    e._staggered = false;
                    if (scene._ambientTint && scene._ambientTint !== 0xffffff) {
                        e.setTint(scene._ambientTint);
                    } else {
                        e.clearTint();
                    }
                }
            });
        });
    },

    /**
     * Phase shift visual — player goes semi-transparent.
     */
    phaseShiftVisual(scene, duration) {
        if (!scene.player) return;
        scene.player.setAlpha(0.35);
        scene._phantomInvis = true;

        // Ghostly trail effect
        const trailEvt = scene.time.addEvent({
            delay: 80,
            loop: true,
            callback: () => {
                if (!scene._phantomInvis || !scene.player.active) return;
                const ghost = scene.add.circle(
                    scene.player.x, scene.player.y, 6,
                    0x8844cc, 0.15
                ).setDepth(scene.player.depth - 1);
                scene.tweens.add({
                    targets: ghost,
                    alpha: 0, scaleX: 0.3, scaleY: 0.3,
                    duration: 300,
                    onComplete: () => ghost.destroy()
                });
            }
        });

        scene.time.delayedCall(duration, () => {
            trailEvt.destroy();
            scene._phantomInvis = false;
            if (scene.player.active) scene.player.setAlpha(1);
        });
    },

    /**
     * Healing cube — autonomous visual entity with logic callbacks.
     * opts: { maxHeal, getPlayerPos(), heal(amount), findNearestEnemy(x,y,range), damageEnemy(enemy,dmg) }
     */
    healingCubeSpawn(scene, x, y, opts) {
        const cube = scene.add.graphics().setDepth(30);
        const cubeSize = 6;
        let healed = 0;
        let cubeX = x, cubeY = y;
        const lifetime = 8000;
        const spawnTime = scene.time.now;

        // Orbit and pulse
        const updateEvt = scene.time.addEvent({
            delay: 50,
            loop: true,
            callback: () => {
                const age = (scene.time.now - spawnTime) / lifetime;
                if (age >= 1 || healed >= opts.maxHeal) {
                    updateEvt.destroy();
                    cube.destroy();
                    return;
                }

                // Float toward player
                const pp = opts.getPlayerPos();
                const dx = pp.x - cubeX, dy = pp.y - cubeY;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist > 30) {
                    cubeX += (dx / dist) * 1.5;
                    cubeY += (dy / dist) * 1.5;
                }

                // Heal when close
                if (dist < 35) {
                    const tick = opts.heal(2);
                    healed += tick;
                }

                // Attack nearby enemies
                const target = opts.findNearestEnemy(cubeX, cubeY, 50);
                if (target && Math.random() < 0.1) {
                    opts.damageEnemy(target, 3);
                }

                // Draw cube
                cube.clear();
                const t = scene.time.now * 0.003;
                const bob = Math.sin(t * 2) * 3;
                const fade = age < 0.8 ? 1 : (1 - age) / 0.2;

                // Inner glow
                cube.fillStyle(0x44ffaa, 0.3 * fade);
                cube.fillCircle(cubeX, cubeY + bob, cubeSize * 1.5);

                // Cube body
                cube.fillStyle(0x22cc88, 0.7 * fade);
                cube.fillRect(cubeX - cubeSize / 2, cubeY + bob - cubeSize / 2, cubeSize, cubeSize);

                // Highlight edge
                cube.fillStyle(0x66ffcc, 0.5 * fade);
                cube.fillRect(cubeX - cubeSize / 2, cubeY + bob - cubeSize / 2, cubeSize, 1);
                cube.fillRect(cubeX - cubeSize / 2, cubeY + bob - cubeSize / 2, 1, cubeSize);
            }
        });

        return () => { updateEvt.destroy(); cube.destroy(); };
    }
};
