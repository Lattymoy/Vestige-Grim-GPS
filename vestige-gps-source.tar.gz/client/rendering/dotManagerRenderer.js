// Vestige GPS — DOTManagerRenderer (Phaser)
// Renders debuff icons above enemies, flash tints, floating damage
// Wire to core: DOTManager.init(DOTManagerRenderer)
import { DOTManager } from '../../core/dotManager.js';

export const DOTManagerRenderer = {
    /**
     * Brief tint flash on a sprite (damage feedback).
     * color: hex number (e.g. 0xff4444)
     * durationMs: flash duration
     */
    flashTint(scene, target, color, durationMs) {
        if (!target || !target.active || !target.setTint) return;
        const hexColor = typeof color === 'string'
            ? parseInt(color.replace('#', ''), 16)
            : color;
        target.setTint(hexColor);
        scene.time.delayedCall(durationMs || 80, () => {
            if (target.active) {
                // Restore ambient tint if available, else clear
                if (scene._ambientTint && scene._ambientTint !== 0xffffff) {
                    target.setTint(scene._ambientTint);
                } else {
                    target.clearTint();
                }
            }
        });
    },

    /**
     * Show floating damage number above a target.
     * dmg: number, color: hex string like '#ff4444'
     */
    floatingDamage(scene, target, dmg, color) {
        if (!target || !target.active) return;
        const x = target.x + (Math.random() - 0.5) * 10;
        const y = target.y - (target.displayHeight || 16) - 4;
        const text = scene.add.text(x, y, `-${dmg}`, {
            fontFamily: 'monospace',
            fontSize: '9px',
            color: color || '#ff4444',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5, 1).setDepth(100);

        scene.tweens.add({
            targets: text,
            y: y - 12,
            alpha: 0,
            duration: 500,
            ease: 'Power2',
            onComplete: () => text.destroy()
        });
    },

    /**
     * Clear debuff icon sprites from a target.
     */
    clearIcons(target) {
        if (!target) return;
        if (target._dotIcons) {
            target._dotIcons.forEach(icon => {
                if (icon && icon.destroy) icon.destroy();
            });
            target._dotIcons = [];
        }
    },

    /**
     * Render debuff type icons above a target.
     * dots: array of { type, color, ... }
     */
    renderDebuffIcons(scene, target, dots) {
        if (!target || !target.active || !dots || dots.length === 0) return;

        // Clear existing
        DOTManagerRenderer.clearIcons(target);
        target._dotIcons = [];

        const iconSize = 4;
        const spacing = 6;
        const startX = target.x - ((dots.length - 1) * spacing) / 2;
        const baseY = target.y - (target.displayHeight || 16) - 8;

        const dotColors = {
            bleed: 0xcc2222,
            burn: 0xff6622,
            toxic: 0x44aa33,
            shock: 0x4488ff,
            slow: 0x8866cc
        };

        dots.forEach((dot, i) => {
            const color = dotColors[dot.type] || 0xffffff;
            const icon = scene.add.circle(
                startX + i * spacing, baseY,
                iconSize / 2, color, 0.8
            ).setDepth(100).setStrokeStyle(1, 0x000000, 0.5);
            target._dotIcons.push(icon);

            // Pulse animation
            scene.tweens.add({
                targets: icon,
                scaleX: 1.3, scaleY: 1.3,
                alpha: 0.5,
                duration: 400,
                yoyo: true,
                repeat: -1,
                ease: 'Sine.easeInOut'
            });
        });

        // Attach position updater
        target._dotIconUpdate = () => {
            if (!target.active || !target._dotIcons) return;
            const sx = target.x - ((target._dotIcons.length - 1) * spacing) / 2;
            const sy = target.y - (target.displayHeight || 16) - 8;
            target._dotIcons.forEach((icon, i) => {
                if (icon.active) icon.setPosition(sx + i * spacing, sy);
            });
        };
    }
};
