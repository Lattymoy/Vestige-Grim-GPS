// Vestige GPS — AttackVFX
// Extracted from monolith L17882-18161

export const AttackVFX = {
    // Intensity profiles — scaled by threat tier
    _profiles: {
        light:  { hitstop: 30,  particles: 6,  sweepLen: 18, sweepWidth: 3, particleSpeed: 100, particleSize: 3   },
        medium: { hitstop: 45,  particles: 10, sweepLen: 24, sweepWidth: 4, particleSpeed: 140, particleSize: 3.5 },
        heavy:  { hitstop: 60,  particles: 15, sweepLen: 30, sweepWidth: 5, particleSpeed: 180, particleSize: 4   },
        acid:   { hitstop: 25,  particles: 10, sweepLen: 16, sweepWidth: 3, particleSpeed: 80,  particleSize: 3   }
    },
    
    _hitstopActive: false,
    
    // === GENERIC VFX — play at position with weight ===
    play(scene, x, y, angle, weight = 'medium') {
        if (!scene) return;
        const p = this._profiles[weight] || this._profiles.medium;
        const color1 = 0xffcc44, color2 = 0xffffff, particleColor = 0xffaa22;
        this._doHitstop(scene, p.hitstop);
        this._animatedSlash(scene, x, y, angle, color1, color2, p);
        this._spawnParticles(scene, x, y, angle, particleColor, color2, p, 'slash');
    },

    // === MAIN ENTRY POINT ===
    enemyHitFlash(scene, enemy, player) {
        if (!scene || !player || !player.active) return;
        const angle = Phaser.Math.Angle.Between(enemy.x, enemy.y, player.x, player.y);
        const type = enemy.enemyType || 'default';
        const x = player.x, y = player.y;
        
        let profile, color1, color2, particleColor, style;
        if (type === 'flicker' || type === 'flicker_attack') {
            profile = this._profiles.medium;
            color1 = 0xaa55ee; color2 = 0xeeccff; particleColor = 0xdd88ff;
            style = 'slash';
        } else if (type === 'flicker_maimed') {
            profile = this._profiles.acid;
            color1 = 0x44cc33; color2 = 0xaaffaa; particleColor = 0x66ee44;
            style = 'acid';
        } else if (type === 'deadlock') {
            profile = this._profiles.heavy;
            color1 = 0xffaa44; color2 = 0xffeedd; particleColor = 0xffcc66;
            style = 'slam';
        } else if (type === 'husk' || type === 'husk_stumble' || type === 'husk_crawl') {
            profile = this._profiles.light;
            color1 = 0xbb6633; color2 = 0xffcc88; particleColor = 0xcc4422;
            style = 'slash';
        } else {
            profile = this._profiles.light;
            color1 = 0xbbbbbb; color2 = 0xffffff; particleColor = 0xdddddd;
            style = 'slash';
        }
        
        // 1. HITSTOP
        this._doHitstop(scene, profile.hitstop);
        
        // 2. ANIMATED SWEEP
        if (style === 'slam') {
            this._animatedSlam(scene, x, y, angle, color1, color2, profile);
        } else if (style === 'acid') {
            this._animatedAcid(scene, x, y, color1, color2, profile);
        } else {
            this._animatedSlash(scene, x, y, angle, color1, color2, profile);
        }
        
        // 3. PARTICLES
        this._spawnParticles(scene, x, y, angle, particleColor, color2, profile, style);
    },
    
    // === 1. HITSTOP ===
    _doHitstop(scene, durationMs) {
        if (this._hitstopActive || durationMs <= 0) return;
        this._hitstopActive = true;
        
        if (scene.physics && scene.physics.world) {
            scene.physics.world.pause();
        }
        scene.tweens.pauseAll();
        
        scene.time.delayedCall(durationMs, () => {
            if (scene.physics && scene.physics.world) {
                scene.physics.world.resume();
            }
            scene.tweens.resumeAll();
            this._hitstopActive = false;
        });
    },
    
    // === 2a. ANIMATED SLASH ===
    // Arc sweeps ACROSS the player from the enemy's attack direction.
    // Centered on `angle` (enemy→player), so the arc visually comes FROM the attacker.
    _animatedSlash(scene, x, y, angle, color1, color2, p) {
        const g = scene.add.graphics().setDepth(40);
        // Arc perpendicular to attack angle — sweeps across the hit point
        const sweepStart = angle - Math.PI / 2 - 0.3;
        const sweepEnd = angle + Math.PI / 2 + 0.3;
        // Offset the arc center slightly toward the attacker so it reads as incoming
        const cx = x - Math.cos(angle) * (p.sweepLen * 0.25);
        const cy = y - Math.sin(angle) * (p.sweepLen * 0.25);
        
        let progress = 0;
        const dur = 100;
        const fadeDur = 280;
        
        const timer = scene.time.addEvent({
            delay: 16, loop: true,
            callback: () => {
                progress += 16;
                const t = Math.min(1, progress / dur);
                const et = 1 - Math.pow(1 - t, 3);
                
                g.clear();
                
                const currentEnd = sweepStart + (sweepEnd - sweepStart) * et;
                const steps = Math.floor(18 * et) + 3;
                const radius = p.sweepLen * (0.6 + 0.4 * et);
                
                for (let s = 0; s < steps; s++) {
                    const frac = s / steps;
                    const a = sweepStart + (currentEnd - sweepStart) * frac;
                    const px = cx + Math.cos(a) * radius;
                    const py = cy + Math.sin(a) * radius;
                    // Thicker in the middle of the arc, tapers at ends
                    const widthMult = Math.sin(frac * Math.PI);
                    const w = p.sweepWidth * widthMult * (0.5 + 0.5 * et);
                    
                    if (w < 0.3) continue;
                    // Outer color
                    g.fillStyle(color1, 0.9 * (1 - frac * 0.15));
                    g.fillCircle(px, py, w + 1.5);
                    // White-hot core
                    g.fillStyle(color2, 0.95 * (1 - frac * 0.3));
                    g.fillCircle(px, py, w * 0.45 + 0.5);
                }
                
                if (progress >= dur) {
                    timer.remove();
                    let fadeP = 0;
                    const fadeTimer = scene.time.addEvent({
                        delay: 16, loop: true,
                        callback: () => {
                            fadeP += 16;
                            g.setAlpha(1 - fadeP / fadeDur);
                            if (fadeP >= fadeDur) { g.destroy(); fadeTimer.remove(); }
                        }
                    });
                }
            }
        });
    },
    
    // === 2b. ANIMATED SLAM — expanding shockwave ring ===
    _animatedSlam(scene, x, y, angle, color1, color2, p) {
        const g = scene.add.graphics().setDepth(40);
        let progress = 0;
        const dur = 180;
        const fadeDur = 350;
        
        const timer = scene.time.addEvent({
            delay: 16, loop: true,
            callback: () => {
                progress += 16;
                const t = Math.min(1, progress / dur);
                const et = 1 - Math.pow(1 - t, 2);
                g.clear();
                
                const radius = 5 + et * 22;
                const ringW = (1 - et * 0.4) * p.sweepWidth;
                
                g.lineStyle(ringW, color1, 0.85 * (1 - et * 0.3));
                g.strokeCircle(x, y, radius);
                g.lineStyle(1.5, color2, 0.95 * (1 - et * 0.4));
                g.strokeCircle(x, y, radius * 0.85);
                
                for (let i = 0; i < 8; i++) {
                    const a = (i / 8) * Math.PI * 2 + 0.2;
                    const crackLen = et * 16;
                    g.lineStyle(2, color1, 0.7 * (1 - et * 0.5));
                    g.beginPath();
                    g.moveTo(x + Math.cos(a) * 4, y + Math.sin(a) * 4);
                    g.lineTo(x + Math.cos(a) * (4 + crackLen), y + Math.sin(a) * (4 + crackLen));
                    g.strokePath();
                }
                
                if (progress >= dur) {
                    timer.remove();
                    let fadeP = 0;
                    const fadeTimer = scene.time.addEvent({
                        delay: 16, loop: true,
                        callback: () => {
                            fadeP += 16;
                            g.setAlpha(1 - fadeP / fadeDur);
                            if (fadeP >= fadeDur) { g.destroy(); fadeTimer.remove(); }
                        }
                    });
                }
            }
        });
    },
    
    // === 2c. ANIMATED ACID — toxic splatter burst ===
    _animatedAcid(scene, x, y, color1, color2, p) {
        const g = scene.add.graphics().setDepth(40);
        let progress = 0;
        const dur = 100;
        
        const timer = scene.time.addEvent({
            delay: 16, loop: true,
            callback: () => {
                progress += 16;
                const t = Math.min(1, progress / dur);
                const et = 1 - Math.pow(1 - t, 3);
                g.clear();
                
                const r = 4 + et * 10;
                g.fillStyle(color1, 0.65 * (1 - t * 0.2));
                g.fillCircle(x, y, r);
                g.fillStyle(color2, 0.55 * (1 - t * 0.3));
                g.fillCircle(x, y, r * 0.55);
                
                for (let i = 0; i < 6; i++) {
                    const a = (i / 6) * Math.PI * 2 + 0.4;
                    const tr = et * (8 + (i % 3) * 4);
                    g.fillStyle(color1, 0.5 * (1 - t * 0.3));
                    g.fillEllipse(x + Math.cos(a) * tr, y + Math.sin(a) * tr, 4 * (1 - t * 0.3), 3 * (1 - t * 0.3));
                }
                
                if (progress >= dur) {
                    timer.remove();
                    let fadeP = 0;
                    const fadeTimer = scene.time.addEvent({
                        delay: 16, loop: true,
                        callback: () => {
                            fadeP += 16;
                            g.setAlpha(1 - fadeP / 400);
                            if (fadeP >= 400) { g.destroy(); fadeTimer.remove(); }
                        }
                    });
                }
            }
        });
    },
    
    // === 3. PARTICLE BURST ===
    _spawnParticles(scene, x, y, angle, color, coreColor, p, style) {
        // Acid has its own splatter tendrils — no square particles
        if (style === 'acid') return;
        
        const fromAngle = angle + Math.PI; // fly away from attacker
        const count = p.particles;
        
        for (let i = 0; i < count; i++) {
            const spread = style === 'slam' ? Math.PI * 2 : 1.6;
            const pAngle = fromAngle + (Math.random() - 0.5) * spread;
            const speed = p.particleSpeed * (0.4 + Math.random());
            const size = p.particleSize * (0.7 + Math.random() * 0.6) * 0.5;
            const isCore = Math.random() < 0.35;
            
            const pColor = isCore ? coreColor : color;
            const particle = scene.add.circle(x, y, size, pColor, 1.0).setDepth(41);
            
            const vx = Math.cos(pAngle) * speed;
            const vy = Math.sin(pAngle) * speed;
            const lifetime = 250 + Math.random() * 250;
            
            let elapsed = 0;
            const pTimer = scene.time.addEvent({
                delay: 16, loop: true,
                callback: () => {
                    elapsed += 16;
                    const t = elapsed / lifetime;
                    if (t >= 1) { particle.destroy(); pTimer.remove(); return; }
                    const decel = 1 - t * 0.7;
                    particle.x += vx * 0.016 * decel;
                    particle.y += vy * 0.016 * decel + t * 2.0;
                    particle.setAlpha(1 - t * t);
                    particle.setScale(1 - t * 0.4);
                }
            });
        }
    }
};

