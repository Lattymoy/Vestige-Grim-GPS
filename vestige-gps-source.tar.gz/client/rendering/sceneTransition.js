// Vestige GPS — SceneTransition (Rendering)
// Camera fades and scene cleanup — client-side only
// Game logic (state packaging) is in core/sceneTransition.js

import { DOTManager } from '../../core/dotManager.js';
import { DOTSystem } from '../../core/dotSystem.js';
import { SignatureEffects } from '../../core/signatureEffects.js';
import { ObjectPool } from './objectPool.js';
import { SceneTransition } from '../../core/sceneTransition.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { InteractHighlight } from '../interactHighlight.js';
import { PlayerStatusIcons } from '../ui/playerStatusIcons.js';
import { OcclusionManager } from './occlusionManager.js';
import { TelegraphSystem } from './telegraphSystem.js';

export const SceneTransitionRenderer = {
    fadeTo(scene, targetScene, data, opts = {}) {
        const duration = opts.duration || 400;
        const color = opts.color || { r: 0, g: 0, b: 0 };
        
        scene.cameras.main.fade(duration, color.r, color.g, color.b);
        scene.time.delayedCall(duration, () => {
            // Cleanup rendering systems
            ObjectPool.destroyScene(scene.scene.key);
            if (typeof OcclusionManager !== 'undefined') OcclusionManager.destroy(scene);
            if (typeof InteractHighlight !== 'undefined') InteractHighlight.destroy(scene);
            if (typeof DynamicShadows !== 'undefined') DynamicShadows.destroy(scene);
            if (typeof TelegraphSystem !== 'undefined') TelegraphSystem.cancelAll();
            if (typeof PlayerStatusIcons !== 'undefined') PlayerStatusIcons.reset();
            
            // Cleanup core systems
            DOTManager.reset();
            DOTSystem.clearPlayer();
            SignatureEffects.reset();
            
            scene.scene.start(targetScene, data);
        });
    },
    
    fadeIn(scene, duration) {
        scene.cameras.main.fadeIn(duration || 400);
    }
};
