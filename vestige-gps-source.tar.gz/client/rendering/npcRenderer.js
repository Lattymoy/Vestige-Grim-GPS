// Vestige GPS — NPCRenderer (Phaser)
// Renders NPC sprites, walk animations, shadows
// Wire to core: NPCManager.init(NPCRenderer)

import { CONFIG } from '../../data/config.js';
import { NPCManager } from '../../core/npcManager.js';

export const NPCRenderer = {
    /**
     * Create an NPC sprite from a preset definition.
     * preset: { textureKey, frameWidth, frameHeight, scale, anims, ... }
     * Returns a Phaser.GameObjects.Sprite
     */
    createNPCSprite(scene, x, y, preset) {
        if (!preset) return null;
        const key = preset.textureKey || preset.id || 'npc_default';

        // Build spritesheet texture if not already present
        if (!scene.textures.exists(key) && preset.pixelData) {
            const size = preset.frameWidth || 16;
            const frames = preset.pixelData.length || 1;
            const canvas = document.createElement('canvas');
            canvas.width = size * frames;
            canvas.height = preset.frameHeight || size;
            const ctx = canvas.getContext('2d');
            // pixelData is array of frames, each frame is array of {x,y,color} or a draw function
            if (typeof preset.draw === 'function') {
                preset.draw(ctx, size);
            }
            scene.textures.addCanvas(key, canvas);
        }

        const sprite = scene.add.sprite(x, y, key, 0);
        const scale = preset.scale || 1;
        sprite.setScale(scale);
        sprite.setOrigin(0.5, 1); // base-center

        // Register walk animations if defined
        if (preset.anims && !scene.anims.exists(key + '_walk_0')) {
            const dirs = ['down', 'up', 'left', 'right'];
            const framesPerDir = preset.anims.framesPerDir || 3;
            for (let d = 0; d < 4; d++) {
                const animKey = `${key}_walk_${d}`;
                if (!scene.anims.exists(animKey)) {
                    const startFrame = d * framesPerDir;
                    const frames = [];
                    for (let f = 0; f < framesPerDir; f++) frames.push({ key, frame: startFrame + f });
                    scene.anims.create({
                        key: animKey,
                        frames,
                        frameRate: preset.anims.frameRate || 6,
                        repeat: -1
                    });
                }
            }
            // Idle = first frame of down
            if (!scene.anims.exists(key + '_idle')) {
                scene.anims.create({
                    key: key + '_idle',
                    frames: [{ key, frame: 0 }],
                    frameRate: 1,
                    repeat: 0
                });
            }
        }

        return sprite;
    },

    /**
     * Play NPC walk animation for direction.
     * dir: 0=down, 1=up, 2=left, 3=right
     */
    playNPCWalk(sprite, dir) {
        if (!sprite || !sprite.anims) return;
        const key = sprite.texture?.key;
        if (!key) return;
        const animKey = `${key}_walk_${dir}`;
        try {
            if (sprite.anims.currentAnim?.key !== animKey) {
                sprite.anims.play(animKey, true);
            }
        } catch (e) { /* anim may not exist */ }
    },

    /**
     * Stop NPC animation and show idle frame.
     */
    stopNPC(sprite) {
        if (!sprite || !sprite.anims) return;
        try {
            sprite.anims.stop();
            sprite.setFrame(0);
        } catch (e) { /* sprite may be destroyed */ }
    },

    /**
     * Add a dynamic shadow under an NPC sprite.
     * opts: { offsetY, scale, alpha }
     */
    addShadow(scene, sprite, opts = {}) {
        if (!sprite) return;
        const ox = 0;
        const oy = opts.offsetY || 4;
        const sScale = opts.scale || 0.5;
        const sAlpha = opts.alpha || 0.15;

        const shadow = scene.add.ellipse(
            sprite.x + ox, sprite.y + oy,
            sprite.displayWidth * sScale, sprite.displayWidth * sScale * 0.4,
            0x000000, sAlpha
        );
        shadow.setDepth(sprite.depth - 1);
        shadow.setOrigin(0.5, 0.5);
        sprite._shadow = shadow;

        // Update shadow position in preUpdate
        sprite._shadowUpdate = () => {
            if (shadow.active && sprite.active) {
                shadow.setPosition(sprite.x + ox, sprite.y + oy);
                shadow.setDepth(sprite.depth - 1);
            }
        };
    }
};
