// Vestige GPS — FloorRenderer
// Extracted from monolith L3604-3931

import { IsoRenderer } from '../isoRenderer.js';


export const FloorRenderer = {
    
    // ── Steel plate deck — irregular welded panels, cable channel ──
    steelPlate(g, x, y, w, h, base) {
        // Irregular plates — different sizes, not a grid
        const plates = [
            [0, 0, 0.45, 0.38], [0.45, 0, 0.55, 0.28],
            [0, 0.38, 0.35, 0.35], [0.35, 0.28, 0.65, 0.45],
            [0, 0.73, 0.55, 0.27], [0.55, 0.73, 0.45, 0.27],
        ];
        plates.forEach(([px, py, pw, ph], i) => {
            const shade = i % 2 === 0 ? IsoRenderer.darken(base, 0.10) : IsoRenderer.lighten(base, 0.05);
            g.fillStyle(shade, 0.45);
            g.fillRect(x + px * w + 1, y + py * h + 1, pw * w - 2, ph * h - 2);
        });
        // Seams between plates
        const seams = [
            [0, 0.38, 0.35, 0.38], [0.35, 0.28, 0.35, 0.73],
            [0.45, 0, 0.45, 0.28], [0, 0.73, 1, 0.73], [0.55, 0.73, 0.55, 1],
        ];
        seams.forEach(([x1, y1, x2, y2]) => {
            g.lineStyle(2, IsoRenderer.darken(base, 0.35), 0.6);
            g.beginPath(); g.moveTo(x + x1 * w, y + y1 * h); g.lineTo(x + x2 * w, y + y2 * h); g.stroke();
            g.lineStyle(1, IsoRenderer.lighten(base, 0.18), 0.25);
            g.beginPath(); g.moveTo(x + x1 * w + 1, y + y1 * h + 1); g.lineTo(x + x2 * w + 1, y + y2 * h + 1); g.stroke();
        });
        // Cable channel along east wall
        g.fillStyle(IsoRenderer.darken(base, 0.20), 0.45);
        g.fillRect(x + w - 22, y + 12, 14, h - 24);
        g.lineStyle(1, IsoRenderer.lighten(base, 0.12), 0.25);
        g.beginPath(); g.moveTo(x + w - 22, y + 12); g.lineTo(x + w - 22, y + h - 12); g.stroke();
        // Worn traffic path center
        g.fillStyle(IsoRenderer.lighten(base, 0.06), 0.15);
        g.fillRect(x + w/2 - 18, y, 36, h);
        // Weld scar
        g.lineStyle(2, IsoRenderer.lighten(base, 0.18), 0.35);
        g.beginPath(); g.moveTo(x + w * 0.2, y + h * 0.55); g.lineTo(x + w * 0.33, y + h * 0.53); g.stroke();
    },
    
    // ── Sealed lab — epoxy coat, tile grout, drain channel, hazard border ──
    sealedLab(g, x, y, w, h, base) {
        // Epoxy sheen
        g.fillStyle(IsoRenderer.lighten(base, 0.08), 0.18);
        g.fillEllipse(x + w * 0.5, y + h * 0.45, w * 0.65, h * 0.5);
        // Tile grid — appropriate for lab/medical
        g.lineStyle(1, IsoRenderer.darken(base, 0.18), 0.3);
        for (let tx = x + 20; tx < x + w; tx += 20) {
            g.beginPath(); g.moveTo(tx, y); g.lineTo(tx, y + h); g.stroke();
        }
        for (let ty = y + 20; ty < y + h; ty += 20) {
            g.beginPath(); g.moveTo(x, ty); g.lineTo(x + w, ty); g.stroke();
        }
        // Drain channel E-W
        const drY = y + h * 0.55;
        g.fillStyle(IsoRenderer.darken(base, 0.30), 0.65);
        g.fillRect(x + 6, drY - 5, w - 12, 10);
        g.lineStyle(2, IsoRenderer.lighten(base, 0.12), 0.35);
        g.beginPath(); g.moveTo(x + 6, drY - 5); g.lineTo(x + w - 6, drY - 5); g.stroke();
        g.lineStyle(1, IsoRenderer.darken(base, 0.35), 0.35);
        g.beginPath(); g.moveTo(x + 6, drY + 5); g.lineTo(x + w - 6, drY + 5); g.stroke();
        for (let dx = x + 10; dx < x + w - 10; dx += 6) {
            g.fillStyle(IsoRenderer.darken(base, 0.22), 0.45);
            g.fillRect(dx, drY - 4, 3, 8);
        }
        // Central drain hub
        g.fillStyle(IsoRenderer.darken(base, 0.35), 0.65);
        g.fillCircle(x + w/2, drY, 9);
        g.lineStyle(2, IsoRenderer.darken(base, 0.40), 0.55);
        g.strokeCircle(x + w/2, drY, 9);
        g.lineStyle(2, IsoRenderer.darken(base, 0.42), 0.5);
        g.beginPath(); g.moveTo(x + w/2 - 6, drY); g.lineTo(x + w/2 + 6, drY); g.stroke();
        g.beginPath(); g.moveTo(x + w/2, drY - 6); g.lineTo(x + w/2, drY + 6); g.stroke();
        // Hazard dashes
        g.lineStyle(3, 0xaaaa44, 0.25);
        const m = 8;
        for (let hx = x + m; hx < x + w - m; hx += 14) {
            g.beginPath(); g.moveTo(hx, y + m); g.lineTo(hx + 7, y + m); g.stroke();
            g.beginPath(); g.moveTo(hx, y + h - m); g.lineTo(hx + 7, y + h - m); g.stroke();
        }
        for (let hy = y + m; hy < y + h - m; hy += 14) {
            g.beginPath(); g.moveTo(x + m, hy); g.lineTo(x + m, hy + 7); g.stroke();
            g.beginPath(); g.moveTo(x + w - m, hy); g.lineTo(x + w - m, hy + 7); g.stroke();
        }
        // Chemical stain
        g.fillStyle(0x253838, 0.2);
        g.fillEllipse(x + w * 0.3, y + h * 0.78, 30, 16);
    },
    
    // ── Hardwood planks — organic grain, staggered joints, knots ──
    hardwood(g, x, y, w, h, base, accent) {
        const alt = accent || IsoRenderer.darken(base, 0.05);
        const plankH = 14;
        const tones = [base, alt, IsoRenderer.darken(base, 0.07), IsoRenderer.lighten(alt, 0.05), IsoRenderer.darken(alt, 0.04)];
        let row = 0;
        for (let py = y; py < y + h; py += plankH) {
            const col = tones[row % tones.length];
            const stagger = ((row * 37 + 13) % 55) + 20;
            const boardW = 45 + (row % 4) * 14;
            g.fillStyle(col, 0.55);
            g.fillRect(x, py, w, plankH);
            // Board end joints
            g.fillStyle(IsoRenderer.darken(base, 0.32), 0.5);
            for (let jx = x + stagger; jx < x + w; jx += boardW) {
                g.fillRect(jx, py, 1, plankH);
            }
            // Grain line
            const gy = py + plankH * 0.4;
            g.lineStyle(1, IsoRenderer.darken(col, 0.10), 0.14);
            g.beginPath(); g.moveTo(x, gy);
            for (let gx = x; gx < x + w; gx += 20) {
                g.lineTo(gx + 20, gy + (Math.sin(gx * 0.3 + row) * 0.8));
            }
            g.stroke();
            // Plank seam
            g.lineStyle(2, IsoRenderer.darken(base, 0.26), 0.45);
            g.beginPath(); g.moveTo(x, py + plankH); g.lineTo(x + w, py + plankH); g.stroke();
            row++;
        }
        // Knotholes
        const knotSpots = [[0.17, 0.17], [0.65, 0.43], [0.8, 0.78]];
        knotSpots.forEach(([kp, kq]) => {
            const kx = x + w * kp, ky = y + h * kq;
            g.fillStyle(IsoRenderer.darken(base, 0.30), 0.5);
            g.fillEllipse(kx, ky, 6, 3.5);
            g.lineStyle(1, IsoRenderer.darken(base, 0.18), 0.25);
            g.strokeEllipse(kx, ky, 10, 6);
        });
        // Worn path near east side
        g.fillStyle(IsoRenderer.lighten(base, 0.06), 0.15);
        g.fillRect(x + w - 25, y + h * 0.28, 25, h * 0.44);
        // Scuffs
        g.fillStyle(IsoRenderer.darken(base, 0.15), 0.22);
        g.fillEllipse(x + w * 0.5, y + h * 0.55, 24, 4);
    },
    
    // ── Diamond plate — continuous hatch over irregular heavy plates ──
    diamondPlate(g, x, y, w, h, base) {
        // Continuous diagonal hatch
        g.lineStyle(1, IsoRenderer.lighten(base, 0.14), 0.10);
        for (let d = 0; d < w + h; d += 8) {
            const sx = x + Math.min(d, w), sy = y + Math.max(0, d - w);
            const ex = x + Math.max(0, d - h), ey = y + Math.min(d, h);
            g.beginPath(); g.moveTo(sx, sy); g.lineTo(ex, ey); g.stroke();
        }
        // Irregular plate sections
        const plates = [
            [0, 0, 0.55, 0.42], [0.55, 0, 0.45, 0.52],
            [0, 0.42, 0.4, 0.58], [0.4, 0.52, 0.6, 0.48],
        ];
        plates.forEach(([px, py, pw, ph], i) => {
            const shade = i % 2 === 0 ? IsoRenderer.darken(base, 0.08) : IsoRenderer.lighten(base, 0.04);
            g.fillStyle(shade, 0.25);
            g.fillRect(x + px * w + 1, y + py * h + 1, pw * w - 2, ph * h - 2);
        });
        // Heavy seams
        const seams = [
            [0, 0.42, 0.4, 0.42], [0.55, 0, 0.55, 0.52],
            [0.4, 0.42, 0.4, 1], [0.4, 0.52, 1, 0.52],
        ];
        seams.forEach(([x1, y1, x2, y2]) => {
            g.lineStyle(3, IsoRenderer.darken(base, 0.30), 0.55);
            g.beginPath(); g.moveTo(x + x1 * w, y + y1 * h); g.lineTo(x + x2 * w, y + y2 * h); g.stroke();
        });
        // Bolt heads at junctions
        const bolts = [[0.55, 0.42], [0.4, 0.52], [0.4, 0.42]];
        bolts.forEach(([bx, by]) => {
            g.fillStyle(IsoRenderer.lighten(base, 0.22), 0.5);
            g.fillCircle(x + bx * w, y + by * h, 4);
            g.lineStyle(2, IsoRenderer.darken(base, 0.18), 0.4);
            g.beginPath(); g.moveTo(x + bx * w - 2.5, y + by * h); g.lineTo(x + bx * w + 2.5, y + by * h); g.stroke();
        });
    },
    
    // ── Bare concrete — mottled surface, expansion joints, cracks ──
    bareConcrete(g, x, y, w, h, base, rng) {
        const rand = rng || Math.random;
        // Mottled trowel texture
        for (let i = 0; i < 18; i++) {
            const mx = x + 5 + rand() * (w - 10);
            const my = y + 5 + rand() * (h - 10);
            const mw = 20 + rand() * 35;
            const mh = 14 + rand() * 21;
            const shade = rand() > 0.5
                ? IsoRenderer.darken(base, 0.06 + rand() * 0.08)
                : IsoRenderer.lighten(base, 0.03 + rand() * 0.05);
            g.fillStyle(shade, 0.18 + rand() * 0.14);
            g.fillEllipse(mx, my, mw, mh);
        }
        // Expansion joints
        g.lineStyle(3, IsoRenderer.darken(base, 0.28), 0.5);
        g.beginPath(); g.moveTo(x + w * 0.33, y); g.lineTo(x + w * 0.33, y + h); g.stroke();
        g.beginPath(); g.moveTo(x + w * 0.66, y); g.lineTo(x + w * 0.66, y + h); g.stroke();
        g.beginPath(); g.moveTo(x, y + h * 0.5); g.lineTo(x + w, y + h * 0.5); g.stroke();
        // Crack from left joint
        g.lineStyle(2, IsoRenderer.darken(base, 0.32), 0.5);
        g.beginPath();
        g.moveTo(x + w * 0.33, y + h * 0.5);
        g.lineTo(x + w * 0.33 + 11, y + h * 0.5 + 22);
        g.lineTo(x + w * 0.33 + 6, y + h * 0.5 + 45);
        g.lineTo(x + w * 0.33 + 15, y + h * 0.5 + 68);
        g.stroke();
        g.lineStyle(1.5, IsoRenderer.darken(base, 0.26), 0.4);
        g.beginPath();
        g.moveTo(x + w * 0.33 + 11, y + h * 0.5 + 22);
        g.lineTo(x + w * 0.33 + 26, y + h * 0.5 + 32);
        g.stroke();
        // Crack from right joint upward
        g.lineStyle(2, IsoRenderer.darken(base, 0.30), 0.45);
        g.beginPath();
        g.moveTo(x + w * 0.66, y + h * 0.5);
        g.lineTo(x + w * 0.66 - 8, y + h * 0.5 - 28);
        g.lineTo(x + w * 0.66 - 4, y + h * 0.5 - 55);
        g.stroke();
        // Repair patch
        g.fillStyle(IsoRenderer.lighten(base, 0.10), 0.3);
        g.fillRect(x + w * 0.56, y + 16, 44, 36);
        g.lineStyle(2, IsoRenderer.darken(base, 0.18), 0.35);
        g.strokeRect(x + w * 0.56, y + 16, 44, 36);
    },
    
    // ── Workshop concrete — oil stains, tire tracks, floor drain ──
    workshopConcrete(g, x, y, w, h, base, rng) {
        const rand = rng || Math.random;
        // Mottled patches
        for (let i = 0; i < 12; i++) {
            const adj = 0.02 + rand() * 0.08;
            const col = rand() > 0.5 ? IsoRenderer.lighten(base, adj) : IsoRenderer.darken(base, adj);
            g.fillStyle(col, 0.15 + rand() * 0.15);
            g.fillEllipse(x + 10 + rand() * (w - 20), y + 10 + rand() * (h - 20),
                25 + rand() * 35, 18 + rand() * 22);
        }
        // A couple expansion joints
        g.lineStyle(3, IsoRenderer.darken(base, 0.25), 0.45);
        g.beginPath(); g.moveTo(x + w * 0.45, y); g.lineTo(x + w * 0.45, y + h); g.stroke();
        g.beginPath(); g.moveTo(x, y + h * 0.45); g.lineTo(x + w, y + h * 0.45); g.stroke();
        // Oil stains
        const oils = [[0.48, 0.54, 45, 28], [0.44, 0.62, 25, 32], [0.32, 0.48, 18, 14]];
        oils.forEach(([ox, oy, ow, oh]) => {
            g.fillStyle(0x1a1815, 0.2);
            g.fillEllipse(x + ox * w, y + oy * h, ow + 8, oh + 5);
            g.fillStyle(0x121010, 0.35);
            g.fillEllipse(x + ox * w, y + oy * h, ow, oh);
            g.lineStyle(2, 0x334466, 0.1);
            g.strokeEllipse(x + ox * w, y + oy * h, ow + 12, oh + 8);
        });
        // Tire tracks N-S
        const trackL = x + w/2 - 21, trackR = x + w/2 + 21;
        g.fillStyle(IsoRenderer.darken(base, 0.12), 0.22);
        g.fillRect(trackL - 5, y + 15, 10, h - 28);
        g.fillRect(trackR - 5, y + 15, 10, h - 28);
        g.lineStyle(1, IsoRenderer.darken(base, 0.15), 0.12);
        for (let ty = y + 20; ty < y + h - 20; ty += 8) {
            g.beginPath(); g.moveTo(trackL - 4, ty); g.lineTo(trackL + 4, ty + 3); g.stroke();
            g.beginPath(); g.moveTo(trackR - 4, ty); g.lineTo(trackR + 4, ty + 3); g.stroke();
        }
        // Floor drain
        const drX = x + w * 0.22, drY = y + h - 24;
        g.fillStyle(IsoRenderer.darken(base, 0.30), 0.55);
        g.fillRect(drX - 12, drY - 8, 24, 16);
        g.lineStyle(2, IsoRenderer.darken(base, 0.35), 0.4);
        g.strokeRect(drX - 12, drY - 8, 24, 16);
        for (let s = drX - 8; s <= drX + 8; s += 5) {
            g.fillStyle(IsoRenderer.darken(base, 0.28), 0.45);
            g.fillRect(s - 1, drY - 6, 2, 12);
        }
    },
    
    // ── Linoleum — scuffed commercial floor, no visible grid ──
    linoleum(g, x, y, w, h, base, accent) {
        const alt = accent || IsoRenderer.lighten(base, 0.04);
        // Mottled color patches — institutional look
        for (let i = 0; i < 14; i++) {
            const mx = x + 10 + Math.random() * (w - 20);
            const my = y + 10 + Math.random() * (h - 20);
            g.fillStyle(i % 2 ? alt : IsoRenderer.darken(base, 0.05), 0.15);
            g.fillEllipse(mx, my, 20 + Math.random() * 40, 15 + Math.random() * 25);
        }
        // Scuff marks from foot traffic
        for (let i = 0; i < 6; i++) {
            g.fillStyle(IsoRenderer.darken(base, 0.10), 0.18);
            g.fillEllipse(x + w * 0.3 + Math.random() * w * 0.4,
                y + h * 0.3 + Math.random() * h * 0.4,
                8 + Math.random() * 14, 3 + Math.random() * 5);
        }
        // Worn path center
        g.fillStyle(IsoRenderer.lighten(base, 0.04), 0.1);
        g.fillEllipse(x + w/2, y + h * 0.55, w * 0.35, h * 0.4);
    },
    
    // ── Institutional tile — subtle grout, cracked tiles, missing patches ──
    institutionalTile(g, x, y, w, h, base, accent, rng) {
        const rand = rng || Math.random;
        const tileS = 22;
        // Grout lines
        g.lineStyle(1, IsoRenderer.darken(base, 0.15), 0.25);
        for (let tx = x + tileS; tx < x + w; tx += tileS) {
            g.beginPath(); g.moveTo(tx, y); g.lineTo(tx, y + h); g.stroke();
        }
        for (let ty = y + tileS; ty < y + h; ty += tileS) {
            g.beginPath(); g.moveTo(x, ty); g.lineTo(x + w, ty); g.stroke();
        }
        // Random discolored tiles
        for (let tx = x; tx < x + w; tx += tileS) {
            for (let ty = y; ty < y + h; ty += tileS) {
                if (rand() < 0.12) {
                    g.fillStyle(accent || IsoRenderer.darken(base, 0.06), 0.12);
                    g.fillRect(tx + 1, ty + 1, tileS - 2, tileS - 2);
                }
            }
        }
        // Cracked tiles
        for (let c = 0; c < 3; c++) {
            const cx = x + 20 + rand() * (w - 40);
            const cy = y + 20 + rand() * (h - 40);
            g.lineStyle(1, IsoRenderer.darken(base, 0.20), 0.3);
            g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx + (rand() - 0.5) * 20, cy + (rand() - 0.5) * 16); g.stroke();
        }
        // Missing tile dark patches
        for (let i = 0; i < 2; i++) {
            if (rand() < 0.5) {
                g.fillStyle(IsoRenderer.darken(base, 0.15), 0.4);
                const mx = x + tileS + rand() * (w - tileS * 2);
                const my = y + tileS + rand() * (h - tileS * 2);
                g.fillRect(mx, my, tileS - 2, tileS - 2);
            }
        }
    },
};

