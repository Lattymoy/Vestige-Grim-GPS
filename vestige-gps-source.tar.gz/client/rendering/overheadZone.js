// Vestige GPS — OverheadZone
// Extracted from monolith L4302-4392

import { IsoRenderer } from '../isoRenderer.js';


export const OverheadZone = {
    // Registry of active overhead zones per scene
    _zones: new Map(),
    
    // Create an overhead zone
    // scene: Phaser scene
    // x, y: center of the overhead area on the ground
    // w, h: width and height of the zone
    // visual: the Phaser game object(s) that should fade (container, rectangle, etc.)
    // opts: { depth, fullAlpha, fadeAlpha, fadeSpeed }
    create(scene, x, y, w, h, visual, opts = {}) {
        const zone = {
            x, y, w, h,
            visual,
            fullAlpha: opts.fullAlpha || 1,
            fadeAlpha: opts.fadeAlpha || 0.15,
            fadeSpeed: opts.fadeSpeed || 0.08,
            currentAlpha: opts.fullAlpha || 1,
            playerInside: false,
            depth: opts.depth || 50
        };
        if (visual.setDepth) visual.setDepth(zone.depth);
        
        if (!this._zones.has(scene)) this._zones.set(scene, []);
        this._zones.get(scene).push(zone);
        return zone;
    },
    
    // Call every frame from scene.update() with player position
    update(scene, playerX, playerY) {
        const zones = this._zones.get(scene);
        if (!zones) return;
        
        for (const zone of zones) {
            const inside = playerX > zone.x - zone.w / 2 && playerX < zone.x + zone.w / 2 &&
                          playerY > zone.y - zone.h / 2 && playerY < zone.y + zone.h / 2;
            
            const targetAlpha = inside ? zone.fadeAlpha : zone.fullAlpha;
            
            // Smooth fade
            if (Math.abs(zone.currentAlpha - targetAlpha) > 0.01) {
                zone.currentAlpha += (targetAlpha - zone.currentAlpha) * zone.fadeSpeed;
                if (zone.visual.setAlpha) zone.visual.setAlpha(zone.currentAlpha);
            }
        }
    },
    
    // Clean up when scene shuts down
    destroy(scene) {
        this._zones.delete(scene);
    },
    
    // Build a gas station canopy — pillars + flat roof
    // Returns { container, zone } where container is the visual and zone is the overhead
    gasStationCanopy(scene, x, y, w, h, opts = {}) {
        const depth = opts.depth || 50;
        const tc = (c) => IsoRenderer.tint(scene, c);
        
        const canopyColor = tc(opts.color || 0x555555);
        const pillarColor = tc(opts.pillarColor || 0x4a4a4a);
        const underColor = tc(IsoRenderer.darken(opts.color || 0x555555, 0.3));
        
        const container = scene.add.container(x, y).setDepth(depth);
        
        // Pillars (drawn at ground level, always visible)
        const pillarW = 4, pillarH = 30;
        const px1 = -w / 2 + 6, px2 = w / 2 - 6;
        const py1 = -h / 2 + 4, py2 = h / 2 - 4;
        
        // Ground-level pillar bases (visible even when canopy fades)
        const pillarsGround = scene.add.container(x, y).setDepth(depth - 2);
        [{ px: px1, py: py1 }, { px: px2, py: py1 }, { px: px1, py: py2 }, { px: px2, py: py2 }].forEach(p => {
            pillarsGround.add(scene.add.rectangle(p.px, p.py, pillarW, pillarH, pillarColor));
            pillarsGround.add(scene.add.rectangle(p.px, p.py + pillarH / 2, pillarW + 4, 3, pillarColor, 0.5));
        });
        
        // Canopy roof (this fades)
        container.add(scene.add.rectangle(0, 0, w, h, underColor, 0.6)); // underside shadow
        container.add(scene.add.rectangle(0, -2, w + 4, h + 4, canopyColor)); // roof slab
        container.add(scene.add.rectangle(0, -4, w + 2, 2, tc(IsoRenderer.lighten(canopyColor, 0.15)))); // roof edge
        
        // Ceiling lights (subtle)
        container.add(scene.add.rectangle(-w * 0.25, 0, 2, h * 0.4, 0xaaaaaa, 0.15));
        container.add(scene.add.rectangle(w * 0.25, 0, 2, h * 0.4, 0xaaaaaa, 0.15));
        
        // Create overhead zone
        const zone = this.create(scene, x, y, w, h, container, { depth, fadeAlpha: 0.12 });
        
        return { container, pillarsGround, zone };
    }
};

