// Vestige GPS — SafehouseExterior
// Extracted from monolith L76483-76553

export const SafehouseExterior = {
    // Draw the safehouse as a small isometric building into a container
    // upgradeLevel reflects unlocked rooms (0-3), vehicleColor for garage
    create(scene, x, y, scale = 1.0) {
        const c = scene.add.container(x, y);
        const s = scale;
        const a = (obj) => { c.add(obj); return obj; };
        
        // Shadow
        a(scene.add.ellipse(4 * s, 22 * s, 50 * s, 14 * s, 0x000000, 0.3));
        
        // === MAIN BUILDING BODY ===
        // Right face (south-east wall - darker)
        a(scene.add.polygon(0, 0, [
            0, 0, 20*s, 10*s, 20*s, -14*s, 0, -24*s
        ], 0x3a3a38).setOrigin(0));
        // Left face (south-west wall - lighter)
        a(scene.add.polygon(0, 0, [
            0, 0, -20*s, 10*s, -20*s, -14*s, 0, -24*s
        ], 0x4a4a48).setOrigin(0));
        // Roof top surface
        a(scene.add.polygon(0, -24*s, [
            0, 0, 20*s, 10*s, 0, 20*s, -20*s, 10*s
        ], 0x555553).setOrigin(0));
        
        // Roof edge highlights
        a(scene.add.rectangle(-10*s, -19*s, 22*s, 1*s, 0x666664));
        a(scene.add.rectangle(10*s, -19*s, 22*s, 1*s, 0x444442));
        
        // === GARAGE DOOR (right face, lower portion) ===
        a(scene.add.rectangle(10*s, -2*s, 12*s, 14*s, 0x1a1a1a));
        // Door grooves
        for (let i = -2; i <= 2; i++) {
            a(scene.add.rectangle(10*s, -2*s + i*3*s, 11*s, 0.5*s, 0x2a2a2a));
        }
        // Hazard stripe
        a(scene.add.rectangle(10*s, 5*s, 11*s, 2*s, 0x8a8a22));
        
        // === WINDOWS ===
        // Left face window
        a(scene.add.rectangle(-10*s, -10*s, 7*s, 5*s, 0x2a3a4a));
        a(scene.add.rectangle(-10*s, -10*s, 7*s, 5*s, 0x4a6a8a, 0.3));
        a(scene.add.rectangle(-10*s, -10*s, 7*s, 0.5*s, 0x555555)); // cross bar
        
        // Right face window (above garage)
        a(scene.add.rectangle(10*s, -16*s, 6*s, 4*s, 0x2a3a4a));
        a(scene.add.rectangle(10*s, -16*s, 6*s, 4*s, 0x4a6a8a, 0.3));
        
        // === DETAILS ===
        // Antenna on roof
        a(scene.add.rectangle(-6*s, -30*s, 1*s, 8*s, 0x666666));
        a(scene.add.rectangle(-6*s, -34*s, 3*s, 1*s, 0x888888));
        
        // Door on left face
        a(scene.add.rectangle(-8*s, 2*s, 5*s, 8*s, 0x3a2a1a));
        a(scene.add.rectangle(-8*s, 2*s, 4*s, 7*s, 0x4a3a2a));
        a(scene.add.circle(-6.5*s, 2*s, 0.7*s, 0x8a8a44)); // doorknob
        
        // Sandbags at base
        for (let i = 0; i < 3; i++) {
            a(scene.add.ellipse(-14*s + i*5*s, 10*s, 6*s, 3*s, 0x6a6a5a));
            a(scene.add.ellipse(-14*s + i*5*s, 9.5*s, 5*s, 2*s, 0x7a7a6a));
        }
        
        // Small light by door (warm glow)
        a(scene.add.circle(-5*s, -4*s, 2*s, 0xffcc44, 0.3));
        a(scene.add.circle(-5*s, -4*s, 1*s, 0xffcc44, 0.5));
        
        return c;
    }
};

