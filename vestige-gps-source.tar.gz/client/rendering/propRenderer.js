// Vestige GPS — PropRenderer
// Extracted from monolith L53275-55119

import { CONFIG } from '../../data/config.js';
import { DynamicShadows } from '../dynamicShadows.js';
import { IsoRenderer } from '../isoRenderer.js';
import { VehicleFleet } from '../vehicleFleet.js';


export const PropRenderer = {
    // Directional two-layer prop shadow — matches DynamicShadows style
    _shadow(scene, x, baseY, w, d) {
        const L = scene.lighting || CONFIG.lighting[CONFIG.timeOfDay] || CONFIG.lighting.midday;
        const ox = Math.cos(L.shadowAngle) * L.shadowLength * 5;
        const oy = Math.abs(Math.sin(L.shadowAngle)) * L.shadowLength * 2;
        const a = 0.08 + (L.intensity || 0.5) * 0.18;
        const h = w * 0.25;
        scene.add.ellipse(x + ox * 1.1, baseY + oy, w * 1.3, h * 1.4, 0x000000, a * 0.3).setDepth(d - 0.02);
        scene.add.ellipse(x + ox, baseY + oy, w, h, 0x000000, a).setDepth(d - 0.01);
    },
    
    // === FLEET-BASED VEHICLE WRECKS ===
    // Uses VehicleFleet spritesheet wreck frames with environmental overlays
    
    _createFleetWreck(scene, x, y, type) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor ? scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity) : c;
        const dmg = Phaser.Math.Between(0, 2);
        
        // Pick a random facing direction for variety
        const dirs = ['down', 'right', 'up', 'left'];
        const dir = dirs[Phaser.Math.Between(0, 3)];
        
        VehicleFleet.registerTextures(scene);
        const frame = VehicleFleet.getFrame(type, dir, true);
        const sprite = scene.add.sprite(x, y, 'fleet_all', frame).setDepth(d);
        
        // Get wreck dimensions based on type
        const isLarge = (type === 'cargo' || type === 'humvee');
        const bW = isLarge ? 68 : 56;
        const bH = isLarge ? 30 : 26;
        
        // Ground shadow — directional, two-layer
        const wShOx = Math.cos(scene.lighting.shadowAngle) * scene.lighting.shadowLength * 6;
        const wShOy = Math.abs(Math.sin(scene.lighting.shadowAngle)) * scene.lighting.shadowLength * 2;
        const wShA = 0.10 + scene.lighting.intensity * 0.18;
        scene.add.ellipse(x + wShOx * 1.1, y + bH/2 + 5 + wShOy, bW * 1.1, bH * 0.35, 0x000000, wShA * 0.3).setDepth(d - 0.02);
        scene.add.ellipse(x + wShOx, y + bH/2 + 5 + wShOy, bW * 0.85, bH * 0.25, 0x000000, wShA).setDepth(d - 0.01);
        
        // Broken glass scatter on ground
        for (let g = 0; g < 4 + dmg * 2; g++) {
            const gx = x + Phaser.Math.Between(-bW/2 - 8, bW/2 + 8);
            const gy = y + bH/2 + Phaser.Math.Between(2, 14);
            scene.add.rectangle(gx, gy, Phaser.Math.Between(1, 3), 1, 0x88aacc, 0.25 + Math.random() * 0.15)
                .setAngle(Phaser.Math.Between(0, 180)).setDepth(d - 0.02);
        }
        
        // Overgrowth / weeds around base
        const biome = CONFIG.currentBiome ? CONFIG.currentBiome.type : 'grassy';
        if (biome !== 'barren' && biome !== 'apocalyptic') {
            const grassCol = tc(0x3a5a2a);
            for (let w = 0; w < 3 + dmg; w++) {
                const wx = x + Phaser.Math.Between(-bW/2, bW/2);
                const wy = y + bH/2 + Phaser.Math.Between(-2, 6);
                const wh = Phaser.Math.Between(5, 10);
                scene.add.rectangle(wx, wy - wh/2, 2, wh, grassCol, 0.5)
                    .setAngle(Phaser.Math.Between(-20, 20)).setDepth(d + 0.011);
            }
        }
        
        // Smoke/steam wisps from engine area
        if (Phaser.Math.Between(0, 2) > 0) {
            for (let s = 0; s < 2; s++) {
                const sx = x + Phaser.Math.Between(-8, 8);
                const sy = y - bH * 0.3;
                const smoke = scene.add.circle(sx, sy, Phaser.Math.Between(2, 4), 0x555555, 0.12).setDepth(d + 0.02);
                scene.tweens.add({ targets: smoke, alpha: 0, y: sy - 20, scaleX: 1.8, duration: Phaser.Math.Between(3000, 5000), repeat: -1, delay: s * 1500 });
            }
        }
        
        // Collision wall
        scene.addWall(x, y, bW + 4, bH + 8, 0x000000, false);
    },
    
    createCarWreck(scene, x, y) {
        // Random car-type wreck from fleet
        const carTypes = ['suv', 'pickup', 'police'];
        const type = carTypes[Phaser.Math.Between(0, carTypes.length - 1)];
        this._createFleetWreck(scene, x, y, type);
    },
    
    createTruckWreck(scene, x, y) {
        // Random large-type wreck from fleet
        const truckTypes = ['cargo', 'humvee'];
        const type = truckTypes[Phaser.Math.Between(0, truckTypes.length - 1)];
        this._createFleetWreck(scene, x, y, type);
    },
    
    createDumpster(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const bodyColor = 0x335533;
        
        // Shadow — directional, two-layer
        const dsOx = Math.cos(scene.lighting.shadowAngle) * scene.lighting.shadowLength * 5;
        const dsOy = Math.abs(Math.sin(scene.lighting.shadowAngle)) * scene.lighting.shadowLength * 2;
        const dsA = 0.10 + scene.lighting.intensity * 0.18;
        scene.add.ellipse(x + dsOx * 1.1, y + 12 + dsOy, 42, 12, 0x000000, dsA * 0.3).setDepth(d - 0.02);
        scene.add.ellipse(x + dsOx, y + 12 + dsOy, 36, 9, 0x000000, dsA).setDepth(d - 0.01);
        
        // Body — front face
        scene.add.rectangle(x, y + 3, 32, 12, tc(bodyColor)).setDepth(d + 0.001);
        // Body — top surface
        scene.add.rectangle(x, y - 4, 32, 12, tc(IsoRenderer.lighten(bodyColor, 0.12))).setDepth(d + 0.002);
        // Body — side face (right)
        scene.add.rectangle(x + 16, y, 4, 18, tc(IsoRenderer.darken(bodyColor, 0.2))).setDepth(d + 0.003);
        
        // Reinforcement ridges on front face
        scene.add.rectangle(x - 10, y + 3, 2, 10, tc(IsoRenderer.darken(bodyColor, 0.15))).setDepth(d + 0.004);
        scene.add.rectangle(x + 10, y + 3, 2, 10, tc(IsoRenderer.darken(bodyColor, 0.15))).setDepth(d + 0.004);
        
        // Lid panels (two halves on top)
        scene.add.rectangle(x - 8, y - 8, 15, 10, tc(IsoRenderer.darken(bodyColor, 0.12))).setDepth(d + 0.005);
        scene.add.rectangle(x + 8, y - 8, 15, 10, tc(IsoRenderer.darken(bodyColor, 0.08))).setDepth(d + 0.005);
        // Lid seam
        scene.add.rectangle(x, y - 8, 1, 10, tc(0x1a2a1a)).setDepth(d + 0.006);
        // Lid handles
        scene.add.rectangle(x - 8, y - 12, 8, 2, tc(0x2a2a2a)).setDepth(d + 0.007);
        scene.add.rectangle(x + 8, y - 12, 8, 2, tc(0x2a2a2a)).setDepth(d + 0.007);
        
        // Bottom rails/feet
        scene.add.rectangle(x - 12, y + 10, 4, 3, tc(0x222222)).setDepth(d - 0.005);
        scene.add.rectangle(x + 12, y + 10, 4, 3, tc(0x222222)).setDepth(d - 0.005);
        
        // Drain slot on front
        scene.add.rectangle(x, y + 8, 8, 2, tc(0x1a2a1a)).setDepth(d + 0.004);
        
        // Rust/grime
        scene.add.rectangle(x + 6, y + 5, 7, 4, tc(0x5a4a3a), 0.3).setDepth(d + 0.004);
        scene.add.rectangle(x - 8, y - 2, 5, 5, tc(0x4a3a2a), 0.25).setDepth(d + 0.004);
        
        scene.addWall(x, y, 35, 22, bodyColor, false);
    },
    
    createOilBarrel(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const bodyColor = 0x444455;
        
        // Shadow
        this._shadow(scene, x, y + 10, 18, d);
        
        // Body — slight bulge shape using stacked rects
        scene.add.rectangle(x, y + 4, 13, 14, tc(bodyColor)).setDepth(d + 0.001);
        scene.add.rectangle(x, y, 14, 8, tc(bodyColor)).setDepth(d + 0.001); // bulge
        scene.add.rectangle(x, y - 5, 13, 6, tc(bodyColor)).setDepth(d + 0.001);
        
        // Side highlight (left)
        scene.add.rectangle(x - 6, y, 2, 18, tc(IsoRenderer.lighten(bodyColor, 0.1))).setDepth(d + 0.002);
        // Side shadow (right)
        scene.add.rectangle(x + 6, y, 2, 18, tc(IsoRenderer.darken(bodyColor, 0.2))).setDepth(d + 0.002);
        
        // Metal bands (3 horizontal) with highlights
        scene.add.rectangle(x, y - 6, 14, 2, tc(IsoRenderer.lighten(bodyColor, 0.15))).setDepth(d + 0.003);
        scene.add.rectangle(x, y - 6, 12, 1, tc(IsoRenderer.lighten(bodyColor, 0.22))).setDepth(d + 0.0035);
        scene.add.rectangle(x, y + 1, 15, 2, tc(IsoRenderer.lighten(bodyColor, 0.15))).setDepth(d + 0.003);
        scene.add.rectangle(x, y + 1, 13, 1, tc(IsoRenderer.lighten(bodyColor, 0.22))).setDepth(d + 0.0035);
        scene.add.rectangle(x, y + 8, 14, 2, tc(IsoRenderer.lighten(bodyColor, 0.15))).setDepth(d + 0.003);
        
        // Top surface (ellipse) with inner rim
        scene.add.ellipse(x, y - 9, 14, 6, tc(IsoRenderer.lighten(bodyColor, 0.2))).setDepth(d + 0.004);
        scene.add.ellipse(x, y - 9, 10, 4, tc(IsoRenderer.lighten(bodyColor, 0.12))).setDepth(d + 0.0045);
        // Bung holes on top
        scene.add.ellipse(x - 3, y - 9, 3, 1.5, tc(IsoRenderer.darken(bodyColor, 0.3))).setDepth(d + 0.005);
        scene.add.ellipse(x + 3, y - 9, 3, 1.5, tc(IsoRenderer.darken(bodyColor, 0.3))).setDepth(d + 0.005);
        
        // Seam lines (vertical)
        scene.add.rectangle(x - 1, y, 1, 16, tc(IsoRenderer.darken(bodyColor, 0.1)), 0.4).setDepth(d + 0.002);
        scene.add.rectangle(x + 4, y, 1, 16, tc(IsoRenderer.darken(bodyColor, 0.06)), 0.25).setDepth(d + 0.002);
        
        // Hazard label/sticker
        scene.add.rectangle(x - 1, y + 4, 6, 4, tc(0x8a7a3a), 0.3).setDepth(d + 0.004);
        scene.add.rectangle(x - 1, y + 4, 4, 2, tc(0x6a5a2a), 0.2).setDepth(d + 0.0045);
        
        // Rust stain drip
        scene.add.rectangle(x + 2, y + 3, 2, 6, tc(0x6a4a3a), 0.2).setDepth(d + 0.003);
        if (Math.random() < 0.5) scene.add.rectangle(x - 3, y + 6, 2, 4, tc(0x5a3a2a), 0.15).setDepth(d + 0.003);
        
        scene.addWall(x, y, 14, 14, bodyColor, false);
    },
    
    createCrateStack(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        
        // Shadow
        this._shadow(scene, x, y + 16, 32, d);
        
        // === BOTTOM CRATE ===
        const bc = 0x665544;
        // Front face
        scene.add.rectangle(x, y + 7, 26, 12, tc(bc)).setDepth(d + 0.001);
        // Top surface
        scene.add.rectangle(x, y, 26, 10, tc(IsoRenderer.lighten(bc, 0.12))).setDepth(d + 0.002);
        // Side face
        scene.add.rectangle(x + 13, y + 3, 4, 16, tc(IsoRenderer.darken(bc, 0.2))).setDepth(d + 0.003);
        // Slat lines (front)
        scene.add.rectangle(x, y + 3, 22, 2, tc(IsoRenderer.darken(bc, 0.12))).setDepth(d + 0.004);
        scene.add.rectangle(x, y + 10, 22, 2, tc(IsoRenderer.darken(bc, 0.12))).setDepth(d + 0.004);
        // Cross brace
        scene.add.rectangle(x, y + 7, 2, 10, tc(IsoRenderer.darken(bc, 0.15))).setDepth(d + 0.004);
        // Corner brackets
        scene.add.rectangle(x - 11, y + 1, 3, 3, tc(0x3a3a3a)).setDepth(d + 0.005);
        scene.add.rectangle(x + 11, y + 1, 3, 3, tc(0x3a3a3a)).setDepth(d + 0.005);
        // Stencil mark
        scene.add.rectangle(x + 5, y + 6, 6, 4, tc(0x2a2a2a), 0.3).setDepth(d + 0.005);
        
        // === TOP CRATE (offset, smaller) ===
        const tc2 = 0x776655;
        scene.add.rectangle(x - 3, y - 6, 20, 10, tc(tc2)).setDepth(d + 0.01);
        scene.add.rectangle(x - 3, y - 12, 20, 8, tc(IsoRenderer.lighten(tc2, 0.12))).setDepth(d + 0.011);
        scene.add.rectangle(x - 3 + 10, y - 9, 3, 14, tc(IsoRenderer.darken(tc2, 0.2))).setDepth(d + 0.012);
        // Top crate slats
        scene.add.rectangle(x - 3, y - 9, 16, 2, tc(IsoRenderer.darken(tc2, 0.12))).setDepth(d + 0.013);
        // Nails
        scene.add.circle(x - 10, y - 7, 1, tc(0x4a4a4a)).setDepth(d + 0.013);
        scene.add.circle(x + 4, y - 7, 1, tc(0x4a4a4a)).setDepth(d + 0.013);
        
        scene.addWall(x, y, 28, 28, bc, false);
    },
    
    createShippingContainer(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const color = Phaser.Math.Between(0, 1) ? 0x885533 : 0x336688;
        
        // Shadow
        this._shadow(scene, x, y + 16, 80, d);
        
        // Main body — front face
        scene.add.rectangle(x, y + 5, 76, 16, tc(color)).setDepth(d + 0.001);
        // Top surface
        scene.add.rectangle(x, y - 5, 76, 14, tc(IsoRenderer.lighten(color, 0.12))).setDepth(d + 0.002);
        // Side face (right)
        scene.add.rectangle(x + 38, y, 4, 22, tc(IsoRenderer.darken(color, 0.25))).setDepth(d + 0.003);
        
        // Corrugation ridges on top surface
        for (let lx = x - 32; lx <= x + 32; lx += 8) {
            scene.add.rectangle(lx, y - 5, 1, 14, tc(IsoRenderer.darken(color, 0.1)), 0.4).setDepth(d + 0.004);
        }
        // Corrugation on front face
        for (let lx = x - 32; lx <= x + 32; lx += 8) {
            scene.add.rectangle(lx, y + 5, 1, 14, tc(IsoRenderer.darken(color, 0.08)), 0.3).setDepth(d + 0.004);
        }
        
        // Door end (left side) — double doors
        scene.add.rectangle(x - 36, y + 5, 6, 16, tc(IsoRenderer.darken(color, 0.15))).setDepth(d + 0.005);
        // Door seam
        scene.add.rectangle(x - 36, y + 5, 1, 14, tc(0x1a1a1a), 0.4).setDepth(d + 0.006);
        // Lock bar
        scene.add.rectangle(x - 34, y + 5, 2, 10, tc(0x2a2a2a)).setDepth(d + 0.007);
        scene.add.rectangle(x - 34, y + 2, 3, 3, tc(0x3a3a3a)).setDepth(d + 0.008); // handle
        
        // Front face door handles (right end)
        scene.add.rectangle(x + 35, y + 3, 3, 8, tc(0x222222)).setDepth(d + 0.006);
        scene.add.rectangle(x + 35, y + 8, 3, 8, tc(0x222222)).setDepth(d + 0.006);
        
        // Corner castings (structural corners)
        scene.add.rectangle(x - 37, y - 10, 4, 4, tc(0x2a2a2a)).setDepth(d + 0.005);
        scene.add.rectangle(x + 37, y - 10, 4, 4, tc(0x2a2a2a)).setDepth(d + 0.005);
        scene.add.rectangle(x - 37, y + 12, 4, 4, tc(0x2a2a2a)).setDepth(d + 0.005);
        scene.add.rectangle(x + 37, y + 12, 4, 4, tc(0x2a2a2a)).setDepth(d + 0.005);
        
        // Identification plate
        scene.add.rectangle(x + 20, y + 2, 14, 6, tc(0xddddcc), 0.3).setDepth(d + 0.006);
        
        // Rust streaks
        scene.add.rectangle(x + 12, y + 7, 3, 8, tc(0x6a4a3a), 0.2).setDepth(d + 0.004);
        scene.add.rectangle(x - 18, y + 9, 2, 6, tc(0x6a4a3a), 0.15).setDepth(d + 0.004);
        
        scene.addWall(x, y, 80, 28, color, false);
    },
    
    createMailbox(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const mb = 0x3344aa;
        
        // Shadow
        this._shadow(scene, x, y + 8, 14, d);
        
        // Post
        scene.add.rectangle(x, y + 4, 4, 16, tc(0x444444)).setDepth(d + 0.001);
        scene.add.rectangle(x + 2, y + 4, 1, 16, tc(IsoRenderer.darken(0x444444, 0.2))).setDepth(d + 0.002);
        scene.add.rectangle(x - 1, y + 4, 1, 14, tc(IsoRenderer.lighten(0x444444, 0.08))).setDepth(d + 0.002);
        // Post base plate
        scene.add.rectangle(x, y + 12, 8, 2, tc(0x3a3a3a)).setDepth(d + 0.001);
        scene.add.rectangle(x, y + 13, 6, 1, tc(0x2a2a2a)).setDepth(d + 0.001);
        
        // Mailbox body — front face
        scene.add.rectangle(x, y - 8, 12, 8, tc(mb)).setDepth(d + 0.01);
        // Top surface (rounded/barrel shape)
        scene.add.rectangle(x, y - 13, 12, 5, tc(IsoRenderer.lighten(mb, 0.15))).setDepth(d + 0.011);
        scene.add.rectangle(x, y - 15, 10, 2, tc(IsoRenderer.lighten(mb, 0.22))).setDepth(d + 0.012);
        // Side face (right)
        scene.add.rectangle(x + 6, y - 10, 3, 10, tc(IsoRenderer.darken(mb, 0.2))).setDepth(d + 0.013);
        // Bottom edge
        scene.add.rectangle(x, y - 4, 12, 1, tc(IsoRenderer.darken(mb, 0.12))).setDepth(d + 0.009);
        
        // Door/flap with hinge detail
        scene.add.rectangle(x - 1, y - 7, 9, 5, tc(IsoRenderer.darken(mb, 0.1))).setDepth(d + 0.014);
        scene.add.rectangle(x - 1, y - 9, 9, 1, tc(IsoRenderer.darken(mb, 0.05))).setDepth(d + 0.014); // hinge line
        // Handle
        scene.add.rectangle(x - 1, y - 6, 5, 1, tc(0x2a2a2a)).setDepth(d + 0.015);
        scene.add.rectangle(x - 1, y - 6, 3, 1, tc(0x4a4a4a)).setDepth(d + 0.016); // handle highlight
        
        // Flag (side)
        const flagUp = Math.random() < 0.3;
        if (flagUp) {
            scene.add.rectangle(x + 8, y - 12, 2, 7, tc(0xcc2222)).setDepth(d + 0.015);
            scene.add.rectangle(x + 8, y - 14, 3, 2, tc(0xdd3333)).setDepth(d + 0.016); // flag tip
        } else {
            scene.add.rectangle(x + 8, y - 7, 5, 2, tc(0xcc2222)).setDepth(d + 0.015);
            scene.add.circle(x + 10, y - 7, 1, tc(0xdd3333)).setDepth(d + 0.016); // pivot
        }
        // House number plate
        scene.add.rectangle(x - 1, y - 11, 6, 3, tc(0xdddddd), 0.4).setDepth(d + 0.014);
        scene.add.rectangle(x - 1, y - 11, 4, 2, tc(0xbbbbbb), 0.3).setDepth(d + 0.0145); // number
        // Rust/weathering
        scene.add.ellipse(x + 3, y - 6, 3, 2, tc(0x2a3a6a), 0.25).setDepth(d + 0.0135);
    },
    
    createTrashCan(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const bodyColor = 0x444444;
        
        // Shadow
        this._shadow(scene, x, y + 9, 16, d);
        
        // Body — tapered (narrower at bottom), 3-face
        scene.add.rectangle(x, y + 5, 11, 8, tc(IsoRenderer.darken(bodyColor, 0.1))).setDepth(d + 0.001);
        scene.add.rectangle(x, y - 1, 12, 8, tc(bodyColor)).setDepth(d + 0.001);
        // Side face (right, darker)
        scene.add.rectangle(x + 6, y + 2, 2, 14, tc(IsoRenderer.darken(bodyColor, 0.25))).setDepth(d + 0.002);
        // Left highlight
        scene.add.rectangle(x - 6, y + 1, 1, 12, tc(IsoRenderer.lighten(bodyColor, 0.08))).setDepth(d + 0.002);
        
        // Ribs/ridges (horizontal bands)
        scene.add.rectangle(x, y - 3, 13, 1, tc(IsoRenderer.lighten(bodyColor, 0.12))).setDepth(d + 0.003);
        scene.add.rectangle(x, y + 2, 12, 1, tc(IsoRenderer.lighten(bodyColor, 0.12))).setDepth(d + 0.003);
        scene.add.rectangle(x, y + 7, 11, 1, tc(IsoRenderer.lighten(bodyColor, 0.12))).setDepth(d + 0.003);
        
        // Lid — top ellipse (foreshortened)
        scene.add.ellipse(x, y - 6, 14, 6, tc(IsoRenderer.lighten(bodyColor, 0.15))).setDepth(d + 0.004);
        scene.add.ellipse(x, y - 6, 10, 4, tc(IsoRenderer.lighten(bodyColor, 0.10))).setDepth(d + 0.0045);
        // Lid handle
        scene.add.rectangle(x, y - 9, 4, 2, tc(0x333333)).setDepth(d + 0.005);
        scene.add.rectangle(x, y - 9, 2, 1, tc(0x555555)).setDepth(d + 0.006); // handle highlight
        
        // Garbage bag peeking out (sometimes)
        if (Math.random() < 0.5) {
            scene.add.rectangle(x + 3, y - 5, 4, 5, tc(0x1a1a1a), 0.5).setDepth(d + 0.0042);
            scene.add.rectangle(x + 4, y - 7, 3, 3, tc(0x1a1a1a), 0.4).setDepth(d + 0.0042);
        }
        // Dent
        if (Math.random() < 0.4) {
            scene.add.ellipse(x - 2, y + 3, 5, 3, tc(IsoRenderer.darken(bodyColor, 0.12)), 0.3).setDepth(d + 0.0025);
        }
        // Scuff mark near base
        scene.add.rectangle(x + 2, y + 8, 4, 1, tc(IsoRenderer.darken(bodyColor, 0.15)), 0.3).setDepth(d + 0.0015);
        // Base rim
        scene.add.rectangle(x, y + 9, 10, 2, tc(IsoRenderer.darken(bodyColor, 0.08))).setDepth(d - 0.005);
        
        scene.addWall(x, y, 12, 12, bodyColor, false);
    },
    
    createFence(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const woodColor = 0x554433;
        
        // Shadow
        this._shadow(scene, x, y + 8, 58, d);
        
        // Posts (3) with top cap, body, side shading, nail
        for (let p = -1; p <= 1; p++) {
            const px = x + p * 24;
            scene.add.rectangle(px, y - 2, 5, 14, tc(IsoRenderer.darken(woodColor, 0.1))).setDepth(d + 0.003);
            scene.add.rectangle(px, y - 8, 6, 3, tc(woodColor)).setDepth(d + 0.004); // post cap
            scene.add.rectangle(px, y - 9, 5, 1, tc(IsoRenderer.lighten(woodColor, 0.1))).setDepth(d + 0.005); // cap top highlight
            scene.add.rectangle(px + 2, y - 2, 1, 14, tc(IsoRenderer.darken(woodColor, 0.25))).setDepth(d + 0.004); // side shade
            // Nail on each post
            scene.add.circle(px, y - 3, 1, tc(0x3a3a3a)).setDepth(d + 0.006);
            scene.add.circle(px, y + 3, 1, tc(0x3a3a3a)).setDepth(d + 0.006);
        }
        
        // Horizontal rails (2) with top highlight and front face
        scene.add.rectangle(x, y - 3, 52, 3, tc(woodColor)).setDepth(d + 0.002);
        scene.add.rectangle(x, y - 4, 50, 1, tc(IsoRenderer.lighten(woodColor, 0.1))).setDepth(d + 0.0025);
        scene.add.rectangle(x, y + 3, 52, 3, tc(woodColor)).setDepth(d + 0.002);
        scene.add.rectangle(x, y + 2, 50, 1, tc(IsoRenderer.lighten(woodColor, 0.1))).setDepth(d + 0.0025);
        // Rail side edges
        scene.add.rectangle(x + 26, y - 3, 1, 3, tc(IsoRenderer.darken(woodColor, 0.2))).setDepth(d + 0.003);
        scene.add.rectangle(x + 26, y + 3, 1, 3, tc(IsoRenderer.darken(woodColor, 0.2))).setDepth(d + 0.003);
        
        // Wood grain on rails
        scene.add.rectangle(x - 10, y - 3, 12, 1, tc(IsoRenderer.darken(woodColor, 0.05)), 0.25).setDepth(d + 0.0022);
        scene.add.rectangle(x + 8, y + 3, 10, 1, tc(IsoRenderer.darken(woodColor, 0.05)), 0.25).setDepth(d + 0.0022);
        
        // Weathering — missing slat section or crack
        if (Math.random() < 0.3) {
            const gapX = x + Phaser.Math.Between(-15, 15);
            scene.add.rectangle(gapX, y + 3, 8, 3, tc(0x2a2a28), 0.5).setDepth(d + 0.002);
        }
        
        scene.addWall(x, y, 60, 8, woodColor, false);
    },
    
    createLampPost(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const poleColor = 0x333333;
        
        // Shadow
        this._shadow(scene, x, y + 22, 16, d);
        
        // Base plate
        scene.add.rectangle(x, y + 20, 10, 4, tc(IsoRenderer.darken(poleColor, 0.15))).setDepth(d + 0.001);
        scene.add.rectangle(x, y + 18, 8, 2, tc(poleColor)).setDepth(d + 0.002);
        
        // Pole — tapered
        scene.add.rectangle(x, y + 10, 5, 16, tc(poleColor)).setDepth(d + 0.003);
        scene.add.rectangle(x, y - 5, 4, 16, tc(poleColor)).setDepth(d + 0.003);
        scene.add.rectangle(x, y - 18, 3, 12, tc(poleColor)).setDepth(d + 0.003);
        // Pole highlight
        scene.add.rectangle(x - 2, y, 1, 36, tc(IsoRenderer.lighten(poleColor, 0.15)), 0.4).setDepth(d + 0.004);
        
        // Arm (horizontal, extending right)
        scene.add.rectangle(x + 4, y - 26, 10, 3, tc(poleColor)).setDepth(d + 0.005);
        // Arm curve brace
        scene.add.rectangle(x + 2, y - 24, 3, 5, tc(IsoRenderer.darken(poleColor, 0.1))).setDepth(d + 0.004);
        
        // Lamp head
        scene.add.rectangle(x + 8, y - 28, 12, 4, tc(0x555555)).setDepth(d + 0.006);
        scene.add.rectangle(x + 8, y - 30, 10, 2, tc(IsoRenderer.lighten(0x555555, 0.2))).setDepth(d + 0.007);
        // Lamp lens (bottom)
        scene.add.rectangle(x + 8, y - 25, 8, 2, tc(0x6a6a5a)).setDepth(d + 0.007);
        
        // Light glow at night
        if (CONFIG.timeOfDay === 'night' || CONFIG.timeOfDay === 'dusk') {
            scene.add.circle(x + 8, y - 20, 8, 0xffffaa, 0.08).setDepth(d + 0.008);
            scene.add.circle(x, y + 10, 25, 0xffffaa, 0.12).setDepth(3);
            // Ground light pool
            scene.add.ellipse(x, y + 20, 40, 20, 0xffffaa, 0.06).setDepth(3);
        }
        
        scene.addWall(x, y + 20, 8, 8, poleColor, false);
    },
    
    createSignPost(scene, x, y) {
        const d = 10 + y * 0.01;
        IsoRenderer.pole(scene, x, y, 4, 32, 0x555555, { depth: d });
        // Sign board: small cube on top
        IsoRenderer.cube(scene, x, y - 28, 20, 4, 10, 0x335533, { depth: d + 0.01, noShadow: true });
        scene.addWall(x, y + 15, 8, 8, 0x555555, false);
    },
    
    createBarrier(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const barColor = 0xdd6622;
        
        // Shadow
        this._shadow(scene, x, y + 8, 50, d);
        
        // Body — front face (angled profile — wider at base)
        scene.add.rectangle(x, y + 3, 46, 8, tc(barColor)).setDepth(d + 0.001);
        // Body — top surface (narrower, lighter)
        scene.add.rectangle(x, y - 2, 44, 6, tc(IsoRenderer.lighten(barColor, 0.12))).setDepth(d + 0.002);
        scene.add.rectangle(x, y - 4, 42, 2, tc(IsoRenderer.lighten(barColor, 0.18))).setDepth(d + 0.0025);
        // Side face
        scene.add.rectangle(x + 23, y + 1, 3, 12, tc(IsoRenderer.darken(barColor, 0.2))).setDepth(d + 0.003);
        // Left edge highlight
        scene.add.rectangle(x - 23, y + 1, 1, 10, tc(IsoRenderer.lighten(barColor, 0.06))).setDepth(d + 0.003);
        // Base lip
        scene.add.rectangle(x, y + 7, 46, 2, tc(IsoRenderer.darken(barColor, 0.08))).setDepth(d - 0.005);
        
        // White reflective stripes (front face)
        scene.add.rectangle(x, y + 4, 42, 3, tc(0xeeeeee)).setDepth(d + 0.004);
        // Stripe segments (dashed orange over white)
        for (let sx = x - 18; sx <= x + 18; sx += 12) {
            scene.add.rectangle(sx, y + 4, 8, 3, tc(0xdd6622)).setDepth(d + 0.005);
        }
        
        // Top edge reflectors with highlight
        scene.add.rectangle(x - 15, y - 4, 4, 2, tc(0xffaa44), 0.4).setDepth(d + 0.004);
        scene.add.rectangle(x + 15, y - 4, 4, 2, tc(0xffaa44), 0.4).setDepth(d + 0.004);
        scene.add.rectangle(x - 15, y - 4, 2, 1, tc(0xffcc66), 0.3).setDepth(d + 0.0045);
        scene.add.rectangle(x + 15, y - 4, 2, 1, tc(0xffcc66), 0.3).setDepth(d + 0.0045);
        
        // Water-fill holes (top)
        scene.add.circle(x - 10, y - 3, 2, tc(IsoRenderer.darken(barColor, 0.2))).setDepth(d + 0.004);
        scene.add.circle(x + 10, y - 3, 2, tc(IsoRenderer.darken(barColor, 0.2))).setDepth(d + 0.004);
        // Fill caps
        scene.add.circle(x - 10, y - 3, 1, tc(0x3a3a3a)).setDepth(d + 0.005);
        scene.add.circle(x + 10, y - 3, 1, tc(0x3a3a3a)).setDepth(d + 0.005);
        
        // Scuff marks / damage
        scene.add.rectangle(x + 8, y + 5, 6, 2, tc(0x333333), 0.2).setDepth(d + 0.004);
        if (Math.random() < 0.4) scene.add.rectangle(x - 12, y + 3, 5, 1, tc(0x444444), 0.2).setDepth(d + 0.004);
        
        scene.addWall(x, y, 50, 12, barColor, false);
    },
    
    createShoppingCart(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const wireColor = 0x888888;
        
        // Shadow
        this._shadow(scene, x, y + 12, 20, d);
        
        // Wheels (4 small)
        scene.add.circle(x - 5, y + 10, 2, tc(0x2a2a2a)).setDepth(d - 0.005);
        scene.add.circle(x + 5, y + 10, 2, tc(0x2a2a2a)).setDepth(d - 0.005);
        scene.add.circle(x - 5, y + 5, 2, tc(0x2a2a2a)).setDepth(d - 0.005);
        scene.add.circle(x + 5, y + 5, 2, tc(0x2a2a2a)).setDepth(d - 0.005);
        
        // Cart frame (wireframe look — use thin rects)
        // Bottom rack
        scene.add.rectangle(x, y + 8, 14, 1, tc(wireColor)).setDepth(d + 0.001);
        // Front face (wire grid)
        scene.add.rectangle(x, y + 3, 14, 10, tc(wireColor), 0).setStrokeStyle(1, tc(wireColor), 0.5).setDepth(d + 0.002);
        // Wire grid lines
        scene.add.rectangle(x, y + 1, 12, 1, tc(wireColor), 0.3).setDepth(d + 0.003);
        scene.add.rectangle(x, y + 5, 12, 1, tc(wireColor), 0.3).setDepth(d + 0.003);
        scene.add.rectangle(x - 3, y + 3, 1, 8, tc(wireColor), 0.3).setDepth(d + 0.003);
        scene.add.rectangle(x + 3, y + 3, 1, 8, tc(wireColor), 0.3).setDepth(d + 0.003);
        
        // Top rim
        scene.add.rectangle(x, y - 2, 14, 2, tc(IsoRenderer.lighten(wireColor, 0.1))).setDepth(d + 0.004);
        
        // Handle bar
        scene.add.rectangle(x, y + 11, 12, 2, tc(0x555555)).setDepth(d + 0.005);
        // Handle grip
        scene.add.rectangle(x, y + 12, 8, 2, tc(0x333333)).setDepth(d + 0.006);
        
        // Child seat flap (folded down)
        scene.add.rectangle(x, y - 1, 10, 2, tc(IsoRenderer.darken(wireColor, 0.15))).setDepth(d + 0.004);
        
        // Random item inside (sometimes)
        if (Math.random() < 0.4) {
            scene.add.rectangle(x + 1, y + 2, 5, 4, tc(0x554433), 0.4).setDepth(d + 0.005);
        }
    },
    
    

    
    createNewspaperBox(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const boxColor = 0x2244aa;
        
        // Shadow
        this._shadow(scene, x, y + 10, 16, d);
        
        // Body front face
        scene.add.rectangle(x, y + 2, 12, 12, tc(boxColor)).setDepth(d + 0.001);
        // Top surface (lighter)
        scene.add.rectangle(x, y - 5, 12, 6, tc(IsoRenderer.lighten(boxColor, 0.12))).setDepth(d + 0.002);
        scene.add.rectangle(x, y - 7, 10, 2, tc(IsoRenderer.lighten(boxColor, 0.18))).setDepth(d + 0.0025);
        // Side face (right, darker)
        scene.add.rectangle(x + 6, y, 3, 14, tc(IsoRenderer.darken(boxColor, 0.2))).setDepth(d + 0.003);
        // Left edge highlight
        scene.add.rectangle(x - 6, y + 1, 1, 12, tc(IsoRenderer.lighten(boxColor, 0.06))).setDepth(d + 0.003);
        
        // Viewing window (front) with frame
        scene.add.rectangle(x - 1, y + 1, 8, 6, tc(0x1a1a2a)).setDepth(d + 0.004);
        scene.add.rectangle(x - 1, y + 1, 7, 5, tc(0x2a2a3a), 0.4).setDepth(d + 0.005); // glass
        scene.add.rectangle(x - 1, y + 1, 6, 4, tc(0x3a3a4a), 0.2).setDepth(d + 0.0055); // glass reflection
        // Newspaper stack visible inside
        scene.add.rectangle(x - 1, y + 2, 5, 3, tc(0xddddcc), 0.3).setDepth(d + 0.005);
        scene.add.rectangle(x - 2, y + 3, 4, 1, tc(0xccccbb), 0.2).setDepth(d + 0.0052); // second paper
        
        // Coin slot
        scene.add.rectangle(x - 1, y + 6, 4, 1, tc(0x1a1a1a)).setDepth(d + 0.004);
        scene.add.circle(x + 2, y + 6, 1, tc(0x2a2a2a)).setDepth(d + 0.005); // coin return
        // Handle with bracket
        scene.add.rectangle(x - 1, y - 1, 6, 2, tc(0x3a3a3a)).setDepth(d + 0.004);
        scene.add.rectangle(x - 1, y - 1, 4, 1, tc(0x5a5a5a)).setDepth(d + 0.005); // handle highlight
        
        // Label/masthead plate
        scene.add.rectangle(x - 1, y - 3, 8, 3, tc(0xdddddd), 0.25).setDepth(d + 0.004);
        scene.add.rectangle(x - 1, y - 3, 6, 2, tc(0xcccccc), 0.15).setDepth(d + 0.0045); // text line
        
        // Feet with front face
        scene.add.rectangle(x - 4, y + 9, 3, 2, tc(0x1a1a3a)).setDepth(d - 0.005);
        scene.add.rectangle(x + 4, y + 9, 3, 2, tc(0x1a1a3a)).setDepth(d - 0.005);
        // Weathering
        scene.add.ellipse(x + 2, y + 5, 3, 2, tc(0x1a2a6a), 0.2).setDepth(d + 0.0015);
        
        scene.addWall(x, y, 14, 14, boxColor, false);
    },
    
    createFireHydrant(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const bodyColor = 0xcc2222;
        
        // Shadow
        this._shadow(scene, x, y + 8, 16, d);
        
        // Base (wider)
        scene.add.rectangle(x, y + 5, 10, 5, tc(IsoRenderer.darken(bodyColor, 0.15))).setDepth(d + 0.001);
        scene.add.rectangle(x, y + 3, 12, 2, tc(IsoRenderer.darken(bodyColor, 0.1))).setDepth(d + 0.002);
        
        // Main barrel body
        scene.add.rectangle(x, y - 1, 9, 10, tc(bodyColor)).setDepth(d + 0.003);
        // Side highlight
        scene.add.rectangle(x - 4, y - 1, 2, 10, tc(IsoRenderer.lighten(bodyColor, 0.15))).setDepth(d + 0.004);
        // Side shadow
        scene.add.rectangle(x + 4, y - 1, 2, 10, tc(IsoRenderer.darken(bodyColor, 0.2))).setDepth(d + 0.004);
        
        // Bonnet (top dome)
        scene.add.ellipse(x, y - 7, 11, 5, tc(IsoRenderer.lighten(bodyColor, 0.1))).setDepth(d + 0.005);
        // Nut on top
        scene.add.ellipse(x, y - 8, 5, 2, tc(IsoRenderer.lighten(bodyColor, 0.2))).setDepth(d + 0.006);
        scene.add.circle(x, y - 8, 2, tc(0x8a2222)).setDepth(d + 0.007);
        
        // Nozzles (left and right)
        scene.add.rectangle(x - 7, y - 2, 5, 3, tc(0xaa1a1a)).setDepth(d + 0.005);
        scene.add.rectangle(x + 7, y - 2, 5, 3, tc(0xaa1a1a)).setDepth(d + 0.005);
        // Nozzle caps
        scene.add.circle(x - 9, y - 2, 2, tc(IsoRenderer.lighten(0xaa1a1a, 0.1))).setDepth(d + 0.006);
        scene.add.circle(x + 9, y - 2, 2, tc(IsoRenderer.lighten(0xaa1a1a, 0.1))).setDepth(d + 0.006);
        // Operating nut (pentagonal — approximate with circle)
        scene.add.circle(x, y - 3, 2, tc(0x8a1a1a)).setDepth(d + 0.005);
        
        // Chain (hanging from nozzle)
        scene.add.rectangle(x - 9, y, 1, 4, tc(0x3a3a3a), 0.5).setDepth(d + 0.005);
        
        // Paint chips
        scene.add.rectangle(x + 2, y + 1, 3, 2, tc(0x9a6a4a), 0.3).setDepth(d + 0.004);
        
        scene.addWall(x, y, 12, 14, bodyColor, false);
    },
    
    createTree(scene, x, y, type = 'leafy') {
        const shadowOffsetX = Math.cos(scene.lighting.shadowAngle) * 20 * scene.lighting.shadowLength;
        const shadowOffsetY = Math.sin(scene.lighting.shadowAngle) * 10 * scene.lighting.shadowLength;
        const shadowAlpha = 0.12 + scene.lighting.intensity * 0.25; // 0.20 night → 0.37 midday
        const trunkDepth = 10 + (y + 10) * 0.01;   // trunk at base Y
        const canopyDepth = 10 + (y - 20) * 0.01;   // canopy at top — same Y-sort
        
        // Shadow — core + halo for soft edge
        const sx = x + shadowOffsetX;
        const sy = y + 18 + Math.abs(shadowOffsetY);
        const sw = 28 + Math.abs(shadowOffsetX) * 0.4;
        const sh = sw * 0.25;
        scene.add.ellipse(sx, sy, sw * 1.4, sh * 1.5, 0x000000, shadowAlpha * 0.3).setDepth(2.9);
        scene.add.ellipse(sx, sy, sw, sh, 0x000000, shadowAlpha).setDepth(3);
        
        if (type === 'pine') {
            const trunkColor = scene.tintColor(0x4a3520, scene.lighting.ambient, scene.lighting.intensity);
            const pine1 = scene.tintColor(0x1a3a1a, scene.lighting.ambient, scene.lighting.intensity);
            const pine2 = scene.tintColor(0x2a4a2a, scene.lighting.ambient, scene.lighting.intensity);
            const pine3 = scene.tintColor(0x3a5a3a, scene.lighting.ambient, scene.lighting.intensity);
            
            // Trunk
            scene.add.rectangle(x, y + 14, 8, 12, trunkColor).setDepth(trunkDepth);
            // Canopy layers — high depth for walk-under
            const c1 = scene.add.rectangle(x, y + 5, 28, 8, pine1).setDepth(canopyDepth + 0.001);
            const c2 = scene.add.rectangle(x, y - 2, 22, 8, pine1).setDepth(canopyDepth + 0.001);
            const c3 = scene.add.rectangle(x, y - 9, 16, 8, pine2).setDepth(canopyDepth + 0.002);
            const c4 = scene.add.rectangle(x, y - 15, 10, 6, pine3).setDepth(canopyDepth + 0.003);
            const c5 = scene.add.rectangle(x, y - 19, 4, 4, pine3).setDepth(canopyDepth + 0.004);
            
            // Track canopy for transparency
            if (!scene.occludables) scene.occludables = [];
            scene.occludables.push({ parts: [c1, c2, c3, c4, c5], x, y: y - 5, w: 30, h: 30, baseAlpha: 1 });
            
        } else if (type === 'dead') {
            const barkColor = scene.tintColor(0x3a3028, scene.lighting.ambient, scene.lighting.intensity);
            const barkDark = scene.tintColor(0x2a2018, scene.lighting.ambient, scene.lighting.intensity);
            
            scene.add.rectangle(x, y + 5, 10, 30, barkColor).setDepth(trunkDepth);
            const b1 = scene.add.rectangle(x - 12, y - 8, 18, 4, barkDark).setAngle(-25).setDepth(canopyDepth + 0.001);
            const b2 = scene.add.rectangle(x + 11, y - 4, 16, 4, barkDark).setAngle(20).setDepth(canopyDepth + 0.001);
            const b3 = scene.add.rectangle(x - 8, y - 16, 12, 3, barkDark).setAngle(-40).setDepth(canopyDepth + 0.002);
            const b4 = scene.add.rectangle(x + 7, y - 14, 10, 3, barkDark).setAngle(35).setDepth(canopyDepth + 0.002);
            
            if (!scene.occludables) scene.occludables = [];
            scene.occludables.push({ parts: [b1, b2, b3, b4], x, y: y - 8, w: 30, h: 24, baseAlpha: 1 });
            
        } else if (type === 'converted') {
            // Anomalous biome — Cube-converted tree, metallic trunk with geometric plate canopy
            const metalTrunk = scene.tintColor(0x7a7a80, scene.lighting.ambient, scene.lighting.intensity);
            const metalDark = scene.tintColor(0x5a5a65, scene.lighting.ambient, scene.lighting.intensity);
            const metalHighlight = scene.tintColor(0x9a9aa0, scene.lighting.ambient, scene.lighting.intensity);
            const plateCyan = scene.tintColor(0x4a6a6a, scene.lighting.ambient, scene.lighting.intensity);
            const plateLight = scene.tintColor(0x6a8a8a, scene.lighting.ambient, scene.lighting.intensity);
            const plateDark = scene.tintColor(0x3a5a5a, scene.lighting.ambient, scene.lighting.intensity);
            const glowCyan = scene.tintColor(0x8aaacc, scene.lighting.ambient, scene.lighting.intensity);
            const rootBrown = scene.tintColor(0x5a4a3a, scene.lighting.ambient, scene.lighting.intensity);
            
            // Transition zone at base — still organic brown fading up to metal
            scene.add.rectangle(x, y + 19, 10, 4, rootBrown).setDepth(trunkDepth - 0.001);
            
            // Exposed chrome roots breaking through soil
            scene.add.rectangle(x - 6, y + 20, 8, 2, metalTrunk, 0.5).setAngle(-15).setDepth(trunkDepth - 0.002);
            scene.add.rectangle(x + 5, y + 21, 7, 2, metalDark, 0.4).setAngle(12).setDepth(trunkDepth - 0.002);
            
            // Trunk — metallic, segmented like chitin plates
            scene.add.rectangle(x, y + 12, 10, 18, metalTrunk).setDepth(trunkDepth);
            // Segmentation lines
            scene.add.rectangle(x, y + 6, 10, 1, metalDark, 0.4).setDepth(trunkDepth + 0.001);
            scene.add.rectangle(x, y + 12, 10, 1, metalDark, 0.4).setDepth(trunkDepth + 0.001);
            scene.add.rectangle(x, y + 18, 10, 1, metalDark, 0.4).setDepth(trunkDepth + 0.001);
            // Chrome highlight on left face
            scene.add.rectangle(x - 4, y + 10, 2, 16, metalHighlight, 0.4).setDepth(trunkDepth + 0.002);
            // Dark shadow on right face
            scene.add.rectangle(x + 4, y + 10, 2, 16, metalDark, 0.5).setDepth(trunkDepth + 0.002);
            
            // Canopy — angular geometric plates instead of organic foliage
            // Each plate has a top highlight edge and bottom gap line
            const platePositions = [
                { dx: 0, dy: -8, w: 14, h: 6 },    // center
                { dx: -8, dy: -5, w: 12, h: 5 },    // left low
                { dx: 8, dy: -6, w: 12, h: 5 },     // right low
                { dx: -5, dy: -13, w: 10, h: 5 },   // left high
                { dx: 5, dy: -12, w: 10, h: 5 },    // right high
                { dx: 0, dy: -17, w: 8, h: 4 },     // top center
                { dx: -12, dy: -9, w: 8, h: 4 },    // far left
                { dx: 12, dy: -10, w: 8, h: 4 },    // far right
            ];
            const canopyParts = [];
            for (const p of platePositions) {
                // Main plate body
                const plate = scene.add.rectangle(x + p.dx, y + p.dy, p.w, p.h, plateCyan).setDepth(canopyDepth + 0.001);
                canopyParts.push(plate);
                // Top highlight edge
                scene.add.rectangle(x + p.dx, y + p.dy - Math.floor(p.h / 2), p.w - 2, 1, plateLight, 0.4).setDepth(canopyDepth + 0.002);
                // Bottom dark gap line
                scene.add.rectangle(x + p.dx, y + p.dy + Math.floor(p.h / 2), p.w, 1, plateDark, 0.5).setDepth(canopyDepth + 0.002);
            }
            
            // Faint cyan underglow beneath canopy
            scene.add.ellipse(x, y + 4, 28, 10, glowCyan, 0.04).setDepth(trunkDepth - 0.003);
            
            if (!scene.occludables) scene.occludables = [];
            scene.occludables.push({ parts: canopyParts, x, y: y - 8, w: 30, h: 28, baseAlpha: 1 });
            
        } else {
            const trunkColor = scene.tintColor(0x4a3a2a, scene.lighting.ambient, scene.lighting.intensity);
            const canopy1 = scene.tintColor(0x2a5a2a, scene.lighting.ambient, scene.lighting.intensity);
            const canopy2 = scene.tintColor(0x3a6a3a, scene.lighting.ambient, scene.lighting.intensity);
            const canopy3 = scene.tintColor(0x4a7a4a, scene.lighting.ambient, scene.lighting.intensity);
            
            // Trunk
            scene.add.rectangle(x, y + 12, 10, 18, trunkColor).setDepth(trunkDepth);
            // Canopy — separate high-depth objects
            const e1 = scene.add.ellipse(x, y - 4, 34, 30, canopy1).setDepth(canopyDepth + 0.001);
            const e2 = scene.add.ellipse(x + 3, y - 6, 26, 24, canopy2).setDepth(canopyDepth + 0.002);
            const e3 = scene.add.ellipse(x - 3, y - 8, 18, 16, canopy3).setDepth(canopyDepth + 0.003);
            
            if (!scene.occludables) scene.occludables = [];
            scene.occludables.push({ parts: [e1, e2, e3], x, y: y - 4, w: 36, h: 32, baseAlpha: 1 });
        }
        
        // Tiny trunk-base collision only — allows walking under canopy
        scene.addWall(x, y + 14, 8, 8, 0x2a3a2a, false);
    },
    
    createBench(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const woodColor = 0x4a3a2a;
        const metalColor = 0x3a3a3a;
        
        // Shadow
        scene.add.ellipse(x + 1, y + 8, 34, 6, 0x000000, 0.15).setDepth(d - 0.01);
        
        // Metal frame legs (2 A-frame supports)
        scene.add.rectangle(x - 10, y + 5, 3, 8, tc(metalColor)).setDepth(d - 0.005);
        scene.add.rectangle(x + 10, y + 5, 3, 8, tc(metalColor)).setDepth(d - 0.005);
        // Leg feet
        scene.add.rectangle(x - 10, y + 9, 5, 2, tc(metalColor)).setDepth(d - 0.005);
        scene.add.rectangle(x + 10, y + 9, 5, 2, tc(metalColor)).setDepth(d - 0.005);
        // Cross brace
        scene.add.rectangle(x, y + 6, 16, 1, tc(metalColor)).setDepth(d - 0.004);
        
        // Seat planks (3 slats)
        scene.add.rectangle(x, y + 1, 30, 3, tc(woodColor)).setDepth(d + 0.001);
        scene.add.rectangle(x, y + 1, 28, 1, tc(IsoRenderer.lighten(woodColor, 0.1))).setDepth(d + 0.002);
        scene.add.rectangle(x, y - 2, 30, 3, tc(IsoRenderer.lighten(woodColor, 0.05))).setDepth(d + 0.001);
        scene.add.rectangle(x, y - 2, 28, 1, tc(IsoRenderer.lighten(woodColor, 0.12))).setDepth(d + 0.002);
        
        // Seat front edge (depth)
        scene.add.rectangle(x, y + 3, 30, 2, tc(IsoRenderer.darken(woodColor, 0.15))).setDepth(d + 0.003);
        // Side edge
        scene.add.rectangle(x + 15, y, 2, 6, tc(IsoRenderer.darken(woodColor, 0.2))).setDepth(d + 0.003);
        
        // Backrest (2 slats)
        scene.add.rectangle(x, y - 5, 30, 2, tc(woodColor)).setDepth(d + 0.004);
        scene.add.rectangle(x, y - 8, 30, 2, tc(IsoRenderer.lighten(woodColor, 0.08))).setDepth(d + 0.004);
        // Backrest top highlight
        scene.add.rectangle(x, y - 9, 28, 1, tc(IsoRenderer.lighten(woodColor, 0.15))).setDepth(d + 0.005);
        
        // Armrests (on supports)
        scene.add.rectangle(x - 12, y - 3, 4, 2, tc(metalColor)).setDepth(d + 0.005);
        scene.add.rectangle(x + 12, y - 3, 4, 2, tc(metalColor)).setDepth(d + 0.005);
        
        // Bolt heads
        scene.add.circle(x - 10, y, 1, tc(0x4a4a4a)).setDepth(d + 0.003);
        scene.add.circle(x + 10, y, 1, tc(0x4a4a4a)).setDepth(d + 0.003);
    },
    
    // ===== ANOMALOUS BIOME PROPS =====
    
    createCrystalSpire(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const bodyColor = 0x5a6a7a;
        const glowColor = 0x8aaacc;
        
        // Ground crack/emergence point
        scene.add.ellipse(x, y + 6, 12, 5, tc(0x1a1020), 0.5).setDepth(d - 0.01);
        // Ground glow
        scene.add.ellipse(x, y + 7, 18, 7, tc(glowColor), 0.06).setDepth(d - 0.02);
        
        // Shadow
        scene.add.ellipse(x + 3, y + 8, 10, 4, 0x000000, 0.2).setDepth(d - 0.01);
        
        // Main crystal body — front face dominant (north-facing), tapers up
        scene.add.rectangle(x, y - 4, 6, 20, tc(bodyColor), 0.8).setDepth(d + 0.001);
        // Narrower top section
        scene.add.rectangle(x, y - 14, 4, 8, tc(IsoRenderer.lighten(bodyColor, 0.1)), 0.85).setDepth(d + 0.002);
        // Point
        scene.add.rectangle(x, y - 19, 2, 4, tc(IsoRenderer.lighten(bodyColor, 0.15)), 0.9).setDepth(d + 0.003);
        
        // Left highlight edge — light catching facet
        scene.add.rectangle(x - 3, y - 6, 1, 18, tc(glowColor), 0.25).setDepth(d + 0.004);
        // Right dark edge
        scene.add.rectangle(x + 3, y - 4, 1, 16, tc(IsoRenderer.darken(bodyColor, 0.3)), 0.5).setDepth(d + 0.004);
        
        // Top facet (thin strip for ¾ view)
        scene.add.rectangle(x, y - 21, 3, 2, tc(glowColor), 0.3).setDepth(d + 0.005);
        
        // Satellite crystals at base
        scene.add.rectangle(x + 4, y + 1, 2, 6, tc(bodyColor), 0.6).setDepth(d + 0.001);
        scene.add.rectangle(x - 3, y + 2, 2, 5, tc(bodyColor), 0.5).setDepth(d + 0.001);
        
        // Cyan vein lines on surface
        scene.add.rectangle(x - 1, y - 8, 1, 10, tc(glowColor), 0.15).setDepth(d + 0.005);
        scene.add.rectangle(x + 1, y - 2, 1, 6, tc(glowColor), 0.12).setDepth(d + 0.005);
        
        scene.addWall(x, y, 8, 10, bodyColor, false);
    },
    
    createCubeNode(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const cubeColor = 0x1a1a2a;
        const lineColor = 0x6a9abb;
        
        // Corrected ground — flat, smooth circle beneath
        scene.add.ellipse(x, y + 4, 18, 8, tc(0x1a1a20), 0.3).setDepth(d - 0.02);
        // Shadow (hovering so shadow is offset)
        scene.add.ellipse(x, y + 5, 10, 4, 0x000000, 0.25).setDepth(d - 0.01);
        
        // Cube body — front face
        scene.add.rectangle(x, y - 1, 8, 8, tc(cubeColor)).setDepth(d + 0.001);
        // Top face (foreshortened)
        scene.add.rectangle(x, y - 6, 8, 3, tc(IsoRenderer.lighten(cubeColor, 0.08))).setDepth(d + 0.002);
        // Right side face
        scene.add.rectangle(x + 4, y - 2, 2, 9, tc(IsoRenderer.darken(cubeColor, 0.15))).setDepth(d + 0.003);
        
        // Cyan edge lines — geometric precision
        scene.add.rectangle(x - 4, y - 1, 1, 8, tc(lineColor), 0.3).setDepth(d + 0.004);
        scene.add.rectangle(x + 4, y - 1, 1, 8, tc(lineColor), 0.2).setDepth(d + 0.004);
        scene.add.rectangle(x, y - 5, 8, 1, tc(lineColor), 0.25).setDepth(d + 0.004);
        scene.add.rectangle(x, y + 3, 8, 1, tc(lineColor), 0.2).setDepth(d + 0.004);
        // Top face edges
        scene.add.rectangle(x, y - 7, 9, 1, tc(lineColor), 0.3).setDepth(d + 0.005);
        
        // Faint ambient glow
        scene.add.ellipse(x, y, 16, 14, tc(lineColor), 0.04).setDepth(d - 0.03);
        
        scene.addWall(x, y, 10, 10, cubeColor, false);
    },
    
    createOrganPillar(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const fleshColor = 0x4a2030;
        const veinColor = 0x6a3040;
        
        // Shadow
        scene.add.ellipse(x + 2, y + 10, 14, 5, 0x000000, 0.25).setDepth(d - 0.01);
        
        // Base bulge
        scene.add.ellipse(x, y + 6, 12, 6, tc(IsoRenderer.darken(fleshColor, 0.15))).setDepth(d + 0.001);
        
        // Main body — layered rings visible from front
        scene.add.rectangle(x, y - 2, 8, 16, tc(fleshColor), 0.9).setDepth(d + 0.002);
        // Slightly wider midsection
        scene.add.rectangle(x, y, 10, 8, tc(fleshColor), 0.85).setDepth(d + 0.002);
        
        // Outer lighter layer
        scene.add.rectangle(x - 4, y - 2, 2, 14, tc(IsoRenderer.lighten(fleshColor, 0.12)), 0.6).setDepth(d + 0.003);
        scene.add.rectangle(x + 4, y - 2, 2, 14, tc(IsoRenderer.darken(fleshColor, 0.15)), 0.6).setDepth(d + 0.003);
        
        // Veins running vertically
        scene.add.rectangle(x - 1, y - 4, 1, 12, tc(veinColor), 0.4).setDepth(d + 0.004);
        scene.add.rectangle(x + 2, y - 2, 1, 10, tc(veinColor), 0.3).setDepth(d + 0.004);
        
        // Open ragged top
        scene.add.ellipse(x, y - 10, 10, 4, tc(IsoRenderer.darken(fleshColor, 0.3))).setDepth(d + 0.005);
        scene.add.ellipse(x, y - 10, 6, 2, tc(0x1a0a10), 0.6).setDepth(d + 0.006); // dark interior
        
        // Faint pulse glow at base
        scene.add.ellipse(x, y + 7, 14, 5, tc(veinColor), 0.06).setDepth(d - 0.02);
        
        scene.addWall(x, y, 10, 14, fleshColor, false);
    },
    
    createCorruptedLamp(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const metalColor = 0x555555;
        const growthColor = 0x4a3050;
        const glowColor = 0x7a9abb;
        
        // Shadow
        scene.add.ellipse(x + 2, y + 20, 10, 4, 0x000000, 0.15).setDepth(d - 0.01);
        
        // Lower pole — normal metal
        scene.add.rectangle(x, y + 10, 3, 18, tc(metalColor)).setDepth(d + 0.001);
        scene.add.rectangle(x + 1, y + 10, 1, 18, tc(IsoRenderer.darken(metalColor, 0.2))).setDepth(d + 0.002);
        // Access panel
        scene.add.rectangle(x, y + 14, 4, 5, tc(IsoRenderer.darken(metalColor, 0.1))).setDepth(d + 0.003);
        
        // Transition point — organic meets metal
        scene.add.ellipse(x, y, 6, 4, tc(growthColor), 0.7).setDepth(d + 0.004);
        
        // Upper section — biomechanical growth replacing lamp
        scene.add.rectangle(x, y - 6, 4, 10, tc(growthColor), 0.8).setDepth(d + 0.005);
        // Bulbous growth where lamp housing was
        scene.add.ellipse(x, y - 12, 10, 8, tc(growthColor), 0.7).setDepth(d + 0.006);
        scene.add.ellipse(x, y - 12, 7, 5, tc(IsoRenderer.lighten(growthColor, 0.1)), 0.5).setDepth(d + 0.007);
        
        // Cold blue light emission
        scene.add.ellipse(x, y - 12, 6, 4, tc(glowColor), 0.3).setDepth(d + 0.008);
        // Light cast on ground
        scene.add.ellipse(x, y + 8, 20, 10, tc(glowColor), 0.04).setDepth(d - 0.03);
        
        scene.addWall(x, y, 6, 8, metalColor, false);
    },
    
    createFungalCluster(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const capColor = 0x6a8a8a;
        const glowColor = 0x8ababa;
        const stalkColor = 0x4a5a5a;
        
        // Ground glow
        scene.add.ellipse(x, y + 4, 22, 10, tc(glowColor), 0.05).setDepth(d - 0.02);
        // Shadow
        scene.add.ellipse(x + 1, y + 5, 18, 6, 0x000000, 0.15).setDepth(d - 0.01);
        
        // 4-6 mushroom forms in a ring
        const count = 4 + Math.floor(Math.random() * 3);
        for (let i = 0; i < count; i++) {
            const angle = (i / count) * Math.PI * 2;
            const dist = 4 + Math.random() * 4;
            const fx = x + Math.cos(angle) * dist;
            const fy = y + Math.sin(angle) * dist * 0.5; // foreshorten
            const capW = 3 + Math.floor(Math.random() * 3);
            const capH = capW - 1;
            const stalkH = 3 + Math.floor(Math.random() * 4);
            
            // Stalk
            scene.add.rectangle(fx, fy - stalkH/2 + 1, 1, stalkH, tc(stalkColor), 0.5).setDepth(d + 0.001 + i * 0.0001);
            // Cap — hexagonal read (wider than tall)
            scene.add.rectangle(fx, fy - stalkH, capW, capH, tc(capColor), 0.6).setDepth(d + 0.002 + i * 0.0001);
            // Glow on cap
            scene.add.rectangle(fx, fy - stalkH, capW - 1, capH - 1, tc(glowColor), 0.2).setDepth(d + 0.003 + i * 0.0001);
        }
        
        // No collision — small enough to walk through
    },
    
    createCephalonShrine(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const stoneColor = 0x4a4a4a;
        const candleColor = 0xddaa44;
        const cubeColor = 0x1a1a2a;
        const lineColor = 0x6a9abb;
        
        // Shadow
        scene.add.ellipse(x + 2, y + 10, 24, 8, 0x000000, 0.2).setDepth(d - 0.01);
        
        // Base slab — overturned table/flat stone
        scene.add.rectangle(x, y + 3, 20, 6, tc(stoneColor)).setDepth(d + 0.001);
        scene.add.rectangle(x, y - 1, 20, 4, tc(IsoRenderer.lighten(stoneColor, 0.1))).setDepth(d + 0.002); // top surface
        scene.add.rectangle(x + 10, y + 1, 2, 8, tc(IsoRenderer.darken(stoneColor, 0.2))).setDepth(d + 0.003);
        
        // Arranged geometric objects on top — cube fragments
        scene.add.rectangle(x - 4, y - 3, 4, 4, tc(cubeColor)).setDepth(d + 0.004);
        scene.add.rectangle(x - 4, y - 5, 4, 2, tc(IsoRenderer.lighten(cubeColor, 0.1))).setDepth(d + 0.005);
        scene.add.rectangle(x - 4, y - 4, 4, 1, tc(lineColor), 0.2).setDepth(d + 0.006);
        
        // Crystal piece
        scene.add.rectangle(x + 3, y - 4, 3, 6, tc(0x5a6a7a), 0.7).setDepth(d + 0.004);
        scene.add.rectangle(x + 2, y - 5, 1, 5, tc(0x8aaacc), 0.2).setDepth(d + 0.005);
        
        // Bent metal angular shape
        scene.add.rectangle(x, y - 3, 2, 5, tc(0x6a6a6a), 0.6).setDepth(d + 0.004);
        
        // Candle stubs around the arrangement
        const candlePositions = [[-8, 1], [8, 1], [-6, -6], [6, -6]];
        for (const [cdx, cdy] of candlePositions) {
            scene.add.rectangle(x + cdx, y + cdy, 2, 3, tc(0xddddcc), 0.5).setDepth(d + 0.007);
            // Wax pool
            scene.add.ellipse(x + cdx, y + cdy + 2, 4, 2, tc(0xccccaa), 0.2).setDepth(d + 0.001);
        }
        
        scene.addWall(x, y, 22, 14, stoneColor, false);
    },
    
    // ===== WASTELAND BIOME PROPS =====
    
    createBleachedSkeleton(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const boneColor = 0xddddcc;
        const boneDark = 0xbbbbaa;
        
        // Shadow beneath
        scene.add.ellipse(x, y + 2, 20, 6, 0x000000, 0.1).setDepth(d - 0.01);
        
        // Ribcage — curved bones visible from ¾ (lying on side)
        for (let r = 0; r < 5; r++) {
            const rx = x - 6 + r * 3;
            scene.add.rectangle(rx, y - 2 - r * 0.3, 1, 6 + r * 0.5, tc(boneColor), 0.7)
                .setAngle(-10 + r * 3).setDepth(d + 0.002);
        }
        // Spine — horizontal line of vertebrae
        scene.add.rectangle(x, y + 2, 16, 2, tc(boneDark), 0.6).setDepth(d + 0.001);
        
        // Skull — facing camera
        scene.add.ellipse(x - 8, y + 1, 5, 4, tc(boneColor), 0.8).setDepth(d + 0.003);
        scene.add.ellipse(x - 8, y, 3, 2, tc(IsoRenderer.darken(boneColor, 0.15)), 0.5).setDepth(d + 0.004); // eye socket
        
        // Hip/pelvis
        scene.add.ellipse(x + 6, y + 2, 4, 3, tc(boneDark), 0.6).setDepth(d + 0.002);
        
        // Leg bones trailing
        scene.add.rectangle(x + 9, y + 3, 8, 1, tc(boneColor), 0.5).setAngle(15).setDepth(d + 0.001);
        scene.add.rectangle(x + 10, y + 1, 7, 1, tc(boneColor), 0.4).setAngle(-10).setDepth(d + 0.001);
        
        // No collision — ground-level
    },
    
    createRockCairn(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const rockColor = 0x6a6055;
        
        // Shadow
        scene.add.ellipse(x + 1, y + 6, 12, 4, 0x000000, 0.15).setDepth(d - 0.01);
        
        // Bottom stones (wider base)
        scene.add.ellipse(x - 2, y + 3, 8, 4, tc(rockColor)).setDepth(d + 0.001);
        scene.add.ellipse(x + 2, y + 2, 7, 3, tc(IsoRenderer.darken(rockColor, 0.1))).setDepth(d + 0.002);
        // Middle stones
        scene.add.ellipse(x, y - 1, 6, 3, tc(IsoRenderer.lighten(rockColor, 0.05))).setDepth(d + 0.003);
        scene.add.ellipse(x - 1, y - 3, 5, 3, tc(rockColor)).setDepth(d + 0.004);
        // Top stone
        scene.add.ellipse(x, y - 5, 4, 2, tc(IsoRenderer.lighten(rockColor, 0.1))).setDepth(d + 0.005);
        
        scene.addWall(x, y, 8, 8, rockColor, false);
    },
    
    createAbandonedTent(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const fabricColor = 0x8a8070; // sun-bleached tan
        
        // Shadow
        scene.add.ellipse(x + 1, y + 6, 22, 8, 0x000000, 0.12).setDepth(d - 0.01);
        
        // Collapsed tent body — dome shape, one side deflated
        // Standing half (one pole still arched)
        scene.add.ellipse(x - 3, y, 12, 8, tc(fabricColor), 0.6).setDepth(d + 0.002);
        scene.add.ellipse(x - 3, y - 1, 10, 6, tc(IsoRenderer.lighten(fabricColor, 0.08)), 0.5).setDepth(d + 0.003);
        // Collapsed half — flat on ground
        scene.add.ellipse(x + 5, y + 2, 10, 4, tc(IsoRenderer.darken(fabricColor, 0.1)), 0.5).setDepth(d + 0.001);
        
        // Pole stub sticking up
        scene.add.rectangle(x - 3, y - 5, 1, 5, tc(0x555555), 0.6).setDepth(d + 0.004);
        // Broken pole on ground
        scene.add.rectangle(x + 6, y + 3, 6, 1, tc(0x555555), 0.3).setAngle(20).setDepth(d + 0.001);
        
        // Entry flap — open
        scene.add.rectangle(x + 1, y + 1, 4, 4, tc(IsoRenderer.darken(fabricColor, 0.25)), 0.4).setDepth(d + 0.002);
        
        // Boot outside entrance
        scene.add.rectangle(x + 4, y + 4, 3, 2, tc(0x3a3025), 0.5).setDepth(d + 0.003);
        
        scene.addWall(x, y, 18, 10, fabricColor, false);
    },
    
    createDriedWellhead(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const metalColor = 0x6a5a4a;
        
        // Shadow
        scene.add.ellipse(x + 2, y + 8, 14, 5, 0x000000, 0.15).setDepth(d - 0.01);
        
        // Base plate — concrete pad
        scene.add.rectangle(x, y + 5, 14, 4, tc(0x5a5a55)).setDepth(d + 0.001);
        scene.add.rectangle(x, y + 3, 14, 2, tc(0x6a6a65)).setDepth(d + 0.002); // top surface
        
        // Pump body — front face dominant
        scene.add.rectangle(x, y - 2, 6, 10, tc(metalColor)).setDepth(d + 0.003);
        scene.add.rectangle(x + 3, y - 2, 1, 10, tc(IsoRenderer.darken(metalColor, 0.2))).setDepth(d + 0.004);
        
        // Spout — extends forward
        scene.add.rectangle(x, y + 1, 8, 2, tc(metalColor)).setDepth(d + 0.005);
        // Spout opening
        scene.add.rectangle(x + 4, y + 1, 2, 3, tc(IsoRenderer.darken(metalColor, 0.15))).setDepth(d + 0.006);
        
        // Handle — up position (frozen by rust)
        scene.add.rectangle(x - 1, y - 8, 8, 2, tc(metalColor)).setDepth(d + 0.007);
        scene.add.rectangle(x + 3, y - 8, 2, 2, tc(IsoRenderer.lighten(metalColor, 0.1))).setDepth(d + 0.008); // grip
        
        // Rust streaks
        scene.add.rectangle(x - 1, y + 1, 2, 4, tc(0x7a4a2a), 0.2).setDepth(d + 0.004);
        
        // Empty bucket below spout
        scene.add.ellipse(x + 1, y + 6, 6, 3, tc(0x5a5040), 0.4).setDepth(d + 0.002);
        
        scene.addWall(x, y, 10, 12, metalColor, false);
    },
    
    createBarbedWire(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const wireColor = 0x6a6a6a;
        
        // Chaotic nest of wire loops on ground
        const loops = 5 + Math.floor(Math.random() * 4);
        for (let i = 0; i < loops; i++) {
            const lx = x + Phaser.Math.Between(-6, 6);
            const ly = y + Phaser.Math.Between(-3, 3);
            const lw = Phaser.Math.Between(6, 12);
            const lh = Phaser.Math.Between(3, 6);
            scene.add.ellipse(lx, ly, lw, lh, tc(wireColor), 0).setDepth(d + 0.001 + i * 0.0001)
                .setStrokeStyle(1, tc(wireColor), 0.4);
        }
        // Barb points — small bright dots
        for (let b = 0; b < 6; b++) {
            const bx = x + Phaser.Math.Between(-7, 7);
            const by = y + Phaser.Math.Between(-3, 3);
            scene.add.circle(bx, by, 1, tc(IsoRenderer.lighten(wireColor, 0.3)), 0.5).setDepth(d + 0.003);
        }
        // Fence post stump nearby
        scene.add.rectangle(x - 8, y + 1, 3, 5, tc(0x5a4a3a), 0.4).setDepth(d + 0.001);
        
        // No collision — low profile ground tangle
    },
    
    createCollapsedBillboard(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const metalColor = 0x5a5a5a;
        const signColor = 0x6a6a60;
        
        // Shadow
        scene.add.ellipse(x, y + 5, 34, 8, 0x000000, 0.12).setDepth(d - 0.01);
        
        // Sign face — on the ground, face down (showing back structure)
        scene.add.rectangle(x, y + 1, 30, 8, tc(signColor), 0.5).setDepth(d + 0.001);
        // Structural beams on back (visible from ¾)
        scene.add.rectangle(x - 8, y, 2, 8, tc(metalColor), 0.6).setDepth(d + 0.002);
        scene.add.rectangle(x + 8, y, 2, 8, tc(metalColor), 0.6).setDepth(d + 0.002);
        scene.add.rectangle(x, y - 1, 20, 1, tc(metalColor), 0.5).setDepth(d + 0.002); // cross brace
        
        // Support leg sticking up at angle
        scene.add.rectangle(x + 14, y - 6, 2, 14, tc(metalColor), 0.5).setAngle(25).setDepth(d + 0.003);
        
        // Corner of sign face visible — fragment of advertisement
        scene.add.rectangle(x - 12, y + 3, 6, 4, tc(0x8a7a5a), 0.3).setDepth(d + 0.003);
        
        scene.addWall(x, y, 32, 10, signColor, false);
    },

    // ===== OVERGROWN BIOME PROPS =====
    
    createCollapsedFence(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const woodColor = 0x6a6058;
        const woodDark = 0x4a4038;
        const vineColor = 0x3a5a2a;
        const vineLight = 0x4a6a3a;
        
        // Shadow
        scene.add.ellipse(x, y + 6, 34, 8, 0x000000, 0.12).setDepth(d - 0.01);
        
        // Left standing panel — north-facing, front face dominant
        scene.add.rectangle(x - 10, y - 2, 10, 14, tc(woodColor)).setDepth(d + 0.001);
        // Plank lines
        scene.add.rectangle(x - 13, y - 2, 1, 14, tc(woodDark), 0.3).setDepth(d + 0.002);
        scene.add.rectangle(x - 8, y - 2, 1, 14, tc(woodDark), 0.3).setDepth(d + 0.002);
        // Top edge weathered
        scene.add.rectangle(x - 10, y - 9, 10, 1, tc(IsoRenderer.lighten(woodColor, 0.08))).setDepth(d + 0.003);
        // Green mold from base climbing up
        scene.add.rectangle(x - 10, y + 3, 10, 4, tc(vineColor), 0.25).setDepth(d + 0.003);
        
        // Right standing panel
        scene.add.rectangle(x + 2, y - 1, 10, 12, tc(woodColor)).setDepth(d + 0.001);
        scene.add.rectangle(x, y - 1, 1, 12, tc(woodDark), 0.3).setDepth(d + 0.002);
        scene.add.rectangle(x + 5, y - 1, 1, 12, tc(woodDark), 0.3).setDepth(d + 0.002);
        scene.add.rectangle(x + 2, y + 3, 10, 3, tc(vineColor), 0.2).setDepth(d + 0.003);
        
        // Fallen panel — forward toward camera, angled
        scene.add.rectangle(x + 14, y + 4, 12, 6, tc(IsoRenderer.darken(woodColor, 0.1)), 0.7).setAngle(15).setDepth(d + 0.004);
        scene.add.rectangle(x + 14, y + 3, 1, 5, tc(woodDark), 0.2).setAngle(15).setDepth(d + 0.005);
        
        // Grass growing through gap between panels
        scene.add.rectangle(x - 3, y + 4, 3, 4, tc(vineLight), 0.3).setDepth(d + 0.001);
        
        // Cross rail visible on standing panels
        scene.add.rectangle(x - 4, y, 24, 2, tc(woodDark), 0.4).setDepth(d + 0.0005);
        
        scene.addWall(x - 4, y, 28, 10, woodColor, false);
    },
    
    createRustedSwingSet(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const metalColor = 0x7a5a3a;
        const metalDark = 0x5a3a1a;
        const chainColor = 0x4a4a4a;
        const grassColor = 0x3a5a2a;
        
        // Shadow
        scene.add.ellipse(x, y + 12, 32, 8, 0x000000, 0.12).setDepth(d - 0.01);
        
        // A-frame legs — north-facing, front face visible
        // Left leg pair
        scene.add.rectangle(x - 10, y + 4, 3, 22, tc(metalColor)).setAngle(-6).setDepth(d + 0.001);
        scene.add.rectangle(x - 8, y + 4, 2, 22, tc(metalDark)).setAngle(4).setDepth(d + 0.0005);
        // Right leg pair
        scene.add.rectangle(x + 10, y + 4, 3, 22, tc(metalColor)).setAngle(6).setDepth(d + 0.001);
        scene.add.rectangle(x + 8, y + 4, 2, 22, tc(metalDark)).setAngle(-4).setDepth(d + 0.0005);
        
        // Crossbar at top
        scene.add.rectangle(x, y - 10, 24, 3, tc(metalColor)).setDepth(d + 0.002);
        // Rust patches on crossbar
        scene.add.rectangle(x + 4, y - 10, 6, 2, tc(0x6a3a1a), 0.3).setDepth(d + 0.003);
        
        // Left swing — intact, chains + seat
        scene.add.rectangle(x - 5, y - 8, 1, 14, tc(chainColor), 0.5).setDepth(d + 0.003);
        scene.add.rectangle(x - 3, y - 8, 1, 14, tc(chainColor), 0.5).setDepth(d + 0.003);
        // Seat
        scene.add.rectangle(x - 4, y + 5, 6, 2, tc(0x2a2a2a)).setDepth(d + 0.004);
        
        // Right swing — broken chain, seat dragging
        scene.add.rectangle(x + 5, y - 8, 1, 10, tc(chainColor), 0.4).setDepth(d + 0.003);
        // Broken chain hangs shorter
        scene.add.rectangle(x + 3, y - 6, 1, 6, tc(chainColor), 0.3).setDepth(d + 0.003);
        // Seat on the ground, dragging
        scene.add.rectangle(x + 5, y + 10, 6, 2, tc(0x2a2a2a), 0.5).setAngle(10).setDepth(d + 0.001);
        
        // Tall grass at base
        for (let g = 0; g < 4; g++) {
            const gx = x - 12 + g * 8 + Math.random() * 4;
            scene.add.rectangle(gx, y + 10, 2, 5 + Math.random() * 3, tc(grassColor), 0.3).setDepth(d - 0.005);
        }
        
        scene.addWall(x, y + 8, 24, 8, metalColor, false);
    },
    
    createBirdBath(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const stoneColor = 0x8a8a7a;
        const stoneDark = 0x6a6a5a;
        const waterColor = 0x3a5a4a;
        
        // Shadow
        scene.add.ellipse(x + 1, y + 6, 12, 4, 0x000000, 0.12).setDepth(d - 0.01);
        
        // Pedestal — front face dominant, ¾ view
        scene.add.rectangle(x, y + 3, 4, 10, tc(stoneColor)).setDepth(d + 0.001);
        // Pedestal side highlight
        scene.add.rectangle(x - 2, y + 3, 1, 10, tc(IsoRenderer.lighten(stoneColor, 0.08)), 0.5).setDepth(d + 0.002);
        // Pedestal base wider
        scene.add.rectangle(x, y + 8, 8, 3, tc(stoneDark)).setDepth(d + 0.001);
        
        // Crack running up pedestal
        scene.add.rectangle(x + 1, y + 2, 1, 7, tc(IsoRenderer.darken(stoneColor, 0.2)), 0.3).setDepth(d + 0.003);
        
        // Bowl — visible from ¾ as an ellipse (looking slightly down into it)
        scene.add.ellipse(x, y - 3, 10, 5, tc(stoneDark)).setDepth(d + 0.004);
        // Bowl rim highlight
        scene.add.ellipse(x, y - 3, 10, 5, tc(IsoRenderer.lighten(stoneColor, 0.1)), 0.3).setDepth(d + 0.005);
        // Stagnant water inside
        scene.add.ellipse(x, y - 2, 7, 3, tc(waterColor), 0.5).setDepth(d + 0.006);
        // Leaf floating in water
        scene.add.ellipse(x + 1, y - 2, 2, 1, tc(0x5a6a2a), 0.4).setDepth(d + 0.007);
        
        // Tilted slightly — base shifting in soft ground
        scene.add.ellipse(x + 2, y + 9, 4, 2, tc(0x3a4a2a), 0.15).setDepth(d - 0.005); // soil displacement
        
        scene.addWall(x, y, 8, 12, stoneColor, false);
    },
    
    createChildBicycle(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const frameColor = 0xcc8899; // faded pink
        const wheelColor = 0x3a3a3a;
        const grassColor = 0x3a5a2a;
        
        // Shadow
        scene.add.ellipse(x, y + 3, 14, 4, 0x000000, 0.1).setDepth(d - 0.01);
        
        // Bike on its side — ¾ view shows frame lying flat
        // Front wheel — bent
        scene.add.circle(x - 4, y, 3, tc(wheelColor), 0.6).setDepth(d + 0.002);
        scene.add.circle(x - 4, y, 2, tc(0x1a1a1a), 0.2).setDepth(d + 0.003); // hub
        // Back wheel
        scene.add.circle(x + 4, y + 1, 3, tc(wheelColor), 0.5).setDepth(d + 0.002);
        scene.add.circle(x + 4, y + 1, 2, tc(0x1a1a1a), 0.2).setDepth(d + 0.003);
        
        // Frame connecting wheels — faded pink
        scene.add.rectangle(x, y, 8, 2, tc(frameColor), 0.5).setDepth(d + 0.004);
        // Handlebar
        scene.add.rectangle(x - 5, y - 1, 4, 1, tc(0x4a4a4a), 0.5).setAngle(-20).setDepth(d + 0.005);
        // Seat
        scene.add.rectangle(x + 3, y - 1, 3, 2, tc(0x2a2a2a), 0.4).setDepth(d + 0.005);
        
        // Training wheels — still attached
        scene.add.circle(x + 3, y + 3, 1, tc(wheelColor), 0.4).setDepth(d + 0.001);
        scene.add.circle(x + 5, y + 3, 1, tc(wheelColor), 0.4).setDepth(d + 0.001);
        
        // Basket with rotted stuffed animal — dark lump
        scene.add.rectangle(x - 6, y - 1, 3, 2, tc(0x5a4a3a), 0.3).setDepth(d + 0.006);
        
        // Tall grass taller than the bike
        for (let g = 0; g < 3; g++) {
            const gx = x - 5 + g * 5;
            scene.add.rectangle(gx, y - 2 - Math.random() * 2, 1, 6 + Math.random() * 3, tc(grassColor), 0.25).setDepth(d + 0.008);
        }
        
        // No collision — ground level, small
    },
    
    createClotheslinePost(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const metalColor = 0x5a5a5a;
        const metalDark = 0x3a3a3a;
        
        // Shadow
        scene.add.ellipse(x + 1, y + 8, 10, 4, 0x000000, 0.1).setDepth(d - 0.01);
        
        // Concrete base pad — cracked
        scene.add.rectangle(x, y + 7, 6, 3, tc(0x7a7a72)).setDepth(d - 0.005);
        scene.add.rectangle(x + 1, y + 7, 1, 3, tc(0x5a5a52), 0.3).setDepth(d - 0.004); // crack
        
        // Vertical post — thin, front face visible
        scene.add.rectangle(x, y - 4, 3, 20, tc(metalColor)).setDepth(d + 0.001);
        // Side highlight
        scene.add.rectangle(x - 1, y - 4, 1, 20, tc(IsoRenderer.lighten(metalColor, 0.1)), 0.3).setDepth(d + 0.002);
        
        // T-crosspiece at top
        scene.add.rectangle(x, y - 14, 10, 2, tc(metalColor)).setDepth(d + 0.003);
        
        // Sagging clothesline — thin lines
        scene.add.rectangle(x - 3, y - 12, 1, 4, tc(0x4a4a3a), 0.2).setDepth(d + 0.004); // line sag
        scene.add.rectangle(x + 3, y - 12, 1, 4, tc(0x4a4a3a), 0.2).setDepth(d + 0.004);
        
        // Sun-bleached shirt hanging stiff — visible garment
        scene.add.rectangle(x - 2, y - 11, 5, 5, tc(0x8a8a82), 0.5).setDepth(d + 0.005);
        // Shirt sleeves
        scene.add.rectangle(x - 5, y - 11, 3, 2, tc(0x8a8a82), 0.35).setAngle(-15).setDepth(d + 0.005);
        scene.add.rectangle(x + 1, y - 11, 3, 2, tc(0x7a7a72), 0.35).setAngle(10).setDepth(d + 0.005);
        
        scene.addWall(x, y + 4, 4, 6, metalColor, false);
    },
    
    createIvyWall(scene, x, y) {
        const d = 10 + y * 0.01;
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const brickColor = 0x8a5a4a;
        const brickDark = 0x6a3a2a;
        const ivyColor = 0x2a5a2a;
        const ivyLight = 0x3a6a3a;
        const ivyDark = 0x1a4a1a;
        
        // Shadow
        scene.add.ellipse(x, y + 8, 28, 6, 0x000000, 0.15).setDepth(d - 0.01);
        
        // Brick wall — north-facing, front face dominant
        scene.add.rectangle(x, y - 1, 22, 16, tc(brickColor)).setDepth(d + 0.001);
        // Brick pattern — horizontal mortar lines
        for (let row = 0; row < 4; row++) {
            scene.add.rectangle(x, y - 7 + row * 4, 22, 1, tc(brickDark), 0.2).setDepth(d + 0.002);
        }
        // Vertical mortar — staggered
        for (let col = 0; col < 3; col++) {
            const cx = x - 8 + col * 8;
            scene.add.rectangle(cx, y - 3, 1, 8, tc(brickDark), 0.15).setDepth(d + 0.002);
            scene.add.rectangle(cx + 4, y + 1, 1, 8, tc(brickDark), 0.15).setDepth(d + 0.002);
        }
        
        // Top edge — ragged, torn wall
        scene.add.rectangle(x - 4, y - 9, 6, 2, tc(brickColor), 0.6).setDepth(d + 0.003);
        scene.add.rectangle(x + 6, y - 8, 4, 1, tc(brickColor), 0.4).setDepth(d + 0.003);
        // Missing bricks at top right
        scene.add.rectangle(x + 8, y - 7, 3, 3, tc(0x1a1a1a), 0.1).setDepth(d + 0.001);
        
        // Side face — thin depth
        scene.add.rectangle(x + 11, y, 2, 16, tc(IsoRenderer.darken(brickColor, 0.2))).setDepth(d + 0.004);
        // Top surface — very thin foreshortened strip
        scene.add.rectangle(x, y - 9, 22, 2, tc(IsoRenderer.lighten(brickColor, 0.05))).setDepth(d + 0.005);
        
        // Dense ivy coverage — overlapping patches
        // Bottom half climbing up
        scene.add.ellipse(x - 3, y + 4, 14, 8, tc(ivyColor), 0.6).setDepth(d + 0.006);
        scene.add.ellipse(x + 4, y + 2, 10, 6, tc(ivyDark), 0.5).setDepth(d + 0.006);
        // Mid coverage
        scene.add.ellipse(x - 5, y - 1, 8, 6, tc(ivyLight), 0.45).setDepth(d + 0.007);
        scene.add.ellipse(x + 2, y - 2, 12, 5, tc(ivyColor), 0.4).setDepth(d + 0.007);
        // Sparse tendrils reaching top
        scene.add.rectangle(x - 6, y - 6, 3, 4, tc(ivyLight), 0.25).setDepth(d + 0.008);
        scene.add.rectangle(x + 5, y - 5, 2, 3, tc(ivyColor), 0.2).setDepth(d + 0.008);
        
        // Exposed brick patches — gaps in ivy
        scene.add.rectangle(x + 3, y + 3, 4, 3, tc(0x9a6a5a), 0.3).setDepth(d + 0.0055);
        scene.add.rectangle(x - 7, y - 4, 3, 4, tc(0x8a5a4a), 0.25).setDepth(d + 0.0055);
        
        // Ivy trailing over top edge
        scene.add.rectangle(x - 2, y - 10, 6, 2, tc(ivyColor), 0.3).setDepth(d + 0.009);
        
        scene.addWall(x, y, 24, 14, brickColor, false);
    },

    // ══════════ OVERGROWN ROUND 2 ══════════
    
    createDoghouse(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // A-frame body — north-facing: front face (14w × 8h), thin roof top
        scene.add.rectangle(x, y, 14, 8, tc(0x6a5a3a)).setDepth(d);
        // Roof (two slants meeting at ridge)
        const g = scene.add.graphics().setDepth(d + 0.01);
        g.fillStyle(tc(0x5a4a2a), 1);
        g.beginPath(); g.moveTo(x - 8, y - 2); g.lineTo(x, y - 8); g.lineTo(x + 8, y - 2); g.closePath(); g.fillPath();
        // Arch entrance (dark)
        g.fillStyle(tc(0x1a1510), 0.8);
        g.beginPath(); g.arc(x, y + 2, 4, Math.PI, 0, false); g.fillPath();
        g.fillRect(x - 4, y + 2, 8, 2);
        // Chain trailing from side
        g.lineStyle(1, tc(0x666655), 0.4);
        g.lineBetween(x + 6, y + 1, x + 12, y + 3); g.lineBetween(x + 12, y + 3, x + 14, y + 5);
    },

    createGuttedFridge(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // Body — north-facing: front face (12w × 20h)
        scene.add.rectangle(x, y - 4, 12, 20, tc(0x7a7a7a)).setDepth(d);
        // Interior (dark, doors removed)
        scene.add.rectangle(x, y - 4, 10, 18, tc(0x2a2a2a)).setDepth(d + 0.01);
        // Wire shelves (3 horizontal lines)
        const g = scene.add.graphics().setDepth(d + 0.02);
        g.lineStyle(1, tc(0x666666), 0.5);
        g.lineBetween(x - 4, y - 10, x + 4, y - 10);
        g.lineBetween(x - 4, y - 4, x + 4, y - 4);
        g.lineBetween(x - 4, y + 2, x + 4, y + 2);
        // Rust streaks
        g.lineStyle(1, tc(0x6a4a2a), 0.3);
        g.lineBetween(x - 3, y - 14, x - 4, y - 4); g.lineBetween(x + 2, y - 14, x + 3, y);
        // Debris mass at bottom
        g.fillStyle(tc(0x3a3530), 0.5);
        g.fillEllipse(x, y + 5, 8, 4);
    },

    createPlaygroundSlide(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Ladder (left side) — rungs
        g.fillStyle(tc(0x5a5a5a), 0.8);
        g.fillRect(x - 5, y - 8, 2, 16); g.fillRect(x - 1, y - 8, 2, 16);
        g.lineStyle(1, tc(0x666666), 0.6);
        for (let r = -6; r <= 6; r += 3) g.lineBetween(x - 5, y + r, x + 1, y + r);
        // Platform (top)
        g.fillStyle(tc(0x5a5a55), 0.7);
        g.fillRect(x - 3, y - 10, 10, 3);
        // Slide surface — curving south toward camera
        g.fillStyle(tc(0x6a6a6a), 0.7);
        g.beginPath(); g.moveTo(x + 1, y - 8); g.lineTo(x + 8, y - 8); g.lineTo(x + 8, y + 8); g.lineTo(x + 1, y + 8); g.closePath(); g.fillPath();
        // Rust on slide
        g.fillStyle(tc(0x6a4a2a), 0.25);
        g.fillRect(x + 2, y - 4, 5, 6);
        // Grass at landing
        g.fillStyle(tc(0x3a6a2a), 0.4);
        g.fillEllipse(x + 5, y + 10, 8, 3);
    },

    createLawnChair(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // North-facing: seat back (10w × 8h) with slats, legs splayed
        const g = scene.add.graphics().setDepth(d);
        // Seat
        g.fillStyle(tc(0xaaaaaa), 0.5);
        g.fillRect(x - 5, y, 10, 4);
        // Back (vertical slats)
        g.fillStyle(tc(0x999999), 0.5);
        for (let s = -4; s <= 4; s += 2) g.fillRect(x + s, y - 8, 1, 8);
        // Legs
        g.lineStyle(1, tc(0x888888), 0.5);
        g.lineBetween(x - 4, y + 4, x - 5, y + 7); g.lineBetween(x + 4, y + 4, x + 5, y + 7);
        // Broken armrest
        g.fillStyle(tc(0x999999), 0.3);
        g.fillRect(x + 4, y - 2, 3, 1);
        // Coffee mug on intact armrest
        g.fillStyle(tc(0x6a5a4a), 0.6);
        g.fillRect(x - 6, y - 1, 2, 2);
    },

    createTireStack(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // 3 stacked tires — ¾ view shows front circle faces stacked
        const g = scene.add.graphics().setDepth(d);
        for (let t = 0; t < 3; t++) {
            const ty = y + 4 - t * 4;
            g.fillStyle(tc(0x2a2a2a), 0.8);
            g.fillEllipse(x, ty, 10, 5);
            g.lineStyle(1, tc(0x1a1a1a), 0.4);
            g.strokeEllipse(x, ty, 10, 5);
        }
        // Water pooled in top tire
        g.fillStyle(tc(0x2a3a3a), 0.4);
        g.fillEllipse(x, y - 8, 6, 3);
        // 4th tire leaning against
        g.fillStyle(tc(0x2a2a2a), 0.7);
        g.fillEllipse(x + 8, y + 2, 5, 8);
        // Weeds growing through
        g.lineStyle(1, tc(0x3a6a2a), 0.4);
        g.lineBetween(x, y - 5, x - 2, y - 12); g.lineBetween(x + 1, y - 5, x + 3, y - 11);
    },

    createPorchSteps(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // 3 steps — north-facing: front face of each step visible
        const g = scene.add.graphics().setDepth(d);
        for (let s = 0; s < 3; s++) {
            const sy = y + 4 - s * 4;
            const sw = 14 - s * 1;
            g.fillStyle(tc(0x6a6a65), 0.8);
            g.fillRect(x - sw / 2, sy, sw, 4); // front face
            g.fillStyle(tc(0x7a7a75), 0.5);
            g.fillRect(x - sw / 2, sy - 1, sw, 1); // top strip
        }
        // Railing (leaning outward)
        g.lineStyle(2, tc(0x5a3a2a), 0.6);
        g.lineBetween(x + 8, y + 8, x + 10, y - 8);
        // Faded welcome mat on top step
        g.fillStyle(tc(0x5a4a3a), 0.25);
        g.fillRect(x - 4, y - 5, 8, 3);
    },

    // ══════════ WASTELAND ROUND 2 ══════════

    createCrackedCistern(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Cylindrical tank — ¾ view: front curve (16w × 10h)
        g.fillStyle(tc(0x6a6a65), 0.8);
        g.fillEllipse(x, y, 16, 10);
        g.fillStyle(tc(0x5a5a55), 0.7);
        g.fillRect(x - 8, y - 4, 16, 8);
        // Jagged crack
        g.lineStyle(2, tc(0x2a2520), 0.7);
        g.lineBetween(x + 1, y - 5, x - 1, y); g.lineBetween(x - 1, y, x + 2, y + 5);
        // Interior visible through crack — dry sediment
        g.fillStyle(tc(0x4a4535), 0.4);
        g.fillRect(x - 1, y - 3, 3, 6);
        // Pipe fittings at base
        g.fillStyle(tc(0x5a5a5a), 0.5);
        g.fillRect(x - 7, y + 4, 3, 2); g.fillRect(x + 5, y + 4, 3, 2);
    },

    createDustGenerator(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // Box body — north-facing: front panel (12w × 8h)
        scene.add.rectangle(x, y, 12, 8, tc(0x5a5a52)).setDepth(d);
        // Dust coating (same color as ground)
        scene.add.rectangle(x, y, 12, 8, tc(0x5a5040), 0.3).setDepth(d + 0.01);
        const g = scene.add.graphics().setDepth(d + 0.02);
        // Dials
        g.fillStyle(tc(0x2a2a2a), 0.5);
        g.fillCircle(x - 3, y - 2, 2); g.fillCircle(x + 3, y - 2, 2);
        // Pull-start handle
        g.lineStyle(1, tc(0x4a4a4a), 0.6);
        g.lineBetween(x + 6, y, x + 10, y - 1);
        // Open fuel cap
        g.fillStyle(tc(0x1a1a1a), 0.5);
        g.fillCircle(x - 4, y - 4, 1.5);
        // Exhaust port
        g.fillStyle(tc(0x3a3a3a), 0.5);
        g.fillRect(x + 5, y + 2, 2, 2);
    },

    createTippedPortapotty(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // On its side — showing into dark interior. Exterior faded blue.
        const g = scene.add.graphics().setDepth(d);
        g.fillStyle(tc(0x4a5a6a), 0.5); // faded blue
        g.fillRect(x - 5, y - 6, 10, 14);
        // Interior (dark)
        g.fillStyle(tc(0x1a1a18), 0.7);
        g.fillRect(x - 4, y - 5, 8, 8);
        // Door (open, facing up from tipped position)
        g.fillStyle(tc(0x3a4a5a), 0.6);
        g.fillRect(x - 5, y - 8, 10, 2);
        // Sand scoring on exterior
        g.fillStyle(tc(0x6a6050), 0.2);
        g.fillRect(x - 4, y + 2, 8, 4);
    },

    createExposedFoundation(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Concrete pad — very low profile (28w × 6h)
        g.fillStyle(tc(0x6a6a65), 0.5);
        g.fillRect(x - 14, y - 3, 28, 6);
        // Crumbling edge
        g.fillStyle(tc(0x5a5a55), 0.3);
        g.fillRect(x - 14, y - 3, 2, 6); g.fillRect(x + 12, y - 3, 2, 6);
        // Rebar stubs (short vertical lines emerging from surface)
        g.lineStyle(1, tc(0x5a3a2a), 0.5);
        for (let r = -10; r <= 10; r += 5) {
            g.lineBetween(x + r, y - 3, x + r, y - 6);
        }
        // Sand in corners
        g.fillStyle(tc(0x5a5040), 0.25);
        g.fillEllipse(x - 10, y, 6, 3); g.fillEllipse(x + 10, y + 1, 5, 2);
    },

    createBuriedRoadSign(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Post (leaning 30°)
        g.fillStyle(tc(0x5a5a55), 0.6);
        g.fillRect(x - 1, y - 4, 2, 10);
        // Sign face (half buried in sand)
        // Faded red octagon (stop sign) — simplified as red rectangle
        g.fillStyle(tc(0x7a3a3a), 0.5);
        g.fillRect(x - 4, y - 8, 8, 6);
        g.fillStyle(tc(0x8a5a5a), 0.3);
        g.fillRect(x - 3, y - 6, 6, 2); // faded text area
        // Sand drift covering bottom half of sign
        g.fillStyle(tc(0x5a5040), 0.5);
        g.fillEllipse(x, y + 2, 10, 5);
    },

    createConcreteBarrierWl(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // Jersey barrier — front face (20w × 6h), cracked
        scene.add.rectangle(x, y, 20, 6, tc(0x6a6a65)).setDepth(d);
        scene.add.rectangle(x, y - 3.5, 20, 1, tc(0x7a7a75), 0.5).setDepth(d + 0.01);
        const g = scene.add.graphics().setDepth(d + 0.02);
        // Rebar showing through chip
        g.fillStyle(tc(0x5a3a2a), 0.4);
        g.fillRect(x + 4, y - 2, 3, 3);
        g.lineStyle(1, tc(0x6a4a3a), 0.5);
        g.lineBetween(x + 5, y - 2, x + 5, y + 1);
        // Sand piled against one side
        g.fillStyle(tc(0x5a5040), 0.35);
        g.fillEllipse(x + 8, y + 2, 6, 3);
        scene.addWall(x, y, 20, 8, 0, false);
    },

    // ══════════ ANOMALOUS ROUND 2 ══════════

    createMetallicVine(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Silver branching lines on wall surface (20w × 24h)
        g.fillStyle(tc(0x4a4a50), 0.3);
        g.fillRect(x - 10, y - 12, 20, 24); // wall backdrop
        // Main trunk
        g.lineStyle(2, tc(0x8a8a9a), 0.6);
        g.lineBetween(x, y + 12, x - 1, y + 2); g.lineBetween(x - 1, y + 2, x + 2, y - 6); g.lineBetween(x + 2, y - 6, x - 2, y - 12);
        // Branches — equidistant attachment points
        g.lineStyle(1, tc(0x7a7a8a), 0.5);
        g.lineBetween(x - 1, y + 2, x - 8, y - 2); g.lineBetween(x + 2, y - 6, x + 8, y - 8);
        g.lineBetween(x - 1, y + 6, x + 7, y + 4); g.lineBetween(x - 2, y - 12, x - 7, y - 10);
        // Metal plate leaves
        g.fillStyle(tc(0x9a9aaa), 0.4);
        const leafPos = [{ x: x - 8, y: y - 2 }, { x: x + 8, y: y - 8 }, { x: x + 7, y: y + 4 }, { x: x - 7, y: y - 10 }];
        for (const l of leafPos) {
            g.fillRect(l.x - 2, l.y - 1, 4, 2);
        }
    },

    createShatteredCube(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Scorched circle on ground
        g.fillStyle(tc(0x1a1520), 0.4);
        g.fillEllipse(x, y, 18, 10);
        // Shards — geometric fragments maintaining spatial relationships
        const shards = [
            { dx: -5, dy: -3, w: 4, h: 3 }, { dx: 3, dy: -2, w: 5, h: 3 },
            { dx: -2, dy: 2, w: 3, h: 4 }, { dx: 4, dy: 3, w: 4, h: 2 },
            { dx: -6, dy: 1, w: 3, h: 3 }, { dx: 1, dy: -4, w: 3, h: 2 }
        ];
        for (const s of shards) {
            g.fillStyle(tc(0x1a1525), 0.8);
            g.fillRect(x + s.dx, y + s.dy, s.w, s.h);
            // Cyan fracture edges
            g.lineStyle(1, tc(0x4adfdf), 0.3);
            g.strokeRect(x + s.dx, y + s.dy, s.w, s.h);
        }
    },

    createBoneArch(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Arch — north-facing: curve overhead (16w × 20h)
        g.lineStyle(3, tc(0xaaa8a0), 0.7);
        g.beginPath(); g.arc(x, y + 4, 8, Math.PI, 0, false); g.strokePath();
        // Pillars (fused bone, left and right)
        g.fillStyle(tc(0x9a9890), 0.7);
        g.fillRect(x - 9, y - 2, 3, 12); g.fillRect(x + 6, y - 2, 3, 12);
        // Joint fusion lines
        g.lineStyle(1, tc(0x7a7870), 0.4);
        g.lineBetween(x - 8, y + 2, x - 7, y + 2); g.lineBetween(x + 7, y + 4, x + 8, y + 4);
        g.lineBetween(x - 8, y + 6, x - 7, y + 6); g.lineBetween(x + 7, y + 8, x + 8, y + 8);
        // Ceramic smooth quality — highlight
        g.fillStyle(tc(0xccccbb), 0.1);
        g.fillRect(x - 8, y - 2, 1, 10);
    },

    createSporeTower(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Stalk — segmented (vertebrae-like)
        for (let s = 0; s < 6; s++) {
            const sy = y + 8 - s * 4;
            const sw = 4 - (s > 3 ? 1 : 0);
            g.fillStyle(tc(0x4a3a4a), 0.8);
            g.fillRect(x - sw / 2, sy, sw, 4);
            g.lineStyle(1, tc(0x3a2a3a), 0.3);
            g.lineBetween(x - sw / 2, sy, x + sw / 2, sy);
        }
        // Cap — split open, showing gills
        g.fillStyle(tc(0x5a4a5a), 0.8);
        g.fillEllipse(x, y - 14, 8, 5);
        // Gill underside (radial lines with cyan glow)
        g.lineStyle(1, tc(0x4adfdf), 0.25);
        for (let a = 0; a < Math.PI; a += 0.4) {
            g.lineBetween(x, y - 14, x + Math.cos(a) * 4 - 2, y - 12 + Math.sin(a) * 2);
        }
        // Underglow
        g.fillStyle(tc(0x4adfdf), 0.08);
        g.fillEllipse(x, y - 12, 10, 4);
        // Small fruiting bodies at base
        g.fillStyle(tc(0x4a3a4a), 0.5);
        g.fillEllipse(x - 3, y + 10, 3, 2); g.fillEllipse(x + 4, y + 9, 2, 2);
    },

    createGeometricCrater(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        const g = scene.add.graphics().setDepth(d);
        // Hexagonal depression — clean edges
        g.fillStyle(tc(0x151018), 0.7);
        g.beginPath();
        for (let i = 0; i < 6; i++) {
            const a = (i * Math.PI * 2) / 6 - Math.PI / 6;
            const px = x + Math.cos(a) * 9;
            const py = y + Math.sin(a) * 5;
            if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
        }
        g.closePath(); g.fillPath();
        // Clean edge highlight
        g.lineStyle(1, tc(0x4adfdf), 0.2);
        g.beginPath();
        for (let i = 0; i < 6; i++) {
            const a = (i * Math.PI * 2) / 6 - Math.PI / 6;
            const px = x + Math.cos(a) * 9;
            const py = y + Math.sin(a) * 5;
            if (i === 0) g.moveTo(px, py); else g.lineTo(px, py);
        }
        g.closePath(); g.strokePath();
        // Small crystal at center
        g.fillStyle(tc(0x2a2035), 0.8);
        g.beginPath(); g.moveTo(x - 1, y + 1); g.lineTo(x + 1, y + 1); g.lineTo(x, y - 3); g.closePath(); g.fillPath();
        g.lineStyle(1, tc(0x4adfdf), 0.3);
        g.lineBetween(x + 1, y + 1, x, y - 3);
    },

    createConvertedDumpster(scene, x, y) {
        const tc = (c) => scene.tintColor(c, scene.lighting.ambient, scene.lighting.intensity);
        const d = 10 + y * 0.01;
        // Metal frame visible but overgrown
        scene.add.rectangle(x, y, 16, 10, tc(0x4a5a4a)).setDepth(d);
        const g = scene.add.graphics().setDepth(d + 0.01);
        // Organic growth pushing lid open
        g.fillStyle(tc(0x3a2a3a), 0.7);
        g.fillEllipse(x, y - 6, 12, 5);
        // Crystalline caps on growth
        g.fillStyle(tc(0x4a3a5a), 0.6);
        g.beginPath(); g.moveTo(x - 3, y - 7); g.lineTo(x - 1, y - 12); g.lineTo(x + 1, y - 7); g.closePath(); g.fillPath();
        g.beginPath(); g.moveTo(x + 2, y - 8); g.lineTo(x + 4, y - 14); g.lineTo(x + 6, y - 8); g.closePath(); g.fillPath();
        // Cyan edge on crystals
        g.lineStyle(1, tc(0x4adfdf), 0.3);
        g.lineBetween(x + 1, y - 7, x - 1, y - 12); g.lineBetween(x + 6, y - 8, x + 4, y - 14);
        // Oxidation at contact points
        g.fillStyle(tc(0x6a4a2a), 0.3);
        g.fillEllipse(x - 5, y + 2, 4, 2); g.fillEllipse(x + 5, y + 3, 3, 2);
        scene.addWall(x, y, 16, 12, 0, false);
    },

};

