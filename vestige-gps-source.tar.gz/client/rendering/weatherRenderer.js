// Vestige GPS — WeatherRenderer (Phaser)
// Renders weather particles, overlays, lightning, shimmer
// Consumes effect configs from core/weatherSystem.js
// Usage: const cleanup = WeatherRenderer.render(scene, effectConfig, biomeId);

import { CONFIG } from '../../data/config.js';

// Helper: random int between min and max inclusive
const _between = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const _floatBetween = (min, max) => min + Math.random() * (max - min);

export const WeatherRenderer = {
    render(scene, effectConfig, biomeId) {
        const cleanup = [];
        if (!effectConfig || !effectConfig.config) return () => {};

        const cfg = effectConfig.config;
        const VW = CONFIG.width, VH = CONFIG.height;

        // Overlay tint
        if (cfg.overlay) {
            const ov = scene.add.rectangle(VW/2, VH/2, VW, VH, cfg.overlay.color, cfg.overlay.alpha);
            ov.setScrollFactor(0).setDepth(0.29).setBlendMode(Phaser.BlendModes.MULTIPLY);
            cleanup.push(ov);
        }

        // Particles
        if (cfg.particles) {
            const pc = cfg.particles;
            const particles = [];
            for (let i = 0; i < pc.count; i++) {
                const p = scene.add.circle(
                    _between(0, VW),
                    _between(-20, VH),
                    pc.type === 'rain' ? 1 : _floatBetween(0.8, 2),
                    pc.color, _floatBetween(0.3, 0.7)
                );
                p.setScrollFactor(0).setDepth(0.295);
                if (pc.type === 'rain') p.setScale(0.5, _floatBetween(2, 4));
                p._wx = p.x; p._wy = p.y;
                p._speed = pc.speed * _floatBetween(0.7, 1.3);
                p._drift = pc.type === 'drift' ? _floatBetween(-1, 1) : 
                           pc.type === 'rain' ? _floatBetween(0.3, 0.8) : 0;
                p._type = pc.type;
                particles.push(p);
                cleanup.push(p);
            }
            const timer = scene.time.addEvent({
                delay: 33, loop: true,
                callback: () => {
                    for (const p of particles) {
                        if (p.scene) {
                            if (p._type === 'rain') {
                                p._wy += p._speed;
                                p._wx += p._drift;
                            } else if (p._type === 'snow') {
                                p._wy += p._speed * 0.5;
                                p._wx += Math.sin(p._wy * 0.02 + p._drift) * 0.5;
                            } else {
                                p._wx += p._speed;
                                p._wy += Math.sin(p._wx * 0.01) * 0.3;
                            }
                            if (p._wy > VH + 10) { p._wy = -10; p._wx = _between(0, VW); }
                            if (p._wx > VW + 10) { p._wx = -10; p._wy = _between(0, VH); }
                            if (p._wx < -10) { p._wx = VW + 10; }
                            p.setPosition(p._wx, p._wy);
                        }
                    }
                }
            });
            cleanup.push({ destroy: () => timer.remove() });
        }

        // Lightning flash for storms
        if (cfg.flash) {
            const flashColor = cfg.flashColor || 0xffffff;
            const flashRect = scene.add.rectangle(VW/2, VH/2, VW, VH, flashColor, 0);
            flashRect.setScrollFactor(0).setDepth(0.296);
            cleanup.push(flashRect);
            const flashTimer = scene.time.addEvent({
                delay: _between(8000, 20000), loop: true,
                callback: () => {
                    if (flashRect.scene) {
                        flashRect.setAlpha(0.15);
                        scene.tweens.add({ targets: flashRect, alpha: 0, duration: 200, delay: 80 });
                        if (Math.random() < 0.4) {
                            scene.time.delayedCall(300, () => {
                                if (flashRect.scene) {
                                    flashRect.setAlpha(0.1);
                                    scene.tweens.add({ targets: flashRect, alpha: 0, duration: 150 });
                                }
                            });
                        }
                    }
                }
            });
            cleanup.push({ destroy: () => flashTimer.remove() });
        }

        // Heat shimmer (barren)
        if (cfg.shimmer) {
            const shimmerG = scene.add.graphics().setScrollFactor(0).setDepth(0.294);
            cleanup.push(shimmerG);
            let shimmerT = 0;
            const shimmerTimer = scene.time.addEvent({
                delay: 50, loop: true,
                callback: () => {
                    if (shimmerG.scene) {
                        shimmerT += 0.05;
                        shimmerG.clear();
                        shimmerG.fillStyle(0xffcc88, 0.03);
                        for (let sx = 0; sx < VW; sx += 20) {
                            const sy = VH * 0.3 + Math.sin(shimmerT + sx * 0.05) * 4;
                            shimmerG.fillRect(sx, sy, 18, 2);
                        }
                    }
                }
            });
            cleanup.push({ destroy: () => shimmerTimer.remove() });
        }

        return () => { cleanup.forEach(o => { try { o.destroy(); } catch(e) {} }); };
    }
};
