// Vestige GPS — EnemyAIRenderer (Phaser)
// Phaser primitive proxies + system delegates for enemy AI visual effects
// Wire to core: EnemyAI.init(EnemyAIRenderer)
//
// This renderer is unusual — most methods are thin wrappers around Phaser primitives.
// The core enemyAI calls _circle(), _rect(), _gfx() etc. which proxy through here.
// This lets enemy attack VFX (telegraphs, projectiles, toxic pools) render in Phaser
// while keeping AI logic framework-independent.

import { CONFIG } from '../../data/config.js';
import { EnemyAI } from '../../core/enemyAI.js';
import { SpriteManager } from '../spriteManager.js';
import { TelegraphSystem } from './telegraphSystem.js';

// Telegraph duration defaults (matches TelegraphSystem tiers)
const TELEGRAPH_DURATIONS = { fast: 300, standard: 500, heavy: 800 };

export const EnemyAIRenderer = {
    // === PHASER PRIMITIVE PROXIES ===
    // These return real Phaser game objects that support chaining (.setDepth, .setStrokeStyle, etc.)

    addCircle(scene, x, y, radius, color, alpha, depth) {
        const c = scene.add.circle(x, y, radius, color, alpha ?? 1);
        if (depth !== undefined) c.setDepth(depth);
        return c;
    },

    addRect(scene, x, y, w, h, color, alpha, depth) {
        const r = scene.add.rectangle(x, y, w, h, color, alpha ?? 1);
        if (depth !== undefined) r.setDepth(depth);
        return r;
    },

    addGraphics(scene, depth) {
        const g = scene.add.graphics();
        if (depth !== undefined) g.setDepth(depth);
        return g;
    },

    addLine(scene, x1, y1, x2, y2, color, alpha, depth) {
        const l = scene.add.line(0, 0, x1, y1, x2, y2, color, alpha ?? 1);
        l.setOrigin(0, 0);
        if (depth !== undefined) l.setDepth(depth);
        return l;
    },

    addEllipse(scene, x, y, w, h, color, alpha, depth) {
        const e = scene.add.ellipse(x, y, w, h, color, alpha ?? 1);
        if (depth !== undefined) e.setDepth(depth);
        return e;
    },

    // === TWEEN + CAMERA ===

    tween(scene, config) {
        return scene.tweens.add(config);
    },

    killTweensOf(scene, target) {
        scene.tweens.killTweensOf(target);
    },

    cameraShake(scene, duration, intensity) {
        if (scene.cameras && scene.cameras.main) {
            scene.cameras.main.shake(duration, intensity);
        }
    },

    cameraMain(scene) {
        return scene.cameras && scene.cameras.main
            ? scene.cameras.main
            : { scrollX: 0, scrollY: 0, width: 800, height: 600 };
    },

    // === TELEGRAPH SYSTEM ===

    /**
     * Create a telegraph indicator (danger zone preview).
     * config: { shape, tier, color, source, radius, angle, arc, ... }
     * Returns telegraph object with .destroy()
     */
    telegraph(scene, config) {
        if (!scene._telegraphSystem) {
            // Inline lightweight telegraph if TelegraphSystem not available
            return EnemyAIRenderer._inlineTelegraph(scene, config);
        }
        return scene._telegraphSystem.create(scene, config);
    },

    telegraphDuration(tier) {
        return TELEGRAPH_DURATIONS[tier] || 500;
    },

    // Inline telegraph fallback
    _inlineTelegraph(scene, cfg) {
        const dur = TELEGRAPH_DURATIONS[cfg.tier] || 500;
        const source = cfg.source;
        if (!source) return { destroy() {} };

        const colors = {
            damage: 0xff4444, arcane: 0x8844cc, fire: 0xff6622,
            toxic: 0x44aa33, default: 0xff4444
        };
        const color = colors[cfg.color] || colors.default;

        let gfx;
        if (cfg.shape === 'cone') {
            gfx = scene.add.graphics().setDepth(2);
            const r = cfg.radius || 35;
            const a = cfg.angle || 0;
            const arc = cfg.arc || Math.PI / 2;
            gfx.fillStyle(color, 0.0);

            // Animate fill-in
            scene.tweens.addCounter({
                from: 0, to: 1, duration: dur,
                onUpdate: (tween) => {
                    const v = tween.getValue();
                    gfx.clear();
                    gfx.fillStyle(color, 0.15 * v);
                    gfx.slice(source.x, source.y, r * v, a - arc / 2, a + arc / 2);
                    gfx.fillPath();
                    gfx.lineStyle(1, color, 0.3 * v);
                    gfx.strokePath();
                }
            });
        } else {
            // Circle telegraph
            const r = cfg.radius || 40;
            gfx = scene.add.circle(source.x, source.y, r, color, 0).setDepth(2);
            gfx.setStrokeStyle(1.5, color, 0.4);
            scene.tweens.add({
                targets: gfx, fillAlpha: 0.2,
                duration: dur, ease: 'Cubic.easeIn'
            });
        }

        return {
            destroy() {
                if (gfx && gfx.destroy) gfx.destroy();
            }
        };
    },

    // === SPRITE SYSTEMS ===

    /**
     * Build enemy spritesheet texture if not already present.
     * Delegates to SpriteManager if available on scene.
     */
    buildEnemySheet(scene, enemyType) {
        if (scene._spriteManager && scene._spriteManager.buildEnemySheet) {
            scene._spriteManager.buildEnemySheet(scene, enemyType);
        }
    },

    textureExists(scene, key) {
        return scene.textures ? scene.textures.exists(key) : false;
    },

    animExists(scene, key) {
        return scene.anims ? scene.anims.exists(key) : false;
    },

    /**
     * Enemy hit flash on player — brief screen feedback.
     */
    enemyHitFlash(scene, enemy, target) {
        if (!target || !target.active) return;
        target.setTint(0xff4444);
        scene.time.delayedCall(80, () => {
            if (target.active) {
                if (scene._ambientTint && scene._ambientTint !== 0xffffff) {
                    target.setTint(scene._ambientTint);
                } else {
                    target.clearTint();
                }
            }
        });

        // Brief camera nudge
        if (scene.cameras && scene.cameras.main) {
            scene.cameras.main.shake(40, 0.003);
        }
    },

    /**
     * Restore ambient tint on a sprite (time-of-day aware).
     */
    restoreTint(sprite) {
        if (!sprite || !sprite.active) return;
        if (sprite.scene && sprite.scene._ambientTint && sprite.scene._ambientTint !== 0xffffff) {
            sprite.setTint(sprite.scene._ambientTint);
        } else if (sprite.clearTint) {
            sprite.clearTint();
        }
    },

    /**
     * Play an attack VFX at a position.
     * type: 'light', 'heavy', 'ranged'
     */
    attackVFXPlay(scene, x, y, angle, type) {
        const colors = { light: 0xffcc44, heavy: 0xff6622, ranged: 0x44aaff };
        const color = colors[type] || 0xffffff;
        const size = type === 'heavy' ? 8 : 5;

        const flash = scene.add.circle(x, y, size, color, 0.6).setDepth(50);
        scene.tweens.add({
            targets: flash,
            scaleX: 2, scaleY: 2,
            alpha: 0,
            duration: 150,
            onComplete: () => flash.destroy()
        });
    },

    // === PHYSICS PROXIES ===

    physicsSprite(scene, x, y, key) {
        return scene.physics.add.sprite(x, y, key);
    },

    physicsOverlap(scene, a, b, callback) {
        scene.physics.add.overlap(a, b, callback);
    },

    physicsExisting(scene, obj) {
        scene.physics.add.existing(obj);
    },

    // === SHADOW SYSTEM ===

    shadowAdd(scene, sprite, opts = {}) {
        if (!sprite) return;
        if (scene._dynamicShadows && scene._dynamicShadows.add) {
            scene._dynamicShadows.add(scene, sprite, opts);
        } else {
            // Inline shadow
            const shadow = scene.add.ellipse(
                sprite.x, sprite.y + (opts.offsetY || 4),
                sprite.displayWidth * (opts.scale || 0.4),
                sprite.displayWidth * (opts.scale || 0.4) * 0.4,
                0x000000, opts.alpha || 0.15
            ).setDepth(1);
            sprite._shadow = shadow;
        }
    },

    shadowRemove(scene, sprite) {
        if (!sprite) return;
        if (scene._dynamicShadows && scene._dynamicShadows.remove) {
            scene._dynamicShadows.remove(scene, sprite);
        } else if (sprite._shadow) {
            sprite._shadow.destroy();
            sprite._shadow = null;
        }
    }
};
