// Vestige GPS — Blurbs (Phaser Implementation)
// Floating combat text rendered via Phaser scene
// Wire to core via: Blurbs.init(PhaserBlurbs)

import { CONFIG } from '../../data/config.js';
import { Blurbs } from '../../core/blurbs.js';
import { uiPx } from '../../core/utils.js';

// uiPx must be provided by the client rendering context
let _uiPx = (n) => Math.round(n * 1.4);
export function setUiPx(fn) { _uiPx = fn; }

export const PhaserBlurbs = {
    _playerSide: 1,

    show(scene, entity, text, opts = {}) {
        if (!scene || !entity) return null;
        const color = opts.color || '#ffffff';
        const fontSize = opts.fontSize || 11;
        const duration = opts.duration || 800;
        const rise = opts.rise || 25;
        const depth = opts.depth || 100;
        const bold = opts.bold !== false;
        const offsetY = opts.offsetY || -30;

        const isPlayer = entity === scene.player;

        if (isPlayer) {
            PhaserBlurbs._playerSide *= -1;
        }

        const startOffX = isPlayer ? PhaserBlurbs._playerSide * (8 + Math.random() * 6) : 0;
        const startOffY = isPlayer ? -(10 + Math.random() * 8) : offsetY;

        const txt = scene.add.text(entity.x + startOffX, entity.y + startOffY, text, {
            fontFamily: CONFIG.font, fontSize: _uiPx(fontSize), fill: color,
            fontStyle: bold ? 'bold' : 'normal', stroke: '#000000', strokeThickness: 2
        }).setOrigin(0.5).setDepth(depth);

        if (isPlayer) {
            const driftX = PhaserBlurbs._playerSide * (18 + Math.random() * 14);
            const driftY = -(20 + Math.random() * 12);
            scene.tweens.add({
                targets: txt,
                x: txt.x + driftX,
                y: txt.y + driftY,
                alpha: 0,
                duration: duration,
                ease: 'Power1',
                onComplete: () => txt.destroy()
            });
        } else {
            scene.tweens.add({
                targets: txt,
                y: txt.y - rise,
                alpha: 0,
                duration: duration,
                ease: 'Power1',
                onComplete: () => txt.destroy()
            });
        }
        return txt;
    },

    showPersistent(scene, entity, text, opts = {}) {
        if (!scene || !entity) return null;
        const color = opts.color || '#ffcc44';
        const offsetY = opts.offsetY || -30;

        const txt = scene.add.text(entity.x, entity.y + offsetY, text, {
            fontFamily: CONFIG.font, fontSize: _uiPx(opts.fontSize || 10), fill: color,
            fontStyle: 'bold', stroke: '#000000', strokeThickness: 2
        }).setOrigin(0.5).setDepth(opts.depth || 100);

        scene.tweens.add({
            targets: txt, alpha: { from: 1, to: 0.5 },
            duration: 600, yoyo: true, repeat: -1
        });

        return {
            text: txt,
            update() { if (txt.active) { txt.x = entity.x; txt.y = entity.y + offsetY; } },
            destroy() { if (txt.active) txt.destroy(); }
        };
    }
};
