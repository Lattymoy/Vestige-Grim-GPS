// Vestige GPS — ObjectPool
// Extracted from game_2_.html lines 27296-27371

export const ObjectPool = {
    _pools: {},
    
    // Get or create a pool by name
    _getPool(key) {
        if (!this._pools[key]) this._pools[key] = [];
        return this._pools[key];
    },
    
    // Acquire a rectangle from pool or create new
    rect(scene, x, y, w, h, color, alpha) {
        const pool = this._getPool('rect_' + scene.scene.key);
        let obj = pool.find(o => !o.active);
        if (obj) {
            obj.setPosition(x, y).setSize(w, h).setFillStyle(color, alpha);
            obj.setScale(1).setAngle(0).setAlpha(alpha !== undefined ? alpha : 1);
            obj.setVisible(true).setActive(true).setDepth(0);
            obj.setStrokeStyle();
            return obj;
        }
        obj = scene.add.rectangle(x, y, w, h, color, alpha);
        obj._poolKey = 'rect_' + scene.scene.key;
        pool.push(obj);
        return obj;
    },
    
    // Acquire a circle from pool or create new
    circle(scene, x, y, r, color, alpha) {
        const pool = this._getPool('circ_' + scene.scene.key);
        let obj = pool.find(o => !o.active);
        if (obj) {
            obj.setPosition(x, y).setRadius(r).setFillStyle(color, alpha);
            obj.setScale(1).setAlpha(alpha !== undefined ? alpha : 1);
            obj.setVisible(true).setActive(true).setDepth(0);
            obj.setStrokeStyle();
            return obj;
        }
        obj = scene.add.circle(x, y, r, color, alpha);
        obj._poolKey = 'circ_' + scene.scene.key;
        pool.push(obj);
        return obj;
    },
    
    // Release back to pool instead of destroying
    release(obj) {
        if (!obj) return;
        obj.setVisible(false).setActive(false);
        obj.setPosition(-999, -999);
    },
    
    // Clean up all pools for a scene
    destroyScene(sceneKey) {
        const keys = Object.keys(this._pools).filter(k => k.endsWith(sceneKey));
        for (const key of keys) {
            const pool = this._pools[key];
            for (const obj of pool) {
                if (obj && obj.destroy) obj.destroy();
            }
            delete this._pools[key];
        }
    },
    
    // Stats for debugging
    stats() {
        const result = {};
        for (const key of Object.keys(this._pools)) {
            const pool = this._pools[key];
            result[key] = { total: pool.length, active: pool.filter(o => o.active).length };
        }
        return result;
    }
};

// ============================================
// AUDIO MANAGER — Synthesized Web Audio API SFX (no audio files needed)
// ============================================
