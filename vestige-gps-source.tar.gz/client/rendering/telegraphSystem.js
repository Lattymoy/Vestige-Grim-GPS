// Vestige GPS — TelegraphSystem
// Extracted from monolith L18531-18789

export const TelegraphSystem = {
    // Tier durations — these are the ONLY valid buildup lengths
    TIERS: {
        fast:     { duration: 800 },
        standard: { duration: 1200 },
        heavy:    { duration: 1800 }
    },
    
    // Damage type color palette
    COLORS: {
        physical: { fill: 0xcc4422, stroke: 0xff5533, flash: 0xff8866 },
        fire:     { fill: 0xff6622, stroke: 0xff8833, flash: 0xffcc66 },
        toxic:    { fill: 0x33aa22, stroke: 0x55cc33, flash: 0x88ee55 },
        arcane:   { fill: 0x7744cc, stroke: 0x9966ee, flash: 0xbb99ff },
        neutral:  { fill: 0xcc8844, stroke: 0xddaa55, flash: 0xeedd88 }
    },
    
    // Active telegraphs — cleaned up on scene transition
    _active: [],
    
    /**
     * Create a telegraph. Returns a handle { cancel(), onComplete(fn) }.
     *
     * @param {Phaser.Scene} scene
     * @param {object} opts
     *   shape:    'circle' | 'cone' | 'line'
     *   tier:     'fast' | 'standard' | 'heavy'
     *   color:    'physical' | 'fire' | 'toxic' | 'arcane' | 'neutral'
     *   x, y:     center position (or start position for line)
     *   source:   enemy sprite — if provided, telegraph follows source position (for circle/cone)
     *   radius:   for circle and cone
     *   angle:    for cone and line — direction in radians
     *   arc:      for cone — total sweep angle in radians (e.g. 1.2)
     *   length:   for line — how far the line extends
     *   width:    for line — width of the line corridor (default 6)
     */
    create(scene, opts) {
        const tier = this.TIERS[opts.tier];
        if (!tier) { console.warn('TelegraphSystem: invalid tier', opts.tier); return null; }
        const pal = this.COLORS[opts.color] || this.COLORS.neutral;
        const duration = tier.duration;
        const shape = opts.shape || 'circle';
        
        const gfx = scene.add.graphics().setDepth(2);
        const startTime = scene.time.now;
        let cancelled = false;
        let completeFn = null;
        
        const handle = {
            cancel: () => { cancelled = true; if (evt) evt.destroy(); gfx.destroy(); },
            onComplete: (fn) => { completeFn = fn; },
            gfx: gfx,
            duration: duration,
            startTime: startTime
        };
        
        const evt = scene.time.addEvent({ delay: 33, loop: true, callback: () => {
            if (cancelled) { evt.destroy(); gfx.destroy(); return; }
            const elapsed = scene.time.now - startTime;
            const prog = Math.min(1, elapsed / duration);
            
            // Source tracking — update position if following an enemy
            let cx = opts.x, cy = opts.y;
            if (opts.source && opts.source.active) {
                cx = opts.source.x;
                cy = opts.source.y;
            }
            
            gfx.clear();
            
            if (shape === 'circle') {
                TelegraphSystem._drawCircle(gfx, cx, cy, opts.radius || 40, prog, pal, duration);
            } else if (shape === 'cone') {
                TelegraphSystem._drawCone(gfx, cx, cy, opts.radius || 60, opts.angle || 0, opts.arc || 1.0, prog, pal);
            } else if (shape === 'line') {
                TelegraphSystem._drawLine(gfx, cx, cy, opts.angle || 0, opts.length || 100, opts.width || 6, prog, pal);
            }
            
            // Completion — damage frame
            if (elapsed >= duration) {
                evt.destroy();
                // Flash frame — bright burst then cleanup
                gfx.clear();
                if (shape === 'circle') {
                    gfx.fillStyle(pal.flash, 0.4);
                    gfx.fillCircle(cx, cy, (opts.radius || 40) * 1.05);
                } else if (shape === 'cone') {
                    gfx.fillStyle(pal.flash, 0.35);
                    gfx.beginPath(); gfx.moveTo(cx, cy);
                    const r = (opts.radius || 60) * 1.05, a = opts.angle || 0, arc = opts.arc || 1.0;
                    for (let s = 0; s <= 8; s++) gfx.lineTo(cx + Math.cos(a - arc/2 + (arc/8)*s) * r, cy + Math.sin(a - arc/2 + (arc/8)*s) * r);
                    gfx.closePath(); gfx.fill();
                } else if (shape === 'line') {
                    const a = opts.angle || 0, len = opts.length || 100, w = (opts.width || 6) * 1.5;
                    const perp = a + Math.PI/2;
                    gfx.fillStyle(pal.flash, 0.35);
                    gfx.beginPath();
                    gfx.moveTo(cx + Math.cos(perp)*w/2, cy + Math.sin(perp)*w/2);
                    gfx.lineTo(cx + Math.cos(a)*len + Math.cos(perp)*w/2, cy + Math.sin(a)*len + Math.sin(perp)*w/2);
                    gfx.lineTo(cx + Math.cos(a)*len - Math.cos(perp)*w/2, cy + Math.sin(a)*len - Math.sin(perp)*w/2);
                    gfx.lineTo(cx - Math.cos(perp)*w/2, cy - Math.sin(perp)*w/2);
                    gfx.closePath(); gfx.fill();
                }
                // Fade out flash over 150ms
                scene.tweens.add({ targets: gfx, alpha: 0, duration: 150, onComplete: () => gfx.destroy() });
                
                if (completeFn) completeFn();
                
                // Remove from active list
                const idx = TelegraphSystem._active.indexOf(handle);
                if (idx >= 0) TelegraphSystem._active.splice(idx, 1);
            }
        }});
        
        this._active.push(handle);
        return handle;
    },
    
    // --- CIRCLE: converging outer ring + filling inner ---
    _drawCircle(gfx, cx, cy, radius, prog, pal, duration) {
        // Outer converging ring — starts at 2.5× radius, shrinks to 1×
        const outerR = radius * (2.5 - prog * 1.5);
        gfx.lineStyle(1.5, pal.stroke, 0.15 + prog * 0.25);
        gfx.strokeCircle(cx, cy, outerR);
        
        // Inner fill — opacity and radius grow
        const fillAlpha = 0.06 + prog * 0.22;
        gfx.fillStyle(pal.fill, fillAlpha);
        gfx.fillCircle(cx, cy, radius);
        
        // Edge stroke — pulses faster as completion nears
        const pulseHz = 3 + prog * 12;
        const pulseAlpha = 0.25 + Math.sin(prog * pulseHz * Math.PI) * 0.15 * prog;
        const strokeW = 1 + prog * 1.5;
        gfx.lineStyle(strokeW, pal.stroke, pulseAlpha);
        gfx.strokeCircle(cx, cy, radius);
        
        // Urgency: inner hot zone appears at 60% progress
        if (prog > 0.6) {
            const urgProg = (prog - 0.6) / 0.4;
            gfx.fillStyle(pal.stroke, 0.08 + urgProg * 0.15);
            gfx.fillCircle(cx, cy, radius * 0.5);
        }
    },
    
    // --- CONE: expanding arc from source point ---
    _drawCone(gfx, cx, cy, radius, angle, arc, prog, pal) {
        const curR = radius * (0.3 + prog * 0.7);
        const curArc = arc * (0.4 + prog * 0.6);
        const segs = 10;
        
        // Fill
        gfx.fillStyle(pal.fill, 0.08 + prog * 0.2);
        gfx.beginPath(); gfx.moveTo(cx, cy);
        for (let s = 0; s <= segs; s++) {
            const a = angle - curArc/2 + (curArc/segs) * s;
            gfx.lineTo(cx + Math.cos(a) * curR, cy + Math.sin(a) * curR);
        }
        gfx.closePath(); gfx.fill();
        
        // Edge strokes
        const pulseHz = 3 + prog * 10;
        const strokeAlpha = 0.2 + prog * 0.35 + Math.sin(prog * pulseHz * Math.PI) * 0.1 * prog;
        gfx.lineStyle(1 + prog, pal.stroke, strokeAlpha);
        gfx.beginPath(); gfx.moveTo(cx, cy);
        gfx.lineTo(cx + Math.cos(angle - curArc/2) * curR, cy + Math.sin(angle - curArc/2) * curR);
        gfx.stroke();
        gfx.beginPath(); gfx.moveTo(cx, cy);
        gfx.lineTo(cx + Math.cos(angle + curArc/2) * curR, cy + Math.sin(angle + curArc/2) * curR);
        gfx.stroke();
        
        // Outer arc
        gfx.beginPath();
        gfx.arc(cx, cy, curR, angle - curArc/2, angle + curArc/2, false);
        gfx.stroke();
        
        // Urgency inner
        if (prog > 0.6) {
            const urgProg = (prog - 0.6) / 0.4;
            gfx.fillStyle(pal.stroke, 0.06 + urgProg * 0.15);
            gfx.beginPath(); gfx.moveTo(cx, cy);
            for (let s = 0; s <= segs; s++) {
                const a = angle - curArc/2 + (curArc/segs) * s;
                gfx.lineTo(cx + Math.cos(a) * curR * 0.5, cy + Math.sin(a) * curR * 0.5);
            }
            gfx.closePath(); gfx.fill();
        }
    },
    
    // --- LINE: dashed to solid corridor toward target ---
    _drawLine(gfx, cx, cy, angle, length, width, prog, pal) {
        const curLen = length * (0.3 + prog * 0.7);
        const perp = angle + Math.PI / 2;
        const hw = width / 2;
        
        // Corridor fill
        gfx.fillStyle(pal.fill, 0.06 + prog * 0.16);
        gfx.beginPath();
        gfx.moveTo(cx + Math.cos(perp) * hw, cy + Math.sin(perp) * hw);
        gfx.lineTo(cx + Math.cos(angle) * curLen + Math.cos(perp) * hw, cy + Math.sin(angle) * curLen + Math.sin(perp) * hw);
        gfx.lineTo(cx + Math.cos(angle) * curLen - Math.cos(perp) * hw, cy + Math.sin(angle) * curLen - Math.sin(perp) * hw);
        gfx.lineTo(cx - Math.cos(perp) * hw, cy - Math.sin(perp) * hw);
        gfx.closePath(); gfx.fill();
        
        // Dashed center line — fills solid as progress completes
        const dashLen = 6, gapLen = 4;
        const solidLen = curLen * prog; // portion that's solid
        gfx.lineStyle(1.5, pal.stroke, 0.2 + prog * 0.35);
        for (let d = 0; d < curLen; d += dashLen + gapLen) {
            const segStart = d;
            const segEnd = Math.min(d + dashLen, curLen);
            if (segStart < solidLen) {
                // Solid segment
                gfx.beginPath();
                gfx.moveTo(cx + Math.cos(angle) * segStart, cy + Math.sin(angle) * segStart);
                gfx.lineTo(cx + Math.cos(angle) * segEnd, cy + Math.sin(angle) * segEnd);
                gfx.stroke();
            } else {
                // Dashed — only draw dash portion
                gfx.lineStyle(1, pal.stroke, 0.1 + prog * 0.15);
                gfx.beginPath();
                gfx.moveTo(cx + Math.cos(angle) * segStart, cy + Math.sin(angle) * segStart);
                gfx.lineTo(cx + Math.cos(angle) * segEnd, cy + Math.sin(angle) * segEnd);
                gfx.stroke();
                gfx.lineStyle(1.5, pal.stroke, 0.2 + prog * 0.35);
            }
        }
        
        // Endpoint warning dot — pulses
        const endX = cx + Math.cos(angle) * curLen;
        const endY = cy + Math.sin(angle) * curLen;
        const pulse = 0.25 + Math.sin(prog * 15 * Math.PI) * 0.15 * prog;
        gfx.fillStyle(pal.flash, pulse);
        gfx.fillCircle(endX, endY, 3 + prog * 5);
        
        // Edge lines
        const edgeAlpha = 0.1 + prog * 0.2;
        gfx.lineStyle(1, pal.stroke, edgeAlpha);
        gfx.beginPath();
        gfx.moveTo(cx + Math.cos(perp) * hw, cy + Math.sin(perp) * hw);
        gfx.lineTo(cx + Math.cos(angle) * curLen + Math.cos(perp) * hw, cy + Math.sin(angle) * curLen + Math.sin(perp) * hw);
        gfx.stroke();
        gfx.beginPath();
        gfx.moveTo(cx - Math.cos(perp) * hw, cy - Math.sin(perp) * hw);
        gfx.lineTo(cx + Math.cos(angle) * curLen - Math.cos(perp) * hw, cy + Math.sin(angle) * curLen - Math.sin(perp) * hw);
        gfx.stroke();
    },
    
    // Cancel all active telegraphs — call on scene shutdown
    cancelAll() {
        [...this._active].forEach(h => h.cancel());
        this._active = [];
    },
    
    // Get tier duration — for enemies that need to know the buildup time for their delayedCall
    getDuration(tier) {
        return (this.TIERS[tier] || this.TIERS.standard).duration;
    }
};

