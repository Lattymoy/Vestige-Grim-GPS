// Vestige GPS — EnemyManagerRenderer (Phaser)
// Enemy spawn, death, hit feedback, blood effects
// Wire to core: EnemyManager.init(EnemyManagerRenderer)

import { CONFIG } from '../../data/config.js';
import { EnemyManager } from '../../core/enemyManager.js';
import { AudioManager } from '../audioManager.js';

export const EnemyManagerRenderer = {
    /**
     * Create a physics-enabled enemy sprite.
     * Returns sprite with body for movement/collision.
     */
    createSprite(scene, x, y, type, cfg) {
        const key = 'enemy_' + type;
        const sheetKey = key + '_sheet';
        const useSheet = scene.textures.exists(sheetKey);
        const texKey = useSheet ? sheetKey : (scene.textures.exists(key) ? key : '__DEFAULT');

        const sprite = scene.physics.add.sprite(x, y, texKey);
        const size = cfg.size || 16;
        sprite.setDisplaySize(size, size);
        sprite.setOrigin(0.5, 0.75);
        sprite.setDepth(20);
        sprite.setCollideWorldBounds(true);

        if (sprite.body) {
            sprite.body.setSize(size * 0.7, size * 0.5);
            sprite.body.setOffset(size * 0.15, size * 0.25);
        }

        sprite.hasAnimSheet = useSheet;
        return sprite;
    },

    /**
     * Pop-in spawn animation.
     */
    spawnAnimation(scene, sprite) {
        if (!sprite || !sprite.active) return;
        sprite.setScale(0.1);
        sprite.setAlpha(0);
        scene.tweens.add({
            targets: sprite,
            scaleX: 1, scaleY: 1, alpha: 1,
            duration: 200,
            ease: 'Back.easeOut'
        });
    },

    /**
     * Add elliptical shadow under enemy.
     */
    addShadow(scene, sprite) {
        if (!sprite) return;
        const w = sprite.displayWidth || 16;
        const shadow = scene.add.ellipse(
            sprite.x, sprite.y + 4,
            w * 0.5, w * 0.2,
            0x000000, 0.15
        ).setDepth(1);
        sprite._shadow = shadow;
    },

    /**
     * Remove shadow from enemy.
     */
    removeShadow(scene, enemy) {
        if (enemy && enemy._shadow) {
            enemy._shadow.destroy();
            enemy._shadow = null;
        }
    },

    /**
     * Apply ambient tint (time-of-day) to a sprite.
     */
    applyAmbientTint(sprite, tint) {
        if (sprite && sprite.setTint && tint && tint !== 0xffffff) {
            sprite.setTint(tint);
        }
    },

    /**
     * Death shrink + fade animation.
     */
    deathAnimation(scene, enemy) {
        if (!enemy || !enemy.active) return;
        enemy._dying = true;
        if (enemy.body) enemy.body.enable = false;

        scene.tweens.add({
            targets: enemy,
            scaleX: 0.1, scaleY: 0.1,
            alpha: 0,
            angle: 90 + Math.random() * 180,
            duration: 250,
            ease: 'Power2',
            onComplete: () => {
                EnemyManagerRenderer.removeShadow(scene, enemy);
                enemy.destroy();
            }
        });
    },

    /**
     * Persistent blood pool at death location.
     */
    bloodPool(scene, x, y, cfg, wasCrit) {
        const poolSize = (cfg.size || 16) * (wasCrit ? 0.6 : 0.4);
        const pool = scene.add.ellipse(
            x + (Math.random() - 0.5) * 4,
            y + 2,
            poolSize, poolSize * 0.5,
            0x330808, 0.35
        ).setDepth(1);

        // Slow fade
        scene.tweens.add({
            targets: pool,
            alpha: 0,
            duration: 15000,
            delay: 5000,
            onComplete: () => pool.destroy()
        });
    },

    /**
     * Blood particle splatter on death.
     */
    bloodSplatter(scene, x, y, cfg) {
        const count = 4 + Math.floor(Math.random() * 3);
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = 5 + Math.random() * 12;
            const size = 1 + Math.random() * 2;
            const particle = scene.add.circle(
                x, y, size, 0x551010, 0.6
            ).setDepth(25);

            scene.tweens.add({
                targets: particle,
                x: x + Math.cos(angle) * dist,
                y: y + Math.sin(angle) * dist,
                alpha: 0,
                scaleX: 0.3, scaleY: 0.3,
                duration: 200 + Math.random() * 150,
                onComplete: () => particle.destroy()
            });
        }
    },

    /**
     * Fade out acid puddle graphics.
     */
    acidFadeout(scene, gfx) {
        if (!gfx) return;
        scene.tweens.add({
            targets: gfx,
            alpha: 0,
            duration: 500,
            onComplete: () => gfx.destroy()
        });
    },

    /**
     * Enemy hit feedback on player — tint + camera.
     */
    hitFeedback(scene, enemy) {
        if (!scene.player || !scene.player.active) return;
        scene.player.setTint(0xff4444);
        scene.time.delayedCall(100, () => {
            if (scene.player && scene.player.active) {
                if (scene._ambientTint && scene._ambientTint !== 0xffffff) {
                    scene.player.setTint(scene._ambientTint);
                } else {
                    scene.player.clearTint();
                }
            }
        });
        if (scene.cameras && scene.cameras.main) {
            scene.cameras.main.shake(60, 0.006);
        }
    },

    /**
     * Dodge i-frame visual feedback — flicker alpha.
     */
    dodgeFeedback(scene, durationMs) {
        if (!scene.player) return;
        scene.isInvincible = true;
        const flickerEvt = scene.time.addEvent({
            delay: 40,
            loop: true,
            callback: () => {
                if (scene.player && scene.player.active) {
                    scene.player.setAlpha(scene.player.alpha < 0.9 ? 1 : 0.4);
                }
            }
        });

        scene.time.delayedCall(durationMs, () => {
            flickerEvt.destroy();
            scene.isInvincible = false;
            if (scene.player && scene.player.active) scene.player.setAlpha(1);
        });
    },

    /**
     * Invincibility frames — player flickers.
     */
    iFrames(scene, durationMs) {
        scene.isInvincible = true;
        const flickerEvt = scene.time.addEvent({
            delay: 50,
            loop: true,
            callback: () => {
                if (scene.player && scene.player.active) {
                    scene.player.setAlpha(scene.player.alpha < 0.9 ? 1 : 0.5);
                }
            }
        });

        scene.time.delayedCall(durationMs, () => {
            flickerEvt.destroy();
            scene.isInvincible = false;
            if (scene.player && scene.player.active) scene.player.setAlpha(1);
        });
    },

    /**
     * Delayed function call.
     */
    delayedCall(scene, ms, callback) {
        return scene.time.delayedCall(ms, callback);
    },

    /**
     * Audio: enemy death sound.
     */
    audioEnemyDeath() {
        // Delegates to AudioManager if available on global scope
        if (typeof AudioManager !== 'undefined' && AudioManager.play) {
            AudioManager.play('enemyDeath');
        }
    },

    /**
     * Audio: player hit sound.
     */
    audioPlayerHit() {
        if (typeof AudioManager !== 'undefined' && AudioManager.play) {
            AudioManager.play('playerHit');
        }
    }
};
