// Vestige GPS — CombatHitRenderer (Phaser)
// Hit feedback: tint flash, camera shake, VFX, iFrame alpha, last stand
// Wire to core: CombatHelper.init(CombatHitRenderer)

import { CONFIG } from '../../data/config.js';
import { CombatHelper } from '../../core/combatHelper.js';
import { _restoreTint, uiPx } from '../../core/utils.js';
import { AudioManager } from '../audioManager.js';
import { AttackVFX } from './attackVFX.js';

// uiPx must be provided by the client rendering context
let _uiPx = (n) => Math.round(n * 1.4);
export function setUiPx(fn) { _uiPx = fn; }

export const CombatHitRenderer = {
    audioPlayerHit() {
        if (typeof AudioManager !== 'undefined' && AudioManager.playerHit) AudioManager.playerHit();
    },

    playerHitFeedback(scene, opts) {
        // Tint flash
        if (scene.player && scene.player.setTint) {
            scene.player.setTint(0xff0000);
            scene.time.delayedCall(150, () => {
                if (!scene.state.dead && scene.player.active) {
                    if (typeof _restoreTint === 'function') _restoreTint(scene.player);
                    else scene.player.clearTint();
                }
            });
        }
        
        // Camera shake
        const shake = opts.shake || { duration: 100, intensity: 0.015 };
        scene.cameras.main.shake(shake.duration, shake.intensity);
        
        // Attack VFX
        if (opts.vfx === 'hitFlash' && opts.source) {
            if (typeof AttackVFX !== 'undefined') AttackVFX.enemyHitFlash(scene, opts.source, scene.player);
        } else if (opts.vfx && typeof opts.vfx === 'object') {
            if (typeof AttackVFX !== 'undefined') AttackVFX.play(scene, scene.player.x, scene.player.y, opts.vfx.angle || 0, opts.vfx.weight || 'medium');
        }
        
        // Knockback
        if (opts.knockback && scene.player.setVelocity) {
            scene.player.setVelocity(
                Math.cos(opts.knockback.angle) * opts.knockback.force,
                Math.sin(opts.knockback.angle) * opts.knockback.force
            );
        }
    },

    playerIFrames(scene, durationMs, visible) {
        if (visible && scene.player) {
            scene.player.setAlpha(0.4);
            scene.time.delayedCall(durationMs, () => {
                scene.isInvincible = false;
                if (scene.player && scene.player.active) scene.player.setAlpha(1);
            });
        } else {
            scene.time.delayedCall(durationMs, () => { scene.isInvincible = false; });
        }
    },

    lastStandEffect(scene) {
        scene.cameras.main.flash(300, 255, 50, 50);
        const ls = scene.add.text(scene.player.x, scene.player.y - 30, 'LAST STAND', {
            fontFamily: CONFIG.font, fontSize: _uiPx(12), fill: '#ff2244', fontStyle: 'bold'
        }).setOrigin(0.5);
        scene.tweens.add({ targets: ls, y: ls.y - 30, alpha: 0, duration: 1200, onComplete: () => ls.destroy() });
        scene.time.delayedCall(1500, () => scene.isInvincible = false);
    },

    simResetEffect(scene) {
        if (scene.player) {
            scene.player.setAlpha(0.2);
            scene.time.delayedCall(500, () => { if (scene.player.active) scene.player.setAlpha(1); });
        }
    }
};
