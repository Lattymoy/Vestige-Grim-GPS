// Vestige GPS — CrownAura
// Extracted from monolith L14663-14781

export const CrownAura = {
    ALPHA: 0.9,
    BOB_AMP: 2,
    BOB_SPEED: 0.003,
    _ready: false,
    _texKey: 'crown_aura_tex',

    init() {
        this._ready = true; // No base64 needed — we draw on demand
    },

    ensureTexture(scene) {
        if (scene.textures.exists(this._texKey)) return true;
        // Handcrafted ¾-iso crown — viewed from slightly below
        // Gold crown with 5 points, gem insets, front-face dominant
        const W = 18, H = 12;
        const can = document.createElement('canvas');
        can.width = W; can.height = H;
        const c = can.getContext('2d');

        // Crown base band — slightly curved for ¾ perspective
        // The front face (bottom) is wider, top is foreshortened
        c.fillStyle = '#c9982e'; // dark gold base
        c.beginPath();
        c.moveTo(1, H - 2);
        c.lineTo(W - 1, H - 2);
        c.lineTo(W - 2, H - 5);
        c.lineTo(2, H - 5);
        c.closePath();
        c.fill();

        // Front face highlight band
        c.fillStyle = '#e8b832';
        c.fillRect(2, H - 4, W - 4, 2);

        // Five crown points rising from band
        const points = [
            { x: 3,  tipY: 1 },   // left outer
            { x: 6,  tipY: 2 },   // left inner
            { x: 9,  tipY: 0 },   // center (tallest)
            { x: 12, tipY: 2 },   // right inner
            { x: 15, tipY: 1 }    // right outer
        ];
        c.fillStyle = '#e8b832'; // bright gold
        points.forEach(p => {
            c.beginPath();
            c.moveTo(p.x - 1.5, H - 5);
            c.lineTo(p.x, p.tipY);
            c.lineTo(p.x + 1.5, H - 5);
            c.fill();
        });

        // Bright tip highlights
        c.fillStyle = '#f5d45a';
        points.forEach(p => {
            c.fillRect(p.x, p.tipY, 1, 1);
        });

        // Gem insets between points — alternating ruby/sapphire
        const gems = [
            { x: 4, y: H - 5, color: '#cc2233' },  // ruby
            { x: 7, y: H - 6, color: '#2244cc' },   // sapphire
            { x: 11, y: H - 6, color: '#cc2233' },   // ruby
            { x: 14, y: H - 5, color: '#2244cc' }    // sapphire
        ];
        gems.forEach(g => {
            c.fillStyle = g.color;
            c.fillRect(g.x, g.y, 2, 2);
            // tiny highlight
            c.fillStyle = '#ffffff';
            c.fillRect(g.x, g.y, 1, 1);
        });

        // Dark outline on bottom edge for depth
        c.fillStyle = '#8a6a1e';
        c.fillRect(1, H - 2, W - 2, 1);

        // Inner shadow on band top
        c.fillStyle = 'rgba(0,0,0,0.2)';
        c.fillRect(2, H - 5, W - 4, 1);

        scene.textures.addImage(this._texKey, can);
        this._ready = true;
        return true;
    },

    createCrown(scene, target) {
        if (!this.ensureTexture(scene)) return null;
        const crown = scene.add.image(
            Math.round(target.x),
            Math.round(target.y - 22), // above head
            this._texKey
        );
        crown.setDisplaySize(18, 12);
        crown.setAlpha(this.ALPHA);
        crown.setDepth(target.depth + 0.2);
        crown._bobPhase = Math.random() * Math.PI * 2;
        return crown;
    },

    updateCrown(target, time) {
        const crown = target._crownSprite;
        if (!crown || !crown.active) return;
        // Bob above head — base offset -22px, bob ±2px
        crown._bobPhase = (crown._bobPhase || 0) + this.BOB_SPEED * 16.67; // ~60fps
        const bobY = Math.sin(crown._bobPhase) * this.BOB_AMP;
        crown.x = Math.round(target.x);
        crown.y = Math.round(target.y - 22 + bobY);
        crown.setDepth(target.depth + 0.2);
    },

    destroyCrown(target) {
        if (target._crownSprite) {
            target._crownSprite.destroy();
            target._crownSprite = null;
        }
        target._hasCrown = false;
    }
};

