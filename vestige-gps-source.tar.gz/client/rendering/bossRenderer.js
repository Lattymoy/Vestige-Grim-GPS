// Vestige GPS — BossRenderer (Phaser)
// All boss fight visual effects: sprites, attacks, phase transitions, hazards
// Wire to core: BossAI.init(BossRenderer)
//
// Pattern: Most attack methods receive callback-based damage delegation:
//   opts.hitPlayer(dmg, shakeIntensity)
//   opts.getPlayerPos() → {x, y}
//   opts.checkDamage() / opts.checkProximity(x, y)
// This keeps damage logic in core while rendering handles projectiles, zones, etc.

import { CONFIG } from '../../data/config.js';
import { BossAI } from '../../core/bossAI.js';
import { AudioManager } from '../audioManager.js';
import { GameScene } from '../scenes/GameScene.js';

// Boss color palettes per type
const BOSS_COLORS = {
    warden:      { primary: 0xcc4422, secondary: 0xff6644, glow: 0xff8844 },
    swarmQueen:  { primary: 0x44aa33, secondary: 0x66cc44, glow: 0x88ff66 },
    phantom:     { primary: 0x6644aa, secondary: 0x8866cc, glow: 0xaa88ff },
    ironclad:    { primary: 0x888888, secondary: 0xaaaaaa, glow: 0xcccccc },
    cubeAnomaly: { primary: 0x44aacc, secondary: 0x66ccee, glow: 0x88eeff }
};

function _bossColor(type, key) {
    return (BOSS_COLORS[type] || BOSS_COLORS.warden)[key || 'primary'];
}

export const BossRenderer = {
    // === BOSS CREATION ===

    createBossSprite(scene, x, y, bossType, stats) {
        const size = stats.size || 32;
        const key = 'boss_' + bossType;
        const texKey = scene.textures.exists(key) ? key : '__DEFAULT';

        const boss = scene.physics.add.sprite(x, y, texKey);
        boss.setDisplaySize(size, size);
        boss.setOrigin(0.5, 0.75);
        boss.setDepth(30);
        boss.setCollideWorldBounds(true);
        if (boss.body) {
            boss.body.setSize(size * 0.6, size * 0.4);
            boss.body.setOffset(size * 0.2, size * 0.3);
        }

        // Tint with boss color
        boss.setTint(_bossColor(bossType, 'primary'));
        return boss;
    },

    bossEntranceVFX(scene, boss, bossType, cx, cy) {
        const color = _bossColor(bossType, 'glow');
        // Expanding ring
        const ring = scene.add.circle(cx, cy, 8, color, 0.4).setDepth(29);
        scene.tweens.add({
            targets: ring,
            scaleX: 6, scaleY: 6, alpha: 0,
            duration: 600,
            onComplete: () => ring.destroy()
        });
        // Boss scale-in
        boss.setScale(0.1);
        boss.setAlpha(0);
        scene.tweens.add({
            targets: boss,
            scaleX: 1, scaleY: 1, alpha: 1,
            duration: 400, ease: 'Back.easeOut'
        });
    },

    bossIdleAnimation(scene, boss, bossType) {
        // Slow bob animation
        scene.tweens.add({
            targets: boss,
            y: boss.y - 2,
            duration: 1200,
            yoyo: true, repeat: -1,
            ease: 'Sine.easeInOut'
        });
    },

    bossNameDisplay(scene, displayName) {
        const cam = scene.cameras.main;
        const t = scene.add.text(cam.scrollX + cam.width / 2, cam.scrollY + 30, displayName, {
            fontFamily: 'monospace', fontSize: '14px', color: '#ff4444',
            fontStyle: 'bold', stroke: '#000000', strokeThickness: 3
        }).setOrigin(0.5, 0).setDepth(200).setScrollFactor(0);

        scene.tweens.add({
            targets: t, alpha: 0, y: t.y - 10,
            duration: 800, delay: 2000,
            onComplete: () => t.destroy()
        });
    },

    showBossHPBar(scene) {
        // Boss HP bar rendered by GameScene HUD — signal it
        scene._showBossHP = true;
    },

    audioBossSpawn() {
        if (typeof AudioManager !== 'undefined') AudioManager.play('bossSpawn');
    },

    setupBossOverlap(scene, boss, onTouch) {
        if (scene.player && scene.physics) {
            scene.physics.add.overlap(boss, scene.player, () => {
                if (!scene.isInvincible && !scene.state.dead) onTouch();
            });
        }
    },

    // === PHASE TRANSITIONS ===

    phaseTransitionVFX(scene, boss, phase, bossType) {
        const color = _bossColor(bossType, 'glow');
        // Screen flash
        const flash = scene.add.rectangle(
            scene.cameras.main.scrollX + scene.cameras.main.width / 2,
            scene.cameras.main.scrollY + scene.cameras.main.height / 2,
            scene.cameras.main.width, scene.cameras.main.height,
            color, 0.3
        ).setDepth(200).setScrollFactor(0);
        scene.tweens.add({
            targets: flash, alpha: 0, duration: 500,
            onComplete: () => flash.destroy()
        });
        scene.cameras.main.shake(200, 0.015);

        // Boss pulse
        scene.tweens.add({
            targets: boss,
            scaleX: 1.3, scaleY: 1.3,
            duration: 150, yoyo: true, repeat: 2
        });
    },

    enrageAura(scene, boss, bossType) {
        const color = _bossColor(bossType, 'glow');
        const aura = scene.add.circle(boss.x, boss.y, boss.displayWidth * 0.6, color, 0.1)
            .setDepth(boss.depth - 1);
        boss._enrageAura = aura;

        scene.tweens.add({
            targets: aura,
            scaleX: 1.2, scaleY: 1.2, fillAlpha: 0.05,
            duration: 600, yoyo: true, repeat: -1
        });
    },

    trackEnrageAura(boss) {
        if (boss._enrageAura && boss._enrageAura.active) {
            boss._enrageAura.setPosition(boss.x, boss.y);
        }
    },

    // === WARDEN ===

    wardenWindup(scene, boss) {
        boss.setTint(0xff2222);
        scene.tweens.add({
            targets: boss,
            scaleX: 1.15, scaleY: 0.9,
            duration: 200, ease: 'Power2'
        });
    },

    wardenChargeStart(scene, boss) {
        scene.cameras.main.shake(100, 0.008);
        // Dust trail
        const trail = scene.time.addEvent({
            delay: 40, loop: true,
            callback: () => {
                if (!boss.active) { trail.destroy(); return; }
                const d = scene.add.circle(boss.x, boss.y + 8, 2, 0x998877, 0.3).setDepth(1);
                scene.tweens.add({
                    targets: d, alpha: 0, scaleX: 2, scaleY: 2,
                    duration: 200, onComplete: () => d.destroy()
                });
            }
        });
        boss._chargeTrail = trail;
    },

    wardenStunned(scene, boss) {
        if (boss._chargeTrail) { boss._chargeTrail.destroy(); boss._chargeTrail = null; }
        boss.setTint(0xffcc44);
        scene.tweens.add({
            targets: boss, scaleX: 1, scaleY: 1, duration: 150
        });
        // Stars around head
        for (let i = 0; i < 3; i++) {
            const a = (i / 3) * Math.PI * 2;
            const star = scene.add.text(
                boss.x + Math.cos(a) * 10, boss.y - 12,
                '*', { fontSize: '8px', color: '#ffcc44' }
            ).setOrigin(0.5).setDepth(50);
            scene.tweens.add({
                targets: star,
                x: boss.x + Math.cos(a + Math.PI) * 10,
                y: boss.y - 14, alpha: 0,
                duration: 800,
                onComplete: () => star.destroy()
            });
        }
    },

    wardenRecover(scene, boss) {
        boss.setTint(_bossColor(boss.bossType || 'warden', 'primary'));
        scene.tweens.add({
            targets: boss, scaleX: 1, scaleY: 1, duration: 100
        });
    },

    // === PHANTOM ===

    phantomVanish(scene, boss, onComplete) {
        scene.tweens.add({
            targets: boss, alpha: 0,
            duration: 300, ease: 'Power2',
            onComplete: () => { if (onComplete) onComplete(); }
        });
    },

    phantomAppear(scene, boss, onComplete) {
        scene.tweens.add({
            targets: boss, alpha: 1,
            duration: 200, ease: 'Power2',
            onComplete: () => { if (onComplete) onComplete(); }
        });
    },

    // === IRONCLAD ===

    ironcladRamStart(scene, boss) {
        boss.setTint(0xffaa44);
        scene.cameras.main.shake(80, 0.005);
    },

    ironcladRamEnd(scene, boss) {
        boss.setTint(_bossColor('ironclad', 'primary'));
    },

    // === CUBE ANOMALY ===

    corruptionWalls(scene, boss, w, h, margin) {
        const walls = [];
        const color = 0x44aacc;
        // Four edge walls
        const positions = [
            { x: w / 2, y: margin / 2, ww: w, hh: margin },           // top
            { x: w / 2, y: h - margin / 2, ww: w, hh: margin },       // bottom
            { x: margin / 2, y: h / 2, ww: margin, hh: h },           // left
            { x: w - margin / 2, y: h / 2, ww: margin, hh: h }        // right
        ];
        positions.forEach(p => {
            const wall = scene.add.rectangle(p.x, p.y, p.ww, p.hh, color, 0.08)
                .setDepth(2).setStrokeStyle(1, color, 0.2);
            walls.push(wall);
            // Pulse
            scene.tweens.add({
                targets: wall, fillAlpha: 0.15,
                duration: 1000, yoyo: true, repeat: -1
            });
        });
        boss._corruptionWalls = walls;
    },

    createGravityWell(scene, x, y, radius, duration, onExpire) {
        const well = scene.add.circle(x, y, radius, 0x6644aa, 0.05)
            .setDepth(3).setStrokeStyle(1.5, 0x8866cc, 0.4);

        // Spiral pull visual
        const gfx = scene.add.graphics().setDepth(4);
        const startTime = scene.time.now;

        const updateEvt = scene.time.addEvent({
            delay: 60, loop: true,
            callback: () => {
                const age = scene.time.now - startTime;
                if (age > duration) {
                    updateEvt.destroy();
                    well.destroy();
                    gfx.destroy();
                    if (onExpire) onExpire(well);
                    return;
                }
                gfx.clear();
                const fade = age < duration * 0.8 ? 1 : (duration - age) / (duration * 0.2);
                gfx.lineStyle(1, 0x8866cc, 0.2 * fade);
                const t = age * 0.002;
                for (let i = 0; i < 3; i++) {
                    const a = t + (i * Math.PI * 2 / 3);
                    const r = radius * 0.3;
                    gfx.lineBetween(
                        x + Math.cos(a) * r, y + Math.sin(a) * r,
                        x + Math.cos(a + 0.5) * radius * 0.8, y + Math.sin(a + 0.5) * radius * 0.8
                    );
                }
            }
        });

        well._dmgCooldown = false;
        return well;
    },

    dimensionTear(scene, boss, hitPlayerFn) {
        const cx = boss.x, cy = boss.y;
        // Expanding dark tear
        const tear = scene.add.graphics().setDepth(50);
        const tearDur = 1200;
        const startTime = scene.time.now;

        const evt = scene.time.addEvent({
            delay: 40, loop: true,
            callback: () => {
                const age = scene.time.now - startTime;
                if (age > tearDur) { evt.destroy(); tear.destroy(); return; }
                const pct = age / tearDur;
                tear.clear();
                const r = 20 + pct * 60;
                tear.fillStyle(0x220033, 0.4 * (1 - pct));
                tear.fillCircle(cx, cy, r);
                tear.lineStyle(2, 0x8844cc, 0.6 * (1 - pct));
                tear.strokeCircle(cx, cy, r);
            }
        });

        // Damage pulse at peak
        scene.time.delayedCall(tearDur * 0.6, () => {
            hitPlayerFn(12, 0.008);
            scene.cameras.main.shake(150, 0.01);
        });
    },

    invertEffect(scene) {
        // Brief screen inversion flash
        const cam = scene.cameras.main;
        const flash = scene.add.rectangle(
            cam.scrollX + cam.width / 2, cam.scrollY + cam.height / 2,
            cam.width, cam.height, 0x220033, 0.4
        ).setDepth(200).setScrollFactor(0);
        scene.tweens.add({
            targets: flash, alpha: 0,
            duration: 400,
            onComplete: () => flash.destroy()
        });
    },

    // === GENERIC BOSS ATTACKS ===

    throwDebris(scene, boss, opts) {
        const pp = opts.getPlayerPos();
        const angle = Math.atan2(pp.y - boss.y, pp.x - boss.x);
        const speed = 120;
        const debris = scene.add.rectangle(boss.x, boss.y, 5, 5, 0x886644, 0.8)
            .setDepth(40).setAngle(Math.random() * 360);

        scene.tweens.add({
            targets: debris,
            x: boss.x + Math.cos(angle) * 200,
            y: boss.y + Math.sin(angle) * 200,
            angle: debris.angle + 360,
            duration: 200 / speed * 1000,
            onUpdate: () => {
                const d = Math.sqrt((debris.x - pp.x) ** 2 + (debris.y - pp.y) ** 2);
                if (d < 15 && !scene.isInvincible && !scene.state.dead) {
                    opts.hitPlayer(10, 0.005);
                    debris.destroy();
                }
            },
            onComplete: () => { if (debris.active) debris.destroy(); }
        });
    },

    projectileVolley(scene, boss, opts) {
        const count = 5 + Math.floor(Math.random() * 3);
        const color = _bossColor(boss.bossType || 'warden', 'secondary');
        for (let i = 0; i < count; i++) {
            scene.time.delayedCall(i * 100, () => {
                if (!boss.active) return;
                const pp = opts.getPlayerPos();
                const angle = Math.atan2(pp.y - boss.y, pp.x - boss.x) + (Math.random() - 0.5) * 0.3;
                const proj = scene.add.circle(boss.x, boss.y, 3, color, 0.8).setDepth(40);
                scene.tweens.add({
                    targets: proj,
                    x: boss.x + Math.cos(angle) * 200,
                    y: boss.y + Math.sin(angle) * 200,
                    duration: 800,
                    onUpdate: () => {
                        const pp2 = opts.getPlayerPos();
                        const d = Math.sqrt((proj.x - pp2.x) ** 2 + (proj.y - pp2.y) ** 2);
                        if (d < 12 && !scene.isInvincible && !scene.state.dead) {
                            opts.hitPlayer(6, 0.003);
                            proj.destroy();
                        }
                    },
                    onComplete: () => { if (proj.active) proj.destroy(); }
                });
            });
        }
    },

    hazardZone(scene, x, y, radius, duration, opts) {
        const color = opts.color || 0xff4444;
        const zone = scene.add.circle(x, y, radius, color, 0.08)
            .setDepth(2).setStrokeStyle(1, color, 0.3);

        const tickEvt = scene.time.addEvent({
            delay: 500, loop: true,
            callback: () => opts.checkDamage()
        });

        // Pulse
        scene.tweens.add({
            targets: zone, fillAlpha: 0.15,
            duration: 400, yoyo: true, repeat: -1
        });

        scene.time.delayedCall(duration, () => {
            tickEvt.destroy();
            scene.tweens.add({
                targets: zone, alpha: 0,
                duration: 300,
                onComplete: () => zone.destroy()
            });
        });
    },

    dropMine(scene, boss, opts) {
        const mine = scene.add.circle(boss.x, boss.y, 4, 0xff6622, 0.6)
            .setDepth(20).setStrokeStyle(1, 0xff4422, 0.8);

        // Proximity check loop
        const checkEvt = scene.time.addEvent({
            delay: 100, loop: true,
            callback: () => {
                if (!mine.active) { checkEvt.destroy(); return; }
                if (opts.checkProximity(mine.x, mine.y)) {
                    // Explode
                    const boom = scene.add.circle(mine.x, mine.y, 25, 0xff4422, 0.3).setDepth(50);
                    scene.tweens.add({
                        targets: boom, scaleX: 2, scaleY: 2, alpha: 0,
                        duration: 200, onComplete: () => boom.destroy()
                    });
                    scene.cameras.main.shake(80, 0.008);
                    checkEvt.destroy();
                    mine.destroy();
                }
            }
        });

        // Auto-expire after 8s
        scene.time.delayedCall(8000, () => {
            if (mine.active) { checkEvt.destroy(); mine.destroy(); }
        });
    },

    turretShot(scene, boss, opts) {
        const pp = opts.getPlayerPos();
        const angle = Math.atan2(pp.y - boss.y, pp.x - boss.x);
        const proj = scene.add.circle(boss.x, boss.y, 2, 0xffcc44, 0.9).setDepth(40);

        scene.tweens.add({
            targets: proj,
            x: boss.x + Math.cos(angle) * 250,
            y: boss.y + Math.sin(angle) * 250,
            duration: 500,
            onUpdate: () => {
                const pp2 = opts.getPlayerPos();
                const d = Math.sqrt((proj.x - pp2.x) ** 2 + (proj.y - pp2.y) ** 2);
                if (d < 10 && !scene.isInvincible && !scene.state.dead) {
                    opts.hitPlayer(5, 0.002);
                    proj.destroy();
                }
            },
            onComplete: () => { if (proj.active) proj.destroy(); }
        });
    },

    createDecoy(scene, boss) {
        const decoy = scene.physics.add.sprite(
            boss.x + (Math.random() - 0.5) * 40,
            boss.y + (Math.random() - 0.5) * 30,
            boss.texture.key
        );
        decoy.setDisplaySize(boss.displayWidth, boss.displayHeight);
        decoy.setOrigin(0.5, 0.75);
        decoy.setDepth(boss.depth);
        decoy.setAlpha(0.6);
        decoy.setTint(0x8866cc);
        return decoy;
    },

    // === UTILITY ===

    delayedCall(scene, ms, callback) {
        return scene.time.delayedCall(ms, callback);
    },

    dodgeVFX(scene, player, durationMs) {
        if (!player) return;
        scene.isInvincible = true;
        player.setAlpha(0.4);
        const flicker = scene.time.addEvent({
            delay: 40, loop: true,
            callback: () => {
                if (player.active) player.setAlpha(player.alpha < 0.5 ? 0.7 : 0.4);
            }
        });
        scene.time.delayedCall(durationMs, () => {
            flicker.destroy();
            scene.isInvincible = false;
            if (player.active) player.setAlpha(1);
        });
    },

    bossHitPlayerVFX(scene, shake) {
        if (!scene.player || !scene.player.active) return;
        scene.player.setTint(0xff4444);
        scene.time.delayedCall(100, () => {
            if (scene.player && scene.player.active) {
                if (scene._ambientTint && scene._ambientTint !== 0xffffff) {
                    scene.player.setTint(scene._ambientTint);
                } else {
                    scene.player.clearTint();
                }
            }
        });
        if (shake && scene.cameras && scene.cameras.main) {
            scene.cameras.main.shake(100, shake);
        }
    }
};
