// Vestige GPS — DOTRenderer (Phaser)
// Renders DOT icons, enemy HP bars, tint flashes
// Wire to core: DOTSystem.init(DOTRenderer)

import { CONFIG } from '../../data/config.js';
import { DOTSystem } from '../../core/dotSystem.js';
import { _restoreTint } from '../../core/utils.js';

export const DOTRenderer = {
    _hudIcons: [],
    _iconsBuilt: false,

    // Build 10×10 pixel art icons for each DOT type
    buildIcons(scene) {
        if (this._iconsBuilt && scene.textures.exists('dot_icon_bleed') && scene.textures.exists('dot_icon_burn')) return;
        
        // BLEED icon — red blood droplet
        const bc = document.createElement('canvas');
        bc.width = 10; bc.height = 10;
        const bx = bc.getContext('2d');
        bx.fillStyle = '#1a0808';
        bx.fillRect(0, 0, 10, 10);
        bx.fillStyle = '#aa2222';
        bx.fillRect(3, 1, 4, 2);
        bx.fillRect(2, 3, 6, 4);
        bx.fillRect(3, 7, 4, 2);
        bx.fillStyle = '#cc3333';
        bx.fillRect(4, 2, 2, 1);
        bx.fillRect(3, 4, 4, 2);
        bx.fillStyle = '#dd5555';
        bx.fillRect(4, 3, 1, 1);
        bx.fillStyle = '#881111';
        bx.fillRect(3, 7, 4, 1);
        bx.fillRect(4, 8, 2, 1);
        if (scene.textures.exists('dot_icon_bleed')) scene.textures.remove('dot_icon_bleed');
        scene.textures.addCanvas('dot_icon_bleed', bc);
        
        // TOXIC icon — green hazard/skull
        const tc = document.createElement('canvas');
        tc.width = 10; tc.height = 10;
        const tx = tc.getContext('2d');
        tx.fillStyle = '#081a08';
        tx.fillRect(0, 0, 10, 10);
        tx.fillStyle = '#228822';
        tx.fillRect(2, 1, 6, 3);
        tx.fillRect(1, 4, 8, 3);
        tx.fillRect(3, 7, 4, 2);
        tx.fillStyle = '#44cc33';
        tx.fillRect(3, 2, 4, 2);
        tx.fillRect(2, 4, 6, 2);
        tx.fillStyle = '#111111';
        tx.fillRect(3, 4, 2, 2);
        tx.fillRect(6, 4, 2, 2);
        tx.fillStyle = '#33aa22';
        tx.fillRect(4, 7, 2, 1);
        if (scene.textures.exists('dot_icon_toxic')) scene.textures.remove('dot_icon_toxic');
        scene.textures.addCanvas('dot_icon_toxic', tc);

        this._iconsBuilt = true;
    },

    flashTint(scene, target, color, durationMs) {
        if (target && target.setTint) {
            target.setTint(color);
            scene.time.delayedCall(durationMs, () => {
                if (target.active) {
                    if (typeof _restoreTint === 'function') _restoreTint(target);
                    else target.clearTint();
                }
            });
        }
    },

    renderDebuffHUD(scene, playerDOTs) {
        this.buildIcons(scene);
        
        // Clean up old icons
        this._hudIcons.forEach(obj => { if (obj && obj.active !== false) obj.destroy(); });
        this._hudIcons = [];
        
        if (playerDOTs.length === 0) return;
        if (!scene.player || !scene.player.active) return;
        
        const D = 35;
        const px = scene.player.x;
        const py = scene.player.y;
        const totalW = playerDOTs.length * 16;
        const startX = px - totalW / 2 + 8;
        const baseY = py + 24;
        
        for (let i = 0; i < playerDOTs.length; i++) {
            const dot = playerDOTs[i];
            const def = CONFIG.dotEffects[dot.type];
            if (!def) continue;
            
            const iconX = startX + (i * 16);
            const iconY = baseY;
            
            const bg = scene.add.rectangle(iconX, iconY, 14, 12, 0x0a0a14, 0.75)
                .setDepth(D).setStrokeStyle(1, def.iconBg, 0.5);
            this._hudIcons.push(bg);
            
            const iconKey = `dot_icon_${dot.type}`;
            if (scene.textures.exists(iconKey)) {
                const icon = scene.add.image(iconX, iconY - 1, iconKey)
                    .setDisplaySize(8, 8).setDepth(D + 1);
                this._hudIcons.push(icon);
            }
            
            const remaining = Math.max(0, (dot.duration - dot.elapsed) / 1000);
            const timerStr = remaining.toFixed(0);
            const timer = scene.add.text(iconX, iconY + 6, timerStr, {
                fontFamily: 'Share Tech Mono, monospace', fontSize: '6px',
                fill: def.color, stroke: '#000', strokeThickness: 1
            }).setOrigin(0.5, 0).setDepth(D + 1);
            this._hudIcons.push(timer);
        }
    },

    ensureEnemyBar(scene, enemy) {
        if (enemy._dying || !enemy.active) return;
        const cfg = CONFIG.enemyTypes[enemy.enemyType];
        if (!cfg) return;
        if (enemy._isBoss) return;
        
        if (!enemy._hpBarGfx) {
            const g = scene.add.graphics().setDepth(50);
            enemy._hpBarGfx = g;
        }
        
        const barW = Math.min(30, Math.max(16, (cfg.size || 20)));
        const barH = 3;
        const enemyHalf = (cfg.size || 20) / 2;
        const pct = Math.max(0, Math.min(1, enemy.hp / enemy.maxHp));
        
        const g = enemy._hpBarGfx;
        g.clear();
        
        // Encompassing shield visual
        if (enemy.hasShield && enemy.shieldHP > 0) {
            const shieldAlpha = 0.12 + Math.sin(scene.time.now * 0.003) * 0.04;
            const shieldR = enemyHalf + 4;
            g.fillStyle(0x2266cc, shieldAlpha);
            g.fillEllipse(enemy.x, enemy.y, shieldR * 2.2, shieldR * 1.8);
            g.lineStyle(1, 0x4488ff, shieldAlpha + 0.1);
            g.strokeEllipse(enemy.x, enemy.y, shieldR * 2.2, shieldR * 1.8);
        }
        
        const hasShield = enemy.hasShield && enemy.shieldHP > 0;
        const hasBuildup = enemy._spawnBuildup > 0 && enemy._spawnBuildup < 1;
        if (pct >= 1 && !hasShield && !hasBuildup) return;
        
        let barY = enemy.y - enemyHalf - 8;
        const barX = enemy.x - barW / 2;
        
        // Health bar
        if (pct < 1) {
            g.fillStyle(0x111111, 0.8);
            g.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);
            let fillColor = 0xcc4444;
            if (pct > 0.6) fillColor = 0x44aa44;
            else if (pct > 0.3) fillColor = 0xaaaa33;
            g.fillStyle(fillColor, 0.9);
            g.fillRect(barX, barY, barW * pct, barH);
            g.lineStyle(1, 0x333344, 0.5);
            g.strokeRect(barX - 1, barY - 1, barW + 2, barH + 2);
            barY += barH + 2;
        }
        
        // Shield bar
        if (hasShield) {
            const shieldPct = Math.max(0, Math.min(1, enemy.shieldHP / enemy.shieldMaxHP));
            g.fillStyle(0x112244, 0.8);
            g.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);
            g.fillStyle(0x4488ff, 0.9);
            g.fillRect(barX, barY, barW * shieldPct, barH);
            g.lineStyle(1, 0x223366, 0.5);
            g.strokeRect(barX - 1, barY - 1, barW + 2, barH + 2);
            barY += barH + 2;
        }
        
        // Buildup bar
        if (hasBuildup) {
            const bPct = enemy._spawnBuildup;
            g.fillStyle(0x1a0e22, 0.8);
            g.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);
            const bIntensity = Math.floor(bPct * 100);
            const bColor = ((80 + bIntensity) << 16) | (30 << 8) | (140 + bIntensity);
            g.fillStyle(bColor, 0.9);
            g.fillRect(barX, barY, barW * bPct, barH);
            g.lineStyle(1, 0x3a1a4a, 0.5);
            g.strokeRect(barX - 1, barY - 1, barW + 2, barH + 2);
            barY += barH + 2;
        }
        
        // Debuff icons above HP bar
        if (enemy._dots && enemy._dots.length > 0) {
            const dotY = enemy.y - enemyHalf - 15;
            for (let i = 0; i < enemy._dots.length; i++) {
                const dot = enemy._dots[i];
                const def = CONFIG.dotEffects[dot.type];
                if (!def) continue;
                const ix = barX + i * 7;
                g.fillStyle(def.iconBg, 0.9);
                g.fillRect(ix, dotY, 5, 5);
                const pctLeft = 1 - (dot.elapsed / dot.duration);
                g.fillStyle(0xffffff, pctLeft * 0.6);
                g.fillRect(ix + 1, dotY + 1, 3, 3);
            }
        }
    },

    cleanupEnemyBar(enemy) {
        if (enemy._hpBarGfx) {
            enemy._hpBarGfx.destroy();
            enemy._hpBarGfx = null;
        }
    },

    clearHudIcons() {
        this._hudIcons.forEach(obj => { if (obj && obj.active !== false) obj.destroy(); });
        this._hudIcons = [];
    }
};
