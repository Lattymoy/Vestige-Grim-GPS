// Vestige GPS — Client Rendering Barrel
// All Phaser renderer implementations for core module bridges
import { CombatSystem } from '../../core/combatSystem.js';
import { EnemyAI } from '../../core/enemyAI.js';
import { PhaserBlurbs } from './blurbs.js';
import { BossRenderer } from './bossRenderer.js';
import { CombatHitRenderer } from './combatHitRenderer.js';
import { ConsumableRenderer } from './consumableRenderer.js';
import { DOTManagerRenderer } from './dotManagerRenderer.js';
import { DOTRenderer } from './dotRenderer.js';
import { EnemyManagerRenderer } from './enemyManagerRenderer.js';
import { InputManager } from './inputManager.js';
import { NPCRenderer } from './npcRenderer.js';
import { ObjectPool } from './objectPool.js';
import { SceneTransitionRenderer } from './sceneTransition.js';
import { SignatureRenderer } from './signatureRenderer.js';
import { WeatherRenderer } from './weatherRenderer.js';
//
// Usage in scene boot:
//   import { CombatRenderer, EnemyAIRenderer, ... } from './combatRenderer.js';
//   CombatSystem.init(CombatRenderer);
//   EnemyAI.init(EnemyAIRenderer);
//   etc.

// === Bridge implementations (wire to core via .init()) ===
export { BossRenderer } from './bossRenderer.js';
export { CombatRenderer } from './combatRenderer.js';
export { CombatHitRenderer } from './combatHitRenderer.js';
export { ConsumableRenderer } from './consumableRenderer.js';
export { DOTManagerRenderer } from './dotManagerRenderer.js';
export { DOTRenderer } from './dotRenderer.js';
export { EnemyAIRenderer } from './enemyAIRenderer.js';
export { EnemyManagerRenderer } from './enemyManagerRenderer.js';
export { NPCRenderer } from './npcRenderer.js';
export { SignatureRenderer } from './signatureRenderer.js';

// === Client-only utilities ===
export { InputManager } from './inputManager.js';
export { ObjectPool } from './objectPool.js';
export { PhaserBlurbs } from './blurbs.js';
export { SceneTransitionRenderer } from './sceneTransition.js';
export { WeatherRenderer } from './weatherRenderer.js';
