// Vestige GPS — ParallaxBG
// Extracted from monolith L34725-35177

import { Utils } from '../../core/utils.js';
import { BIOMES } from '../../data/biomesLookup.js';
import { CONFIG } from '../../data/config.js';
import { IsoRenderer } from '../isoRenderer.js';


export const ParallaxBG = {
    // Time-of-day sky palettes per biome
    _skyPalettes: {
        grassy: {
            dawn:   { top: 0x2a1830, mid: 0xff8855, low: 0xffcc88, fog: 0xddaa77 },
            midday: { top: 0x4477bb, mid: 0x6699cc, low: 0xaaccee, fog: 0x99bbcc },
            dusk:   { top: 0x1a1028, mid: 0xcc5533, low: 0xff9966, fog: 0xbb7744 },
            night:  { top: 0x060810, mid: 0x0a0e1a, low: 0x141828, fog: 0x1a1a2a }
        },
        barren: {
            dawn:   { top: 0x2a1820, mid: 0xdd8844, low: 0xeebb77, fog: 0xccaa66 },
            midday: { top: 0x887755, mid: 0xaa9977, low: 0xccbb99, fog: 0xbbaa88 },
            dusk:   { top: 0x1a0e10, mid: 0xbb5533, low: 0xee8855, fog: 0xaa6633 },
            night:  { top: 0x080606, mid: 0x100a08, low: 0x1a1410, fog: 0x1a1612 }
        },
        apocalyptic: {
            dawn:   { top: 0x1a1020, mid: 0x6a4455, low: 0x8a6677, fog: 0x5a3a4a },
            midday: { top: 0x3a3844, mid: 0x555060, low: 0x6a6674, fog: 0x4a4855 },
            dusk:   { top: 0x120818, mid: 0x5a2a3a, low: 0x7a4455, fog: 0x4a2233 },
            night:  { top: 0x040406, mid: 0x080810, low: 0x101018, fog: 0x0e0e16 }
        }
    },

    // Create parallax background for safehouse (camera scroll-driven)
    createForSafehouse(scene, biomeId, tod) {
        const VW = CONFIG.width, VH = CONFIG.height;
        const layers = [];
        const palette = (this._skyPalettes[biomeId] || this._skyPalettes.grassy)[tod] || this._skyPalettes.grassy.midday;
        const biome = BIOMES[biomeId] || BIOMES.grassy;
        const isNight = tod === 'night';
        const isDawn = tod === 'dawn';
        const isDusk = tod === 'dusk';
        // All layers use scrollFactor(0) — fixed to viewport, no bleed into interior
        const skyH = VH * 0.45; // sky occupies top 45% of viewport

        // ── LAYER 0: SKY GRADIENT (fixed to viewport) ──
        const skyG = scene.add.graphics().setDepth(0.001).setScrollFactor(0);
        for (let y = 0; y < skyH + 20; y++) {
            const t = y / skyH;
            const col = this._lerpColor(palette.top, t < 0.5 ? palette.mid : palette.low, Math.min(t < 0.5 ? t * 2 : (t - 0.5) * 2, 1));
            skyG.fillStyle(col, 0.95);
            skyG.fillRect(0, y, VW + 2, 2);
        }
        layers.push(skyG);

        // ── LAYER 1: CELESTIAL (sun/moon/stars — viewport coords) ──
        const celestC = scene.add.container(0, 0).setDepth(0.005).setScrollFactor(0);
        if (isNight) {
            // Stars
            for (let i = 0; i < 35; i++) {
                const sx = Phaser.Math.Between(10, VW - 10);
                const sy = Phaser.Math.Between(8, skyH * 0.7);
                const ss = Phaser.Math.FloatBetween(0.4, 1.3);
                const sa = Phaser.Math.FloatBetween(0.2, 0.8);
                const star = scene.add.circle(sx, sy, ss, 0xffffff, sa);
                celestC.add(star);
                scene.tweens.add({
                    targets: star, alpha: { from: sa, to: sa * 0.2 },
                    duration: Phaser.Math.Between(1500, 4000), yoyo: true, repeat: -1,
                    delay: Phaser.Math.Between(0, 3000)
                });
            }
            // Moon — right side of viewport
            const moonX = VW * 0.7, moonY = skyH * 0.2;
            const moon = scene.add.circle(moonX, moonY, 14, 0xeeeedd, 0.85);
            const moonShadow = scene.add.circle(moonX + 5, moonY - 3, 12, palette.top, 0.9);
            celestC.add(moon); celestC.add(moonShadow);
            celestC.add(scene.add.circle(moonX, moonY, 30, 0xaabbcc, 0.1));
        } else {
            // Sun
            const sunX = isDawn ? VW * 0.2 : isDusk ? VW * 0.8 : VW * 0.5;
            const sunY = (isDawn || isDusk) ? skyH * 0.75 : skyH * 0.2;
            const sunR = (isDawn || isDusk) ? 18 : 14;
            celestC.add(scene.add.circle(sunX, sunY, sunR * 3, 0xffdd88, 0.06));
            celestC.add(scene.add.circle(sunX, sunY, sunR * 1.8, 0xffcc66, 0.12));
            celestC.add(scene.add.circle(sunX, sunY, sunR, 0xffeeaa, isDawn || isDusk ? 0.7 : 0.5));
            if (isDawn || isDusk) {
                const glowG = scene.add.graphics();
                glowG.fillStyle(isDawn ? 0xff8844 : 0xff6633, 0.08);
                glowG.fillRect(0, skyH * 0.7, VW, skyH * 0.3);
                celestC.add(glowG);
            }
        }
        layers.push(celestC);

        // ── LAYER 2: FAR MOUNTAINS ──
        const farG = scene.add.graphics().setDepth(0.01).setScrollFactor(0);
        const farCol = this._todTint(biome.mountain, tod, 0.6);
        const farColLight = this._todTint(biome.mountainFar || IsoRenderer.lighten(biome.mountain, 0.1), tod, 0.5);
        // Back range
        farG.fillStyle(farColLight, 0.7);
        farG.beginPath(); farG.moveTo(-10, skyH + 10);
        for (let x = -10; x <= VW + 10; x += 4) {
            const baseY = skyH * 0.55;
            const y = baseY + Math.sin(x * 0.01) * skyH * 0.12 + Math.sin(x * 0.025 + 1) * skyH * 0.07;
            farG.lineTo(x, y);
        }
        farG.lineTo(VW + 10, skyH + 10); farG.closePath(); farG.fill();
        // Front range
        farG.fillStyle(farCol, 0.85);
        farG.beginPath(); farG.moveTo(-10, skyH + 10);
        for (let x = -10; x <= VW + 10; x += 3) {
            const baseY = skyH * 0.65;
            let y;
            if (biomeId === 'barren') {
                // Flat mesas
                const mesa = Math.floor((x + 80) / 160);
                const inMesa = ((x + 80) % 160);
                y = baseY + (inMesa < 20 || inMesa > 130 ? skyH * 0.15 : skyH * 0.02);
            } else if (biomeId === 'apocalyptic') {
                // Jagged spires
                y = baseY + Math.sin(x * 0.04) * skyH * 0.1 + Math.abs(Math.sin(x * 0.09)) * skyH * 0.08;
            } else {
                // Rolling hills
                y = baseY + Math.sin(x * 0.012 + 2) * skyH * 0.1 + Math.sin(x * 0.03) * skyH * 0.05;
            }
            farG.lineTo(x, y);
        }
        farG.lineTo(VW + 10, skyH + 10); farG.closePath(); farG.fill();
        layers.push(farG);

        // ── LAYER 3: MID TERRAIN (treeline/structures between mountains and ground) ──
        const midG = scene.add.graphics().setDepth(0.02).setScrollFactor(0);
        const midCol = this._todTint(biome.ground, tod, 0.7);
        midG.fillStyle(midCol, 0.9);
        midG.beginPath(); midG.moveTo(-10, skyH + 10);
        for (let x = -10; x <= VW + 10; x += 3) {
            const baseY = skyH * 0.8;
            let y;
            if (biomeId === 'grassy') {
                y = baseY + Math.sin(x * 0.015 + 0.5) * skyH * 0.06 + Math.cos(x * 0.05) * skyH * 0.03;
            } else if (biomeId === 'barren') {
                y = baseY + Math.sin(x * 0.008) * skyH * 0.04;
            } else {
                y = baseY + Math.sin(x * 0.02) * skyH * 0.05 + Math.abs(Math.sin(x * 0.07)) * skyH * 0.03;
            }
            midG.lineTo(x, y);
        }
        midG.lineTo(VW + 10, skyH + 10); midG.closePath(); midG.fill();
        // Accent details on mid layer
        const accentCol = this._todTint(biome.groundAccent, tod, 0.8);
        midG.fillStyle(accentCol, 0.4);
        if (biomeId === 'grassy') {
            for (let i = 0; i < 8; i++) {
                const bx = Phaser.Math.Between(20, VW - 20);
                const by = skyH * 0.82 + Phaser.Math.Between(-4, 8);
                midG.fillEllipse(bx, by, Phaser.Math.Between(10, 24), Phaser.Math.Between(6, 12));
            }
        } else if (biomeId === 'apocalyptic') {
            for (let i = 0; i < 5; i++) {
                const bx = Phaser.Math.Between(30, VW - 30);
                const by = skyH * 0.85 + Phaser.Math.Between(-2, 4);
                midG.fillRect(bx - 2, by - 8, 4, 10);
            }
        }
        layers.push(midG);

        // Note: No near-details or foreground-framing layers — they caused
        // interior overlay issues due to scroll factor mismatch with game objects.
        // The 3-layer sky (gradient + mountains + mid terrain) provides sufficient depth.

        return layers;
    },

    // Create parallax for menu (auto-drift, no camera scroll)
    createForMenu(scene, biomeId, tod, yOffset, height) {
        const VW = CONFIG.width;
        const palette = (this._skyPalettes[biomeId] || this._skyPalettes.grassy)[tod || 'midday'];
        const biome = BIOMES[biomeId] || BIOMES.grassy;
        const layers = [];
        const scale = height / 80; // scale relative to preview height

        // Sky gradient
        const skyG = scene.add.graphics().setDepth(0.5);
        for (let y = 0; y < height; y++) {
            const t = y / height;
            const col = this._lerpColor(palette.top, palette.low, t);
            skyG.fillStyle(col, 0.9);
            skyG.fillRect(0, yOffset + y, VW, 2);
        }
        layers.push(skyG);

        // Far mountains
        const farG = scene.add.graphics().setDepth(0.6);
        const farCol = this._todTint(biome.mountain, tod || 'midday', 0.6);
        farG.fillStyle(farCol, 0.8);
        farG.beginPath(); farG.moveTo(0, yOffset + height * 0.7);
        this._drawSilhouetteScaled(farG, biomeId, 'far_front', VW, height * 0.25, yOffset + height * 0.35);
        farG.lineTo(VW, yOffset + height * 0.7); farG.closePath(); farG.fill();
        layers.push(farG);

        // Ground fill
        const gCol = this._todTint(biome.ground, tod || 'midday', 0.8);
        const groundG = scene.add.graphics().setDepth(0.7);
        groundG.fillStyle(gCol, 1);
        groundG.fillRect(0, yOffset + height * 0.65, VW, height * 0.4);
        layers.push(groundG);

        return { layers, driftPhase: 0 };
    },

    // Auto-drift update for menu previews (call from scene.update)
    updateMenuDrift(layers, delta) {
        // Menu parallax uses x-position drift — layers shift left slowly
        if (!layers || !layers.layers) return;
        layers.driftPhase += delta * 0.00005;
    },

    // ── SILHOUETTE GENERATORS ──
    _drawSilhouette(g, biomeId, layer, W) {
        if (biomeId === 'grassy') {
            if (layer === 'far_back') {
                // Gentle rolling hills
                for (let x = -50; x <= W + 50; x += 5) {
                    const y = 260 + Math.sin(x * 0.008) * 35 + Math.sin(x * 0.018 + 1) * 20 + Math.sin(x * 0.004) * 15;
                    g.lineTo(x, y);
                }
            } else if (layer === 'far_front') {
                // Slightly taller rolling terrain
                for (let x = -50; x <= W + 50; x += 4) {
                    const y = 275 + Math.sin(x * 0.01 + 2) * 30 + Math.sin(x * 0.025) * 18 + Math.sin(x * 0.006 + 1) * 12;
                    g.lineTo(x, y);
                }
            } else if (layer === 'mid') {
                // Tree canopy outlines — rounded bumps
                for (let x = -50; x <= W + 50; x += 3) {
                    const base = 350 + Math.sin(x * 0.012) * 8;
                    const tree = Math.max(0, Math.sin(x * 0.035 + 0.5) * 22 + Math.sin(x * 0.08) * 10);
                    g.lineTo(x, base - tree);
                }
            }
        } else if (biomeId === 'barren') {
            if (layer === 'far_back') {
                // Flat mesas with sharp cliff edges
                let y = 280;
                for (let x = -50; x <= W + 50; x += 3) {
                    const mesa = Math.sin(x * 0.004 + 1) > 0.3 ? -40 - Math.sin(x * 0.002) * 15 : 0;
                    const target = 280 + mesa + Math.sin(x * 0.015) * 5;
                    y += (target - y) * 0.15; // Sharp transitions
                    g.lineTo(x, y);
                }
            } else if (layer === 'far_front') {
                let y = 290;
                for (let x = -50; x <= W + 50; x += 3) {
                    const mesa = Math.sin(x * 0.006) > 0.4 ? -30 - Math.sin(x * 0.003 + 2) * 12 : 0;
                    const target = 295 + mesa + Math.sin(x * 0.02 + 1) * 4;
                    y += (target - y) * 0.2;
                    g.lineTo(x, y);
                }
            } else if (layer === 'mid') {
                // Eroded buttes — flat tops with steep sides
                for (let x = -50; x <= W + 50; x += 3) {
                    const butte = Math.abs(Math.sin(x * 0.008 + 2)) > 0.7 ? -15 : 0;
                    const y = 360 + butte + Math.sin(x * 0.03) * 4;
                    g.lineTo(x, y);
                }
            }
        } else { // apocalyptic
            if (layer === 'far_back') {
                // Twisted spires — jagged vertical bursts
                for (let x = -50; x <= W + 50; x += 3) {
                    const spike = Math.sin(x * 0.05) * Math.sin(x * 0.013 + 1);
                    const y = 270 + spike * 50 + Math.sin(x * 0.007) * 15;
                    g.lineTo(x, Math.max(200, y));
                }
            } else if (layer === 'far_front') {
                for (let x = -50; x <= W + 50; x += 3) {
                    const spike = Math.sin(x * 0.04 + 2) * Math.sin(x * 0.017);
                    const y = 285 + spike * 40 + Math.sin(x * 0.009 + 3) * 12;
                    g.lineTo(x, Math.max(220, y));
                }
            } else if (layer === 'mid') {
                // Collapsed structures — angular, broken geometry
                for (let x = -50; x <= W + 50; x += 3) {
                    const angle = (Math.sin(x * 0.02 + 1) + Math.sin(x * 0.06)) * 0.5;
                    const collapse = angle > 0.3 ? -20 * angle : 0;
                    const y = 360 + collapse + Math.sin(x * 0.04) * 6;
                    g.lineTo(x, y);
                }
            }
        }
    },

    _drawSilhouetteScaled(g, biomeId, layer, w, h, baseY, xOffset) {
        const ox = xOffset || 0;
        // Scaled version for menu previews
        if (biomeId === 'grassy') {
            for (let x = 0; x <= w; x += 3) {
                const y = baseY + Math.sin(x * 0.02 + 2) * h * 0.5 + Math.sin(x * 0.05) * h * 0.3;
                g.lineTo(ox + x, y);
            }
        } else if (biomeId === 'barren') {
            let y = baseY;
            for (let x = 0; x <= w; x += 3) {
                const mesa = Math.sin(x * 0.012) > 0.3 ? -h * 0.5 : 0;
                const target = baseY + mesa + Math.sin(x * 0.03) * h * 0.1;
                y += (target - y) * 0.15;
                g.lineTo(ox + x, y);
            }
        } else {
            for (let x = 0; x <= w; x += 3) {
                const spike = Math.sin(x * 0.08) * Math.sin(x * 0.025 + 1);
                const y = baseY + spike * h * 0.6 + Math.sin(x * 0.015) * h * 0.15;
                g.lineTo(ox + x, Math.max(baseY - h, y));
            }
        }
    },

    _drawMidDetails(g, biomeId, W) {
        if (biomeId === 'grassy') {
            // Bush clusters
            for (let i = 0; i < 15; i++) {
                const x = Phaser.Math.Between(0, W);
                const y = 355 + Phaser.Math.Between(0, 20);
                g.fillEllipse(x, y, Phaser.Math.Between(6, 16), Phaser.Math.Between(4, 8));
            }
        } else if (biomeId === 'barren') {
            // Cracked ground lines
            for (let i = 0; i < 10; i++) {
                const x = Phaser.Math.Between(50, W - 50);
                const y = 360 + Phaser.Math.Between(0, 15);
                g.fillRect(x, y, Phaser.Math.Between(15, 40), 1);
            }
        } else {
            // Void patches
            for (let i = 0; i < 8; i++) {
                const x = Phaser.Math.Between(50, W - 50);
                const y = 350 + Phaser.Math.Between(0, 25);
                g.fillStyle(0x0a0a12, 0.3);
                g.fillEllipse(x, y, Phaser.Math.Between(8, 20), Phaser.Math.Between(4, 10));
            }
        }
    },

    _drawNearDetails(scene, container, biomeId, tod, W) {
        const tint = (c) => this._todTint(c, tod, 0.85);
        if (biomeId === 'grassy') {
            // Scattered bushes and grass tufts
            for (let i = 0; i < 20; i++) {
                const x = Phaser.Math.Between(-50, W + 50);
                const y = 340 + Phaser.Math.Between(10, 50);
                const bw = Phaser.Math.Between(6, 14);
                const bh = Phaser.Math.Between(4, 8);
                container.add(scene.add.ellipse(x, y, bw, bh, tint(0x2a4a2a), 0.7));
                if (Math.random() < 0.3) {
                    container.add(scene.add.ellipse(x, y - 2, bw * 0.7, bh * 0.7, tint(0x3a5a3a), 0.5));
                }
            }
            // Wildflower dots
            for (let i = 0; i < 12; i++) {
                const x = Phaser.Math.Between(0, W);
                const y = 355 + Phaser.Math.Between(5, 40);
                const fc = Phaser.Utils.Array.GetRandom([0xddcc44, 0xcc6644, 0xaa88cc, 0xeeee88]);
                container.add(scene.add.circle(x, y, 1.5, tint(fc), 0.6));
            }
        } else if (biomeId === 'barren') {
            // Dead scrub and rocks
            for (let i = 0; i < 12; i++) {
                const x = Phaser.Math.Between(-50, W + 50);
                const y = 350 + Phaser.Math.Between(5, 40);
                container.add(scene.add.ellipse(x, y, Phaser.Math.Between(4, 10), Phaser.Math.Between(3, 6), tint(0x4a4030), 0.5));
            }
            // Small rocks
            for (let i = 0; i < 8; i++) {
                const x = Phaser.Math.Between(0, W);
                const y = 360 + Phaser.Math.Between(0, 30);
                container.add(scene.add.ellipse(x, y, Phaser.Math.Between(3, 8), Phaser.Math.Between(2, 4), tint(0x5a5040), 0.4));
            }
        } else {
            // Corrupted growths and debris
            for (let i = 0; i < 10; i++) {
                const x = Phaser.Math.Between(-50, W + 50);
                const y = 345 + Phaser.Math.Between(10, 45);
                const g = scene.add.graphics();
                const gc = tint(Phaser.Utils.Array.GetRandom([0x3a2a4a, 0x2a2a3a, 0x4a2a3a]));
                g.fillStyle(gc, 0.6);
                // Angular shards
                g.beginPath();
                g.moveTo(x, y);
                g.lineTo(x + Phaser.Math.Between(-4, 4), y - Phaser.Math.Between(6, 14));
                g.lineTo(x + Phaser.Math.Between(2, 8), y - Phaser.Math.Between(2, 6));
                g.closePath(); g.fill();
                container.add(g);
            }
            // Faint particles
            for (let i = 0; i < 6; i++) {
                const x = Phaser.Math.Between(50, W - 50);
                const y = 340 + Phaser.Math.Between(0, 50);
                const p = scene.add.circle(x, y, 1, 0x6644aa, 0.3);
                container.add(p);
                scene.tweens.add({
                    targets: p, y: y - 15, alpha: 0,
                    duration: Phaser.Math.Between(3000, 6000), repeat: -1,
                    delay: Phaser.Math.Between(0, 3000)
                });
            }
        }
    },

    _drawForeground(scene, container, biomeId, tod, W) {
        const tint = (c) => this._todTint(c, tod, 0.9);
        if (biomeId === 'grassy') {
            // Tall grass blades at edges
            for (let side = 0; side < 2; side++) {
                const baseX = side === 0 ? -20 : W + 20;
                const dir = side === 0 ? 1 : -1;
                for (let i = 0; i < 8; i++) {
                    const x = baseX + dir * Phaser.Math.Between(5, 40);
                    const y = 340 + Phaser.Math.Between(20, 60);
                    const g = scene.add.graphics();
                    g.fillStyle(tint(0x2a4a20), 0.5);
                    g.fillTriangle(x, y, x + dir * 2, y - Phaser.Math.Between(12, 25), x + dir * 4, y);
                    container.add(g);
                }
            }
        } else if (biomeId === 'barren') {
            // Dust haze overlay
            const haze = scene.add.graphics();
            haze.fillStyle(tint(0x8a7a60), 0.06);
            haze.fillRect(-50, 360, W + 100, 30);
            container.add(haze);
        } else {
            // Chromatic edge distortion
            const edgeL = scene.add.rectangle(10, 355, 6, 40, 0x4422aa, 0.08);
            const edgeR = scene.add.rectangle(W - 10, 355, 6, 40, 0xaa2244, 0.08);
            container.add(edgeL); container.add(edgeR);
            scene.tweens.add({ targets: [edgeL, edgeR], alpha: { from: 0.04, to: 0.12 }, duration: 2000, yoyo: true, repeat: -1 });
        }
    },

    // ── COLOR UTILITIES ──
    _lerpColor(c1, c2, t) {
        const r1 = (c1 >> 16) & 0xff, g1 = (c1 >> 8) & 0xff, b1 = c1 & 0xff;
        const r2 = (c2 >> 16) & 0xff, g2 = (c2 >> 8) & 0xff, b2 = c2 & 0xff;
        const r = Math.round(r1 + (r2 - r1) * t);
        const g = Math.round(g1 + (g2 - g1) * t);
        const b = Math.round(b1 + (b2 - b1) * t);
        return (r << 16) | (g << 8) | b;
    },

    _todTint(color, tod, strength) {
        const tints = { dawn: 0xffaa77, midday: 0xffffff, dusk: 0xff7755, night: 0x5566aa };
        const tint = tints[tod] || tints.midday;
        return this._lerpColor(color, tint, 1 - strength);
    },

    // Destroy all layers
    destroy(layers) {
        if (!layers) return;
        const list = Array.isArray(layers) ? layers : (layers.layers || []);
        list.forEach(l => { try { if (l && l.destroy) l.destroy(); } catch(e) {} });
    }
};

