// Vestige GPS — CRTTypewriter
// Extracted from monolith L30377-30426

import { AudioManager } from './audioManager.js';


export const CRTTypewriter = {
    type(scene, textObj, opts = {}) {
        const fullText = textObj.text;
        const speed = opts.speed || 30;
        const sound = opts.sound !== false;
        textObj.setText('');
        textObj._twFull = fullText;
        textObj._twDone = false;
        
        let idx = 0;
        const timer = scene.time.addEvent({
            delay: speed,
            repeat: fullText.length - 1,
            callback: () => {
                if (!textObj || !textObj.active) { timer.remove(); return; }
                idx++;
                if (idx < fullText.length) {
                    textObj.setText(fullText.substring(0, idx) + '▌');
                } else {
                    textObj.setText(fullText + ' ▌');
                    textObj._twDone = true;
                    let blinks = 0;
                    const blinkTimer = scene.time.addEvent({
                        delay: 300, repeat: 5,
                        callback: () => {
                            if (!textObj || !textObj.active) { blinkTimer.remove(); return; }
                            blinks++;
                            textObj.setText(blinks % 2 === 0 ? fullText + ' ▌' : fullText);
                        }
                    });
                    scene.time.delayedCall(2000, () => {
                        if (textObj && textObj.active) textObj.setText(fullText);
                    });
                    if (opts.onComplete) opts.onComplete();
                }
                if (sound && idx % 2 === 0) {
                    try { AudioManager.crtType(); } catch(e) {}
                }
            }
        });
        textObj._twTimer = timer;
        return timer;
    },
    
    skip(textObj) {
        if (textObj._twTimer) { textObj._twTimer.remove(); textObj._twTimer = null; }
        if (textObj._twFull) textObj.setText(textObj._twFull);
        textObj._twDone = true;
    }
};

