// Vestige GPS — InteractHighlight
// Extracted from monolith lines 30437-30505
// TODO: convert internal global refs to imports

export const InteractHighlight = {
    _scenes: new Map(),
    
    show(scene, target, label, opts = {}) {
        const key = scene.scene.key;
        let state = this._scenes.get(key);
        
        if (!state) {
            const dot = scene.add.circle(0, 0, 3, 0xddcc66, 0.9).setDepth(997);
            const ring = scene.add.graphics().setDepth(996);
            state = { dot, ring, target, phase: 0 };
            this._scenes.set(key, state);
        } else {
            state.target = target;
            state.dot.setVisible(true);
            state.ring.setVisible(true);
        }
        
        const tx = target.x || 0;
        const ty = target.y || 0;
        
        // Phase drives the ring expansion (0 → 1 over ~1.5s at 60fps)
        state.phase = (state.phase + 0.012) % 1;
        const p = state.phase;
        
        // Center dot — gentle pulse
        const dotPulse = 0.6 + Math.sin(p * Math.PI * 2) * 0.3;
        state.dot.setPosition(tx, ty);
        state.dot.setAlpha(dotPulse);
        
        // Expanding ring — grows from 4px to 18px radius, fades out
        const ringR = 4 + p * 14;
        const ringAlpha = (1 - p) * 0.5;
        const g = state.ring;
        g.clear();
        g.lineStyle(1.5, 0xccaa55, ringAlpha);
        g.strokeCircle(tx, ty, ringR);
    },
    
    hide(scene) {
        const state = this._scenes.get(scene.scene.key);
        if (!state) return;
        state.dot.setVisible(false);
        state.ring.setVisible(false).clear();
        state.target = null;
    },
    
    getTarget(scene) {
        const state = this._scenes.get(scene.scene.key);
        return state ? state.target : null;
    },
    
    checkTap(scene, worldX, worldY, maxDist) {
        const state = this._scenes.get(scene.scene.key);
        if (!state || !state.target || !state.dot.visible) return false;
        const t = state.target;
        const dist = Phaser.Math.Distance.Between(worldX, worldY, t.x || 0, t.y || 0);
        return dist < (maxDist || 50);
    },
    
    destroy(scene) {
        const key = scene.scene.key;
        const state = this._scenes.get(key);
        if (!state) return;
        if (state.dot) state.dot.destroy();
        if (state.ring) state.ring.destroy();
        this._scenes.delete(key);
    }
};
