// Vestige GPS — VehicleFleet
// Extracted from monolith L5896-6308

export const VehicleFleet = {
    TYPES: ['humvee','suv','cargo','police','pickup'],
    DIRS: ['down','right','up','left'], // frame column order
    FW: 64, FH: 64,
    _ready: false,
    _canvas: null,

    // Color palettes per type
    palettes: {
        humvee:  { main:'#5a6b3a', dark:'#3a4a28', light:'#7a8b50', met:'#4a4a3a', win:'#2a3a2a' },
        suv:     { main:'#a0a8b0', dark:'#707880', light:'#c0c8d0', met:'#888890', win:'#3a4a5a' },
        cargo:   { main:'#5a6b3a', dark:'#3a4a28', light:'#7a8b50', met:'#4a4a3a', win:'#2a3a2a' },
        police:  { main:'#1a1a2a', dark:'#0a0a18', light:'#2a2a3a', met:'#333333', win:'#2a3a4a', white:'#e0e0e8' },
        pickup:  { main:'#5a5a60', dark:'#3a3a40', light:'#7a7a82', met:'#4a4a50', win:'#2a3a4a' },
    },

    // Wreck palettes — muted, burnt versions
    wreckPalettes: [
        { main:'#4a4540', dark:'#2a2520', light:'#5a5550', met:'#3a3a3a', win:'#1a2020' },
        { main:'#554433', dark:'#3a2a20', light:'#665544', met:'#3a3530', win:'#1a2020' },
        { main:'#664444', dark:'#4a2a2a', light:'#775555', met:'#3a3030', win:'#1a1a1a' },
        { main:'#445566', dark:'#2a3540', light:'#556677', met:'#3a3a3a', win:'#1a2530' },
        { main:'#555555', dark:'#3a3a3a', light:'#666666', met:'#333333', win:'#1a1a1a' },
        { main:'#5a5040', dark:'#3a3530', light:'#6a6050', met:'#3a3530', win:'#1a1a18' },
    ],

    generate() {
        const FW=this.FW, FH=this.FH;
        const canvas = document.createElement('canvas');
        // 4 cols × 10 rows (5 normal + 5 wrecked)
        canvas.width = FW * 4; canvas.height = FH * 10;
        const ctx = canvas.getContext('2d');
        const R=(cx,cy,w,h,c,a)=>{ctx.globalAlpha=a!==undefined?a:1;ctx.fillStyle=c;ctx.fillRect(Math.round(cx-w/2),Math.round(cy-h/2),Math.round(w),Math.round(h));ctx.globalAlpha=1;};
        const E=(cx,cy,w,h,c,a)=>{ctx.globalAlpha=a!==undefined?a:1;ctx.fillStyle=c;ctx.beginPath();ctx.ellipse(Math.round(cx),Math.round(cy),w/2,h/2,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;};
        const trap=(x1,x2,x3,x4,y1,y2,c,a)=>{ctx.globalAlpha=a!==undefined?a:1;ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y1);ctx.lineTo(x4,y2);ctx.lineTo(x3,y2);ctx.closePath();ctx.fill();ctx.globalAlpha=1;};
        const bk='#1a1a1a',hub='#2a2a2a',hl='#ffffaa',hd='#ffaa44',tl='#aa2222',td='#881111';

        // Draw a vehicle type at a given row with a palette
        const self = this;

        function drawHumvee(row, p) {
            const M=p.main,D=p.dark,L=p.light,Mt=p.met,W=p.win;
            // DOWN
            let ox=0,oy=row*FH,cx=ox+32,b=oy+48;
            E(cx,b+4,54,12,'#000',0.3);R(cx-22,b+1,10,6,bk);R(cx+22,b+1,10,6,bk);
            R(cx-24,b-8,6,18,D);R(cx+24,b-8,6,18,D);R(cx,b-8,46,14,D);R(cx,b-16,44,10,M);
            R(cx,b-18,36,6,M);R(cx,b-20,30,3,L);
            R(cx,b-8,34,6,Mt);R(cx,b-8,30,2,'#222');R(cx,b-6,30,1,'#222');R(cx,b-10,30,1,'#222');
            R(cx-18,b-8,5,5,hl);R(cx+18,b-8,5,5,hl);R(cx-18,b-3,4,3,hd);R(cx+18,b-3,4,3,hd);
            R(cx,b-2,46,4,Mt);R(cx,b-1,42,2,'#333');R(cx,b+2,46,3,hub);
            R(cx,b-28,28,6,D);R(cx,b-32,26,4,M);R(cx,b-35,28,3,L);
            R(cx-6,b-25,10,6,W);R(cx+6,b-25,10,6,W);R(cx,b-25,3,6,D);
            R(cx-14,b-25,3,8,D);R(cx+14,b-25,3,8,D);
            R(cx,b-22,42,3,L,0.4);R(cx-8,b-38,1,6,'#444');
            // RIGHT
            ox=FW;cx=ox+32;b=oy+50;
            E(cx,b+3,58,12,'#000',0.3);
            E(cx-18,b+1,12,12,bk);E(cx-18,b+1,7,7,hub);E(cx+18,b+1,12,12,bk);E(cx+18,b+1,7,7,hub);
            R(cx-18,b-5,16,6,D);R(cx+18,b-5,16,6,D);R(cx,b,50,5,bk);R(cx,b-8,54,10,D);R(cx,b-14,52,7,M);
            trap(cx+14,cx+28,cx+14,cx+28,b-17,b-8,M);R(cx+20,b-10,16,6,M);R(cx+22,b-12,10,3,L);R(cx-24,b-10,8,8,D);
            R(cx-4,b-20,24,6,D);R(cx-4,b-23,24,4,M);R(cx-4,b-25,26,3,L);
            R(cx+4,b-18,5,8,W);R(cx+11,b-18,5,8,W);R(cx+8,b-18,2,8,D);R(cx-8,b-19,8,5,W);
            R(cx+13,b-18,4,10,D);R(cx-13,b-18,4,8,D);
            R(cx+26,b-12,3,4,hl);R(cx+26,b-7,3,3,hd);R(cx-26,b-12,3,4,tl);R(cx-26,b-7,3,3,'#661111');
            R(cx+27,b-2,4,8,Mt);R(cx-26,b-2,4,8,Mt);R(cx-8,b-29,1,8,'#444');R(cx-4,b-26,28,2,L,0.4);
            // UP
            ox=FW*2;cx=ox+32;b=oy+48;
            E(cx,b+4,54,12,'#000',0.3);R(cx-22,b+1,10,6,bk);R(cx+22,b+1,10,6,bk);
            R(cx-24,b-10,6,18,D);R(cx+24,b-10,6,18,D);R(cx,b-8,46,14,D);R(cx,b-16,44,10,M);
            R(cx,b-8,36,8,D);R(cx,b-8,28,4,Mt,0.2);
            R(cx-18,b-10,5,6,tl);R(cx+18,b-10,5,6,tl);R(cx-18,b-6,5,3,'#661111');R(cx+18,b-6,5,3,'#661111');
            R(cx,b-6,8,4,'#333');R(cx,b-2,46,4,Mt);R(cx,b+2,46,3,hub);
            R(cx,b-28,28,6,D);R(cx,b-32,26,4,M);R(cx,b-35,28,3,L);
            R(cx,b-25,20,5,W);R(cx-12,b-25,3,8,D);R(cx+12,b-25,3,8,D);
            R(cx,b-22,42,3,L,0.4);R(cx-8,b-38,1,6,'#444');
            // LEFT
            ox=FW*3;cx=ox+32;b=oy+50;
            E(cx,b+3,58,12,'#000',0.3);
            E(cx+18,b+1,12,12,bk);E(cx+18,b+1,7,7,hub);E(cx-18,b+1,12,12,bk);E(cx-18,b+1,7,7,hub);
            R(cx+18,b-5,16,6,D);R(cx-18,b-5,16,6,D);R(cx,b,50,5,bk);R(cx,b-8,54,10,D);R(cx,b-14,52,7,M);
            trap(cx-28,cx-14,cx-28,cx-14,b-17,b-8,M);R(cx-20,b-10,16,6,M);R(cx-22,b-12,10,3,L);R(cx+24,b-10,8,8,D);
            R(cx+4,b-20,24,6,D);R(cx+4,b-23,24,4,M);R(cx+4,b-25,26,3,L);
            R(cx-4,b-18,5,8,W);R(cx-11,b-18,5,8,W);R(cx-8,b-18,2,8,D);R(cx+8,b-19,8,5,W);
            R(cx-13,b-18,4,10,D);R(cx+13,b-18,4,8,D);
            R(cx-26,b-12,3,4,hl);R(cx-26,b-7,3,3,hd);R(cx+26,b-12,3,4,tl);R(cx+26,b-7,3,3,'#661111');
            R(cx-27,b-2,4,8,Mt);R(cx+26,b-2,4,8,Mt);R(cx+8,b-29,1,8,'#444');R(cx+4,b-26,28,2,L,0.4);
        }

        function drawSUV(row, p) {
            const M=p.main,D=p.dark,L=p.light,Mt=p.met,W=p.win;
            // DOWN
            let ox=0,oy=row*FH,cx=ox+32,b=oy+48;
            E(cx,b+4,48,12,'#000',0.3);R(cx-18,b+1,8,6,bk);R(cx+18,b+1,8,6,bk);
            R(cx-20,b-14,4,22,D);R(cx+20,b-14,4,22,D);
            R(cx,b-8,38,12,D);R(cx,b-16,36,10,M);R(cx,b-18,30,4,L);
            R(cx,b-8,28,8,Mt);R(cx,b-8,24,5,'#aaa');R(cx,b-8,20,2,'#666');
            R(cx-15,b-8,5,5,hl);R(cx+15,b-8,5,5,hl);R(cx-14,b-3,4,3,hd);R(cx+14,b-3,4,3,hd);
            R(cx,b-2,40,4,Mt);R(cx,b-1,38,2,'#aaa');
            R(cx,b-28,30,10,D);R(cx,b-34,28,7,M);R(cx,b-38,26,4,L);
            R(cx,b-26,26,8,W);R(cx-14,b-26,3,12,D);R(cx+14,b-26,3,12,D);
            R(cx,b-40,22,1,Mt);R(cx,b-22,36,3,L,0.4);
            // RIGHT — _/===| profile
            ox=FW;cx=ox+32;b=oy+48;
            E(cx,b+5,54,12,'#000',0.3);
            E(cx-16,b+2,10,10,bk);E(cx-16,b+2,6,6,hub);E(cx+16,b+2,10,10,bk);E(cx+16,b+2,6,6,hub);
            R(cx,b-1,48,5,bk);R(cx,b-8,50,10,D);R(cx,b-14,48,8,M);
            trap(cx+12,cx+26,cx+16,cx+26,b-16,b-8,M);R(cx+22,b-12,8,3,L);
            R(cx-24,b-12,4,14,D);
            R(cx-6,b-22,34,10,D);R(cx-6,b-28,32,7,M);R(cx-6,b-32,34,4,L);
            trap(cx+8,cx+16,cx+4,cx+16,b-30,b-16,D);
            R(cx+10,b-22,8,12,W);R(cx-4,b-24,10,10,W);R(cx-14,b-24,8,10,W);
            R(cx+15,b-22,3,16,D);R(cx-19,b-22,3,14,D);R(cx-1,b-22,2,12,D);R(cx-9,b-22,2,12,D);
            R(cx-6,b-34,28,1,Mt);R(cx-6,b-36,28,1,Mt);R(cx-14,b-35,2,4,Mt);R(cx+6,b-35,2,4,Mt);
            R(cx+26,b-12,3,4,hl);R(cx+26,b-7,3,3,hd);
            R(cx-25,b-14,3,8,tl);R(cx-25,b-7,3,3,td);
            R(cx+26,b-2,3,6,Mt);R(cx-25,b-2,3,6,Mt);
            E(cx-16,b-4,12,6,D);E(cx+16,b-4,12,6,D);
            // UP
            ox=FW*2;cx=ox+32;b=oy+48;
            E(cx,b+4,48,12,'#000',0.3);R(cx-18,b+1,8,6,bk);R(cx+18,b+1,8,6,bk);
            R(cx-20,b-16,4,22,D);R(cx+20,b-16,4,22,D);
            R(cx,b-8,38,12,D);R(cx,b-16,36,10,M);
            R(cx,b-8,32,8,D);R(cx,b-8,24,4,Mt,0.15);
            R(cx-15,b-14,4,8,tl);R(cx+15,b-14,4,8,tl);R(cx-15,b-7,4,3,td);R(cx+15,b-7,4,3,td);
            R(cx,b-6,10,4,'#333');R(cx,b-6,8,3,'#555',0.4);R(cx,b-2,40,4,Mt);
            R(cx,b-28,30,10,D);R(cx,b-34,28,7,M);R(cx,b-38,26,4,L);
            R(cx,b-26,22,7,W);R(cx-13,b-26,3,12,D);R(cx+13,b-26,3,12,D);
            R(cx,b-40,22,1,Mt);R(cx,b-22,36,3,L,0.35);R(cx,b-24,10,1,D);
            // LEFT — mirror
            ox=FW*3;cx=ox+32;b=oy+48;
            E(cx,b+5,54,12,'#000',0.3);
            E(cx+16,b+2,10,10,bk);E(cx+16,b+2,6,6,hub);E(cx-16,b+2,10,10,bk);E(cx-16,b+2,6,6,hub);
            R(cx,b-1,48,5,bk);R(cx,b-8,50,10,D);R(cx,b-14,48,8,M);
            trap(cx-26,cx-12,cx-26,cx-16,b-16,b-8,M);R(cx-22,b-12,8,3,L);
            R(cx+24,b-12,4,14,D);
            R(cx+6,b-22,34,10,D);R(cx+6,b-28,32,7,M);R(cx+6,b-32,34,4,L);
            trap(cx-16,cx-8,cx-16,cx-4,b-30,b-16,D);
            R(cx-10,b-22,8,12,W);R(cx+4,b-24,10,10,W);R(cx+14,b-24,8,10,W);
            R(cx-15,b-22,3,16,D);R(cx+19,b-22,3,14,D);R(cx+1,b-22,2,12,D);R(cx+9,b-22,2,12,D);
            R(cx+6,b-34,28,1,Mt);R(cx+6,b-36,28,1,Mt);R(cx+14,b-35,2,4,Mt);R(cx-6,b-35,2,4,Mt);
            R(cx-26,b-12,3,4,hl);R(cx-26,b-7,3,3,hd);
            R(cx+25,b-14,3,8,tl);R(cx+25,b-7,3,3,td);
            R(cx-26,b-2,3,6,Mt);R(cx+25,b-2,3,6,Mt);
            E(cx+16,b-4,12,6,D);E(cx-16,b-4,12,6,D);
        }

        function drawCargo(row, p) {
            const M=p.main,D=p.dark,L=p.light,Mt=p.met,W=p.win;
            // DOWN
            let ox=0,oy=row*FH,cx=ox+32,b=oy+48;
            E(cx,b+4,48,12,'#000',0.3);R(cx-18,b+1,10,6,bk);R(cx+18,b+1,10,6,bk);
            R(cx-20,b-14,5,20,D);R(cx+20,b-14,5,20,D);
            R(cx,b-10,40,14,D);R(cx,b-18,38,10,M);
            R(cx,b-10,30,8,Mt);R(cx,b-10,26,4,'#222');R(cx,b-8,26,1,'#333');R(cx,b-12,26,1,'#333');
            R(cx-16,b-10,6,5,hl);R(cx+16,b-10,6,5,hl);R(cx-15,b-4,5,3,hd);R(cx+15,b-4,5,3,hd);
            R(cx,b-3,42,5,Mt);R(cx,b,42,3,hub);
            R(cx,b-26,32,6,D);R(cx,b-30,30,4,M);R(cx,b-33,28,3,L);
            R(cx,b-24,26,5,W);R(cx-14,b-24,3,8,D);R(cx+14,b-24,3,8,D);
            R(cx,b-36,36,3,L,0.4);
            // RIGHT
            ox=FW;cx=ox+32;b=oy+47;
            E(cx,b+5,58,12,'#000',0.3);
            E(cx-18,b+2,10,10,bk);E(cx-18,b+2,6,6,hub);E(cx-14,b+2,10,10,bk);E(cx-14,b+2,6,6,hub);
            E(cx+20,b+2,10,10,bk);E(cx+20,b+2,6,6,hub);
            R(cx,b,52,5,bk);
            R(cx-8,b-8,38,12,D);R(cx-8,b-16,36,10,M);R(cx-8,b-22,36,6,D);R(cx-8,b-25,36,3,L);
            R(cx-8,b-12,34,1,'#2a3a1a',0.3);R(cx-8,b-18,34,1,'#2a3a1a',0.3);
            R(cx+22,b-8,14,12,D);R(cx+22,b-14,12,8,M);R(cx+22,b-17,10,8,W);
            R(cx+22,b-21,12,4,D);R(cx+22,b-23,12,2,L);
            R(cx+29,b-10,3,4,hl);R(cx+29,b-5,3,3,hd);R(cx-27,b-10,3,4,tl);R(cx-27,b-5,3,3,'#661111');
            R(cx+29,b-1,3,6,Mt);R(cx-27,b-1,3,6,Mt);
            E(cx-16,b-2,14,6,D);E(cx+20,b-2,12,6,D);
            // UP
            ox=FW*2;cx=ox+32;b=oy+48;
            E(cx,b+4,48,12,'#000',0.3);R(cx-18,b+1,10,6,bk);R(cx+18,b+1,10,6,bk);
            R(cx-20,b-14,5,20,D);R(cx+20,b-14,5,20,D);
            R(cx,b-10,40,14,D);R(cx,b-18,38,10,M);
            R(cx,b-10,30,10,D);R(cx-1,b-10,2,10,Mt);R(cx,b-10,28,1,Mt,0.3);
            R(cx-16,b-12,5,6,tl);R(cx+16,b-12,5,6,tl);R(cx-16,b-7,5,3,'#661111');R(cx+16,b-7,5,3,'#661111');
            R(cx,b-3,42,5,Mt);R(cx,b,42,3,hub);
            R(cx,b-28,30,4,D);R(cx,b-31,28,3,M);R(cx,b-34,26,3,L);R(cx,b-24,38,3,L,0.35);
            // LEFT
            ox=FW*3;cx=ox+32;b=oy+47;
            E(cx,b+5,58,12,'#000',0.3);
            E(cx+18,b+2,10,10,bk);E(cx+18,b+2,6,6,hub);E(cx+14,b+2,10,10,bk);E(cx+14,b+2,6,6,hub);
            E(cx-20,b+2,10,10,bk);E(cx-20,b+2,6,6,hub);
            R(cx,b,52,5,bk);
            R(cx+8,b-8,38,12,D);R(cx+8,b-16,36,10,M);R(cx+8,b-22,36,6,D);R(cx+8,b-25,36,3,L);
            R(cx+8,b-12,34,1,'#2a3a1a',0.3);R(cx+8,b-18,34,1,'#2a3a1a',0.3);
            R(cx-22,b-8,14,12,D);R(cx-22,b-14,12,8,M);R(cx-22,b-17,10,8,W);
            R(cx-22,b-21,12,4,D);R(cx-22,b-23,12,2,L);
            R(cx-29,b-10,3,4,hl);R(cx-29,b-5,3,3,hd);R(cx+27,b-10,3,4,tl);R(cx+27,b-5,3,3,'#661111');
            R(cx-29,b-1,3,6,Mt);R(cx+27,b-1,3,6,Mt);
            E(cx+16,b-2,14,6,D);E(cx-20,b-2,12,6,D);
        }

        function drawPolice(row, p) {
            const M=p.main,D=p.dark,L=p.light,Mt=p.met,W=p.win,PW=p.white||'#e0e0e8';
            // DOWN
            let ox=0,oy=row*FH,cx=ox+32,b=oy+48;
            E(cx,b+4,48,12,'#000',0.3);R(cx-18,b+1,8,6,bk);R(cx+18,b+1,8,6,bk);
            R(cx-20,b-16,4,20,M);R(cx+20,b-16,4,20,M);
            R(cx,b-8,38,10,PW);R(cx,b-18,36,10,M);R(cx,b-20,30,4,L);
            R(cx,b-10,28,5,'#333');R(cx,b-10,24,3,'#222');
            R(cx-15,b-10,5,4,hl);R(cx+15,b-10,5,4,hl);R(cx-14,b-5,4,3,hd);R(cx+14,b-5,4,3,hd);
            R(cx,b-4,34,3,'#333');R(cx-14,b-4,3,5,'#444');R(cx+14,b-4,3,5,'#444');R(cx,b,40,3,hub);
            R(cx,b-30,30,6,D);R(cx,b-34,28,4,M);R(cx,b-37,26,3,L);
            R(cx,b-27,26,6,W);R(cx-14,b-27,3,10,D);R(cx+14,b-27,3,10,D);
            R(cx,b-39,24,3,D);R(cx-8,b-39,8,3,'#ff2222');R(cx+8,b-39,8,3,'#4444ff');R(cx,b-39,4,3,'#aaa');
            R(cx,b-24,36,3,L,0.4);
            // RIGHT
            ox=FW;cx=ox+32;b=oy+46;
            E(cx,b+6,54,12,'#000',0.3);
            E(cx-16,b+2,10,10,bk);E(cx-16,b+2,6,6,hub);E(cx+16,b+2,10,10,bk);E(cx+16,b+2,6,6,hub);
            R(cx,b-1,48,5,'#0a0a0a');R(cx,b-8,50,10,PW);R(cx,b-14,48,8,M);R(cx,b-6,48,4,M);
            R(cx+20,b-10,12,8,M);R(cx+22,b-12,8,4,L);R(cx-20,b-10,10,8,M);
            R(cx-2,b-22,28,8,D);R(cx-2,b-26,26,6,M);R(cx-2,b-30,24,3,L);
            R(cx+6,b-20,10,10,W);R(cx-6,b-20,12,8,W);
            R(cx+12,b-20,3,12,D);R(cx-13,b-20,3,10,D);R(cx,b-20,2,10,D);
            R(cx-2,b-32,20,3,D);R(cx+4,b-32,8,3,'#ff2222');R(cx-8,b-32,8,3,'#4444ff');R(cx-2,b-32,3,3,'#aaa');
            R(cx+26,b-12,3,4,hl);R(cx+26,b-7,3,3,hd);R(cx-25,b-12,3,4,tl);R(cx-25,b-7,3,3,td);
            R(cx+28,b-4,3,10,'#333');R(cx+29,b-8,2,3,'#444');
            R(cx+26,b-2,3,6,'#333');R(cx-25,b-2,3,6,'#333');
            E(cx-16,b-4,12,6,M);E(cx+16,b-4,12,6,M);
            // UP
            ox=FW*2;cx=ox+32;b=oy+48;
            E(cx,b+4,48,12,'#000',0.3);R(cx-18,b+1,8,6,bk);R(cx+18,b+1,8,6,bk);
            R(cx-20,b-18,4,20,M);R(cx+20,b-18,4,20,M);
            R(cx,b-8,38,10,PW);R(cx,b-18,36,10,M);
            R(cx,b-10,30,6,M);R(cx,b-10,22,4,'#333',0.15);
            R(cx-15,b-12,5,6,tl);R(cx+15,b-12,5,6,tl);R(cx-15,b-7,5,3,td);R(cx+15,b-7,5,3,td);
            R(cx,b-7,10,4,'#333');R(cx,b-7,8,3,'#555',0.4);R(cx,b-4,40,4,'#333');
            R(cx,b-30,30,6,D);R(cx,b-34,28,4,M);R(cx,b-37,26,3,L);
            R(cx,b-27,22,5,W);R(cx-13,b-27,3,10,D);R(cx+13,b-27,3,10,D);
            R(cx,b-39,24,3,D);R(cx+8,b-39,8,3,'#ff2222');R(cx-8,b-39,8,3,'#4444ff');R(cx,b-39,4,3,'#aaa');
            R(cx,b-24,36,3,L,0.35);
            // LEFT
            ox=FW*3;cx=ox+32;b=oy+46;
            E(cx,b+6,54,12,'#000',0.3);
            E(cx+16,b+2,10,10,bk);E(cx+16,b+2,6,6,hub);E(cx-16,b+2,10,10,bk);E(cx-16,b+2,6,6,hub);
            R(cx,b-1,48,5,'#0a0a0a');R(cx,b-8,50,10,PW);R(cx,b-14,48,8,M);R(cx,b-6,48,4,M);
            R(cx-20,b-10,12,8,M);R(cx-22,b-12,8,4,L);R(cx+20,b-10,10,8,M);
            R(cx+2,b-22,28,8,D);R(cx+2,b-26,26,6,M);R(cx+2,b-30,24,3,L);
            R(cx-6,b-20,10,10,W);R(cx+6,b-20,12,8,W);
            R(cx-12,b-20,3,12,D);R(cx+13,b-20,3,10,D);R(cx,b-20,2,10,D);
            R(cx+2,b-32,20,3,D);R(cx-4,b-32,8,3,'#ff2222');R(cx+8,b-32,8,3,'#4444ff');R(cx+2,b-32,3,3,'#aaa');
            R(cx-26,b-12,3,4,hl);R(cx-26,b-7,3,3,hd);R(cx+25,b-12,3,4,tl);R(cx+25,b-7,3,3,td);
            R(cx-28,b-4,3,10,'#333');R(cx-29,b-8,2,3,'#444');
            R(cx-26,b-2,3,6,'#333');R(cx+25,b-2,3,6,'#333');
            E(cx+16,b-4,12,6,M);E(cx-16,b-4,12,6,M);
        }

        function drawPickup(row, p) {
            const M=p.main,D=p.dark,L=p.light,Mt=p.met,W=p.win;
            // DOWN
            let ox=0,oy=row*FH,cx=ox+32,b=oy+48;
            E(cx,b+4,48,12,'#000',0.3);R(cx-18,b+1,8,6,bk);R(cx+18,b+1,8,6,bk);
            R(cx-20,b-14,4,18,D);R(cx+20,b-14,4,18,D);
            R(cx,b-8,38,10,D);R(cx,b-16,36,10,M);R(cx,b-18,30,4,L);
            R(cx,b-10,30,6,Mt);R(cx,b-10,26,4,'#333');R(cx,b-10,22,2,'#222');
            R(cx-16,b-10,5,5,hl);R(cx+16,b-10,5,5,hl);R(cx-15,b-4,4,3,hd);R(cx+15,b-4,4,3,hd);
            R(cx,b-4,40,4,Mt);R(cx,b-2,38,2,'#333');
            R(cx,b-28,26,6,D);R(cx,b-32,24,4,M);R(cx,b-35,22,3,L);
            R(cx,b-25,22,6,W);R(cx-12,b-25,3,8,D);R(cx+12,b-25,3,8,D);
            R(cx,b-37,28,2,L,0.4);R(cx,b-22,36,3,L,0.35);
            // RIGHT
            ox=FW;cx=ox+32;b=oy+46;
            E(cx,b+6,56,12,'#000',0.3);
            E(cx-16,b+2,11,11,bk);E(cx-16,b+2,7,7,hub);E(cx+18,b+2,11,11,bk);E(cx+18,b+2,7,7,hub);
            R(cx,b-1,50,5,bk);
            R(cx-12,b-6,30,8,D);R(cx-12,b-10,28,4,M);R(cx-12,b-4,26,4,hub);R(cx-12,b-12,28,2,L);
            R(cx+16,b-8,18,12,D);R(cx+16,b-14,16,8,M);
            R(cx+22,b-10,10,8,M);R(cx+24,b-12,6,4,L);
            R(cx+10,b-22,16,8,D);R(cx+10,b-26,14,5,M);R(cx+10,b-29,14,3,L);
            R(cx+14,b-21,8,10,W);R(cx+4,b-20,6,8,W);
            R(cx+19,b-20,3,12,D);R(cx+1,b-20,3,10,D);R(cx+10,b-20,2,10,D);
            R(cx+27,b-12,3,4,hl);R(cx+27,b-7,3,3,hd);R(cx-26,b-10,3,5,tl);R(cx-26,b-6,3,3,td);
            R(cx+27,b-2,3,6,Mt);R(cx-26,b-2,3,6,Mt);
            E(cx-16,b-3,12,6,D);E(cx+18,b-3,12,6,D);
            // Door handle + side mirror
            R(cx-2,b-8,3,2,Mt);R(cx+20,b-16,4,3,D);
            // Bed rails (pickup truck bed ridges)
            R(cx-20,b-14,2,10,D);R(cx-12,b-18,22,1,Mt,0.4);
            // Exhaust pipe
            R(cx-26,b+2,3,2,'#444');R(cx-28,b+2,2,1,'#555');
            // Weathering: mud splatter, rust, scratches
            R(cx-8,b+1,10,2,'#4a3a2a',0.25);R(cx+6,b+2,7,2,'#3a2a1a',0.2);
            R(cx-20,b-6,4,2,'#6a3a1a',0.2);R(cx+14,b-4,3,2,'#5a3a1a',0.15);
            R(cx-4,b-10,6,1,L,0.25);R(cx+8,b-8,5,1,D,0.2);
            R(cx+4,b-20,8,6,'#5a5a4a',0.08);R(cx+5,b-22,1,4,'#aaa',0.18);
            // UP
            ox=FW*2;cx=ox+32;b=oy+48;
            E(cx,b+4,48,12,'#000',0.3);R(cx-18,b+1,8,6,bk);R(cx+18,b+1,8,6,bk);
            R(cx-20,b-14,4,18,D);R(cx+20,b-14,4,18,D);
            R(cx,b-8,38,10,D);R(cx,b-14,36,8,M);
            R(cx,b-8,28,6,D);R(cx,b-8,20,3,Mt,0.2);
            R(cx-16,b-10,5,6,tl);R(cx+16,b-10,5,6,tl);R(cx-16,b-6,5,3,td);R(cx+16,b-6,5,3,td);
            R(cx,b-5,10,4,'#333');R(cx,b-3,40,4,Mt);R(cx,b,6,3,'#333');
            R(cx-18,b-18,4,10,D);R(cx+18,b-18,4,10,D);R(cx,b-18,32,3,hub);
            R(cx,b-26,24,6,D);R(cx,b-30,22,4,M);R(cx,b-33,20,3,L);
            R(cx,b-24,18,4,W);R(cx,b-20,36,3,L,0.35);
            // LEFT
            ox=FW*3;cx=ox+32;b=oy+46;
            E(cx,b+6,56,12,'#000',0.3);
            E(cx+16,b+2,11,11,bk);E(cx+16,b+2,7,7,hub);E(cx-18,b+2,11,11,bk);E(cx-18,b+2,7,7,hub);
            R(cx,b-1,50,5,bk);
            R(cx+12,b-6,30,8,D);R(cx+12,b-10,28,4,M);R(cx+12,b-4,26,4,hub);R(cx+12,b-12,28,2,L);
            R(cx-16,b-8,18,12,D);R(cx-16,b-14,16,8,M);
            R(cx-22,b-10,10,8,M);R(cx-24,b-12,6,4,L);
            R(cx-10,b-22,16,8,D);R(cx-10,b-26,14,5,M);R(cx-10,b-29,14,3,L);
            R(cx-14,b-21,8,10,W);R(cx-4,b-20,6,8,W);
            R(cx-19,b-20,3,12,D);R(cx-1,b-20,3,10,D);R(cx-10,b-20,2,10,D);
            R(cx-27,b-12,3,4,hl);R(cx-27,b-7,3,3,hd);R(cx+26,b-10,3,5,tl);R(cx+26,b-6,3,3,td);
            R(cx-27,b-2,3,6,Mt);R(cx+26,b-2,3,6,Mt);
            E(cx+16,b-3,12,6,D);E(cx-18,b-3,12,6,D);
            // Door handle + side mirror (mirrored)
            R(cx+2,b-8,3,2,Mt);R(cx-20,b-16,4,3,D);
            // Bed rails
            R(cx+20,b-14,2,10,D);R(cx+12,b-18,22,1,Mt,0.4);
            // Exhaust pipe
            R(cx+26,b+2,3,2,'#444');R(cx+28,b+2,2,1,'#555');
            // Weathering
            R(cx+8,b+1,10,2,'#4a3a2a',0.25);R(cx-6,b+2,7,2,'#3a2a1a',0.2);
            R(cx+20,b-6,4,2,'#6a3a1a',0.2);R(cx-14,b-4,3,2,'#5a3a1a',0.15);
            R(cx+4,b-10,6,1,L,0.25);R(cx-8,b-8,5,1,D,0.2);
            R(cx-4,b-20,8,6,'#5a5a4a',0.08);R(cx-5,b-22,1,4,'#aaa',0.18);
        }

        function addWreckDamage(row) {
            // Overlay damage on an already-drawn row: rust, dents, missing parts, cracks
            for (let col = 0; col < 4; col++) {
                const ox = col * FW, oy = row * FH;
                const cx = ox + 32, b = oy + 42;
                // Rust patches
                R(cx + (Math.random()*20-10), b + (Math.random()*10-2), 6+Math.random()*6, 3+Math.random()*4, '#6a4a2a', 0.35);
                R(cx + (Math.random()*16-8), b + (Math.random()*8), 5+Math.random()*5, 2+Math.random()*3, '#7a5a3a', 0.3);
                // Broken window — dark smash
                R(cx + (Math.random()*10-5), b - 16 + (Math.random()*6-3), 5+Math.random()*4, 4+Math.random()*3, '#0a0a0a', 0.4);
                // Dent shadow
                R(cx + (Math.random()*14-7), b - 4 + (Math.random()*6), 4, 5, '#000000', 0.12);
                // Scratch
                R(cx + (Math.random()*18-9), b - 6 + (Math.random()*8), 8+Math.random()*6, 1, '#888', 0.2);
                // Missing wheel chance — black out one tire area
                if (Math.random() > 0.5) {
                    const wx = (col < 2) ? cx - 16 : cx + 16;
                    R(wx, b + 8, 12, 8, '#1a1210', 0.5);
                }
            }
        }

        // Draw normal vehicles (rows 0-4)
        const drawFns = [drawHumvee, drawSUV, drawCargo, drawPolice, drawPickup];
        const pals = [this.palettes.humvee, this.palettes.suv, this.palettes.cargo, this.palettes.police, this.palettes.pickup];
        for (let i = 0; i < 5; i++) {
            drawFns[i](i, pals[i]);
        }

        // Draw wrecked vehicles (rows 5-9) with random wreck palettes + damage overlay
        for (let i = 0; i < 5; i++) {
            const wp = this.wreckPalettes[Math.floor(Math.random() * this.wreckPalettes.length)];
            // For police wrecks, add white field
            const wreckPal = i === 3 ? {...wp, white: '#8a8a88'} : wp;
            drawFns[i](5 + i, wreckPal);
            addWreckDamage(5 + i);
        }

        this._canvas = canvas;
        this._ready = true;
        return canvas;
    },

    // Register all textures in a Phaser scene
    registerTextures(scene) {
        if (!this._ready) this.generate();
        const canvas = this._canvas;
        // One big spritesheet: fleet_all
        if (!scene.textures.exists('fleet_all')) {
            scene.textures.addSpriteSheet('fleet_all', canvas, { frameWidth: this.FW, frameHeight: this.FH });
        }
    },

    // Get frame index for a vehicle type + direction
    // type: 'humvee'|'suv'|'cargo'|'police'|'pickup'
    // dir: 'down'|'right'|'up'|'left'
    // wrecked: boolean
    getFrame(type, dir, wrecked) {
        const typeIdx = this.TYPES.indexOf(type);
        const dirIdx = this.DIRS.indexOf(dir);
        if (typeIdx < 0 || dirIdx < 0) return 0;
        const row = wrecked ? typeIdx + 5 : typeIdx;
        return row * 4 + dirIdx;
    },

    // Create a sprite for a vehicle
    createSprite(scene, x, y, type, dir, wrecked) {
        this.registerTextures(scene);
        const frame = this.getFrame(type || 'pickup', dir || 'right', wrecked || false);
        return scene.add.sprite(x, y, 'fleet_all', frame);
    },

    // Get a random wreck type (weighted: more civilian, fewer military)
    randomWreckType() {
        const weights = { humvee: 5, suv: 25, cargo: 10, police: 10, pickup: 25 };
        const entries = Object.entries(weights);
        const total = entries.reduce((s, [,w]) => s + w, 0);
        let roll = Math.random() * total;
        for (const [type, w] of entries) {
            roll -= w;
            if (roll <= 0) return type;
        }
        return 'pickup';
    }
};

