// Vestige GPS — DynamicShadows
// Extracted from monolith lines 30879-31024
// TODO: convert internal global refs to imports

import { CONFIG } from '../data/config.js';


export const DynamicShadows = {
    _shadows: new Map(), // sceneKey → [{core, halo, target, offsetY, scale, baseAlpha, interior}]
    
    // ¾ iso shadow ratio — shadow ellipse height is 25% of width
    ISO_RATIO: 0.25,
    
    // Get current lighting params
    _getLighting() {
        const tod = CONFIG.timeOfDay || 'midday';
        return CONFIG.lighting[tod] || CONFIG.lighting.midday;
    },
    
    // Register an object to receive a dynamic floor shadow
    add(scene, target, opts = {}) {
        const key = scene.scene.key;
        if (!this._shadows.has(key)) this._shadows.set(key, []);
        const list = this._shadows.get(key);
        
        // Don't double-register
        if (list.find(s => s.target === target)) return;
        
        const offsetY = opts.offsetY || 0;
        const scale = opts.scale || 1.0;
        const baseAlpha = opts.alpha || 0.14;
        const interior = opts.interior || false;
        
        // Compute base shadow width from target
        let sw;
        if (target.list && target.list.length > 0) {
            let minX = Infinity, maxX = -Infinity;
            target.list.forEach(c => {
                if (!c.visible || c.type === 'Text') return;
                const cw = (c.displayWidth || c.width || 0);
                if (cw < 2) return;
                const fa = c.fillAlpha !== undefined ? c.fillAlpha : 1;
                const fc = c.fillColor !== undefined ? c.fillColor : -1;
                if (fc === 0 && fa < 0.35) return;
                minX = Math.min(minX, c.x - cw / 2);
                maxX = Math.max(maxX, c.x + cw / 2);
            });
            sw = (maxX - minX) * (target.scaleX || 1) * 0.7 * scale;
        } else {
            sw = (target.displayWidth || target.width || 20) * 0.7 * scale;
        }
        sw = Math.max(6, sw);
        
        // Two-layer shadow: inner core (darker, smaller) + outer halo (softer, wider)
        const core = scene.add.ellipse(0, 0, sw, sw * this.ISO_RATIO, 0x000000, baseAlpha)
            .setDepth((target.depth || 0) - 0.5);
        const halo = scene.add.ellipse(0, 0, sw * 1.4, sw * this.ISO_RATIO * 1.5, 0x000000, baseAlpha * 0.35)
            .setDepth((target.depth || 0) - 0.6);
        
        list.push({ core, halo, target, offsetY, _baseSW: sw, baseAlpha, interior });
    },
    
    // Update all shadow positions, shapes, and opacity based on time of day
    update(scene) {
        const list = this._shadows.get(scene.scene.key);
        if (!list) return;
        
        const light = this._getLighting();
        const angle = light.shadowAngle;
        const len = light.shadowLength;
        const intensity = light.intensity;
        
        for (const entry of list) {
            const t = entry.target;
            if (!t || !t.active) {
                entry.core.setVisible(false);
                entry.halo.setVisible(false);
                continue;
            }
            
            const bsw = entry._baseSW;
            const vis = t.visible !== false;
            
            // Keep depth just below caster
            const tDepth = t.depth || 0;
            entry.core.setDepth(tDepth - 0.5);
            entry.halo.setDepth(tDepth - 0.6);
            
            if (entry.interior) {
                // Interior: fixed overhead light — subtle, centered
                const ix = t.x + 1.5;
                const iy = t.y + entry.offsetY + 3;
                entry.core.setPosition(ix, iy);
                entry.core.setSize(bsw, bsw * this.ISO_RATIO);
                entry.core.setAlpha(entry.baseAlpha * 0.8);
                entry.halo.setPosition(ix, iy);
                entry.halo.setSize(bsw * 1.3, bsw * this.ISO_RATIO * 1.3);
                entry.halo.setAlpha(entry.baseAlpha * 0.25);
            } else {
                // Outdoor: directional shadow based on sun position
                // offX: horizontal cast direction (dawn=-X, dusk=+X, midday/night=0)
                const offX = Math.cos(angle) * len * 8;
                // offY: base offset + slight forward push for low sun, compressed for iso
                const offY = entry.offsetY + Math.abs(Math.sin(angle)) * len * 2 + 3;
                
                // Stretch: longer shadows are wider and slightly taller
                const stretchW = bsw * (1 + len * 0.5);
                const stretchH = stretchW * this.ISO_RATIO;
                
                // Alpha: strong at midday (high contrast), soft at dawn/dusk, near-invisible at night
                const coreAlpha = Math.min(0.28, entry.baseAlpha * intensity * 1.2);
                const haloAlpha = coreAlpha * 0.3;
                
                const sx = t.x + offX;
                const sy = t.y + offY;
                
                // Core shadow — tight, darker
                entry.core.setPosition(sx, sy);
                entry.core.setSize(stretchW, stretchH);
                entry.core.setAlpha(coreAlpha);
                
                // Halo shadow — wider, softer, offset slightly further from caster
                entry.halo.setPosition(sx + offX * 0.15, sy + 1);
                entry.halo.setSize(stretchW * 1.4, stretchH * 1.5);
                entry.halo.setAlpha(haloAlpha);
            }
            
            entry.core.setVisible(vis);
            entry.halo.setVisible(vis);
        }
    },
    
    // Remove shadow for a specific target
    remove(scene, target) {
        const list = this._shadows.get(scene.scene.key);
        if (!list) return;
        const idx = list.findIndex(s => s.target === target);
        if (idx >= 0) {
            list[idx].core.destroy();
            list[idx].halo.destroy();
            list.splice(idx, 1);
        }
    },
    
    // Clean up scene
    destroy(scene) {
        const key = scene.scene.key;
        const list = this._shadows.get(key);
        if (!list) return;
        list.forEach(s => { if (s.core) s.core.destroy(); if (s.halo) s.halo.destroy(); });
        this._shadows.delete(key);
    }
};
