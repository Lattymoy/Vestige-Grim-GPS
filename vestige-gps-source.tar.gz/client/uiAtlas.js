// Vestige GPS — UIAtlas
// Extracted from monolith lines 32107-32895
// TODO: convert internal global refs to imports

import { PIXELLAB_READY } from '../data/pixellabReady.js';


export const UIAtlas = {
    built: false,
    FRAME: 5,         // frame thickness for nine-slice panels (PixelLab atlas)
    PANEL_SRC: 20,    // source texture size (must be > FRAME*2)
    BTN_W: 48,
    BTN_H: 22,
    SLOT_SIZE: 36,
    ICON_SIZE: 14,

    _seed: 42,
    _rand() { this._seed = (this._seed * 16807) % 2147483647; return (this._seed - 1) / 2147483646; },
    _resetSeed(s) { this._seed = s || 42; },

    // ── PIXELLAB ATLAS LOADER ──
    _loadAtlasTextures(scene) {
        if (typeof PIXELLAB_READY === 'undefined') return;
        // Prefer code-drawn versions for icons and slots (better visual match)
        const skip = {};
        Object.keys(PIXELLAB_READY).forEach(k => {
            if (k.startsWith('ui_icon_') || k === 'ui_slot_empty' || k.startsWith('ui_tab_')) skip[k] = true;
        });
        let loaded = 0;
        Object.entries(PIXELLAB_READY).forEach(([key, img]) => {
            if (skip[key]) return;
            if (scene.textures.exists(key)) return;
            try {
                if (img.complete && img.naturalWidth > 0) {
                    scene.textures.addImage(key, img);
                    loaded++;
                }
            } catch(e) { console.warn('Atlas load failed:', key, e); }
        });
        if (loaded > 0) console.log(`[UIAtlas] PixelLab: ${loaded} textures loaded`);
    },

    build(scene) {
        if (this.built && scene.textures.exists('ui_panel')) return;
        // Remove stale textures if frame size changed
        ['ui_panel', 'ui_panel_sm', 'ui_panel_danger', 'ui_panel_chat', 'ui_tab_active', 'ui_tab_inactive'].forEach(k => {
            if (scene.textures.exists(k)) scene.textures.remove(k);
        });
        this._loadAtlasTextures(scene);
        this._buildPanelTextures(scene);
        this._buildButtonTextures(scene);
        this._buildSlotTextures(scene);
        this._buildHealthBarTextures(scene);
        this._buildResourceIcons(scene);
        this._buildMiscTextures(scene);
        this._buildMultiplayerTextures(scene);
        this.built = true;
    },

    // ── HELPER: crisp 1px border (NO strokeRect) ──
    _border(ctx, x, y, w, h, color) {
        ctx.fillStyle = color;
        ctx.fillRect(x, y, w, 1);         // top
        ctx.fillRect(x, y + h - 1, w, 1); // bottom
        ctx.fillRect(x, y, 1, h);         // left
        ctx.fillRect(x + w - 1, y, 1, h); // right
    },

    // ── HELPER: draw metal grain on a region ──
    _metalGrain(ctx, x, y, w, h, baseR, baseG, baseB, density) {
        this._resetSeed(x * 31 + y * 17);
        for (let i = 0; i < w * h * (density || 0.15); i++) {
            const gx = x + this._rand() * w, gy = y + this._rand() * h;
            const len = 1 + this._rand() * 4;
            const bright = this._rand() > 0.5;
            ctx.globalAlpha = this._rand() * 0.12;
            ctx.fillStyle = bright ? `rgb(${baseR+12},${baseG+10},${baseB+8})` : `rgb(${baseR-8},${baseG-8},${baseB-6})`;
            ctx.fillRect(Math.floor(gx), Math.floor(gy), Math.ceil(len), 1);
        }
        ctx.globalAlpha = 1;
    },

    // ── HELPER: draw a rivet ──
    _rivet(ctx, x, y, size) {
        size = size || 3;
        ctx.fillStyle = '#222018'; ctx.fillRect(x, y, size + 1, size + 1);
        ctx.fillStyle = '#3a3628'; ctx.fillRect(x, y, size, size);
        ctx.fillStyle = '#4a4638'; ctx.fillRect(x, y, 1, 1);
        ctx.fillStyle = '#1a1814'; ctx.fillRect(x + size - 1, y + size - 1, 1, 1);
    },

    // ════════════════════════════════════════
    // PANEL NINE-SLICE TEXTURES
    // ════════════════════════════════════════
    _buildPanelTextures(scene) {
        const S = this.PANEL_SRC;
        const F = this.FRAME;

        this._buildOnePanel(scene, 'ui_panel', S, F, {
            metalR: 28, metalG: 26, metalB: 20,
            innerFill: '#0a0a14', accentDefault: '#4466aa',
            weldSeam: true, rivets: true, cornerBrackets: true
        });
        this._buildOnePanel(scene, 'ui_panel_sm', S, F, {
            metalR: 24, metalG: 22, metalB: 18,
            innerFill: '#0c0c16', accentDefault: '#334466',
            weldSeam: false, rivets: false, cornerBrackets: true
        });
        this._buildOnePanel(scene, 'ui_panel_danger', S, F, {
            metalR: 34, metalG: 22, metalB: 18,
            innerFill: '#0e0808', accentDefault: '#aa3333',
            weldSeam: true, rivets: true, cornerBrackets: true
        });
    },

    _buildOnePanel(scene, key, S, F, cfg) {
        if (scene.textures.exists(key)) return;
        const canvas = document.createElement('canvas');
        canvas.width = S; canvas.height = S;
        const ctx = canvas.getContext('2d');
        const { metalR: mR, metalG: mG, metalB: mB } = cfg;

        // Thin metal frame — single-pixel gradient per side
        for (let y = 0; y < F; y++) {
            const t = y / F;
            ctx.fillStyle = `rgb(${Math.floor(mR+t*6)},${Math.floor(mG+t*4)},${Math.floor(mB+t*3)})`;
            ctx.fillRect(0, y, S, 1);
        }
        for (let y = S - F; y < S; y++) {
            const t = (y - (S - F)) / F;
            ctx.fillStyle = `rgb(${Math.floor(mR+4-t*4)},${Math.floor(mG+2-t*2)},${mB})`;
            ctx.fillRect(0, y, S, 1);
        }
        for (let x = 0; x < F; x++) {
            const t = x / F;
            ctx.fillStyle = `rgb(${Math.floor(mR-2+t*6)},${Math.floor(mG-2+t*4)},${mB})`;
            ctx.fillRect(x, F, 1, S - F * 2);
        }
        for (let x = S - F; x < S; x++) {
            const t = (x - (S - F)) / F;
            ctx.fillStyle = `rgb(${Math.floor(mR+4-t*4)},${Math.floor(mG+2-t*2)},${mB})`;
            ctx.fillRect(x, F, 1, S - F * 2);
        }

        // Subtle grain (fewer passes, lower density for thin frame)
        this._metalGrain(ctx, 0, 0, S, F, mR, mG, mB, 0.08);
        this._metalGrain(ctx, 0, S - F, S, F, mR, mG, mB, 0.08);
        this._metalGrain(ctx, 0, F, F, S - F * 2, mR, mG, mB, 0.08);
        this._metalGrain(ctx, S - F, F, F, S - F * 2, mR, mG, mB, 0.08);

        // Inner edge — 1px dark line separating frame from content
        ctx.fillStyle = '#060608';
        ctx.fillRect(F, F, S - F * 2, 1);       // top inner
        ctx.fillRect(F, S - F - 1, S - F * 2, 1); // bottom inner
        ctx.fillRect(F, F, 1, S - F * 2);       // left inner
        ctx.fillRect(S - F - 1, F, 1, S - F * 2); // right inner

        // Clean interior
        ctx.fillStyle = cfg.innerFill;
        ctx.fillRect(F + 1, F + 1, S - F * 2 - 2, S - F * 2 - 2);

        // Accent line — single pixel colored border inside frame
        ctx.fillStyle = cfg.accentDefault;
        ctx.globalAlpha = 0.3;
        ctx.fillRect(F + 1, F, S - F * 2 - 2, 1);
        ctx.fillRect(F + 1, S - F - 1, S - F * 2 - 2, 1);
        ctx.fillRect(F, F + 1, 1, S - F * 2 - 2);
        ctx.fillRect(S - F - 1, F + 1, 1, S - F * 2 - 2);
        ctx.globalAlpha = 1;

        // Outer edge highlight — 1px bright line on outside
        ctx.fillStyle = `rgb(${mR+10},${mG+8},${mB+6})`;
        ctx.globalAlpha = 0.3;
        ctx.fillRect(0, 0, S, 1);  // top
        ctx.fillRect(0, 0, 1, S);  // left
        ctx.globalAlpha = 1;

        scene.textures.addImage(key, canvas);
    },

    // ════════════════════════════════════════
    // BUTTON TEXTURES
    // ════════════════════════════════════════
    _buildButtonTextures(scene) {
        const W = this.BTN_W, H = this.BTN_H;
        const states = {
            'ui_btn':          { metal: [26, 24, 18], inner: '#0c0c18', border: '#33302a' },
            'ui_btn_press':    { metal: [20, 18, 14], inner: '#08080e', border: '#2a2820' },
            'ui_btn_disabled': { metal: [20, 20, 20], inner: '#0a0a0e', border: '#222222' },
            'ui_btn_danger':   { metal: [32, 20, 16], inner: '#100808', border: '#3a2020' },
            'ui_btn_confirm':  { metal: [20, 28, 18], inner: '#081008', border: '#203a20' },
        };

        Object.entries(states).forEach(([key, cfg]) => {
            if (scene.textures.exists(key)) return;
            const canvas = document.createElement('canvas');
            canvas.width = W; canvas.height = H;
            const ctx = canvas.getContext('2d');

            for (let y = 0; y < H; y++) {
                const t = y / H;
                ctx.fillStyle = `rgb(${Math.floor(cfg.metal[0]+t*3)},${Math.floor(cfg.metal[1]+t*2)},${Math.floor(cfg.metal[2]+t*2)})`;
                ctx.fillRect(0, y, W, 1);
            }
            ctx.fillStyle = cfg.inner;
            ctx.fillRect(2, 2, W - 4, H - 4);
            this._border(ctx, 0, 0, W, H, cfg.border);
            ctx.fillStyle = '#3a3628';
            ctx.fillRect(2, 2, 2, 2);
            ctx.fillRect(W - 4, 2, 2, 2);
            this._metalGrain(ctx, 0, 0, W, 2, cfg.metal[0], cfg.metal[1], cfg.metal[2], 0.3);
            this._metalGrain(ctx, 0, H - 2, W, 2, cfg.metal[0], cfg.metal[1], cfg.metal[2], 0.3);
            scene.textures.addImage(key, canvas);
        });
    },

    // ════════════════════════════════════════
    // ITEM SLOT TEXTURES (empty + per-rarity)
    // ════════════════════════════════════════
    _buildSlotTextures(scene) {
        const S = this.SLOT_SIZE;
        this._buildOneSlot(scene, 'ui_slot_empty', S, '#222233', '#1a1a22', null);
        const rarities = {
            common:    { border: '#888888', glow: '#aaaaaa' },
            uncommon:  { border: '#44aa44', glow: '#66dd66' },
            rare:      { border: '#4488ff', glow: '#66aaff' },
            legendary: { border: '#ffaa22', glow: '#ffcc44' },
            unique:    { border: '#ff2244', glow: '#ff4466' },
            bane:      { border: '#8800ff', glow: '#aa44ff' },
        };
        Object.entries(rarities).forEach(([name, cfg]) => {
            this._buildOneSlot(scene, `ui_slot_${name}`, S, cfg.border, '#0e0e16', cfg.glow);
        });
    },

    _buildOneSlot(scene, key, S, borderColor, bgColor, glowColor) {
        if (scene.textures.exists(key)) return;
        // +2 padding so border is never at canvas edge
        const P = 1; // 1px padding on each side
        const T = S + P * 2; // total canvas size
        const canvas = document.createElement('canvas');
        canvas.width = T; canvas.height = T;
        const ctx = canvas.getContext('2d');

        // Background
        ctx.fillStyle = bgColor;
        ctx.fillRect(P, P, S, S);

        // Inner bevel
        ctx.fillStyle = '#060608';
        ctx.fillRect(P + 1, P + 1, S - 2, S - 2);
        ctx.fillStyle = bgColor;
        ctx.fillRect(P + 2, P + 2, S - 4, S - 4);

        // Border (crisp fillRect, no strokeRect)
        this._border(ctx, P, P, S, S, borderColor);

        // Glow bleed
        if (glowColor) {
            ctx.globalAlpha = 0.1;
            ctx.fillStyle = glowColor;
            ctx.fillRect(P + 2, P + 2, S - 4, S - 4);
            ctx.globalAlpha = 0.2;
            ctx.fillRect(P + 1, P + 1, S - 2, 1);
            ctx.fillRect(P + 1, P + 1, 1, S - 2);
            ctx.globalAlpha = 1;
        }

        // Corner ticks (inset 1px from border)
        const tc = glowColor || borderColor;
        ctx.fillStyle = tc;
        ctx.globalAlpha = 0.5;
        // TL
        ctx.fillRect(P, P, 5, 1); ctx.fillRect(P, P, 1, 5);
        // TR
        ctx.fillRect(P + S - 5, P, 5, 1); ctx.fillRect(P + S - 1, P, 1, 5);
        // BL
        ctx.fillRect(P, P + S - 1, 5, 1); ctx.fillRect(P, P + S - 5, 1, 5);
        // BR
        ctx.fillRect(P + S - 5, P + S - 1, 5, 1); ctx.fillRect(P + S - 1, P + S - 5, 1, 5);
        ctx.globalAlpha = 1;

        scene.textures.addImage(key, canvas);
    },

    // ════════════════════════════════════════
    // HEALTH BAR TEXTURES
    // ════════════════════════════════════════
    _buildHealthBarTextures(scene) {
        this._buildHPFrame(scene, 'ui_hp_player', 140, 18, {
            frameMetal: [26, 30, 22], innerBg: '#0a100a',
            accentColor: '#44aa44', rivets: true
        });
        this._buildHPFrame(scene, 'ui_hp_boss', 240, 22, {
            frameMetal: [32, 22, 22], innerBg: '#100808',
            accentColor: '#9944cc', rivets: true, heavy: true
        });
        this._buildHPFrame(scene, 'ui_hp_enemy', 40, 6, {
            frameMetal: [22, 20, 20], innerBg: '#0a0808',
            accentColor: '#cc4444', rivets: false
        });
        this._buildHPFrame(scene, 'ui_hp_friendly', 40, 6, {
            frameMetal: [20, 22, 26], innerBg: '#08080a',
            accentColor: '#4488cc', rivets: false
        });
        this._buildHPFrame(scene, 'ui_hp_nameplate', 56, 8, {
            frameMetal: [22, 24, 28], innerBg: '#08080e',
            accentColor: '#4466aa', rivets: false
        });
    },

    _buildHPFrame(scene, key, w, h, cfg) {
        if (scene.textures.exists(key)) return;
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        const [mR, mG, mB] = cfg.frameMetal;
        const border = cfg.heavy ? 3 : (h > 10 ? 2 : 1);

        // Metal frame
        for (let y = 0; y < h; y++) {
            const t = y / h;
            ctx.fillStyle = `rgb(${Math.floor(mR+t*4)},${Math.floor(mG+t*3)},${mB})`;
            ctx.fillRect(0, y, w, 1);
        }

        // Inner recess
        ctx.fillStyle = cfg.innerBg;
        ctx.fillRect(border, border, w - border * 2, h - border * 2);

        // Bevel
        ctx.fillStyle = `rgb(${mR-6},${mG-6},${mB-4})`;
        ctx.fillRect(border, border, w - border * 2, 1);
        ctx.fillRect(border, border, 1, h - border * 2);

        // Border (crisp)
        this._border(ctx, 0, 0, w, h, `rgb(${mR+10},${mG+8},${mB+6})`);

        // Accent pip (left edge)
        ctx.fillStyle = cfg.accentColor;
        ctx.fillRect(0, 0, border, h);
        ctx.globalAlpha = 0.3;
        ctx.fillRect(border, 0, 1, h);
        ctx.globalAlpha = 1;

        if (cfg.rivets) {
            this._rivet(ctx, 1, 1, 2);
            this._rivet(ctx, w - 4, 1, 2);
            this._rivet(ctx, 1, h - 4, 2);
            this._rivet(ctx, w - 4, h - 4, 2);
        }

        if (cfg.heavy) {
            this._metalGrain(ctx, 0, 0, w, border, mR, mG, mB, 0.25);
            this._metalGrain(ctx, 0, h - border, w, border, mR, mG, mB, 0.25);
            ctx.fillStyle = cfg.accentColor;
            ctx.globalAlpha = 0.12;
            for (let x = border + 4; x < w - border - 4; x += 8) {
                ctx.fillRect(x, 0, 2, border);
                ctx.fillRect(x + 2, h - border, 2, border);
            }
            ctx.globalAlpha = 1;
        }

        scene.textures.addImage(key, canvas);
    },

    // ════════════════════════════════════════
    // RESOURCE ICONS (14×14 pixel art, integer coords only)
    // ════════════════════════════════════════
    _buildResourceIcons(scene) {
        const S = this.ICON_SIZE;

        // ── RESOURCE ICONS ──

        // BITS (hexagonal crystal)
        this._buildIcon(scene, 'ui_icon_bits', S, (ctx) => {
            // Hex data token — ¾ perspective coin
            // Outer rim (dark gold)
            ctx.fillStyle = '#887722';
            ctx.fillRect(4, 1, 6, 1);    // top edge
            ctx.fillRect(3, 2, 8, 1);    // top wider
            ctx.fillRect(2, 3, 10, 1);   // full width starts
            ctx.fillRect(2, 4, 10, 1);
            ctx.fillRect(2, 5, 10, 1);
            ctx.fillRect(2, 6, 10, 1);
            ctx.fillRect(2, 7, 10, 1);
            ctx.fillRect(2, 8, 10, 1);
            ctx.fillRect(3, 9, 8, 1);    // bottom narrowing
            ctx.fillRect(4, 10, 6, 1);   // bottom edge
            // Inner face (bright gold)
            ctx.fillStyle = '#ccaa44';
            ctx.fillRect(4, 2, 6, 1);
            ctx.fillRect(3, 3, 8, 6);
            ctx.fillRect(4, 9, 6, 1);
            // Highlight (top-left)
            ctx.fillStyle = '#eedd66';
            ctx.fillRect(4, 3, 4, 1);
            ctx.fillRect(3, 4, 3, 1);
            // Hot spot
            ctx.fillStyle = '#ffee88';
            ctx.fillRect(4, 3, 2, 1);
            // Center emblem — "B" circuit pattern
            ctx.fillStyle = '#997722';
            ctx.fillRect(5, 4, 1, 5);   // B spine
            ctx.fillRect(6, 4, 2, 1);   // B top arm
            ctx.fillRect(8, 5, 1, 1);   // B top bump
            ctx.fillRect(6, 6, 2, 1);   // B mid arm
            ctx.fillRect(6, 8, 2, 1);   // B bottom arm
            ctx.fillRect(8, 7, 1, 1);   // B bottom bump
            // Edge shadow (bottom)
            ctx.fillStyle = '#665511';
            ctx.fillRect(4, 10, 6, 1);
            ctx.fillRect(3, 9, 1, 1);
            ctx.fillRect(10, 9, 1, 1);
            // ¾ depth strip (bottom edge thickness)
            ctx.fillStyle = '#775511';
            ctx.fillRect(4, 11, 6, 1);
            ctx.fillRect(5, 12, 4, 1);
        });

        // FUEL (canister)
        this._buildIcon(scene, 'ui_icon_fuel', S, (ctx) => {
            ctx.fillStyle = '#447744'; ctx.fillRect(3, 3, 8, 9);
            ctx.fillStyle = '#556655'; ctx.fillRect(5, 1, 4, 3);
            ctx.fillStyle = '#666'; ctx.fillRect(9, 2, 2, 1);
            ctx.fillStyle = '#66aa66'; ctx.fillRect(4, 6, 6, 2);
            ctx.fillStyle = '#5a8a5a'; ctx.fillRect(3, 3, 1, 9);
            ctx.fillStyle = '#338833'; ctx.globalAlpha = 0.5; ctx.fillRect(4, 8, 6, 3); ctx.globalAlpha = 1;
        });

        // AMMO (bullet)
        this._buildIcon(scene, 'ui_icon_ammo', S, (ctx) => {
            ctx.fillStyle = '#aa8844'; ctx.fillRect(5, 4, 4, 8);
            ctx.fillStyle = '#888'; ctx.fillRect(5, 2, 4, 3);
            ctx.fillStyle = '#999'; ctx.fillRect(6, 1, 2, 2);
            ctx.fillStyle = '#996633'; ctx.fillRect(6, 11, 2, 1);
            ctx.fillStyle = '#ccaa55'; ctx.fillRect(5, 4, 1, 7);
            ctx.fillStyle = '#887733'; ctx.fillRect(4, 10, 6, 1);
        });

        // MATERIALS (gear)
        this._buildIcon(scene, 'ui_icon_materials', S, (ctx) => {
            ctx.fillStyle = '#887766';
            ctx.fillRect(6, 0, 2, 3); ctx.fillRect(6, 11, 2, 3);
            ctx.fillRect(11, 6, 3, 2); ctx.fillRect(0, 6, 3, 2);
            ctx.fillRect(10, 2, 2, 2); ctx.fillRect(2, 2, 2, 2);
            ctx.fillRect(10, 10, 2, 2); ctx.fillRect(2, 10, 2, 2);
            ctx.fillStyle = '#776655'; ctx.fillRect(4, 3, 6, 8); ctx.fillRect(3, 4, 8, 6);
            ctx.fillStyle = '#665544'; ctx.fillRect(5, 5, 4, 4);
            ctx.fillStyle = '#0a0a0e'; ctx.fillRect(6, 6, 2, 2);
            ctx.fillStyle = '#998877'; ctx.fillRect(4, 4, 2, 1);
        });

        // HEALTH (cross)
        this._buildIcon(scene, 'ui_icon_health', S, (ctx) => {
            ctx.fillStyle = '#cc4444'; ctx.fillRect(5, 2, 4, 10); ctx.fillRect(2, 5, 10, 4);
            ctx.fillStyle = '#ff6666'; ctx.fillRect(6, 3, 2, 1); ctx.fillRect(3, 6, 1, 2);
        });

        // ── INTERACTION ICONS ──

        // SEARCH (magnifying glass)
        this._buildIcon(scene, 'ui_icon_search', S, (ctx) => {
            ctx.fillStyle = '#8899aa';
            ctx.fillRect(4, 1, 6, 1); ctx.fillRect(3, 2, 1, 1); ctx.fillRect(10, 2, 1, 1);
            ctx.fillRect(2, 3, 1, 4); ctx.fillRect(11, 3, 1, 4);
            ctx.fillRect(3, 7, 1, 1); ctx.fillRect(10, 7, 1, 1); ctx.fillRect(4, 8, 6, 1);
            ctx.fillStyle = '#667788';
            ctx.fillRect(9, 8, 2, 1); ctx.fillRect(10, 9, 2, 1); ctx.fillRect(11, 10, 2, 1); ctx.fillRect(12, 11, 1, 2);
            ctx.fillStyle = '#aabbcc'; ctx.fillRect(4, 3, 3, 2);
        });

        // LOCK (padlock)
        this._buildIcon(scene, 'ui_icon_lock', S, (ctx) => {
            ctx.fillStyle = '#888'; ctx.fillRect(5, 1, 1, 4); ctx.fillRect(8, 1, 1, 4);
            ctx.fillRect(5, 1, 4, 1); 
            ctx.fillStyle = '#aa8844'; ctx.fillRect(3, 5, 8, 8);
            ctx.fillStyle = '#cc9955'; ctx.fillRect(4, 6, 6, 6);
            ctx.fillStyle = '#0a0a0e'; ctx.fillRect(6, 8, 2, 3);
        });

        // UNLOCK (open padlock)
        this._buildIcon(scene, 'ui_icon_unlock', S, (ctx) => {
            ctx.fillStyle = '#888'; ctx.fillRect(8, 0, 1, 4); ctx.fillRect(11, 0, 1, 4);
            ctx.fillRect(8, 0, 4, 1);
            ctx.fillStyle = '#44aa44'; ctx.fillRect(3, 5, 8, 8);
            ctx.fillStyle = '#55cc55'; ctx.fillRect(4, 6, 6, 6);
            ctx.fillStyle = '#0a0a0e'; ctx.fillRect(6, 8, 2, 3);
        });

        // DOOR (doorway)
        this._buildIcon(scene, 'ui_icon_door', S, (ctx) => {
            ctx.fillStyle = '#665544'; ctx.fillRect(3, 1, 8, 12);
            ctx.fillStyle = '#554433'; ctx.fillRect(4, 2, 6, 10);
            ctx.fillStyle = '#443322'; ctx.fillRect(5, 3, 4, 8);
            ctx.fillStyle = '#aa8866'; ctx.fillRect(8, 6, 1, 2);
        });

        // VEHICLE (car silhouette)
        this._buildIcon(scene, 'ui_icon_vehicle', S, (ctx) => {
            ctx.fillStyle = '#667788'; ctx.fillRect(1, 6, 12, 4);
            ctx.fillStyle = '#556677'; ctx.fillRect(3, 3, 6, 4);
            ctx.fillStyle = '#888'; ctx.fillRect(8, 4, 3, 3);
            ctx.fillStyle = '#222'; ctx.fillRect(2, 10, 3, 2); ctx.fillRect(9, 10, 3, 2);
            ctx.fillStyle = '#ffcc44'; ctx.fillRect(12, 7, 1, 1);
        });

        // WEAPON (sword)
        this._buildIcon(scene, 'ui_icon_weapon', S, (ctx) => {
            ctx.fillStyle = '#999'; ctx.fillRect(6, 0, 2, 8);
            ctx.fillStyle = '#aaa'; ctx.fillRect(6, 0, 1, 7);
            ctx.fillStyle = '#776644'; ctx.fillRect(4, 8, 6, 1);
            ctx.fillStyle = '#665533'; ctx.fillRect(6, 9, 2, 4);
            ctx.fillStyle = '#bbb'; ctx.fillRect(6, 1, 2, 1);
        });

        // SHIELD
        this._buildIcon(scene, 'ui_icon_shield', S, (ctx) => {
            ctx.fillStyle = '#4466aa'; ctx.fillRect(2, 1, 10, 8);
            ctx.fillRect(3, 9, 8, 1); ctx.fillRect(4, 10, 6, 1);
            ctx.fillRect(5, 11, 4, 1); ctx.fillRect(6, 12, 2, 1);
            ctx.fillStyle = '#5577bb'; ctx.fillRect(3, 2, 8, 6);
            ctx.fillStyle = '#6688cc'; ctx.fillRect(6, 3, 2, 4);
            ctx.fillRect(4, 4, 6, 2);
        });

        // SKULL
        this._buildIcon(scene, 'ui_icon_skull', S, (ctx) => {
            ctx.fillStyle = '#ccbbaa'; ctx.fillRect(4, 1, 6, 2); ctx.fillRect(3, 3, 8, 5);
            ctx.fillRect(4, 8, 6, 2);
            ctx.fillStyle = '#0a0a0e'; ctx.fillRect(4, 4, 2, 2); ctx.fillRect(8, 4, 2, 2);
            ctx.fillRect(5, 7, 1, 1); ctx.fillRect(7, 7, 1, 1);
            ctx.fillStyle = '#aa9988'; ctx.fillRect(5, 10, 1, 2); ctx.fillRect(7, 10, 1, 2);
            ctx.fillRect(6, 9, 2, 1);
        });

        // WARNING (triangle)
        this._buildIcon(scene, 'ui_icon_warning', S, (ctx) => {
            ctx.fillStyle = '#ccaa22';
            for (let y = 0; y < 12; y++) {
                const hw = Math.floor(y * 7 / 12);
                ctx.fillRect(7 - hw, y + 1, hw * 2 + 1, 1);
            }
            ctx.fillStyle = '#0a0a0e'; ctx.fillRect(6, 5, 2, 4); ctx.fillRect(6, 10, 2, 1);
        });

        // STAR
        this._buildIcon(scene, 'ui_icon_star', S, (ctx) => {
            ctx.fillStyle = '#ccaa44';
            ctx.fillRect(6, 0, 2, 3); ctx.fillRect(5, 3, 4, 2);
            ctx.fillRect(0, 4, 14, 2); ctx.fillRect(2, 6, 10, 1);
            ctx.fillRect(3, 7, 3, 2); ctx.fillRect(8, 7, 3, 2);
            ctx.fillRect(3, 9, 2, 2); ctx.fillRect(9, 9, 2, 2);
            ctx.fillRect(2, 11, 2, 1); ctx.fillRect(10, 11, 2, 1);
        });

        // INTERACT (hand)
        this._buildIcon(scene, 'ui_icon_interact', S, (ctx) => {
            ctx.fillStyle = '#ccbb99';
            ctx.fillRect(5, 1, 2, 5); ctx.fillRect(7, 2, 2, 4);
            ctx.fillRect(3, 3, 2, 4); ctx.fillRect(9, 3, 2, 3);
            ctx.fillRect(3, 6, 8, 4); ctx.fillRect(4, 10, 6, 3);
            ctx.fillStyle = '#bbaa88'; ctx.fillRect(4, 7, 6, 2);
        });

        // CHIP (floppy disk / data)
        this._buildIcon(scene, 'ui_icon_chip', S, (ctx) => {
            ctx.fillStyle = '#4466aa'; ctx.fillRect(2, 1, 10, 12);
            ctx.fillStyle = '#335599'; ctx.fillRect(3, 2, 8, 10);
            ctx.fillStyle = '#888'; ctx.fillRect(4, 2, 6, 3);
            ctx.fillStyle = '#222'; ctx.fillRect(5, 7, 4, 4);
            ctx.fillStyle = '#333'; ctx.fillRect(5, 3, 1, 1);
        });

        // WRENCH
        this._buildIcon(scene, 'ui_icon_wrench', S, (ctx) => {
            ctx.fillStyle = '#888';
            ctx.fillRect(2, 1, 3, 1); ctx.fillRect(1, 2, 1, 2); ctx.fillRect(4, 2, 1, 2);
            ctx.fillRect(2, 4, 3, 1); ctx.fillRect(3, 4, 1, 1);
            ctx.fillRect(4, 5, 1, 1); ctx.fillRect(5, 6, 1, 1); ctx.fillRect(6, 7, 1, 1);
            ctx.fillRect(7, 8, 1, 1); ctx.fillRect(8, 9, 1, 1);
            ctx.fillRect(9, 10, 3, 1); ctx.fillRect(9, 11, 1, 1); ctx.fillRect(12, 11, 1, 1);
            ctx.fillRect(10, 12, 3, 1);
            ctx.fillStyle = '#aaa'; ctx.fillRect(2, 2, 2, 1);
        });

        // HEAL (pill capsule)
        this._buildIcon(scene, 'ui_icon_heal', S, (ctx) => {
            ctx.fillStyle = '#44aa44'; ctx.fillRect(4, 2, 6, 10);
            ctx.fillRect(3, 3, 1, 8); ctx.fillRect(10, 3, 1, 8);
            ctx.fillStyle = '#eee'; ctx.fillRect(4, 2, 6, 5); ctx.fillRect(3, 3, 1, 4);
            ctx.fillStyle = '#55cc55'; ctx.fillRect(6, 4, 2, 1); ctx.fillRect(5, 5, 4, 1);
        });

        // PACKAGE (box)
        this._buildIcon(scene, 'ui_icon_package', S, (ctx) => {
            ctx.fillStyle = '#886644'; ctx.fillRect(2, 3, 10, 9);
            ctx.fillStyle = '#775533'; ctx.fillRect(3, 4, 8, 7);
            ctx.fillStyle = '#aa8855'; ctx.fillRect(2, 3, 10, 2);
            ctx.fillStyle = '#996644'; ctx.fillRect(6, 3, 2, 9);
        });

        // ARROW RIGHT
        this._buildIcon(scene, 'ui_icon_arrow', S, (ctx) => {
            ctx.fillStyle = '#aabbcc';
            ctx.fillRect(2, 6, 8, 2);
            ctx.fillRect(8, 4, 2, 2); ctx.fillRect(8, 8, 2, 2);
            ctx.fillRect(10, 5, 1, 4); ctx.fillRect(11, 6, 1, 2);
        });

        // CUBE (outline)
        this._buildIcon(scene, 'ui_icon_cube', S, (ctx) => {
            ctx.fillStyle = '#8844aa';
            ctx.fillRect(3, 3, 8, 8);
            ctx.fillStyle = '#0a0a0e'; ctx.fillRect(4, 4, 6, 6);
            ctx.fillStyle = '#aa66cc'; ctx.fillRect(5, 5, 4, 4);
            ctx.fillStyle = '#cc88ff'; ctx.fillRect(6, 6, 2, 2);
        });

        // BACKPACK
        this._buildIcon(scene, 'ui_icon_backpack', S, (ctx) => {
            ctx.fillStyle = '#556644'; ctx.fillRect(3, 3, 8, 10);
            ctx.fillStyle = '#667755'; ctx.fillRect(4, 4, 6, 8);
            ctx.fillStyle = '#445533'; ctx.fillRect(5, 1, 4, 3);
            ctx.fillStyle = '#888'; ctx.fillRect(5, 6, 4, 3);
            ctx.fillStyle = '#999'; ctx.fillRect(6, 7, 2, 1);
        });

        // EXPLOSION (burst)
        this._buildIcon(scene, 'ui_icon_explosion', S, (ctx) => {
            ctx.fillStyle = '#cc6622';
            ctx.fillRect(5, 0, 4, 3); ctx.fillRect(5, 11, 4, 3);
            ctx.fillRect(0, 5, 3, 4); ctx.fillRect(11, 5, 3, 4);
            ctx.fillRect(2, 2, 3, 3); ctx.fillRect(9, 2, 3, 3);
            ctx.fillRect(2, 9, 3, 3); ctx.fillRect(9, 9, 3, 3);
            ctx.fillStyle = '#ff8844'; ctx.fillRect(4, 4, 6, 6);
            ctx.fillStyle = '#ffcc44'; ctx.fillRect(5, 5, 4, 4);
            ctx.fillStyle = '#ffee88'; ctx.fillRect(6, 6, 2, 2);
        });
    },

    _buildIcon(scene, key, S, drawFn) {
        if (scene.textures.exists(key)) return;
        const canvas = document.createElement('canvas');
        canvas.width = S; canvas.height = S;
        const ctx = canvas.getContext('2d');
        drawFn(ctx);
        scene.textures.addImage(key, canvas);
    },

    // ════════════════════════════════════════
    // MISC TEXTURES
    // ════════════════════════════════════════
    _buildMiscTextures(scene) {
        // Close button (16×16 — pixel X, no arc)
        this._buildIcon(scene, 'ui_close', 16, (ctx) => {
            // Dark circle (pixelated)
            ctx.fillStyle = '#1e1c16';
            // Fill a rough circle with rects
            ctx.fillRect(4, 1, 8, 1);
            ctx.fillRect(2, 2, 12, 1);
            ctx.fillRect(1, 3, 14, 10);
            ctx.fillRect(2, 13, 12, 1);
            ctx.fillRect(4, 14, 8, 1);
            // Border ring
            ctx.fillStyle = '#3a3628';
            ctx.fillRect(4, 0, 8, 1);
            ctx.fillRect(2, 1, 2, 1); ctx.fillRect(12, 1, 2, 1);
            ctx.fillRect(1, 2, 1, 1); ctx.fillRect(14, 2, 1, 1);
            ctx.fillRect(0, 3, 1, 10); ctx.fillRect(15, 3, 1, 10);
            ctx.fillRect(1, 13, 1, 1); ctx.fillRect(14, 13, 1, 1);
            ctx.fillRect(2, 14, 2, 1); ctx.fillRect(12, 14, 2, 1);
            ctx.fillRect(4, 15, 8, 1);
            // X mark
            ctx.fillStyle = '#aa8877';
            // Diagonal \
            ctx.fillRect(4, 4, 2, 2);
            ctx.fillRect(5, 5, 2, 2);
            ctx.fillRect(6, 6, 2, 2);
            ctx.fillRect(7, 7, 2, 2);
            ctx.fillRect(8, 8, 2, 2);
            ctx.fillRect(9, 9, 2, 2);
            ctx.fillRect(10, 10, 2, 2);
            // Diagonal /
            ctx.fillRect(10, 4, 2, 2);
            ctx.fillRect(9, 5, 2, 2);
            ctx.fillRect(8, 6, 2, 2);
            // center already covered
            ctx.fillRect(6, 8, 2, 2);
            ctx.fillRect(5, 9, 2, 2);
            ctx.fillRect(4, 10, 2, 2);
        });

        // Tab active
        this._buildTabTexture(scene, 'ui_tab_active', 48, 20, '#0e0e18', '#4466aa', true);
        this._buildTabTexture(scene, 'ui_tab_inactive', 48, 20, '#0a0a10', '#222244', false);

        // LEDs (6×6)
        ['#33dd33', '#ddaa33', '#cc3333', '#333333'].forEach((col, i) => {
            const lkey = ['ui_led_green', 'ui_led_amber', 'ui_led_red', 'ui_led_off'][i];
            this._buildIcon(scene, lkey, 6, (ctx) => {
                ctx.canvas.width = 6; ctx.canvas.height = 6;
                ctx.fillStyle = '#111';
                ctx.fillRect(0, 0, 6, 6);
                ctx.fillStyle = col;
                ctx.fillRect(1, 1, 4, 4);
                if (i < 3) {
                    ctx.fillStyle = '#fff';
                    ctx.globalAlpha = 0.3;
                    ctx.fillRect(1, 1, 1, 1);
                    ctx.globalAlpha = 1;
                }
            });
        });
    },

    _buildTabTexture(scene, key, w, h, bgColor, accentColor, active) {
        if (scene.textures.exists(key)) return;
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');

        ctx.fillStyle = bgColor;
        ctx.fillRect(0, 0, w, h);
        this._border(ctx, 0, 0, w, h, active ? '#3a3a5a' : '#1a1a2a');

        if (active) {
            ctx.fillStyle = accentColor;
            ctx.fillRect(0, 0, w, 2);
            ctx.globalAlpha = 0.06;
            ctx.fillRect(0, 2, w, h - 2);
            ctx.globalAlpha = 1;
        }

        ctx.fillStyle = active ? bgColor : '#16162a';
        ctx.fillRect(0, h - 1, w, 1);

        scene.textures.addImage(key, canvas);
    },

    // ════════════════════════════════════════
    // MULTIPLAYER-READY TEXTURES
    // ════════════════════════════════════════
    _buildMultiplayerTextures(scene) {
        this._buildHPFrame(scene, 'ui_hp_party', 100, 14, {
            frameMetal: [22, 24, 28], innerBg: '#08080e',
            accentColor: '#4466aa', rivets: false
        });
        this._buildOnePanel(scene, 'ui_panel_chat', this.PANEL_SRC, this.FRAME, {
            metalR: 18, metalG: 18, metalB: 22,
            innerFill: '#0c0c14', accentDefault: '#333355',
            weldSeam: false, rivets: false, cornerBrackets: false
        });
        // Ready check icons (12×12 pixel art, no arc)
        this._buildIcon(scene, 'ui_ready_yes', 12, (ctx) => {
            ctx.canvas.width = 12; ctx.canvas.height = 12;
            ctx.fillStyle = '#0a1a0a';
            // Pixel circle
            ctx.fillRect(3, 0, 6, 1);
            ctx.fillRect(1, 1, 10, 1);
            ctx.fillRect(0, 2, 12, 8);
            ctx.fillRect(1, 10, 10, 1);
            ctx.fillRect(3, 11, 6, 1);
            // Checkmark
            ctx.fillStyle = '#33aa55';
            ctx.fillRect(2, 5, 2, 2);
            ctx.fillRect(3, 6, 2, 2);
            ctx.fillRect(4, 7, 2, 2);
            ctx.fillRect(5, 6, 2, 2);
            ctx.fillRect(6, 5, 2, 2);
            ctx.fillRect(7, 4, 2, 2);
            ctx.fillRect(8, 3, 2, 2);
        });
        this._buildIcon(scene, 'ui_ready_no', 12, (ctx) => {
            ctx.canvas.width = 12; ctx.canvas.height = 12;
            ctx.fillStyle = '#1a0a0a';
            ctx.fillRect(3, 0, 6, 1);
            ctx.fillRect(1, 1, 10, 1);
            ctx.fillRect(0, 2, 12, 8);
            ctx.fillRect(1, 10, 10, 1);
            ctx.fillRect(3, 11, 6, 1);
            // X mark
            ctx.fillStyle = '#aa3333';
            ctx.fillRect(3, 3, 2, 2);
            ctx.fillRect(4, 4, 2, 2);
            ctx.fillRect(5, 5, 2, 2);
            ctx.fillRect(6, 6, 2, 2);
            ctx.fillRect(7, 7, 2, 2);
            ctx.fillRect(7, 3, 2, 2);
            ctx.fillRect(6, 4, 2, 2);
            ctx.fillRect(4, 6, 2, 2);
            ctx.fillRect(3, 7, 2, 2);
        });
    }
};
