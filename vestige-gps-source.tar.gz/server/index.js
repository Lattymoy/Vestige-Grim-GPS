// Vestige GPS — Server
// Fastify API + WebSocket for real-time
//
// Routes:
//   POST /auth/register, /auth/login
//   GET  /player — player state
//   POST /safehouse/establish — place safehouse at GPS coords
//   GET  /safehouse — get safehouse state
//   POST /safehouse/module — build a module
//   GET  /nodes/nearby?lat=&lng=&radius= — find/generate nodes near coords
//   POST /nodes/discover — create a new node at GPS coords
//   POST /mission/start — begin combat at a node
//   POST /mission/save — checkpoint combat state
//   POST /mission/complete — finish mission, award loot
//   GET  /route/plan?from_lat=&from_lng=&to_lat=&to_lng= — plan a route
//   POST /route/create — save a planned route

import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import fastifyStatic from '@fastify/static';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

import { BiomeClassifier } from '../core/biomeClassifier.js';
import { ItemManager } from '../core/itemManager.js';
import { SurvivorGenerator } from '../core/survivorGenerator.js';
import { TerrainGenerator } from '../core/terrainGenerator.js';

dotenv.config();

const __dirname = dirname(fileURLToPath(import.meta.url));
const { Pool } = pg;

const db = new Pool({
    connectionString: process.env.DATABASE_URL || 'postgresql://localhost:5432/vestige',
});

const app = Fastify({ logger: true });

await app.register(cors, { origin: true });
await app.register(jwt, { secret: process.env.JWT_SECRET || 'vestige-dev-secret-change-in-prod' });

// Serve the PWA client
await app.register(fastifyStatic, {
    root: join(__dirname, '..', 'client', 'public'),
    prefix: '/',
});

// ============================================
// AUTH MIDDLEWARE
// ============================================
app.decorate('authenticate', async (request, reply) => {
    try {
        await request.jwtVerify();
    } catch (err) {
        reply.code(401).send({ error: 'Unauthorized' });
    }
});

// ============================================
// AUTH ROUTES
// ============================================
app.post('/auth/register', async (request, reply) => {
    const { username, email, password } = request.body;
    if (!username || !email || !password) {
        return reply.code(400).send({ error: 'Missing fields' });
    }
    if (password.length < 8) {
        return reply.code(400).send({ error: 'Password must be at least 8 characters' });
    }

    const hash = await bcrypt.hash(password, 12);

    try {
        const result = await db.query(
            `INSERT INTO players (username, email, password)
             VALUES ($1, $2, $3)
             RETURNING id, username, email, created_at`,
            [username, email.toLowerCase(), hash]
        );
        const player = result.rows[0];

        // Create initial player state
        await db.query(
            `INSERT INTO player_state (player_id) VALUES ($1)`,
            [player.id]
        );

        // Create initial vehicle
        await db.query(
            `INSERT INTO vehicles (player_id) VALUES ($1)`,
            [player.id]
        );

        const token = app.jwt.sign({ id: player.id, username: player.username });
        return { token, player: { id: player.id, username: player.username } };
    } catch (err) {
        if (err.code === '23505') {
            return reply.code(409).send({ error: 'Username or email already taken' });
        }
        throw err;
    }
});

app.post('/auth/login', async (request, reply) => {
    const { email, password } = request.body;

    const result = await db.query(
        `SELECT id, username, email, password FROM players WHERE email = $1`,
        [email?.toLowerCase()]
    );
    const player = result.rows[0];

    if (!player || !(await bcrypt.compare(password, player.password))) {
        return reply.code(401).send({ error: 'Invalid credentials' });
    }

    // Update last active
    await db.query(`UPDATE players SET last_active = NOW() WHERE id = $1`, [player.id]);

    const token = app.jwt.sign({ id: player.id, username: player.username });
    return { token, player: { id: player.id, username: player.username } };
});

// ============================================
// PLAYER STATE
// ============================================
app.get('/player', { preHandler: [app.authenticate] }, async (request) => {
    const { rows } = await db.query(
        `SELECT p.username, p.foundry, p.created_at,
                ps.level, ps.xp, ps.bits, ps.health, ps.stats, ps.achievements, ps.quests
         FROM players p
         JOIN player_state ps ON ps.player_id = p.id
         WHERE p.id = $1`,
        [request.user.id]
    );
    return rows[0] || {};
});

// ============================================
// SAFEHOUSE
// ============================================
app.post('/safehouse/establish', { preHandler: [app.authenticate] }, async (request, reply) => {
    const { lat, lng, name } = request.body;
    if (!lat || !lng) return reply.code(400).send({ error: 'GPS coordinates required' });

    // Check if player already has a safehouse
    const existing = await db.query(
        `SELECT id FROM safehouses WHERE player_id = $1`,
        [request.user.id]
    );
    if (existing.rows.length > 0) {
        return reply.code(409).send({ error: 'Safehouse already established. Relocate instead.' });
    }

    // Classify biome at safehouse location
    const biome = await BiomeClassifier.classify(lat, lng);

    const result = await db.query(
        `INSERT INTO safehouses (player_id, name, location)
         VALUES ($1, $2, ST_SetSRID(ST_MakePoint($3, $4), 4326)::geography)
         RETURNING id, name`,
        [request.user.id, name || 'Safehouse', lng, lat]  // PostGIS is lng,lat order
    );

    return {
        safehouse: result.rows[0],
        biome: biome.biome,
        message: `Safehouse established in ${biome.biome} territory.`
    };
});

app.get('/safehouse', { preHandler: [app.authenticate] }, async (request) => {
    const { rows } = await db.query(
        `SELECT id, name, modules, layout, level,
                ST_Y(location::geometry) as lat, ST_X(location::geometry) as lng
         FROM safehouses WHERE player_id = $1`,
        [request.user.id]
    );
    return rows[0] || { error: 'No safehouse established' };
});

app.post('/safehouse/module', { preHandler: [app.authenticate] }, async (request, reply) => {
    const { module_id } = request.body;
    if (!module_id) return reply.code(400).send({ error: 'module_id required' });

    // Get current modules and check prereqs/cost (server-authoritative)
    const { rows } = await db.query(
        `SELECT modules FROM safehouses WHERE player_id = $1`,
        [request.user.id]
    );
    if (!rows[0]) return reply.code(404).send({ error: 'No safehouse' });

    const currentModules = rows[0].modules || [];

    // TODO: Validate module exists, check prereqs, deduct cost from inventory
    // For now, just add it
    currentModules.push({ id: module_id, built_at: new Date().toISOString() });

    await db.query(
        `UPDATE safehouses SET modules = $1 WHERE player_id = $2`,
        [JSON.stringify(currentModules), request.user.id]
    );

    return { modules: currentModules };
});

// ============================================
// NODE DISCOVERY (the GPS core)
// ============================================
app.get('/nodes/nearby', { preHandler: [app.authenticate] }, async (request, reply) => {
    const { lat, lng, radius } = request.query;
    if (!lat || !lng) return reply.code(400).send({ error: 'lat and lng required' });

    const radiusMeters = Math.min(Number(radius) || 1000, 10000); // cap at 10km

    // Find existing nodes within radius
    const { rows } = await db.query(
        `SELECT id, biome, node_type, difficulty, name, metadata,
                ST_Y(location::geometry) as lat, ST_X(location::geometry) as lng,
                ST_Distance(location, ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography) as distance_m
         FROM world_nodes
         WHERE ST_DWithin(
             location,
             ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography,
             $3
         )
         ORDER BY distance_m
         LIMIT 50`,
        [Number(lng), Number(lat), radiusMeters]
    );

    return { nodes: rows };
});

app.post('/nodes/discover', { preHandler: [app.authenticate] }, async (request, reply) => {
    const { lat, lng } = request.body;
    if (!lat || !lng) return reply.code(400).send({ error: 'GPS coordinates required' });

    // Check if a node already exists very close (within 50m)
    const existing = await db.query(
        `SELECT id, biome, node_type FROM world_nodes
         WHERE ST_DWithin(
             location,
             ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography,
             50
         ) LIMIT 1`,
        [Number(lng), Number(lat)]
    );

    if (existing.rows.length > 0) {
        return { node: existing.rows[0], existing: true };
    }

    // Classify this location
    const biome = await BiomeClassifier.classify(lat, lng);

    // Get distance from player's safehouse for difficulty
    const safehouse = await db.query(
        `SELECT ST_Distance(
            location,
            ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography
         ) / 1000 as distance_km
         FROM safehouses WHERE player_id = $3`,
        [Number(lng), Number(lat), request.user.id]
    );

    const distKm = safehouse.rows[0]?.distance_km || 1;
    const difficulty = BiomeClassifier.getDifficulty(distKm);

    // Create the node
    const result = await db.query(
        `INSERT INTO world_nodes (location, biome, node_type, difficulty, metadata, discovered_by)
         VALUES (ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography, $3, $4, $5, $6, $7)
         RETURNING id, biome, node_type, difficulty`,
        [Number(lng), Number(lat), biome.biome, 'defense', difficulty,
         JSON.stringify({ classification: biome }), request.user.id]
    );

    return { node: result.rows[0], discovered: true, biome: biome };
});

// ============================================
// MISSIONS (combat)
// ============================================
app.post('/mission/start', { preHandler: [app.authenticate] }, async (request, reply) => {
    const { node_id } = request.body;
    if (!node_id) return reply.code(400).send({ error: 'node_id required' });

    // Get node data
    const node = await db.query(`SELECT * FROM world_nodes WHERE id = $1`, [node_id]);
    if (!node.rows[0]) return reply.code(404).send({ error: 'Node not found' });

    const nodeData = node.rows[0];

    // Generate terrain for this biome (server-authoritative seed)
    const seed = `${node_id}-${Date.now()}`;

    // Create active mission
    const mission = await db.query(
        `INSERT INTO active_missions (player_id, node_id, state)
         VALUES ($1, $2, $3)
         RETURNING id`,
        [request.user.id, node_id, JSON.stringify({
            seed,
            biome: nodeData.biome,
            difficulty: nodeData.difficulty,
            wave: 1,
            convoyHP: 100,
        })]
    );

    return {
        mission_id: mission.rows[0].id,
        biome: nodeData.biome,
        difficulty: nodeData.difficulty,
        seed,
    };
});

app.post('/mission/complete', { preHandler: [app.authenticate] }, async (request, reply) => {
    const { mission_id, waves_cleared, extracted_at, time_seconds } = request.body;

    // Get mission
    const mission = await db.query(
        `SELECT * FROM active_missions WHERE id = $1 AND player_id = $2`,
        [mission_id, request.user.id]
    );
    if (!mission.rows[0]) return reply.code(404).send({ error: 'Mission not found' });

    const missionData = mission.rows[0];

    // Generate loot (server-authoritative via ItemManager)
    // TODO: Use ItemManager.generateLoot() with biome/difficulty params
    const loot = [];

    // Record completion
    await db.query(
        `INSERT INTO node_completions (player_id, node_id, waves_cleared, extracted_at, loot_earned, time_seconds)
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [request.user.id, missionData.node_id, waves_cleared, extracted_at,
         JSON.stringify(loot), time_seconds]
    );

    // Clean up active mission
    await db.query(`DELETE FROM active_missions WHERE id = $1`, [mission_id]);

    return { completed: true, loot, waves_cleared };
});

// ============================================
// INVENTORY
// ============================================
app.get('/inventory', { preHandler: [app.authenticate] }, async (request) => {
    const { rows } = await db.query(
        `SELECT id, location, slot, item_data, stack_count
         FROM inventory WHERE player_id = $1
         ORDER BY location, created_at`,
        [request.user.id]
    );
    return { items: rows };
});

// ============================================
// ROUTE PLANNING
// ============================================
app.get('/route/plan', { preHandler: [app.authenticate] }, async (request, reply) => {
    const { lat, lng, radius } = request.query;
    if (!lat || !lng) return reply.code(400).send({ error: 'lat and lng required' });

    const radiusMeters = Math.min(Number(radius) || 2000, 10000);

    // Get nodes in area, ordered by distance
    const { rows: nodes } = await db.query(
        `SELECT id, biome, node_type, difficulty, name,
                ST_Y(location::geometry) as lat, ST_X(location::geometry) as lng,
                ST_Distance(location, ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography) as distance_m
         FROM world_nodes
         WHERE ST_DWithin(
             location,
             ST_SetSRID(ST_MakePoint($1, $2), 4326)::geography,
             $3
         )
         ORDER BY distance_m
         LIMIT 20`,
        [Number(lng), Number(lat), radiusMeters]
    );

    // Check which nodes this player has already completed
    const completedIds = new Set();
    if (nodes.length > 0) {
        const { rows: completions } = await db.query(
            `SELECT DISTINCT node_id FROM node_completions WHERE player_id = $1`,
            [request.user.id]
        );
        completions.forEach(c => completedIds.add(c.node_id));
    }

    // Mark completion status
    const enrichedNodes = nodes.map(n => ({
        ...n,
        completed: completedIds.has(n.id),
    }));

    return { nodes: enrichedNodes };
});

// ============================================
// START
// ============================================
const port = process.env.PORT || 3000;
const host = process.env.HOST || '0.0.0.0';

try {
    await app.listen({ port, host });
    console.log(`\n  Vestige GPS server running on http://localhost:${port}`);
    console.log(`  Planet Raum awaits.\n`);
} catch (err) {
    app.log.error(err);
    process.exit(1);
}
