import { defineConfig } from 'vite';

export default defineConfig({
    base: './',
    root: '.',
    publicDir: 'public',
    server: {
        port: 3000,
        host: true
    },
    build: {
        outDir: 'dist',
        assetsInlineLimit: 0,
        chunkSizeWarningLimit: 1500,
        rollupOptions: {
            input: 'index.html',
            output: {
                manualChunks(id) {
                    if (id.includes('node_modules/phaser')) return 'phaser';
                    if (id.includes('/data/')) return 'data';
                    if (id.includes('/core/')) return 'core';
                    if (id.includes('/client/scenes/')) return 'scenes';
                    if (id.includes('/client/')) return 'client';
                }
            }
        }
    },
    optimizeDeps: {
        include: ['phaser']
    }
});
