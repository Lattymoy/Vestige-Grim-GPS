-- Vestige GPS — Database Schema
-- PostgreSQL + PostGIS
-- Run: psql -d vestige -f schema.sql

-- Enable PostGIS for spatial queries
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- PLAYERS
-- ============================================
CREATE TABLE players (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username    VARCHAR(32) UNIQUE NOT NULL,
    email       VARCHAR(255) UNIQUE NOT NULL,
    password    VARCHAR(255) NOT NULL,  -- bcrypt hash
    foundry     VARCHAR(32),             -- chosen foundry allegiance
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    last_active TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- PLAYER STATE
-- Replaces localStorage SaveManager data
-- ============================================
CREATE TABLE player_state (
    player_id   UUID PRIMARY KEY REFERENCES players(id) ON DELETE CASCADE,
    level       INT DEFAULT 1,
    xp          INT DEFAULT 0,
    bits        INT DEFAULT 0,            -- currency
    health      INT DEFAULT 100,
    perks       JSONB DEFAULT '[]',
    stats       JSONB DEFAULT '{}',       -- StatTracker data (kills, runs, etc)
    achievements JSONB DEFAULT '{}',
    quests      JSONB DEFAULT '{}',
    settings    JSONB DEFAULT '{}',
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- SAFEHOUSE
-- Player's home base with modular rooms
-- ============================================
CREATE TABLE safehouses (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id   UUID UNIQUE REFERENCES players(id) ON DELETE CASCADE,
    name        VARCHAR(64) DEFAULT 'Safehouse',
    location    GEOGRAPHY(POINT, 4326) NOT NULL,  -- GPS coordinates where established
    modules     JSONB DEFAULT '[]',                -- installed module list
    layout      JSONB DEFAULT '{}',                -- room positions and connections
    level       INT DEFAULT 1,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Spatial index for finding nearby safehouses (multiplayer future)
CREATE INDEX idx_safehouse_location ON safehouses USING GIST(location);

-- ============================================
-- SAFEHOUSE MODULES
-- What modules exist and their definitions
-- ============================================
CREATE TABLE safehouse_modules (
    id          VARCHAR(32) PRIMARY KEY,
    name        VARCHAR(64) NOT NULL,
    description TEXT,
    category    VARCHAR(32) NOT NULL,     -- 'crafting', 'storage', 'defense', 'intel', 'living'
    tier        INT DEFAULT 1,
    build_cost  JSONB NOT NULL,           -- { scrap: 50, components: 10 }
    effects     JSONB DEFAULT '{}',       -- what this module unlocks/provides
    prereqs     JSONB DEFAULT '[]'        -- module IDs required before building
);

-- ============================================
-- INVENTORY
-- Player's items (backpack + safehouse stash)
-- ============================================
CREATE TABLE inventory (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id   UUID REFERENCES players(id) ON DELETE CASCADE,
    location    VARCHAR(16) NOT NULL,     -- 'backpack', 'stash', 'equipped'
    slot        VARCHAR(32),              -- equipment slot if equipped (weapon, melee, gear, head, etc)
    item_data   JSONB NOT NULL,           -- full item object from ItemManager
    stack_count INT DEFAULT 1,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_inventory_player ON inventory(player_id, location);

-- ============================================
-- SQUAD
-- Survivor squad members with permadeath
-- ============================================
CREATE TABLE squad_members (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id   UUID REFERENCES players(id) ON DELETE CASCADE,
    survivor    JSONB NOT NULL,           -- SurvivorGenerator output
    status      VARCHAR(16) DEFAULT 'alive',  -- 'alive', 'downed', 'dead'
    assigned_to VARCHAR(32),              -- module assignment or 'field'
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    died_at     TIMESTAMPTZ
);

CREATE INDEX idx_squad_player ON squad_members(player_id, status);

-- ============================================
-- WORLD NODES
-- Real-world locations mapped to game nodes
-- Discovered by players, shared across the world
-- ============================================
CREATE TABLE world_nodes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    location    GEOGRAPHY(POINT, 4326) NOT NULL,
    biome       VARCHAR(32) NOT NULL,     -- mapped from terrain/land-use data
    node_type   VARCHAR(32) NOT NULL,     -- 'defense', 'boss', 'haven', 'poi'
    difficulty  INT DEFAULT 1,            -- 1-10 scale
    name        VARCHAR(128),             -- generated or from place data
    metadata    JSONB DEFAULT '{}',       -- terrain classification data, POI info
    discovered_by UUID REFERENCES players(id),
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- The critical spatial index — "find all nodes within X meters"
CREATE INDEX idx_nodes_location ON world_nodes USING GIST(location);
CREATE INDEX idx_nodes_biome ON world_nodes(biome);
CREATE INDEX idx_nodes_type ON world_nodes(node_type);

-- ============================================
-- PLAYER NODE HISTORY
-- Track which nodes a player has completed
-- ============================================
CREATE TABLE node_completions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id   UUID REFERENCES players(id) ON DELETE CASCADE,
    node_id     UUID REFERENCES world_nodes(id) ON DELETE CASCADE,
    completed_at TIMESTAMPTZ DEFAULT NOW(),
    waves_cleared INT,
    extracted_at  INT,                    -- wave number if early extract
    loot_earned  JSONB DEFAULT '[]',
    time_seconds INT
);

CREATE INDEX idx_completions_player ON node_completions(player_id);
CREATE INDEX idx_completions_node ON node_completions(node_id);

-- ============================================
-- VEHICLE STATE
-- Player's vehicle (mobile hub when away from safehouse)
-- ============================================
CREATE TABLE vehicles (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id   UUID UNIQUE REFERENCES players(id) ON DELETE CASCADE,
    fuel        INT DEFAULT 100,
    max_fuel    INT DEFAULT 100,
    mods        JSONB DEFAULT '{}',       -- installed vehicle modifications
    condition   INT DEFAULT 100           -- durability
);

-- ============================================
-- GPS BIOME MAPPING
-- Rules for classifying real terrain into Raum biomes
-- ============================================
CREATE TABLE biome_rules (
    id          SERIAL PRIMARY KEY,
    biome_id    VARCHAR(32) NOT NULL,
    land_use    VARCHAR(64),              -- 'urban', 'forest', 'water', 'desert', etc
    elevation_min INT,                    -- meters
    elevation_max INT,
    climate     VARCHAR(32),              -- 'arid', 'temperate', 'tropical', etc
    priority    INT DEFAULT 0             -- higher = preferred when multiple match
);

-- Seed with default biome classification rules
INSERT INTO biome_rules (biome_id, land_use, priority) VALUES
    ('ironfield',   'urban',        10),
    ('ironfield',   'industrial',   15),
    ('ironfield',   'commercial',   8),
    ('mirelands',   'forest',       10),
    ('mirelands',   'wetland',      15),
    ('mirelands',   'park',         5),
    ('scorchflats', 'desert',       15),
    ('scorchflats', 'barren',       10),
    ('scorchflats', 'scrub',        8),
    ('tidemarsh',   'water',        10),
    ('tidemarsh',   'coastal',      15),
    ('tidemarsh',   'beach',        12),
    ('hollows',     'cave',         15),
    ('hollows',     'mountain',     10),
    ('hollows',     'quarry',       12),
    ('ashveil',     'volcanic',     15),
    ('ashveil',     'wasteland',    10);

-- ============================================
-- ACTIVE MISSIONS
-- Currently running combat instances
-- ============================================
CREATE TABLE active_missions (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id   UUID REFERENCES players(id) ON DELETE CASCADE,
    node_id     UUID REFERENCES world_nodes(id),
    state       JSONB NOT NULL,           -- full combat state snapshot
    wave        INT DEFAULT 1,
    started_at  TIMESTAMPTZ DEFAULT NOW(),
    last_save   TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- ROUTES
-- Planned routes from safehouse or vehicle
-- ============================================
CREATE TABLE routes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    player_id   UUID REFERENCES players(id) ON DELETE CASCADE,
    origin      GEOGRAPHY(POINT, 4326) NOT NULL,
    waypoints   JSONB NOT NULL,           -- ordered array of node IDs
    status      VARCHAR(16) DEFAULT 'planned',  -- 'planned', 'active', 'completed', 'abandoned'
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
