// Vestige GPS — CONFIG
// Extracted from game_2_.html lines 2391-3164
// Central configuration — references all data modules

import { LORE_DATA } from './lore.js';
import { ENEMY_DEFS } from './enemies.js';
import { BIOME_DEFS } from './biomes.js';
import { LOCATION_DEFS } from './locations.js';
import { ITEM_DEFS } from './items.js';
import { WEAPON_SPRITE_DATA } from './weaponSprites.js';

export const CONFIG = {
    uiScale: 1.2,    // Global text scale — tune for device readability (1.0 = original, 1.2 = phone-friendly)
    uiMinPx: 9,      // Minimum font size floor in pixels
    width: 360,
    height: (() => {
        const vh = typeof window !== 'undefined' ? (window.visualViewport ? window.visualViewport.height : window.innerHeight) : 640;
        const vw = typeof window !== 'undefined' ? (window.visualViewport ? window.visualViewport.width : window.innerWidth) : 360;
        return Math.max(640, Math.min(960, Math.round(360 * (vh / vw))));
    })(),
    font: "-apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    
    // ========================================
    // WORLD LORE — Canonical source of truth
    // ========================================
    lore: LORE_DATA.lore,

    
    // ========================================
    // FOUNDRIES — Weapon manufacturer system
    // Visual DNA, stat tendencies, lore hooks
    // Foundries apply to T3+ procedural weapons
    // ========================================
    foundries: LORE_DATA.foundries,

    // ========================================
    // WEAPON FLAVOR TEXT — Rolled at generation
    // Every weapon/melee gets one. Personality on every drop.
    // ========================================
    weaponFlavor: LORE_DATA.weaponFlavor,

    // ========================================
    // LORE CHIPS — Collectible world-building
    // Found on corpses, in terminals, hidden in buildings
    // ========================================
    loreChips: LORE_DATA.loreChips,

    
    loreSeries: LORE_DATA.loreSeries,

    
    // ========================================
    // QUESTS — Objectives that drive progression
    // ========================================
    quests: {
        // MAIN QUESTLINE
        main_01: { id: 'main_01', type: 'main', title: 'First Steps', desc: 'Complete your first supply run and return alive.', target: 1, stat: 'runsCompleted', reward: { bits: 100 } },
        main_02: { id: 'main_02', type: 'main', title: 'Armed and Dangerous', desc: 'Equip a Forged-tier weapon or higher.', target: 1, stat: 'custom', check: 'equippedTier3', reward: { bits: 200 } },
        main_03: { id: 'main_03', type: 'main', title: 'Deep Reach', desc: 'Reach depth 3 on the traversal map.', target: 3, stat: 'highestReach', reward: { bits: 300 } },
        main_04: { id: 'main_04', type: 'main', title: 'The Cube Calls', desc: 'Collect your first Encrypted Cube.', target: 1, stat: 'cubesCollected', reward: { bits: 500 } },
        main_05: { id: 'main_05', type: 'main', title: 'Slay the Warden', desc: 'Defeat a boss enemy.', target: 1, stat: 'bossesKilled', reward: { bits: 1000 } },
        
        // COMBAT
        combat_01: { id: 'combat_01', type: 'combat', title: 'First Blood', desc: 'Kill 10 enemies.', target: 10, stat: 'enemiesKilled', reward: { bits: 50 } },
        combat_02: { id: 'combat_02', type: 'combat', title: 'Body Count', desc: 'Kill 100 enemies.', target: 100, stat: 'enemiesKilled', reward: { bits: 200, title: 'Killer' } },
        combat_03: { id: 'combat_03', type: 'combat', title: 'Blade Dancer', desc: 'Kill 50 enemies with melee weapons.', target: 50, stat: 'meleeKills', reward: { bits: 150, title: 'Blade Dancer' } },
        combat_04: { id: 'combat_04', type: 'combat', title: 'Marksman', desc: 'Kill 50 enemies with ranged weapons.', target: 50, stat: 'rangedKills', reward: { bits: 150, title: 'Marksman' } },
        
        // EXPLORATION
        explore_01: { id: 'explore_01', type: 'explore', title: 'Scavenger', desc: 'Loot 50 items from the world.', target: 50, stat: 'itemsLooted', reward: { bits: 100 } },
        explore_02: { id: 'explore_02', type: 'explore', title: 'Urban Explorer', desc: 'Explore 20 buildings.', target: 20, stat: 'buildingsExplored', reward: { bits: 150, title: 'Explorer' } },
        explore_03: { id: 'explore_03', type: 'explore', title: 'Completionist', desc: 'Open 100 containers.', target: 100, stat: 'containersOpened', reward: { bits: 200 } },
        
        // SURVIVAL
        survive_01: { id: 'survive_01', type: 'survive', title: 'Survivor', desc: 'Complete 10 supply runs.', target: 10, stat: 'runsCompleted', reward: { bits: 300, title: 'Veteran' } },
        survive_02: { id: 'survive_02', type: 'survive', title: 'Unkillable', desc: 'Complete 5 runs without dying.', target: 5, stat: 'custom', check: 'consecutiveRuns', reward: { bits: 500, title: 'Unkillable' } }
    },
    
    // ========================================
    // ACHIEVEMENTS — Milestone rewards
    // ========================================
    achievements: {
        ach_first_run:   { id: 'ach_first_run', title: 'Welcome to Raum', desc: 'Complete your first supply run.', icon: '🌅', stat: 'runsCompleted', target: 1, reward: { aura: 'dust' } },
        ach_100_kills:   { id: 'ach_100_kills', title: 'Century', desc: 'Kill 100 enemies.', icon: '💀', stat: 'enemiesKilled', target: 100, reward: { title: 'Centurion' } },
        ach_500_kills:   { id: 'ach_500_kills', title: 'Massacre', desc: 'Kill 500 enemies.', icon: '☠', stat: 'enemiesKilled', target: 500, reward: { aura: 'bloodmist' } },
        ach_first_boss:  { id: 'ach_first_boss', title: 'Giant Slayer', desc: 'Defeat your first boss.', icon: '👑', stat: 'bossesKilled', target: 1, reward: { title: 'Giant Slayer' } },
        ach_first_bane:  { id: 'ach_first_bane', title: 'Bane Collector', desc: 'Find a Bane weapon.', icon: '⚡', stat: 'baneWeaponsFound', target: 1, reward: { aura: 'voidglow' } },
        ach_first_flair: { id: 'ach_first_flair', title: 'Shiny Hunter', desc: 'Find a weapon with animated flair.', icon: '✦', stat: 'flairWeaponsFound', target: 1, reward: { title: 'Collector' } },
        ach_cube_5:      { id: 'ach_cube_5', title: 'Cube Seeker', desc: 'Collect 5 Encrypted Cubes.', icon: '🔲', stat: 'cubesCollected', target: 5, reward: { aura: 'cubelink' } },
        ach_reach_5:     { id: 'ach_reach_5', title: 'Deep Runner', desc: 'Reach depth 5 on the traversal map.', icon: '🗺', stat: 'highestReach', target: 5, reward: { title: 'Deep Runner' } },
        ach_10_runs:     { id: 'ach_10_runs', title: 'Hardened', desc: 'Complete 10 supply runs.', icon: '🔁', stat: 'runsCompleted', target: 10, reward: { title: 'Hardened' } },
        ach_50_runs:     { id: 'ach_50_runs', title: 'Raum Veteran', desc: 'Complete 50 supply runs.', icon: '🎖', stat: 'runsCompleted', target: 50, reward: { aura: 'warscarred', title: 'Raum Veteran' } },
        ach_lore_10:     { id: 'ach_lore_10', title: 'Archivist', desc: 'Collect 10 lore chips.', icon: '📖', stat: 'custom', check: 'loreCount', target: 10, reward: { title: 'Archivist' } },
        ach_death_0:     { id: 'ach_death_0', title: 'Untouched', desc: 'Complete a run taking zero damage.', icon: '🛡', stat: 'custom', check: 'zeroDamageRun', reward: { aura: 'pristine', title: 'Untouched' } },
        ach_explore_50:  { id: 'ach_explore_50', title: 'Cartographer', desc: 'Explore 50 buildings.', icon: '🏚', stat: 'buildingsExplored', target: 50, reward: { title: 'Cartographer' } }
    },
    
    // Player titles and auras
    playerTitles: ['Newcomer', 'Survivor', 'Killer', 'Blade Dancer', 'Marksman', 'Explorer', 'Veteran', 'Unkillable', 'Centurion', 'Giant Slayer', 'Collector', 'Deep Runner', 'Hardened', 'Raum Veteran', 'Archivist', 'Untouched', 'Cartographer'],
    
    playerAuras: {
        none:       { name: 'None', color: null, desc: 'No aura' },
        dust:       { name: 'Dust Walker', color: 0x8a7a6a, desc: 'Faint dust motes orbit you' },
        bloodmist:  { name: 'Blood Mist', color: 0xff3333, desc: 'A red haze clings to your form' },
        voidglow:   { name: 'Void Touch', color: 0x8844ff, desc: 'Dark energy wisps trail behind you' },
        cubelink:   { name: 'Cube Resonance', color: 0x33aaaa, desc: 'Teal geometric fragments orbit you' },
        warscarred: { name: 'War Scarred', color: 0xff8844, desc: 'Ember-like sparks drift from your steps' },
        pristine:   { name: 'Pristine', color: 0xffffff, desc: 'A clean white glow — untouched by Raum' }
    },
    
    // Survivor-specific auras — earned per-survivor, die with them
    survivorAuras: {
        none:           { name: 'None', color: null, desc: 'No aura', tier: 'none' },
        lordOfRaum:     { name: 'Sovereign', color: 0xddaa33, desc: '', tier: 'mastery' }
        // More survivor auras will be added here
    },
    
    // Survivor-specific titles — earned per-survivor, die with them
    survivorTitles: {
        'Newcomer':      { name: 'Newcomer', color: '#8899aa', desc: '', tier: 'default' },
        'Lord of Raum':  { name: 'Lord of Raum', color: '#ddaa33', desc: '', tier: 'mastery' }
    },
    
    
    // ========================================
    // TRAINING — Gym stat upgrades
    // ========================================
    // ========================================
    // WORKBENCH — Reforge costs & vehicle mods
    // ========================================
    reforge: {
        // Base material cost per weapon tier
        baseCost: [0, 5, 10, 18, 30, 50, 80],
        // Escalation multiplier per reroll on same weapon
        escalation: 1.5,
        // Max tracked rerolls (cost caps here)
        maxEscalation: 8
    },
    
    // Weapon enhancement — upgrade to +1 to unlock augment slot
    enhance: {
        cost: 40,           // flat material cost
        maxLevel: 1         // only +1 for now
    },
    
    vehicleMods: {
        weapon: {
            name: 'WEAPON MOUNT', icon: '🔫', color: '#ff6644', desc: 'Mounted armament',
            tiers: [
                { name: 'Makeshift Turret', cost: 30, desc: 'Slow-firing scrap gun. +5 vehicle damage.', stats: { vehicleDamage: 5, fireRate: 0.8 } },
                { name: 'Salvaged MG', cost: 60, desc: 'Reliable machine gun. +10 vehicle damage.', stats: { vehicleDamage: 10, fireRate: 1.2 } },
                { name: 'Mounted Cannon', cost: 120, desc: 'Heavy-hitting cannon. +20 vehicle damage.', stats: { vehicleDamage: 20, fireRate: 0.5 } },
                { name: 'Twin Autocannon', cost: 200, desc: 'Dual-barrel devastation. +30 vehicle damage, fast fire.', stats: { vehicleDamage: 30, fireRate: 1.8 } }
            ]
        },
        armor: {
            name: 'ARMOR PLATING', icon: '🛡', color: '#6688aa', desc: 'Vehicle durability',
            tiers: [
                { name: 'Scrap Plates', cost: 20, desc: 'Bolted junk panels. +25 vehicle HP.', stats: { vehicleHP: 25 } },
                { name: 'Welded Shell', cost: 45, desc: 'Solid steel plating. +50 vehicle HP.', stats: { vehicleHP: 50 } },
                { name: 'Reinforced Hull', cost: 90, desc: 'Layered composite armor. +100 vehicle HP.', stats: { vehicleHP: 100 } },
                { name: 'Fortress Frame', cost: 160, desc: 'Near-indestructible. +175 vehicle HP.', stats: { vehicleHP: 175 } }
            ]
        },
        fuel: {
            name: 'FUEL SYSTEM', icon: '⛽', color: '#66aa44', desc: 'Fuel capacity',
            tiers: [
                { name: 'Reserve Can', cost: 15, desc: 'Strapped-on jerry can. +15 max fuel.', stats: { fuelCapacity: 15 } },
                { name: 'Extended Tank', cost: 35, desc: 'Larger fuel tank. +30 max fuel.', stats: { fuelCapacity: 30 } },
                { name: 'Dual Tank System', cost: 70, desc: 'Twin-tank setup. +50 max fuel.', stats: { fuelCapacity: 50 } },
                { name: 'High-Cap Reservoir', cost: 130, desc: 'Massive fuel reserve. +80 max fuel.', stats: { fuelCapacity: 80 } }
            ]
        },
        utility: {
            name: 'UTILITY RACK', icon: '📦', color: '#aa8866', desc: 'Storage capacity',
            tiers: [
                { name: 'Side Pouches', cost: 20, desc: 'Strapped bags. +2 backpack slots.', stats: { extraSlots: 2 } },
                { name: 'Cargo Net', cost: 50, desc: 'Mounted cargo net. +4 backpack slots.', stats: { extraSlots: 4 } },
                { name: 'Roof Rack', cost: 100, desc: 'Full roof storage. +6 backpack slots.', stats: { extraSlots: 6 } },
                { name: 'Expedition Rig', cost: 180, desc: 'Maximum hauling capacity. +8 backpack slots.', stats: { extraSlots: 8 } }
            ]
        }
    },
    
    gym: {
        categories: {
            core: {
                name: 'CORE', icon: 'C', color: '#ff4444', animType: 'crunch',
                tagline: 'Endurance',
                buffs: {
                    maxHealth:    { name: 'Max HP',        low: 10, mid: 15, high: 25, unit: ' HP' },
                    damageResist: { name: 'Dmg Resist',    low: 2,  mid: 4,  high: 6,  unit: '%' },
                    elemResist:   { name: 'Elem Resist',   low: 5,  mid: 8,  high: 12, unit: '%' }
                }
            },
            arms: {
                name: 'ARMS', icon: 'A', color: '#ffaa44', animType: 'press',
                tagline: 'Firepower',
                buffs: {
                    accuracy: { name: 'Accuracy',  low: 5, mid: 8, high: 12, unit: '' },
                    damage:   { name: 'Damage',    low: 3, mid: 5, high: 8, unit: '%' },
                    crit:     { name: 'Crit',      low: 3, mid: 5, high: 8, unit: '' }
                }
            },
            legs: {
                name: 'LEGS', icon: 'L', color: '#44aaff', animType: 'squat',
                tagline: 'Mobility',
                buffs: {
                    dodge:    { name: 'Dodge',     low: 2, mid: 4, high: 6,  unit: '%' },
                    speed:    { name: 'Speed',     low: 3, mid: 5, high: 8,  unit: '%' },
                    lootLuck: { name: 'Luck',      low: 2, mid: 4, high: 6,  unit: '' }
                }
            }
        },
        durations: [5, 10, 15],  // minutes, random pick
        baseCost: 50,
        costScale: 1.5,  // escalates per session within 24h
        freeCooldown: 86400000  // 24 hours in ms
    },
    
    barracks: {
        levels: {
            1: { maxSurvivors: 2, label: 'Bunkroom' },
            2: { maxSurvivors: 3, label: 'Barracks', costBits: 200, costMaterials: 80, upgradeMs: 2 * 60 * 1000 },
            3: { maxSurvivors: 4, label: 'Squad Bay', costBits: 500, costMaterials: 200, upgradeMs: 10 * 60 * 1000 },
            4: { maxSurvivors: 5, label: 'Garrison', costBits: 1200, costMaterials: 500, upgradeMs: 30 * 60 * 1000 },
            5: { maxSurvivors: 6, label: 'Fortress', costBits: 3000, costMaterials: 1200, upgradeMs: 60 * 60 * 1000 }
        },
        maxLevel: 5
    },
    
    player: {
        health: 100,
        speed: 180,
        dodgeSpeed: 380,
        dodgeDuration: 220,
        dodgeCooldown: 600,
        meleeDamage: 18,
        meleeCooldown: 350,
        meleeRange: 70,
        autoMeleeRange: 38,
        gunDamage: 14,
        powerAmmo: 0,
        fireRate: 280,
        bulletSpeed: 650,
        firingRange: 160
    },
    enemy: {
        sightRange: 200,
        sightAngle: 120,
        hearingRange: 300,
        awarenessRate: 40,
        awarenessDecay: 15,
        searchTime: 3000,
        patrolPauseTime: 2000
    },
    enemyTypes: ENEMY_DEFS.enemyTypes,

    
    // Shield config — enemies may spawn with shields. Melee + Power Ammo break shields.
    // Canvas sizes for attack sprite variants (base types use canvasSize from enemyTypes)
    spriteCanvasSize: {
        deadlock_charge: 56, deadlock_slam: 56,
        host_slam: 72,
        reaper_slash: 64, reaper_spin: 64, reaper_dash: 64, reaper_crouch: 64, reaper_land: 64,
        flicker_attack: 28, flicker_maimed: 28,
    },
    shieldConfig: {
        // Chance by enemy type (0 = never, 1 = always)
        spawnChance: { husk: 0.05, husk_crawl: 0, flicker: 0, flicker_maimed: 0, host: 0.2, deadlock: 0.3, reaper: 0.25, spawn: 0.35 },
        baseHP: 30,       // Shield HP at reach 1
        reachScale: 8,    // +HP per reach level
        meleeMultiplier: 1.0,   // Full melee damage to shields
        powerAmmoMultiplier: 0.4, // Reduced power ammo damage to shields
        bulletMultiplier: 0.0,    // Normal bullets do 0 damage to shields
        bossShieldHP: { 1: 80, 2: 120, 3: 160 }, // Per phase
        bossShieldReachScale: 15
    },
    
    // DOT (Damage Over Time) effect definitions
    dotEffects: {
        bleed: {
            name: 'BLEED', color: '#cc3333', iconBg: 0xaa2222,
            damage: 1, tickRate: 600, duration: 4000,
            blurbColor: '#cc4444', blurbText: 'BLEED'
        },
        toxic: {
            name: 'TOXIC', color: '#44cc33', iconBg: 0x339922,
            damage: 2, tickRate: 500, duration: 5000,
            blurbColor: '#55cc33', blurbText: 'TOXIC'
        },
        burn: {
            name: 'BURN', color: '#ff8833', iconBg: 0xcc6622,
            damage: 2, tickRate: 500, duration: 4000,
            blurbColor: '#ff9944', blurbText: 'BURN'
        }
    },
    swipeThreshold: 40,
    swipeTime: 300,
    world: { width: 800, height: 800 },
    
    // Map size profiles — dimensions + content density scaling
    mapSizes: {
        small: {
            width: 600, height: 600,
            buildingScale: 0.6, propScale: 0.5, treeScale: 0.4,
            spawnScale: 0.8, lootScale: 0.8, groundDetailScale: 0.5,
            label: 'Small Arena'
        },
        medium: {
            width: 800, height: 800,
            buildingScale: 1.0, propScale: 1.0, treeScale: 1.0,
            spawnScale: 1.0, lootScale: 1.0, groundDetailScale: 1.0,
            label: 'Standard Zone'
        },
        large: {
            width: 1100, height: 1100,
            buildingScale: 1.6, propScale: 1.5, treeScale: 1.4,
            spawnScale: 1.3, lootScale: 1.4, groundDetailScale: 1.5,
            label: 'Exploration Zone'
        }
    },
    
    // Game mode → map size mapping
    modeSizeMap: {
        defense: 'medium',
        boss: 'medium'
    },
    
    // Active map size profile (set per scene)
    activeMapSize: null,
    
    // Current biome (set when player selects a node)
    currentBiome: {
        type: 'grassy',
        seed: null
    },
    
    // Biome definitions
    biomes: BIOME_DEFS.biomes,

    // ========================================
    // WORLD NOTES — diegetic lore objects found during exploration
    // ========================================
    worldNotes: BIOME_DEFS.worldNotes,

    // ========================================
    // ENVIRONMENTAL STORYTELLING SCENES
    // Multi-prop compositions that tell a story — one per zone max
    // ========================================
    storyScenes: BIOME_DEFS.storyScenes,

    // ========================================
    // LOCATION SYSTEM — specific node identities
    // ========================================
    locations: LOCATION_DEFS.locations,

    // Story event pools — pre-entry narrative encounters
    storyEvents: LOCATION_DEFS.storyEvents,

    leveling: {
        maxLevel: 30,
        // XP required per level (escalating curve)
        xpForLevel: (level) => Math.floor(100 * Math.pow(1.35, level - 1)),
        // XP rewards for actions
        xpRewards: {
            enemyKill: 15,
            eliteKill: 40,
            bossKill: 100,
            nodeCleared: 50,
            buildingExplored: 10,
            itemExtracted: 5,
            rareItemExtracted: 20,
            legendaryItemExtracted: 50,
            runCompleted: 75,
            runCompletedFlawless: 150, // no deaths
            achievementUnlocked: 100,
            cubFragmentFound: 80,
            questCompleted: 60
        },
        // Rewards per level
        levelRewards: {
            // Every level: +5 base HP, +1 inventory slot
            perLevel: { hp: 5, inventorySlots: 1 },
            // Milestone levels: special unlocks
            milestones: {
                5:  { title: 'Scavenger', reward: 'Unlock mod slot 2 for weapons', perk: 'mod_slot_2' },
                10: { title: 'Survivor', reward: 'Unlock vehicle mod slot 2', perk: 'vehicle_slot_2' },
                15: { title: 'Veteran', reward: 'Unlock reforge discount (20%)', perk: 'reforge_discount' },
                20: { title: 'Warden', reward: 'Unlock elite loot table', perk: 'elite_loot' },
                25: { title: 'Vanguard', reward: 'Unlock Soulbound crafting', perk: 'soulbound_craft' },
                30: { title: 'Remnant', reward: 'Unlock prestige mode', perk: 'prestige' }
            }
        }
    },

    // Building archetypes - define interior personality
    buildingArchetypes: LOCATION_DEFS.buildingArchetypes,

    // Building templates for procedural generation
    buildingTemplates: LOCATION_DEFS.buildingTemplates,

    
    // Biome damage chance (probability a building spawns damaged)
    biomeDamageChance: {
        grassy: 0.12,
        barren: 0.35,
        apocalyptic: 0.55
    },
    
    // Prop templates
    propTemplates: LOCATION_DEFS.propTemplates,

    
    // Time of day settings
    timeOfDay: 'midday', // dawn, midday, dusk, night
    lighting: {
        dawn: {
            ambient: 0xffeebb,
            intensity: 0.78,
            shadowAngle: Math.PI,       // sun east → shadow falls west (-X)
            shadowLength: 1.6,
            skyColor: 0x2a2535,
            grassColor: 0x2a3828,
            roadColor: 0x282525
        },
        midday: {
            ambient: 0xffffff,
            intensity: 1.0,
            shadowAngle: -Math.PI / 2,  // sun overhead → shadow centered
            shadowLength: 0.2,
            skyColor: 0x1a1a12,
            grassColor: 0x2a3a2a,
            roadColor: 0x2a2a2a
        },
        dusk: {
            ambient: 0xff9966,
            intensity: 0.55,
            shadowAngle: 0.0,           // sun west → shadow falls east (+X)
            shadowLength: 1.8,
            skyColor: 0x1a1520,
            grassColor: 0x282830,
            roadColor: 0x252228
        },
        night: {
            ambient: 0x8899bb,           // brighter moonlight (was 0x7799cc)
            intensity: 0.42,             // was 0.3 — moonlit night, not pitch black
            shadowAngle: -Math.PI / 2,  // diffuse moonlight → centered, faint
            shadowLength: 0.15,
            skyColor: 0x151525,
            grassColor: 0x1a2020,
            roadColor: 0x1a1a20
        }
    },
    
    // Inventory system
    inventory: {
        backpackSlots: 6,
        vehicleSlots: 6,
        safehouseStashSlots: 16,
        
        // Visual settings for backpack sprite
        backpackSize: 48,
        backpackOffset: { x: 0, y: -4 },
        
        // Future upgrade paths (placeholder)
        upgrades: {
            backpack: [6, 8, 10, 12],
            vehicle: [6, 9, 12, 15]
        }
    },
    
    // Item categories
    itemCategories: {
        weapon: { label: 'Weapon', color: 0xaa4444, icon: '🔫' },
        melee: { label: 'Melee', color: 0xcc6633, icon: '🗡' },
        gear: { label: 'Gear', color: 0x4488aa, icon: '🧥' },
        augment: { label: 'Augment', color: 0xaa44ff, icon: '⬡' },
        consumable: { label: 'Consumable', color: 0x44aa44, icon: '💊' },
        key: { label: 'Key/Quest', color: 0xddaa22, icon: '🔑' }
    },
    
    // Tier system
    tiers: {
        1: { name: 'Standard', label: 'Common', color: 0x888888, glow: 0xaaaaaa, modSlots: 0, damageMult: 1.0, utilityMult: 1.0, dropWeight: 50 },
        2: { name: 'Military', label: 'Uncommon', color: 0x44aa44, glow: 0x66dd66, modSlots: 1, damageMult: 1.15, utilityMult: 1.06, dropWeight: 25 },
        3: { name: 'Forged', label: 'Rare', color: 0x4488ff, glow: 0x66aaff, modSlots: 2, damageMult: 1.35, utilityMult: 1.12, dropWeight: 12 },
        4: { name: 'Master Forged', label: 'Legendary', color: 0xffaa22, glow: 0xffcc44, modSlots: 3, damageMult: 1.60, utilityMult: 1.20, dropWeight: 5 },
        5: { name: 'Blood Forged', label: 'Unique', color: 0xff2244, glow: 0xff4466, modSlots: 4, damageMult: 2.00, utilityMult: 1.30, dropWeight: 1 },
        6: { name: 'Bane', label: 'Bane', color: 0x8800ff, glow: 0xaa44ff, modSlots: 4, damageMult: 2.50, utilityMult: 1.40, dropWeight: 0 }
    },
    
    // Mod rarity affects stat values
    modTiers: {
        1: { name: 'Common', color: 0x888888, valueMult: 1.0, dropWeight: 40 },
        2: { name: 'Uncommon', color: 0x44aa44, valueMult: 1.3, dropWeight: 28 },
        3: { name: 'Rare', color: 0x4488ff, valueMult: 1.6, dropWeight: 16 },
        4: { name: 'Master', color: 0xffaa22, valueMult: 2.0, dropWeight: 8 },
        5: { name: 'Legendary', color: 0xff2244, valueMult: 2.5, dropWeight: 2 }
    },
    
    // Mod pools per item category — ALL VALUES ARE FLAT (no percentages)
    modPools: {
        weapon: [
            { id: 'dmg_boost', name: 'Damage', stat: 'damage', base: 5, unit: '', max: 12 },
            { id: 'fire_rate', name: 'Fire Rate', stat: 'fireRate', base: 5, unit: '', max: 12 },
            { id: 'reload_spd', name: 'Reload', stat: 'reload', base: 5, unit: '', max: 12 },
            { id: 'accuracy', name: 'Accuracy', stat: 'accuracy', base: 5, unit: '', max: 12 },
            { id: 'crit', name: 'Crit', stat: 'crit', base: 8, unit: '%', max: 20, displayDiv: 2 },
            { id: 'mag_size', name: 'Mag', stat: 'mag', base: 5, unit: '', max: 12 },
            { id: 'pierce', name: 'Pierce', stat: 'pierce', base: 1, unit: '', max: 2 },
            { id: 'target_range', name: 'Target Range', stat: 'targetRange', base: 1, unit: '', max: 2 },
            { id: 'soulbound', name: 'Soulbound', stat: 'soulbound', base: 1, unit: '', max: 3, special: true }
        ],
        melee: [
            { id: 'atk_spd', name: 'Attack Speed', stat: 'attackSpeed', base: 5, unit: '', max: 12 },
            { id: 'melee_dmg', name: 'Damage', stat: 'meleeDamage', base: 5, unit: '', max: 12 },
            { id: 'stagger', name: 'Stagger', stat: 'stagger', base: 5, unit: '%', max: 12 },
            { id: 'lifesteal', name: 'Lifesteal', stat: 'lifesteal', base: 3, unit: '%', max: 8 },
            { id: 'reach', name: 'Reach', stat: 'reach', base: 5, unit: '', max: 12 },
            { id: 'mass_atk', name: 'Mass Attack', stat: 'massAttack', base: 1, unit: '', max: 2 },
            { id: 'shield_atk', name: 'Shield Attack', stat: 'shieldAttack', base: 1, unit: '', max: 2 },
            { id: 'soulbound', name: 'Soulbound', stat: 'soulbound', base: 1, unit: '', max: 3, special: true }
        ],
        gear: [
            { id: 'carry_cap', name: 'Carry Capacity', stat: 'carryCapacity', base: 3, unit: ' slot', max: 8 },
            { id: 'max_hp', name: 'Health', stat: 'maxHealth', base: 15, unit: '', max: 38 },
            { id: 'dmg_resist', name: 'Resist', stat: 'damageResist', base: 3, unit: '%', max: 8 },
            { id: 'sightline', name: 'Sightline', stat: 'sightline', base: 4, unit: 's', max: 10, displayDiv: 10 },
            { id: 'heal_boost', name: 'Health Boost', stat: 'healBonus', base: 8, unit: '%', max: 20 },
            { id: 'luck', name: 'Luck', stat: 'lootLuck', base: 3, unit: '', max: 8 },
            { id: 'burn_resist', name: 'Burn Resist', stat: 'burnResist', base: 8, unit: '%', max: 20 },
            { id: 'poison_resist', name: 'Poison Resist', stat: 'poisonResist', base: 8, unit: '%', max: 20 },
            { id: 'bleed_resist', name: 'Bleed Resist', stat: 'bleedResist', base: 8, unit: '%', max: 20 },
            { id: 'soulbound', name: 'Soulbound', stat: 'soulbound', base: 1, unit: '', max: 3, special: true }
        ]
    },
    
    // Blood Forged signature mods (unique mechanics)
    // DOT (Damage Over Time) types
    dotTypes: {
        burn:   { name: 'Burn',   color: 0xff6622, icon: '🔥', tickInterval: 1000, source: 'gun' },
        poison: { name: 'Poison', color: 0x44cc44, icon: '☠',  tickInterval: 1000, source: 'lifesteal' },
        bleed:  { name: 'Bleed',  color: 0xcc2222, icon: '🩸', tickInterval: 1000, source: 'melee' }
    },
    
    // Blood Forged (T5) unique mods — percentage-based, chance roll on 5th mod slot
    bloodForgedSignatures: {
        weapon: [
            { id: 'bf_nomad', name: 'Nomad', desc: 'Up to +15% damage based on distance from target', effect: 'nomad', value: 15, type: 'passive' },
            { id: 'bf_ricochet', name: 'Ricochet', desc: 'Shots bounce to a second target at 50% damage', effect: 'ricochet', value: 50, type: 'passive' },
            { id: 'bf_berserker', name: 'Berserker', desc: 'Up to +20% damage as health drops', effect: 'berserker', value: 20, type: 'passive' },
            { id: 'bf_dabloon', name: 'Dabloon', desc: 'Double shot consuming 2 ammo at -10% damage', effect: 'dabloon', value: 10, type: 'passive' },
            { id: 'bf_diablo', name: 'Diablo', desc: '+15% boss damage', effect: 'diablo', value: 15, type: 'passive' }
        ],
        melee: [
            { id: 'bf_vampiric', name: 'Vampiric', desc: 'Kills heal 10HP, hits have a chance to heal 1HP', effect: 'vampiric', value: 10, type: 'passive' },
            { id: 'bf_whirlwind', name: 'Whirlwind', desc: '360° attack hits all nearby enemies. 5s cooldown', effect: 'whirlwind', value: 100, cooldown: 5000, type: 'passive' },
            { id: 'bf_finisher', name: 'Finisher', desc: 'Enemies below 10% HP are instantly executed', effect: 'finisher', value: 10, type: 'passive' },
            { id: 'bf_reaper', name: 'Reaper', desc: 'Hits have a chance to apply Bleed (15 dmg over 5s)', effect: 'reaper', value: 15, dot: 'bleed', dotDuration: 5000, type: 'passive' }
        ],
        gear: [
            { id: 'bf_laststand', name: 'Last Stand', desc: 'Survive lethal hit once per run at 1HP', effect: 'lastStand', value: 1, type: 'passive' },
            { id: 'bf_soulsurvivor', name: 'Soul Survivor', desc: 'All equipment gains 1 Soulbound charge (consumed first)', effect: 'soulSurvivor', value: 1, type: 'passive' },
            { id: 'bf_braveheart', name: 'Braveheart', desc: 'Currency pickups also restore health', effect: 'braveheart', value: 1, type: 'passive' }
        ]
    },
    
    // Base item templates (weapons, melee, gear, relics)
    baseItems: ITEM_DEFS.baseItems,

    
    // Blood Forged named items (unique T5 names)
    bloodForgedNames: {
        rifle: 'Longwatch', mini: 'Buzzkill', heavy_rifle: 'The Hemorrhage',
        handcannon: 'Godshand', sniper: 'Dead Reckoning',
        blade: 'Whisper', blunt: 'Skullsplitter', heavy: 'Earthbreaker',
        scrap_armor: 'Ghost Skin', gear_light: 'The Whisper', gear_medium: 'Ironhide',
        gear_heavy: 'The Bulwark'
    },

    // Fire mode stat modifiers — applied on top of base weapon stats during generation
    fireModeConfig: {
        semi:  { label: 'Semi-Auto', fireRateMult: 1.0, damageMult: 1.0, recoilMult: 1.0 },
        burst: { label: 'Burst',     fireRateMult: 0.7, damageMult: 1.15, recoilMult: 0.8, burstCount: 3, burstDelay: 60 },
        auto:  { label: 'Full-Auto', fireRateMult: 1.4, damageMult: 0.85, recoilMult: 1.3 },
        bolt:  { label: 'Bolt-Action', fireRateMult: 0.5, damageMult: 1.4, recoilMult: 0.6 }
    },
    
    // Recoil types — cosmetic label + minor accuracy modifier
    recoilConfig: {
        stable:     { label: 'Stable',     accuracyBonus: 5 },
        vertical:   { label: 'Vertical',   accuracyBonus: 0 },
        horizontal: { label: 'Horizontal', accuracyBonus: -3 },
        erratic:    { label: 'Erratic',    accuracyBonus: -5 },
        heavy:      { label: 'Heavy',      accuracyBonus: -2 },
        kick:       { label: 'High Kick',  accuracyBonus: -4 }
    },
    
    // ═══════════════════════════════════════════════════════════
    // FOUNDRY FRAME SYSTEM — per-foundry weapon archetypes
    // Each foundry defines its own frame pool with stat curves
    // and modular part configurations for visual assembly
    // ═══════════════════════════════════════════════════════════
    foundryFrames: WEAPON_SPRITE_DATA.foundryFrames,

    // Scrap frames for T1-T2 (no foundry)
    scrapFrames: WEAPON_SPRITE_DATA.scrapFrames,

    
    // ═══════════════════════════════════════════════════════════
    // FOUNDRY FIRING EFFECTS — per-foundry bullet/tracer/flash
    // ═══════════════════════════════════════════════════════════
    foundryFX: WEAPON_SPRITE_DATA.foundryFX,

    
    // ═══════════════════════════════════════════════════════════
    // FOUNDRY MELEE EFFECTS — per-foundry swing/impact/trail FX
    // ═══════════════════════════════════════════════════════════
    foundryMeleeFX: WEAPON_SPRITE_DATA.foundryMeleeFX,

    
    // ═══════════════════════════════════════════════════════════
    // FOUNDRY MELEE FRAMES — per-foundry melee archetypes
    // ═══════════════════════════════════════════════════════════
    foundryMeleeFrames: WEAPON_SPRITE_DATA.foundryMeleeFrames,

    scrapMeleeFrames: WEAPON_SPRITE_DATA.scrapMeleeFrames,

    
    // Procedural weapon name generation (tier-based style)
    weaponNames: WEAPON_SPRITE_DATA.weaponNames,

    
    // Procedural melee names
    meleeNames: WEAPON_SPRITE_DATA.meleeNames,

    
    // Procedural gear names
    gearNames: WEAPON_SPRITE_DATA.gearNames,

    // Bane weapons — boss-exclusive ultra-rare drops (tier 6)
    baneWeapons: WEAPON_SPRITE_DATA.baneWeapons,

    baneDropChance: 0.04,

    
    // Equipment slots
    equipmentSlots: {
        weapon: { label: 'Gun', icon: 'W' },
        melee: { label: 'Melee', icon: 'M' },
        gear: { label: 'Gear', icon: 'G' },
        consumable: { label: 'Quick', icon: 'Q' }
    },
    
    // Player customization
    customization: {
        skinTones: [
            { id: 'light', name: 'Light', base: '#f0c8a8', shade: '#d4a888' },
            { id: 'medium', name: 'Medium', base: '#d4a070', shade: '#b88858' },
            { id: 'tan', name: 'Tan', base: '#c08850', shade: '#a07040' },
            { id: 'brown', name: 'Brown', base: '#8a5a30', shade: '#704820' },
            { id: 'dark', name: 'Dark', base: '#5a3820', shade: '#482810' },
            { id: 'deep', name: 'Deep', base: '#3a2515', shade: '#2a1a0a' },
            { id: 'chrome', name: 'Chrome', base: '#8899aa', shade: '#667788' },
            { id: 'rust', name: 'Rust', base: '#7a5533', shade: '#5a3a22' },
            { id: 'carbon', name: 'Carbon', base: '#3a3a44', shade: '#2a2a33' },
            { id: 'infected', name: 'Infected', base: '#8aaa7a', shade: '#6a8866' }
        ],
        hairColors: [
            { id: 'black', name: 'Black', base: '#1a1a1a', highlight: '#2a2a2a' },
            { id: 'brown', name: 'Brown', base: '#4a3728', highlight: '#5a4738' },
            { id: 'auburn', name: 'Auburn', base: '#6a3020', highlight: '#7a4030' },
            { id: 'blond', name: 'Blond', base: '#b8a060', highlight: '#c8b070' },
            { id: 'red', name: 'Red', base: '#8a2a1a', highlight: '#9a3a2a' },
            { id: 'grey', name: 'Grey', base: '#6a6a6a', highlight: '#7a7a7a' },
            { id: 'white', name: 'White', base: '#c8c8c8', highlight: '#dadada' },
            { id: 'blue', name: 'Blue', base: '#2a3a6a', highlight: '#3a4a7a' }
        ],
        hairStyles: [
            { id: 'short', name: 'Short' },
            { id: 'buzzed', name: 'Buzzed' },
            { id: 'long', name: 'Long' },
            { id: 'mohawk', name: 'Mohawk' },
            { id: 'bald', name: 'Bald' }
        ],
        shirtColors: [
            { id: 'green', name: 'Forest', base: '#3a6a4a', light: '#4a7a5a', dark: '#2a5a3a' },
            { id: 'grey', name: 'Slate', base: '#4a4a52', light: '#5a5a62', dark: '#3a3a42' },
            { id: 'red', name: 'Crimson', base: '#6a2a2a', light: '#7a3a3a', dark: '#5a1a1a' },
            { id: 'blue', name: 'Navy', base: '#2a3a5a', light: '#3a4a6a', dark: '#1a2a4a' },
            { id: 'brown', name: 'Earth', base: '#5a4a30', light: '#6a5a40', dark: '#4a3a20' },
            { id: 'black', name: 'Charcoal', base: '#2a2a2a', light: '#3a3a3a', dark: '#1a1a1a' },
            { id: 'white', name: 'Off-White', base: '#a0a0a0', light: '#b0b0b0', dark: '#909090' },
            { id: 'olive', name: 'Olive', base: '#4a5a2a', light: '#5a6a3a', dark: '#3a4a1a' }
        ],
        pantsColors: [
            { id: 'dark', name: 'Dark', base: '#2a3a4a', light: '#3a4a5a' },
            { id: 'black', name: 'Black', base: '#1a1a22', light: '#2a2a32' },
            { id: 'khaki', name: 'Khaki', base: '#6a6040', light: '#7a7050' },
            { id: 'grey', name: 'Grey', base: '#3a3a40', light: '#4a4a50' },
            { id: 'camo', name: 'Camo', base: '#3a4a2a', light: '#4a5a3a' },
            { id: 'brown', name: 'Brown', base: '#4a3a28', light: '#5a4a38' }
        ],
        vehicleColors: [
            { id: 'blue', name: 'Steel Blue', body: '#4a6080', dark: '#3a4a60', light: '#5a7090' },
            { id: 'green', name: 'Military', body: '#4a6a4a', dark: '#3a5a3a', light: '#5a7a5a' },
            { id: 'red', name: 'Rust Red', body: '#6a3a30', dark: '#5a2a20', light: '#7a4a40' },
            { id: 'black', name: 'Matte Black', body: '#2a2a2e', dark: '#1a1a1e', light: '#3a3a3e' },
            { id: 'sand', name: 'Desert', body: '#7a6a4a', dark: '#6a5a3a', light: '#8a7a5a' },
            { id: 'white', name: 'Arctic', body: '#8a8a8e', dark: '#7a7a7e', light: '#9a9a9e' }
        ],
        backpackColors: [
            { id: 'green', name: 'Ranger', base: '#4a6a4a', dark: '#3a5a3a', light: '#5a7a5a', accent: '#6a8a6a' },
            { id: 'brown', name: 'Scout', base: '#5a4a30', dark: '#4a3a20', light: '#6a5a40', accent: '#7a6a50' },
            { id: 'grey', name: 'Tactical', base: '#4a4a50', dark: '#3a3a40', light: '#5a5a60', accent: '#6a6a70' },
            { id: 'black', name: 'Stealth', base: '#2a2a2e', dark: '#1a1a1e', light: '#3a3a3e', accent: '#4a4a4e' },
            { id: 'red', name: 'Medic', base: '#5a2a2a', dark: '#4a1a1a', light: '#6a3a3a', accent: '#7a4a4a' },
            { id: 'blue', name: 'Navy', base: '#2a3a5a', dark: '#1a2a4a', light: '#3a4a6a', accent: '#4a5a7a' }
        ]
    },
    
    // Item rarity colors (legacy compat — maps tier to rarity name)
    itemRarity: {
        common: { color: 0x888888, glow: 0xaaaaaa },
        uncommon: { color: 0x44aa44, glow: 0x66dd66 },
        rare: { color: 0x4488ff, glow: 0x66aaff },
        legendary: { color: 0xffaa22, glow: 0xffcc44 },
        unique: { color: 0xff2244, glow: 0xff4466 },
        bane: { color: 0x8800ff, glow: 0xaa44ff }
    },
    
    // Currency definitions
    currencies: {
        bits: { name: 'Bits', icon: '◈', color: '#aaccee', cap: null },
        fuel: { name: 'Fuel', icon: '⛽', color: '#dd8844', cap: 100 },
        parts: { name: 'Materials', icon: '🔩', color: '#aa8866', cap: null },
        ammo: { name: 'Power Ammo', icon: '▪', color: '#cc88ff', cap: null },
        materials: { name: 'Materials', icon: '🔩', color: '#aa8866', cap: null }
    },
    
    // Static items (non-procedural — consumables, scrap, keys)
    items: ITEM_DEFS.items,

    
    // Loot tables — reach-scaled via getLootTable()
    lootTables: ITEM_DEFS.lootTables,

    
    // Reach-based tier weight adjustments
    reachTierBonus: {
        // Per-reach bonus weight added to higher tiers, subtracted from common
        1: { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 },
        2: { 1: -5, 2: 3, 3: 2, 4: 0, 5: 0 },
        3: { 1: -12, 2: 5, 3: 5, 4: 2, 5: 0 },
        4: { 1: -18, 2: 6, 3: 8, 4: 3, 5: 0.3 },
        5: { 1: -25, 2: 6, 3: 10, 4: 6, 5: 0.5 },
        6: { 1: -28, 2: 5, 3: 10, 4: 8, 5: 0.7 },
        7: { 1: -30, 2: 4, 3: 10, 4: 10, 5: 0.8 },
        8: { 1: -32, 2: 3, 3: 10, 4: 12, 5: 1.0 }
    },
    
    // Currency scaling by reach
    reachCurrencyMult: {
        1: 1.0, 2: 1.2, 3: 1.5, 4: 1.8, 5: 2.2, 6: 2.5, 7: 2.8, 8: 3.0
    },
    
    // Item drop chance from enemy kills by reach
    reachDropChance: {
        1: 0.22, 2: 0.26, 3: 0.30, 4: 0.34, 5: 0.38, 6: 0.40, 7: 0.42, 8: 0.45
    },
    
    // Loot beam configs per tier
    lootBeamConfig: {
        1: { color: 0xaaaaaa, height: 0, particles: 0 },         // Common: no beam
        2: { color: 0x44aa44, height: 30, particles: 2 },        // Uncommon: short green
        3: { color: 0x4488ff, height: 55, particles: 4 },        // Rare: medium blue
        4: { color: 0xffaa22, height: 80, particles: 6 },        // Legendary: tall orange
        5: { color: 0xff2244, height: 110, particles: 8 },       // Blood Forged: dramatic red
        6: { color: 0x8800ff, height: 140, particles: 12 }       // Bane: void purple pillar
    }
};

// UI font scaling helper — returns scaled fontSize string (e.g. '12px')
// Enforces CONFIG.uiMinPx floor so nothing is unreadably small on phones
