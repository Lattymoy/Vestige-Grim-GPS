// Vestige GPS — TitleFont
// Extracted from monolith L5738-5889

export const TitleFont = {
    built: false,
    _glyphs: null,
    _widths: null,
    CHAR_H: 12,
    
    build() {
        if (this.built) return;
        
        // Helpers
        const vb = (x, y, h) => { const p = []; for (let i = 0; i < h; i++) p.push([x, y+i]); return p; };
        const hb = (x, y, w) => { const p = []; for (let i = 0; i < w; i++) p.push([x+i, y]); return p; };
        const sf = (x, y) => [[x-1,y],[x,y],[x+1,y]]; // serif foot
        
        const G = {};
        G['A'] = [...hb(3,1,3), [2,2],[6,2], [1,3],[7,3], ...hb(1,4,7), [1,5],[7,5], [1,6],[7,6], [1,7],[7,7], ...sf(1,8), ...sf(7,8)];
        G['B'] = [...hb(1,1,5), [1,2],[6,2], [1,3],[6,3], ...hb(1,4,5), [1,5],[6,5], [1,6],[7,6], [1,7],[6,7], ...hb(1,8,5), ...vb(1,2,6)];
        G['C'] = [...hb(3,1,4), [2,2],[7,2], [1,3], [1,4], [1,5], [1,6], [2,7],[7,7], ...hb(3,8,4)];
        G['D'] = [...hb(1,1,5), [1,2],[6,2], [1,3],[7,3], [1,4],[7,4], [1,5],[7,5], [1,6],[7,6], [1,7],[6,7], ...hb(1,8,5), ...vb(1,2,6)];
        G['E'] = [...hb(1,1,7), [1,2], [1,3], ...hb(1,4,5), [1,5], [1,6], [1,7], ...hb(1,8,7), ...vb(1,2,6)];
        G['F'] = [...hb(1,1,7), [1,2], [1,3], ...hb(1,4,5), [1,5], [1,6], [1,7], ...sf(1,8), ...vb(1,2,6)];
        G['G'] = [...hb(3,1,4), [2,2],[7,2], [1,3], [1,4],[5,4],[6,4],[7,4], [1,5],[7,5], [2,6],[7,6], ...hb(3,7,4), ...vb(1,3,3)];
        G['H'] = [[1,1],[7,1], ...vb(1,2,6), ...vb(7,2,6), ...hb(1,4,7), ...sf(1,8), ...sf(7,8)];
        G['I'] = [...hb(2,1,5), ...vb(4,2,6), ...hb(2,8,5)];
        G['J'] = [...hb(3,1,5), ...vb(6,2,5), [1,7],[6,7], ...hb(2,8,4)];
        G['K'] = [[1,1],[6,1], [1,2],[5,2], [1,3],[4,3], [1,4],[3,4], [1,5],[4,5], [1,6],[5,6], [1,7],[6,7], ...sf(1,8),...sf(7,8), ...vb(1,2,6)];
        G['L'] = [[1,1], ...vb(1,2,6), ...hb(1,8,7)];
        G['M'] = [[0,1],[8,1], [0,2],[1,2],[7,2],[8,2], [0,3],[2,3],[6,3],[8,3], [0,4],[3,4],[5,4],[8,4], [0,5],[4,5],[8,5], [0,6],[8,6], [0,7],[8,7], ...sf(0,8),...sf(8,8)];
        G['N'] = [[1,1],[7,1], [1,2],[2,2],[7,2], [1,3],[3,3],[7,3], [1,4],[4,4],[7,4], [1,5],[5,5],[7,5], [1,6],[6,6],[7,6], [1,7],[7,7], ...sf(1,8),...sf(7,8)];
        G['O'] = [...hb(3,1,3), [2,2],[6,2], [1,3],[7,3], [1,4],[7,4], [1,5],[7,5], [1,6],[7,6], [2,7],[6,7], ...hb(3,8,3)];
        G['P'] = [...hb(1,1,5), [1,2],[6,2], [1,3],[7,3], [1,4],[6,4], ...hb(1,5,5), [1,6], [1,7], ...sf(1,8), ...vb(1,2,6)];
        G['Q'] = [...hb(3,1,3), [2,2],[6,2], [1,3],[7,3], [1,4],[7,4], [1,5],[5,5],[7,5], [2,6],[6,6], ...hb(3,7,3), [7,8]];
        G['R'] = [...hb(1,1,5), [1,2],[6,2], [1,3],[7,3], [1,4],[6,4], ...hb(1,5,4), [1,6],[5,6], [1,7],[6,7], ...sf(1,8),...sf(7,8), ...vb(1,2,6)];
        G['S'] = [...hb(2,1,5), [1,2],[7,2], [1,3], [2,4], ...hb(3,5,3), [6,6], [1,7],[7,7], ...hb(2,8,5)];
        G['T'] = [...hb(0,1,9), ...vb(4,2,6), ...sf(4,8)];
        G['U'] = [[1,1],[7,1], ...vb(1,2,5), ...vb(7,2,5), [2,7],[6,7], ...hb(3,8,3)];
        G['V'] = [[1,1],[7,1], [1,2],[7,2], [2,3],[6,3], [2,4],[6,4], [3,5],[5,5], [3,6],[5,6], [4,7], [4,8]];
        G['W'] = [[0,1],[4,1],[8,1], [0,2],[4,2],[8,2], [0,3],[3,3],[5,3],[8,3], [1,4],[3,4],[5,4],[7,4], [1,5],[3,5],[5,5],[7,5], [2,6],[6,6], [2,7],[6,7], [3,8],[5,8]];
        G['X'] = [[1,1],[7,1], [2,2],[6,2], [3,3],[5,3], [4,4], [3,5],[5,5], [2,6],[6,6], [1,7],[7,7], ...sf(1,8),...sf(7,8)];
        G['Y'] = [[1,1],[7,1], [2,2],[6,2], [3,3],[5,3], [4,4], ...vb(4,5,3), ...sf(4,8)];
        G['Z'] = [...hb(1,1,7), [6,2], [5,3], [4,4], [3,5], [2,6], [1,7], ...hb(1,8,7)];
        G['0'] = [...hb(3,1,3), [2,2],[6,2], [1,3],[6,3],[7,3], [1,4],[5,4],[7,4], [1,5],[7,5], [1,6],[3,6],[7,6], [2,7],[6,7], ...hb(3,8,3)];
        G['1'] = [[3,1],[4,1], [2,2],[4,2], ...vb(4,3,5), ...hb(2,8,5)];
        G['2'] = [...hb(2,1,4), [1,2],[6,2], [6,3], [5,4], [4,5], [3,6], [2,7], ...hb(1,8,7)];
        G['3'] = [...hb(2,1,4), [1,2],[6,2], [6,3], ...hb(3,4,3), [6,5], [6,6], [1,7],[6,7], ...hb(2,8,4)];
        G['4'] = [[5,1], [4,2],[5,2], [3,3],[5,3], [2,4],[5,4], ...hb(1,5,7), [5,6],[5,7], ...sf(5,8)];
        G['5'] = [...hb(1,1,7), [1,2], ...hb(1,3,5), [6,4], [7,5], [7,6], [1,7],[6,7], ...hb(2,8,4)];
        G['6'] = [...hb(3,1,3), [2,2], [1,3], ...hb(1,4,5), [1,5],[6,5], [1,6],[7,6], [2,7],[6,7], ...hb(3,8,3)];
        G['7'] = [...hb(1,1,7), [7,2], [6,3], [5,4], [4,5], [4,6], [4,7], ...sf(4,8)];
        G['8'] = [...hb(3,1,3), [2,2],[6,2], [1,3],[7,3], [2,4],[6,4], ...hb(3,5,3), [2,6],[6,6], [1,7],[7,7], ...hb(2,8,5)];
        G['9'] = [...hb(3,1,3), [2,2],[6,2], [1,3],[7,3], [2,4],[6,4], ...hb(3,5,5), [7,6], [6,7], ...hb(3,8,3)];
        G[' '] = [];
        G['.'] = [[4,7],[4,8]];
        G[':'] = [[4,3],[4,4], [4,7],[4,8]];
        G['!'] = [...vb(4,1,5), [4,7],[4,8]];
        G['?'] = [...hb(2,1,4),[1,2],[6,2],[6,3],[5,4],[4,5],[4,7],[4,8]];
        G["'"] = [[4,1],[4,2]];
        G['-'] = [...hb(2,4,4)];
        
        // Measure max right edge per char
        this._widths = {};
        for (const [ch, pts] of Object.entries(G)) {
            if (pts.length === 0) { this._widths[ch] = 4; continue; }
            let maxX = 0;
            pts.forEach(([x]) => { if (x > maxX) maxX = x; });
            this._widths[ch] = maxX + 2; // +2 for spacing
        }
        this._widths[' '] = 4;
        
        this._glyphs = G;
        this.built = true;
    },
    
    measureText(text, scale) {
        if (!this.built) this.build();
        const gap = Math.max(1, Math.round(scale));
        let w = 0;
        for (const ch of text.toUpperCase()) {
            w += (this._widths[ch] || 6) * scale + gap;
        }
        return w > 0 ? w - gap : 0;
    },
    
    // Draw title — returns a Phaser Graphics object
    drawTitle(scene, x, y, title, opts = {}) {
        this.build();
        const {
            maxWidth = 120,
            maxScale = 1.2,
            minScale = 0.6,
            depth = 100,
            alpha = 1,
            center = false
        } = opts;
        
        const text = title.toUpperCase();
        const ch = this.CHAR_H;
        
        // Find best scale
        let scale = maxScale;
        while (scale > minScale && this.measureText(text, scale) > maxWidth) {
            scale -= 0.05;
        }
        scale = Math.max(minScale, scale);
        
        const g = scene.add.graphics().setDepth(depth).setAlpha(alpha).setScrollFactor(0);
        const gap = Math.max(1, Math.round(scale));
        let cx = 0;
        const totalW = this.measureText(text, scale);
        const ox = center ? x - totalW / 2 : x;
        
        for (const c of text) {
            const glyph = this._glyphs[c];
            if (!glyph || glyph.length === 0) { cx += (this._widths[c] || 4) * scale + gap; continue; }
            
            // Shadow
            glyph.forEach(([gx, gy]) => {
                g.fillStyle(0x050505, 0.6);
                g.fillRect(Math.round(ox + cx + gx * scale + scale * 0.5), Math.round(y + gy * scale + scale * 0.5), Math.ceil(scale), Math.ceil(scale));
            });
            
            // Main fill — gold gradient
            glyph.forEach(([gx, gy]) => {
                const t = gy / ch;
                const r = Math.round(230 - t * 60);
                const gr = Math.round(185 - t * 55);
                const b = Math.round(70 - t * 30);
                const col = (r << 16) | (gr << 8) | b;
                g.fillStyle(col, 1);
                g.fillRect(Math.round(ox + cx + gx * scale), Math.round(y + gy * scale), Math.ceil(scale), Math.ceil(scale));
            });
            
            // Highlight top edges
            glyph.forEach(([gx, gy]) => {
                const hasAbove = glyph.some(([ax, ay]) => ax === gx && ay === gy - 1);
                if (!hasAbove && gy > 0) {
                    g.fillStyle(0xf5dc78, 0.7);
                    g.fillRect(Math.round(ox + cx + gx * scale), Math.round(y + gy * scale), Math.ceil(scale), Math.max(1, Math.ceil(scale * 0.4)));
                }
            });
            
            cx += (this._widths[c] || 6) * scale + gap;
        }
        
        g._titleWidth = totalW;
        return g;
    },
    
    drawInline(scene, x, y, title, opts = {}) {
        return this.drawTitle(scene, x, y, title, { ...opts, center: false });
    }
};

