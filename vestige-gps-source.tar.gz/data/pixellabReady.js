// Vestige GPS — PIXELLAB_READY
// Extracted from monolith L32096-32101

import { PIXELLAB_UI } from './pixellabUi.js';

export const PIXELLAB_READY = {};
Object.entries(PIXELLAB_UI).forEach(([key, dataUrl]) => {
    const img = new Image();
    img.src = dataUrl;
    PIXELLAB_READY[key] = img;
});

