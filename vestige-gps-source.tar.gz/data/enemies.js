// Vestige GPS — ENEMY_DEFS
// Extracted from game_2_.html lines 485-570

export const ENEMY_DEFS = {
    enemyTypes: {
        // Basic enemies
        crawler: { deprecated: true, name: 'Crawler', health: 40, speed: 30, chaseSpeed: 45, damage: 18, size: 22, color: 0x6a4a3a, attackCooldown: 1200, 
            ai: 'melee', desc: 'Dismembered husk. Still dragging itself toward you.',
            canvasSize: 32 },
        walker: { deprecated: true, name: 'Walker', health: 50, speed: 60, chaseSpeed: 85, damage: 15, size: 24, color: 0xaa4444, attackCooldown: 1000, 
            ai: 'melee', desc: 'Standard infected. Relentless.',
            canvasSize: 32 },
        sprinter: { deprecated: true, name: 'Sprinter', health: 30, speed: 90, chaseSpeed: 160, damage: 10, size: 20, color: 0xcc5577, attackCooldown: 600, 
            ai: 'melee', desc: 'Fast and frantic. Weak.',
            canvasSize: 32 },
        
        // Advanced enemies
        host: { name: 'Host', health: 100, speed: 25, chaseSpeed: 40, damage: 10, size: 56, color: 0x7a5533,
            ai: 'host', attackCooldown: 4000, powerCooldown: 12000,
            attackRange: 160, fleeRange: 70, keepDist: 120, sightRange: 250,
            projectileSpeed: 140, quickBuildupTime: 1200, powerBuildupTime: 2500,
            quickCount: 4, powerCount: 4,
            detachRange: 80, detachCooldown: 5000, detachCount: 2,
            toxicDamage: 3, toxicDuration: 5000, toxicTickRate: 500,
            blastRadius: 35, blastToxicDuration: 6000,
            desc: 'God, my entire team.. wiped out by this thing. It shot these projectiles. Couldn\'t walk on the ground in front of them.',
            canvasSize: 72, noContactDamage: true, attackFlags: ['_hostBuilding'] },
        skitterling: { name: 'Skitterling', health: 8, speed: 55, chaseSpeed: 80, damage: 5, size: 12, color: 0x5a4422,
            ai: 'skitter', attackCooldown: 800, jumpRange: 35, jumpSpeed: 250, jumpDuration: 250,
            desc: 'Spawned from the Host\'s putrid payload. Tiny, fast, suicidal.',
            canvasSize: 16, noContactDamage: true },
        deadlock: { name: 'Deadlock', health: 180, speed: 32, chaseSpeed: 55, damage: 30, size: 38, color: 0x886644, attackCooldown: 2500,
            ai: 'deadlock', chargeSpeed: 280, chargeWindup: 900, chargeDuration: 380, slamCooldown: 14000, slamRadius: 150, slamBuildup: 1600,
            initialSlamDelay: 3000, shieldChance: 0.15, desc: 'Mechanical flesh. Burning CRT. Locks you in and runs you down.',
            canvasSize: 56, noContactDamage: true, attackFlags: ['_deadlockCharging', '_deadlockSlamming', '_deadlockWindup', '_deadlockSlamWindup'], animLockFlags: ['_deadlockCharging', '_deadlockWindup', '_deadlockSlamming', '_deadlockSlamWindup'] },
        stalker: { deprecated: true, name: 'Stalker', health: 35, speed: 70, chaseSpeed: 120, damage: 20, size: 20, color: 0x445566, attackCooldown: 800,
            ai: 'flank', flankDist: 80, desc: 'Circles around. Attacks from behind.',
            canvasSize: 28, attackFlags: ['_charging', '_lungeWindup'] },
        reaper: { name: 'Reaper', health: 200, speed: 35, chaseSpeed: 65, damage: 18, size: 48, color: 0x6a5544,
            ai: 'reaper', attackCooldown: 3000,
            keepDist: 80, fleeRange: 35, axeRange: 65, sightRange: 280,
            lightArcDamage: 16, lightArcCooldown: 3000, lightArcBuildup: 600, lightArcRange: 65, lightArcAngle: 1.1,
            dashDamage: 28, dashCooldown: 9000, dashBuildup: 1200, dashSpeed: 280, dashDuration: 300,
            whirlwindDamage: 4, whirlwindCooldown: 11000, whirlwindBuildup: 700, whirlwindDuration: 1200, whirlwindRadius: 55, whirlwindTicks: 3,
            dropDamage: 22, dropCooldown: 16000, dropBuildup: 1800, dropBlastRadius: 45, dropBurnDuration: 4000,
            desc: 'A towering giant forged from the remnants of a long gone civilization. What knight uses scraps?',
            canvasSize: 64, noContactDamage: true, attackFlags: ['_reaperBuilding', '_reaperDashing'], animLockFlags: ['_reaperBuilding'] },
        spawn: { name: 'Spawn', health: 200, speed: 35, chaseSpeed: 45, damage: 0, size: 36, color: 0x6a4488,
            ai: 'overseer', attackCooldown: 0, lootTable: 'husk_drop',
            keepDist: 140, fleeRange: 90, sightRange: 300,
            spawnRate: 10000, spawnBurst: 2, spawnTypes: ['husk', 'husk', 'husk', 'flicker'],
            spawnBuildupTime: 2000,
            auraRadius: 100, auraSpeedBuff: 1.3, auraDamageBuff: 1.25,
            desc: 'A resemblance to the anomaly known as the Cube. Its presence seems non-hostile — until it decides to start bringing in the fleet.',
            canvasSize: 48, noContactDamage: true },
        
        // Boss
        boss: { name: 'The Tesseract', health: 400, speed: 40, chaseSpeed: 70, damage: 35, size: 48, color: 0x8844aa, attackCooldown: 2000, isBoss: true,
            ai: 'boss', desc: 'The Cube calls to it.',
            canvasSize: 64 },
        
        // === NEW ATTACK-COMMITTED ENEMIES ===
        husk: { name: 'Husk', health: 50, speed: 55, chaseSpeed: 80, damage: 12, size: 24, color: 0x8a5a4a,
            ai: 'melee', attackCooldown: 1000, lootTable: 'husk_drop',
            desc: 'Cube-turned Raumian. Whatever they were is gone — hollowed out in the wake of the Anomaly. Moves wrong. Nobody knows why.',
            canvasSize: 32 },
        husk_crawl: { name: 'Husk Crawler', health: 35, speed: 22, chaseSpeed: 35, damage: 15, size: 24, color: 0x6a3a2a,
            ai: 'melee', attackCooldown: 1400, lootTable: 'husk_drop',
            desc: 'What remains of a Husk after the legs are gone. Still dragging itself forward. Still reaching.',
            canvasSize: 32 },
        husk_stumble: { name: 'Husk', health: 50, speed: 55, chaseSpeed: 80, damage: 12, size: 24, color: 0x8a5a4a,
            ai: 'melee', attackCooldown: 1000, lootTable: 'husk_drop', desc: 'Off balance.',
            canvasSize: 32 },
        flicker: { name: 'Flicker', health: 25, speed: 90, chaseSpeed: 120, damage: 8, size: 20, color: 0x6a3a8a,
            ai: 'erratic', attackCooldown: 800, attackRange: 28, lootTable: 'flicker_drop',
            desc: 'No signs of Raumian semblance. Blades for arms, tendrils where a head should be, erratic beyond reason. What has the Cube done.',
            canvasSize: 28, attackFlags: ['_flickerAttacking'], animLockFlags: ['_flickerAttacking'] },
        flicker_maimed: { name: 'Maimed Flicker', health: 20, speed: 70, chaseSpeed: 100, damage: 5, size: 20, color: 0x5a2a7a,
            ai: 'erratic_maimed', attackCooldown: 600, lootTable: 'flicker_drop',
            acidTrailInterval: 180, acidDamage: 2, acidDuration: 8000, acidTickRate: 500,
            desc: 'Blades severed. What spills from the stumps eats through everything it touches. Still coming.',
            canvasSize: 28 }
    }
};

// ═══════════════════════════════════════════════════════════
// DEFENSE EVENT DATA — Foundry Convoy Defense configuration
// NPC names, dialogue, checkpoint upgrades, wave composition
// ═══════════════════════════════════════════════════════════
