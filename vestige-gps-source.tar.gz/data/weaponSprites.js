// Vestige GPS — WEAPON_SPRITE_DATA
// Extracted from game_2_.html lines 1906-2390

export const WEAPON_SPRITE_DATA = {
    foundryFrames: {
        // ── TERRACORP — Conventional Ballistic ──
        terracorp: {
            stock:      { name: 'Stock',      weight: 30,
                mult: { damage: 1.0, fireRate: 1.0, accuracy: 1.0, mag: 1.0, reload: 1.0 },
                parts: { barrel: 'standard', stock: 'polymer', magazine: 'box', muzzle: 'birdcage' } },
            tactical:   { name: 'Tactical',   weight: 25,
                mult: { damage: 1.0, fireRate: 1.05, accuracy: 1.1, mag: 1.0, reload: 0.95 },
                parts: { barrel: 'standard', stock: 'adjustable', magazine: 'box', muzzle: 'compensator' } },
            heavy:      { name: 'Heavy Duty',  weight: 20,
                mult: { damage: 1.15, fireRate: 0.85, accuracy: 1.05, mag: 0.9, reload: 1.1 },
                parts: { barrel: 'heavy', stock: 'fixed', magazine: 'box', muzzle: 'brake' } },
            suppressed: { name: 'Suppressed',  weight: 15,
                mult: { damage: 0.9, fireRate: 1.0, accuracy: 0.95, mag: 1.0, reload: 1.0 },
                parts: { barrel: 'standard', stock: 'polymer', magazine: 'box', muzzle: 'suppressor' } },
            cqb:        { name: 'CQB',         weight: 10,
                mult: { damage: 0.95, fireRate: 1.15, accuracy: 0.8, mag: 1.15, reload: 0.9 },
                parts: { barrel: 'short', stock: 'folding', magazine: 'extended', muzzle: 'flash_hider' } }
        },
        // ── UCR — Precision / Gauss-Assisted ──
        ucr: {
            stock:       { name: 'Stock',        weight: 25,
                mult: { damage: 1.0, fireRate: 1.0, accuracy: 1.05, mag: 1.0, reload: 1.0 },
                parts: { barrel: 'precision', stock: 'ergonomic', magazine: 'flush', muzzle: 'compensator' } },
            marksman:    { name: 'Marksman',     weight: 25,
                mult: { damage: 1.1, fireRate: 0.85, accuracy: 1.25, mag: 0.85, reload: 1.1 },
                parts: { barrel: 'match', stock: 'precision', magazine: 'flush', muzzle: 'tuned' } },
            railAssist:  { name: 'Rail-Assisted', weight: 20,
                mult: { damage: 1.2, fireRate: 0.9, accuracy: 1.15, mag: 0.9, reload: 1.05 },
                parts: { barrel: 'railed', stock: 'ergonomic', magazine: 'flush', muzzle: 'coils' } },
            lightweight: { name: 'Lightweight',  weight: 20,
                mult: { damage: 0.9, fireRate: 1.1, accuracy: 1.0, mag: 1.1, reload: 0.85 },
                parts: { barrel: 'fluted', stock: 'skeleton', magazine: 'flush', muzzle: 'ported' } },
            competition: { name: 'Competition',  weight: 10,
                mult: { damage: 0.95, fireRate: 1.0, accuracy: 1.3, mag: 0.8, reload: 1.15 },
                parts: { barrel: 'match', stock: 'thumbhole', magazine: 'flush', muzzle: 'tuned' } }
        },
        // ── DERALICT — Industrial Repurposed ──
        deralict: {
            stock:       { name: 'Stock',        weight: 25,
                mult: { damage: 1.05, fireRate: 1.0, accuracy: 0.95, mag: 1.0, reload: 1.05 },
                parts: { barrel: 'bore', stock: 'pipe', magazine: 'canister', muzzle: 'nozzle' } },
            overclocked: { name: 'Overclocked',  weight: 20,
                mult: { damage: 0.85, fireRate: 1.35, accuracy: 0.85, mag: 1.2, reload: 0.85 },
                parts: { barrel: 'bore', stock: 'pipe', magazine: 'drum', muzzle: 'open' } },
            reinforced:  { name: 'Reinforced',   weight: 20,
                mult: { damage: 1.25, fireRate: 0.75, accuracy: 1.0, mag: 0.85, reload: 1.2 },
                parts: { barrel: 'heavy_bore', stock: 'braced', magazine: 'canister', muzzle: 'cage' } },
            boreOut:     { name: 'Bore-Out',     weight: 20,
                mult: { damage: 1.4, fireRate: 0.6, accuracy: 1.1, mag: 0.7, reload: 1.3 },
                parts: { barrel: 'wide_bore', stock: 'none', magazine: 'hopper', muzzle: 'flared' } },
            stripped:    { name: 'Stripped',      weight: 15,
                mult: { damage: 0.9, fireRate: 1.2, accuracy: 0.9, mag: 1.1, reload: 0.9 },
                parts: { barrel: 'bore', stock: 'none', magazine: 'canister', muzzle: 'open' } }
        },
        // ── SWORN — Scavenged Hybrid ──
        sworn: {
            stock:       { name: 'Stock',         weight: 25,
                mult: { damage: 1.0, fireRate: 1.0, accuracy: 1.0, mag: 1.0, reload: 1.0 },
                parts: { barrel: 'salvaged', stock: 'wrapped', magazine: 'taped', muzzle: 'hacksawed' } },
            fieldMod:    { name: 'Field-Modified', weight: 25,
                mult: { damage: 1.05, fireRate: 1.1, accuracy: 0.95, mag: 1.05, reload: 0.95 },
                parts: { barrel: 'salvaged', stock: 'chopped', magazine: 'taped_double', muzzle: 'welded' } },
            stripped:    { name: 'Stripped',       weight: 20,
                mult: { damage: 0.85, fireRate: 1.2, accuracy: 0.9, mag: 1.0, reload: 0.85 },
                parts: { barrel: 'cut_down', stock: 'none', magazine: 'taped', muzzle: 'raw' } },
            juryRig:     { name: 'Jury-Rigged',   weight: 15,
                mult: { damage: 1.15, fireRate: 1.15, accuracy: 0.85, mag: 1.2, reload: 1.15 },
                parts: { barrel: 'mixed', stock: 'scrap', magazine: 'franken', muzzle: 'improvised' } },
            uprising:    { name: 'Uprising',      weight: 15,
                mult: { damage: 1.1, fireRate: 1.0, accuracy: 1.05, mag: 0.9, reload: 1.0 },
                parts: { barrel: 'salvaged', stock: 'carved', magazine: 'taped', muzzle: 'filed' } }
        },
        // ── BLACKREACH — Focused Energy ──
        blackreach: {
            stock:       { name: 'Stock',        weight: 25,
                mult: { damage: 1.05, fireRate: 1.0, accuracy: 1.05, mag: 1.0, reload: 1.0 },
                parts: { barrel: 'emitter', stock: 'integrated', magazine: 'cell', muzzle: 'lens' } },
            focused:     { name: 'Focused',      weight: 25,
                mult: { damage: 1.2, fireRate: 0.8, accuracy: 1.3, mag: 0.85, reload: 1.15 },
                parts: { barrel: 'long_emitter', stock: 'integrated', magazine: 'cell', muzzle: 'aperture' } },
            channeled:   { name: 'Channeled',    weight: 20,
                mult: { damage: 1.1, fireRate: 1.1, accuracy: 1.0, mag: 1.1, reload: 1.0 },
                parts: { barrel: 'emitter', stock: 'skeletal', magazine: 'dual_cell', muzzle: 'diffuser' } },
            overcharged: { name: 'Overcharged',  weight: 15,
                mult: { damage: 1.35, fireRate: 0.7, accuracy: 1.1, mag: 0.7, reload: 1.3 },
                parts: { barrel: 'charged_emitter', stock: 'none', magazine: 'core', muzzle: 'prism' } },
            sleek:       { name: 'Sleek',        weight: 15,
                mult: { damage: 0.9, fireRate: 1.15, accuracy: 1.0, mag: 1.15, reload: 0.85 },
                parts: { barrel: 'slim_emitter', stock: 'skeletal', magazine: 'cell', muzzle: 'slit' } }
        },
        // ── CEPHALON — Anomalous Particle ──
        cephalon: {
            stock:       { name: 'Stock',        weight: 25,
                mult: { damage: 1.05, fireRate: 1.0, accuracy: 1.0, mag: 1.0, reload: 1.0 },
                parts: { barrel: 'conduit', stock: 'floating', magazine: 'phase', muzzle: 'ring' } },
            phaseTuned:  { name: 'Phase-Tuned',  weight: 25,
                mult: { damage: 1.0, fireRate: 1.0, accuracy: 1.35, mag: 0.9, reload: 1.05 },
                parts: { barrel: 'long_conduit', stock: 'floating', magazine: 'phase', muzzle: 'void_ring' } },
            recursive:   { name: 'Recursive',    weight: 20,
                mult: { damage: 0.9, fireRate: 1.1, accuracy: 1.0, mag: 1.4, reload: 0.8 },
                parts: { barrel: 'conduit', stock: 'organic', magazine: 'recursive', muzzle: 'ring' } },
            unstable:    { name: 'Unstable',     weight: 15,
                mult: { damage: 1.3, fireRate: 1.2, accuracy: 0.9, mag: 0.8, reload: 1.2 },
                parts: { barrel: 'warped', stock: 'none', magazine: 'exposed', muzzle: 'fracture' } },
            resonant:    { name: 'Resonant',     weight: 15,
                mult: { damage: 1.15, fireRate: 0.85, accuracy: 1.15, mag: 1.0, reload: 1.1 },
                parts: { barrel: 'tuned_conduit', stock: 'floating', magazine: 'phase', muzzle: 'harmonic' } }
        }
    },
    scrapFrames: {
        stock:    { name: 'Stock',    weight: 40,
            mult: { damage: 1.0, fireRate: 1.0, accuracy: 1.0, mag: 1.0, reload: 1.0 },
            parts: { barrel: 'pipe', stock: 'wood', magazine: 'taped', muzzle: 'raw' } },
        stripped: { name: 'Stripped', weight: 30,
            mult: { damage: 0.85, fireRate: 1.15, accuracy: 0.95, mag: 1.1, reload: 0.9 },
            parts: { barrel: 'pipe', stock: 'none', magazine: 'taped', muzzle: 'raw' } },
        taped:    { name: 'Taped',   weight: 30,
            mult: { damage: 0.9, fireRate: 1.05, accuracy: 0.9, mag: 1.05, reload: 0.95 },
            parts: { barrel: 'pipe', stock: 'plank', magazine: 'taped', muzzle: 'hacksawed' } }
    },
    foundryFX: {
        terracorp: {
            bulletColor: 0xffdd44, bulletShape: 'rect', bulletSize: [8, 4],
            muzzleColor: 0xffcc44, muzzleCore: 0xffffff, muzzleSize: 5, muzzleType: 'flash',
            tracerColor: 0xffdd66, tracerCore: 0xffffff, tracerWidth: 2, tracerLen: 60, tracerFade: 100,
            impactColor: 0xffcc44, impactType: 'sparks'
        },
        ucr: {
            bulletColor: 0x88bbff, bulletShape: 'rect', bulletSize: [7, 3],
            muzzleColor: 0x88ccff, muzzleCore: 0xeeeeff, muzzleSize: 4, muzzleType: 'flash',
            tracerColor: 0x88bbff, tracerCore: 0xddeeff, tracerWidth: 1.5, tracerLen: 70, tracerFade: 80,
            impactColor: 0x88bbff, impactType: 'sparks'
        },
        deralict: {
            bulletColor: 0xff8833, bulletShape: 'rect', bulletSize: [9, 5],
            muzzleColor: 0xff7722, muzzleCore: 0xffcc66, muzzleSize: 7, muzzleType: 'sparky',
            tracerColor: 0xff8833, tracerCore: 0xffaa44, tracerWidth: 3, tracerLen: 50, tracerFade: 100,
            impactColor: 0xff7722, impactType: 'sparks', impactCount: 8
        },
        sworn: {
            bulletColor: 0xddcc44, bulletShape: 'rect', bulletSize: [8, 4],
            muzzleColor: 0xddcc44, muzzleCore: 0xffffcc, muzzleSize: 5, muzzleType: 'smoky',
            tracerColor: 0xddcc44, tracerCore: 0xffffee, tracerWidth: 2, tracerLen: 55, tracerFade: 100,
            tracerWobble: 0.02,
            impactColor: 0xddcc44, impactType: 'sparks'
        },
        blackreach: {
            bulletColor: 0xeebb33, bulletShape: 'circle', bulletSize: [5, 5],
            muzzleColor: 0xeebb33, muzzleCore: 0xffffcc, muzzleSize: 4, muzzleType: 'pulse',
            tracerColor: 0xeebb33, tracerCore: 0xffdd88, tracerWidth: 1, tracerLen: 80, tracerFade: 150,
            impactColor: 0xeebb33, impactType: 'glow'
        },
        cephalon: {
            bulletColor: 0x33aaaa, bulletShape: 'circle', bulletSize: [5, 5],
            muzzleColor: 0x33aaaa, muzzleCore: 0x88ffee, muzzleSize: 4, muzzleType: 'ripple',
            tracerColor: 0x33aaaa, tracerCore: 0x66ddcc, tracerWidth: 1.5, tracerLen: 65, tracerFade: 120,
            tracerWavy: true,
            impactColor: 0x33aaaa, impactType: 'glow', impactDistort: true
        },
        scrap: {
            bulletColor: 0xccaa44, bulletShape: 'rect', bulletSize: [7, 4],
            muzzleColor: 0xccaa33, muzzleCore: 0xffffdd, muzzleSize: 5, muzzleType: 'flash',
            tracerColor: 0xccaa44, tracerCore: 0xddddaa, tracerWidth: 2, tracerLen: 50, tracerFade: 90,
            impactColor: 0xccaa33, impactType: 'sparks'
        }
    },
    foundryMeleeFX: {
        terracorp: {
            swingColor: 0xffdd44, swingCore: 0xffffff, swingWidth: 2.5,
            impactColor: 0xffcc44, sparkColor: 0xffaa44, impactCount: 6,
            shakeIntensity: 0.004, trailType: 'arc'
        },
        ucr: {
            swingColor: 0x88bbff, swingCore: 0xddeeff, swingWidth: 2,
            impactColor: 0x88ccff, sparkColor: 0x88bbff, impactCount: 5,
            shakeIntensity: 0.003, trailType: 'arc'
        },
        deralict: {
            swingColor: 0xff8833, swingCore: 0xffcc66, swingWidth: 3,
            impactColor: 0xff7722, sparkColor: 0xff6611, impactCount: 8,
            shakeIntensity: 0.005, trailType: 'heavy'
        },
        sworn: {
            swingColor: 0xddcc44, swingCore: 0xffffcc, swingWidth: 2,
            impactColor: 0xddcc44, sparkColor: 0xccbb33, impactCount: 5,
            shakeIntensity: 0.003, trailType: 'arc'
        },
        blackreach: {
            swingColor: 0xeebb33, swingCore: 0xffffcc, swingWidth: 2,
            impactColor: 0xeebb33, sparkColor: 0xffdd44, impactCount: 4,
            shakeIntensity: 0.002, trailType: 'glow'
        },
        cephalon: {
            swingColor: 0x33aaaa, swingCore: 0x88ffee, swingWidth: 2,
            impactColor: 0x33aaaa, sparkColor: 0x66ddcc, impactCount: 4,
            shakeIntensity: 0.002, trailType: 'glow', trailDistort: true
        },
        scrap: {
            swingColor: 0xffcc44, swingCore: 0xffffff, swingWidth: 2,
            impactColor: 0xccaa33, sparkColor: 0xddbb44, impactCount: 6,
            shakeIntensity: 0.003, trailType: 'arc'
        }
    },
    foundryMeleeFrames: {
        // ── TERRACORP — Standard-issue combat tools ──
        terracorp: {
            stock:     { name: 'Stock',     weight: 30,
                mult: { damage: 1.0, attackSpeed: 1.0, stagger: 1.0, reach: 1.0 },
                parts: { handle: 'polymer', head: 'steel', guard: 'crossbar' } },
            tactical:  { name: 'Tactical',  weight: 25,
                mult: { damage: 0.95, attackSpeed: 1.15, stagger: 0.9, reach: 0.95 },
                parts: { handle: 'rubber', head: 'steel', guard: 'knuckle' } },
            combat:    { name: 'Combat',    weight: 25,
                mult: { damage: 1.15, attackSpeed: 0.85, stagger: 1.2, reach: 1.05 },
                parts: { handle: 'polymer', head: 'hardened', guard: 'crossbar' } },
            breacher:  { name: 'Breacher',  weight: 20,
                mult: { damage: 1.25, attackSpeed: 0.75, stagger: 1.4, reach: 1.1 },
                parts: { handle: 'polymer', head: 'tungsten', guard: 'full' } }
        },
        // ── UCR — Precision-forged, balanced ──
        ucr: {
            stock:     { name: 'Stock',     weight: 25,
                mult: { damage: 1.0, attackSpeed: 1.05, stagger: 1.0, reach: 1.0 },
                parts: { handle: 'machined', head: 'alloy', guard: 'swept' } },
            duelist:   { name: 'Duelist',   weight: 25,
                mult: { damage: 0.9, attackSpeed: 1.3, stagger: 0.7, reach: 1.05 },
                parts: { handle: 'machined', head: 'alloy', guard: 'rapier' } },
            balanced:  { name: 'Balanced',  weight: 25,
                mult: { damage: 1.05, attackSpeed: 1.05, stagger: 1.05, reach: 1.0 },
                parts: { handle: 'contoured', head: 'tempered', guard: 'swept' } },
            ceremonial:{ name: 'Ceremonial', weight: 25,
                mult: { damage: 1.15, attackSpeed: 0.9, stagger: 1.15, reach: 1.05 },
                parts: { handle: 'engraved', head: 'tempered', guard: 'ornate' } }
        },
        // ── DERALICT — Industrial bludgeons ──
        deralict: {
            stock:     { name: 'Stock',      weight: 25,
                mult: { damage: 1.1, attackSpeed: 0.95, stagger: 1.1, reach: 1.0 },
                parts: { handle: 'pipe', head: 'cast_iron', guard: 'flange' } },
            overdriven:{ name: 'Overdriven', weight: 25,
                mult: { damage: 0.85, attackSpeed: 1.3, stagger: 0.8, reach: 0.9 },
                parts: { handle: 'pipe', head: 'piston', guard: 'none' } },
            sledge:    { name: 'Sledge',     weight: 25,
                mult: { damage: 1.35, attackSpeed: 0.65, stagger: 1.5, reach: 1.1 },
                parts: { handle: 'rebar', head: 'counterweight', guard: 'plate' } },
            cutter:    { name: 'Cutter',     weight: 25,
                mult: { damage: 1.2, attackSpeed: 0.85, stagger: 1.0, reach: 1.0 },
                parts: { handle: 'pipe', head: 'saw_disc', guard: 'cage' } }
        },
        // ── SWORN — Resistance improvised ──
        sworn: {
            stock:     { name: 'Stock',       weight: 25,
                mult: { damage: 1.0, attackSpeed: 1.0, stagger: 1.0, reach: 1.0 },
                parts: { handle: 'wrapped', head: 'scavenged', guard: 'tape' } },
            shiv:      { name: 'Shiv',        weight: 25,
                mult: { damage: 0.8, attackSpeed: 1.4, stagger: 0.6, reach: 0.85 },
                parts: { handle: 'cord', head: 'sharpened', guard: 'none' } },
            cleaver:   { name: 'Cleaver',     weight: 25,
                mult: { damage: 1.2, attackSpeed: 0.85, stagger: 1.2, reach: 1.0 },
                parts: { handle: 'carved', head: 'chopper', guard: 'bolted' } },
            ripper:    { name: 'Ripper',      weight: 25,
                mult: { damage: 1.1, attackSpeed: 1.1, stagger: 0.9, reach: 0.95 },
                parts: { handle: 'wrapped', head: 'serrated', guard: 'tape' } }
        },
        // ── BLACKREACH — Energy-edged ──
        blackreach: {
            stock:     { name: 'Stock',      weight: 25,
                mult: { damage: 1.05, attackSpeed: 1.0, stagger: 1.0, reach: 1.0 },
                parts: { handle: 'crystal', head: 'energy_edge', guard: 'emitter' } },
            focused:   { name: 'Focused',    weight: 25,
                mult: { damage: 1.25, attackSpeed: 0.85, stagger: 1.1, reach: 1.15 },
                parts: { handle: 'crystal', head: 'focused_edge', guard: 'prism' } },
            resonant:  { name: 'Resonant',   weight: 25,
                mult: { damage: 1.0, attackSpeed: 1.2, stagger: 0.85, reach: 1.0 },
                parts: { handle: 'slim_crystal', head: 'harmonic', guard: 'emitter' } },
            nova:      { name: 'Nova',       weight: 25,
                mult: { damage: 1.3, attackSpeed: 0.75, stagger: 1.4, reach: 1.1 },
                parts: { handle: 'crystal', head: 'overcharged', guard: 'arc' } }
        },
        // ── CEPHALON — Anomalous geometry ──
        cephalon: {
            stock:     { name: 'Stock',       weight: 25,
                mult: { damage: 1.05, attackSpeed: 1.0, stagger: 1.0, reach: 1.0 },
                parts: { handle: 'bone', head: 'phase_edge', guard: 'ring' } },
            recursive: { name: 'Recursive',   weight: 25,
                mult: { damage: 0.9, attackSpeed: 1.25, stagger: 0.8, reach: 1.1 },
                parts: { handle: 'tendril', head: 'fold', guard: 'none' } },
            void:      { name: 'Void-Touched', weight: 25,
                mult: { damage: 1.2, attackSpeed: 0.9, stagger: 1.2, reach: 1.0 },
                parts: { handle: 'bone', head: 'void_edge', guard: 'orbit' } },
            parasitic: { name: 'Parasitic',    weight: 25,
                mult: { damage: 1.15, attackSpeed: 1.1, stagger: 1.0, reach: 0.95 },
                parts: { handle: 'organic', head: 'leech', guard: 'spine' } }
        }
    },
    scrapMeleeFrames: {
        stock:    { name: 'Stock',    weight: 40,
            mult: { damage: 1.0, attackSpeed: 1.0, stagger: 1.0, reach: 1.0 },
            parts: { handle: 'wood', head: 'rusty', guard: 'none' } },
        honed:    { name: 'Honed',    weight: 30,
            mult: { damage: 0.85, attackSpeed: 1.25, stagger: 0.7, reach: 0.95 },
            parts: { handle: 'tape', head: 'filed', guard: 'none' } },
        weighted: { name: 'Weighted', weight: 30,
            mult: { damage: 1.2, attackSpeed: 0.75, stagger: 1.4, reach: 1.05 },
            parts: { handle: 'wood', head: 'bolted', guard: 'scrap' } }
    },
    weaponNames: {
        // T1-T2: Scrap style — no foundry, just junk
        scrap: {
            prefix: ['Rust', 'Scrap', 'Junk', 'Pipe', 'Worn', 'Crude', 'Bent', 'Cracked', 'Tape-Wrapped', 'Salvaged'],
            rifle: ['Popper', 'Banger', 'Rattler', 'Spitter', 'Clacker', 'Barker'],
            mini: ['Buzzer', 'Sprayer', 'Spitter', 'Rattler', 'Zipper', 'Plinker'],
            heavy_rifle: ['Chucker', 'Thumper', 'Growler', 'Belcher', 'Rumbler'],
            handcannon: ['Boomer', 'Thumper', 'Kicker', 'Biter', 'Slugger'],
            sniper: ['Poker', 'Piercer', 'Peeker', 'Pinger', 'Reacher']
        },
        // T3+: Foundry designations — each foundry has its own naming convention
        foundry: {
            terracorp: {
                rifle: ['AR', 'CR', 'TR', 'Sentry', 'Ranger', 'Patrol', 'Enforcer'],
                mini: ['PDW', 'CQB', 'SM', 'Hornet', 'Vector', 'Viper'],
                heavy_rifle: ['SAW', 'MG', 'LMG', 'Typhoon', 'Barrage', 'Rampart'],
                handcannon: ['TC', 'DM', 'HC', 'Kingpin', 'Judge', 'Authority'],
                sniper: ['DMR', 'SR', 'MK', 'Overwatch', 'Longarm', 'Sentinel']
            },
            ucr: {
                rifle: ['R', 'MR', 'PR', 'Vanguard', 'Precision', 'Caliber'],
                mini: ['MP', 'CQR', 'SG', 'Quickdraw', 'Tempest', 'Razor'],
                heavy_rifle: ['LR', 'HV', 'BR', 'Avalanche', 'Cascade', 'Titan'],
                handcannon: ['Mag', 'PC', 'HK', 'Verdict', 'Decree', 'Sovereign'],
                sniper: ['LR', 'XR', 'DX', 'Parallax', 'Zenith', 'Apex']
            },
            deralict: {
                rifle: ['D', 'RK', 'Drill', 'Jackhammer', 'Rockbreaker', 'Tunneler'],
                mini: ['Grinder', 'Bore', 'Cut', 'Buzzsaw', 'Shredder', 'Mulcher'],
                heavy_rifle: ['Crusher', 'Rig', 'Core', 'Demolisher', 'Collapser', 'Seismic'],
                handcannon: ['Slug', 'Ram', 'Piston', 'Boreshot', 'Breaker', 'Hammerfall'],
                sniper: ['Spike', 'Reach', 'Pin', 'Deepstrike', 'Faultline', 'Surveyor']
            },
            sworn: {
                rifle: ['Mk', 'F', 'Lib', 'Defiant', 'Reclaimer', 'Uprising'],
                mini: ['Hornet', 'Wasp', 'Sting', 'Spark', 'Rally', 'Firebrand'],
                heavy_rifle: ['Thunder', 'Wrath', 'Fury', 'Broadside', 'Rampage', 'Barricade'],
                handcannon: ['Fist', 'Oath', 'Bark', 'Conviction', 'Last Resort', 'Ironhand'],
                sniper: ['Ghost', 'Shadow', 'Watch', 'Vigil', 'Whisper', 'Patience']
            },
            blackreach: {
                rifle: ['Whisper', 'Veil', 'Shade', 'Umbral', 'Nocturne', 'Gloom'],
                mini: ['Murmur', 'Drift', 'Pulse', 'Wisp', 'Haze', 'Wraith'],
                heavy_rifle: ['Silence', 'Weight', 'Hollow', 'Oblivion', 'Abyss', 'Dread'],
                handcannon: ['Eclipse', 'Void', 'Dusk', 'Omen', 'Requiem', 'Dirge'],
                sniper: ['Phantom', 'Thread', 'Reach', 'Vanish', 'Mirage', 'Enigma']
            },
            cephalon: {
                rifle: ['Signal', 'Wave', 'Node', 'Cipher', 'Vector', 'Nexus'],
                mini: ['Hum', 'Freq', 'Drone', 'Static', 'Flux', 'Catalyst'],
                heavy_rifle: ['Resonance', 'Mass', 'Depth', 'Anomaly', 'Singularity', 'Epoch'],
                handcannon: ['Pulse', 'Rift', 'Core', 'Paradox', 'Vertex', 'Threshold'],
                sniper: ['Arc', 'Lens', 'Axis', 'Horizon', 'Convergence', 'Focus']
            }
        }
    },
    meleeNames: {
        scrap: {
            blade: ['Shiv', 'Shank', 'Slicer', 'Cutter', 'Fang', 'Ripper'],
            blunt: ['Basher', 'Clubber', 'Cracker', 'Smasher', 'Breaker'],
            heavy: ['Crusher', 'Slammer', 'Maul', 'Wrecker', 'Pounder']
        },
        foundry: {
            terracorp: {
                blade: ['Combat Knife', 'Bayonet', 'Sidearm Edge'],
                blunt: ['Riot Baton', 'Compliance Tool', 'Pacifier'],
                heavy: ['Breaching Hammer', 'Siege Maul', 'TC Demolisher']
            },
            ucr: {
                blade: ['Officer Blade', 'Dress Saber', 'Precision Edge'],
                blunt: ['Mace', 'UCR Enforcer', 'Command Baton'],
                heavy: ['War Hammer', 'Impact Driver', 'Devastator']
            },
            deralict: {
                blade: ['Ore Cutter', 'Mining Shear', 'Slag Edge'],
                blunt: ['Rock Hammer', 'Drill Shaft', 'Piledriver'],
                heavy: ['Bore Maul', 'Seismic Head', 'Deralict Crusher']
            },
            sworn: {
                blade: ['Freedom Edge', 'Reclaimer', 'Field Knife'],
                blunt: ['Protest Stick', 'Rally Club', 'Defiance'],
                heavy: ['Uprising Maul', 'Breaker', 'Last Word']
            },
            blackreach: {
                blade: ['Twilight Fang', 'Veil Cutter', 'Shade Knife'],
                blunt: ['Midnight Rod', 'Obsidian Mace', 'Dark Weight'],
                heavy: ['Eclipse Maul', 'Void Hammer', 'Silence']
            },
            cephalon: {
                blade: ['Frequency Blade', 'Signal Edge', 'Harmonic'],
                blunt: ['Resonance Rod', 'Tuning Fork', 'Amplitude'],
                heavy: ['Mass Driver', 'Waveform', 'Terminus']
            }
        }
    },
    gearNames: {
        scrap: {
            scrap_armor: ['Rags', 'Wraps', 'Patchwork', 'Bindings', 'Scraps', 'Tatters'],
            gear_light: ['Vest', 'Liner', 'Underlay', 'Shell', 'Guard', 'Cover'],
            gear_medium: ['Coat', 'Jacket', 'Harness', 'Tunic', 'Overcoat', 'Wrap'],
            gear_heavy: ['Plate', 'Hauler', 'Carapace', 'Shell', 'Cuirass', 'Hull']
        },
        foundry: {
            terracorp: {
                gear_light: ['Recon Suit', 'Scout Rig', 'Patrol Vest', 'Ranger Kit'],
                gear_medium: ['Field Plate', 'Standard Issue', 'Enforcer Rig', 'Garrison Kit'],
                gear_heavy: ['Siege Plate', 'Bulwark', 'Bunker Suit', 'Fortress Rig']
            },
            ucr: {
                gear_light: ['Officer Vest', 'Dress Guard', 'Precision Weave', 'Recon Plate'],
                gear_medium: ['Combat Harness', 'War Coat', 'Vanguard Plate', 'Duty Rig'],
                gear_heavy: ['Juggernaut', 'Sovereign Plate', 'Fortress', 'Ironclad']
            },
            deralict: {
                gear_light: ['Shaft Vest', 'Tunnel Wrap', 'Bore Liner', 'Miner Rig'],
                gear_medium: ['Blast Coat', 'Core Suit', 'Dig Harness', 'Depth Plate'],
                gear_heavy: ['Crusher Rig', 'Bedrock Suit', 'Excavator', 'Tectonic Plate']
            },
            sworn: {
                gear_light: ['Runner Vest', 'Field Wrap', 'Scout Coat', 'Nomad Kit'],
                gear_medium: ['Resistance Coat', 'Rally Plate', 'Frontline Rig', 'Barricade Vest'],
                gear_heavy: ['Vanguard Plate', 'Bastion', 'Sworn Wall', 'Iron Oath']
            },
            blackreach: {
                gear_light: ['Shade Vest', 'Whisper Wrap', 'Veil Weave', 'Dusk Liner'],
                gear_medium: ['Twilight Coat', 'Umbral Plate', 'Gloom Harness', 'Night Rig'],
                gear_heavy: ['Abyss Plate', 'Eclipse Suit', 'Void Shell', 'Darkfall']
            },
            cephalon: {
                gear_light: ['Signal Vest', 'Flux Weave', 'Node Liner', 'Resonance Wrap'],
                gear_medium: ['Waveform Coat', 'Harmonic Plate', 'Frequency Rig', 'Cipher Vest'],
                gear_heavy: ['Anomaly Shell', 'Singularity Plate', 'Mass Core', 'Epoch Suit']
            }
        }
    },
    baneWeapons: {
        warden: {
            baseId: 'heavy', name: "Warden's Burden", icon: '🔨',
            category: 'melee',
            stats: { damage: 85, attackSpeed: 25, reach: 80, stagger: 95, shieldAttack: 3 },
            signature: { id: 'bane_shackled', name: 'Shackled', desc: 'Every 15s melee becomes power-charged. Hit unleashes charge, shackling nearby enemies for 5s', effect: 'shackled', value: 5, cooldown: 15000 },
            lore: 'The weight of judgment, carried without mercy.'
        },
        swarmQueen: {
            baseId: 'mini', name: 'Swarm Caller', icon: '🔫',
            category: 'weapon',
            stats: { damage: 45, fireRate: 58, accuracy: 60, crit: 50, mag: 70, reload: 80, pierce: 2, targetRange: 2 },
            fireMode: 'auto', recoilType: 'erratic',
            signature: { id: 'bane_parasitic', name: 'Parasitic Rounds', desc: 'Every 10s auto-loads 10 poison rounds (+1 dmg, heals 2HP per hit)', effect: 'parasiticRounds', value: 10, cooldown: 10000, dot: 'poison' },
            lore: 'Each bullet carries a hunger of its own.'
        },
        phantom: {
            baseId: 'blade', name: 'Voidfang', icon: '🔪',
            category: 'melee',
            stats: { damage: 50, attackSpeed: 65, reach: 50, stagger: 25, shieldAttack: 2 },
            signature: { id: 'bane_phaseshift', name: 'Phase Shift', desc: 'Dodging turns you invisible for 5s. 10s cooldown', effect: 'phaseShift', value: 5, cooldown: 10000 },
            lore: 'Cuts between what is and what was.'
        },
        ironclad: {
            baseId: 'heavy_rifle', name: 'Siege Breaker', icon: '🔫',
            category: 'weapon',
            stats: { damage: 95, fireRate: 18, accuracy: 80, crit: 80, mag: 15, reload: 40, pierce: 3, targetRange: 3 },
            fireMode: 'semi', recoilType: 'heavy',
            signature: { id: 'bane_hardened', name: 'Hardened', desc: 'Dodging reduces damage taken by 50% for 5s. 25s cooldown', effect: 'hardened', value: 50, cooldown: 25000, duration: 5000 },
            lore: 'Built from the plates of the thing it killed.'
        },
        cubeAnomaly: {
            baseId: 'handcannon', name: 'Anomaly Core', icon: '🔫',
            category: 'weapon',
            stats: { damage: 70, fireRate: 25, accuracy: 82, crit: 120, mag: 16, reload: 40, pierce: 2, targetRange: 4 },
            fireMode: 'semi', recoilType: 'kick',
            signature: { id: 'bane_anotherworld', name: 'Another World', desc: 'Kills spawn a healing cube (100HP). When full, seeks enemy and explodes. 30s cooldown', effect: 'anotherWorld', value: 100, cooldown: 30000 },
            lore: 'A fragment of the anomaly, weaponized.'
        }
    }
};

