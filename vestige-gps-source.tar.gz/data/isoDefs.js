// Vestige GPS — ISO_DEFS
// Extracted from monolith L4394-5539

export const ISO_DEFS = {
    
    // ==================== FURNITURE ====================
    
    // --- Medicine Cabinet (Pharmacy, Research Lab) ---
    medicine_cabinet: {
        w: 16, h: 20, sideW: 10,
        colors: { body: 0xdddddd, glass: 0x8aaabb, cross: 0xaa3333, handle: 0x888888, trim: 0xcccccc },
        parts: [
            { face: 'front', x: 0, y: 0, w: 16, h: 20, color: 'body', z: 1 },
            { face: 'front', x: 0, y: 0, w: 14, h: 18, color: 'glass', alpha: 0.45, z: 2 },
            { face: 'front', x: 0, y: -4, w: 12, h: 1, color: 'trim', z: 3 },
            { face: 'front', x: 0, y: 4, w: 12, h: 1, color: 'trim', z: 3 },
            { face: 'front', x: 0, y: 0, w: 2, h: 6, color: 'cross', z: 4 },
            { face: 'front', x: 0, y: 0, w: 6, h: 2, color: 'cross', z: 4 },
            { face: 'front', x: 6, y: 0, w: 1, h: 3, color: 'handle', z: 5 },
            { face: 'back', x: 0, y: 0, w: 16, h: 20, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 14, h: 18, color: 'body', z: 2 },
            { face: 'back', x: 0, y: -6, w: 10, h: 2, color: 'trim', shade: 'dark', alpha: 0.3, z: 3 },
            { face: 'back', x: 0, y: 6, w: 10, h: 2, color: 'trim', shade: 'dark', alpha: 0.3, z: 3 },
            { face: 'side', x: 0, y: 0, w: 10, h: 20, color: 'body', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -6, w: 8, h: 1, color: 'trim', alpha: 0.3, z: 2 },
            { face: 'top', x: 0, y: -10, w: 16, h: 3, color: 'body', shade: 'light', z: 6 }
        ]
    },
    
    // --- Gun Rack (Police Station, Bunker) ---
    gun_rack: {
        w: 20, h: 30, sideW: 10,
        colors: { frame: 0x3a3a3a, rifle: 0x1a1a1a, backing: 0x4a4a4a, lock: 0x8a8a3a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 20, h: 30, color: 'backing', z: 1 },
            { face: 'front', x: -6, y: 0, w: 2, h: 20, color: 'rifle', z: 3 },
            { face: 'front', x: 0, y: 0, w: 2, h: 22, color: 'rifle', z: 3 },
            { face: 'front', x: 6, y: 0, w: 2, h: 18, color: 'rifle', z: 3 },
            { face: 'front', x: 0, y: -12, w: 18, h: 2, color: 'frame', z: 4 },
            { face: 'front', x: 0, y: 12, w: 18, h: 2, color: 'frame', z: 4 },
            { face: 'front', x: 8, y: -12, w: 3, h: 3, color: 'lock', z: 5 },
            { face: 'back', x: 0, y: 0, w: 20, h: 30, color: 'frame', z: 1 },
            { face: 'back', x: 0, y: 0, w: 18, h: 28, color: 'backing', shade: 'dark', z: 2 },
            { face: 'back', x: -6, y: -4, w: 4, h: 2, color: 'frame', shade: 'dark', z: 3 },
            { face: 'back', x: 6, y: -4, w: 4, h: 2, color: 'frame', shade: 'dark', z: 3 },
            { face: 'back', x: 0, y: 8, w: 12, h: 2, color: 'frame', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 0, w: 10, h: 30, color: 'frame', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -15, w: 20, h: 3, color: 'frame', shade: 'light', z: 6 }
        ]
    },
    
    // --- Fuel Pump (Gas Station) ---
    fuel_pump: {
        w: 10, h: 24, sideW: 6,
        colors: { body: 0xcc4444, hose: 0x1a1a1a, display: 0x2a2a3a, nozzle: 0x888888, trim: 0xaa3333 },
        parts: [
            { face: 'front', x: 0, y: 0, w: 10, h: 24, color: 'body', z: 1 },
            { face: 'front', x: 0, y: -8, w: 8, h: 4, color: 'display', z: 3 },
            { face: 'front', x: 0, y: -8, w: 6, h: 2, color: 0x2a3a2a, alpha: 0.4, z: 4 },
            { face: 'front', x: 3, y: -2, w: 2, h: 4, color: 'nozzle', z: 3 },
            { face: 'front', x: 4, y: 2, w: 1, h: 8, color: 'hose', z: 2 },
            { face: 'front', x: 0, y: 10, w: 10, h: 2, color: 'trim', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: 0, w: 10, h: 24, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 8, h: 22, color: 'body', z: 2 },
            { face: 'back', x: 0, y: 10, w: 10, h: 2, color: 'trim', shade: 'darker', z: 3 },
            { face: 'back', x: 0, y: -4, w: 4, h: 6, color: 'body', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 0, w: 6, h: 24, color: 'body', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -12, w: 10, h: 3, color: 'body', shade: 'light', z: 6 }
        ]
    },
    
    // --- Jukebox (Diner) ---
    jukebox: {
        w: 14, h: 22, sideW: 8,
        colors: { body: 0x5a3a5a, chrome: 0xaa8855, glass: 0x1a1a2a, grill: 0xaa6644 },
        parts: [
            { face: 'front', x: 0, y: 0, w: 14, h: 22, color: 'body', z: 1 },
            { face: 'front', x: 0, y: -4, w: 10, h: 10, color: 'glass', z: 2 },
            { face: 'front', x: 0, y: -4, w: 4, h: 2, color: 0x3a3a3a, alpha: 0.5, z: 3 },
            { face: 'front', x: 0, y: -10, w: 12, h: 2, color: 'chrome', z: 4 },
            { face: 'front', x: 0, y: 2, w: 12, h: 1, color: 'chrome', z: 4 },
            { face: 'front', x: 0, y: 8, w: 10, h: 4, color: 'grill', z: 3 },
            { face: 'front', x: -3, y: 4, w: 2, h: 2, color: 0xcc4444, z: 5 },
            { face: 'front', x: 0, y: 4, w: 2, h: 2, color: 0x44cc44, z: 5 },
            { face: 'front', x: 3, y: 4, w: 2, h: 2, color: 0x4444cc, z: 5 },
            { face: 'back', x: 0, y: 0, w: 14, h: 22, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 12, h: 20, color: 'body', z: 2 },
            { face: 'back', x: 0, y: 6, w: 8, h: 6, color: 'body', shade: 'darker', z: 3 },
            { face: 'back', x: -3, y: -2, w: 1, h: 10, color: 0x2a2a2a, alpha: 0.4, z: 3 },
            { face: 'side', x: 0, y: 0, w: 8, h: 22, color: 'body', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -10, w: 6, h: 1, color: 'chrome', z: 3 },
            { face: 'top', x: 0, y: -11, w: 14, h: 3, color: 'body', shade: 'lighter', z: 6 }
        ]
    },
    
    // --- Pew (Church) ---
    pew: {
        w: 30, h: 10, sideW: 8,
        colors: { wood: 0x5a4a3a, seat: 0x6a5a4a, slot: 0x3a2a1a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 30, h: 8, color: 'wood', z: 1 },
            { face: 'front', x: 0, y: -5, w: 28, h: 6, color: 'seat', z: 2 },
            { face: 'front', x: -8, y: 2, w: 4, h: 2, color: 'slot', z: 3 },
            { face: 'front', x: 4, y: 2, w: 4, h: 2, color: 'slot', z: 3 },
            { face: 'front', x: -13, y: 0, w: 3, h: 10, color: 'wood', shade: 'dark', z: 2 },
            { face: 'front', x: 13, y: 0, w: 3, h: 10, color: 'wood', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: 0, w: 30, h: 8, color: 'wood', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 28, h: 6, color: 'wood', z: 2 },
            { face: 'back', x: -13, y: 0, w: 3, h: 10, color: 'wood', shade: 'darker', z: 2 },
            { face: 'back', x: 13, y: 0, w: 3, h: 10, color: 'wood', shade: 'darker', z: 2 },
            { face: 'side', x: 0, y: 0, w: 8, h: 10, color: 'wood', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -5, w: 30, h: 2, color: 'seat', shade: 'light', z: 6 }
        ]
    },
    
    // --- Exam Table (Research Lab) ---
    exam_table: {
        w: 24, h: 16, sideW: 12,
        colors: { steel: 0x4a4a4a, pad: 0x4a5a4a, paper: 0xdddddd },
        parts: [
            { face: 'front', x: 0, y: 0, w: 24, h: 14, color: 'steel', z: 1 },
            { face: 'front', x: 0, y: -3, w: 22, h: 4, color: 'pad', z: 2 },
            { face: 'front', x: -8, y: -3, w: 6, h: 2, color: 'paper', z: 3 },
            { face: 'front', x: -10, y: 5, w: 2, h: 6, color: 'steel', shade: 'dark', z: 1 },
            { face: 'front', x: 10, y: 5, w: 2, h: 6, color: 'steel', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 24, h: 14, color: 'steel', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 22, h: 12, color: 'steel', z: 2 },
            { face: 'back', x: -10, y: 5, w: 2, h: 6, color: 'steel', shade: 'darker', z: 1 },
            { face: 'back', x: 10, y: 5, w: 2, h: 6, color: 'steel', shade: 'darker', z: 1 },
            { face: 'side', x: 0, y: 0, w: 12, h: 14, color: 'steel', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: 4, w: 8, h: 2, color: 'steel', z: 2 },
            { face: 'top', x: 0, y: -7, w: 24, h: 3, color: 'pad', shade: 'light', z: 6 }
        ]
    },
    
    // --- Vending Machine (Diner, Motel, School) ---
    vending_machine: {
        w: 12, h: 28, sideW: 8,
        colors: { body: 0x2a3a5a, window: 0x3a4a5a, coin: 0x888888, hatch: 0x1a1a1a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 12, h: 28, color: 'body', z: 1 },
            { face: 'front', x: 0, y: -5, w: 9, h: 14, color: 'window', z: 2 },
            { face: 'front', x: -3, y: -9, w: 2, h: 3, color: 0xcc4444, z: 3 },
            { face: 'front', x: 0, y: -9, w: 2, h: 3, color: 0x44cc44, z: 3 },
            { face: 'front', x: 3, y: -9, w: 2, h: 3, color: 0x4444cc, z: 3 },
            { face: 'front', x: -3, y: -5, w: 2, h: 3, color: 0xcccc44, z: 3 },
            { face: 'front', x: 0, y: -5, w: 2, h: 3, color: 0xcc8844, z: 3 },
            { face: 'front', x: 3, y: -5, w: 2, h: 3, color: 0x8844cc, z: 3 },
            { face: 'front', x: 0, y: -12, w: 8, h: 2, color: 0xcc4444, z: 4 },
            { face: 'front', x: 5, y: 2, w: 1, h: 3, color: 'coin', z: 3 },
            { face: 'front', x: 0, y: 10, w: 8, h: 4, color: 'hatch', z: 3 },
            { face: 'back', x: 0, y: 0, w: 12, h: 28, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 10, h: 26, color: 'body', z: 2 },
            { face: 'back', x: 0, y: 8, w: 6, h: 4, color: 0x2a2a2a, z: 3 },
            { face: 'back', x: 3, y: -8, w: 2, h: 12, color: 0x1a1a1a, alpha: 0.3, z: 3 },
            { face: 'side', x: 0, y: 0, w: 8, h: 28, color: 'body', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -14, w: 12, h: 3, color: 'body', shade: 'light', z: 6 }
        ]
    },
    
    // --- Filing Cabinet (Police, Office, School) ---
    filing_cabinet: {
        w: 12, h: 24, sideW: 8,
        colors: { metal: 0x555560, drawer: 0x3a3a40, handle: 0x888888, label: 0xccccaa },
        parts: [
            { face: 'front', x: 0, y: 0, w: 12, h: 24, color: 'metal', z: 1 },
            { face: 'front', x: 0, y: -8, w: 10, h: 6, color: 'drawer', z: 2 },
            { face: 'front', x: 0, y: 0, w: 10, h: 6, color: 'drawer', z: 2 },
            { face: 'front', x: 0, y: 8, w: 10, h: 6, color: 'drawer', z: 2 },
            { face: 'front', x: 3, y: -8, w: 3, h: 1, color: 'handle', z: 3 },
            { face: 'front', x: 3, y: 0, w: 3, h: 1, color: 'handle', z: 3 },
            { face: 'front', x: 3, y: 8, w: 3, h: 1, color: 'handle', z: 3 },
            { face: 'front', x: -2, y: -8, w: 3, h: 2, color: 'label', alpha: 0.5, z: 3 },
            { face: 'front', x: 0, y: 9, w: 10, h: 2, color: 'drawer', shade: 'light', z: 2, id: 'ajar' },
            { face: 'back', x: 0, y: 0, w: 12, h: 24, color: 'metal', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 10, h: 22, color: 'metal', z: 2 },
            { face: 'back', x: 0, y: 6, w: 6, h: 3, color: 'metal', shade: 'darker', z: 3 },
            { face: 'side', x: 0, y: 0, w: 8, h: 24, color: 'metal', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -12, w: 12, h: 3, color: 'metal', shade: 'light', z: 6 }
        ]
    },
    
    // --- Workbench (Hardware Store, Auto Shop, Bunker) ---
    workbench: {
        w: 28, h: 16, sideW: 12,
        colors: { wood: 0x5a4a35, metal: 0x4a4a4a, peg: 0x3a3a3a, vice: 0x888888 },
        parts: [
            { face: 'front', x: 0, y: 2, w: 28, h: 12, color: 'wood', z: 1 },
            { face: 'front', x: 0, y: -2, w: 28, h: 2, color: 'metal', z: 2 },
            { face: 'front', x: 0, y: -9, w: 26, h: 10, color: 'peg', z: 0 },
            { face: 'front', x: -6, y: -10, w: 2, h: 5, color: 0x2a2a2a, z: 1 },
            { face: 'front', x: -2, y: -8, w: 3, h: 3, color: 0x2a2a2a, z: 1 },
            { face: 'front', x: 3, y: -11, w: 1, h: 6, color: 0x2a2a2a, z: 1 },
            { face: 'front', x: 8, y: -9, w: 4, h: 3, color: 0x2a2a2a, z: 1 },
            { face: 'front', x: 12, y: 0, w: 4, h: 4, color: 'vice', z: 3 },
            { face: 'front', x: -10, y: 6, w: 3, h: 8, color: 'wood', shade: 'dark', z: 0 },
            { face: 'front', x: 10, y: 6, w: 3, h: 8, color: 'wood', shade: 'dark', z: 0 },
            { face: 'back', x: 0, y: 2, w: 28, h: 12, color: 'wood', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: -2, w: 28, h: 2, color: 'metal', shade: 'dark', z: 2 },
            { face: 'back', x: -10, y: 6, w: 3, h: 8, color: 'wood', shade: 'darker', z: 0 },
            { face: 'back', x: 10, y: 6, w: 3, h: 8, color: 'wood', shade: 'darker', z: 0 },
            { face: 'back', x: 0, y: 4, w: 14, h: 1, color: 'metal', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 2, w: 12, h: 12, color: 'wood', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -2, w: 10, h: 2, color: 'metal', z: 2 },
            { face: 'top', x: 0, y: -3, w: 28, h: 3, color: 'wood', shade: 'light', z: 6 }
        ]
    },
    
    // --- Chalkboard (School) ---
    chalkboard: {
        w: 30, h: 20, sideW: 3,
        colors: { frame: 0x5a4a35, board: 0x2a4a3a, chalk: 0xccccbb, tray: 0x4a3a2a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 30, h: 20, color: 'frame', z: 1 },
            { face: 'front', x: 0, y: 0, w: 28, h: 18, color: 'board', z: 2 },
            { face: 'front', x: -5, y: -3, w: 12, h: 1, color: 'chalk', alpha: 0.25, z: 3 },
            { face: 'front', x: 3, y: 1, w: 8, h: 1, color: 'chalk', alpha: 0.2, z: 3 },
            { face: 'front', x: -2, y: 5, w: 15, h: 1, color: 'chalk', alpha: 0.15, z: 3 },
            { face: 'front', x: 0, y: 9, w: 26, h: 2, color: 'tray', z: 4 },
            { face: 'front', x: -8, y: 9, w: 3, h: 1, color: 'chalk', z: 5 },
            { face: 'back', x: 0, y: 0, w: 30, h: 20, color: 'frame', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 28, h: 18, color: 'frame', z: 2 },
            { face: 'back', x: -8, y: 0, w: 2, h: 14, color: 'frame', shade: 'darker', z: 3 },
            { face: 'back', x: 8, y: 0, w: 2, h: 14, color: 'frame', shade: 'darker', z: 3 },
            { face: 'side', x: 0, y: 0, w: 3, h: 20, color: 'frame', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -10, w: 30, h: 2, color: 'frame', shade: 'light', z: 6 }
        ]
    },
    
    // --- Display Case (Grocery, Store) ---
    display_case: {
        w: 24, h: 14, sideW: 10,
        colors: { frame: 0x3a3a3a, glass: 0x4a5a6a, shelf: 0x555555 },
        parts: [
            { face: 'front', x: 0, y: 0, w: 24, h: 14, color: 'frame', z: 1 },
            { face: 'front', x: 0, y: 0, w: 22, h: 12, color: 'glass', alpha: 0.5, z: 2 },
            { face: 'front', x: 0, y: 0, w: 20, h: 1, color: 'shelf', z: 3 },
            { face: 'front', x: 3, y: 0, w: 18, h: 10, color: 0xffffff, alpha: 0.06, z: 4 },
            { face: 'back', x: 0, y: 0, w: 24, h: 14, color: 'frame', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 22, h: 12, color: 'frame', z: 2 },
            { face: 'back', x: 0, y: 0, w: 20, h: 1, color: 'shelf', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 0, w: 10, h: 14, color: 'frame', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -7, w: 24, h: 3, color: 'frame', shade: 'light', z: 6 }
        ],
        scatter: [
            { x: -6, y: -3, w: 3, h: 4, color: 0xcc8844 },
            { x: -2, y: -3, w: 2, h: 4, color: 0x88cc44 },
            { x: 2, y: -3, w: 3, h: 3, color: 0x8888cc },
            { x: -5, y: 3, w: 2, h: 3, color: 0xcc4444 },
            { x: 0, y: 3, w: 3, h: 3, color: 0x44cc88 },
            { x: 5, y: 3, w: 2, h: 4, color: 0xcccc44 }
        ]
    },
    
    // --- Bunk Bed (Bunker, Motel) ---
    bunk_bed: {
        w: 20, h: 30, sideW: 10,
        colors: { frame: 0x4a4a4a, blanketB: 0x4a5040, blanketT: 0x405060, pillow: 0xaaaaaa, ladder: 0x3a3a3a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 20, h: 30, color: 'frame', z: 0 },
            { face: 'front', x: 0, y: 8, w: 18, h: 10, color: 'blanketB', z: 1 },
            { face: 'front', x: -6, y: 5, w: 4, h: 3, color: 'pillow', z: 2 },
            { face: 'front', x: 0, y: -8, w: 18, h: 10, color: 'blanketT', z: 1 },
            { face: 'front', x: -6, y: -11, w: 4, h: 3, color: 'pillow', z: 2 },
            { face: 'front', x: 0, y: -1, w: 18, h: 2, color: 'frame', z: 3 },
            { face: 'front', x: 8, y: 0, w: 2, h: 28, color: 'ladder', z: 4 },
            { face: 'front', x: 8, y: -7, w: 4, h: 1, color: 'ladder', z: 5 },
            { face: 'front', x: 8, y: 1, w: 4, h: 1, color: 'ladder', z: 5 },
            { face: 'front', x: 8, y: 9, w: 4, h: 1, color: 'ladder', z: 5 },
            { face: 'back', x: 0, y: 0, w: 20, h: 30, color: 'frame', shade: 'dark', z: 0 },
            { face: 'back', x: 0, y: 0, w: 18, h: 28, color: 'frame', z: 1 },
            { face: 'back', x: 0, y: -1, w: 18, h: 2, color: 'frame', shade: 'light', z: 3 },
            { face: 'back', x: -6, y: -8, w: 8, h: 1, color: 'blanketT', shade: 'dark', alpha: 0.3, z: 2 },
            { face: 'back', x: -6, y: 8, w: 8, h: 1, color: 'blanketB', shade: 'dark', alpha: 0.3, z: 2 },
            { face: 'side', x: 0, y: 0, w: 10, h: 30, color: 'frame', shade: 'dark', z: 1 },
            { face: 'side', x: 3, y: 0, w: 2, h: 28, color: 'ladder', z: 3 },
            { face: 'top', x: 0, y: -15, w: 20, h: 3, color: 'frame', shade: 'light', z: 6 }
        ]
    },
    
    // --- Altar (Church) ---
    altar: {
        w: 24, h: 14, sideW: 10,
        colors: { wood: 0x4a3a2a, face: 0x5a4a3a, cloth: 0xccccaa, brass: 0x8a7a3a, candle: 0xffcc44 },
        parts: [
            { face: 'front', x: 0, y: 0, w: 24, h: 14, color: 'face', z: 1 },
            { face: 'front', x: 0, y: 0, w: 22, h: 12, color: 'wood', z: 1 },
            { face: 'front', x: 0, y: 0, w: 2, h: 6, color: 'brass', alpha: 0.6, z: 3 },
            { face: 'front', x: 0, y: 0, w: 6, h: 2, color: 'brass', alpha: 0.6, z: 3 },
            { face: 'front', x: 0, y: -5, w: 22, h: 2, color: 'cloth', z: 4 },
            { face: 'front', x: -4, y: -5, w: 2, h: 1, color: 'cloth', shade: 'dark', z: 5 },
            { face: 'front', x: 4, y: -5, w: 2, h: 1, color: 'cloth', shade: 'dark', z: 5 },
            { face: 'front', x: -10, y: -8, w: 1, h: 4, color: 'brass', z: 4 },
            { face: 'front', x: 10, y: -8, w: 1, h: 4, color: 'brass', z: 4 },
            { face: 'front', type: 'circle', x: -10, y: -10, r: 1.5, color: 'candle', alpha: 0.5, z: 5 },
            { face: 'front', type: 'circle', x: 10, y: -10, r: 1.5, color: 'candle', alpha: 0.5, z: 5 },
            { face: 'back', x: 0, y: 0, w: 24, h: 14, color: 'wood', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 22, h: 12, color: 'wood', z: 2 },
            { face: 'back', x: 0, y: -5, w: 20, h: 2, color: 'cloth', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 0, w: 10, h: 14, color: 'wood', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -7, w: 24, h: 3, color: 'cloth', z: 6 }
        ]
    },
    
    // ==================== VEHICLES ====================
    
    // --- Pickup Truck (player vehicle, wrecks) ---
    pickup_truck: {
        w: 58, h: 26, sideW: 16,
        colors: { body: 0x4a5040, dark: 0x3a4030, light: 0x5a6050, window: 0x2a3a4a, wheel: 0x1a1a1a, metal: 0x3a3a3a },
        parts: [
            // Chassis
            { face: 'any', type: 'ellipse', x: 0, y: 12, w: 54, h: 8, color: 0x000000, alpha: 0.35, z: -1 },
            // Wheels
            { face: 'front', type: 'ellipse', x: -16, y: 10, w: 8, h: 5, color: 'wheel', z: 0 },
            { face: 'front', type: 'ellipse', x: 16, y: 10, w: 8, h: 5, color: 'wheel', z: 0 },
            { face: 'front', type: 'ellipse', x: -16, y: 10, w: 4, h: 3, color: 'metal', z: 1 },
            { face: 'front', type: 'ellipse', x: 16, y: 10, w: 4, h: 3, color: 'metal', z: 1 },
            // Undercarriage
            { face: 'front', x: 0, y: 8, w: 44, h: 4, color: 0x1a1a1a, z: 1 },
            // Body lower
            { face: 'front', x: 0, y: 2, w: 48, h: 10, color: 'dark', z: 2 },
            // Body upper
            { face: 'front', x: 0, y: -2, w: 46, h: 6, color: 'body', z: 3 },
            // Hood
            { face: 'front', x: 20, y: 2, w: 10, h: 8, color: 'body', z: 3 },
            { face: 'front', x: 22, y: 0, w: 6, h: 4, color: 'light', z: 4 },
            // Bed
            { face: 'front', x: -20, y: 2, w: 10, h: 8, color: 'dark', z: 2 },
            // Cabin roof
            { face: 'front', x: 2, y: -8, w: 24, h: 6, color: 'dark', z: 4 },
            { face: 'front', x: 2, y: -11, w: 22, h: 4, color: 'body', z: 5 },
            { face: 'front', x: 2, y: -13, w: 20, h: 2, color: 'light', z: 6 },
            // Windshield
            { face: 'front', x: 8, y: -5, w: 8, h: 8, color: 'window', z: 5 },
            // Side window
            { face: 'front', x: -4, y: -6, w: 10, h: 6, color: 'window', z: 5 },
            // Headlights
            { face: 'front', x: 24, y: 1, w: 2, h: 3, color: 0xffffaa, z: 6 },
            // Taillights
            { face: 'front', x: -24, y: 1, w: 2, h: 3, color: 0xaa2222, z: 6 },
            // Side face
            { face: 'back', x: 0, y: 2, w: 48, h: 10, color: 'dark', z: 2 },
            { face: 'back', x: 0, y: -2, w: 46, h: 6, color: 'body', shade: 'dark', z: 3 },
            { face: 'back', x: 0, y: -8, w: 24, h: 6, color: 'dark', shade: 'dark', z: 4 },
            { face: 'back', x: -16, y: 10, w: 8, h: 5, color: 'wheel', z: 0 },
            { face: 'back', x: 16, y: 10, w: 8, h: 5, color: 'wheel', z: 0 },
            { face: 'back', x: -20, y: 1, w: 2, h: 3, color: 0xaa2222, z: 6 },
            { face: 'back', x: 20, y: 1, w: 2, h: 3, color: 0xaa2222, z: 6 },
            { face: 'back', x: 0, y: 6, w: 12, h: 3, color: 0x2a2a2a, z: 4 },
            { face: 'side', x: 0, y: 2, w: 14, h: 16, color: 'dark', z: 2 },
            { face: 'side', x: 0, y: -8, w: 12, h: 8, color: 'body', z: 4 },
            { face: 'top', x: 0, y: -11, w: 24, h: 3, color: 'light', z: 7 }
        ],
        variants: {
            wrecked: {
                recolor: { body: 0x3a3530, dark: 0x2a2520, light: 0x4a4540 },
                addParts: [
                    { face: 'front', x: 5, y: -2, w: 8, h: 1, color: 0x5a3a2a, alpha: 0.4, z: 7 },
                    { face: 'front', x: -10, y: 4, w: 6, h: 2, color: 0x4a3a2a, alpha: 0.3, z: 7 }
                ]
            },
            military: {
                recolor: { body: 0x3a4030, dark: 0x2a3020, light: 0x4a5040 },
                addParts: [
                    { face: 'front', x: -18, y: -6, w: 2, h: 10, color: 0x3a3a3a, z: 8 },
                    { face: 'front', x: -14, y: -10, w: 10, h: 2, color: 0x3a3a3a, z: 8 }
                ]
            }
        }
    },
    
    // --- Sedan (parked cars, wrecks) ---
    sedan: {
        w: 52, h: 22, sideW: 14,
        colors: { body: 0x4a4a55, dark: 0x3a3a45, light: 0x5a5a65, window: 0x2a3a4a, wheel: 0x1a1a1a },
        parts: [
            { face: 'any', type: 'ellipse', x: 0, y: 10, w: 44, h: 7, color: 0x000000, alpha: 0.3, z: -1 },
            { face: 'front', type: 'ellipse', x: -12, y: 8, w: 6, h: 4, color: 'wheel', z: 0 },
            { face: 'front', type: 'ellipse', x: 12, y: 8, w: 6, h: 4, color: 'wheel', z: 0 },
            { face: 'front', x: 0, y: 6, w: 36, h: 3, color: 0x1a1a1a, z: 1 },
            { face: 'front', x: 0, y: 2, w: 38, h: 8, color: 'dark', z: 2 },
            { face: 'front', x: 0, y: -1, w: 36, h: 5, color: 'body', z: 3 },
            { face: 'front', x: 16, y: 1, w: 8, h: 6, color: 'body', z: 3 },
            { face: 'front', x: -16, y: 1, w: 8, h: 6, color: 'dark', z: 2 },
            { face: 'front', x: 0, y: -6, w: 20, h: 5, color: 'dark', z: 4 },
            { face: 'front', x: 0, y: -9, w: 18, h: 3, color: 'body', z: 5 },
            { face: 'front', x: 0, y: -11, w: 16, h: 2, color: 'light', z: 6 },
            { face: 'front', x: 5, y: -4, w: 7, h: 6, color: 'window', z: 5 },
            { face: 'front', x: -4, y: -5, w: 8, h: 5, color: 'window', z: 5 },
            { face: 'front', x: 18, y: 0, w: 2, h: 3, color: 0xffffaa, z: 6 },
            { face: 'front', x: -18, y: 0, w: 2, h: 3, color: 0xaa2222, z: 6 },
            { face: 'back', x: 0, y: 2, w: 38, h: 8, color: 'dark', z: 2 },
            { face: 'back', x: 0, y: -1, w: 36, h: 5, color: 'body', shade: 'dark', z: 3 },
            { face: 'back', x: 0, y: -6, w: 20, h: 5, color: 'dark', shade: 'dark', z: 4 },
            { face: 'back', x: -12, y: 8, w: 6, h: 4, color: 'wheel', z: 0 },
            { face: 'back', x: 12, y: 8, w: 6, h: 4, color: 'wheel', z: 0 },
            { face: 'back', x: -14, y: 0, w: 3, h: 3, color: 0xaa2222, z: 6 },
            { face: 'back', x: 14, y: 0, w: 3, h: 3, color: 0xaa2222, z: 6 },
            { face: 'back', x: 0, y: 5, w: 8, h: 2, color: 0x2a2a2a, z: 4 },
            { face: 'side', x: 0, y: 1, w: 12, h: 12, color: 'dark', z: 2 },
            { face: 'top', x: 0, y: -9, w: 20, h: 3, color: 'light', z: 7 }
        ],
        variants: {
            wrecked: {
                recolor: { body: 0x3a3a40, dark: 0x2a2a30, light: 0x4a4a50 },
                addParts: [
                    { face: 'front', x: 4, y: -3, w: 6, h: 5, color: 0x1a1a1a, alpha: 0.3, z: 6, id: 'broken_window' },
                    { face: 'front', x: -8, y: 2, w: 5, h: 2, color: 0x4a3a2a, alpha: 0.3, z: 7 }
                ]
            }
        }
    },
    
    // ==================== MAP BUILDINGS (small scale) ====================
    
    // --- Hospital (landmark) ---
    hospital: {
        w: 36, h: 28, sideW: 10,
        colors: { wall: 0x404548, wallD: 0x354043, roof: 0x555560, cross: 0xcc3333 },
        parts: [
            { face: 'front', x: 0, y: 0, w: 36, h: 24, color: 'wall', z: 1 },
            { face: 'front', x: 0, y: 0, w: 2, h: 8, color: 'cross', z: 3 },
            { face: 'front', x: 0, y: 0, w: 8, h: 2, color: 'cross', z: 3 },
            { face: 'front', x: -10, y: 2, w: 4, h: 5, color: 0x2a3a4a, z: 2 },
            { face: 'front', x: -4, y: 2, w: 4, h: 5, color: 0x2a3a4a, z: 2 },
            { face: 'front', x: 10, y: 2, w: 4, h: 5, color: 0x2a3a4a, z: 2 },
            { face: 'front', x: 0, y: 8, w: 6, h: 6, color: 0x1a1a1a, z: 2 },
            { face: 'back', x: 0, y: 0, w: 36, h: 24, color: 'wallD', z: 1 },
            { face: 'back', x: 0, y: 0, w: 34, h: 22, color: 'wall', shade: 'dark', z: 2 },
            { face: 'back', x: -8, y: 2, w: 4, h: 5, color: 0x2a3a4a, shade: 'dark', z: 2 },
            { face: 'back', x: 8, y: 2, w: 4, h: 5, color: 0x2a3a4a, shade: 'dark', z: 2 },
            { face: 'side', x: 0, y: 0, w: 10, h: 24, color: 'wallD', z: 1 },
            { face: 'top', x: 0, y: -12, w: 36, h: 6, color: 'roof', z: 6 },
            { face: 'top', type: 'circle', x: 5, y: -10, r: 2, color: 'cross', alpha: 0.5, z: 7 }
        ]
    },
    
    // --- Water Tower (barren landmark) ---
    water_tower: {
        w: 16, h: 30, sideW: 6,
        colors: { tank: 0x5a5a5a, rust: 0x4a3a2a, legs: 0x3a3a3a, ladder: 0x4a4a4a },
        parts: [
            { face: 'front', type: 'ellipse', x: 0, y: -8, w: 16, h: 12, color: 'tank', z: 2 },
            { face: 'front', type: 'ellipse', x: 0, y: -12, w: 14, h: 4, color: 'tank', shade: 'light', z: 3 },
            { face: 'front', x: 3, y: -6, w: 4, h: 3, color: 'rust', alpha: 0.4, z: 3 },
            { face: 'front', x: -4, y: -4, w: 3, h: 2, color: 'rust', alpha: 0.3, z: 3 },
            { face: 'front', x: -5, y: 4, w: 2, h: 16, color: 'legs', z: 1 },
            { face: 'front', x: 5, y: 4, w: 2, h: 16, color: 'legs', z: 1 },
            { face: 'front', x: 0, y: 4, w: 2, h: 14, color: 'legs', z: 1 },
            { face: 'front', x: 7, y: -2, w: 1, h: 18, color: 'ladder', z: 2 },
            { face: 'front', x: 7, y: -6, w: 2, h: 1, color: 'ladder', z: 3 },
            { face: 'front', x: 7, y: 2, w: 2, h: 1, color: 'ladder', z: 3 },
            { face: 'front', x: 7, y: 8, w: 2, h: 1, color: 'ladder', z: 3 },
            { face: 'back', type: 'ellipse', x: 0, y: -8, w: 16, h: 12, color: 'tank', shade: 'dark', z: 2 },
            { face: 'back', x: -5, y: 4, w: 2, h: 16, color: 'legs', shade: 'dark', z: 1 },
            { face: 'back', x: 5, y: 4, w: 2, h: 16, color: 'legs', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 4, w: 2, h: 14, color: 'legs', shade: 'dark', z: 1 },
            { face: 'side', type: 'ellipse', x: 0, y: -8, w: 6, h: 12, color: 'tank', shade: 'dark', z: 2 },
            { face: 'top', type: 'ellipse', x: 0, y: -14, w: 14, h: 6, color: 'tank', shade: 'lighter', z: 6 }
        ]
    },
    
    // --- Radio Tower (apocalyptic landmark) ---
    radio_tower: {
        w: 10, h: 36, sideW: 4,
        colors: { steel: 0x5a5a5a, wire: 0x3a3a3a, beacon: 0xff2222 },
        parts: [
            { face: 'front', x: -3, y: 4, w: 1, h: 28, color: 'steel', z: 1 },
            { face: 'front', x: 3, y: 4, w: 1, h: 28, color: 'steel', z: 1 },
            { face: 'front', x: 0, y: -12, w: 1, h: 6, color: 'steel', z: 2 },
            { face: 'front', x: 0, y: -4, w: 5, h: 1, color: 'steel', z: 2 },
            { face: 'front', x: 0, y: 4, w: 4, h: 1, color: 'steel', z: 2 },
            { face: 'front', x: 0, y: 12, w: 3, h: 1, color: 'steel', z: 2 },
            { face: 'front', x: -2, y: 0, w: 4, h: 20, color: 'steel', alpha: 0.15, z: 0 },
            { face: 'front', type: 'circle', x: 0, y: -15, r: 2, color: 'beacon', alpha: 0.7, z: 5 },
            { face: 'front', type: 'circle', x: 0, y: -15, r: 4, color: 'beacon', alpha: 0.15, z: 4 },
            { face: 'front', x: -6, y: 16, w: 8, h: 1, color: 'wire', alpha: 0.4, z: 0, angle: 30 },
            { face: 'front', x: 6, y: 16, w: 8, h: 1, color: 'wire', alpha: 0.4, z: 0, angle: -30 },
            { face: 'back', x: -3, y: 4, w: 1, h: 28, color: 'steel', shade: 'dark', z: 1 },
            { face: 'back', x: 3, y: 4, w: 1, h: 28, color: 'steel', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 4, w: 4, h: 1, color: 'steel', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: 12, w: 3, h: 1, color: 'steel', shade: 'dark', z: 2 },
            { face: 'side', x: 0, y: 4, w: 4, h: 28, color: 'steel', shade: 'dark', alpha: 0.5, z: 1 }
        ]
    },
    
    // ==================== PORTED HAND-DRAWN FURNITURE ====================
    
    // --- Register (counter cash register) ---
    register: {
        w: 22, h: 16, sideW: 10,
        colors: { body: 0x3a3a3a, screen: 0x1a1a2a, screenGlow: 0x2a3a2a, drawer: 0x333333, keypad: 0x5a5a5a, knob: 0x8a7a3a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 22, h: 14, color: 'body' },
            { face: 'front', x: 0, y: 0, w: 20, h: 12, color: 'body', shade: 'light' },
            { face: 'top', x: 0, y: -8, w: 22, h: 4, color: 'body', shade: 'lighter' },
            { face: 'front', x: 0, y: 3, w: 18, h: 5, color: 'drawer' },
            { face: 'front', x: 0, y: 1, w: 6, h: 1, color: 'keypad' },
            { face: 'front', type: 'circle', x: -4, y: 3, r: 2, color: 'knob' },
            { face: 'front', x: -4, y: -10, w: 10, h: 6, color: 'screen' },
            { face: 'front', x: -4, y: -10, w: 8, h: 4, color: 'screenGlow' },
            { face: 'front', x: 4, y: -8, w: 2, h: 1, color: 'keypad', z: 1 },
            { face: 'front', x: 4, y: -6, w: 2, h: 1, color: 'keypad', z: 1 },
            { face: 'front', x: 7, y: -8, w: 2, h: 1, color: 'keypad', z: 1 },
            { face: 'front', x: 7, y: -6, w: 2, h: 1, color: 'keypad', z: 1 },
            { face: 'back', x: 0, y: 0, w: 22, h: 14, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 20, h: 12, color: 'body', z: 2 },
            { face: 'back', x: 0, y: -4, w: 8, h: 3, color: 0x2a2a2a, z: 3 },
            { face: 'side', x: 0, y: 0, w: 10, h: 14, color: 'body', shade: 'dark' },
            { face: 'side', x: 0, y: -8, w: 10, h: 4, color: 'body' },
            { face: 'side', x: 3, y: -10, w: 4, h: 5, color: 'screen' }
        ]
    },
    
    // --- Fridge (tall upright) ---
    fridge: {
        w: 20, h: 36, sideW: 10,
        colors: { body: 0x8a9aaa, handle: 0x6a6a6a, vent: 0x7a8a9a, dispenser: 0x7a8a9a, magnet: 0x9a5a5a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 20, h: 36, color: 'body' },
            { face: 'front', x: 0, y: 0, w: 18, h: 34, color: 'body', shade: 'light' },
            { face: 'top', x: 0, y: -19, w: 20, h: 4, color: 'body', shade: 'lighter' },
            { face: 'front', x: 0, y: -8, w: 18, h: 1, color: 'body', shade: 'dark' },
            { face: 'front', x: 7, y: -13, w: 2, h: 6, color: 'handle' },
            { face: 'front', x: 7, y: 4, w: 2, h: 8, color: 'handle' },
            { face: 'front', x: -3, y: -4, w: 8, h: 5, color: 'dispenser', shade: 'dark' },
            { face: 'front', x: -5, y: -2, w: 3, h: 3, color: 'magnet', alpha: 0.5 },
            { face: 'front', x: -2, y: -16, w: 6, h: 2, color: 'body', shade: 'dark' },
            { face: 'back', x: 0, y: 0, w: 20, h: 36, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 18, h: 34, color: 'body', z: 2 },
            { face: 'back', x: 0, y: 10, w: 14, h: 6, color: 'body', shade: 'darker', z: 3 },
            { face: 'back', x: 3, y: -6, w: 1, h: 16, color: 0x2a2a2a, alpha: 0.3, z: 3 },
            { face: 'back', x: -3, y: 12, w: 3, h: 3, color: 0x2a2a2a, z: 4 },
            { face: 'side', x: 0, y: 0, w: 10, h: 36, color: 'body', shade: 'dark' },
            { face: 'side', x: 0, y: -19, w: 10, h: 4, color: 'body' }
        ]
    },
    
    // --- Shelf (wall-mounted shelving unit) ---
    shelf: {
        w: 24, h: 30, sideW: 8,
        colors: { frame: 0x5a4a3a, shelf: 0x6a5a4a, bracket: 0x4a4a4a, items: 0x5a6a5a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 24, h: 30, color: 'frame' },
            { face: 'front', x: 0, y: 0, w: 22, h: 28, color: 'frame', shade: 'light' },
            { face: 'front', x: 0, y: -8, w: 22, h: 2, color: 'shelf' },
            { face: 'front', x: 0, y: 4, w: 22, h: 2, color: 'shelf' },
            { face: 'front', x: 0, y: 14, w: 22, h: 2, color: 'shelf' },
            { face: 'top', x: 0, y: -16, w: 24, h: 3, color: 'frame', shade: 'lighter' },
            { face: 'front', x: -6, y: -4, w: 4, h: 6, color: 'items' },
            { face: 'front', x: 2, y: -3, w: 3, h: 5, color: 0x6a5a4a },
            { face: 'front', x: 7, y: -5, w: 5, h: 4, color: 0x4a5a6a },
            { face: 'front', x: -4, y: 8, w: 6, h: 5, color: 0x7a6a5a },
            { face: 'front', x: 5, y: 9, w: 4, h: 4, color: 0x5a5a6a },
            { face: 'back', x: 0, y: 0, w: 24, h: 30, color: 'frame', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 22, h: 28, color: 'frame', z: 2 },
            { face: 'back', x: -8, y: -4, w: 4, h: 2, color: 'bracket', z: 3 },
            { face: 'back', x: 8, y: -4, w: 4, h: 2, color: 'bracket', z: 3 },
            { face: 'back', x: -8, y: 8, w: 4, h: 2, color: 'bracket', z: 3 },
            { face: 'back', x: 8, y: 8, w: 4, h: 2, color: 'bracket', z: 3 },
            { face: 'side', x: 0, y: 0, w: 8, h: 30, color: 'frame', shade: 'dark' },
            { face: 'side', x: 3, y: -8, w: 5, h: 2, color: 'shelf' },
            { face: 'side', x: 3, y: 4, w: 5, h: 2, color: 'shelf' }
        ]
    },
    
    // --- Crate (wooden supply crate) ---
    crate: {
        w: 20, h: 16, sideW: 10,
        colors: { wood: 0x5a4830, plank: 0x6a5840, band: 0x4a4a4a, nail: 0x6a6a6a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 20, h: 14, color: 'wood' },
            { face: 'front', x: 0, y: 0, w: 18, h: 12, color: 'plank' },
            { face: 'front', x: 0, y: -2, w: 20, h: 2, color: 'band' },
            { face: 'front', x: 0, y: 4, w: 20, h: 2, color: 'band' },
            { face: 'front', x: -8, y: 0, w: 1, h: 14, color: 'wood', shade: 'dark' },
            { face: 'front', x: 8, y: 0, w: 1, h: 14, color: 'wood', shade: 'dark' },
            { face: 'front', type: 'circle', x: -8, y: -2, r: 1, color: 'nail' },
            { face: 'front', type: 'circle', x: 8, y: -2, r: 1, color: 'nail' },
            { face: 'top', x: 0, y: -8, w: 20, h: 4, color: 'plank', shade: 'lighter' },
            { face: 'top', x: 0, y: -8, w: 18, h: 2, color: 'wood' },
            { face: 'back', x: 0, y: 0, w: 20, h: 14, color: 'wood', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 18, h: 12, color: 'plank', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: -2, w: 20, h: 2, color: 'band', shade: 'dark', z: 3 },
            { face: 'back', x: 0, y: 4, w: 20, h: 2, color: 'band', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 0, w: 10, h: 14, color: 'wood', shade: 'dark' },
            { face: 'side', x: 0, y: -2, w: 10, h: 2, color: 'band' }
        ]
    },
    
    // --- Desk (office/work desk) ---
    desk: {
        w: 32, h: 18, sideW: 12,
        colors: { top: 0x5a4a3a, body: 0x4a3a2a, drawer: 0x3a2a1a, handle: 0x6a6a6a, legs: 0x3a3530 },
        parts: [
            { face: 'front', x: 0, y: -4, w: 32, h: 4, color: 'top' },
            { face: 'front', x: 0, y: -4, w: 30, h: 2, color: 'top', shade: 'light' },
            { face: 'front', x: 0, y: 3, w: 30, h: 10, color: 'body' },
            { face: 'front', x: -6, y: 2, w: 12, h: 6, color: 'drawer' },
            { face: 'front', x: -6, y: 2, w: 6, h: 1, color: 'handle' },
            { face: 'front', x: 6, y: 2, w: 12, h: 6, color: 'drawer', shade: 'dark' },
            { face: 'front', x: 6, y: 2, w: 6, h: 1, color: 'handle' },
            { face: 'top', x: 0, y: -7, w: 32, h: 3, color: 'top', shade: 'lighter' },
            { face: 'front', x: -14, y: 8, w: 3, h: 8, color: 'legs' },
            { face: 'front', x: 14, y: 8, w: 3, h: 8, color: 'legs' },
            { face: 'back', x: 0, y: -4, w: 32, h: 4, color: 'top', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 3, w: 30, h: 10, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: -14, y: 8, w: 3, h: 8, color: 'legs', shade: 'dark', z: 0 },
            { face: 'back', x: 14, y: 8, w: 3, h: 8, color: 'legs', shade: 'dark', z: 0 },
            { face: 'back', x: 0, y: 6, w: 16, h: 1, color: 'body', shade: 'darker', z: 2 },
            { face: 'side', x: 0, y: -4, w: 12, h: 4, color: 'top', shade: 'dark' },
            { face: 'side', x: 0, y: 3, w: 10, h: 10, color: 'body', shade: 'dark' },
            { face: 'side', x: 0, y: 8, w: 2, h: 8, color: 'legs' }
        ]
    },
    
    // --- Nightstand (bedside table) ---
    nightstand: {
        w: 14, h: 14, sideW: 8,
        colors: { body: 0x5a4a3a, top: 0x6a5a4a, drawer: 0x4a3a2a, handle: 0x7a7a6a, lamp: 0xaaaa88, shelf: 0x3a2a1a, feet: 0x3a2a1a, ring: 0x888868 },
        parts: [
            // Front — frame, drawer, shelf opening
            { face: 'front', x: 0, y: 0, w: 14, h: 12, color: 'body', z: 1 },
            { face: 'front', x: 0, y: 0, w: 12, h: 10, color: 'body', shade: 'light', z: 2 },
            // Top drawer
            { face: 'front', x: 0, y: -2, w: 10, h: 4, color: 'drawer', z: 3 },
            { face: 'front', x: 0, y: -2, w: 8, h: 2, color: 'drawer', shade: 'light', z: 4 },
            { face: 'front', x: 0, y: -2, w: 3, h: 1, color: 'handle', z: 5 },
            // Open shelf below
            { face: 'front', x: 0, y: 4, w: 10, h: 4, color: 'shelf', z: 2 },
            { face: 'front', x: 0, y: 4, w: 8, h: 2, color: 'shelf', shade: 'dark', z: 3 },
            // Feet
            { face: 'front', x: -5, y: 7, w: 2, h: 2, color: 'feet', z: 0 },
            { face: 'front', x: 5, y: 7, w: 2, h: 2, color: 'feet', z: 0 },
            // Top surface with lamp base
            { face: 'top', x: 0, y: -7, w: 14, h: 3, color: 'top', z: 6 },
            { face: 'top', x: -3, y: -8, w: 4, h: 2, color: 'lamp', alpha: 0.4, z: 7 },
            { face: 'top', type: 'circle', x: -3, y: -8, r: 1, color: 'ring', z: 8 },
            // Back
            { face: 'back', x: 0, y: 0, w: 14, h: 12, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 12, h: 10, color: 'body', z: 2 },
            { face: 'back', x: 0, y: 3, w: 8, h: 2, color: 'body', shade: 'darker', z: 3 },
            // Side — drawer line, shelf edge
            { face: 'side', x: 0, y: 0, w: 8, h: 12, color: 'body', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -2, w: 6, h: 1, color: 'drawer', shade: 'dark', z: 2 },
            { face: 'side', x: 0, y: 4, w: 6, h: 1, color: 'shelf', shade: 'dark', z: 2 },
            { face: 'side', x: 0, y: -7, w: 8, h: 3, color: 'top', shade: 'dark', z: 3 }
        ]
    },
    
    // --- Dresser (wide bedroom storage) ---
    dresser: {
        w: 28, h: 20, sideW: 10,
        colors: { body: 0x5a4a3a, top: 0x6a5a4a, drawer: 0x4a3a2a, handle: 0x6a6a5a, divider: 0x3a2a1a, trim: 0x5a4a38, feet: 0x3a2a1a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 28, h: 18, color: 'body', z: 1 },
            { face: 'front', x: 0, y: 0, w: 26, h: 16, color: 'body', shade: 'light', z: 2 },
            { face: 'front', x: 0, y: -5, w: 24, h: 5, color: 'drawer', z: 3 },
            { face: 'front', x: 0, y: -5, w: 22, h: 3, color: 'drawer', shade: 'light', z: 4 },
            { face: 'front', x: -5, y: -5, w: 2, h: 1, color: 'handle', z: 5 },
            { face: 'front', x: 5, y: -5, w: 2, h: 1, color: 'handle', z: 5 },
            { face: 'front', x: 0, y: -2, w: 24, h: 1, color: 'divider', alpha: 0.3, z: 4 },
            { face: 'front', x: 0, y: 3, w: 24, h: 5, color: 'drawer', shade: 'dark', z: 3 },
            { face: 'front', x: 0, y: 3, w: 22, h: 3, color: 'drawer', z: 4 },
            { face: 'front', x: -5, y: 3, w: 2, h: 1, color: 'handle', z: 5 },
            { face: 'front', x: 5, y: 3, w: 2, h: 1, color: 'handle', z: 5 },
            { face: 'front', x: 0, y: 8, w: 26, h: 2, color: 'trim', z: 2 },
            { face: 'front', x: -12, y: 10, w: 3, h: 2, color: 'feet', z: 0 },
            { face: 'front', x: 12, y: 10, w: 3, h: 2, color: 'feet', z: 0 },
            { face: 'top', x: 0, y: -10, w: 28, h: 3, color: 'top', z: 6 },
            { face: 'top', x: 0, y: -10, w: 26, h: 2, color: 'top', shade: 'light', z: 7 },
            { face: 'back', x: 0, y: 0, w: 28, h: 18, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 26, h: 16, color: 'body', z: 2 },
            { face: 'back', x: 0, y: 4, w: 14, h: 2, color: 'body', shade: 'darker', z: 3 },
            { face: 'back', x: -8, y: -4, w: 6, h: 2, color: 'body', shade: 'darker', z: 3 },
            { face: 'side', x: 0, y: 0, w: 10, h: 18, color: 'body', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -5, w: 8, h: 1, color: 'divider', alpha: 0.2, z: 2 },
            { face: 'side', x: 0, y: -2, w: 8, h: 1, color: 'divider', alpha: 0.2, z: 2 },
            { face: 'side', x: 0, y: 3, w: 8, h: 1, color: 'divider', alpha: 0.2, z: 2 },
            { face: 'side', x: 0, y: -10, w: 10, h: 3, color: 'top', shade: 'dark', z: 3 }
        ]
    },
    
    // --- Barrel (metal/oil drum) ---
    barrel: {
        w: 12, h: 16, sideW: 8,
        colors: { body: 0x4a5a4a, band: 0x3a3a3a, lid: 0x5a6a5a, rust: 0x6a4a3a, stave: 0x3a4a3a, bung: 0x555555, drip: 0x2a3a2a },
        parts: [
            // Front face — cylindrical barrel front
            { face: 'front', x: 0, y: 0, w: 12, h: 14, color: 'body', z: 1 },
            { face: 'front', x: 0, y: 0, w: 10, h: 12, color: 'body', shade: 'light', z: 2 },
            // Stave lines (vertical seams)
            { face: 'front', x: -3, y: 0, w: 1, h: 12, color: 'stave', alpha: 0.15, z: 3 },
            { face: 'front', x: 3, y: 0, w: 1, h: 12, color: 'stave', alpha: 0.15, z: 3 },
            // Metal bands
            { face: 'front', x: 0, y: -5, w: 12, h: 2, color: 'band', z: 4 },
            { face: 'front', x: 0, y: 0, w: 12, h: 1, color: 'band', alpha: 0.5, z: 4 },
            { face: 'front', x: 0, y: 5, w: 12, h: 2, color: 'band', z: 4 },
            // Bung hole (access port)
            { face: 'front', x: 2, y: -1, w: 3, h: 2, color: 'bung', z: 5 },
            { face: 'front', x: 2, y: -1, w: 2, h: 1, color: 'bung', shade: 'dark', z: 6 },
            // Rust/drip stain
            { face: 'front', x: -3, y: 2, w: 3, h: 4, color: 'rust', alpha: 0.3, showAt: 0.2, z: 3 },
            { face: 'front', x: 2, y: 1, w: 2, h: 5, color: 'drip', alpha: 0.2, z: 3 },
            // Top — elliptical lid
            { face: 'top', type: 'ellipse', x: 0, y: -8, w: 12, h: 5, color: 'lid', z: 7 },
            { face: 'top', type: 'ellipse', x: 0, y: -8, w: 8, h: 3, color: 'lid', shade: 'light', z: 8 },
            { face: 'top', type: 'circle', x: 2, y: -8, r: 2, color: 'band', z: 9 },
            // Back
            { face: 'back', x: 0, y: 0, w: 12, h: 14, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: -5, w: 12, h: 2, color: 'band', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: 5, w: 12, h: 2, color: 'band', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: 0, w: 10, h: 10, color: 'body', z: 3 },
            // Side — depth panel with band edges
            { face: 'side', x: 0, y: 0, w: 8, h: 14, color: 'body', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -5, w: 8, h: 2, color: 'band', z: 2 },
            { face: 'side', x: 0, y: 5, w: 8, h: 2, color: 'band', z: 2 },
            { face: 'side', x: 0, y: 0, w: 6, h: 10, color: 'body', z: 3 }
        ]
    },
    
    // --- Locker (tall metal locker) ---
    locker: {
        w: 16, h: 30, sideW: 8,
        colors: { body: 0x5a6a6a, door: 0x6a7a7a, vent: 0x4a5a5a, handle: 0x7a7a7a, label: 0xaaaa88 },
        parts: [
            { face: 'front', x: 0, y: 0, w: 16, h: 28, color: 'body' },
            { face: 'front', x: -4, y: 0, w: 7, h: 26, color: 'door' },
            { face: 'front', x: 4, y: 0, w: 7, h: 26, color: 'door', shade: 'dark' },
            { face: 'front', x: 0, y: 0, w: 1, h: 26, color: 'body', shade: 'dark' },
            { face: 'front', x: -2, y: -6, w: 2, h: 4, color: 'handle' },
            { face: 'front', x: 2, y: -6, w: 2, h: 4, color: 'handle' },
            { face: 'front', x: -4, y: -12, w: 5, h: 2, color: 'label' },
            { face: 'front', x: -4, y: 10, w: 5, h: 4, color: 'vent' },
            { face: 'front', x: 4, y: 10, w: 5, h: 4, color: 'vent' },
            { face: 'top', x: 0, y: -15, w: 16, h: 3, color: 'body', shade: 'lighter' },
            { face: 'back', x: 0, y: 0, w: 16, h: 28, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 14, h: 26, color: 'body', z: 2 },
            { face: 'back', x: 0, y: 10, w: 10, h: 4, color: 'vent', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 0, w: 8, h: 28, color: 'body', shade: 'dark' },
            { face: 'side', x: 0, y: -15, w: 8, h: 3, color: 'body' }
        ]
    },
    
    // --- Table (simple flat table) ---
    table: {
        w: 28, h: 16, sideW: 10,
        colors: { top: 0x5a4a3a, legs: 0x4a3a2a, edge: 0x6a5a4a, apron: 0x4a3a28, grain: 0x5a4a32, shadow: 0x3a2a1a },
        parts: [
            // Front face — tabletop visible head-on
            { face: 'front', x: 0, y: -3, w: 28, h: 5, color: 'top', z: 2 },
            { face: 'front', x: 0, y: -4, w: 26, h: 2, color: 'top', shade: 'light', z: 3 },
            { face: 'front', x: 0, y: -2, w: 26, h: 1, color: 'edge', shade: 'dark', z: 3 },
            // Wood grain lines on top surface
            { face: 'front', x: -5, y: -4, w: 14, h: 1, color: 'grain', alpha: 0.15, z: 4 },
            { face: 'front', x: 4, y: -3, w: 10, h: 1, color: 'grain', alpha: 0.1, z: 4 },
            // Apron (support rail under tabletop)
            { face: 'front', x: 0, y: 1, w: 24, h: 3, color: 'apron', z: 1 },
            { face: 'front', x: 0, y: 1, w: 22, h: 1, color: 'apron', shade: 'light', z: 2 },
            // Legs with taper
            { face: 'front', x: -11, y: 6, w: 3, h: 8, color: 'legs', z: 0 },
            { face: 'front', x: 11, y: 6, w: 3, h: 8, color: 'legs', z: 0 },
            { face: 'front', x: -11, y: 10, w: 2, h: 2, color: 'legs', shade: 'dark', z: 0 },
            { face: 'front', x: 11, y: 10, w: 2, h: 2, color: 'legs', shade: 'dark', z: 0 },
            // Cross-stretcher between legs
            { face: 'front', x: 0, y: 7, w: 20, h: 1, color: 'apron', shade: 'dark', z: 0 },
            // Floor shadow under tabletop
            { face: 'front', x: 0, y: 3, w: 22, h: 1, color: 'shadow', alpha: 0.15, z: -1 },
            // Top foreshortened strip
            { face: 'top', x: 0, y: -6, w: 28, h: 3, color: 'edge', z: 5 },
            { face: 'top', x: -6, y: -6, w: 10, h: 1, color: 'grain', alpha: 0.1, z: 6 },
            // Back face
            { face: 'back', x: 0, y: -3, w: 28, h: 5, color: 'top', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: 1, w: 24, h: 3, color: 'apron', shade: 'dark', z: 1 },
            { face: 'back', x: -11, y: 6, w: 3, h: 8, color: 'legs', shade: 'dark', z: 0 },
            { face: 'back', x: 11, y: 6, w: 3, h: 8, color: 'legs', shade: 'dark', z: 0 },
            { face: 'back', x: 0, y: 0, w: 22, h: 1, color: 'apron', shade: 'darker', z: 1 },
            // Side face — see apron depth, two legs, stretcher
            { face: 'side', x: 0, y: -3, w: 10, h: 5, color: 'top', shade: 'dark', z: 2 },
            { face: 'side', x: 0, y: 1, w: 8, h: 3, color: 'apron', shade: 'dark', z: 1 },
            { face: 'side', x: -3, y: 6, w: 2, h: 8, color: 'legs', z: 0 },
            { face: 'side', x: 3, y: 6, w: 2, h: 8, color: 'legs', shade: 'dark', z: 0 },
            { face: 'side', x: 0, y: 7, w: 6, h: 1, color: 'apron', shade: 'darker', z: 0 }
        ]
    },
    
    // --- Toolrack (wall pegboard with tools) ---
    toolrack: {
        w: 22, h: 26, sideW: 6,
        colors: { board: 0x5a5a50, peg: 0x4a4a4a, hammer: 0x6a5a4a, wrench: 0x7a7a7a, saw: 0x8a8a7a },
        parts: [
            { face: 'front', x: 0, y: 0, w: 22, h: 24, color: 'board' },
            { face: 'front', x: 0, y: 0, w: 20, h: 22, color: 'board', shade: 'light' },
            { face: 'front', x: -6, y: -6, w: 2, h: 10, color: 'hammer' },
            { face: 'front', x: -6, y: -12, w: 6, h: 3, color: 'hammer', shade: 'dark' },
            { face: 'front', x: 0, y: -4, w: 8, h: 2, color: 'wrench' },
            { face: 'front', x: 0, y: -7, w: 3, h: 3, color: 'wrench', shade: 'dark' },
            { face: 'front', x: 6, y: -5, w: 2, h: 12, color: 'saw' },
            { face: 'front', x: 6, y: -12, w: 5, h: 2, color: 'saw', shade: 'dark' },
            { face: 'front', x: -3, y: 6, w: 4, h: 3, color: 'peg' },
            { face: 'front', x: 4, y: 6, w: 4, h: 3, color: 'peg' },
            { face: 'top', x: 0, y: -13, w: 22, h: 2, color: 'board', shade: 'lighter' },
            { face: 'back', x: 0, y: 0, w: 22, h: 24, color: 'board', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 20, h: 22, color: 'board', z: 2 },
            { face: 'back', x: -6, y: 0, w: 4, h: 2, color: 'peg', shade: 'dark', z: 3 },
            { face: 'back', x: 6, y: 0, w: 4, h: 2, color: 'peg', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 0, w: 6, h: 24, color: 'board', shade: 'dark' }
        ]
    },
    
    // --- Cabinet (generic tall cabinet) ---
    cabinet: {
        w: 18, h: 24, sideW: 10,
        colors: { body: 0x5a4a3a, door: 0x6a5a4a, handle: 0x7a7a6a, trim: 0x4a3a2a, hinge: 0x4a4a3a, crown: 0x7a6a58, gap: 0x2a2018, shelf: 0x3a3018 },
        parts: [
            // Front — frame
            { face: 'front', x: 0, y: 0, w: 18, h: 22, color: 'body', z: 1 },
            { face: 'front', x: 0, y: 0, w: 16, h: 20, color: 'body', shade: 'light', z: 2 },
            // Left door
            { face: 'front', x: -4, y: 0, w: 7, h: 18, color: 'door', z: 3 },
            { face: 'front', x: -4, y: 0, w: 5, h: 16, color: 'door', shade: 'light', z: 4 },
            // Right door
            { face: 'front', x: 4, y: 0, w: 7, h: 18, color: 'door', shade: 'dark', z: 3 },
            { face: 'front', x: 4, y: 0, w: 5, h: 16, color: 'door', z: 4 },
            // Center gap
            { face: 'front', x: 0, y: 0, w: 1, h: 18, color: 'gap', z: 5 },
            // Handles
            { face: 'front', x: -2, y: -2, w: 1, h: 4, color: 'handle', z: 6 },
            { face: 'front', x: 2, y: -2, w: 1, h: 4, color: 'handle', z: 6 },
            // Hinges
            { face: 'front', x: -7, y: -5, w: 1, h: 2, color: 'hinge', z: 5 },
            { face: 'front', x: -7, y: 5, w: 1, h: 2, color: 'hinge', z: 5 },
            { face: 'front', x: 7, y: -5, w: 1, h: 2, color: 'hinge', z: 5 },
            { face: 'front', x: 7, y: 5, w: 1, h: 2, color: 'hinge', z: 5 },
            // Crown molding
            { face: 'front', x: 0, y: -11, w: 18, h: 2, color: 'crown', z: 5 },
            // Base trim
            { face: 'front', x: 0, y: 11, w: 18, h: 2, color: 'trim', z: 3 },
            // Top
            { face: 'top', x: 0, y: -12, w: 18, h: 3, color: 'body', shade: 'lighter', z: 7 },
            { face: 'top', x: 0, y: -12, w: 16, h: 2, color: 'crown', shade: 'light', z: 8 },
            // Back
            { face: 'back', x: 0, y: 0, w: 18, h: 22, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 0, w: 16, h: 20, color: 'body', z: 2 },
            { face: 'back', x: 0, y: 6, w: 10, h: 2, color: 'body', shade: 'darker', z: 3 },
            // Side — shelf edges visible, crown molding wraps
            { face: 'side', x: 0, y: 0, w: 10, h: 22, color: 'body', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -4, w: 8, h: 1, color: 'shelf', alpha: 0.15, z: 2 },
            { face: 'side', x: 0, y: 4, w: 8, h: 1, color: 'shelf', alpha: 0.15, z: 2 },
            { face: 'side', x: 0, y: -11, w: 10, h: 2, color: 'crown', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: -12, w: 10, h: 3, color: 'body', z: 4 }
        ]
    },
    
    // --- Bed (bedroom furniture) ---
    bed: {
        w: 36, h: 28, sideW: 12,
        colors: { frame: 0x4a3a2a, mattress: 0x6a6a7a, sheet: 0x8a8a9a, pillow: 0x9a9aaa, post: 0x4a3a2a },
        parts: [
            // Footboard (front face — player sees head-on)
            { face: 'front', x: 0, y: 10, w: 36, h: 6, color: 'frame', z: 2 },
            { face: 'front', x: 0, y: 10, w: 34, h: 4, color: 'frame', shade: 'light', z: 3 },
            { face: 'front', x: 0, y: 7, w: 36, h: 2, color: 'frame', shade: 'lighter', z: 4 },
            // Footboard posts
            { face: 'front', x: -17, y: 8, w: 4, h: 10, color: 'frame', shade: 'dark', z: 3 },
            { face: 'front', x: 17, y: 8, w: 4, h: 10, color: 'frame', shade: 'darker', z: 3 },
            // Post caps
            { face: 'front', x: -17, y: 3, w: 5, h: 3, color: 'frame', shade: 'light', z: 5 },
            { face: 'front', x: 17, y: 3, w: 5, h: 3, color: 'frame', shade: 'light', z: 5 },
            // Mattress top surface (foreshortened, receding toward wall)
            { face: 'front', x: 0, y: -2, w: 32, h: 16, color: 'mattress', z: 1 },
            { face: 'front', x: 0, y: -2, w: 30, h: 14, color: 'mattress', shade: 'light', z: 1 },
            // Sheet/blanket
            { face: 'front', x: 0, y: 2, w: 28, h: 10, color: 'sheet', z: 2 },
            { face: 'front', x: 0, y: 2, w: 26, h: 8, color: 'sheet', shade: 'light', z: 2 },
            { face: 'front', x: 0, y: -2, w: 26, h: 1, color: 'sheet', shade: 'dark', z: 3 },
            // Pillows (at head, against wall)
            { face: 'front', x: -8, y: -8, w: 10, h: 5, color: 'pillow', z: 2 },
            { face: 'front', x: 8, y: -8, w: 10, h: 5, color: 'pillow', z: 2 },
            { face: 'front', x: -8, y: -9, w: 8, h: 2, color: 'pillow', shade: 'light', z: 3 },
            { face: 'front', x: 8, y: -9, w: 8, h: 2, color: 'pillow', shade: 'light', z: 3 },
            // Headboard (against wall, foreshortened)
            { face: 'front', x: 0, y: -12, w: 38, h: 4, color: 'frame', shade: 'dark', z: 0 },
            { face: 'front', x: 0, y: -13, w: 36, h: 2, color: 'frame', shade: 'light', z: 1 },
            // Side rails
            { face: 'front', x: -17, y: 0, w: 2, h: 22, color: 'frame', shade: 'darker', z: 0 },
            { face: 'front', x: 17, y: 0, w: 2, h: 22, color: 'frame', shade: 'darker', z: 0 },
            // Legs
            { face: 'front', x: -15, y: 14, w: 3, h: 3, color: 'frame', shade: 'darker', z: -1 },
            { face: 'front', x: 15, y: 14, w: 3, h: 3, color: 'frame', shade: 'darker', z: -1 },
            // Back face — headboard visible, plain frame back
            { face: 'back', x: 0, y: -12, w: 38, h: 4, color: 'frame', z: 5 },
            { face: 'back', x: 0, y: -12, w: 36, h: 2, color: 'frame', shade: 'light', z: 6 },
            { face: 'back', x: 0, y: -2, w: 32, h: 16, color: 'mattress', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 2, w: 28, h: 10, color: 'sheet', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: 10, w: 36, h: 6, color: 'frame', shade: 'dark', z: 3 },
            { face: 'back', x: -17, y: 0, w: 2, h: 22, color: 'frame', shade: 'darker', z: 0 },
            { face: 'back', x: 17, y: 0, w: 2, h: 22, color: 'frame', shade: 'darker', z: 0 },
            // Side face
            { face: 'side', x: 0, y: 0, w: 12, h: 22, color: 'frame', shade: 'dark', z: 0 },
            { face: 'side', x: 0, y: -2, w: 10, h: 14, color: 'mattress', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: 2, w: 10, h: 8, color: 'sheet', shade: 'dark', z: 2 },
            { face: 'top', x: 0, y: -14, w: 36, h: 3, color: 'frame', shade: 'lighter', z: 7 }
        ]
    },
    
    // --- TV on Stand (entertainment) ---
    tv: {
        w: 24, h: 22, sideW: 8,
        colors: { cabinet: 0x3a3530, screen: 0x1a1a2a, screenGlow: 0x2a2a3a, bezel: 0x2a2a2a, stand: 0x2a2a2a, led: 0x3a8a3a },
        parts: [
            // TV stand/cabinet
            { face: 'front', x: 0, y: 6, w: 24, h: 8, color: 'cabinet', z: 1 },
            { face: 'front', x: 0, y: 6, w: 22, h: 6, color: 'cabinet', shade: 'light', z: 2 },
            { face: 'front', x: 0, y: 2, w: 24, h: 2, color: 'cabinet', shade: 'lighter', z: 3 },
            { face: 'front', x: 12, y: 6, w: 2, h: 8, color: 'cabinet', shade: 'dark', z: 2 },
            // Screen (front face — large, dominant)
            { face: 'front', x: 0, y: -6, w: 22, h: 14, color: 'screen', z: 3 },
            { face: 'front', x: 0, y: -6, w: 20, h: 12, color: 'screenGlow', z: 4 },
            // Screen glare
            { face: 'front', x: -4, y: -8, w: 4, h: 2, color: 0x3a3a4a, alpha: 0.3, z: 5 },
            // Top of TV — foreshortened strip
            { face: 'front', x: 0, y: -13, w: 22, h: 2, color: 'bezel', z: 5 },
            // Bottom bezel
            { face: 'front', x: 0, y: 1, w: 20, h: 1, color: 'bezel', z: 5 },
            // Stand neck
            { face: 'front', x: 0, y: 1, w: 4, h: 3, color: 'stand', z: 3 },
            // Power LED
            { face: 'front', type: 'circle', x: 8, y: 1, r: 1, color: 'led', alpha: 0.5, z: 6 },
            // Back face — plain rear panel with vents
            { face: 'back', x: 0, y: -6, w: 22, h: 14, color: 'bezel', z: 3 },
            { face: 'back', x: 0, y: -6, w: 20, h: 12, color: 'bezel', shade: 'light', z: 4 },
            { face: 'back', x: 0, y: -2, w: 14, h: 4, color: 0x1a1a1a, z: 5 },
            { face: 'back', x: 4, y: -8, w: 1, h: 6, color: 0x1a1a1a, alpha: 0.4, z: 5 },
            { face: 'back', x: 0, y: 6, w: 24, h: 8, color: 'cabinet', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: 1, w: 4, h: 3, color: 'stand', z: 3 },
            // Side face
            { face: 'side', x: 0, y: 6, w: 8, h: 8, color: 'cabinet', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: 2, w: 8, h: 2, color: 'cabinet', z: 2 },
            { face: 'side', x: 2, y: -6, w: 3, h: 14, color: 'screen', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: -4, w: 1, h: 16, color: 'bezel', shade: 'dark', z: 1 },
            { face: 'top', x: 0, y: -14, w: 22, h: 2, color: 'bezel', shade: 'light', z: 7 }
        ]
    },
    
    // --- Couch (living room seating) ---
    couch: {
        w: 36, h: 18, sideW: 10,
        colors: { body: 0x4a4a55, cushion: 0x4a4a55, arm: 0x4a4a55, legs: 0x3a3a3a },
        parts: [
            // Back rest (front face)
            { face: 'front', x: 0, y: -4, w: 36, h: 10, color: 'body', z: 1 },
            { face: 'front', x: 0, y: -4, w: 34, h: 8, color: 'body', shade: 'light', z: 2 },
            // Back rest top (foreshortened)
            { face: 'front', x: 0, y: -10, w: 36, h: 3, color: 'body', shade: 'lighter', z: 4 },
            // Seat cushion (foreshortened top)
            { face: 'front', x: 0, y: 4, w: 32, h: 8, color: 'cushion', shade: 'light', z: 3 },
            // Cushion divide
            { face: 'front', x: 0, y: 4, w: 1, h: 6, color: 'body', shade: 'dark', alpha: 0.4, z: 4 },
            // Arms
            { face: 'front', x: -17, y: 0, w: 4, h: 16, color: 'arm', shade: 'dark', z: 2 },
            { face: 'front', x: 17, y: 0, w: 4, h: 16, color: 'arm', shade: 'darker', z: 2 },
            { face: 'front', x: -17, y: -8, w: 4, h: 2, color: 'arm', shade: 'light', z: 4 },
            { face: 'front', x: 17, y: -8, w: 4, h: 2, color: 'arm', shade: 'light', z: 4 },
            // Right side face edge
            { face: 'front', x: 19, y: 0, w: 2, h: 16, color: 'arm', shade: 'darker', z: 1 },
            // Front apron
            { face: 'front', x: 0, y: 8, w: 32, h: 2, color: 'body', shade: 'dark', z: 2 },
            // Legs
            { face: 'front', x: -14, y: 10, w: 3, h: 3, color: 'legs', z: -1 },
            { face: 'front', x: 14, y: 10, w: 3, h: 3, color: 'legs', z: -1 },
            // Throw pillow
            { face: 'front', x: -8, y: -2, w: 8, h: 6, color: 'cushion', shade: 'lighter', z: 4 },
            // Back face — plain back panel
            { face: 'back', x: 0, y: -4, w: 36, h: 10, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: -4, w: 34, h: 8, color: 'body', z: 2 },
            { face: 'back', x: -17, y: 0, w: 4, h: 16, color: 'arm', shade: 'darker', z: 2 },
            { face: 'back', x: 17, y: 0, w: 4, h: 16, color: 'arm', shade: 'darker', z: 2 },
            { face: 'back', x: 0, y: 4, w: 30, h: 6, color: 'body', shade: 'dark', z: 1 },
            { face: 'back', x: -14, y: 10, w: 3, h: 3, color: 'legs', z: -1 },
            { face: 'back', x: 14, y: 10, w: 3, h: 3, color: 'legs', z: -1 },
            // Side face — arm dominant, cushion sliver
            { face: 'side', x: -2, y: 0, w: 10, h: 16, color: 'arm', shade: 'dark', z: 1 },
            { face: 'side', x: -2, y: -8, w: 10, h: 3, color: 'arm', shade: 'light', z: 3 },
            { face: 'side', x: 4, y: -3, w: 6, h: 14, color: 'body', shade: 'dark', z: 1 },
            { face: 'side', x: 4, y: 2, w: 6, h: 8, color: 'cushion', shade: 'dark', z: 2 },
            { face: 'top', x: 0, y: -11, w: 36, h: 3, color: 'body', shade: 'lighter', z: 7 }
        ]
    },
    
    // --- Computer Desk (desk + monitor + keyboard + chair) ---
    computer_desk: {
        w: 30, h: 28, sideW: 12,
        colors: { desk: 0x4a4035, deskTop: 0x5a5045, monitor: 0x2a2a2a, screen: 0x1a3a4a, screenGlow: 0x3a5a6a, keyboard: 0x3a3a3a, chair: 0x4a3a3a, legs: 0x3a3025 },
        parts: [
            { face: 'front', x: 0, y: -2, w: 30, h: 4, color: 'legs', z: 1 },
            { face: 'front', x: 0, y: 4, w: 30, h: 10, color: 'deskTop', z: 2 },
            { face: 'front', x: 0, y: 10, w: 28, h: 4, color: 'desk', z: 2 },
            { face: 'front', x: -14, y: 6, w: 4, h: 14, color: 'desk', shade: 'dark', z: 1 },
            { face: 'front', x: 14, y: 6, w: 4, h: 14, color: 'desk', shade: 'dark', z: 1 },
            { face: 'front', x: -12, y: 16, w: 3, h: 8, color: 'legs', z: 0 },
            { face: 'front', x: 12, y: 16, w: 3, h: 8, color: 'legs', z: 0 },
            { face: 'front', x: 0, y: -4, w: 4, h: 6, color: 'monitor', z: 3 },
            { face: 'front', x: 0, y: 0, w: 6, h: 3, color: 'monitor', z: 3 },
            { face: 'front', x: 0, y: -14, w: 22, h: 16, color: 'monitor', z: 4 },
            { face: 'front', x: 0, y: -14, w: 20, h: 14, color: 'screen', z: 5 },
            { face: 'front', x: -2, y: -16, w: 14, h: 2, color: 'screenGlow', z: 6 },
            { face: 'front', x: 0, y: -12, w: 10, h: 2, color: 'screenGlow', alpha: 0.6, z: 6 },
            { face: 'front', x: 0, y: -22, w: 20, h: 3, color: 'monitor', shade: 'light', z: 5 },
            { face: 'front', x: 0, y: 6, w: 16, h: 6, color: 'keyboard', z: 3 },
            { face: 'front', x: 0, y: 5, w: 14, h: 4, color: 'keyboard', shade: 'light', z: 4 },
            { face: 'front', type: 'ellipse', x: 10, y: 5, w: 4, h: 6, color: 'keyboard', z: 3 },
            { face: 'front', x: 0, y: 22, w: 14, h: 8, color: 'chair', z: 1 },
            { face: 'front', x: 0, y: 20, w: 12, h: 4, color: 'chair', shade: 'light', z: 2 },
            { face: 'front', x: 0, y: 28, w: 12, h: 10, color: 'chair', shade: 'light', z: 1 },
            { face: 'front', type: 'ellipse', x: 0, y: 30, w: 14, h: 4, color: 'keyboard', z: 0 },
            { face: 'back', x: 0, y: 4, w: 30, h: 10, color: 'desk', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: -14, w: 22, h: 16, color: 'monitor', shade: 'dark', z: 4 },
            { face: 'back', x: 0, y: -10, w: 14, h: 6, color: 0x1a1a1a, z: 5 },
            { face: 'back', x: -12, y: 16, w: 3, h: 8, color: 'legs', shade: 'dark', z: 0 },
            { face: 'back', x: 12, y: 16, w: 3, h: 8, color: 'legs', shade: 'dark', z: 0 },
            { face: 'side', x: 0, y: 4, w: 12, h: 10, color: 'desk', shade: 'dark', z: 2 },
            { face: 'side', x: 2, y: -14, w: 3, h: 14, color: 'monitor', shade: 'dark', z: 4 },
            { face: 'side', x: 0, y: -4, w: 4, h: 6, color: 'monitor', z: 3 },
            { face: 'side', x: 0, y: 16, w: 2, h: 8, color: 'legs', z: 0 },
            { face: 'top', x: 0, y: -23, w: 20, h: 3, color: 'monitor', shade: 'lighter', z: 7 }
        ]
    },
    
    // --- Chest (reinforced storage chest) ---
    chest: {
        w: 24, h: 18, sideW: 10,
        colors: { wood: 0x6a4a35, woodDk: 0x4a3020, band: 0x555555, lock: 0x666666, lid: 0x7a5a45, stud: 0x666666, hinge: 0x555555 },
        parts: [
            { face: 'front', x: 0, y: 2, w: 24, h: 16, color: 'wood', z: 1 },
            { face: 'front', x: 0, y: 2, w: 22, h: 14, color: 'wood', shade: 'light', z: 2 },
            { face: 'front', x: 0, y: -2, w: 24, h: 2, color: 'band', z: 3 },
            { face: 'front', x: 0, y: 6, w: 24, h: 2, color: 'band', z: 3 },
            { face: 'front', x: 0, y: 2, w: 4, h: 6, color: 'lock', z: 4 },
            { face: 'front', type: 'circle', x: 0, y: 2, r: 2, color: 'lock', shade: 'light', z: 5 },
            { face: 'front', type: 'circle', x: -10, y: -4, r: 1, color: 'stud', z: 4 },
            { face: 'front', type: 'circle', x: 10, y: -4, r: 1, color: 'stud', z: 4 },
            { face: 'front', type: 'circle', x: -10, y: 8, r: 1, color: 'stud', z: 4 },
            { face: 'front', type: 'circle', x: 10, y: 8, r: 1, color: 'stud', z: 4 },
            { face: 'top', x: 0, y: -8, w: 24, h: 6, color: 'lid', z: 6 },
            { face: 'top', x: 0, y: -9, w: 22, h: 3, color: 'lid', shade: 'light', z: 7 },
            { face: 'back', x: 0, y: 2, w: 24, h: 16, color: 'woodDk', z: 1 },
            { face: 'back', x: 0, y: 2, w: 22, h: 14, color: 'wood', shade: 'dark', z: 2 },
            { face: 'back', x: -6, y: -2, w: 3, h: 4, color: 'hinge', z: 3 },
            { face: 'back', x: 6, y: -2, w: 3, h: 4, color: 'hinge', z: 3 },
            { face: 'back', x: 0, y: -2, w: 24, h: 2, color: 'band', shade: 'dark', z: 3 },
            { face: 'back', x: 0, y: 6, w: 24, h: 2, color: 'band', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 2, w: 10, h: 16, color: 'wood', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -2, w: 10, h: 2, color: 'band', shade: 'dark', z: 3 },
            { face: 'side', x: 0, y: 6, w: 10, h: 2, color: 'band', shade: 'dark', z: 3 }
        ]
    },
    
    // --- Gym Rack (barbell rack with weights) ---
    gym_rack: {
        w: 28, h: 28, sideW: 12,
        colors: { frame: 0x3a3a3a, bar: 0x6a6a6a, plate: 0x2a2a2a, plateLt: 0x3a3a3a, hook: 0x5a5a5a, base: 0x3a3a3a },
        parts: [
            { face: 'front', x: -10, y: 0, w: 6, h: 30, color: 'frame', z: 1 },
            { face: 'front', x: -10, y: 0, w: 4, h: 28, color: 'frame', shade: 'light', z: 2 },
            { face: 'front', x: 10, y: 0, w: 6, h: 30, color: 'frame', z: 1 },
            { face: 'front', x: 10, y: 0, w: 4, h: 28, color: 'frame', shade: 'light', z: 2 },
            { face: 'front', x: 0, y: -14, w: 24, h: 4, color: 'frame', shade: 'light', z: 3 },
            { face: 'top', x: 0, y: -16, w: 24, h: 3, color: 'frame', shade: 'lighter', z: 7 },
            { face: 'front', x: 0, y: 12, w: 24, h: 3, color: 'frame', z: 2 },
            { face: 'front', x: -10, y: -6, w: 8, h: 3, color: 'hook', z: 4 },
            { face: 'front', x: -10, y: -8, w: 6, h: 2, color: 'hook', shade: 'light', z: 5 },
            { face: 'front', x: 10, y: -6, w: 8, h: 3, color: 'hook', z: 4 },
            { face: 'front', x: 10, y: -8, w: 6, h: 2, color: 'hook', shade: 'light', z: 5 },
            { face: 'front', x: 0, y: -6, w: 28, h: 3, color: 'bar', z: 5 },
            { face: 'front', x: 0, y: -8, w: 26, h: 2, color: 'bar', shade: 'light', z: 6 },
            { face: 'front', x: -13, y: -6, w: 4, h: 12, color: 'plate', z: 4 },
            { face: 'front', x: -12, y: -6, w: 3, h: 10, color: 'plateLt', z: 5 },
            { face: 'front', x: 13, y: -6, w: 4, h: 12, color: 'plate', z: 4 },
            { face: 'front', x: 14, y: -6, w: 3, h: 10, color: 'plateLt', z: 5 },
            { face: 'front', x: -10, y: 14, w: 10, h: 3, color: 'base', z: 1 },
            { face: 'front', x: 10, y: 14, w: 10, h: 3, color: 'base', z: 1 },
            { face: 'front', x: 2, y: 10, w: 8, h: 10, color: 'plateLt', z: 0 },
            { face: 'front', x: 2, y: 8, w: 6, h: 3, color: 'frame', shade: 'light', z: 1 },
            { face: 'back', x: -10, y: 0, w: 6, h: 30, color: 'frame', shade: 'dark', z: 1 },
            { face: 'back', x: 10, y: 0, w: 6, h: 30, color: 'frame', shade: 'dark', z: 1 },
            { face: 'back', x: 0, y: -14, w: 24, h: 4, color: 'frame', z: 3 },
            { face: 'back', x: 0, y: 12, w: 24, h: 3, color: 'frame', shade: 'dark', z: 2 },
            { face: 'side', x: 0, y: 0, w: 12, h: 30, color: 'frame', shade: 'dark', z: 1 },
            { face: 'side', x: 0, y: -14, w: 10, h: 4, color: 'frame', z: 3 },
            { face: 'side', x: 0, y: -6, w: 12, h: 3, color: 'bar', shade: 'dark', z: 5 },
            { face: 'side', x: -4, y: -6, w: 3, h: 12, color: 'plate', z: 4 }
        ]
    },
    
    // --- Toilet (Bathroom) ---
    // ¾ perspective: front shows bowl front face + seat rim, side shows bowl profile + tank
    toilet: {
        w: 14, h: 18, sideW: 10,
        colors: { bowl: 0xcccccc, seat: 0xdddddd, rim: 0xbbbbbb, tank: 0xc8c8c8, tankLid: 0xd4d4d4, handle: 0x888888, water: 0x8aaacc, base: 0xbbbbbb, shadow: 0x999999, pipe: 0x777777 },
        parts: [
            // Front face — bowl front visible head-on
            // Bowl body (rounded front)
            { face: 'front', x: 0, y: 3, w: 12, h: 10, color: 'bowl', z: 2 },
            { face: 'front', x: 0, y: 3, w: 10, h: 8, color: 'bowl', shade: 'light', z: 3 },
            // Seat rim (oval top edge of bowl)
            { face: 'front', x: 0, y: -2, w: 12, h: 3, color: 'seat', z: 4 },
            { face: 'front', x: 0, y: -2, w: 10, h: 2, color: 'seat', shade: 'light', z: 5 },
            // Interior hole (dark)
            { face: 'front', x: 0, y: -1, w: 8, h: 2, color: 'water', alpha: 0.4, z: 6 },
            // Tank behind bowl (upper section against wall)
            { face: 'front', x: 0, y: -7, w: 10, h: 6, color: 'tank', z: 1 },
            { face: 'front', x: 0, y: -7, w: 8, h: 4, color: 'tank', shade: 'light', z: 2 },
            // Tank lid
            { face: 'front', x: 0, y: -10, w: 10, h: 2, color: 'tankLid', z: 3 },
            // Flush handle
            { face: 'front', x: 5, y: -8, w: 3, h: 1, color: 'handle', z: 4 },
            // Base
            { face: 'front', x: 0, y: 8, w: 10, h: 3, color: 'base', shade: 'dark', z: 1 },
            // Bowl shadow
            { face: 'front', x: 0, y: 4, w: 12, h: 1, color: 'shadow', alpha: 0.15, z: 1 },
            
            // Back face — see tank back + pipe
            { face: 'back', x: 0, y: -7, w: 10, h: 6, color: 'tank', shade: 'dark', z: 2 },
            { face: 'back', x: 0, y: -7, w: 8, h: 4, color: 'tank', z: 3 },
            { face: 'back', x: 0, y: -10, w: 10, h: 2, color: 'tankLid', shade: 'dark', z: 4 },
            { face: 'back', x: 0, y: 3, w: 12, h: 10, color: 'bowl', shade: 'dark', z: 1 },
            { face: 'back', x: -3, y: -3, w: 2, h: 8, color: 'pipe', alpha: 0.4, z: 2 },
            
            // Side face — see bowl PROFILE (curved silhouette), tank depth
            { face: 'side', x: 0, y: 3, w: 10, h: 10, color: 'bowl', shade: 'dark', z: 2 },
            { face: 'side', x: 0, y: 5, w: 8, h: 6, color: 'bowl', z: 3 },
            // Seat rim edge
            { face: 'side', x: 0, y: -1, w: 10, h: 2, color: 'seat', shade: 'dark', z: 4 },
            // Tank side
            { face: 'side', x: -2, y: -7, w: 6, h: 6, color: 'tank', shade: 'dark', z: 1 },
            { face: 'side', x: -2, y: -10, w: 6, h: 2, color: 'tankLid', shade: 'dark', z: 2 },
            // Pipe running from tank to bowl
            { face: 'side', x: -1, y: -3, w: 1, h: 4, color: 'pipe', alpha: 0.5, z: 3 },
            // Base
            { face: 'side', x: 0, y: 8, w: 8, h: 3, color: 'base', shade: 'darker', z: 1 },
            
            // Top — foreshortened seat oval
            { face: 'top', type: 'ellipse', x: 0, y: -4, w: 12, h: 4, color: 'seat', z: 7 },
            { face: 'top', type: 'ellipse', x: 0, y: -4, w: 8, h: 3, color: 'water', alpha: 0.3, z: 8 }
        ]
    }
};

