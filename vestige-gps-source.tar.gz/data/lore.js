// Vestige GPS — LORE_DATA
// Extracted from game_2_.html lines 47-484

export const LORE_DATA = {
    lore: {
        world: {
            planet: 'Raum',
            event: 'The Collapse',
            summary: 'Raum was once a thriving industrial world. The Collapse shattered its infrastructure and left its populace starving. What caused the Collapse is disputed — some blame corporate greed, others whisper about what arrived after.',
            era: 'Post-Collapse'
        },
        
        the_cube: {
            name: 'The Cube',
            nature: 'An anomalous object that appeared after the Collapse. Its origin is unknown. Those who interact with it are changed. Those who worship it pay a price no one speaks of openly.',
            fragments: 'Encrypted Cube Fragments are scattered across Raum. Each contains a resonance that defies known physics. Collecting them draws attention.',
            mystery: 'Whether the Cube caused the Collapse or was drawn to its aftermath remains the central question. The truth may be worse than either.'
        },
        
        factions: {
            terracorp: {
                name: 'Terracorp',
                type: 'Deep military complex',
                status: 'Active, hidden',
                desc: 'Terracorp operates in hiding, away from the starving populace. Their installations are buried deep, their soldiers well-equipped. They claim to preserve order. Their definition of order serves only themselves.',
                motto: 'Through structure, survival.'
            },
            ucr: {
                name: 'United Corporations of Raum',
                alias: 'UCR',
                type: 'Pre-war military-industrial alliance',
                status: 'Remnants persist',
                desc: 'The UCR ran the largest supply of military-grade weapons from the old war. Their factories are ruins now, but their stockpiles remain — buried in vaults, locked in bunkers, guarded by automated systems that outlasted their makers.',
                motto: 'Built to last. Built to kill.'
            },
            deralict: {
                name: 'Deralict',
                type: 'Heavy mining corporation',
                status: 'Active under Terracorp command',
                desc: 'Deralict still operates heavy mining installations at the command of Terracorp. Their workers are expendable. Their machines are not. What they mine in the deep shafts is not always ore.',
                motto: 'Dig deeper.'
            },
            sworn: {
                name: 'Sworn',
                type: 'Resistance movement',
                status: 'Active, decentralized',
                desc: 'The Sworn are the well-known resistance to the higher powers that drain Raum of enrichment and any hopes to repair what was lost. They fight with salvaged gear, stolen tech, and the one thing the corporations cannot manufacture — conviction.',
                motto: 'What was taken will be reclaimed.'
            },
            blackreach: {
                name: 'Blackreach',
                type: 'Mythical shielded community',
                status: 'Unconfirmed',
                desc: 'A mythical community of shielded individuals said to live lives compared to pre-war. No one has found Blackreach. Some who searched never returned. The weapons that bear their name appear in the wastes with no explanation.',
                motto: 'Beyond the veil, we endure.'
            },
            cephalon: {
                name: 'Cephalon',
                type: 'Cube worship cult',
                status: 'Growing',
                desc: 'The mysterious force that arrived after the Collapse. Those who worship the Cube. Those who pay the price. Cephalon adherents speak of transcendence, of a frequency beneath all things. Their weapons hum with a resonance that should not exist.',
                motto: 'The signal is the way.'
            }
        }
    },
    foundries: {
        terracorp: {
            name: 'Terracorp',
            tag: 'TC',
            faction: 'terracorp',
            // Visual DNA
            palette: {
                body: '#3a4a32',       // dark olive
                bodyLight: '#4a5a42',
                bodyDark: '#2a3a22',
                accent: '#8a2a2a',     // tactical red
                metal: '#4a4a4a',      // gunmetal
                metalLight: '#5a5a5a',
                detail: '#2a2a2a'      // matte black
            },
            finish: 'matte',
            traitBias: 'balanced',     // no stat skew
            desc: 'Standard-issue Terracorp sidearms. Clean, maintained, utterly without personality.',
            flavorPool: [
                'Serial number filed. Replaced with a barcode.',
                'Issued, not earned.',
                'Smells like bunker air and compliance.'
            ],
            gearOutfit: { shirt: { base: '#3a4a32', light: '#4a5a42', dark: '#2a3a22' }, pants: { base: '#2a3a22', light: '#3a4a32' } }
        },
        ucr: {
            name: 'UCR',
            tag: 'UCR',
            faction: 'ucr',
            palette: {
                body: '#3a3a4a',       // steel blue-grey
                bodyLight: '#4a4a5a',
                bodyDark: '#2a2a3a',
                accent: '#6a8aaa',     // chrome blue
                metal: '#5a5a6a',      // polished steel
                metalLight: '#7a7a8a',
                detail: '#ddeeff'      // white stencil
            },
            finish: 'polished',
            traitBias: 'accuracy',     // accuracy bonus
            desc: 'Pre-war UCR manufacturing. Precision tolerances that modern fabrication cannot replicate.',
            flavorPool: [
                'Factory sealed. Vault preserved.',
                'The war ended. The warranty did not.',
                'Older than everyone who wants it.'
            ],
            gearOutfit: { shirt: { base: '#3a3a4a', light: '#4a4a5a', dark: '#2a2a3a' }, pants: { base: '#2a2a3a', light: '#3a3a4a' } }
        },
        deralict: {
            name: 'Deralict',
            tag: 'DRL',
            faction: 'deralict',
            palette: {
                body: '#3a3028',       // dark iron
                bodyLight: '#4a4038',
                bodyDark: '#2a2018',
                accent: '#cc6622',     // burnt orange
                metal: '#5a4a3a',      // raw iron
                metalLight: '#6a5a4a',
                detail: '#ccaa22'      // hazard yellow
            },
            finish: 'industrial',
            traitBias: 'damage',       // raw damage bonus
            desc: 'Deralict mining tools retrofitted for killing. Overbuilt, overweight, overeffective.',
            flavorPool: [
                'Originally a rock drill. Adjusted for softer targets.',
                'CAUTION: INDUSTRIAL USE ONLY is scratched out.',
                'Weighs as much as its kill count.'
            ],
            gearOutfit: { shirt: { base: '#3a3028', light: '#4a4038', dark: '#2a2018' }, pants: { base: '#2a2018', light: '#3a3028' } }
        },
        sworn: {
            name: 'Sworn',
            tag: 'SWN',
            faction: 'sworn',
            palette: {
                body: '#5a4a38',       // tan/earth
                bodyLight: '#6a5a48',
                bodyDark: '#4a3a28',
                accent: '#4a6a3a',     // resistance green
                metal: '#5a5a4a',      // worn metal
                metalLight: '#6a6a5a',
                detail: '#8a7a6a'      // wrapped grip color
            },
            finish: 'worn',
            traitBias: 'speed',        // fire rate / mobility
            desc: 'Sworn field modifications. Lighter, faster, held together by wire and will.',
            flavorPool: [
                'Three owners. None of them quit.',
                'Carved initials on the stock. Not all are crossed out.',
                'Runs on spite.'
            ],
            gearOutfit: { shirt: { base: '#5a4a38', light: '#6a5a48', dark: '#4a3a28' }, pants: { base: '#4a3a28', light: '#5a4a38' } }
        },
        blackreach: {
            name: 'Blackreach',
            tag: 'BLK',
            faction: 'blackreach',
            palette: {
                body: '#1a1a22',       // deep black
                bodyLight: '#2a2a32',
                bodyDark: '#0a0a12',
                accent: '#aa8833',     // gold trim
                metal: '#2a2a3a',      // dark alloy
                metalLight: '#3a3a4a',
                detail: '#6a3a8a'      // deep purple
            },
            finish: 'luxe',
            traitBias: 'crit',         // crit chance / special
            desc: 'Blackreach armaments. Nobody knows how they reach the surface. Nobody asks twice.',
            flavorPool: [
                'No serial number. No manufacturer stamp. No history.',
                'Warm to the touch. Always.',
                'Found in a dead drop. The dead did not drop it.'
            ],
            gearOutfit: { shirt: { base: '#1a1a22', light: '#2a2a32', dark: '#0a0a12' }, pants: { base: '#0a0a12', light: '#1a1a22' } }
        },
        cephalon: {
            name: 'Cephalon',
            tag: 'CPH',
            faction: 'cephalon',
            palette: {
                body: '#1a2a2a',       // dark carbon
                bodyLight: '#2a3a3a',
                bodyDark: '#0a1a1a',
                accent: '#33aaaa',     // teal glow
                metal: '#2a3a3a',      // alien alloy
                metalLight: '#3a4a4a',
                detail: '#44ddcc'      // iridescent
            },
            finish: 'anomalous',
            traitBias: 'mod',          // mod effectiveness
            desc: 'Cephalon-touched armaments. The materials should not exist. The geometry is subtly wrong. They work too well.',
            flavorPool: [
                'Hums at a frequency that makes teeth ache.',
                'The barrel is 2mm longer on the inside than the outside.',
                'Do not disassemble. (Written in a language that predates Raum.)'
            ],
            gearOutfit: { shirt: { base: '#1a2a2a', light: '#2a3a3a', dark: '#0a1a1a' }, pants: { base: '#0a1a1a', light: '#1a2a2a' } }
        }
    },
    weaponFlavor: {
        generic: [
            'Somebody died holding this. Somebody else pried it loose.',
            'The scratches tell a story. None of it is good.',
            'Heavy for its size. Heavier for what it\'s done.',
            'Not the first owner. Won\'t be the last.',
            'Still warm from the last fight.',
            'The safety was filed off a long time ago.',
            'Recoil pattern worn into the grip.',
            'Smells like cordite and regret.',
            'There are tallies scratched into the stock.',
            'The previous owner didn\'t need it anymore.',
            'Functional. That\'s the best you can say about anything out here.',
            'It works. Don\'t ask how.',
            'The barrel is slightly bent. Still shoots straight enough.',
            'More tape than metal at this point.',
            'Reliable. The most dangerous word on Raum.',
            'You don\'t find these. They find you.',
            'Built to outlast its owner. Usually does.',
            'Every dent is a lesson someone else learned.',
            'Field-tested. The field was not kind.',
            'No manual. No warranty. No mercy.',
            'Cleaned once. Maybe twice. Definitely not recently.',
            'Lighter than expected. That\'s suspicious.',
            'The trigger pull is smooth from use, not design.',
            'Production date worn off. Doesn\'t matter anymore.',
            'Someone etched HOLD FAST into the receiver.',
            'Three rounds short of a full magazine. Always.',
            'Makes a sound when the wind hits it. Almost like humming.',
            'Last seen in the hands of someone who isn\'t around to miss it.',
            'Whoever built this didn\'t plan for it to last this long.'
        ],
        // Universal lines safe for melee AND ranged — no gun-specific references
        universal: [
            'Somebody died holding this. Somebody else pried it loose.',
            'The scratches tell a story. None of it is good.',
            'Heavy for its size. Heavier for what it\'s done.',
            'Not the first owner. Won\'t be the last.',
            'Still warm from the last fight.',
            'The previous owner didn\'t need it anymore.',
            'Functional. That\'s the best you can say about anything out here.',
            'It works. Don\'t ask how.',
            'More tape than metal at this point.',
            'Reliable. The most dangerous word on Raum.',
            'You don\'t find these. They find you.',
            'Built to outlast its owner. Usually does.',
            'Every dent is a lesson someone else learned.',
            'Field-tested. The field was not kind.',
            'No manual. No warranty. No mercy.',
            'Lighter than expected. That\'s suspicious.',
            'Production date worn off. Doesn\'t matter anymore.',
            'Makes a sound when the wind hits it. Almost like humming.',
            'Last seen in the hands of someone who isn\'t around to miss it.',
            'Whoever built this didn\'t plan for it to last this long.'
        ],
        melee: [
            'The edge remembers every bone it\'s met.',
            'Balanced for killing. Poorly balanced for everything else.',
            'Blood in the grain that won\'t wash out.',
            'Swings like a conversation ender.',
            'Simple. Brutal. Honest.',
            'The handle is wrapped in something you don\'t want to identify.',
            'Older than the Collapse. Sharper than the day it was forged.',
            'Makes a sound when you swing it. Almost like it\'s breathing.',
            'No moving parts. Nothing to jam. Nothing to fail.',
            'They don\'t make them like this anymore. They don\'t make anything anymore.',
            'You can feel the weight of it pulling toward the fight.',
            'More a tool than a weapon. Same result either way.',
            'The flat of the blade has been used as a mirror. And a shovel.',
            'Grip shaped to a dead man\'s hand.',
            'The first hit is always the loudest.'
        ],
        foundry: {
            terracorp: [
                'Standard issue. Standard kills.',
                'Terracorp stamp still visible. Worth more than the weapon.',
                'Bunker-preserved. Never seen daylight until now.',
                'Requisition tag still attached. Owner: REDACTED.',
                'Cleaned, oiled, and completely soulless.',
                'The serial number matches a manifest from a bunker that no longer exists.',
                'Smells like bunker air and protocol.',
                'Approved for distribution. Not for questions.'
            ],
            ucr: [
                'Pre-war precision. Post-war necessity.',
                'The machining tolerances are absurd. So is its kill count.',
                'UCR quality control would weep seeing it now.',
                'Vault-fresh. Shoots like a memory of civilization.',
                'Engineering so good it\'s almost unfair.',
                'Worth more than most people\'s safehouses.',
                'The warranty outlasted the manufacturer.',
                'Calibrated to tolerances that no longer matter.'
            ],
            deralict: [
                'Originally meant for rock. Works fine on flesh.',
                'The safety label says INDUSTRIAL USE ONLY. Someone disagreed.',
                'Overbuilt for mining. Perfectly built for this.',
                'Smells like engine oil and deep earth.',
                'Shaft 9 stamped on the frame. Nobody goes to Shaft 9.',
                'Heavier than it needs to be. Hits harder than it should.',
                'The motor housing still vibrates when you grip it.',
                'Bore diameter suggests it was made for something bigger than rock.'
            ],
            sworn: [
                'Three names scratched inside the stock. Two are crossed out.',
                'Held together by conviction and wire.',
                'Sworn field mod. Lighter. Meaner.',
                'Passed from hand to hand across the wasteland.',
                'The resistance doesn\'t build weapons. They inherit them.',
                'Every scratch is a border crossed.',
                'Wrapped in cloth that used to be a flag.',
                'There\'s a prayer carved where the serial number was.'
            ],
            blackreach: [
                'No origin. No history. No explanation.',
                'Warm to the touch. Always.',
                'The metal is a color that doesn\'t have a name.',
                'Found in a dead drop that wasn\'t there yesterday.',
                'Someone paid a price for this. Not in credits.',
                'It hums at a frequency just below hearing.',
                'The shadow it casts doesn\'t match its shape.',
                'Trade provenance: unknown. Trade value: don\'t ask.'
            ],
            cephalon: [
                'The geometry is wrong. It works anyway.',
                'Do not look at it under magnification.',
                'The materials predate Raum. Possibly by millennia.',
                'It resonates with something deep underground.',
                'The instruction manual is in a language that hasn\'t been invented yet.',
                'Maintenance: not recommended. Disassembly: not possible.',
                'The barrel is 2mm longer on the inside.',
                'It solved a problem the engineers hadn\'t identified yet.'
            ]
        },
        flair: {
            electric: [
                'Sparks jump between your fingers when you grip it.',
                'The arc leaves afterimages on your retinas.',
                'Touch the barrel. I dare you.'
            ],
            ember: [
                'The heat never fades. Even in the cold.',
                'Ash falls from it like snow.',
                'It burned through its last holster.'
            ],
            void: [
                'The shadows around it bend wrong.',
                'Something watches from the fractures.',
                'Light enters it and doesn\'t come back.'
            ],
            frost: [
                'Your breath fogs when you hold it.',
                'The ice regrows faster than you can scrape it.',
                'Cold enough to burn.'
            ],
            gilded: [
                'The gold isn\'t decorative. It grew there.',
                'Worth a fortune. If you could find a buyer.',
                'The veins pulse faintly in dim light.'
            ],
            spectral: [
                'It leaves a trail in the air that fades slowly.',
                'Looks like it exists in two places at once.',
                'The afterimage moves independently sometimes.'
            ]
        },
        gear: [
            'The stitching holds. That\'s all you can ask.',
            'Smells like the last three people who wore it.',
            'The padding stopped a bullet once. You can feel the dent.',
            'Blood on the collar that won\'t wash out.',
            'Heavier than it looks. Lighter than what it stops.',
            'Someone died in this. You try not to think about it.',
            'The straps have been adjusted for a dozen different bodies.',
            'More patch than original material at this point.',
            'It won\'t stop everything. But it\'ll slow it down.',
            'The lining is scratchy. The alternative is worse.',
            'Keeps the rain out. Keeps the bullets mostly out.',
            'You can tell which parts were added after the Collapse.',
            'Fits like it was made for someone else. Because it was.',
            'The clasps are mismatched. They still hold.',
            'Warm in the cold. Cold in the heat. Wrong in every weather.',
            'There\'s a name tag inside. The name has been scratched off.',
            'Every pocket has something left in it by the previous owner.',
            'The armor plates are scavenged from three different sources.',
            'It creaks when you move. At least you know it\'s there.'
        ]
    },
    loreChips: {
        // WORLD — Planet Raum and the Collapse
        world_001: { id: 'world_001', series: 'world', title: 'Raum Before', text: 'Raum was a forge world. Thirty billion souls worked its crust, fed its furnaces, breathed its smoke. They called it progress.', rarity: 'common' },
        world_002: { id: 'world_002', series: 'world', title: 'The Day It Stopped', text: 'No warning. No build-up. One moment the grid was live, the next — silence. Every system on Raum failed simultaneously. The Collapse was not gradual. It was a switch.', rarity: 'common' },
        world_003: { id: 'world_003', series: 'world', title: 'After the Silence', text: 'The first three days killed more people than the next three years. Without power, without water treatment, without logistics — civilization does not decay. It drops.', rarity: 'uncommon' },
        world_004: { id: 'world_004', series: 'world', title: 'The Starving Season', text: 'They called the first winter the Starving Season. Those who survived it do not speak of what they ate. Those who didn\'t survive it were the lucky ones.', rarity: 'uncommon' },
        world_005: { id: 'world_005', series: 'world', title: 'Year Zero', text: 'Nobody counts the old calendar anymore. Year Zero is when the Collapse happened. Everything before it is myth. Everything after it is survival.', rarity: 'rare' },
        
        // TERRACORP
        tc_001: { id: 'tc_001', series: 'terracorp', title: 'Requisition Order 17-C', text: 'All surface personnel are to be recalled. Bunker seals engage at 0400. Anyone not inside by then is outside. This is not negotiable. — TC Command', rarity: 'common' },
        tc_002: { id: 'tc_002', series: 'terracorp', title: 'Internal Memo', text: 'The populace does not need to know we had advance warning. Maintain narrative: the Collapse was unforeseen. Compartmentalize.', rarity: 'rare' },
        tc_003: { id: 'tc_003', series: 'terracorp', title: 'Deep Protocol', text: 'Project VESTIGE is greenlit. Begin stockpiling immediately. If the surface cannot be held, it will be reclaimed. On our terms.', rarity: 'legendary' },
        
        // UCR
        ucr_001: { id: 'ucr_001', series: 'ucr', title: 'Vault Manifest', text: 'Arsenal 7 contents: 14,000 small arms, 2,300 crew-served weapons, 890,000 rounds assorted. Status: SEALED. Access: DENIED.', rarity: 'common' },
        ucr_002: { id: 'ucr_002', series: 'ucr', title: 'War\'s End', text: 'The armistice was signed at 14:00 local. By 14:01, procurement had already begun stockpiling for the next one. UCR does not believe in peace. UCR believes in market cycles.', rarity: 'uncommon' },
        ucr_003: { id: 'ucr_003', series: 'ucr', title: 'The Last Contract', text: 'UCR\'s final contract was for something the board never disclosed. The payment was not in credits. The delivery was not a weapon. At least, not one anyone recognized.', rarity: 'legendary' },
        
        // DERALICT
        drl_001: { id: 'drl_001', series: 'deralict', title: 'Shift Report', text: 'Shaft 9 broke through to something at 1,400 meters. Not ore. Not rock. Foreman says to keep digging. Three workers refused. They\'ve been reassigned.', rarity: 'uncommon' },
        drl_002: { id: 'drl_002', series: 'deralict', title: 'Medical Log', text: 'Another case of the Hum. Patient reports hearing low-frequency vibrations from the deep shafts. Prescribed rest. Patient reports the Hum is louder when resting.', rarity: 'rare' },
        
        // SWORN
        swn_001: { id: 'swn_001', series: 'sworn', title: 'Resistance Broadcast', text: 'To all who listen: Terracorp has food. They have water. They have medicine. They chose to let you starve. We choose differently. — Sworn Radio', rarity: 'common' },
        swn_002: { id: 'swn_002', series: 'sworn', title: 'Dead Drop Note', text: 'Cache is under the old overpass. Third pillar from the south. Don\'t take the rifles — they\'re for the eastern push. Take only what you need. Leave the rest for those who need it more.', rarity: 'uncommon' },
        
        // BLACKREACH
        blk_001: { id: 'blk_001', series: 'blackreach', title: 'Traveler\'s Journal', text: 'I met a woman who claimed to have seen Blackreach. She described buildings without damage. Children playing. Clean water. I asked her to take me there. She said she couldn\'t remember the way back.', rarity: 'rare' },
        blk_002: { id: 'blk_002', series: 'blackreach', title: 'The Shielded', text: 'Their weapons appear in caches with no trail. No supply chain. No serial numbers. Someone is manufacturing arms at pre-war quality and distributing them anonymously. Why?', rarity: 'legendary' },
        
        // CEPHALON / THE CUBE
        cph_001: { id: 'cph_001', series: 'cephalon', title: 'First Contact', text: 'It appeared three weeks after the Collapse. No trajectory. No landing. It was simply there — a perfect geometric form hovering above the crater. It hummed.', rarity: 'rare' },
        cph_002: { id: 'cph_002', series: 'cephalon', title: 'The Frequency', text: 'The signal is real. I have measured it. 7.83 Hz — the old Schumann resonance of Earth, a planet none of us have seen. How does a Raum artifact broadcast an Earth frequency?', rarity: 'legendary' },
        cph_003: { id: 'cph_003', series: 'cephalon', title: 'Sermon Fragment', text: 'The Cube does not ask for worship. It asks for attention. Attention is the first currency. Belief is the second. The third... the third is something the body pays.', rarity: 'legendary' },
        cph_004: { id: 'cph_004', series: 'cephalon', title: '█████ LOG', text: 'Subject touched the fragment for 0.3 seconds. Subject\'s pupils dilated to ███. Subject spoke fluently in ████████ for 11 minutes. Subject has no memory of the event. Subject\'s hair is now white.', rarity: 'legendary' }
    },
    loreSeries: {
        world: { name: 'The World of Raum', icon: '[W]', color: '#8888aa' },
        terracorp: { name: 'Terracorp Files', icon: '[T]', color: '#8a2a2a' },
        ucr: { name: 'UCR Archives', icon: '[U]', color: '#6a8aaa' },
        deralict: { name: 'Deralict Logs', icon: '[D]', color: '#cc6622' },
        sworn: { name: 'Sworn Broadcasts', icon: '[S]', color: '#4a6a3a' },
        blackreach: { name: 'Blackreach Whispers', icon: '[B]', color: '#aa8833' },
        cephalon: { name: 'Cephalon Transmissions', icon: '[C]', color: '#33aaaa' }
    }
};

