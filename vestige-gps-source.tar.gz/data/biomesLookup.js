// Vestige GPS — BIOMES
// Extracted from monolith L34357-34391

export const BIOMES = {
    grassy: {
        id: 'grassy', name: 'Overgrown',
        subtitle: 'Plentiful',
        desc: 'Reclaimed land swallowed by green. Resources are plentiful — food, materials, salvage. But easy pickings attract company.',
        ground: 0x2a3a2a, groundAccent: 0x283020,
        sky: 0x5588bb, skyLow: 0x88aacc,
        skyDawn: 0xffaa77, skyDusk: 0xff7755, skyNight: 0x0a0a1e,
        mountain: 0x445566, mountainFar: 0x556677,
        accent: 0x3a5a3a, patchCol: 0x283020,
        mapColor: 0x3a5a3a
    },
    barren: {
        id: 'barren', name: 'Wasteland',
        subtitle: 'Scarce',
        desc: 'Scorched flats and dust-choked roads. Salvage is rare and worth killing for. Every supply run is a calculated risk.',
        ground: 0x3a352a, groundAccent: 0x302a22,
        sky: 0x998877, skyLow: 0xbbaa99,
        skyDawn: 0xddaa66, skyDusk: 0xcc7744, skyNight: 0x0e0a08,
        mountain: 0x554433, mountainFar: 0x665544,
        accent: 0x5a5040, patchCol: 0x302a22,
        mapColor: 0x5a5040
    },
    apocalyptic: {
        id: 'apocalyptic', name: 'Anomalous',
        subtitle: 'Swarming',
        desc: 'Collapsed structures warped by unknown forces. Hostile presence is constant — they come in numbers. Enemies are the loot source.',
        ground: 0x252525, groundAccent: 0x1a1020,
        sky: 0x556070, skyLow: 0x4a5060,
        skyDawn: 0x6a5a60, skyDusk: 0x5a3a44, skyNight: 0x060608,
        mountain: 0x2a2a30, mountainFar: 0x353540,
        accent: 0x6a4a6a, patchCol: 0x1a1020,
        mapColor: 0x6a4a6a
    }
};

