// Vestige GPS — DEFENSE_DATA
// Extracted from game_2_.html lines 571-684

export const DEFENSE_DATA = {
    // NPC name pools per foundry (quest-giver + soldier names)
    foundryNames: {
        terracorp: ['Sgt. Torres', 'Cpl. Vasquez', 'Pvt. Lin', 'Lt. Okoro', 'Spc. Reeves', 'Pvt. Marsh'],
        ucr: ['Spec. Hendricks', 'Off. Nakamura', 'Eng. Pryce', 'Cmdr. Weiss', 'Tech. Osei', 'Off. Liang'],
        deralict: ['Wrench', 'Bolt', 'Sarge', 'Junkdog', 'Rivet', 'Torque'],
        sworn: ['Scout Kael', 'Runner Mira', 'Blade Ash', 'Point Rook', 'Trail Wren', 'Edge Sable'],
        blackreach: ['Agent Null', 'Operative Six', 'Shadow', 'Cipher', 'Specter', 'Onyx'],
        cephalon: ['Unit-7', 'Resonance', 'Echo-3', 'Flux', 'Harmonic', 'Drift-9']
    },
    
    // Quest-giver dialogue tree
    dialogue: {
        intro: [
            { text: "Convoy's hit. Engine's shot, hostiles closing on every scanner.", options: null },
            { text: "We need someone covering our flank while we patch her up. You in?",
              options: [
                { label: 'Begin Defense', action: 'start_defense' },
                { label: 'What happened?', action: 'lore_1' },
                { label: 'What are we facing?', action: 'lore_2' },
                { label: 'Not now', action: 'close' }
              ]
            }
        ],
        loreResponses: {
            lore_1: { text: "Ambush about 3 clicks back. They hit the drivetrain first — knew what they were doing. Lost contact with command.", returnTo: 1 },
            lore_2: { text: "Scanners picking up movement from all quadrants. Husks, mostly. Maybe worse. It's going to get ugly.", returnTo: 1 }
        }
    },
    
    // Speech bubble lines during combat
    npcLines: {
        waveStart: ["Here they come.", "Contacts inbound.", "Weapons hot.", "Hold the line.", "Don't let them through."],
        waveEnd: ["Clear. Catch your breath.", "Good kills.", "Engine's getting there.", "Almost there."],
        checkpoint: ["Foundry's got options. Your call.", "Pick your loadout. We've got maybe 30 seconds."],
        convoyLow: ["She can't take much more!", "We're losing the convoy!", "Protect the transport!"],
        victory: ["Engine's live. We owe you one.", "She's running. Won't forget this.", "Convoy's operational. You saved lives."],
        soldierDown: ["Medic!", "I'm hit!", "Cover me!", "Going down!"],
        soldierUp: ["Back in the fight.", "I'm good.", "Still breathing."]
    },
    
    // Wave enemy composition by tier (1-12)
    waveComposition: {
        light:  { types: ['husk', 'husk_crawl', 'flicker'], caravanTargetChance: 0.2 },
        medium: { types: ['husk', 'flicker', 'host', 'spawn'], caravanTargetChance: 0.35 },
        heavy:  { types: ['husk', 'flicker', 'host', 'deadlock', 'reaper'], caravanTargetChance: 0.45 },
        intense:{ types: ['husk', 'flicker', 'host', 'deadlock', 'reaper', 'spawn'], caravanTargetChance: 0.55 }
    },
    
    // Checkpoint upgrade definitions
    checkpoints: {
        3: {
            title: 'SHIELD INSTALLATION',
            subtitle: 'The foundry can install a defensive system on the convoy.',
            upgrades: [
                { id: 'barrier_shield', name: 'Barrier Shield', desc: 'Energy wall blocks enemy pathing.\nShield HP: 60 — 20s regen cooldown.', icon: '◎', color: 0x4488cc },
                { id: 'damage_field', name: 'Damage Field', desc: 'Enemies inside take 5 DPS.\nEmitter HP: 40 — 15s cooldown.', icon: '⚡', color: 0xcc4444 },
                { id: 'repair_aura', name: 'Repair Aura', desc: 'Heals convoy 2 HP/s, player 1 HP/s.\nGenerator HP: 50 — 18s cooldown.', icon: '+', color: 0x44cc44 }
            ]
        },
        6: {
            title: 'POWER UPGRADE',
            subtitle: 'Choose how to push the advantage.',
            upgrades: [
                { id: 'foundry_arsenal', name: 'Foundry Arsenal', desc: 'Soldier damage x2, fire rate +50%.\nSplash damage on shots.', icon: '▲', color: 0xcc8844 },
                { id: 'power_surge', name: 'Power Surge', desc: 'Player +30% damage, +20% attack speed.\nLasts entire defense.', icon: '★', color: 0xccaa44 },
                { id: 'foundry_rep', name: 'Foundry Standing', desc: '+50 bits now. Bonus loot quality.\nThe foundry will remember this.', icon: '◆', color: 0xaa88cc }
            ]
        },
        9: {
            title: 'HEAVY SUPPORT',
            subtitle: 'The convoy can provide one final upgrade.',
            upgrades: [
                { id: 'manual_turret', name: 'Manual Turret', desc: 'Mount the convoy turret.\nAuto-aim, 25 dmg, overheat system.', icon: '⊕', color: 0xcc6644 },
                { id: 'reinforcements', name: 'Reinforcements', desc: 'Humvee arrives with 2 extra soldiers.\nConvoy HP +40, full heal.', icon: '▣', color: 0x44aa44 },
                { id: 'emergency_repair', name: 'Emergency Repair', desc: 'Full convoy + player heal.\nAll soldiers revived. Max HP +20.', icon: '✦', color: 0x44aacc }
            ]
        }
    },
    
    // Soldier combat stats
    soldier: {
        hp: 60,
        damage: 8,
        fireRate: 1500,     // ms between shots
        range: 130,
        leashDist: 100,     // max distance from convoy
        downTime: 12000,    // ms before recovery
        recoveryHp: 0.5,    // recover at 50% max HP
        bulletSpeed: 280,
        bulletColor: 0xccaa44
    },
    
    // Shield configs
    shields: {
        barrier_shield: { hp: 60, radius: 100, cooldown: 20000, blocksPath: true, color: 0x4488cc },
        damage_field:   { hp: 40, radius: 95, cooldown: 15000, dps: 5, color: 0xcc4444 },
        repair_aura:    { hp: 50, radius: 95, cooldown: 18000, convoyHps: 2, playerHps: 1, color: 0x44cc44 }
    },
    
    // Turret stats
    turret: {
        damage: 25,
        fireRate: 250,      // ms between shots (4/sec)
        range: 160,
        maxHeat: 100,
        heatPerShot: 3.33,  // ~30 seconds of continuous fire
        coolRate: 12.5,     // per second — 8s full cooldown
        overheatCooldown: 8000,
        bulletSpeed: 400,
        bulletColor: 0xffaa33
    }
};

