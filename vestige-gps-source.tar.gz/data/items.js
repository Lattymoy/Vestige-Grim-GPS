// Vestige GPS — ITEM_DEFS
// Extracted from game_2_.html lines 1352-1905

export const ITEM_DEFS = {
    baseItems: {
        // === WEAPONS (5 types, 2 sprite classes, RNG fire modes) ===
        // All stats are flat 1-100 scale (pierce/targetRange 1-5). Stats are BASE before tier scaling.
        rifle: { category: 'weapon', name: 'Rifle', icon: '🔫', sprite: 'rifle',
            stats: { damage: 22, fireRate: 40, accuracy: 55, crit: 22, mag: 30, reload: 50, pierce: 1, targetRange: 2 },
            fireModes: ['semi', 'burst', 'auto'],
            recoilTypes: ['stable', 'vertical', 'horizontal'] },
        mini: { category: 'weapon', name: 'Mini', icon: '🔫', sprite: 'mini',
            stats: { damage: 10, fireRate: 55, accuracy: 40, crit: 10, mag: 55, reload: 60, pierce: 1, targetRange: 1 },
            fireModes: ['auto', 'burst'],
            recoilTypes: ['erratic', 'vertical', 'stable'] },
        heavy_rifle: { category: 'weapon', name: 'Heavy Rifle', icon: '🔫', sprite: 'heavy_rifle',
            stats: { damage: 25, fireRate: 30, accuracy: 50, crit: 20, mag: 20, reload: 40, pierce: 1, targetRange: 2 },
            fireModes: ['auto', 'semi'],
            recoilTypes: ['heavy', 'vertical'] },
        handcannon: { category: 'weapon', name: 'Hand Cannon', icon: '🔫', sprite: 'handcannon',
            stats: { damage: 35, fireRate: 15, accuracy: 45, crit: 30, mag: 15, reload: 35, pierce: 1, targetRange: 2 },
            fireModes: ['semi'],
            recoilTypes: ['heavy', 'kick'] },
        sniper: { category: 'weapon', name: 'Sniper', icon: '🔫', sprite: 'sniper',
            stats: { damage: 40, fireRate: 10, accuracy: 75, crit: 40, mag: 10, reload: 30, pierce: 2, targetRange: 3 },
            fireModes: ['semi', 'bolt'],
            recoilTypes: ['kick', 'heavy'] },
        
        // === MELEE (3 types) ===
        // All stats 1-100 flat. shieldAttack base 1 for all melee. massAttack/reach/lifesteal from mods.
        blade: { category: 'melee', name: 'Blade', icon: '🔪',
            stats: { damage: 18, attackSpeed: 50, reach: 30, stagger: 10, shieldAttack: 1 } },
        blunt: { category: 'melee', name: 'Blunt', icon: '🗡',
            stats: { damage: 30, attackSpeed: 35, reach: 40, stagger: 55, shieldAttack: 1 } },
        heavy: { category: 'melee', name: 'Heavy', icon: '🔨',
            stats: { damage: 40, attackSpeed: 15, reach: 50, stagger: 65, shieldAttack: 1 } },
        
        // === GEAR (3 frames + scrap starter) ===
        // Tier-scaled stats: health, armor. Fixed stats: speed, luck, backpack.
        scrap_armor: { category: 'gear', name: 'Scrap Armor', icon: '👕', gearClass: 'scrap',
            stats: { health: 80, armor: 1, speed: 105, luck: 0, backpack: 6 },
            outfit: { shirt: { base: '#5a4a3a', light: '#6a5a4a', dark: '#4a3a2a' }, pants: { base: '#3a3a30', light: '#4a4a40' } } },
        gear_light: { category: 'gear', name: 'Light Armor', icon: '👕', gearClass: 'light',
            stats: { health: 100, armor: 3, speed: 115, luck: 8, backpack: 8, dodge: 12 },
            outfit: { shirt: { base: '#4a4a4a', light: '#5a5a5a', dark: '#3a3a3a' }, pants: { base: '#3a3a3a', light: '#4a4a4a' } } },
        gear_medium: { category: 'gear', name: 'Medium Armor', icon: '🧥', gearClass: 'medium',
            stats: { health: 175, armor: 10, speed: 100, luck: 5, backpack: 12 },
            outfit: { shirt: { base: '#3a3a3a', light: '#4a4a4a', dark: '#2a2a2a' }, pants: { base: '#2a2a2a', light: '#3a3a3a' } } },
        gear_heavy: { category: 'gear', name: 'Heavy Armor', icon: '🛡', gearClass: 'heavy',
            stats: { health: 275, armor: 18, speed: 80, luck: 2, backpack: 18 },
            outfit: { shirt: { base: '#2a2a32', light: '#3a3a42', dark: '#1a1a22' }, pants: { base: '#2a2a30', light: '#3a3a40' } } },
        
        // === AUGMENT CHIPS (Blood Forged — 4 passive, 3 active) ===
        // PASSIVE: Field Medic — auto-consume lowest bandage at 25% HP, boosts rare med drop chance
        field_medic: { category: 'augment', name: 'Field Medic', icon: '💊',
            stats: {}, desc: 'Auto-uses lowest bandage below 25% HP (30s CD). Rare meds drop more often.',
            relicType: 'passive', relicAbility: 'fieldMedic', relicCooldown: 30000 },
        // PASSIVE: Blood Pact — taking damage stacks +4% damage (max 5 stacks, 20%). Also reduces incoming damage by 3% per stack.
        blood_pact: { category: 'augment', name: 'Blood Pact', icon: '🩸',
            stats: {}, desc: 'Each hit taken: +4% damage dealt, -3% damage taken. Stacks 5x. Fades after 8s.',
            relicType: 'passive', relicAbility: 'bloodPact' },
        // PASSIVE: Lucky Ducky — +50% currency drops, +5% loot chance
        lucky_ducky: { category: 'augment', name: 'Lucky Ducky', icon: '🦆',
            stats: {}, desc: '+50% currency drops, +5% loot luck.',
            relicType: 'passive', relicAbility: 'luckyDucky' },
        // PASSIVE: Sheltered — damage reduction after exiting interior
        sheltered: { category: 'augment', name: 'Sheltered', icon: '🏠',
            stats: {}, desc: '-20% damage taken for 15s after exiting a building. 10s cooldown.',
            relicType: 'passive', relicAbility: 'sheltered', relicCooldown: 10000 },
        // ACTIVE: War Totem — place a ward that heals allies in radius + boosts damage. Bullets pass through.
        war_totem: { category: 'augment', name: 'War Totem', icon: '🛡',
            stats: {}, desc: 'Activate: Ward bubble — heals 3 HP/s, +25% damage, 8s duration. 45s CD.',
            relicType: 'active', relicAbility: 'warTotem', relicCooldown: 45000 },
        // ACTIVE: Firepower — fire slug ammo that applies Burn DOT
        firepower: { category: 'augment', name: 'Firepower', icon: '🔥',
            stats: {}, desc: 'Activate: Fire slugs for 10s — applies Burn (15 dmg/5s). 15s CD.',
            relicType: 'active', relicAbility: 'firepower', relicCooldown: 15000 },
        // ACTIVE: Sharpshooter — perfect accuracy + damage bonus
        sharpshooter: { category: 'augment', name: 'Sharpshooter', icon: '🎯',
            stats: {}, desc: 'Activate: 100% accuracy + 25% damage for 8s. 20s CD.',
            relicType: 'active', relicAbility: 'sharpshooter', relicCooldown: 20000 }
    },
    items: {
        // === BANDAGES — Channel heal, interruptible ===
        bandage: {
            id: 'bandage', category: 'consumable', subtype: 'bandage', name: 'Bandage',
            icon: '🩹', description: 'Regen 25% HP over time. Channeled — interruptible.', rarity: 'common', tier: 1,
            healPercent: 25, effect: 'channelHeal', channelTime: 3000, regenDuration: 4000
        },
        bandage_military: {
            id: 'bandage_military', category: 'consumable', subtype: 'bandage', name: 'Military Bandage',
            icon: '🩹', description: 'Regen 40% HP over time. Channeled — interruptible.', rarity: 'uncommon', tier: 2,
            healPercent: 40, effect: 'channelHeal', channelTime: 3000, regenDuration: 4000
        },
        
        // === MEDICAL KITS — Instant heal ===
        medkit: {
            id: 'medkit', category: 'consumable', subtype: 'medkit', name: 'Medical Kit',
            icon: '💊', description: 'Instantly restores 20% HP.', rarity: 'rare', tier: 3, healPercent: 20, effect: 'instantHeal'
        },
        medkit_advanced: {
            id: 'medkit_advanced', category: 'consumable', subtype: 'medkit', name: 'Advanced Medical Kit',
            icon: '💊', description: 'Instantly restores 35% HP.', rarity: 'legendary', tier: 4, healPercent: 35, effect: 'instantHeal'
        },
        
        // === GRENADES — Require lock-on target ===
        grenade_frag: {
            id: 'grenade_frag', category: 'consumable', subtype: 'grenade', name: 'Frag Grenade',
            icon: '💣', description: 'Large radius explosion. Bounces before detonating.', rarity: 'legendary', tier: 4,
            effect: 'grenade', grenadeType: 'frag', effectValue: 120, effectRadius: 100,
            fuseTime: 600, callout: 'Frag out!'
        },
        grenade_poison: {
            id: 'grenade_poison', category: 'consumable', subtype: 'grenade', name: 'Poison Grenade',
            icon: '☠', description: 'Unleashes poison gas. DOT for 10s.', rarity: 'masterForged', tier: 5,
            effect: 'grenade', grenadeType: 'poison', effectValue: 12, effectRadius: 90,
            fuseTime: 600, zoneDuration: 10000, tickInterval: 1000, callout: 'Incoming toxicity!'
        },
        grenade_inferno: {
            id: 'grenade_inferno', category: 'consumable', subtype: 'grenade', name: 'Inferno Grenade',
            icon: '🔥', description: 'Spreads fire on impact. DOT for 10s.', rarity: 'masterForged', tier: 5,
            effect: 'grenade', grenadeType: 'inferno', effectValue: 12, effectRadius: 80,
            fuseTime: 0, zoneDuration: 10000, tickInterval: 1000, callout: 'Flames inbound!'
        },
        
        // === PYLONS — Channel to place, interruptible ===
        pylon_heal: {
            id: 'pylon_heal', category: 'consumable', subtype: 'pylon', name: 'Healing Pylon',
            icon: '⛨', description: 'Drops a healing rift. Heals inside for 10s. Channeled.', rarity: 'masterForged', tier: 5,
            effect: 'pylon', pylonType: 'heal', pylonValue: 8, pylonRadius: 50,
            channelTime: 2000, zoneDuration: 10000, tickInterval: 500
        },
        pylon_damage: {
            id: 'pylon_damage', category: 'consumable', subtype: 'pylon', name: 'Damage Pylon',
            icon: '⚔', description: 'Drops a damage rift. +25% damage inside for 10s. Channeled.', rarity: 'masterForged', tier: 5,
            effect: 'pylon', pylonType: 'damage', pylonValue: 25, pylonRadius: 50,
            channelTime: 2000, zoneDuration: 10000
        },
        
        // === ENERGY DRINK — Gym enhancement consumable ===
        energy_drink: {
            id: 'energy_drink', category: 'consumable', subtype: 'energy_drink', name: 'Energy Drink',
            icon: '⚡', description: 'Use at the gym to guarantee max training results.', rarity: 'uncommon', tier: 2,
            effect: 'gym_boost'
        },
        
        // ═══════════════════════════════════════════
        // KEY ITEMS — Lootable, visible in inventory, consumed on use
        // ═══════════════════════════════════════════
        lockpick: {
            id: 'lockpick', category: 'key_item', subtype: 'lockpick', name: 'Lockpick',
            icon: '🔓', description: 'Attempt to pick a lock. Not guaranteed.', rarity: 'rare', tier: 3,
            useAction: 'lockpick'
        },
        lore_chip: {
            id: 'lore_chip', category: 'key_item', subtype: 'lore_chip', name: 'Lore Chip',
            icon: '💿', description: 'Encoded data chip. Use to unlock lore entry.', rarity: 'rare', tier: 3,
            useAction: 'lore'
        },
        toolkit: {
            id: 'toolkit', category: 'key_item', subtype: 'toolkit', name: 'Toolkit',
            icon: '🔧', description: 'Auto-completes vehicle breakdowns. Consumed on use.', rarity: 'rare', tier: 3,
            useAction: 'toolkit'
        },
        fuel_canister: {
            id: 'fuel_canister', category: 'key_item', subtype: 'fuel_canister', name: 'Fuel Canister',
            icon: '⛽', description: 'Grants 8-15 fuel.', rarity: 'uncommon', tier: 2,
            useAction: 'grant_fuel', grantMin: 8, grantMax: 15
        },
        purse: {
            id: 'purse', category: 'key_item', subtype: 'currency_grant', name: 'Purse',
            icon: '👛', description: 'Grants 10-25 bits.', rarity: 'common', tier: 1,
            useAction: 'grant_bits', grantMin: 10, grantMax: 25
        },
        wallet: {
            id: 'wallet', category: 'key_item', subtype: 'currency_grant', name: 'Wallet',
            icon: '💰', description: 'Grants 30-60 bits.', rarity: 'uncommon', tier: 2,
            useAction: 'grant_bits', grantMin: 30, grantMax: 60
        },
        scrap_box: {
            id: 'scrap_box', category: 'key_item', subtype: 'currency_grant', name: 'Scrap Box',
            icon: '📦', description: 'Grants 5-12 materials.', rarity: 'uncommon', tier: 2,
            useAction: 'grant_materials', grantMin: 5, grantMax: 12
        },
        ammo_box: {
            id: 'ammo_box', category: 'key_item', subtype: 'currency_grant', name: 'Ammunition Box',
            icon: '🎯', description: 'Grants 8-20 power ammo.', rarity: 'uncommon', tier: 2,
            useAction: 'grant_powerAmmo', grantMin: 8, grantMax: 20
        },
        
        // ═══════════════════════════════════════════
        // SCRAP MATERIALS — Salvageable at safehouse into Materials (LOCKED)
        // ═══════════════════════════════════════════
        scrap_wood: {
            id: 'scrap_wood', category: 'scrap', name: 'Scrap Wood',
            icon: '🪵', description: 'Raw wood. Scrap at safehouse.', rarity: 'common',
            scrapValue: 2
        },
        scrap_wire: {
            id: 'scrap_wire', category: 'scrap', name: 'Wire Bundle',
            icon: '🔌', description: 'Salvageable wire. Scrap at safehouse.', rarity: 'common',
            scrapValue: 3
        },
        scrap_metal: {
            id: 'scrap_metal', category: 'scrap', name: 'Metal Scrap',
            icon: '⚙', description: 'Bent metal. Scrap at safehouse.', rarity: 'common',
            scrapValue: 3
        },
        scrap_cloth: {
            id: 'scrap_cloth', category: 'scrap', name: 'Cloth Strip',
            icon: '🧵', description: 'Torn fabric. Scrap at safehouse.', rarity: 'common',
            scrapValue: 1
        },
        scrap_tech: {
            id: 'scrap_tech', category: 'scrap', name: 'Tech Component',
            icon: '💾', description: 'Electronic salvage. Scrap at safehouse.', rarity: 'uncommon',
            scrapValue: 6
        },
        
        // === HUSK REMAINS — personal effects from the Cube-turned ===
        husk_faded_id: {
            id: 'husk_faded_id', category: 'key_item', subtype: 'currency_grant', name: 'Faded ID',
            icon: '🪪', description: 'A Raumian identification card. The photo is bleached. The name is gone.',
            rarity: 'common', grantBits: 8, grantMats: 0
        },
        husk_corroded_trinket: {
            id: 'husk_corroded_trinket', category: 'key_item', subtype: 'currency_grant', name: 'Corroded Trinket',
            icon: '📿', description: 'A ring, a pendant — something personal. Tarnished beyond recognition.',
            rarity: 'common', grantBits: 12, grantMats: 0
        },
        husk_tattered_cloth: {
            id: 'husk_tattered_cloth', category: 'scrap', name: 'Tattered Garment',
            icon: '🧵', description: 'What they were wearing when it happened. Barely holds together.',
            rarity: 'common', scrapValue: 2
        },
        husk_cube_residue: {
            id: 'husk_cube_residue', category: 'scrap', name: 'Cube Residue',
            icon: '🔮', description: 'A faint crystalline buildup in the tissue. Warm to the touch.',
            rarity: 'uncommon', scrapValue: 5
        },
        husk_cracked_visor: {
            id: 'husk_cracked_visor', category: 'key_item', subtype: 'currency_grant', name: 'Cracked Visor',
            icon: '🥽', description: 'Standard-issue Raumian eye protection. Cracked clean through the lens.',
            rarity: 'uncommon', grantBits: 18, grantMats: 2
        },
        husk_memory_shard: {
            id: 'husk_memory_shard', category: 'key_item', subtype: 'lore_chip', name: 'Memory Shard',
            icon: '🧠', description: 'A sliver of neural tissue fused with Cube crystal. Something flickers inside.',
            rarity: 'rare'
        },
        
        // === FLICKER REMAINS — barely organic, mostly Cube ===
        flicker_blade_shard: {
            id: 'flicker_blade_shard', category: 'scrap', name: 'Blade Shard',
            icon: '🗡', description: 'A fragment of crystallized bone-metal. Still vibrating faintly.',
            rarity: 'uncommon', scrapValue: 4
        },
        flicker_tendril_strand: {
            id: 'flicker_tendril_strand', category: 'scrap', name: 'Tendril Strand',
            icon: '🧬', description: 'Severed tendril. Twitches on its own. Not quite dead.',
            rarity: 'common', scrapValue: 2
        },
        flicker_phase_residue: {
            id: 'flicker_phase_residue', category: 'scrap', name: 'Phase Residue',
            icon: '🔮', description: 'Iridescent dust left behind after a phase shift. Warm. Unstable.',
            rarity: 'uncommon', scrapValue: 6
        },
        flicker_cube_node: {
            id: 'flicker_cube_node', category: 'key_item', subtype: 'currency_grant', name: 'Cube Node',
            icon: '💠', description: 'A dense crystal knot embedded where a brain should be. Pulses with dim light.',
            rarity: 'rare', grantBits: 22, grantMats: 4
        },
        
        // === THE CUBE — Encrypted loot, decrypt at safehouse ===
        cube_uncommon: {
            id: 'cube_uncommon', category: 'cube', name: 'Uncommon Cube',
            icon: '🔲', description: 'Decrypt at safehouse. Contains Military-Forged gear.', rarity: 'uncommon',
            tier: 2, cubeTier: 'uncommon'
        },
        cube_rare: {
            id: 'cube_rare', category: 'cube', name: 'Rare Cube',
            icon: '🔲', description: 'Decrypt at safehouse. Contains Military-Master gear.', rarity: 'rare',
            tier: 3, cubeTier: 'rare'
        },
        cube_master: {
            id: 'cube_master', category: 'cube', name: 'Master Cube',
            icon: '🔲', description: 'Decrypt at safehouse. Contains Forged-Blood gear.', rarity: 'master',
            tier: 4, cubeTier: 'master'
        },
        cube_legendary: {
            id: 'cube_legendary', category: 'cube', name: 'Legendary Cube',
            icon: '🔲', description: 'Decrypt at safehouse. Contains Master-Blood gear.', rarity: 'legendary',
            tier: 5, cubeTier: 'legendary'
        },
        
        // === KEY/QUEST ===
        keycard_red: {
            id: 'keycard_red', category: 'key', name: 'Red Keycard',
            icon: '🔑', description: 'Opens secured doors.', rarity: 'rare'
        },
    },
    lootTables: {
        // === HUSK DROP TABLE — personal effects of the Cube-turned ===
        husk_drop: [
            { id: 'husk_tattered_cloth', weight: 30 },
            { id: 'husk_faded_id', weight: 20 },
            { id: 'husk_corroded_trinket', weight: 15 },
            { id: 'husk_cube_residue', weight: 10 },
            { id: 'husk_cracked_visor', weight: 6 },
            { id: 'bandage', weight: 12 },
            { id: 'husk_memory_shard', weight: 2 }
        ],
        
        // === FLICKER DROP TABLE — Cube-twisted remains ===
        flicker_drop: [
            { id: 'flicker_tendril_strand', weight: 30 },
            { id: 'flicker_blade_shard', weight: 25 },
            { id: 'flicker_phase_residue', weight: 12 },
            { id: 'flicker_cube_node', weight: 5 },
            { id: 'bandage', weight: 15 },
            { id: 'husk_cube_residue', weight: 8 }
        ],
        
        // === ENEMY KILL TABLES (by reach bracket) ===
        enemy_early: [ // Reach 1-2
            { id: 'bandage', weight: 18 },
            { id: 'scrap_cloth', weight: 18 },
            { id: 'scrap_wood', weight: 14 },
            { id: 'purse', weight: 5 },
            { type: 'procedural', category: 'melee', weight: 12 },
            { type: 'procedural', category: 'weapon', weight: 5 },
            { type: 'procedural', category: 'gear', weight: 2 }
        ],
        enemy_mid: [ // Reach 3-4
            { id: 'bandage_military', weight: 22 },
            { id: 'bandage', weight: 10 },
            { id: 'medkit', weight: 5 },
            { id: 'grenade_frag', weight: 3 },
            { id: 'scrap_metal', weight: 10 },
            { id: 'scrap_wire', weight: 8 },
            { id: 'scrap_tech', weight: 4 },
            { id: 'lockpick', weight: 2 },
            { type: 'procedural', category: 'melee', weight: 10 },
            { type: 'procedural', category: 'weapon', weight: 8 },
            { type: 'procedural', category: 'gear', weight: 5 },
            { type: 'procedural', category: 'augment', weight: 1 }
        ],
        enemy_late: [ // Reach 5+
            { id: 'medkit', weight: 12 },
            { id: 'medkit_advanced', weight: 5 },
            { id: 'bandage_military', weight: 8 },
            { id: 'grenade_frag', weight: 6 },
            { id: 'grenade_poison', weight: 2 },
            { id: 'grenade_inferno', weight: 2 },
            { id: 'scrap_tech', weight: 8 },
            { id: 'scrap_metal', weight: 6 },
            { id: 'lockpick', weight: 3 },
            { id: 'cube_uncommon', weight: 1 },
            { type: 'procedural', category: 'weapon', weight: 14 },
            { type: 'procedural', category: 'melee', weight: 10 },
            { type: 'procedural', category: 'gear', weight: 8 },
            { type: 'procedural', category: 'augment', weight: 3 }
        ],
        
        // === BOSS TABLES ===
        boss: [
            { id: 'medkit_advanced', weight: 15 },
            { id: 'grenade_frag', weight: 8 },
            { id: 'grenade_poison', weight: 4 },
            { id: 'grenade_inferno', weight: 4 },
            { id: 'scrap_tech', weight: 5 },
            { type: 'procedural', category: 'weapon', weight: 20 },
            { type: 'procedural', category: 'melee', weight: 15 },
            { type: 'procedural', category: 'gear', weight: 12 },
            { type: 'procedural', category: 'augment', weight: 4 },
            { id: 'cube_uncommon', weight: 3 },
            { id: 'cube_rare', weight: 2 }
        ],
        boss_high: [
            { id: 'medkit_advanced', weight: 8 },
            { id: 'grenade_poison', weight: 5 },
            { id: 'grenade_inferno', weight: 5 },
            { id: 'pylon_heal', weight: 3 },
            { id: 'pylon_damage', weight: 3 },
            { type: 'procedural', category: 'weapon', weight: 25 },
            { type: 'procedural', category: 'gear', weight: 20 },
            { type: 'procedural', category: 'augment', weight: 10 },
            { id: 'cube_rare', weight: 4 },
            { id: 'cube_master', weight: 3 },
            { id: 'cube_legendary', weight: 1 }
        ],
        
        // === CONTAINER TABLES (by building archetype) ===
        container_residential: [
            { id: 'bandage', weight: 25 },
            { id: 'scrap_cloth', weight: 18 },
            { id: 'scrap_wood', weight: 12 },
            { id: 'purse', weight: 6 },
            { type: 'procedural', category: 'melee', weight: 4 },
            { type: 'procedural', category: 'gear', weight: 3 }
        ],
        container_commercial: [
            { id: 'bandage', weight: 15 },
            { id: 'scrap_cloth', weight: 10 },
            { id: 'scrap_metal', weight: 12 },
            { id: 'bandage_military', weight: 5 },
            { id: 'wallet', weight: 4 },
            { id: 'purse', weight: 5 },
            { id: 'energy_drink', weight: 3 },
            { type: 'procedural', category: 'weapon', weight: 4 },
            { type: 'procedural', category: 'gear', weight: 3 }
        ],
        container_industrial: [
            { id: 'scrap_metal', weight: 20 },
            { id: 'scrap_wire', weight: 15 },
            { id: 'scrap_tech', weight: 5 },
            { id: 'grenade_frag', weight: 4 },
            { id: 'bandage_military', weight: 8 },
            { id: 'fuel_canister', weight: 4 },
            { id: 'scrap_box', weight: 3 },
            { id: 'ammo_box', weight: 2 },
            { type: 'procedural', category: 'weapon', weight: 8 },
            { type: 'procedural', category: 'melee', weight: 6 }
        ],
        container_medical: [
            { id: 'bandage', weight: 20 },
            { id: 'bandage_military', weight: 15 },
            { id: 'medkit', weight: 8 },
            { id: 'medkit_advanced', weight: 3 }
        ],
        container_locked: [
            { id: 'medkit', weight: 8 },
            { id: 'medkit_advanced', weight: 5 },
            { id: 'grenade_frag', weight: 5 },
            { id: 'grenade_poison', weight: 2 },
            { id: 'grenade_inferno', weight: 2 },
            { id: 'pylon_heal', weight: 2 },
            { id: 'lockpick', weight: 3 },
            { id: 'toolkit', weight: 1 },
            { id: 'ammo_box', weight: 3 },
            { id: 'fuel_canister', weight: 3 },
            { id: 'wallet', weight: 3 },
            { id: 'cube_uncommon', weight: 2 },
            { id: 'cube_rare', weight: 1 },
            { type: 'procedural', category: 'weapon', weight: 18 },
            { type: 'procedural', category: 'melee', weight: 12 },
            { type: 'procedural', category: 'gear', weight: 15 },
            { type: 'procedural', category: 'augment', weight: 5 }
        ],
        
        // === SEARCHABLE PROP TABLE ===
        prop_search: [
            { id: 'scrap_cloth', weight: 20 },
            { id: 'scrap_wood', weight: 18 },
            { id: 'scrap_wire', weight: 12 },
            { id: 'scrap_metal', weight: 10 },
            { id: 'bandage', weight: 15 },
            { id: 'purse', weight: 4 },
            { id: 'wallet', weight: 2 }
        ],
        
        // === HIDDEN CHEST TABLE ===
        chest_hidden: [
            { id: 'medkit', weight: 8 },
            { id: 'medkit_advanced', weight: 4 },
            { id: 'grenade_frag', weight: 5 },
            { id: 'grenade_poison', weight: 3 },
            { id: 'grenade_inferno', weight: 3 },
            { id: 'pylon_heal', weight: 2 },
            { id: 'pylon_damage', weight: 2 },
            { id: 'lockpick', weight: 5 },
            { id: 'toolkit', weight: 1 },
            { id: 'ammo_box', weight: 4 },
            { id: 'fuel_canister', weight: 3 },
            { id: 'wallet', weight: 3 },
            { id: 'cube_uncommon', weight: 2 },
            { id: 'cube_rare', weight: 2 },
            { type: 'procedural', category: 'weapon', weight: 18 },
            { type: 'procedural', category: 'gear', weight: 15 },
            { type: 'procedural', category: 'augment', weight: 6 },
            { type: 'procedural', category: 'melee', weight: 10 }
        ],
        
        // === SCAVENGE EVENT TABLES ===
        scavenge_gas: [
            { id: 'scrap_metal', weight: 15 },
            { id: 'scrap_wire', weight: 12 },
            { id: 'bandage', weight: 10 },
            { id: 'fuel_canister', weight: 3 },
            { id: 'energy_drink', weight: 2 },
            { type: 'procedural', category: 'weapon', weight: 5 },
            { type: 'procedural', category: 'melee', weight: 4 }
        ],
        scavenge_motel: [
            { id: 'bandage', weight: 18 },
            { id: 'bandage_military', weight: 10 },
            { id: 'medkit', weight: 4 },
            { id: 'scrap_cloth', weight: 12 },
            { id: 'purse', weight: 3 },
            { id: 'energy_drink', weight: 2 },
            { type: 'procedural', category: 'gear', weight: 5 }
        ],
        scavenge_cache: [
            { id: 'scrap_tech', weight: 8 },
            { id: 'scrap_metal', weight: 10 },
            { id: 'grenade_frag', weight: 4 },
            { id: 'bandage_military', weight: 8 },
            { id: 'lockpick', weight: 3 },
            { type: 'procedural', category: 'weapon', weight: 12 },
            { type: 'procedural', category: 'gear', weight: 8 },
            { type: 'procedural', category: 'augment', weight: 2 }
        ],
        scavenge_ambush: [
            { id: 'scrap_metal', weight: 12 },
            { id: 'scrap_wire', weight: 10 },
            { id: 'grenade_frag', weight: 10 },
            { id: 'bandage', weight: 10 },
            { type: 'procedural', category: 'weapon', weight: 8 },
            { type: 'procedural', category: 'melee', weight: 8 }
        ],
        scavenge_survivor: [
            { id: 'bandage_military', weight: 12 },
            { id: 'medkit', weight: 6 },
            { id: 'scrap_tech', weight: 6 },
            { id: 'scrap_cloth', weight: 10 },
            { type: 'procedural', category: 'gear', weight: 6 },
            { type: 'procedural', category: 'augment', weight: 2 }
        ],
        
        // === CUBE DECRYPTION TABLE (Forged+ minus Bane) ===
        cube_decrypt: [
            { type: 'procedural', category: 'weapon', weight: 25, minTier: 3 },
            { type: 'procedural', category: 'melee', weight: 20, minTier: 3 },
            { type: 'procedural', category: 'gear', weight: 25, minTier: 3 },
            { type: 'procedural', category: 'augment', weight: 8, minTier: 3 }
        ],
        
        // Legacy compat
        normal: [
            { id: 'bandage', weight: 25 },
            { id: 'scrap_cloth', weight: 12 },
            { type: 'procedural', category: 'melee', weight: 8 },
            { type: 'procedural', category: 'weapon', weight: 4 },
            { type: 'procedural', category: 'gear', weight: 2 }
        ],
        container: [
            { id: 'bandage', weight: 22 },
            { id: 'scrap_cloth', weight: 10 },
            { id: 'scrap_wood', weight: 8 },
            { id: 'bandage_military', weight: 6 },
            { type: 'procedural', category: 'melee', weight: 5 },
            { type: 'procedural', category: 'weapon', weight: 3 },
            { type: 'procedural', category: 'gear', weight: 2 }
        ]
    }
};

