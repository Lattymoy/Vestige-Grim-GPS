// Vestige GPS — BIOME_DEFS
// Extracted from game_2_.html lines 685-918

export const BIOME_DEFS = {
    biomes: {
        grassy: {
            name: 'Overgrown',
            groundColor: 0x2a3a2a,
            groundAccent: 0x283020,
            roadColor: 0x3a3530,
            buildings: [
                { type: 'house', weight: 25 },
                { type: 'house_large', weight: 12 },
                { type: 'apartment', weight: 8 },
                { type: 'shed', weight: 20 },
                { type: 'church', weight: 5 },
                { type: 'gas_station_main', weight: 5 },
                { type: 'store', weight: 8 },
                { type: 'convenience', weight: 7 },
                { type: 'park_restroom', weight: 10 }
            ],
            props: [
                { type: 'tree', weight: 28 },
                { type: 'tree_pine', weight: 12 },
                { type: 'mailbox', weight: 10 },
                { type: 'fence_h', weight: 8 },
                { type: 'bench', weight: 6 },
                { type: 'trash_can', weight: 6 },
                { type: 'car_wreck', weight: 8 },
                { type: 'lamp_post', weight: 4 },
                { type: 'collapsed_fence', weight: 10 },
                { type: 'rusted_swing_set', weight: 5 },
                { type: 'bird_bath', weight: 6 },
                { type: 'child_bicycle', weight: 4 },
                { type: 'clothesline_post', weight: 5 },
                { type: 'ivy_wall', weight: 6 },
                { type: 'doghouse', weight: 5 },
                { type: 'gutted_fridge', weight: 4 },
                { type: 'playground_slide', weight: 3 },
                { type: 'lawn_chair', weight: 6 },
                { type: 'tire_stack', weight: 5 },
                { type: 'porch_steps', weight: 4 }
            ],
            propCount: [8, 14],
            buildingCount: [2, 4],
            shellCount: [0, 1],     // open ruins — walk-through, no scene transition
            sceneCount: [0, 1],     // environmental storytelling scenes per zone
            enemyTypes: ['husk', 'husk_crawl', 'flicker'],
            enemyCount: [3, 6],
            enemyStatScale: 1.0,
            mapColor: 0x3a5a3a,
            mapAccent: 0x2a4a2a,
            // Plentiful — lots of loot, common quality
            lootQuantityMult: 1.4,    // more items per container search
            lootQualityBonus: -0.05,  // slightly worse quality rolls
            enemyDropMult: 0.8,       // enemies drop less (fewer dangerous enemies)
            searchableMult: 1.3       // more searchable objects spawn
        },
        barren: {
            name: 'Wasteland',
            groundColor: 0x3a352a,
            groundAccent: 0x302a22,
            roadColor: 0x3a3835,
            buildings: [
                { type: 'shed', weight: 20 },
                { type: 'small_shed', weight: 12 },
                { type: 'gas_station_main', weight: 12 },
                { type: 'rest_stop', weight: 12 },
                { type: 'warehouse', weight: 8 },
                { type: 'store', weight: 8 },
                { type: 'garage', weight: 10 },
                { type: 'motel', weight: 8 },
                { type: 'bunker', weight: 5 },
                { type: 'ruins', weight: 5 }
            ],
            props: [
                { type: 'dead_tree', weight: 18 },
                { type: 'oil_barrel', weight: 14 },
                { type: 'barrier', weight: 10 },
                { type: 'sign_post', weight: 8 },
                { type: 'car_wreck', weight: 12 },
                { type: 'fence_h', weight: 5 },
                { type: 'crate_stack', weight: 4 },
                { type: 'truck_wreck', weight: 4 },
                { type: 'bleached_skeleton', weight: 8 },
                { type: 'rock_cairn', weight: 6 },
                { type: 'abandoned_tent', weight: 5 },
                { type: 'dried_wellhead', weight: 4 },
                { type: 'barbed_wire', weight: 7 },
                { type: 'collapsed_billboard', weight: 3 },
                { type: 'cracked_cistern', weight: 4 },
                { type: 'dust_generator', weight: 3 },
                { type: 'tipped_portapotty', weight: 3 },
                { type: 'exposed_foundation', weight: 5 },
                { type: 'buried_road_sign', weight: 6 },
                { type: 'concrete_barrier_wl', weight: 5 }
            ],
            propCount: [4, 8],
            buildingCount: [1, 3],
            shellCount: [1, 3],     // Wasteland has more ruins than intact buildings
            sceneCount: [0, 1],     // environmental storytelling scenes per zone
            enemyTypes: ['husk', 'flicker', 'host'],
            enemyCount: [3, 6],
            enemyStatScale: 1.0,
            mapColor: 0x5a5040,
            mapAccent: 0x4a4030,
            // Scarce — fewer finds, but better quality
            lootQuantityMult: 0.7,    // fewer items per search
            lootQualityBonus: 0.12,   // better quality rolls
            enemyDropMult: 1.0,       // normal enemy drops
            searchableMult: 0.6       // fewer searchable objects
        },
        apocalyptic: {
            name: 'Anomalous',
            groundColor: 0x252525,
            groundAccent: 0x1a1020,
            roadColor: 0x2a2a28,
            buildings: [
                { type: 'store', weight: 15 },
                { type: 'warehouse', weight: 14 },
                { type: 'office_building', weight: 10 },
                { type: 'hospital_main', weight: 4 },
                { type: 'restaurant', weight: 10 },
                { type: 'pharmacy', weight: 8 },
                { type: 'factory', weight: 6 },
                { type: 'garage', weight: 7 },
                { type: 'storage_unit', weight: 5 },
                { type: 'apartment', weight: 6 },
                { type: 'loading_dock', weight: 5 },
                { type: 'police_station', weight: 4 },
                { type: 'ruins', weight: 6 }
            ],
            props: [
                { type: 'car_wreck', weight: 18 },
                { type: 'dumpster', weight: 10 },
                { type: 'fire_hydrant', weight: 6 },
                { type: 'lamp_post', weight: 5 },
                { type: 'shipping_container', weight: 6 },
                { type: 'trash_can', weight: 6 },
                { type: 'crate_stack', weight: 5 },
                { type: 'truck_wreck', weight: 3 },
                { type: 'crystal_spire', weight: 12 },
                { type: 'cube_node', weight: 6 },
                { type: 'organ_pillar', weight: 8 },
                { type: 'corrupted_lamp', weight: 7 },
                { type: 'fungal_cluster', weight: 10 },
                { type: 'cephalon_shrine', weight: 3 },
                { type: 'converted_tree', weight: 8 },
                { type: 'metallic_vine', weight: 6 },
                { type: 'shattered_cube', weight: 5 },
                { type: 'bone_arch', weight: 3 },
                { type: 'spore_tower', weight: 5 },
                { type: 'geometric_crater', weight: 7 },
                { type: 'converted_dumpster', weight: 4 }
            ],
            propCount: [12, 20],
            buildingCount: [3, 5],
            shellCount: [0, 2],     // some structures breached by Cube growth
            sceneCount: [0, 1],     // environmental storytelling scenes per zone
            enemyTypes: ['husk', 'deadlock', 'host', 'spawn', 'flicker', 'reaper'],
            enemyCount: [3, 6],
            enemyStatScale: 1.0,
            mapColor: 0x6a4a6a,
            mapAccent: 0x4a2a4a,
            // Swarming — enemies are the loot source
            lootQuantityMult: 1.0,    // normal container loot
            lootQualityBonus: 0.05,   // slightly better quality
            enemyDropMult: 1.6,       // enemies drop significantly more
            searchableMult: 0.9       // slightly fewer searchables (enemies compensate)
        }
    },
    worldNotes: {
        grassy: [
            { id: 'OG01', format: 'Handwritten on a utility bill', text: "Lisa took the kids to her mother's. I told her I'd catch up after I boarded the windows. That was three days ago. Roads are gone. Not blocked \u2014 gone. The overpass on Route 9 is just not there anymore. I don't know what that means. I'm going to try the creek path tomorrow." },
            { id: 'OG02', format: 'Spray-painted on a garage door', text: "ALIVE INSIDE \u2014 DO NOT BOARD UP \u2014 3 PEOPLE" },
            { id: 'OG03', format: 'Spiral notebook page, torn out', text: "Day 11. Water from the creek tastes wrong but we're boiling it. Marcus says it's fine. Marcus also said the Guard was coming and that was a week ago. Found a pharmacy on Elm \u2014 already hit. Got ibuprofen and bandages from under the register where nobody checked. Small wins." },
            { id: 'OG04', format: 'Sticky note on a refrigerator', text: "DO NOT EAT the canned pears. Something is wrong with them. Tyler threw up for six hours. \u2014 S" },
            { id: 'OG05', format: "Child's notebook, crayon", text: "Miss Karen says we cant go outside anymore. Daddy didn't come for pickup. Aiden says his mom is sick. I dont like sleeping at school. When is it over" },
            { id: 'OG06', format: 'Printed flyer, water-damaged', text: "COMMUNITY MEETING \u2014 Greenfield Elementary Gym \u2014 7PM Thursday. Topics: Water distribution, perimeter volunteers needed, medical supply inventory. BRING YOUR OWN CHAIR. Do NOT bring weapons inside the building. This is not negotiable. \u2014 Greenfield Residents Council" },
            { id: 'OG07', format: 'Journal entry, leather-bound', text: "We agreed to share the generator but the Hendersons are running it all night. You can hear it from three blocks. Might as well hang a sign that says 'we have electricity, come take our stuff.' I talked to Dale about it and he just shrugged. People can't think past tonight. That's the problem. Nobody's planning for week two because nobody believes there'll be a week two." },
            { id: 'OG08', format: 'Marker on a paper bag', text: "Seed kit: tomato, beans, squash, basil. If you find this and I'm not here, plant them. West-facing beds get the most light. Don't bother with the corn \u2014 soil here is too acidite. Good luck. \u2014 M.W." },
            { id: 'OG09', format: 'Letter, unsealed envelope', text: "Mom \u2014 I know you said don't come back to the city but I have to tell you what happened at the plant. They knew. Before the Collapse, before any of it. Terracorp had people in hazmat suits three weeks before the public evac. I saw the trucks myself. Whatever they were moving, it wasn't equipment. I'm not going to write what I think it was. I'll tell you in person. Stay inside. Lock everything. I'm leaving tonight. \u2014 R" },
            { id: 'OG10', format: 'Scratched into a door frame', text: "J + K + baby \u2014 headed east toward UCR camp. Feb? March? Lost track. If you're reading this we didn't make it back. Tell her we tried." },
            { id: 'OG11', format: 'Napkin, ballpoint pen', text: "Trade rates at the school: 1 can food = 2 water bottles. 1 battery = 3 cans. Antibiotics = name your price. Nobody's trading ammo anymore. Bad sign." },
            { id: 'OG12', format: 'Taped note on a door', text: "PICKED CLEAN. Don't waste your time. Insulin is gone. Epipens gone. Inhalers gone. If you need prescription meds, try the vet clinic on Parker. Same compounds, different labels. \u2014 someone who checked" },
        ],
        barren: [
            { id: 'WL01', format: 'Marker on duct tape, stuck to a dashboard', text: "Heading south. Fuel for 40mi maybe. If the bridge at Kellner is out I don't know. Will mark the route. Look for blue flags." },
            { id: 'WL02', format: 'Scratched into concrete with a nail', text: "WELL DRY 4 WEEKS. CREEK DRY 2 WEEKS. RAIN 0." },
            { id: 'WL03', format: 'Pencil on cardboard', text: "To whoever raided our cache \u2014 you left the medical supplies. Thank you. If it was on purpose, you're decent people and I hope you make it. If it was an accident, please don't come back." },
            { id: 'WL04', format: 'Logbook, spiral-bound', text: "Entry 47. Generator failed. Battery backup will last two days. Opening the blast door means exposure but staying means dark. Dark means we can't see the vents. Last time we couldn't see the vents, something got in. I'll take the sun. Packing out at dawn." },
            { id: 'WL05', format: 'Spray paint on road surface', text: "BRIDGE OUT 2KM \u2192" },
            { id: 'WL06', format: 'Folded paper in a glass jar', text: "Elise Markham. Born August 3. Died here. She was brave and she was tired and she decided. We didn't try to stop her. That haunts me. But I think she earned the right. We buried her east of the marker, three feet. If her family comes looking, she's here. She's home now. \u2014 Cpl. Torres" },
            { id: 'WL07', format: "Crayon on a paper plate", text: "DAD WENT TO FIND WATER. STAYING IN THE VAN. IF SOMEONE FINDS THIS PLEASE HELP US. WE ARE KIDS." },
            { id: 'WL08', format: 'Typed, laminated card', text: "CACHE 7-B. Contents: 14 cans protein, 6 water purification tabs, 1 med kit, 1 thermal blanket, 1 flashlight w/ batteries. Resupply date: OVERDUE. If you are not the assigned resupply team, leave this cache sealed. Someone is counting on it. \u2014 Sworn Logistics, Cell 9" },
            { id: 'WL09', format: 'Pen on a fuel receipt', text: "Traded the shotgun for 6 gallons. Hated it but we can't eat a shotgun. Man said Sworn has a camp past the salt flats. 50 miles. That's two days walking. One if we push. Starting tomorrow morning." },
            { id: 'WL10', format: 'Permanent marker on a concrete barrier', text: "TERRACORP CHECKPOINT \u2014 DO NOT APPROACH FROM SOUTH. THEY SHOOT. GO AROUND. 4MI DETOUR WEST THROUGH DRY WASH." },
            { id: 'WL11', format: 'Burned edge paper, partial', text: "...can't be sure it's contagious but we can't take the risk. Three more showing symptoms. The sores match what Delta team reported near the\u2014 ...decided to burn everything they touched. Clothes, bedding, the shelter itself. God forgive us if we're wrong about this." },
            { id: 'WL12', format: 'Marker on a bedsheet, staked to ground', text: "NEED PICKUP \u2014 4 SURVIVORS \u2014 NO VEHICLE \u2014 SIGNAL FIRE AT NIGHT" },
        ],
        apocalyptic: [
            { id: 'AN01', format: 'Field journal, waterproof notebook', text: "Day 3 in the zone. Readings are off the chart but command says push to grid reference 7-7. Miller is hearing things \u2014 says it sounds like math. Not numbers. The structure of math. I don't know what that means. I told him to drink water and shut up. His nose started bleeding after lunch. Mine too. Didn't tell him that." },
            { id: 'AN02', format: 'Etched into Cube material', text: "IT DOESN'T HURT. THAT'S THE WORST PART." },
            { id: 'AN03', format: 'Folded letter in a plastic bag', text: "Brother Maren \u2014 I felt it last night. During the Third Silence, when we knelt, I felt the resonance in my teeth. My fillings. It vibrates at a frequency I can't name but my body already knows. The others felt it too. Sister Dahl wept. Not from fear. From recognition. We are not worshipping something alien. We are remembering something forgotten. The Cube does not teach. It reminds. Come join us. Leave your weapons at the boundary. You won't need them. You won't want them. \u2014 Adherent Voss" },
            { id: 'AN04', format: 'Terminal screen, still powered', text: "LOG 0047 // AUTOMATED ENTRY // DR. CHEN NOT RESPONDING.\nTissue sample 12-F continues geometric restructuring. Cell walls now hexagonal. Mitosis replaced by unknown division process \u2014 cells split along angular planes. Sample no longer classifiable as biological.\nNOTE: Sample was a standard biopsy from Dr. Chen's forearm, taken 72 hours ago. Dr. Chen's current forearm does not match the sample. His tissue is advancing faster than the sample. Quarantine escalation requested. Dr. Chen is not in his quarters. Door locked from inside. Window was not broken. Window was not opened. Window is gone." },
            { id: 'AN05', format: 'Marker on a torn map', text: "Safe corridor closes at sundown. DO NOT be in the zone after dark. The geometry changes at night. Paths that existed at noon do not exist at midnight. This is not metaphor. Grid reference 4-2 to 6-8 passable 0600-1800 ONLY. After 1800, that space is occupied. By what: unclear. Recommend thermal imaging. Recommend not looking directly." },
            { id: 'AN06', format: 'Audio log transcript, pinned to wall', text: "TRANSCRIPT \u2014 CPL REYES, DEBRIEFING 09\nQ: What did you see in the structure?\nA: It was... organized. Not like a building. Like an organ. Everything had a function. Walls were moving. Not fast. Breathing. The floor was warm.\nQ: Were there hostiles?\nA: I don't think hostile is the right word. There were shapes. They looked at us. Not with eyes. They oriented. Like an antenna.\nQ: Did they engage?\nA: They let us in. That's what I can't stop thinking about. The door opened when we approached. It knew we were coming. It let us in and it let us leave. I think it was showing us something." },
            { id: 'AN07', format: 'Precise stencil graffiti', text: "YOU ARE NOW ENTERING CUBE INFLUENCE RADIUS. EXPOSURE LIMIT: 4 HOURS. SYMPTOMS BEYOND 4H: Nosebleed. Tinnitus. Geometric visual artifacts. Pattern recognition errors. Certainty. TURN BACK. THIS IS NOT A SUGGESTION. \u2014 Sworn Recon, Fireteam Echo" },
            { id: 'AN08', format: 'Scrawled in blood on tile', text: "it's not killing us. it's finishing us." },
            { id: 'AN09', format: 'Research note, typed, coffee-stained', text: "Cube material does not reflect or absorb light in any documented manner. It renders. The surface produces an image of what it should look like based on viewing angle. Remove the viewer and the surface is not dark, not light, not any color. It is unparseable. The material does not exist in a visual state without an observer. I have read this sentence back four times and I am aware of how it sounds. I am requesting transfer." },
            { id: 'AN10', format: 'Torn prayer book, margin notes', text: "[Printed: 'And the light shall guide the faithful through darkness\u2014']\nMargin note in pen: 'not light. not dark. the cube is a third thing. we don't have a word for it yet. faith is the closest we come. faith is belief without comprehension. that is exactly what the Cube requires. not worship. not understanding. presence.'" },
            { id: 'AN11', format: 'Dog tags + folded note', text: "Pvt. Adrienne Cole. SN 7741-902. Fireteam Echo.\nShe went in to pull Chen out. She was in the structure for eleven minutes. She came back. She sat down. She said, 'It's beautiful in there.' She hasn't spoken since. That was six days ago. Her eyes are open. She eats if you feed her. She breathes. But Adrienne is not in there anymore. Whatever came back is waiting for something. \u2014 Sgt. Okafor" },
            { id: 'AN12', format: 'Hasty marker on a wall', text: "CEPHALON ARE NOT FRIENDLIES. Repeat: NOT friendly. They will offer food and shelter. They will not lock your door. You will wake up at the node. You will not remember walking there. Three of us woke up kneeling. GET OUT." },
        ],
    },
    storyScenes: {
        grassy: [
            { id: 'lastBarbecue', name: 'The Last Barbecue', footprint: { w: 60, h: 40 } },
            { id: 'memorialWall', name: 'The Memorial Wall', footprint: { w: 50, h: 35 } },
            { id: 'theQueue', name: 'The Queue', footprint: { w: 70, h: 30 } },
            { id: 'gardenOvergrown', name: 'The Garden That Kept Going', footprint: { w: 55, h: 40 } }
        ],
        barren: [
            { id: 'thePyre', name: 'The Pyre', footprint: { w: 50, h: 50 } },
            { id: 'waterWasHere', name: 'Water Was Here', footprint: { w: 60, h: 40 } },
            { id: 'theDig', name: 'The Dig', footprint: { w: 45, h: 45 } },
            { id: 'lastGasStation', name: 'The Last Gas Station', footprint: { w: 65, h: 45 } }
        ],
        apocalyptic: [
            { id: 'fallenPatrol', name: 'The Patrol That Didn\'t Report', footprint: { w: 55, h: 45 } },
            { id: 'cephalonCamp', name: 'Cephalon Camp', footprint: { w: 60, h: 55 } },
            { id: 'theOffering', name: 'The Offering', footprint: { w: 45, h: 40 } },
            { id: 'barricadeInward', name: 'The Barricade That Faced Inward', footprint: { w: 55, h: 55 } }
        ]
    }
};

