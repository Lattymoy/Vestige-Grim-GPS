// Vestige GPS — Data barrel export
// Import any data module from here
import { BIOME_DEFS } from './biomes.js';
import { CONFIG } from './config.js';
import { DEFENSE_DATA } from './defense.js';
import { ENEMY_DEFS } from './enemies.js';
import { ITEM_DEFS } from './items.js';
import { LOCATION_DEFS } from './locations.js';
import { LORE_DATA } from './lore.js';
import { WEAPON_SPRITE_DATA } from './weaponSprites.js';

export { LORE_DATA } from './lore.js';
export { ENEMY_DEFS } from './enemies.js';
export { DEFENSE_DATA } from './defense.js';
export { BIOME_DEFS } from './biomes.js';
export { LOCATION_DEFS } from './locations.js';
export { ITEM_DEFS } from './items.js';
export { WEAPON_SPRITE_DATA } from './weaponSprites.js';
export { CONFIG } from './config.js';
