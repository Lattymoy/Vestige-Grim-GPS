// Vestige GPS — GrimFont
// Extracted from monolith L5540-5731

export const GrimFont = {
    charSet: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.:!?-+\'"/(),%#@→←↑↓♦ ',
    charW: 24,
    charH: 32,
    built: false,
    
    build(scene) {
        if (this.built && scene.textures.exists('grimFont')) return;
        
        const chars = this.charSet;
        const cw = this.charW;
        const ch = this.charH;
        const cols = chars.length;
        const canvas = document.createElement('canvas');
        canvas.width = cw * cols;
        canvas.height = ch;
        const ctx = canvas.getContext('2d');
        
        // Seed random for consistent weathering
        let seed = 42;
        const sRand = () => { seed = (seed * 16807 + 0) % 2147483647; return (seed - 1) / 2147483646; };
        
        for (let i = 0; i < cols; i++) {
            const char = chars[i];
            const ox = i * cw;
            
            ctx.save();
            ctx.beginPath();
            ctx.rect(ox, 0, cw, ch);
            ctx.clip();
            
            if (char === ' ') { ctx.restore(); continue; }
            
            // Shadow
            ctx.fillStyle = '#0a0a0a';
            ctx.font = `bold ${ch - 6}px serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(char, ox + cw/2 + 1, ch/2 + 1);
            
            // Main fill — warm bone/parchment
            const grad = ctx.createLinearGradient(ox, 4, ox, ch - 4);
            grad.addColorStop(0, '#e8ddd0');
            grad.addColorStop(0.5, '#d8cbb8');
            grad.addColorStop(1, '#c4b8a4');
            ctx.fillStyle = grad;
            ctx.fillText(char, ox + cw/2, ch/2);
            
            // Weathering scratches per character
            ctx.globalCompositeOperation = 'destination-out';
            const scratchCount = 2 + Math.floor(sRand() * 3);
            for (let s = 0; s < scratchCount; s++) {
                const sx = ox + sRand() * cw;
                const sy = sRand() * ch;
                ctx.beginPath();
                ctx.moveTo(sx, sy);
                ctx.lineTo(sx + sRand() * 10 - 5, sy + sRand() * 4 - 2);
                ctx.lineWidth = sRand() * 1.2 + 0.3;
                ctx.stroke();
            }
            ctx.globalCompositeOperation = 'source-over';
            
            // Tiny dark distress spots
            for (let d = 0; d < 3; d++) {
                ctx.fillStyle = `rgba(10,10,10,${sRand() * 0.3})`;
                ctx.fillRect(ox + sRand() * cw, sRand() * ch, sRand() * 2 + 0.5, sRand() * 1.5 + 0.5);
            }
            
            ctx.restore();
        }
        
        // Register as spritesheet
        scene.textures.addSpriteSheet('grimFont', canvas, { frameWidth: cw, frameHeight: ch });
        this.built = true;
        
        // Also build the rust/blood variant for "GRIM" style text
        this.buildRustVariant(scene);
    },
    
    buildRustVariant(scene) {
        if (scene.textures.exists('grimFontRust')) return;
        
        const chars = this.charSet;
        const cw = this.charW;
        const ch = this.charH;
        const cols = chars.length;
        const canvas = document.createElement('canvas');
        canvas.width = cw * cols;
        canvas.height = ch;
        const ctx = canvas.getContext('2d');
        
        let seed = 77;
        const sRand = () => { seed = (seed * 16807 + 0) % 2147483647; return (seed - 1) / 2147483646; };
        
        for (let i = 0; i < cols; i++) {
            const char = chars[i];
            const ox = i * cw;
            
            ctx.save();
            ctx.beginPath();
            ctx.rect(ox, 0, cw, ch);
            ctx.clip();
            
            if (char === ' ') { ctx.restore(); continue; }
            
            // Shadow
            ctx.fillStyle = '#0a0a0a';
            ctx.font = `bold ${ch - 6}px serif`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(char, ox + cw/2 + 1, ch/2 + 1);
            
            // Rust gradient
            const grad = ctx.createLinearGradient(ox, 2, ox, ch - 2);
            grad.addColorStop(0, '#cc8844');
            grad.addColorStop(0.35, '#bb6633');
            grad.addColorStop(0.65, '#994422');
            grad.addColorStop(1, '#773320');
            ctx.fillStyle = grad;
            ctx.fillText(char, ox + cw/2, ch/2);
            
            // Heavier scratches
            ctx.globalCompositeOperation = 'destination-out';
            const scratchCount = 3 + Math.floor(sRand() * 3);
            for (let s = 0; s < scratchCount; s++) {
                const sx = ox + sRand() * cw;
                const sy = sRand() * ch;
                ctx.beginPath();
                ctx.moveTo(sx, sy);
                ctx.lineTo(sx + sRand() * 12 - 6, sy + sRand() * 5 - 2);
                ctx.lineWidth = sRand() * 1.8 + 0.5;
                ctx.stroke();
            }
            ctx.globalCompositeOperation = 'source-over';
            
            // Drip marks on some characters
            if (sRand() > 0.6) {
                const dx = ox + cw * 0.3 + sRand() * cw * 0.4;
                const dLen = 3 + sRand() * 6;
                ctx.fillStyle = `rgba(${100 + Math.floor(sRand()*40)},${40 + Math.floor(sRand()*20)},${15 + Math.floor(sRand()*15)},${0.2 + sRand()*0.15})`;
                ctx.fillRect(dx, ch - 4, 1, dLen);
            }
            
            ctx.restore();
        }
        
        scene.textures.addSpriteSheet('grimFontRust', canvas, { frameWidth: cw, frameHeight: ch });
    },
    
    // Draw text using the grim font — returns a container
    drawText(scene, x, y, text, options = {}) {
        const {
            scale = 1,
            rust = false,
            spacing = 0,
            depth = 10,
            alpha = 1,
            center = true
        } = options;
        
        const key = rust ? 'grimFontRust' : 'grimFont';
        const chars = this.charSet;
        const cw = this.charW * scale;
        const gap = spacing * scale;
        const str = text.toUpperCase();
        
        const container = scene.add.container(x, y).setDepth(depth).setAlpha(alpha);
        
        let cx = 0;
        const images = [];
        for (let i = 0; i < str.length; i++) {
            const ch = str[i];
            const idx = chars.indexOf(ch);
            if (idx === -1) { cx += cw * 0.5; continue; } // unknown char = half space
            
            const img = scene.add.image(cx, 0, key, idx).setScale(scale).setOrigin(0, 0.5);
            container.add(img);
            images.push(img);
            cx += cw + gap;
        }
        
        // Center the container on the x position
        if (center && images.length > 0) {
            const totalW = cx - gap;
            container.x = x - totalW / 2;
        }
        
        container._grimImages = images;
        container._grimTotalWidth = cx - gap;
        return container;
    }
};

