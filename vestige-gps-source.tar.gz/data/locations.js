// Vestige GPS — LOCATION_DEFS
// Extracted from game_2_.html lines 919-1351

export const LOCATION_DEFS = {
    locations: {
        // --- SCAVENGE LOCATIONS ---
        gas_station: {
            category: 'scavenge', buildingTemplate: 'gas_station_main',
            biomeWeight: { grassy: 15, barren: 35, apocalyptic: 20 },
            names: { prefixes: ['Dusty Pines', 'Route 9', 'Last Mile', 'Crossroads', 'Red Mesa', 'Broken Arrow', 'Sunset', 'Three Forks', 'Mile Marker', 'Lone Star'], suffixes: ['Gas', 'Fuel Stop', 'Pumps'] },
            lootTable: 'container_commercial', lootModifiers: { fuel: 3.0, consumable: 1.5 },
            storyChance: 0.10, enemyMod: 0.8, icon: '⛽'
        },
        pharmacy: {
            category: 'scavenge', buildingTemplate: 'pharmacy',
            biomeWeight: { grassy: 10, barren: 15, apocalyptic: 30 },
            names: { prefixes: ['QuickCare', 'MedPlus', 'Greenleaf', 'AllHealth', 'Valley', 'Sunrise', 'ClearView'], suffixes: ['Pharmacy', 'Drug', 'Medical'] },
            lootTable: 'container_medical', lootModifiers: { medical: 3.0, consumable: 1.5 },
            storyChance: 0.12, enemyMod: 1.0, icon: '💊'
        },
        hardware_store: {
            category: 'scavenge', buildingTemplate: 'store',
            biomeWeight: { grassy: 20, barren: 25, apocalyptic: 15 },
            names: { prefixes: ['BuildRight', 'Iron Oak', 'Hammer & Nail', 'Trusty', 'Raum Valley', 'HardLine'], suffixes: ['Hardware', 'Supply Co.', 'Tools'] },
            lootTable: 'container_industrial', lootModifiers: { weapon_mod: 2.0, crafting: 3.0 },
            storyChance: 0.08, enemyMod: 0.9, icon: '🔧'
        },
        grocery: {
            category: 'scavenge', buildingTemplate: 'store',
            biomeWeight: { grassy: 30, barren: 15, apocalyptic: 20 },
            names: { prefixes: ['FreshMart', 'Green Valley', 'Corner', 'Daily', 'SaveMore', 'Hometown', 'BrightLeaf'], suffixes: ['Grocery', 'Market', 'Foods'] },
            lootTable: 'container_commercial', lootModifiers: { consumable: 3.0, medical: 1.2 },
            storyChance: 0.08, enemyMod: 0.8, icon: '🛒'
        },
        house: {
            category: 'scavenge', buildingTemplate: 'house',
            biomeWeight: { grassy: 35, barren: 10, apocalyptic: 15 },
            names: { prefixes: ['Oak', 'Maple', 'Elm', 'Cedar', 'Pine', 'Birch', 'Willow', 'Ash', 'Walnut', 'Poplar'], suffixes: ['St. House', 'Ave. Home', 'Lane Place'] },
            lootTable: 'container_residential', lootModifiers: { general: 1.5 },
            storyChance: 0.15, enemyMod: 0.7, icon: '🏠'
        },
        apartment: {
            category: 'scavenge', buildingTemplate: 'apartment',
            biomeWeight: { grassy: 10, barren: 10, apocalyptic: 35 },
            names: { prefixes: ['Skyline', 'Metro', 'Cornerstone', 'Greystone', 'Parkview', 'Highrise', 'Summit'], suffixes: ['Apartments', 'Tower', 'Flats'] },
            lootTable: 'container_residential', lootModifiers: { general: 1.5, weapon: 1.2 },
            storyChance: 0.12, multiStory: true, floors: [2, 3], hasRoofDeck: true,
            enemyMod: 1.3, icon: '🏢'
        },
        warehouse: {
            category: 'scavenge', buildingTemplate: 'warehouse',
            biomeWeight: { grassy: 10, barren: 20, apocalyptic: 30 },
            names: { prefixes: ['Consolidated', 'Pacific', 'Atlas', 'Iron Gate', 'Blackwall', 'Regional', 'GridLock'], suffixes: ['Warehouse', 'Storage', 'Depot'] },
            lootTable: 'container_industrial', lootModifiers: { general: 1.5, powerAmmo: 2.0 },
            storyChance: 0.10, enemyMod: 1.4, icon: '📦'
        },
        auto_shop: {
            category: 'scavenge', buildingTemplate: 'garage',
            biomeWeight: { grassy: 15, barren: 25, apocalyptic: 15 },
            names: { prefixes: ['QuickFix', 'Axle', 'Iron Horse', 'RoadKing', 'Gearhead', 'Torque'], suffixes: ['Auto', 'Garage', 'Motors'] },
            lootTable: 'container_industrial', lootModifiers: { weapon_mod: 2.0, crafting: 2.5 },
            storyChance: 0.08, enemyMod: 0.9, icon: '🔩'
        },
        motel: {
            category: 'scavenge', buildingTemplate: 'motel',
            biomeWeight: { grassy: 10, barren: 30, apocalyptic: 15 },
            names: { prefixes: ['Sunset', 'Cactus', 'Starlight', 'Blue Ridge', 'Wayward', 'Neon', 'Dusty Trail'], suffixes: ['Motel', 'Inn', 'Lodge'] },
            lootTable: 'container_residential', lootModifiers: { consumable: 1.5, medical: 1.3 },
            storyChance: 0.15, enemyMod: 0.8, icon: '🛏'
        },
        diner: {
            category: 'scavenge', buildingTemplate: 'restaurant',
            biomeWeight: { grassy: 15, barren: 25, apocalyptic: 15 },
            names: { prefixes: ['Rosie\'s', 'The Silver', 'Route 66', 'Copper Kettle', 'Rusty Spoon', 'Moonlight'], suffixes: ['Diner', 'Grill', 'Cafe'] },
            lootTable: 'container_commercial', lootModifiers: { consumable: 2.5 },
            storyChance: 0.12, enemyMod: 0.7, icon: '🍽'
        },
        police_station: {
            category: 'scavenge', buildingTemplate: 'police_station',
            biomeWeight: { grassy: 8, barren: 15, apocalyptic: 25 },
            names: { prefixes: ['District', 'Central', 'Raum County', 'Precinct 9', 'North', 'South'], suffixes: ['Police', 'Precinct', 'Station'] },
            lootTable: 'container_locked', lootModifiers: { weapon: 2.0, powerAmmo: 3.0 },
            storyChance: 0.15, enemyMod: 1.3, icon: '🚔'
        },
        church: {
            category: 'scavenge', buildingTemplate: 'church',
            biomeWeight: { grassy: 20, barren: 12, apocalyptic: 12 },
            names: { prefixes: ['St. Elara\'s', 'Our Lady of', 'First Light', 'Redemption', 'Grace', 'Shepherd\'s'], suffixes: ['Church', 'Chapel', 'Parish'] },
            lootTable: 'container_residential', lootModifiers: { general: 1.0 },
            storyChance: 0.35, enemyMod: 0.5, icon: '⛪'
        },
        school: {
            category: 'scavenge', buildingTemplate: 'office_building',
            biomeWeight: { grassy: 20, barren: 8, apocalyptic: 12 },
            names: { prefixes: ['Raum Valley', 'Westfield', 'Northridge', 'Pine Hill', 'Clearwater', 'Blackwood'], suffixes: ['Elementary', 'School', 'Academy'] },
            lootTable: 'container_residential', lootModifiers: { general: 1.2 },
            storyChance: 0.25, enemyMod: 0.8, icon: '🏫'
        },
        research_lab: {
            category: 'scavenge', buildingTemplate: 'factory',
            biomeWeight: { grassy: 5, barren: 10, apocalyptic: 20 },
            names: { prefixes: ['Terracorp', 'UCR', 'Deralict', 'Sworn', 'Blackreach', 'Cephalon'], suffixes: ['Lab', 'Research', 'Facility'] },
            lootTable: 'container_locked', lootModifiers: { crafting: 3.0, augment: 2.0 },
            storyChance: 0.50, enemyMod: 1.5, icon: '🔬'
        },
        bunker: {
            category: 'scavenge', buildingTemplate: 'bunker',
            biomeWeight: { grassy: 5, barren: 15, apocalyptic: 10 },
            names: { prefixes: ['Site', 'Vault', 'Shelter', 'Outpost', 'Fallback', 'Echo'], suffixes: ['Alpha', 'Bravo', 'Seven', 'Twelve', 'Zero'] },
            lootTable: 'container_locked', lootModifiers: { weapon: 1.5, ammo: 2.0, medical: 1.5 },
            storyChance: 0.30, enemyMod: 1.2, icon: '🕳'
        }
    },
    storyEvents: {
        gas_station: [
            { title: 'Barricaded Survivor', text: 'A survivor is barricaded inside, shouting through the glass. He says he\'ll trade fuel for safe passage.',
              choices: [
                { label: 'Help him', outcome: 'fuel', value: 5, followUp: 'He hands you a fuel canister. "There\'s more inside."' },
                { label: 'Demand supplies', outcome: 'loot_bonus', value: 1.5, followUp: 'He reluctantly shoves a bag through the gap.' },
                { label: 'Move on', outcome: 'none', followUp: 'You leave him to his fortress of glass and steel.' }
            ]},
            { title: 'Fuel Leak', text: 'Gas pools on the ground. One spark and this place goes up. The pumps still have fuel in them.',
              choices: [
                { label: 'Risk it — siphon fuel', outcome: 'fuel_risky', value: 8, risk: 0.3, riskCost: 'hp', riskValue: 25, followUp: 'You fill up. Your hands are shaking.' },
                { label: 'Play it safe', outcome: 'none', followUp: 'Not worth dying over a few gallons.' }
            ]}
        ],
        pharmacy: [
            { title: 'Locked Cabinet', text: 'The pharmacy\'s controlled substances cabinet is still sealed. Something valuable might be inside.',
              choices: [
                { label: 'Force it open', outcome: 'medical_bonus', value: 2.0, followUp: 'Medical supplies spill out. Jackpot.' },
                { label: 'Search elsewhere', outcome: 'loot_bonus', value: 1.2, followUp: 'You find useful supplies on the shelves instead.' }
            ]}
        ],
        house: [
            { title: 'Family Photos', text: 'Photos line the hallway. A child\'s drawing on the fridge reads "Daddy come home." A radio crackles on a Foundry frequency.',
              choices: [
                { label: 'Tune in', outcome: 'lore', value: 1, followUp: 'A Cephalon broadcast. Coordinates. Instructions. Something about "Phase 3."' },
                { label: 'Turn it off', outcome: 'none', followUp: 'Some signals are better left unheard.' }
            ]},
            { title: 'Hidden Cellar', text: 'A rug in the living room covers a trap door. Scratch marks suggest it\'s been opened recently.',
              choices: [
                { label: 'Open it', outcome: 'loot_bonus', value: 2.0, risk: 0.25, riskCost: 'ambush', riskValue: 3, followUp: 'A stash of supplies — someone was preparing for the worst.' },
                { label: 'Leave it', outcome: 'none', followUp: 'Whatever\'s down there can stay down there.' }
            ]}
        ],
        church: [
            { title: 'Cube Markings', text: 'The walls are covered in geometric patterns. Not graffiti — something precise. Mathematical. The air hums.',
              choices: [
                { label: 'Study them', outcome: 'lore', value: 2, followUp: 'The patterns resolve into coordinates. A Cube resonance frequency. Your head throbs.' },
                { label: 'Pray', outcome: 'hp', value: 15, followUp: 'You kneel. The humming fades. You feel... restored.' },
                { label: 'Back away', outcome: 'none', followUp: 'Some knowledge has teeth.' }
            ]}
        ],
        research_lab: [
            { title: 'Active Terminal', text: 'A terminal flickers with Cube frequency data. The screen shows a Foundry seal.',
              choices: [
                { label: 'Download data', outcome: 'lore', value: 3, risk: 0.2, riskCost: 'alarm', riskValue: 4, followUp: 'Data copied. But something noticed.' },
                { label: 'Destroy it', outcome: 'safe_entry', value: 1, followUp: 'The screen dies. Fewer surprises inside.' },
                { label: 'Bypass', outcome: 'none', followUp: 'You step around it carefully.' }
            ]},
            { title: 'Specimen Chamber', text: 'Glass pods line the corridor. Most are shattered. One still pulses with a faint violet glow.',
              choices: [
                { label: 'Open the pod', outcome: 'augment', value: 1, risk: 0.4, riskCost: 'hp', riskValue: 30, followUp: 'A crystalline fragment. It burns cold in your hand.' },
                { label: 'Seal the room', outcome: 'safe_entry', value: 1, followUp: 'Better locked than loose.' }
            ]}
        ],
        motel: [
            { title: 'Do Not Disturb', text: 'Room 7 has the deadbolt engaged from inside. A low growl comes from behind the door.',
              choices: [
                { label: 'Kick it in', outcome: 'loot_bonus', value: 1.5, risk: 0.4, riskCost: 'ambush', riskValue: 2, followUp: 'The room is trashed but there\'s gear inside.' },
                { label: 'Try another room', outcome: 'none', followUp: 'Plenty of other doors to try.' }
            ]}
        ],
        warehouse: [
            { title: 'Shipping Manifest', text: 'A clipboard on the loading dock lists recent deliveries. One entry is marked "BLACKREACH — DO NOT OPEN."',
              choices: [
                { label: 'Find that crate', outcome: 'loot_bonus', value: 2.0, followUp: 'Row 7, Bay 3. The crate is heavy. Worth it.' },
                { label: 'Grab what\'s easy', outcome: 'loot_bonus', value: 1.2, followUp: 'You fill your pack from the nearest pallets.' }
            ]}
        ],
        bunker: [
            { title: 'Emergency Broadcast', text: 'The bunker\'s PA system crackles to life. A pre-recorded voice: "If you can hear this, the Collapse has begun. Proceed to—" Static.',
              choices: [
                { label: 'Search for the rest', outcome: 'lore', value: 2, followUp: 'You find a partial message. Coordinates. A name: "Project Vestige."' },
                { label: 'Loot and leave', outcome: 'loot_bonus', value: 1.3, followUp: 'Answers can wait. Supplies can\'t.' }
            ]}
        ],
        police_station: [
            { title: 'Evidence Lockup', text: 'The evidence room gate is ajar. Confiscated weapons line the shelves.',
              choices: [
                { label: 'Take what you need', outcome: 'weapon_bonus', value: 2.0, followUp: 'Firearms, ammunition, a tactical vest. Law and order is over.' },
                { label: 'Check the cells first', outcome: 'loot_bonus', value: 1.3, risk: 0.3, riskCost: 'ambush', riskValue: 2, followUp: 'Something was locked in here. Not anymore.' }
            ]}
        ],
        school: [
            { title: 'Gymnasium Shelter', text: 'Cots and supplies are set up in the gym. This was an evacuation point. Most of the supplies are gone, but not all.',
              choices: [
                { label: 'Search thoroughly', outcome: 'loot_bonus', value: 1.5, followUp: 'Under the bleachers: canned food, first aid, a child\'s stuffed bear.' },
                { label: 'Read the bulletin board', outcome: 'lore', value: 1, followUp: 'Evacuation routes. Foundry relief schedules. Names of the missing.' }
            ]}
        ],
        apartment: [
            { title: 'Rooftop Signal', text: 'Someone rigged a radio antenna on the roof. It\'s still broadcasting — a repeating tone on a Sworn frequency.',
              choices: [
                { label: 'Follow the signal up', outcome: 'lore', value: 2, followUp: 'The roof. The view. And a message scratched into the antenna base: "THEY ARE LISTENING."' },
                { label: 'Cut the wire', outcome: 'safe_entry', value: 1, followUp: 'The signal dies. Whatever it was calling, it stops.' }
            ]}
        ],
        diner: [
            { title: 'Last Supper', text: 'Tables are set. Food still on plates — calcified but arranged. Someone recreated a dinner party. A note reads: "One last meal before the end."',
              choices: [
                { label: 'Check the kitchen', outcome: 'loot_bonus', value: 1.5, followUp: 'Canned goods behind the counter. Enough to matter.' },
                { label: 'Sit down', outcome: 'hp', value: 10, followUp: 'You rest. Just for a moment. It helps.' }
            ]}
        ],
        auto_shop: [
            { title: 'Work Order', text: 'A vehicle is up on the lift. The work order says "UCR Fleet — Priority." The toolboxes look untouched.',
              choices: [
                { label: 'Grab the tools', outcome: 'loot_bonus', value: 1.5, followUp: 'Quality tools. Useful for repairs and modifications.' },
                { label: 'Check the vehicle', outcome: 'fuel', value: 3, followUp: 'Still has fuel in the lines. You drain what you can.' }
            ]}
        ]
    },
    buildingArchetypes: {
        residential: {
            name: 'Residential',
            sizeMultiplier: 2.5,
            floor: { base: 0x2a2525, accent: 0x352520, pattern: 'wood' },
            walls: { color: 0x4a4540, trim: 0x3a3530, style: 'plaster' },
            light: { color: 0xffddaa, size: [140, 110], inner: [80, 60], alpha: [0.05, 0.10], innerAlpha: [0.03, 0.07], speed: 2500, innerSpeed: 1800, scale: [1, 1.01], pos: 0.35, offsetX: 0.2 },
            roomCount: [2, 3],    // side rooms
            hasStairs: true,
            lootPool: {
                common: ['Bandage', 'Cloth', 'Ration'],
                uncommon: ['Power Ammo', 'Wire'],
                rare: ['Bandage', 'Bandage', 'Power Ammo']
            },
            enemyChance: 0.4,     // chance per side room
            enemyCount: [1, 2],   // per room if spawned
            enemyTypes: ['husk', 'husk_crawl'],
            ambience: 'lived_in'  // decor style
        },
        commercial: {
            name: 'Commercial',
            sizeMultiplier: 2.2,
            floor: { base: 0x2a2520, accent: 0x252018, pattern: 'checker' },
            walls: { color: 0x484848, trim: 0x383838, style: 'bare' },
            light: { color: 0xccddff, size: [120, 80], inner: [60, 40], alpha: [0.0, 0.12], innerAlpha: [0.0, 0.08], speed: 80, innerSpeed: 50, scale: [1, 1.02], pos: 0.4, hold: 1500, repeatDelay: 1000 },
            roomCount: [1, 2],
            hasStairs: false,
            lootPool: {
                common: ['Ration', 'Ration', 'Bandage'],
                uncommon: ['Power Ammo', 'Scrap Metal'],
                rare: ['Bandage', 'Power Ammo', 'Power Ammo']
            },
            enemyChance: 0.5,
            enemyCount: [1, 2],
            enemyTypes: ['husk', 'flicker'],
            ambience: 'ransacked'
        },
        industrial: {
            name: 'Industrial',
            sizeMultiplier: 2.8,
            floor: { base: 0x252525, accent: 0x202020, pattern: 'concrete' },
            walls: { color: 0x3a3a3a, trim: 0x2a2a2a, style: 'cinderblock' },
            light: { color: 0xffaa44, size: [100, 80], inner: [50, 40], alpha: [0.0, 0.15], innerAlpha: [0.0, 0.10], speed: 60, innerSpeed: 40, scale: [0.8, 1.2], pos: 0.3, offsetX: -0.3, burst: true },
            roomCount: [1, 2],
            hasStairs: false,
            lootPool: {
                common: ['Scrap Metal', 'Wire', 'Power Ammo'],
                uncommon: ['Power Ammo', 'Power Ammo', 'Wire'],
                rare: ['Scrap Metal', 'Scrap Metal', 'Power Ammo', 'Power Ammo']
            },
            enemyChance: 0.6,
            enemyCount: [1, 3],
            enemyTypes: ['husk', 'husk_crawl', 'flicker'],
            ambience: 'industrial'
        },
        civic: {
            name: 'Civic',
            sizeMultiplier: 2.4,
            floor: { base: 0x252a2a, accent: 0x203030, pattern: 'tile' },
            walls: { color: 0x454a55, trim: 0x353a45, style: 'concrete' },
            light: { color: 0xddeeff, size: [160, 120], inner: [90, 65], alpha: [0.05, 0.08], innerAlpha: [0.03, 0.06], speed: 100, innerSpeed: 60, scale: [1, 1.01], pos: 0.4 },
            roomCount: [2, 3],
            hasStairs: true,
            lootPool: {
                common: ['Bandage', 'Cloth', 'Wire'],
                uncommon: ['Bandage', 'Bandage', 'Scrap Metal'],
                rare: ['Bandage', 'Bandage', 'Bandage', 'Power Ammo']
            },
            enemyChance: 0.5,
            enemyCount: [1, 2],
            enemyTypes: ['husk', 'husk_crawl'],
            ambience: 'institutional'
        },
        shelter: {
            name: 'Shelter',
            sizeMultiplier: 1.8,
            floor: { base: 0x2a2822, accent: 0x252018, pattern: 'concrete' },
            walls: { color: 0x3a3a30, trim: 0x2a2a22, style: 'bare' },
            light: { color: 0xffffdd, size: [90, 65], inner: [45, 32], alpha: [0.02, 0.05], innerAlpha: [0.01, 0.03], speed: 3000, innerSpeed: 2200, scale: [1, 1.01], pos: 0.4 },
            roomCount: [0, 1],
            hasStairs: false,
            lootPool: {
                common: ['Cloth', 'Scrap Metal'],
                uncommon: ['Ration', 'Bandage'],
                rare: ['Power Ammo', 'Wire', 'Bandage']
            },
            enemyChance: 0.3,
            enemyCount: [1, 1],
            enemyTypes: ['husk_crawl'],
            ambience: 'abandoned'
        }
    },
    buildingTemplates: {
        // Residential
        house: { width: [80, 100], height: [70, 90], color: 0x3a3535, archetype: 'residential', names: ['House', 'Home'],
            shapes: ['rect', 'rect', 'L_right', 'L_left'], interiorScale: [2.2, 2.8] },
        house_large: { width: [110, 140], height: [90, 110], color: 0x3a3030, archetype: 'residential', names: ['House', 'Residence'],
            shapes: ['rect', 'L_right', 'L_left'], interiorScale: [2.5, 3.2] },
        apartment: { width: [130, 160], height: [100, 130], color: 0x3a3038, archetype: 'residential', names: ['Apartments', 'Tenement', 'Flats'],
            shapes: ['rect', 'L_right', 'L_left'], interiorScale: [2.6, 3.4] },
        motel: { width: [140, 170], height: [80, 100], color: 0x3a3530, archetype: 'commercial', names: ['Motel', 'Motor Inn', 'Lodge'],
            shapes: ['rect', 'L_right'], interiorScale: [2.0, 2.6] },
        
        // Commercial
        store: { width: [100, 130], height: [80, 100], color: 0x3a3530, archetype: 'commercial', names: ['Store', 'Mini Mart', 'Shop'],
            shapes: ['rect', 'rect', 'L_right'], interiorScale: [2.0, 2.6] },
        pharmacy: { width: [90, 110], height: [75, 90], color: 0x354040, archetype: 'commercial', subtype: 'pharmacy', names: ['Pharmacy', 'Drugstore'],
            shapes: ['rect'], interiorScale: [2.0, 2.5] },
        restaurant: { width: [100, 120], height: [80, 95], color: 0x403530, archetype: 'commercial', names: ['Restaurant', 'Diner', 'Cafe'],
            shapes: ['rect', 'L_left'], interiorScale: [2.2, 2.8] },
        gas_station_main: { width: [120, 150], height: [90, 110], color: 0x2a3530, archetype: 'commercial', subtype: 'gas_station', names: ['Gas Station', 'Fuel Stop'],
            shapes: ['rect'], interiorScale: [1.8, 2.4] },
        convenience: { width: [70, 90], height: [75, 90], color: 0x354038, archetype: 'commercial', names: ['Quick Stop', 'Corner Store', 'Bodega'],
            shapes: ['rect'], interiorScale: [1.8, 2.2] },
        
        // Industrial
        warehouse: { width: [150, 180], height: [110, 140], color: 0x2a2a2a, archetype: 'industrial', names: ['Warehouse', 'Storage Depot'],
            shapes: ['rect', 'L_right', 'L_left'], interiorScale: [2.8, 3.6] },
        factory: { width: [160, 200], height: [120, 150], color: 0x252525, archetype: 'industrial', names: ['Factory', 'Plant'],
            shapes: ['rect', 'L_right'], interiorScale: [3.0, 3.8] },
        garage: { width: [80, 100], height: [70, 85], color: 0x2a2a2a, archetype: 'industrial', names: ['Garage', 'Auto Shop'],
            shapes: ['rect'], interiorScale: [2.2, 2.8] },
        storage_unit: { width: [60, 80], height: [65, 80], color: 0x333333, archetype: 'industrial', names: ['Storage', 'Locker'],
            shapes: ['rect'], interiorScale: [1.6, 2.0] },
        loading_dock: { width: [120, 150], height: [80, 100], color: 0x282828, archetype: 'industrial', names: ['Loading Dock', 'Freight Bay'],
            shapes: ['rect', 'L_left'], interiorScale: [2.4, 3.0] },
        
        // Civic
        hospital_main: { width: [180, 220], height: [140, 170], color: 0x404548, archetype: 'civic', subtype: 'hospital', names: ['Hospital', 'Medical Center'],
            shapes: ['rect', 'L_right', 'L_left'], interiorScale: [2.8, 3.6] },
        office_building: { width: [120, 160], height: [140, 180], color: 0x404550, archetype: 'civic', names: ['Office', 'Office Building'],
            shapes: ['rect', 'L_right'], interiorScale: [2.4, 3.0] },
        church: { width: [100, 130], height: [90, 120], color: 0x4a4540, archetype: 'civic', names: ['Church', 'Chapel'],
            shapes: ['rect'], interiorScale: [2.4, 3.0] },
        park_restroom: { width: [50, 65], height: [55, 65], color: 0x4a4a42, archetype: 'shelter', names: ['Restroom', 'Facilities'],
            shapes: ['rect'], interiorScale: [1.4, 1.8] },
        police_station: { width: [120, 150], height: [90, 120], color: 0x3a3a4a, archetype: 'civic', names: ['Police Station', 'Precinct'],
            shapes: ['rect', 'L_right'], interiorScale: [2.4, 3.2] },
        
        // Shelter
        shed: { width: [40, 55], height: [50, 60], color: 0x3a3a30, archetype: 'shelter', names: ['Shed', 'Tool Shed', 'Outhouse'],
            shapes: ['rect'], interiorScale: [1.4, 1.8] },
        small_shed: { width: [30, 40], height: [40, 50], color: 0x353530, archetype: 'shelter', names: ['Shed', 'Shack'],
            shapes: ['rect'], interiorScale: [1.2, 1.6] },
        rest_stop: { width: [100, 120], height: [80, 95], color: 0x354035, archetype: 'commercial', names: ['Rest Stop', 'Travel Center'],
            shapes: ['rect'], interiorScale: [2.0, 2.6] },
        ruins: { width: [80, 120], height: [75, 100], color: 0x2a2a28, archetype: 'shelter', names: ['Ruins', 'Collapsed Building', 'Wreckage'],
            shapes: ['rect'], alwaysDamaged: true, interiorScale: [1.6, 2.2] },
        bunker: { width: [60, 80], height: [65, 80], color: 0x303030, archetype: 'industrial', names: ['Bunker', 'Fallout Shelter'],
            shapes: ['rect'], interiorScale: [1.6, 2.2] }
    },
    propTemplates: {
        tree: { width: 30, height: 40, collision: true, colWidth: 12, colHeight: 25 },
        tree_pine: { width: 25, height: 45, collision: true, colWidth: 10, colHeight: 25 },
        dead_tree: { width: 25, height: 40, collision: true, colWidth: 10, colHeight: 20 },
        converted_tree: { width: 30, height: 40, collision: true, colWidth: 10, colHeight: 20 },
        fuel_pump: { width: 20, height: 35, collision: true, colWidth: 20, colHeight: 35 },
        car_wreck: { width: 56, height: 34, collision: true, colWidth: 56, colHeight: 34 },
        truck_wreck: { width: 76, height: 34, collision: true, colWidth: 76, colHeight: 34 },
        dumpster: { width: 35, height: 25, collision: true, colWidth: 35, colHeight: 25 },
        oil_barrel: { width: 15, height: 15, collision: true, colWidth: 15, colHeight: 15 },
        crate_stack: { width: 30, height: 30, collision: true, colWidth: 30, colHeight: 30 },
        shipping_container: { width: 80, height: 30, collision: true, colWidth: 80, colHeight: 30 },
        forklift: { width: 30, height: 40, collision: true, colWidth: 30, colHeight: 40 },
        mailbox: { width: 10, height: 15, collision: false },
        trash_can: { width: 12, height: 12, collision: true, colWidth: 12, colHeight: 12 },
        bench: { width: 32, height: 10, collision: false },
        fence_h: { width: 60, height: 8, collision: true, colWidth: 60, colHeight: 8 },
        barrier: { width: 50, height: 12, collision: true, colWidth: 50, colHeight: 12 },
        lamp_post: { width: 8, height: 50, collision: true, colWidth: 8, colHeight: 8 },
        sign_post: { width: 8, height: 40, collision: true, colWidth: 8, colHeight: 8 },
        shopping_cart: { width: 18, height: 24, collision: false },
        newspaper_box: { width: 14, height: 18, collision: true, colWidth: 14, colHeight: 18 },
        fire_hydrant: { width: 12, height: 16, collision: true, colWidth: 12, colHeight: 16 },
        // Anomalous biome props
        crystal_spire: { width: 10, height: 24, collision: true, colWidth: 8, colHeight: 10 },
        cube_node: { width: 12, height: 12, collision: true, colWidth: 10, colHeight: 10 },
        organ_pillar: { width: 12, height: 20, collision: true, colWidth: 10, colHeight: 14 },
        corrupted_lamp: { width: 8, height: 40, collision: true, colWidth: 6, colHeight: 8 },
        fungal_cluster: { width: 20, height: 12, collision: false },
        cephalon_shrine: { width: 24, height: 16, collision: true, colWidth: 22, colHeight: 14 },
        // Wasteland biome props
        bleached_skeleton: { width: 20, height: 10, collision: false },
        rock_cairn: { width: 10, height: 12, collision: true, colWidth: 8, colHeight: 8 },
        abandoned_tent: { width: 20, height: 12, collision: true, colWidth: 18, colHeight: 10 },
        dried_wellhead: { width: 12, height: 16, collision: true, colWidth: 10, colHeight: 12 },
        barbed_wire: { width: 16, height: 8, collision: false },
        collapsed_billboard: { width: 34, height: 12, collision: true, colWidth: 32, colHeight: 10 },
        // Overgrown round 2
        doghouse: { width: 14, height: 12, collision: true, colWidth: 12, colHeight: 10 },
        gutted_fridge: { width: 12, height: 20, collision: true, colWidth: 10, colHeight: 14 },
        playground_slide: { width: 14, height: 22, collision: true, colWidth: 12, colHeight: 16 },
        lawn_chair: { width: 10, height: 12, collision: false },
        tire_stack: { width: 12, height: 14, collision: true, colWidth: 10, colHeight: 10 },
        porch_steps: { width: 16, height: 14, collision: true, colWidth: 14, colHeight: 12 },
        // Wasteland round 2
        cracked_cistern: { width: 16, height: 12, collision: true, colWidth: 14, colHeight: 10 },
        dust_generator: { width: 12, height: 10, collision: true, colWidth: 10, colHeight: 8 },
        tipped_portapotty: { width: 10, height: 14, collision: true, colWidth: 10, colHeight: 12 },
        exposed_foundation: { width: 28, height: 6, collision: false },
        buried_road_sign: { width: 8, height: 10, collision: true, colWidth: 6, colHeight: 6 },
        concrete_barrier_wl: { width: 20, height: 8, collision: true, colWidth: 18, colHeight: 8 },
        // Anomalous round 2
        metallic_vine: { width: 20, height: 24, collision: false },
        shattered_cube: { width: 18, height: 12, collision: false },
        bone_arch: { width: 16, height: 20, collision: true, colWidth: 4, colHeight: 4 },
        spore_tower: { width: 8, height: 26, collision: true, colWidth: 6, colHeight: 8 },
        geometric_crater: { width: 18, height: 4, collision: false },
        converted_dumpster: { width: 16, height: 12, collision: true, colWidth: 14, colHeight: 10 }
    }
};

